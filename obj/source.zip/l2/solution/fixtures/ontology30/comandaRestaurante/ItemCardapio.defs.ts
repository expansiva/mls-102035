/// <mls fileReference="_102047_/l4/comandaRestaurante/ontology/ItemCardapio.defs.ts" enhancement="_blank"/>

import type { Ns5OntologyEntityArtifact, Ns5Readonly } from '/_102035_/l2/solution/types.js';

export const comandaRestauranteEntityItemCardapio = {
  "schemaVersion": "2026-09-11-ns5-ontology-v2",
  "moduleName": "comandaRestaurante",
  "entityId": "ItemCardapio",
  "title": "Item do cardápio",
  "description": "Produto oferecido no cardápio do restaurante, com informações comerciais específicas do cardápio.",
  "kind": "mdm",
  "party": "none",
  "mdmSubtype": "Product",
  "displayField": "name",
  "fields": [
    {
      "fieldId": "preco",
      "title": "Preço",
      "type": "money",
      "required": true,
      "description": "Preço de venda atual do item no cardápio."
    }
  ],
  "fieldsBase": [
    { "fieldId": "name", "title": "Nome", "type": "string", "required": true, "description": "Nome do item do cardápio." },
    { "fieldId": "category", "title": "Categoria", "type": "string", "required": true, "description": "Categoria do item no cardápio (ex.: entrada, prato principal, bebida)." },
    { "fieldId": "unitOfMeasure", "title": "Unidade de medida", "type": "string", "required": true, "description": "Unidade de medida do item (ex.: unidade, porção, ml)." }
  ],
  "lifecycleStates": [],
  "transitions": [],
  "storage": {
    "target": "mdm",
    "scope": "organization",
    "idField": "id",
    "mdmType": "comandaRestaurante.ItemCardapio"
  }
} as const satisfies Ns5Readonly<Ns5OntologyEntityArtifact>;

export type ComandaRestauranteEntityItemCardapioType = typeof comandaRestauranteEntityItemCardapio;

export default comandaRestauranteEntityItemCardapio;
