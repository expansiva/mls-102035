/// <mls fileReference="_102035_/l2/agentNewSolution5/replayRealRuns.test.ts" enhancement="_blank"/>

import assert from 'node:assert/strict';
import test from 'node:test';

import { parseNs4ClassicDefsSource } from '/_102035_/l2/agentNewSolution/helpers/ns4ClassicDefs.js';
import {
  loadNs5Actors,
  loadNs5Entities,
  loadNs5FixtureJson,
  loadNs5FixtureText,
  loadNs5Journeys,
  loadNs5Module,
  loadNs5OntologyIndex,
  loadNs5OracleSources,
  ns5ReplayModules,
  stripNs5Hashes,
  stripNs5HashSource,
} from '/_102035_/l2/agentNewSolution5/helpers/ns5RealFixtures.test.js';
import {
  applyNs5AccessFormNormalizations,
  buildNs5AccessArtifact,
  normalizeNs5AccessPayload,
} from '/_102035_/l2/agentNewSolution5/steps/access60/contracts.js';
import { validateNs5Access } from '/_102035_/l2/agentNewSolution5/steps/access60/gate.js';
import { runNs5Oracle } from '/_102035_/l2/agentNewSolution5/steps/finalize80/gate.js';
import {
  buildNs5IntegrationArtifact,
  normalizeNs5IntegrationPayload,
} from '/_102035_/l2/agentNewSolution5/steps/integration70/contracts.js';
import { validateNs5Integration } from '/_102035_/l2/agentNewSolution5/steps/integration70/gate.js';
import {
  applyNs5InferredActorDrop,
  validateNs5Journeys,
} from '/_102035_/l2/agentNewSolution5/steps/journeys20/gate.js';
import {
  buildNs5JourneyIndex,
  hashNs5Journey,
  normalizeNs5JourneysPayload,
} from '/_102035_/l2/agentNewSolution5/steps/journeys20/contracts.js';
import { normalizeNs5ModuleArtifact } from '/_102035_/l2/agentNewSolution5/steps/module10/contracts.js';
import { validateNs5ModuleArtifact } from '/_102035_/l2/agentNewSolution5/steps/module10/gate.js';
import {
  assembleNs5Ontology,
  normalizeNs5OntologyBindings,
  normalizeNs5OntologyEntity,
  normalizeNs5OntologyPlan,
} from '/_102035_/l2/agentNewSolution5/steps/ontology30/contracts.js';
import { validateNs5OntologyBindings } from '/_102035_/l2/agentNewSolution5/steps/ontology30/gate.js';
import { ns5RuleEntries } from '/_102035_/l2/solution/rulesView.js';
import {
  buildNs5RulesArtifact,
  buildNs5RulesArtifactV2,
  normalizeNs5RulesPayload,
} from '/_102035_/l2/agentNewSolution5/steps/rules40/contracts.js';
import { validateNs5Rules } from '/_102035_/l2/agentNewSolution5/steps/rules40/gate.js';
import {
  buildNs5WorkflowsArtifact,
  normalizeNs5WorkflowsPayload,
} from '/_102035_/l2/agentNewSolution5/steps/workflows50/contracts.js';
import { validateNs5Workflows } from '/_102035_/l2/agentNewSolution5/steps/workflows50/gate.js';
import { renderDefsSource, type Ns5FileInfo } from '/_102035_/l2/solution/fs.js';
import { ns5OntologyEdges, ns5OntologyEntityViews } from '/_102035_/l2/solution/ontologyView.js';
import type {
  Ns5JourneyArtifact,
  Ns5ModuleArtifact,
  Ns5OntologyEntityArtifact,
  Ns5SystemDecision,
} from '/_102035_/l2/solution/types.js';

const PROJECT = 102047;

function defsFile(folder: string, shortName: string): Ns5FileInfo {
  return { project: PROJECT, level: 4, folder, shortName, extension: '.defs.ts' };
}

function assertDefsMatch(rendered: string, recorded: string, label: string): void {
  const renderedJson = parseNs4ClassicDefsSource<unknown>(rendered);
  const recordedJson = parseNs4ClassicDefsSource<unknown>(recorded);
  assert.deepEqual(stripNs5Hashes(renderedJson), stripNs5Hashes(recordedJson), `${label} json`);
  assert.equal(stripNs5HashSource(rendered), stripNs5HashSource(recorded), `${label} source`);
}

function render(
  folder: string,
  shortName: string,
  exportName: string,
  value: unknown,
  typeName: string,
): string {
  return renderDefsSource(defsFile(folder, shortName), exportName, value, typeName);
}

/** ns5_43 T7: the shared view answers for both forms, so the replay does not assume v2. */
function accessView(entities: Ns5OntologyAnyEntity[]) {
  return ns5OntologyEntityViews(entities).map(view => ({
    entityId: view.entityId,
    party: view.party,
    fields: view.fields.map(field => ({ fieldId: field.fieldId })),
    ...(view.details ? { details: view.details } : {}),
    storage: { idField: view.idField },
    ...(view.writer && view.writer !== 'journey' ? { writer: view.writer } : {}),
    ...(view.paths ? { paths: view.paths } : {}),
  }));
}

function workflowJourneyView(journeys: Ns5JourneyArtifact[]) {
  return journeys.map(journey => ({
    journeyId: journey.journeyId,
    business: {
      actorRef: journey.business.actorRef,
      steps: journey.business.steps.map(step => ({
        stepId: step.stepId,
        kind: step.kind,
        entity: step.entity,
        ...(step.handoffTo ? { handoffTo: step.handoffTo } : {}),
      })),
    },
  }));
}

for (const moduleName of ns5ReplayModules()) {
  void test(`${moduleName} module10 draft replays to module.defs.ts`, () => {
    const draft = loadNs5FixtureJson<Ns5ModuleArtifact & { actors: unknown[] }>('steps/module10/fixtures', `${moduleName}-draft.json`);
    const { artifact, actors } = normalizeNs5ModuleArtifact(draft, {
      sourcePrompt: draft.sourcePrompt,
      fixedModuleName: moduleName,
    });
    const gate = validateNs5ModuleArtifact(artifact, { fixedModuleName: moduleName, actors });
    assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
    const recordedText = loadNs5FixtureText('steps/module10/fixtures', `${moduleName}-module.defs.ts`);
    const recorded = parseNs4ClassicDefsSource<Ns5ModuleArtifact>(recordedText);
    // ontology30 may later write lifted `details` onto the same path; module10 does not.
    const { details: _lifted, ...recordedModule10 } = recorded as Ns5ModuleArtifact & { details?: unknown };
    assert.deepEqual(stripNs5Hashes(artifact), stripNs5Hashes(recordedModule10), 'module json');
    if (!recorded.details) {
      const rendered = render(moduleName, 'module', `${moduleName}Module`, artifact, 'Ns5ModuleArtifact');
      assertDefsMatch(rendered, recordedText, 'module');
    }
  });

  void test(`${moduleName} journeys20 draft replays to journeys/*.defs.ts`, async () => {
    const draft = loadNs5FixtureJson<{ journeys: unknown[]; systemDecisions?: unknown[] }>(
      'steps/journeys20/fixtures',
      `${moduleName}-draft.json`,
    );
    const actors = loadNs5Actors(moduleName);
    const { journeys } = normalizeNs5JourneysPayload(draft);
    const gate = validateNs5Journeys(journeys, { actors, moduleName });
    assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
    const dropped = applyNs5InferredActorDrop(journeys, actors);
    const artifacts: Ns5JourneyArtifact[] = [];
    for (const journey of dropped.journeys) artifacts.push(await hashNs5Journey(journey));
    const index = buildNs5JourneyIndex(moduleName, artifacts, dropped.systemDecisions);
    for (const artifact of artifacts) {
      const rendered = render(
        `${moduleName}/journeys`,
        artifact.journeyId,
        `${artifact.journeyId}Journey`,
        artifact,
        'Ns5JourneyArtifact',
      );
      assertDefsMatch(
        rendered,
        loadNs5FixtureText('steps/journeys20/fixtures', moduleName, `${artifact.journeyId}.defs.ts`),
        artifact.journeyId,
      );
    }
    const indexRendered = render(
      `${moduleName}/journeys`,
      'index',
      `${moduleName}JourneyIndex`,
      index,
      'Ns5JourneyIndexArtifact',
    );
    assertDefsMatch(
      indexRendered,
      loadNs5FixtureText('steps/journeys20/fixtures', moduleName, 'index.defs.ts'),
      'journey index',
    );
  });

  /**
   * DELIBERATELY v2 (ns5_42 / ns5_43 T7). `ontology30` now GENERATES v3, but the eleven recorded
   * modules were produced by the v2 normalize and gate, which `contracts.ts` / `gate.ts` keep
   * unchanged next to `contractsV3.ts` / `gateV3.ts`. They stay v2 until ns5_44 regenerates them;
   * the v3 form is proved against the four hand-written `agendaClinica` files in
   * `steps/ontology30/fixtures/agendaClinica-v3/` by `agentNs5OntologyV3.test.ts`.
   */
  void test(`${moduleName} ontology30 drafts replay to ontology/*.defs.ts`, () => {
    const planDraft = loadNs5FixtureJson<unknown>('steps/ontology30/fixtures', `${moduleName}-plan-draft.json`);
    const bindingsDraft = loadNs5FixtureJson<unknown>('steps/ontology30/fixtures', `${moduleName}-bindings-draft.json`);
    const journeys = loadNs5Journeys(moduleName);
    const plan = normalizeNs5OntologyPlan(planDraft, moduleName, journeys);
    const details = plan.entities.map(entity => {
      const raw = loadNs5FixtureJson<unknown>('steps/ontology30/fixtures', moduleName, `${entity.entityId}-draft.json`);
      return normalizeNs5OntologyEntity(raw, entity.entityId, journeys, {
        idField: entity.storage.idField,
        kind: entity.kind,
      });
    });
    const bindings = normalizeNs5OntologyBindings(bindingsDraft);
    const gate = validateNs5OntologyBindings(plan, details, bindings, {
      moduleName,
      actors: loadNs5Actors(moduleName),
      journeys,
    });
    assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
    const assembled = assembleNs5Ontology(plan, details, bindings);
    for (const entity of assembled.entities) {
      const rendered = render(
        `${moduleName}/ontology`,
        entity.entityId,
        `${moduleName}Entity${entity.entityId}`,
        entity,
        'Ns5OntologyEntityArtifact',
      );
      const recordedText = loadNs5FixtureText('steps/ontology30/fixtures', moduleName, `${entity.entityId}.defs.ts`);
      const recordedJson = parseNs4ClassicDefsSource<Ns5OntologyEntityArtifact & { fieldsBase?: unknown }>(recordedText);
      // ns5_36: fieldsBase is a hand-authored level-1 field selection overlay (mdm only, ns5_35a type),
      // not yet produced by ontology30 normalize/render — that lands with ns5_35. The replay still
      // proves everything else byte for byte via the json-level check below.
      const { fieldsBase: _fieldsBase, ...recordedWithoutFieldsBase } = recordedJson;
      assert.deepEqual(stripNs5Hashes(entity), stripNs5Hashes(recordedWithoutFieldsBase), `${entity.entityId} json`);
      if (!('fieldsBase' in recordedJson)) {
        assertDefsMatch(rendered, recordedText, entity.entityId);
      }
    }
    const indexRendered = render(
      `${moduleName}/ontology`,
      'index',
      `${moduleName}OntologyIndex`,
      assembled.index,
      'Ns5OntologyIndexArtifact',
    );
    assertDefsMatch(
      indexRendered,
      loadNs5FixtureText('steps/ontology30/fixtures', moduleName, 'index.defs.ts'),
      'ontology index',
    );
  });

  /**
   * ns5_45: the normalize now produces the MAP and the step emits `rules-v2`; these thirteen catalogs
   * were RECORDED in the v1 array form, so the replay renders them in the form they were recorded in.
   * `ruleId` is never integer-like, so map insertion order is the draft order and the byte-compare below
   * still proves the whole round trip array -> map -> array.
   */
  void test(`${moduleName} rules40 draft replays to rules.defs.ts`, () => {
    const draft = loadNs5FixtureJson<unknown>('steps/rules40/fixtures', `${moduleName}-draft.json`);
    const { rules, duplicateRuleIds } = normalizeNs5RulesPayload(draft);
    const gate = validateNs5Rules(rules, { moduleName, duplicateRuleIds });
    assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
    const artifact = buildNs5RulesArtifact(moduleName, ns5RuleEntries(buildNs5RulesArtifactV2(moduleName, rules)));
    const rendered = render(moduleName, 'rules', `${moduleName}Rules`, artifact, 'Ns5RulesArtifact');
    assertDefsMatch(rendered, loadNs5FixtureText('steps/rules40/fixtures', `${moduleName}-rules.defs.ts`), 'rules');
  });

  void test(`${moduleName} workflows50 draft replays to workflows.defs.ts`, () => {
    const draft = loadNs5FixtureJson<{ systemDecisions?: Ns5SystemDecision[] }>(
      'steps/workflows50/fixtures',
      `${moduleName}-draft.json`,
    );
    const normalized = normalizeNs5WorkflowsPayload(draft);
    const { processes, journeyDecisions } = normalized;
    // Draft is the post-normalize payload; re-normalize will not re-emit already-dropped duplicates.
    const systemDecisions = normalized.systemDecisions.length
      ? normalized.systemDecisions
      : (draft.systemDecisions ?? []);
    const journeys = loadNs5Journeys(moduleName);
    const entities = loadNs5Entities(moduleName);
    const gate = validateNs5Workflows(processes, {
      moduleName,
      actorIds: loadNs5Actors(moduleName).map(actor => actor.actorId),
      journeys: workflowJourneyView(journeys),
      entities: ns5OntologyEntityViews(entities).map(view => ({
        entityId: view.entityId,
        transitions: view.transitions.map(transition => ({ transitionId: transition.transitionId, by: transition.by })),
      })),
      journeyDecisions,
    });
    assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
    const artifact = buildNs5WorkflowsArtifact(moduleName, processes, journeyDecisions, systemDecisions);
    const rendered = render(moduleName, 'workflows', `${moduleName}Workflows`, artifact, 'Ns5WorkflowsArtifact');
    assertDefsMatch(rendered, loadNs5FixtureText('steps/workflows50/fixtures', `${moduleName}-workflows.defs.ts`), 'workflows');
  });

  void test(`${moduleName} access60 draft replays to access.defs.ts`, () => {
    const draft = loadNs5FixtureJson<unknown>('steps/access60/fixtures', `${moduleName}-draft.json`);
    const { grants: rawGrants } = normalizeNs5AccessPayload(draft);
    const actors = loadNs5Actors(moduleName);
    const entities = loadNs5Entities(moduleName);
    const { grants } = applyNs5AccessFormNormalizations(rawGrants, accessView(entities));
    const index = loadNs5OntologyIndex(moduleName);
    const journeys = loadNs5Journeys(moduleName);
    const gate = validateNs5Access(grants, {
      moduleName,
      actors,
      entities: accessView(entities),
      relationships: ns5OntologyEdges(index),
      journeys: journeys.map(journey => ({
        journeyId: journey.journeyId,
        business: { actorRef: journey.business.actorRef },
      })),
    });
    assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
    const artifact = buildNs5AccessArtifact(moduleName, actors, grants);
    const rendered = render(moduleName, 'access', `${moduleName}Access`, artifact, 'Ns5AccessArtifact');
    assertDefsMatch(rendered, loadNs5FixtureText('steps/access60/fixtures', `${moduleName}-access.defs.ts`), 'access');
  });

  void test(`${moduleName} integration70 draft replays to integration.defs.ts`, () => {
    const draft = loadNs5FixtureJson<unknown>('steps/integration70/fixtures', `${moduleName}-draft.json`);
    const { inbound, outbound, plugins } = normalizeNs5IntegrationPayload(draft);
    const moduleArtifact = loadNs5Module(moduleName);
    const entities = loadNs5Entities(moduleName);
    const gate = validateNs5Integration(inbound, outbound, plugins, {
      moduleName,
      actors: loadNs5Actors(moduleName),
      entities: entities.map(entity => ({ entityId: entity.entityId })),
      registryModuleNames: [],
      sourcePrompt: moduleArtifact.sourcePrompt,
    });
    assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
    const artifact = buildNs5IntegrationArtifact(moduleName, inbound, outbound, plugins);
    const rendered = render(moduleName, 'integration', `${moduleName}Integration`, artifact, 'Ns5IntegrationArtifact');
    assertDefsMatch(
      rendered,
      loadNs5FixtureText('steps/integration70/fixtures', `${moduleName}-integration.defs.ts`),
      'integration',
    );
  });

  void test(`${moduleName} finalize80 oracle on the recorded sources`, () => {
    const sources = loadNs5OracleSources(moduleName);
    const report = runNs5Oracle(sources);
    const recorded = loadNs5FixtureJson<{ finalStatus: string; errors: unknown[]; warnings: unknown[] }>(
      'steps/finalize80/fixtures',
      `${moduleName}-finalize-report.json`,
    );
    assert.equal(
      report.finalStatus,
      'passed',
      report.errors.map(issue => `${issue.code} ${issue.path}: ${issue.message}`).join('\n'),
    );
    assert.equal(report.errors.length, 0);
    assert.equal(recorded.finalStatus, 'passed');
    assert.equal(recorded.errors.length, 0);
  });
}

/**
 * ns5_42 T6: the replay set and the v3 form fixture are two different things and must stay apart.
 * `fixtures/<mod>/` is what the v2 generator produced and is replayed byte for byte;
 * `fixtures/agendaClinica-v3/` is the hand-written form the v3 generator has to reach. The same
 * module name lives in both, so this guards the day someone overwrites one with the other.
 */
void test('the v2 replay pack and the v3 form fixture of agendaClinica are distinct', () => {
  const v2 = parseNs4ClassicDefsSource<{ schemaVersion: string }>(
    loadNs5FixtureText('steps/ontology30/fixtures', 'agendaClinica', 'Paciente.defs.ts'),
  );
  const v3 = parseNs4ClassicDefsSource<{ schemaVersion: string; kind: string }>(
    loadNs5FixtureText('steps/ontology30/fixtures', 'agendaClinica-v3', 'Paciente.defs.ts'),
  );
  assert.equal(v2.schemaVersion, '2026-09-11-ns5-ontology-v2');
  assert.equal(v3.schemaVersion, '2026-09-15-ns5-ontology-v3');
  assert.equal(v3.kind, 'role');
});
