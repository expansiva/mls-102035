/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/finalize80/gate.ts" enhancement="_blank"/>

/**
 * Integrity oracle across the six NS5 sources. One code per check (I1–I13).
 * Errors fail the run; warnings do not.
 *
 * I2 checks `effect: 'transition'` + `transitionRef` against ontology (actor in `by`,
 * `from` reachable from source-SCC births) for journey `act` and for workflow
 * `mechanical`/`llm` stages. `create` and `update` are not I2 errors.
 * collectNs5LifecycleSignal / ns5LifecycleHasBranchingOrigin still gate `decide`.
 * ontology30 rejects appendOnly plus a transition act or decide first, with repair.
 */

import { anchorPath } from '/_102035_/l2/agentNewSolution5/steps/access60/contracts.js';
import {
  collectNs5LifecycleSignal,
  ns5EntityHasActOrAffects,
  ns5EntityHasWrittenFields,
  ns5EntityWriter,
  ns5LifecycleHasBranchingOrigin,
  ns5ReachableStates,
  ns5ResolveEntityWriter,
  ns5SourceSccStates,
} from '/_102035_/l2/agentNewSolution5/steps/ontology30/contracts.js';
import {
  ns5FieldRefExists,
  splitFieldRef,
  type Ns5RulesEntityView,
} from '/_102035_/l2/agentNewSolution5/steps/rules40/contracts.js';
import {
  collectNs5InboundPending,
  parseNs5InboundEventRef,
  parseNs5OutboundOn,
  parseNs5UsedBy,
} from '/_102035_/l2/agentNewSolution5/steps/integration70/contracts.js';
import {
  collectNs5Handoffs,
  collectNs5ProcessSignals,
  parseNs5TriggerEvent,
} from '/_102035_/l2/agentNewSolution5/steps/workflows50/contracts.js';
import type { Ns5OntologyEntityArtifact } from '/_102035_/l2/solution/types.js';
import {
  buildNs5FinalizeReport,
  NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION,
  NS5_FINALIZE_I2_POSSIBLE_MISSING_TRANSITION_REF,
  NS5_FINALIZE_I6_SYSTEM_TRANSITION_UNOWNED,
  NS5_FINALIZE_I8_LOGIN_PERSON_WITHOUT_REGISTRATION,
  NS5_FINALIZE_I11_INBOUND_PENDING_IN_SIBLING,
  oracleCode,
  type Ns5FinalizeReport,
  type Ns5OracleCheckId,
  type Ns5OracleIssue,
  type Ns5OracleSources,
} from '/_102035_/l2/agentNewSolution5/steps/finalize80/contracts.js';

export function runNs5Oracle(sources: Ns5OracleSources): Ns5FinalizeReport {
  const errors: Ns5OracleIssue[] = [];
  const warnings: Ns5OracleIssue[] = [];
  const add = (
    bucket: Ns5OracleIssue[],
    checkId: Ns5OracleCheckId,
    path: string,
    message: string,
    code?: Ns5OracleIssue['code'],
  ) => {
    bucket.push({ checkId, code: code || oracleCode(checkId), path, message });
  };
  const error: IssueFn = (checkId, path, message, code) => add(errors, checkId, path, message, code);
  const warning: IssueFn = (checkId, path, message, code) => add(warnings, checkId, path, message, code);

  checkI1(sources, error);
  checkI2(sources, error, warning);
  checkI3(sources, error);
  checkI4(sources, error);
  checkI5(sources, error);
  checkI6(sources, warning);
  checkI7(sources, error);
  checkI8(sources, error);
  checkI9(sources, error);
  checkI10(sources, error);
  checkI11(sources, warning);
  checkI12(sources, error);
  checkI13(sources, warning);

  return buildNs5FinalizeReport(sources.module.moduleName, errors, warnings, {
    actors: sources.access.actors.length,
    journeys: sources.journeys.length,
    entities: sources.entities.length,
    rules: sources.rules.rules.length,
    processes: sources.workflows.processes.length,
    grants: sources.access.grants.length,
  });
}

function checkI1(sources: Ns5OracleSources, error: IssueFn): void {
  const actorIds = new Set(sources.access.actors.map(actor => actor.actorId).filter(Boolean));
  const entityById = entityMap(sources);
  const entityIds = new Set(entityById.keys());
  const journeyById = new Map(sources.journeys.map(journey => [journey.journeyId, journey]));
  const journeyIds = new Set(journeyById.keys());

  for (const entry of sources.journeyIndex.journeys) {
    if (entry.actorRef && !actorIds.has(entry.actorRef)) {
      error('I1', `journeys/index.${entry.journeyId}.actorRef`, `Unknown actor ${entry.actorRef}.`);
    }
    if (entry.journeyId && !journeyIds.has(entry.journeyId)) {
      error('I1', `journeys/index.${entry.journeyId}`, `Unknown journey ${entry.journeyId}.`);
    }
  }

  for (const journey of sources.journeys) {
    const base = `journeys.${journey.journeyId}`;
    if (journey.business.actorRef && !actorIds.has(journey.business.actorRef)) {
      error('I1', `${base}.actorRef`, `Unknown actor ${journey.business.actorRef}.`);
    }
    journey.business.steps.forEach((step, index) => {
      const path = `${base}.steps[${index}]`;
      if (step.entity && !entityIds.has(step.entity) && !isLiftedModuleDetailRef(step.entity, sources)) {
        error('I1', `${path}.entity`, `Unknown entity ${step.entity}.`);
      }
      for (const extra of step.affects || []) {
        if (extra && !entityIds.has(extra) && !isLiftedModuleDetailRef(extra, sources)) {
          error('I1', `${path}.affects`, `Unknown entity ${extra}.`);
        }
      }
      if (step.handoffTo && !actorIds.has(step.handoffTo)) {
        error('I1', `${path}.handoffTo`, `Unknown actor ${step.handoffTo}.`);
      }
      if (step.transitionRef) {
        const entity = entityById.get(step.entity);
        const ids = new Set((entity?.transitions || []).map(item => item.transitionId).filter(Boolean));
        if (!ids.has(step.transitionRef)) {
          error('I1', `${path}.transitionRef`, `Unknown transition ${step.transitionRef}.`);
        }
      }
    });
  }

  for (const entity of sources.entities) {
    const states = new Set(entity.lifecycleStates.map(item => item.state).filter(Boolean));
    entity.transitions.forEach((transition, index) => {
      const path = `ontology.${entity.entityId}.transitions[${index}]`;
      for (const from of transition.from) {
        if (from && !states.has(from)) error('I1', `${path}.from`, `Unknown lifecycle state ${from}.`);
      }
      if (transition.to && !states.has(transition.to)) {
        error('I1', `${path}.to`, `Unknown lifecycle state ${transition.to}.`);
      }
      if (Array.isArray(transition.by)) {
        for (const actor of transition.by) {
          if (actor && !actorIds.has(actor)) error('I1', `${path}.by`, `Unknown actor ${actor}.`);
        }
      }
    });
  }

  sources.workflows.processes.forEach((process, processIndex) => {
    const base = `workflows.processes[${processIndex}]`;
    if (process.trigger.kind === 'manual' && process.trigger.actorRef && !actorIds.has(process.trigger.actorRef)) {
      error('I1', `${base}.trigger.actorRef`, `Unknown actor ${process.trigger.actorRef}.`);
    }
    if (process.trigger.kind === 'event' && process.trigger.event) {
      const parsed = parseNs5TriggerEvent(process.trigger.event);
      const inboundRef = parseNs5InboundEventRef(process.trigger.event);
      if (parsed) {
        if (!entityIds.has(parsed.entityId)) {
          error('I1', `${base}.trigger.event`, `Unknown entity ${parsed.entityId}.`);
        } else {
          const ids = new Set((entityById.get(parsed.entityId)?.transitions || []).map(item => item.transitionId));
          if (!ids.has(parsed.transitionId)) {
            error('I1', `${base}.trigger.event`, `Unknown transition ${parsed.entityId}.${parsed.transitionId}.`);
          }
        }
      } else if (inboundRef) {
        const inboundIds = new Set(
          sources.integration.inbound.map(item => `${item.from || ''}.${item.event || item.id}`),
        );
        if (!inboundIds.has(`${inboundRef.moduleName}.${inboundRef.eventId}`)) {
          error('I1', `${base}.trigger.event`, `Unknown inbound event ${process.trigger.event}.`);
        }
      } else {
        error('I1', `${base}.trigger.event`, `Unknown transition ${process.trigger.event}.`);
      }
    }
    process.tasks.forEach((task, taskIndex) => {
      const path = `${base}.tasks[${taskIndex}]`;
      if (task.actorRef && !actorIds.has(task.actorRef)) {
        error('I1', `${path}.actorRef`, `Unknown actor ${task.actorRef}.`);
      }
      if (task.journeyRef && !journeyIds.has(task.journeyRef)) {
        error('I1', `${path}.journeyRef`, `Unknown journey ${task.journeyRef}.`);
      }
      if (task.entityRef && !entityIds.has(task.entityRef)) {
        error('I1', `${path}.entityRef`, `Unknown entity ${task.entityRef}.`);
      }
      if (task.transitionRef && task.entityRef) {
        const ids = new Set((entityById.get(task.entityRef)?.transitions || []).map(item => item.transitionId));
        if (!ids.has(task.transitionRef)) {
          error('I1', `${path}.transitionRef`, `Unknown transition ${task.transitionRef}.`);
        }
      }
    });
  });
  (sources.workflows.journeyDecisions || []).forEach((decision, index) => {
    const path = `workflows.journeyDecisions[${index}]`;
    if (decision.journeyId && !journeyIds.has(decision.journeyId)) {
      error('I1', `${path}.journeyId`, `Unknown journey ${decision.journeyId}.`);
    }
    if (decision.processId) {
      const ids = new Set(sources.workflows.processes.map(process => process.processId));
      if (!ids.has(decision.processId)) {
        error('I1', `${path}.processId`, `Unknown process ${decision.processId}.`);
      }
    }
  });

  sources.access.grants.forEach((grant, index) => {
    const path = `access.grants[${index}]`;
    if (grant.actorRef && !actorIds.has(grant.actorRef)) {
      error('I1', `${path}.actorRef`, `Unknown actor ${grant.actorRef}.`);
    }
    for (const entityId of grant.entityRefs) {
      if (entityId && !entityIds.has(entityId)) error('I1', `${path}.entityRefs`, `Unknown entity ${entityId}.`);
    }
    if (grant.dataScope.anchorEntity && !entityIds.has(grant.dataScope.anchorEntity)) {
      error('I1', `${path}.anchorEntity`, `Unknown entity ${grant.dataScope.anchorEntity}.`);
    }
    for (const ref of [...(grant.disclosure.allowedFields || []), ...(grant.disclosure.deniedFields || [])]) {
      if (!fieldExists(ref, entityById)) error('I1', `${path}.disclosure`, `Unknown field ${ref}.`);
    }
  });

  const integrationItems = [
    ...sources.integration.inbound.map((item, index) => ({ path: `integration.inbound[${index}]`, item })),
    ...sources.integration.outbound.map((item, index) => ({ path: `integration.outbound[${index}]`, item })),
  ];
  for (const { path, item } of integrationItems) {
    for (const entityId of item.entityRefs) {
      if (entityId && !entityIds.has(entityId)) error('I1', `${path}.entityRefs`, `Unknown entity ${entityId}.`);
    }
  }
}

function checkI2(sources: Ns5OracleSources, error: IssueFn, warning: IssueFn): void {
  const entityById = entityMap(sources);
  const reachableByEntity = new Map<string, Set<string> | null>();
  for (const entity of sources.entities) {
    if (!entityHasLifecycle(entity)) continue;
    reachableByEntity.set(entity.entityId, reachableFromBirths(entity));
  }
  for (const journey of sources.journeys) {
    const actor = journey.business.actorRef;
    journey.business.steps.forEach((step, index) => {
      const path = `journeys.${journey.journeyId}.steps[${index}]`;
      if (step.kind === 'decide') {
        const signal = collectNs5LifecycleSignal(sources.journeys, step.entity);
        const entity = entityById.get(step.entity);
        if (signal.requiresBranching && (!entity || !ns5LifecycleHasBranchingOrigin(entity))) {
          error(
            'I2',
            path,
            `decide ${step.stepId} on ${step.entity} needs at least two transitions from the same origin state.`,
          );
        }
        return;
      }
      if (step.kind !== 'act' || !step.entity) return;
      const entity = entityById.get(step.entity);
      if (step.effect === 'transition') {
        if (!step.transitionRef) return;
        const transition = (entity?.transitions || []).find(item => item.transitionId === step.transitionRef);
        if (!transition) return;
        if (!actorMatches(transition.by, actor)) {
          error(
            'I2',
            path,
            `act ${step.stepId} transitionRef ${step.transitionRef} on ${step.entity} does not include ${actor || '(missing actor)'} in by.`,
            NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION,
          );
          return;
        }
        const reachable = reachableByEntity.get(step.entity) ?? null;
        if (!fromIntersects(transition.from, reachable)) {
          error(
            'I2',
            path,
            `act ${step.stepId} transitionRef ${step.transitionRef} on ${step.entity} has from states unreachable from source-SCC births.`,
            NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION,
          );
        }
        return;
      }
      if (step.effect === 'create') return;
      if (!entityHasLifecycle(entity)) return;
      if (!(entity?.transitions || []).some(item => actorMatches(item.by, actor))) return;
      warning(
        'I2',
        path,
        `act ${step.stepId} on ${step.entity} has no transitionRef; ${actor || '(missing actor)'} has declared transitions (possible missing transitionRef).`,
        NS5_FINALIZE_I2_POSSIBLE_MISSING_TRANSITION_REF,
      );
    });
  }
  sources.workflows.processes.forEach((process, processIndex) => {
    process.tasks.forEach((task, taskIndex) => {
      if (task.kind !== 'mechanical' && task.kind !== 'llm') return;
      if (task.effect !== 'transition') return;
      if (!task.transitionRef || !task.entityRef) return;
      const path = `workflows.processes[${processIndex}].tasks[${taskIndex}]`;
      const entity = entityById.get(task.entityRef);
      const transition = (entity?.transitions || []).find(item => item.transitionId === task.transitionRef);
      if (!transition) return;
      if (!taskTransitionByAllows(transition.by, task.actorRef)) {
        error(
          'I2',
          path,
          `task ${task.taskId} transitionRef ${task.transitionRef} on ${task.entityRef} does not include ${task.actorRef || 'system'} in by.`,
          NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION,
        );
        return;
      }
      const reachable = reachableByEntity.get(task.entityRef) ?? null;
      if (!fromIntersects(transition.from, reachable)) {
        error(
          'I2',
          path,
          `task ${task.taskId} transitionRef ${task.transitionRef} on ${task.entityRef} has from states unreachable from source-SCC births.`,
          NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION,
        );
      }
    });
  });
}

function checkI3(sources: Ns5OracleSources, error: IssueFn): void {
  const journeyActors = new Set(sources.journeys.map(journey => journey.business.actorRef).filter(Boolean));
  const grantsByActor = new Set(sources.access.grants.map(grant => grant.actorRef).filter(Boolean));
  for (const actor of sources.access.actors) {
    if (!actor.actorId) continue;
    if (!journeyActors.has(actor.actorId)) {
      error('I3', `access.actors.${actor.actorId}`, `Actor ${actor.actorId} has no journey.`);
    }
    if (!grantsByActor.has(actor.actorId)) {
      error('I3', `access.actors.${actor.actorId}`, `Actor ${actor.actorId} has no grant.`);
    }
  }
}

function checkI4(sources: Ns5OracleSources, error: IssueFn): void {
  const ruleIds = new Set(sources.rules.rules.map(rule => rule.ruleId).filter(Boolean));
  for (const entity of sources.entities) {
    entity.transitions.forEach((transition, index) => {
      (transition.ruleRefs || []).forEach((ruleRef, refIndex) => {
        if (!ruleRef) return;
        if (ruleIds.has(ruleRef)) return;
        error(
          'I4',
          `ontology.${entity.entityId}.transitions[${index}].ruleRefs[${refIndex}]`,
          `Unknown rule ${ruleRef}.`,
        );
      });
    });
  }
}

function checkI5(sources: Ns5OracleSources, error: IssueFn): void {
  const entityById = entityMap(sources);
  const relationships = sources.ontologyIndex.relationships.map(item => ({
    relationshipId: item.relationshipId,
    fromEntity: item.fromEntity,
    toEntity: item.toEntity,
    required: item.required,
  }));
  const personIds = sources.entities.filter(entity => entity.party === 'person').map(entity => entity.entityId);

  for (const entity of sources.entities) {
    if (entity.kind !== 'mdm') continue;
    if (!entity.mdmSubtype) {
      error('I5', `ontology.${entity.entityId}.mdmSubtype`, `mdm entity ${entity.entityId} is missing mdmSubtype.`);
    }
  }

  sources.access.grants.forEach((grant, index) => {
    if (grant.dataScope.mode !== 'own') return;
    const anchor = grant.dataScope.anchorEntity || personIds[0] || '';
    for (const entityId of grant.entityRefs) {
      const entity = entityById.get(entityId);
      if (!entity || entity.kind === 'mdm') continue;
      const target = anchor && entityById.get(anchor)?.party === 'person'
        ? anchor
        : personIds.find(personId => anchorPath(entityId, personId, relationships) !== null) || '';
      if (!target || anchorPath(entityId, target, relationships) === null) {
        error(
          'I5',
          `access.grants[${index}].entityRefs`,
          `own grant ${grant.grantId} entity ${entityId} does not reach a party:person.`,
        );
      }
    }
  });
}

function checkI6(sources: Ns5OracleSources, warning: IssueFn): void {
  const journeyViews = sources.journeys.map(journey => ({
    journeyId: journey.journeyId,
    business: {
      actorRef: journey.business.actorRef,
      steps: journey.business.steps,
    },
  }));
  const entityViews = sources.entities.map(entity => ({
    entityId: entity.entityId,
    transitions: entity.transitions.map(transition => ({ transitionId: transition.transitionId, by: transition.by })),
  }));
  const coveredJourneys = new Set<string>();
  const ownedTransitions = new Set<string>();
  for (const process of sources.workflows.processes) {
    if (process.trigger.kind === 'event' && process.trigger.event) {
      const parsed = parseNs5TriggerEvent(process.trigger.event);
      if (parsed) ownedTransitions.add(`${parsed.entityId}.${parsed.transitionId}`);
    }
    for (const task of process.tasks) {
      if (task.kind === 'human' && task.journeyRef) coveredJourneys.add(task.journeyRef);
      if (
        (task.kind === 'mechanical' || task.kind === 'llm')
        && task.effect === 'transition'
        && task.entityRef
        && task.transitionRef
      ) {
        ownedTransitions.add(`${task.entityRef}.${task.transitionRef}`);
      }
    }
  }
  for (const handoff of collectNs5Handoffs(journeyViews)) {
    if (coveredJourneys.has(handoff.journeyId)) continue;
    warning(
      'I6',
      `journeys.${handoff.journeyId}.${handoff.stepId}`,
      `handoff ${handoff.stepId} has no covering process in workflows.`,
    );
  }
  const signals = collectNs5ProcessSignals(journeyViews, entityViews);
  const needsProcess = signals.filter(signal => signal.kind === 'foreignBy' || signal.kind === 'crossActorDecide');
  if (needsProcess.length && sources.workflows.processes.length === 0) {
    warning(
      'I6',
      'workflows.processes',
      'A foreign-by transition or cross-actor decide has no process in workflows.',
    );
  }
  for (const entity of sources.entities) {
    for (const transition of entity.transitions) {
      if (transition.by !== 'system' && transition.by !== 'time') continue;
      const key = `${entity.entityId}.${transition.transitionId}`;
      if (ownedTransitions.has(key)) continue;
      warning(
        'I6',
        `ontology.${entity.entityId}.${transition.transitionId}`,
        `system/time transition ${key} is not an effect:transition stage or trigger.event.`,
        NS5_FINALIZE_I6_SYSTEM_TRANSITION_UNOWNED,
      );
    }
  }
}

function checkI7(sources: Ns5OracleSources, error: IssueFn): void {
  reportOrphans('journeys', sources.journeyDiskFiles, sources.journeyIndex.journeys.map(entry => entry.journeyId), error);
  reportOrphans('ontology', sources.ontologyDiskFiles, sources.ontologyIndex.entities, error);
}

/**
 * A party:person that anchors an own/related grant is someone who will sign in.
 * She is registered when any of: (a) an internal actor writes her (`act` entity
 * or `affects` — same writer predicate as I10, restricted to internal-actor
 * journeys); (b) `writer: 'crud'` covered by an internal-actor grant (same
 * predicate as `NS5_ACCESS_CRUD_WITHOUT_INTERNAL_GRANT` / I10); (c) an `act` of
 * her own external actor writes her (self-registration); (d) derived `parent`
 * or `attach` — attach by an internal actor is cadastro, by an external actor
 * is self-registration. Journey `entry.mode` has no public value.
 */
function checkI8(sources: Ns5OracleSources, error: IssueFn): void {
  const entityById = entityMap(sources);
  const actorById = new Map(sources.access.actors.map(actor => [actor.actorId, actor]));
  const writerPlan = {
    entities: sources.entities,
    relationships: sources.ontologyIndex.relationships,
  };
  const internalJourneys = sources.journeys.filter(journey =>
    actorById.get(journey.business.actorRef)?.kind === 'internal');
  sources.access.grants.forEach((grant, index) => {
    const mode = grant.dataScope.mode;
    if (mode !== 'own' && mode !== 'related') return;
    const personId = grant.dataScope.anchorEntity || '';
    if (!personId) return;
    const entity = entityById.get(personId);
    if (!entity || entity.party !== 'person') return;
    if (ns5EntityHasActOrAffects(internalJourneys, personId)) return;
    const crudByInternal = ns5EntityWriter(entity) === 'crud' && sources.access.grants.some(item => {
      if (!item.entityRefs.includes(personId)) return false;
      return actorById.get(item.actorRef)?.kind === 'internal';
    });
    if (crudByInternal) return;
    const grantActor = actorById.get(grant.actorRef);
    if (grantActor?.kind === 'external') {
      const ownJourneys = sources.journeys.filter(journey => journey.business.actorRef === grant.actorRef);
      if (ns5EntityHasActOrAffects(ownJourneys, personId)) return;
    }
    const resolved = ns5ResolveEntityWriter(entity, writerPlan, sources.journeys);
    if (resolved.kind === 'parent' || resolved.kind === 'attach') return;
    error(
      'I8',
      `access.grants[${index}]`,
      `Person ${personId} is the ${mode} login anchor of grant ${grant.grantId} but is not registered: no internal actor writes that entity (act entity or affects), it is not writer: 'crud' with an internal-actor grant, and the grant's own external actor does not write it (self-registration).`,
      NS5_FINALIZE_I8_LOGIN_PERSON_WITHOUT_REGISTRATION,
    );
  });
}

function checkI9(sources: Ns5OracleSources, error: IssueFn): void {
  for (const entity of sources.entities) {
    const fieldIds = new Set(entity.fields.map(field => field.fieldId).filter(Boolean));
    (entity.uniqueKeys || []).forEach((key, keyIndex) => {
      key.forEach((fieldId, fieldIndex) => {
        if (!fieldId) return;
        if (fieldIds.has(fieldId)) return;
        error(
          'I9',
          `ontology.${entity.entityId}.uniqueKeys[${keyIndex}][${fieldIndex}]`,
          `Unknown field ${fieldId}.`,
        );
      });
    });
  }
}

/**
 * Same writer predicates as ontology30 / access60: a written entity is an `act`
 * entity or listed in an act's `affects`, or `writer: 'crud'` / `writer: 'inbound'`,
 * or derived `parent`/`attach`; a crud entity has an internal-actor grant; inbound
 * must appear in inbound.writes. Conflicting crud is dropped by ontology30
 * normalize, not by this check.
 */
function checkI10(sources: Ns5OracleSources, error: IssueFn): void {
  const actorById = new Map(sources.access.actors.map(actor => [actor.actorId, actor]));
  const inboundWrites = new Set(sources.integration.inbound.flatMap(item => item.writes || []));
  const writerPlan = {
    entities: sources.entities,
    relationships: sources.ontologyIndex.relationships,
  };
  for (const entity of sources.entities) {
    const path = `ontology.${entity.entityId}`;
    const resolved = ns5ResolveEntityWriter(entity, writerPlan, sources.journeys);
    const crud = resolved.kind === 'crud';
    const inbound = resolved.kind === 'inbound';
    if (resolved.kind === 'none' && ns5EntityHasWrittenFields(entity)) {
      error(
        'I10',
        `${path}.writer`,
        `Entity ${entity.entityId} has written fields but no writer: it must be the entity of an act step or listed in an act's affects, or declare writer: 'crud' (a reference catalog with no lifecycle), or writer: 'inbound' (created by an integration event).`,
      );
    }
    if (inbound && !inboundWrites.has(entity.entityId)) {
      error(
        'I10',
        `${path}.writer`,
        `Entity ${entity.entityId} declares writer inbound but no inbound.writes names it.`,
      );
    }
    if (!crud) continue;
    const covered = sources.access.grants.some(grant => {
      if (!grant.entityRefs.includes(entity.entityId)) return false;
      return actorById.get(grant.actorRef)?.kind === 'internal';
    });
    if (covered) continue;
    error(
      'I10',
      `${path}.writer`,
      `CRUD entity ${entity.entityId} has no grant from an internal actor.`,
    );
  }
}

function checkI11(sources: Ns5OracleSources, warning: IssueFn): void {
  const pending = collectNs5InboundPending(
    sources.integration.inbound,
    sources.module.moduleName,
    sources.siblings || [],
  );
  pending.forEach((request, index) => {
    warning(
      'I11',
      `integration.inbound pending[${index}]`,
      `inbound ${request.eventId} from ${request.to || request.targetModule} is not published by that sibling; queued at l4/${request.targetModule}/tobe/integration/.`,
      NS5_FINALIZE_I11_INBOUND_PENDING_IN_SIBLING,
    );
  });
}

function checkI12(sources: Ns5OracleSources, error: IssueFn): void {
  const entityById = entityMap(sources);
  const journeySteps = new Map<string, Set<string>>();
  for (const journey of sources.journeys) {
    journeySteps.set(journey.journeyId, new Set(journey.business.steps.map(step => step.stepId)));
  }
  const processTasks = new Map<string, Set<string>>();
  for (const process of sources.workflows.processes) {
    processTasks.set(process.processId, new Set(process.tasks.map(task => task.taskId)));
  }
  const platformEventIds = new Set(sources.platformEventIds || []);
  sources.integration.outbound.forEach((item, index) => {
    const path = `integration.outbound[${index}]`;
    const parsed = parseNs5OutboundOn(item.on || '');
    if (!parsed) {
      error('I12', `${path}.on`, 'outbound.on must be Entity.transitionId or Entity.create.');
      return;
    }
    const entity = entityById.get(parsed.entityId);
    if (!entity) {
      error('I12', `${path}.on`, `Unknown entity ${parsed.entityId}.`);
      return;
    }
    if (parsed.transitionId === 'create') return;
    if (!entity.transitions.some(row => row.transitionId === parsed.transitionId)) {
      error('I12', `${path}.on`, `Unknown transition ${parsed.entityId}.${parsed.transitionId}.`);
    }
  });
  sources.integration.inbound.forEach((item, index) => {
    if (item.from !== 'organization') return;
    const eventId = item.event || item.id;
    if (platformEventIds.size && !platformEventIds.has(eventId)) {
      error('I12', `integration.inbound[${index}].event`, `event ${eventId} is not in the platform catalog.`);
    }
  });
  sources.integration.plugins.forEach((plugin, pluginIndex) => {
    plugin.usedBy.forEach((ref, refIndex) => {
      const path = `integration.plugins[${pluginIndex}].usedBy[${refIndex}]`;
      const parsed = parseNs5UsedBy(ref);
      if (!parsed) {
        error('I12', path, 'usedBy must be journeyId.stepId or processId.taskId.');
        return;
      }
      const steps = journeySteps.get(parsed.ownerId);
      if (steps) {
        if (!steps.has(parsed.memberId)) error('I12', path, `Unknown step ${ref}.`);
        return;
      }
      const tasks = processTasks.get(parsed.ownerId);
      if (tasks) {
        if (!tasks.has(parsed.memberId)) error('I12', path, `Unknown task ${ref}.`);
        return;
      }
      error('I12', path, `Unknown journey or process ${parsed.ownerId}.`);
    });
  });
}

function checkI13(sources: Ns5OracleSources, warning: IssueFn): void {
  sources.access.grants.forEach((grant, index) => {
    if (grant.dataScope.mode !== 'custom') return;
    warning(
      'I13',
      `access.grants[${index}]`,
      `custom grant ${grant.grantId || index} for actor ${grant.actorRef || '(missing)'}; the backend does not apply custom.`,
    );
  });
}

function reportOrphans(kind: 'journeys' | 'ontology', diskFiles: string[] | undefined, indexIds: string[], error: IssueFn): void {
  if (!diskFiles) return;
  const keep = new Set<string>(['index', ...indexIds.filter(Boolean)]);
  const extras: string[] = [];
  const seen = new Set<string>();
  for (const raw of diskFiles) {
    const name = String(raw || '').replace(/\.defs\.ts$/, '');
    if (!name || keep.has(name) || seen.has(name)) continue;
    seen.add(name);
    extras.push(name);
  }
  extras.sort();
  if (!extras.length) return;
  error('I7', `${kind}/`, `orphan files: ${extras.join(', ')}`);
}

type IssueFn = (checkId: Ns5OracleCheckId, path: string, message: string, code?: Ns5OracleIssue['code']) => void;

function entityHasLifecycle(entity: Ns5OntologyEntityArtifact | undefined): boolean {
  return Boolean(entity && (entity.lifecycleStates.length || entity.transitions.length));
}

function reachableFromBirths(entity: Ns5OntologyEntityArtifact): Set<string> | null {
  const time = new Set(entity.lifecycleStates.filter(entry => entry.reachedBy === 'time').map(entry => entry.state));
  const roots = ns5SourceSccStates(entity.transitions).filter(state => !time.has(state));
  if (roots.length) return ns5ReachableStates(roots, entity.transitions);
  const fallback = entity.lifecycleStates
    .filter(entry => entry.reachedBy !== 'time')
    .map(entry => entry.state)
    .filter(Boolean);
  return fallback.length ? new Set(fallback) : null;
}

function actorMatches(by: Ns5OntologyEntityArtifact['transitions'][number]['by'], actor: string): boolean {
  return Boolean(actor && Array.isArray(by) && by.includes(actor));
}

function taskTransitionByAllows(
  by: Ns5OntologyEntityArtifact['transitions'][number]['by'],
  actorRef?: string,
): boolean {
  if (by === 'system' || by === 'time') return true;
  return Boolean(actorRef && Array.isArray(by) && by.includes(actorRef));
}

function fromIntersects(from: readonly string[], reachable: Set<string> | null): boolean {
  if (!from.length) return false;
  if (reachable === null) return true;
  return from.some(state => reachable.has(state));
}



function entityMap(sources: Ns5OracleSources): Map<string, Ns5OntologyEntityArtifact> {
  return new Map(sources.entities.map(entity => [entity.entityId, entity]));
}

/**
 * A journey `entity`/`affects` naming an id ontology30 lifted into `module.details`
 * is a legitimate read of those aggregates — not an unknown entity. Both locks:
 * the id is in `liftedAggregateEntities` (pipeline.json) and `module.details` still
 * has keys (the absorbed aggregates). An unknown id that was never lifted stays I1.
 */
function isLiftedModuleDetailRef(id: string, sources: Ns5OracleSources): boolean {
  if (!id) return false;
  if (!(sources.liftedAggregateEntities || []).includes(id)) return false;
  const details = sources.module.details;
  return !!details && Object.keys(details).length > 0;
}

function fieldExists(ref: string, entityById: Map<string, Ns5OntologyEntityArtifact>): boolean {
  const parsed = splitFieldRef(ref);
  if (!parsed) return false;
  const entity = entityById.get(parsed.entityId);
  if (!entity) return false;
  return ns5FieldRefExists(ref, asRulesEntity(entity));
}

function asRulesEntity(entity: Ns5OntologyEntityArtifact): Ns5RulesEntityView {
  return {
    entityId: entity.entityId,
    fields: entity.fields,
    details: entity.details
      ? Object.fromEntries(Object.entries(entity.details).map(([name, detail]) => [name, detail.description]))
      : undefined,
    storage: entity.storage,
    transitions: entity.transitions.map(transition => ({ transitionId: transition.transitionId, by: transition.by })),
  };
}
