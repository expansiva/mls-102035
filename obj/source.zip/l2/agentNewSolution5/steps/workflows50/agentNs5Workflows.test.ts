/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/workflows50/agentNs5Workflows.test.ts" enhancement="_blank"/>

import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

import { lintToolSchema } from '/_102025_/l2/toolSchemaLint.js';
import { createNs4FlexibleWorkerTool } from '/_102035_/l2/solution/helpers/ns4WorkerTools.js';
import { ownerStepId } from '/_102035_/l2/agentNewSolution5/helpers/ns5Core.js';
import {
  loadNs5Actors,
  loadNs5Entities,
  loadNs5FixtureJson,
  loadNs5Journeys,
  loadNs5Workflows,
} from '/_102035_/l2/solution/testing/ns5RealFixtures.test.js';
import type {
  Ns5JourneyArtifact,
  Ns5OntologyEntityArtifact,
  Ns5WorkflowProcess,
} from '/_102035_/l2/solution/types.js';
import { buildNs5WorkflowsHumanPrompt, buildNs5WorkflowsTool } from '/_102035_/l2/agentNewSolution5/steps/workflows50/agentNs5Workflows.js';
import {
  buildNs5WorkflowsArtifact,
  buildNs5WorkflowsArtifactV3,
  collectNs5ProcessSignals,
  collectNs5TimeEventPhrases,
  collectNs5WorkflowsRefCatalog,
  normalizeNs5WorkflowsPayload,
  NS5_WORKFLOW_DROP_UNKNOWN_ICON,
  ns5WorkflowsNeedsLlm,
  type Ns5WorkflowsEntityView,
  type Ns5WorkflowsJourneyView,
} from '/_102035_/l2/solution/gates/workflows50/contracts.js';
import {
  formatNs5WorkflowsGate,
  validateNs5Workflows,
} from '/_102035_/l2/solution/gates/workflows50/gate.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));

function loadSchema(): Record<string, unknown> {
  return JSON.parse(
    readFileSync(path.join(HERE, '../../schemas/workflows.schema.json'), 'utf8'),
  ) as Record<string, unknown>;
}

function journey(
  journeyId: string,
  actorRef: string,
  steps: Ns5WorkflowsJourneyView['business']['steps'],
): Ns5WorkflowsJourneyView {
  return { journeyId, business: { actorRef, steps } };
}

function entity(
  entityId: string,
  transitions: Ns5WorkflowsEntityView['transitions'] = [],
): Ns5WorkflowsEntityView {
  return { entityId, transitions };
}

const ORDEN_ACTORS = ['recepcionista', 'tecnico', 'cliente'];

const ORDEN_JOURNEYS: Ns5WorkflowsJourneyView[] = [
  journey('abrirOrdenServicio', 'recepcionista', [
    { stepId: 'createServiceOrder', kind: 'act', entity: 'ServiceOrder', effect: 'create' },
    { stepId: 'handToTechnician', kind: 'handoff', entity: 'ServiceOrder', handoffTo: 'tecnico' },
  ]),
  journey('prepararPresupuestoServicio', 'tecnico', [
    { stepId: 'publishBudget', kind: 'act', entity: 'ServiceOrder', effect: 'transition', transitionRef: 'publishBudget' },
    { stepId: 'handToCustomer', kind: 'handoff', entity: 'ServiceOrder', handoffTo: 'cliente' },
  ]),
  journey('consultarYDecidirPresupuesto', 'cliente', [
    { stepId: 'decideBudget', kind: 'decide', entity: 'ServiceOrder' },
  ]),
  journey('repararAparato', 'tecnico', [
    { stepId: 'markServiceOrderReady', kind: 'act', entity: 'ServiceOrder', effect: 'transition', transitionRef: 'markServiceOrderReady' },
    { stepId: 'handToReception', kind: 'handoff', entity: 'ServiceOrder', handoffTo: 'recepcionista' },
  ]),
  journey('entregarAparato', 'recepcionista', [
    { stepId: 'recordDelivery', kind: 'act', entity: 'ServiceOrder', effect: 'transition', transitionRef: 'completeServiceOrder' },
  ]),
];

const ORDEN_ENTITIES: Ns5WorkflowsEntityView[] = [
  entity('ServiceOrder', [
    { transitionId: 'publishBudget', by: ['tecnico'] },
    { transitionId: 'approveBudget', by: ['cliente'] },
    { transitionId: 'rejectBudget', by: ['cliente'] },
    { transitionId: 'markServiceOrderReady', by: ['tecnico'] },
    { transitionId: 'completeServiceOrder', by: ['recepcionista'] },
  ]),
];

const COMANDA_JOURNEYS: Ns5WorkflowsJourneyView[] = [
  journey('abrirComandaParaMesa', 'garcom', [
    { stepId: 'open', kind: 'act', entity: 'Comanda', effect: 'create' },
  ]),
  journey('lancarItemNaComanda', 'garcom', [
    { stepId: 'addItem', kind: 'act', entity: 'ItemComanda', effect: 'create', affects: ['Comanda'] },
  ]),
  journey('cancelarItemLancado', 'garcom', [
    { stepId: 'cancelItem', kind: 'act', entity: 'ItemComanda', effect: 'transition', transitionRef: 'cancelarItem' },
  ]),
  journey('fecharComanda', 'caixa', [
    { stepId: 'close', kind: 'act', entity: 'Comanda', effect: 'transition', transitionRef: 'fecharComanda' },
  ]),
];

const COMANDA_ENTITIES: Ns5WorkflowsEntityView[] = [
  entity('Comanda', [{ transitionId: 'fecharComanda', by: ['caixa'] }]),
  entity('ItemComanda', [{ transitionId: 'cancelarItem', by: ['garcom'] }]),
];

const COMANDA_ACTORS = ['garcom', 'caixa'];

const MANUAL_TRIGGER = { kind: 'manual' as const, actorRef: 'recepcionista' };

function humanTask(taskId: string, actorRef: string, journeyRef: string, next: string[], description: string) {
  return { taskId, kind: 'human' as const, actorRef, journeyRef, next, description };
}

function validProcess(overrides: Partial<Ns5WorkflowProcess> = {}): Record<string, unknown> {
  return {
    processId: 'serviceOrderFulfillment',
    title: 'Service order fulfillment',
    description: 'Reception, analysis, customer decision, repair, delivery.',
    trigger: MANUAL_TRIGGER,
    tasks: [
      humanTask('receive', 'recepcionista', 'abrirOrdenServicio', ['analyze'], 'Reception opens the order.'),
      humanTask('analyze', 'tecnico', 'prepararPresupuestoServicio', ['decide'], 'Technician publishes the budget.'),
      humanTask('decide', 'cliente', 'consultarYDecidirPresupuesto', ['repair'], 'Customer approves or rejects the budget.'),
      humanTask('repair', 'tecnico', 'repararAparato', ['deliver'], 'Technician marks the order ready.'),
      humanTask('deliver', 'recepcionista', 'entregarAparato', [], 'Reception delivers the device.'),
    ],
    ...overrides,
  };
}

function drafts(payload: unknown, journeyIds?: readonly string[]) {
  return normalizeNs5WorkflowsPayload(payload, journeyIds ? { journeyIds } : undefined);
}

function gateOf(
  processes: Ns5WorkflowProcess[],
  journeys = ORDEN_JOURNEYS,
  entities = ORDEN_ENTITIES,
  actorIds = ORDEN_ACTORS,
  journeyDecisions?: ReturnType<typeof drafts>['journeyDecisions'],
) {
  return validateNs5Workflows(processes, { actorIds, journeys, entities, journeyDecisions });
}

void test('workflows50 tool schema is provider-clean', () => {
  const tool = buildNs5WorkflowsTool(loadSchema(), createNs4FlexibleWorkerTool);
  assert.equal(tool.function.name, 'submitNs5Workflows');
  assert.equal(lintToolSchema(JSON.stringify(tool.function.parameters)), null);
});

void test('real ordenServicio5 workflows draft is one process of human stages per journey, no locate/inspect', () => {
  const draft = loadNs5FixtureJson<{ processes: Ns5WorkflowProcess[] }>('fixtures/workflows50', 'ordenServicio5-draft.json');
  assert.equal(draft.processes.length, 1);
  const process = draft.processes[0];
  assert.equal(process.processId, 'gestionarOrdenServicio');
  assert.equal(process.trigger.kind, 'manual');
  assert.ok(process.tasks.length <= 6);
  assert.equal(process.tasks.every(task => task.kind === 'human'), true);
  assert.equal(process.tasks.every(task => Boolean(task.journeyRef) && !('stepRef' in task)), true);
  const keys = process.tasks.map(task => `${task.kind}|${task.journeyRef}`);
  assert.equal(new Set(keys).size, keys.length);
  const journeys = loadNs5Journeys('ordenServicio5').map(item => ({
    journeyId: item.journeyId,
    business: {
      actorRef: item.business.actorRef,
      steps: item.business.steps.map(step => ({
        stepId: step.stepId,
        kind: step.kind,
        entity: step.entity,
        ...(step.handoffTo ? { handoffTo: step.handoffTo } : {}),
      })),
    },
  }));
  const entities = loadNs5Entities('ordenServicio5').map(item => ({
    entityId: item.entityId,
    transitions: item.transitions.map(transition => ({ transitionId: transition.transitionId, by: transition.by })),
  }));
  const normalized = drafts(draft, journeys.map(item => item.journeyId));
  const gate = validateNs5Workflows(normalized.processes, {
    actorIds: loadNs5Actors('ordenServicio5').map(actor => actor.actorId),
    journeys,
    entities,
    journeyDecisions: normalized.journeyDecisions,
  });
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
});

void test('real comandaRestaurante5 workflows draft is empty and has no process signal', () => {
  const draft = loadNs5FixtureJson<{ processes: Ns5WorkflowProcess[] }>('fixtures/workflows50', 'comandaRestaurante5-draft.json');
  assert.deepEqual(draft.processes, []);
});

void test('comanda-like journeys have no process signal (skip LLM)', () => {
  const signals = collectNs5ProcessSignals(COMANDA_JOURNEYS, COMANDA_ENTITIES);
  assert.deepEqual(signals, []);
  assert.equal(ns5WorkflowsNeedsLlm(signals, []), false);
  const gate = validateNs5Workflows([], {
    actorIds: COMANDA_ACTORS,
    journeys: COMANDA_JOURNEYS,
    entities: COMANDA_ENTITIES,
  });
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
});

void test('handoff is a process signal', () => {
  const signals = collectNs5ProcessSignals(ORDEN_JOURNEYS, [entity('ServiceOrder')]);
  assert.ok(signals.some(signal => signal.kind === 'handoff'));
});

void test('multi-actor transitions on one entity are a foreignBy signal', () => {
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: {
      ...item.business,
      steps: item.business.steps.filter(step => step.kind !== 'handoff' && step.kind !== 'decide'),
    },
  }));
  const signals = collectNs5ProcessSignals(noHandoff, ORDEN_ENTITIES);
  assert.ok(signals.some(signal => signal.kind === 'foreignBy' && signal.entityId === 'ServiceOrder'));
});

void test('cross-actor decide is a process signal when transitions are empty', () => {
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: {
      ...item.business,
      steps: item.business.steps.filter(step => step.kind !== 'handoff'),
    },
  }));
  const signals = collectNs5ProcessSignals(noHandoff, [entity('ServiceOrder')]);
  assert.ok(signals.some(signal => signal.kind === 'crossActorDecide' && signal.stepId === 'decideBudget'));
});

void test('system and time transitions are process signals and do not force an empty-process error', () => {
  const signals = collectNs5ProcessSignals(
    [journey('watchWaitlist', 'organizador', [{ stepId: 'watch', kind: 'inspect', entity: 'Inscricao' }])],
    [entity('Inscricao', [{ transitionId: 'promoteFromWaitlist', by: 'system' }])],
  );
  assert.ok(signals.some(signal => signal.kind === 'systemBy' && signal.transitionId === 'promoteFromWaitlist'));
  const gate = validateNs5Workflows([], {
    actorIds: ['organizador'],
    journeys: [journey('watchWaitlist', 'organizador', [{ stepId: 'watch', kind: 'inspect', entity: 'Inscricao' }])],
    entities: [entity('Inscricao', [{ transitionId: 'promoteFromWaitlist', by: 'system' }])],
  });
  assert.equal(gate.ok, true);
  assert.equal(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_SIGNAL_WITHOUT_PROCESS'), false);
});

void test('time/event phrases are extracted in code and force the LLM call', () => {
  const phrases = collectNs5TimeEventPhrases(
    'Todo mês, dia 1, gerar as mensalidades. Quando o plano vence, avisar. Fechar automaticamente.',
  );
  assert.ok(phrases.some(phrase => /todo m/i.test(phrase)));
  assert.ok(phrases.some(phrase => /quando o plano vence/i.test(phrase)));
  assert.ok(phrases.some(phrase => /automaticamente/i.test(phrase)));
  assert.equal(ns5WorkflowsNeedsLlm([], phrases), true);
  assert.equal(ns5WorkflowsNeedsLlm([], []), false);
});

void test('normalize + gate accept a valid chained process covering handoffs by journeyRef', () => {
  const normalized = drafts({ processes: [validProcess()] });
  const gate = gateOf(normalized.processes);
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
});

void test('normalize keeps the process functions and omits the key when the model sent none', () => {
  const functions = [{ functionId: 'openOrder', description: 'Reception opens the order; a repeated call returns the same order.' }];
  const withFunctions = drafts({ processes: [validProcess({ functions })] });
  assert.deepEqual(withFunctions.processes[0].functions, functions);
  const without = drafts({ processes: [validProcess()] });
  assert.equal('functions' in without.processes[0], false);
});

void test('empty catalog is invalid when a handoff exists', () => {
  const gate = gateOf([]);
  assert.equal(gate.ok, false);
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_SIGNAL_WITHOUT_PROCESS'));
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_HANDOFF_UNCOVERED'));
});

void test('gate rejects a human task without actorRef or journeyRef', () => {
  const processes = drafts({
    processes: [validProcess({
      tasks: [{
        taskId: 'decide',
        kind: 'human',
        next: [],
        description: 'Customer decides.',
      }],
    })],
  }).processes;
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: { ...item.business, steps: item.business.steps.filter(step => step.kind !== 'handoff') },
  }));
  const gate = gateOf(processes, noHandoff, ORDEN_ENTITIES);
  assert.equal(gate.ok, false);
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_HUMAN_ACTOR'));
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_HUMAN_JOURNEY'));
});

void test('gate rejects unknown actor, journey, entity and next refs', () => {
  const processes = drafts({
    processes: [validProcess({
      tasks: [{
        taskId: 'ghost',
        kind: 'human',
        actorRef: 'ghost',
        journeyRef: 'ghostJourney',
        next: ['missing'],
        description: 'Broken refs.',
      }],
    })],
  }).processes;
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: { ...item.business, steps: item.business.steps.filter(step => step.kind !== 'handoff') },
  }));
  const gate = gateOf(processes, noHandoff, ORDEN_ENTITIES);
  assert.equal(gate.ok, false);
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_ACTOR_UNKNOWN'));
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_JOURNEY_UNKNOWN'));
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_NEXT_UNKNOWN'));
});

void test('gate rejects a cycle that does not go through wait', () => {
  const processes = drafts({
    processes: [validProcess({
      tasks: [
        humanTask('a', 'tecnico', 'prepararPresupuestoServicio', ['b'], 'A.'),
        humanTask('b', 'cliente', 'consultarYDecidirPresupuesto', ['a'], 'B.'),
      ],
    })],
  }).processes;
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: { ...item.business, steps: item.business.steps.filter(step => step.kind !== 'handoff') },
  }));
  const gate = gateOf(processes, noHandoff, ORDEN_ENTITIES);
  assert.equal(gate.ok, false);
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_CYCLE'));
  const feedback = formatNs5WorkflowsGate(gate.issues);
  assert.match(feedback, /NS5_WORKFLOWS_CYCLE/);
});

void test('a cycle through wait is allowed', () => {
  const processes = drafts({
    processes: [validProcess({
      tasks: [
        humanTask('a', 'tecnico', 'prepararPresupuestoServicio', ['pause'], 'A.'),
        { taskId: 'pause', kind: 'wait', next: ['b'], description: 'Wait for the customer.' },
        humanTask('b', 'cliente', 'consultarYDecidirPresupuesto', ['a'], 'B.'),
      ],
    })],
  }).processes;
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: { ...item.business, steps: item.business.steps.filter(step => step.kind !== 'handoff') },
  }));
  const gate = gateOf(processes, noHandoff, ORDEN_ENTITIES);
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
});

void test('uncovered handoff fails NS5_WORKFLOWS_HANDOFF_UNCOVERED', () => {
  const processes = drafts({
    processes: [validProcess({
      tasks: [humanTask('receive', 'recepcionista', 'abrirOrdenServicio', [], 'Reception opens the order.')],
    })],
  }).processes;
  const gate = gateOf(processes);
  assert.equal(gate.ok, false);
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_HANDOFF_UNCOVERED'));
});

void test('normalize maps id to processId/taskId, drops empty next, and drops duplicate stages', () => {
  const normalized = drafts({
    processes: [{
      id: 'serviceOrderFulfillment',
      title: 'Fulfillment',
      description: 'Chain.',
      trigger: MANUAL_TRIGGER,
      tasks: [
        {
          id: 'decide',
          kind: 'human',
          actorRef: 'cliente',
          journeyRef: 'consultarYDecidirPresupuesto',
          next: ['repair', 'repair', ''],
          description: 'Customer decides.',
        },
        {
          taskId: 'decideAgain',
          kind: 'human',
          actorRef: 'cliente',
          journeyRef: 'consultarYDecidirPresupuesto',
          next: ['repair'],
          description: 'Duplicate decide.',
        },
      ],
    }],
  });
  assert.equal(normalized.processes[0].processId, 'serviceOrderFulfillment');
  assert.equal(normalized.processes[0].tasks.length, 1);
  assert.equal(normalized.processes[0].tasks[0].taskId, 'decide');
  assert.equal(normalized.processes[0].tasks[0].journeyRef, 'consultarYDecidirPresupuesto');
  assert.equal('stepRef' in normalized.processes[0].tasks[0], false);
  assert.deepEqual(normalized.processes[0].tasks[0].next, ['repair']);
  assert.ok(normalized.systemDecisions.some(decision => decision.decisionId === 'dropDuplicateTaskDecideAgain'));
});

void test('mechanical create Mensalidade is the academia scheduled shape', () => {
  const journeys = [
    journey('gerarMensalidadesDoMes', 'financeiro', [
      { stepId: 'gerar', kind: 'act', entity: 'Mensalidade', effect: 'create' },
    ]),
  ];
  const entities = [entity('Mensalidade')];
  const normalized = drafts({
    processes: [{
      processId: 'gerarMensalidadesMensal',
      title: 'Gerar mensalidades do mês',
      description: 'Todo mês cria as mensalidades dos alunos ativos.',
      trigger: { kind: 'scheduled', schedule: 'todo mês, dia 1' },
      tasks: [{
        taskId: 'criarMensalidades',
        kind: 'mechanical',
        entityRef: 'Mensalidade',
        effect: 'create',
        next: [],
        description: 'Criar as mensalidades do mês.',
      }],
    }],
    journeyDecisions: [{ journeyId: 'gerarMensalidadesDoMes', inProcess: true, processId: 'gerarMensalidadesMensal' }],
  }, ['gerarMensalidadesDoMes']);
  const gate = validateNs5Workflows(normalized.processes, {
    actorIds: ['financeiro'],
    journeys,
    entities,
    journeyDecisions: normalized.journeyDecisions,
  });
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
  assert.equal(normalized.processes[0].trigger.kind, 'scheduled');
  assert.equal(normalized.processes[0].tasks[0].kind, 'mechanical');
  assert.equal(normalized.processes[0].tasks[0].effect, 'create');
  assert.equal(normalized.journeyDecisions[0].inProcess, true);
});

void test('frota preventiva is event plus a human journey stage', () => {
  const journeys = [
    journey('abrirOrdemPreventiva', 'gestorFrota', [
      { stepId: 'abrir', kind: 'act', entity: 'OrdemManutencao', effect: 'create' },
    ]),
  ];
  const entities = [entity('Preventiva', [{ transitionId: 'vencer', by: 'time' }])];
  const normalized = drafts({
    processes: [{
      processId: 'tratarPreventivaVencida',
      title: 'Tratar preventiva vencida',
      description: 'Quando a preventiva vence, o gestor abre a ordem.',
      trigger: { kind: 'event', event: 'Preventiva.vencer' },
      tasks: [humanTask('abrirOrdemPreventiva', 'gestorFrota', 'abrirOrdemPreventiva', [], 'Abrir a ordem preventiva.')],
    }],
    journeyDecisions: [{ journeyId: 'abrirOrdemPreventiva', inProcess: true, processId: 'tratarPreventivaVencida' }],
  }, ['abrirOrdemPreventiva']);
  const gate = validateNs5Workflows(normalized.processes, {
    actorIds: ['gestorFrota'],
    journeys,
    entities,
    journeyDecisions: normalized.journeyDecisions,
  });
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
  assert.equal(normalized.processes[0].trigger.kind, 'event');
  assert.equal(normalized.processes[0].tasks[0].kind, 'human');
});

void test('evento waitlist is event plus mechanical transition', () => {
  const journeys = [
    journey('cancelarInscricao', 'participante', [
      { stepId: 'cancelar', kind: 'act', entity: 'Inscricao', effect: 'transition', transitionRef: 'cancelar' },
    ]),
  ];
  const entities = [entity('Inscricao', [
    { transitionId: 'cancelar', by: ['participante'] },
    { transitionId: 'promoteFromWaitlist', by: 'system' },
  ])];
  const normalized = drafts({
    processes: [{
      processId: 'promoverListaDeEspera',
      title: 'Promover lista de espera',
      description: 'Quando uma inscrição cancela, o sistema promove a lista de espera.',
      trigger: { kind: 'event', event: 'Inscricao.cancelar' },
      tasks: [{
        taskId: 'promover',
        kind: 'mechanical',
        entityRef: 'Inscricao',
        effect: 'transition',
        transitionRef: 'promoteFromWaitlist',
        next: [],
        description: 'Promover o próximo da lista de espera.',
      }],
    }],
    journeyDecisions: [{ journeyId: 'cancelarInscricao', inProcess: true, processId: 'promoverListaDeEspera' }],
  }, ['cancelarInscricao']);
  const gate = validateNs5Workflows(normalized.processes, {
    actorIds: ['participante'],
    journeys,
    entities,
    journeyDecisions: normalized.journeyDecisions,
  });
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
});

void test('mechanical transitionRef must exist with by system or the actor', () => {
  const processes = drafts({
    processes: [validProcess({
      trigger: { kind: 'manual', actorRef: 'recepcionista' },
      tasks: [{
        taskId: 'autoClose',
        kind: 'mechanical',
        entityRef: 'ServiceOrder',
        effect: 'transition',
        transitionRef: 'approveBudget',
        next: [],
        description: 'Wrong by.',
      }],
    })],
  }).processes;
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: { ...item.business, steps: item.business.steps.filter(step => step.kind !== 'handoff') },
  }));
  const gate = gateOf(processes, noHandoff, ORDEN_ENTITIES);
  assert.equal(gate.ok, false);
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_TRANSITION_BY'));
});

void test('trigger.event accepts module.eventId inbound form', () => {
  const processes = drafts({
    processes: [validProcess({
      trigger: { kind: 'event', event: 'comandaRestaurante.comandaFechada' },
    })],
  }).processes;
  const gate = gateOf(processes);
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
});

void test('trigger.event still rejects a malformed event id', () => {
  const processes = drafts({
    processes: [validProcess({
      trigger: { kind: 'event', event: 'not-an-event' },
    })],
  }).processes;
  const gate = gateOf(processes);
  assert.equal(gate.ok, false);
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_TRIGGER_EVENT'));
});

/** ns5_48: the alert stage — a recurring duty of a person, no journey and no entity. */
function alertProcess(tasks: unknown[]): Record<string, unknown> {
  return {
    processId: 'gerarMensalidades',
    title: 'Monthly fees',
    description: 'Every month the management issues the fees.',
    trigger: { kind: 'scheduled', schedule: 'todo mes, dia 1' },
    tasks,
  };
}

const NO_HANDOFF_JOURNEYS = ORDEN_JOURNEYS.map(item => ({
  ...item,
  business: { ...item.business, steps: item.business.steps.filter(step => step.kind !== 'handoff') },
}));

void test('gate accepts an alert stage under a scheduled trigger', () => {
  const processes = drafts({
    processes: [alertProcess([{
      taskId: 'avisarGerencia',
      kind: 'alert',
      actorRef: 'recepcionista',
      next: [],
      description: 'Run abrirOrdenServicio for every active enrolment.',
    }])],
  }).processes;
  assert.equal(processes[0].tasks[0].kind, 'alert');
  const gate = gateOf(processes, NO_HANDOFF_JOURNEYS, ORDEN_ENTITIES);
  assert.equal(gate.ok, true, gate.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
});

void test('gate rejects an alert without actorRef and an alert with an unknown actor', () => {
  const missing = drafts({
    processes: [alertProcess([{ taskId: 'semAtor', kind: 'alert', next: [], description: 'No one owns it.' }])],
  }).processes;
  const missingGate = gateOf(missing, NO_HANDOFF_JOURNEYS, ORDEN_ENTITIES);
  assert.equal(missingGate.ok, false);
  assert.ok(missingGate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_ALERT_ACTOR'));

  const unknown = drafts({
    processes: [alertProcess([{ taskId: 'fantasma', kind: 'alert', actorRef: 'ghost', next: [], description: 'Unknown actor.' }])],
  }).processes;
  const unknownGate = gateOf(unknown, NO_HANDOFF_JOURNEYS, ORDEN_ENTITIES);
  assert.equal(unknownGate.ok, false);
  assert.ok(unknownGate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_ALERT_ACTOR'));
});

void test('gate rejects an alert that carries a journeyRef or an entityRef', () => {
  const processes = drafts({
    processes: [alertProcess([{
      taskId: 'comJornada',
      kind: 'alert',
      actorRef: 'recepcionista',
      journeyRef: 'abrirOrdenServicio',
      next: [],
      description: 'An alert is not a human stage.',
    }])],
  }).processes;
  // normalize keeps the field so the gate can name the mistake instead of dropping it silently.
  assert.equal(processes[0].tasks[0].journeyRef, 'abrirOrdenServicio');
  const gate = gateOf(processes, NO_HANDOFF_JOURNEYS, ORDEN_ENTITIES);
  assert.equal(gate.ok, false);
  const kind = gate.issues.find(issue => issue.code === 'NS5_WORKFLOWS_KIND');
  assert.ok(kind);
  assert.match(kind.message, /alert carries no journey or entity/);
});

void test('a state the data already answers is no signal: no phrase, no LLM call', () => {
  const phrases = collectNs5TimeEventPhrases('A mensalidade fica vencida depois do dia 10. O aluno bloqueado nao entra.');
  assert.deepEqual(phrases, []);
  assert.equal(ns5WorkflowsNeedsLlm([], phrases), false);
  assert.equal(
    ns5WorkflowsNeedsLlm([], collectNs5TimeEventPhrases('Todo mes a gerencia gera as mensalidades.')),
    true,
  );
});

void test('buildNs5WorkflowsArtifactV3 stamps v3 and v2 stays available for recorded runs', () => {
  const normalized = drafts({ processes: [validProcess()] });
  assert.equal(
    buildNs5WorkflowsArtifactV3('mensalidadesAcademia', normalized.processes).schemaVersion,
    '2026-09-17-ns5-workflows-v3',
  );
  assert.equal(
    buildNs5WorkflowsArtifact('mensalidadesAcademia', normalized.processes).schemaVersion,
    '2026-09-12-ns5-workflows-v2',
  );
});

void test('workflows schema declares the alert branch with all five keys required', () => {
  const schema = loadSchema() as { $defs: { task: { oneOf: Array<Record<string, any>> } } };
  const branches = schema.$defs.task.oneOf;
  assert.equal(branches.length, 4);
  const alert = branches.find(branch => branch.properties?.kind?.const === 'alert');
  assert.ok(alert);
  assert.equal(alert.additionalProperties, false);
  assert.deepEqual(alert.required, ['taskId', 'kind', 'actorRef', 'next', 'description']);
  assert.deepEqual(Object.keys(alert.properties).sort(), ['actorRef', 'description', 'icon', 'kind', 'next', 'taskId']);
});

void test('buildNs5WorkflowsArtifact keeps schemaVersion and process order', () => {
  const normalized = drafts({
    processes: [validProcess()],
    journeyDecisions: ORDEN_JOURNEYS.map(item => ({
      journeyId: item.journeyId,
      inProcess: true,
      processId: 'serviceOrderFulfillment',
    })),
  }, ORDEN_JOURNEYS.map(item => item.journeyId));
  const artifact = buildNs5WorkflowsArtifact(
    'ordenServicio5',
    normalized.processes,
    normalized.journeyDecisions,
    normalized.systemDecisions,
  );
  assert.equal(artifact.schemaVersion, '2026-09-12-ns5-workflows-v2');
  assert.equal(artifact.moduleName, 'ordenServicio5');
  assert.equal(artifact.processes[0].processId, 'serviceOrderFulfillment');
  assert.equal(artifact.processes[0].tasks[2].actorRef, 'cliente');
  assert.equal(artifact.journeyDecisions.length, 5);
});

void test('ownerStepId maps workflows50 repair planIds', () => {
  assert.equal(ownerStepId('workflows50'), 'workflows50');
  assert.equal(ownerStepId('workflows50-repair-1'), 'workflows50');
  assert.equal(ownerStepId('workflows50-done'), '');
});

void test('human prompt carries source request, journeys, write acts, phrases and transitions', () => {
  const serviceOrder = {
    schemaVersion: '2026-09-11-ns5-ontology-v2',
    moduleName: 'ordenServicio5',
    entityId: 'ServiceOrder',
    title: 'Service order',
    description: 'Repair order.',
    kind: 'core',
    party: 'none',
    displayField: 'numeroOrden',
    fields: [],
    lifecycleStates: [
      { state: 'open', reachedBy: 'actor' },
      { state: 'budgetReady', reachedBy: 'actor' },
    ],
    transitions: [{
      transitionId: 'publishBudget',
      from: ['open'],
      to: 'budgetReady',
      by: ['tecnico'],
      description: 'Technician publishes the budget.',
    }],
    storage: { target: 'moduleDatabase', scope: 'module', idField: 'id' },
  } as Ns5OntologyEntityArtifact;
  const decideJourney = {
    schemaVersion: '2026-09-10-ns5-journey-v1',
    journeyId: 'consultarYDecidirPresupuesto',
    business: {
      actorRef: 'cliente',
      title: 'Decide the budget',
      goal: 'Approve or reject.',
      entry: { mode: 'fromNotification' },
      steps: [
        { stepId: 'decideBudget', kind: 'decide', entity: 'ServiceOrder', title: 'Decide', description: 'The customer decides.' },
      ],
      outcome: { statement: 'Decided.', evidence: ['Decided.'] },
    },
    businessHash: 'sha256:0',
  } as Ns5JourneyArtifact;
  const analyzeJourney = {
    schemaVersion: '2026-09-10-ns5-journey-v1',
    journeyId: 'prepararPresupuestoServicio',
    business: {
      actorRef: 'tecnico',
      title: 'Analyze',
      goal: 'Publish a budget.',
      entry: { mode: 'contextOrLookup' },
      steps: [
        {
          stepId: 'publishBudget',
          kind: 'act',
          entity: 'ServiceOrder',
          effect: 'transition',
          transitionRef: 'publishBudget',
          title: 'Publish',
          description: 'Budget is published.',
        },
        { stepId: 'handToCustomer', kind: 'handoff', entity: 'ServiceOrder', handoffTo: 'cliente', title: 'Hand off', description: 'Customer decides next.' },
      ],
      outcome: { statement: 'Published.', evidence: ['Published.'] },
    },
    businessHash: 'sha256:1',
  } as Ns5JourneyArtifact;
  const human = buildNs5WorkflowsHumanPrompt({
    sourcePrompt: 'modulo orden de servicio. perfiles: recepcionista, tecnico, cliente. cuando el cliente responde, continuar.',
    userLanguage: 'es',
    actorIds: ORDEN_ACTORS,
    journeys: [analyzeJourney, decideJourney],
    entities: [serviceOrder],
  });
  assert.match(human, /Source request/);
  assert.match(human, /consultarYDecidirPresupuesto \(cliente\)/);
  assert.match(human, /handoffTo=cliente/);
  assert.match(human, /ServiceOrder\.publishBudget/);
  assert.match(human, /"kind": "handoff"/);
  assert.match(human, /effect=transition/);
  assert.match(human, /Time and event phrases/);
  assert.match(human, /cuando el cliente responde/i);
  assert.doesNotMatch(human, /stepRefs/);
});

void test('workflows50 prompt has no domain examples and keeps process vs FSM', () => {
  const prompt = readFileSync(path.join(HERE, 'prompt.md'), 'utf8');
  assert.match(prompt, /submitNs5Workflows/);
  assert.match(prompt, /not the entity lifecycle/);
  assert.match(prompt, /placeholders — use only ids that exist in the module/);
  assert.match(prompt, /journeyDecisions/);
  assert.match(prompt, /mechanical/);
  assert.doesNotMatch(prompt, /stepRef/);
  assert.doesNotMatch(prompt, /comanda|garcom|waiter|stock|quantity|descuento|presupuesto|recepcionista/i);
});

// --- ns5_49: workflows50 runs before ontology30 -----------------------------
// There is no ontology on disk when this step runs, so `entities` arrives empty. What a stage cites
// is a declaration the ontology will honour; the checks against the ontology stand down, and the
// catalog of valid ids comes from the journeys. The thirteen recorded v2 runs still pass entities,
// and for them nothing changes.

const NS5_49_FORWARD_PROCESS: Ns5WorkflowProcess[] = drafts({
  processes: [validProcess({
    processId: 'closeOrders',
    trigger: { kind: 'scheduled', schedule: 'todo mes' },
    tasks: [
      {
        taskId: 'archive',
        kind: 'mechanical',
        entityRef: 'ServiceOrderArchive',
        effect: 'transition',
        transitionRef: 'archiveServiceOrder',
        next: [],
        description: 'The system archives the order.',
      },
    ],
  })],
}).processes;

void test('ns5_49: with no ontology, a stage may cite an entity and a transition that do not exist yet', () => {
  const gate = validateNs5Workflows(NS5_49_FORWARD_PROCESS, {
    actorIds: ORDEN_ACTORS,
    journeys: [],
    entities: [],
  });
  assert.equal(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_ENTITY_UNKNOWN'), false, formatNs5WorkflowsGate(gate.issues));
  assert.equal(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_TRANSITION'), false, formatNs5WorkflowsGate(gate.issues));
  assert.equal(gate.ok, true, formatNs5WorkflowsGate(gate.issues));
});

void test('ns5_49: the same citation is still checked when the ontology IS on hand (recorded v2 runs)', () => {
  const gate = validateNs5Workflows(NS5_49_FORWARD_PROCESS, {
    actorIds: ORDEN_ACTORS,
    journeys: [],
    entities: ORDEN_ENTITIES,
  });
  assert.equal(gate.ok, false);
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_ENTITY_UNKNOWN'));
});

// ns5_56 narrowed the ns5_49 leniency for `trigger.event` ONLY: a stage may still cite an entity or a
// transition the ontology has not declared, but what STARTS a process has to be something a journey
// moves. `manutencaoFrota` invented `PlanoManutencao.preventivaVencida` — a condition over data — and
// nothing caught it until finalize80 I1, with no repair round left.
void test('ns5_56: with no ontology, trigger.event must name a transition a journey moves', () => {
  const processes = drafts({
    processes: [validProcess({
      processId: 'onArchive',
      trigger: { kind: 'event', event: 'ServiceOrderArchive.archiveServiceOrder' },
      tasks: [{ taskId: 'note', kind: 'wait', next: [], description: 'Waits a day.' }],
    })],
  }).processes;
  const without = validateNs5Workflows(processes, { actorIds: ORDEN_ACTORS, journeys: ORDEN_JOURNEYS, entities: [] });
  const issue = without.issues.find(item => item.code === 'NS5_WORKFLOWS_TRIGGER_EVENT');
  assert.ok(issue, formatNs5WorkflowsGate(without.issues));
  assert.match(issue.message, /is not a transition any journey moves/);
  assert.match(issue.message, /derived field/);
  assert.match(issue.message, /alert stage/);
  // Not the ontology lookup: there is no ontology here.
  assert.equal(without.issues.some(item => item.code === 'NS5_WORKFLOWS_ENTITY_UNKNOWN'), false);
  const withOntology = validateNs5Workflows(processes, { actorIds: ORDEN_ACTORS, journeys: [], entities: ORDEN_ENTITIES });
  assert.ok(withOntology.issues.some(item => item.code === 'NS5_WORKFLOWS_ENTITY_UNKNOWN'));
});

void test('ns5_56: a trigger.event inside the journey catalog passes with no ontology', () => {
  const processes = drafts({
    processes: [validProcess({
      processId: 'onPublish',
      trigger: { kind: 'event', event: 'ServiceOrder.publishBudget' },
      tasks: [{ taskId: 'note', kind: 'wait', next: [], description: 'Waits a day.' }],
    })],
  }).processes;
  const gate = validateNs5Workflows(processes, { actorIds: ORDEN_ACTORS, journeys: ORDEN_JOURNEYS, entities: [] });
  assert.equal(gate.issues.some(item => item.code === 'NS5_WORKFLOWS_TRIGGER_EVENT'), false, formatNs5WorkflowsGate(gate.issues));
});

void test('ns5_56: an inbound trigger.event is untouched', () => {
  const processes = drafts({
    processes: [validProcess({
      processId: 'onInbound',
      trigger: { kind: 'event', event: 'billing.invoicePaid' },
      tasks: [{ taskId: 'note', kind: 'wait', next: [], description: 'Waits a day.' }],
    })],
  }).processes;
  const gate = validateNs5Workflows(processes, { actorIds: ORDEN_ACTORS, journeys: ORDEN_JOURNEYS, entities: [] });
  assert.equal(gate.issues.some(item => item.code === 'NS5_WORKFLOWS_TRIGGER_EVENT'), false, formatNs5WorkflowsGate(gate.issues));
});

void test('ns5_49: a foreignBy signal alone no longer obliges a process', () => {
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: {
      ...item.business,
      steps: item.business.steps.filter(step => step.kind !== 'handoff' && step.kind !== 'decide'),
    },
  }));
  const signals = collectNs5ProcessSignals(noHandoff, ORDEN_ENTITIES);
  assert.ok(signals.some(signal => signal.kind === 'foreignBy'));
  const gate = validateNs5Workflows([], { actorIds: ORDEN_ACTORS, journeys: noHandoff, entities: ORDEN_ENTITIES });
  assert.equal(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_SIGNAL_WITHOUT_PROCESS'), false);
});

void test('ns5_49: a handoff and a cross-actor decide still oblige a process', () => {
  const gate = validateNs5Workflows([], { actorIds: ORDEN_ACTORS, journeys: ORDEN_JOURNEYS, entities: [] });
  assert.ok(gate.issues.some(issue => issue.code === 'NS5_WORKFLOWS_SIGNAL_WITHOUT_PROCESS'));
});

void test('ns5_49: the reference catalog comes from the journeys when there is no ontology', () => {
  const catalog = collectNs5WorkflowsRefCatalog(ORDEN_JOURNEYS, ORDEN_ACTORS, []);
  assert.deepEqual(catalog.entityIds, ['ServiceOrder']);
  assert.deepEqual(catalog.transitionRefs.sort(), [
    'ServiceOrder.completeServiceOrder',
    'ServiceOrder.markServiceOrderReady',
    'ServiceOrder.publishBudget',
  ]);
});

void test('workflows schema requires process functions and lowerCamel functionId', () => {
  const schema = loadSchema() as {
    $defs: {
      process: {
        required: string[];
        additionalProperties: boolean;
        properties: {
          functions: {
            minItems: number;
            items: {
              additionalProperties: boolean;
              required: string[];
              properties: { functionId: { pattern: string }; description: { minLength: number } };
            };
          };
        };
      };
    };
  };
  const process = schema.$defs.process;
  assert.equal(process.additionalProperties, false);
  assert.ok(process.required.includes('functions'));
  const functions = process.properties.functions;
  assert.equal(functions.minItems, 1);
  assert.equal(functions.items.additionalProperties, false);
  assert.deepEqual(functions.items.required, ['functionId', 'description']);
  const re = new RegExp(functions.items.properties.functionId.pattern);
  assert.equal(re.test('iniciarTarefa'), true);
  assert.equal(re.test('IniciarTarefa'), false);
});

void test('duplicate functionId across processes is NS5_WORKFLOWS_FUNCTION_ID', () => {
  const fn = { functionId: 'abrirOcorrencia', description: 'A screen calls this to open the occurrence.' };
  const processes = [
    validProcess({ processId: 'one', functions: [fn] }),
    validProcess({ processId: 'two', functions: [{ ...fn }] }),
  ] as Ns5WorkflowProcess[];
  const gate = gateOf(processes);
  const duplicates = gate.issues.filter(issue => issue.code === 'NS5_WORKFLOWS_FUNCTION_ID');
  assert.equal(duplicates.length, 1);
  assert.equal(duplicates[0]?.severity, 'error');
  assert.equal(gate.ok, false);
});

void test('a process without functions warns and stays valid', () => {
  const processes = [validProcess()] as Ns5WorkflowProcess[];
  const gate = gateOf(processes);
  const missing = gate.issues.filter(issue => issue.code === 'NS5_WORKFLOWS_FUNCTIONS_MISSING');
  assert.equal(missing.length, 1);
  assert.equal(missing[0]?.severity, 'warning');
  assert.equal(gate.issues.some(issue => issue.severity === 'error'), false);
  assert.equal(gate.ok, true);
});

void test('recorded compras fixture still passes the workflows gate', () => {
  const workflows = loadNs5Workflows('compras');
  const journeys = loadNs5Journeys('compras').map(item => ({
    journeyId: item.journeyId,
    business: {
      actorRef: item.business.actorRef,
      steps: item.business.steps.map(step => ({
        stepId: step.stepId,
        kind: step.kind,
        entity: step.entity,
        ...(step.handoffTo ? { handoffTo: step.handoffTo } : {}),
        ...(step.effect ? { effect: step.effect } : {}),
        ...(step.transitionRef ? { transitionRef: step.transitionRef } : {}),
      })),
    },
  }));
  const entities = loadNs5Entities('compras').map(item => ({
    entityId: item.entityId,
    transitions: (item.transitions || []).map(transition => ({
      transitionId: transition.transitionId,
      by: transition.by,
    })),
  }));
  const normalized = drafts(workflows, journeys.map(item => item.journeyId));
  const gate = validateNs5Workflows(normalized.processes, {
    actorIds: loadNs5Actors('compras').map(actor => actor.actorId),
    journeys,
    entities,
    journeyDecisions: normalized.journeyDecisions,
  });
  assert.equal(gate.ok, true, formatNs5WorkflowsGate(gate.issues));
});

void test('room person and a periodic wait survive normalization', () => {
  const normalized = drafts({
    processes: [validProcess({
      room: 'person',
      tasks: [
        humanTask('receive', 'recepcionista', 'abrirOrdenServicio', ['pause'], 'Reception opens the order.'),
        { taskId: 'pause', kind: 'wait', next: [], description: 'Wait.', wake: { mode: 'periodic', every: 'PT1H' } },
        { taskId: 'aside', kind: 'human', actorRef: 'tecnico', journeyRef: 'prepararPresupuestoServicio', next: [], description: 'Not a wait.', wake: { mode: 'periodic', every: 'P1D' } },
      ],
    })],
  });
  assert.equal(normalized.processes[0].room, 'person');
  const pause = normalized.processes[0].tasks.find(task => task.taskId === 'pause');
  assert.deepEqual(pause?.wake, { mode: 'periodic', every: 'PT1H' });
  const aside = normalized.processes[0].tasks.find(task => task.taskId === 'aside');
  assert.equal(aside?.wake, undefined);
  assert.ok(normalized.systemDecisions.some(decision => decision.decisionId === 'dropWakeOffWaitAside'));
});

void test('periodic wake without every, or with a non-duration, is NS5_WORKFLOWS_WAKE_EVERY', () => {
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: { ...item.business, steps: item.business.steps.filter(step => step.kind !== 'handoff') },
  }));
  const gateFor = (wake: { mode: 'periodic'; every?: string }) => {
    const processes = drafts({
      processes: [validProcess({
        room: 'exclusive',
        tasks: [
          humanTask('receive', 'recepcionista', 'abrirOrdenServicio', ['pause'], 'Reception opens the order.'),
          { taskId: 'pause', kind: 'wait', next: [], description: 'Wait.', wake },
        ],
      })],
    }).processes;
    return gateOf(processes, noHandoff, ORDEN_ENTITIES);
  };
  const missing = gateFor({ mode: 'periodic' });
  assert.equal(missing.ok, false);
  assert.ok(missing.issues.some(issue => issue.code === 'NS5_WORKFLOWS_WAKE_EVERY' && issue.severity === 'error'));
  const bad = gateFor({ mode: 'periodic', every: '1h' });
  assert.equal(bad.ok, false);
  assert.ok(bad.issues.some(issue => issue.code === 'NS5_WORKFLOWS_WAKE_EVERY' && issue.severity === 'error'));
});

void test('a recorded process without room and a wait without wake only warn and stay valid', () => {
  const noHandoff = ORDEN_JOURNEYS.map(item => ({
    ...item,
    business: { ...item.business, steps: item.business.steps.filter(step => step.kind !== 'handoff') },
  }));
  const processes = drafts({
    processes: [validProcess({
      tasks: [
        humanTask('receive', 'recepcionista', 'abrirOrdenServicio', ['pause'], 'Reception opens the order.'),
        { taskId: 'pause', kind: 'wait', next: [], description: 'Wait.' },
      ],
    })],
  }).processes;
  const gate = gateOf(processes, noHandoff, ORDEN_ENTITIES);
  assert.equal(gate.ok, true, formatNs5WorkflowsGate(gate.issues));
  assert.equal(gate.issues.filter(issue => issue.code === 'NS5_WORKFLOWS_ROOM_MISSING' && issue.severity === 'warning').length, 1);
  assert.equal(gate.issues.filter(issue => issue.code === 'NS5_WORKFLOWS_WAKE_MISSING' && issue.severity === 'warning').length, 1);
  assert.equal(gate.issues.some(issue => issue.severity === 'error'), false);
});

void test('ns5_49: the human prompt no longer carries the entity lifecycle block', () => {
  const prompt = buildNs5WorkflowsHumanPrompt({
    sourcePrompt: 'todo mes a gerencia fecha as ordens.',
    userLanguage: 'pt-BR',
    actorIds: ORDEN_ACTORS,
    journeys: ORDEN_JOURNEYS as never,
    entities: [],
  });
  assert.equal(prompt.includes('## Entities with lifecycle'), false);
  assert.match(prompt, /## Valid reference ids/);
  assert.match(prompt, /ServiceOrder\.publishBudget/);
});

void test('icon null is absent and an unknown Lucide name is dropped and recorded', () => {
  const normalized = drafts({
    processes: [validProcess({
      tasks: [
        { ...humanTask('receive', 'recepcionista', 'abrirOrdenServicio', [], 'Reception opens the order.'), icon: null },
        { ...humanTask('analyze', 'tecnico', 'prepararPresupuestoServicio', [], 'Technician publishes the budget.'), icon: 'not-a-lucide-name' },
        { ...humanTask('repair', 'tecnico', 'repararAparato', [], 'Technician marks the order ready.'), icon: 'clipboard-check' },
      ],
    })],
  });
  const tasks = normalized.processes[0].tasks;
  assert.equal('icon' in tasks[0], false);
  assert.equal('icon' in tasks[1], false);
  assert.equal(tasks[2].icon, 'clipboard-check');
  assert.equal(normalized.normalizations.length, 1);
  assert.equal(normalized.normalizations[0].kind, NS5_WORKFLOW_DROP_UNKNOWN_ICON);
  assert.equal(normalized.normalizations[0].taskId, 'analyze');
  assert.equal(normalized.systemDecisions.some(decision => decision.decisionId.includes('icon')), false);
});

void test('workflows50 prompt and schema state task icon as intention', () => {
  const prompt = readFileSync(path.join(HERE, 'prompt.md'), 'utf8');
  assert.match(prompt, /`icon` is a Lucide icon name for the task/);
  const schema = loadSchema() as {
    $defs: { task: { oneOf: Array<{ required: string[]; properties: { icon?: { type: string } } }> } };
  };
  assert.equal(schema.$defs.task.oneOf.length, 4);
  for (const branch of schema.$defs.task.oneOf) {
    assert.equal(branch.required.includes('icon'), false);
    assert.equal(branch.properties.icon?.type, 'string');
  }
  const source = readFileSync(path.join(HERE, 'agentNs5Workflows.ts'), 'utf8');
  assert.match(source, /normalizations/);
});
