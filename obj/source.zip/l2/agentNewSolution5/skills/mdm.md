<!-- mls fileReference="_102035_/l2/agentNewSolution5/skills/mdm.md" enhancement="_blank" -->
<!-- injected into the prompts of module10, journeys20, ontology30 and access60 (readAgentText('skills', 'mdm', '.md')); generic platform knowledge, no business domain -->

# MDM — how the platform keeps people, companies, products and places

The organization has ONE master data store (MDM). A module never owns a person, a company, a product, a
place or an asset: it declares a **role** over a level-1 record and keeps only what is specific to the
module in its own namespace. This is what makes the same customer appear in every module as one record.

## The record

Every MDM record has four layers. Only the last one belongs to a module.

| layer | who writes | what it holds |
|---|---|---|
| identification | organization | `subtype` (level-1 catalog), `name`, `docType` + `docId`, `countryCode`, `tags` |
| base | organization | typed fields of the subtype (`contacts[]`, `addresses[]`, `birthDate`, `legalName`, `sku`…), `relationshipRefs` |
| general | organization, by promotion | fields that more than one module needed and the platform promoted |
| `details[<moduleId>]` | **the module** | the module's namespace: only what nobody else needs |

A module reads identification + base + general + its own namespace. Other modules' namespaces are visible
only by name. A module never redeclares a level-1 field (name, document, contacts, addresses) in its
namespace, and never stores a login or an identity there.

## Identity and login

A person who signs in is one MDM record. Her login is an **index row**, not a field: the tag table
(`mdm_tag`) holds many rows per record — `{ entityType: 'MdmEntity', entityId: <mdmId>, namespace: 'login',
tag: <login e-mail>, module: 'organization' }` — and is indexed by `(entityType, tag, module)`, so login
resolves in one indexed lookup. One login e-mail belongs to exactly one record; one record may carry other
identifiers the same way (an external system id, a badge number), each in its own namespace.

The record's `docType` + `docId` stay for the **national document** (`CPF`, `CNPJ`, `SSN`…), unique among
permanent records, which is what deduplication uses. A person can therefore have both a login and a
document, and a record that never signs in has no login row.

The JWT says **who** (login e-mail) and **what she may do** (authorities `<moduleId>:<actorId>`). The MDM
says **where she exists**: the role tags `<moduleId>.<EntityId>` on her record list every module she takes
part in, and `details[<moduleId>]` holds that module's data about her. The platform resolves the session
person (`sessionContext.person`); a module never does. Nothing about permissions is stored in the MDM;
nothing about identity is stored in a module table.

Registering a person who will sign in is a write by an internal actor — an `act` on that person entity,
or an `act` that attaches her (`affects`) such as an enrollment or an order opening (or a public self-registration
entry), or she is reference data kept by an internal actor (`writer: 'crud'` with that actor's grant), or she
registers herself (an `act` of her own external actor that writes her). The engine also counts two
derived writes, recorded as `writerDerived` — do not invent `crud`/`inbound` for them: a non-mdm child
that is the many-side of a required `manyToOne`/`oneToMany` whose parent already has a writer (`parent`);
and an mdm role referenced by a required FK of a record whose writer is an `act` with `effect: 'create'`
(`attach` — create-or-attach of that role). The platform does the rest: looks the e-mail up in the login index
and the document in the record, attaches the role when it is the same person, refuses when the
e-mail belongs to another record, and issues the invitation. A journey never has an 'invite' or
'verify e-mail' step.

## Roles

`kind: role` in the ontology means "a role of this module over a level-1 subtype". One rule per line:

- `subtype` is one of the platform subtypes (`Person`, `Company`, `Product`, `Service`, `Location`,
  `AssetEquipment`…); `roleTag`, `source` and `storage` are derived, never written.
- The record is the platform record: start from the `## Starting point` the prompt gives you, keep the
  fields the role uses, drop the rest, and keep every branch — `identification`, `base`, the subtype
  branch, `general` and the branch named after this module.
- Only tighten: `required` false to true, `values` a subset, a stricter `pattern` or `maxLength`. Never
  loosen, never rename, never change a type, never make a derived field writable.
- Never add a field to a platform branch. What the module knows and nobody else needs goes in
  `details.<moduleId>`, and only that.
- The namespace never carries identity, document, contact, login, a copy of a platform field, or a field
  that fakes a platform service (photo, receipt, attachment, link to a file, phone). Empty is a correct
  namespace, and its description is written for you.
- `displayField` is a path of the record (`details.identification.name`).
- No `lifecycleStates`, no `transitions`: a master record has no business state; its activity is the MDM
  status (active / inactive), and what happens to it is recorded by the module's own entities.
- `capabilities` are chosen by id from the platform catalog, each with the sentence of this module, plus
  the module's own with the prefix `<moduleId>.`; `rules` are ids only.

Creating a role is **create-or-attach**: the engine looks the record up by document (or contact), creates
it only when absent, then attaches the role tag and writes the namespace. A role is never deleted; it is
inactivated and can be reactivated.

Actors are not roles. A receptionist or a manager is an actor (someone who acts) and a profile (a set of
authorities); she becomes an MDM entity only when the business needs to record something **about** her
(an employee file, a commission). Do not create a `Person` entity per actor. An internal actor whose
records are scoped to *her own*, *her team's* or *what is assigned to her* is a `Person` role of the
module (the actor id as entity name is fine); team and assignment are level-1 relationships
(`MemberOf`, `ReportsTo`, `Employs`) or a foreign key to that Person — never a free-text filter.

## Relationships

Relationships between records are typed, versioned and live in the MDM (`link` / `unlink`), from the
level-1 catalog: `Family`, `GuardianOf`, `CustomerOf`, `SupplierOf`, `Employs`, `MemberOf`, `Owns`,
`LocatedAt`, `HasContact`… One person may be guardian of many, customer of many, member of many. Compact
keys (`family`, `guardians`, `customers`…) are kept on the record for fast reads.

A module uses these instead of inventing a join entity when the fact is about two master records
("this person is responsible for that person"). A module invents an entity only for a **business event
or transaction** of its own (an enrollment, an order, a payment).

## Ownership and scope

Who may see a record is decided by the access matrix, and enforced by the backend as a path:
- `own`: the entity reaches, through its foreign keys, the `Person` whose login row is the session login;
- `assigned`: a direct foreign key to the Person of the login;
- `related`: a level-1 relationship (`MemberOf`, `ReportsTo`, `Employs`, `GuardianOf`, `Family`…) to the login person;
- `organization`: no path; every record of the organization.
A journey step that reads "my orders" or "my students" is therefore a `dataScope`, never a filter field
the user types.

WHICH fields they see is `disclosure`, and on a master record it addresses the tree of the document
(`<Entity>.details.identification.name`, `<Entity>.details.person`), never the identity alone: an actor
granted only `<Entity>.id` sees a uuid and no name.

## Computed values

Values derived from other data (a total, a balance, a due situation) are not fields and not entities:
they are `details: { <name>: { type, description } }` on the entity that owns them (or on the module,
for organization-wide aggregates). A panel entity that only stores those aggregates (no writer, no
fields besides the identity) is lifted into
`module.details`; the panel is the source of overlapping keys. The backend computes them; a rule may
cite them. An entity with real fields is never a panel.

## What the MDM already answers (do not model it in the module)

Deduplication by document, contact channels, addresses, aliases, tags (`mdm_tag`, many rows per record),
relationships, status history, attachments (photos, files), comments (notes), **audit** (every master-data
write is logged and readable through the platform `audit` module — never create an audit, log or history entity),
prospects with promotion, number sequences, and the `general` layer. The machine-readable list is the platform
catalog (`platform.defs.ts`, emitted with the level-1 defs). If the request needs one
of these for a person, company, product or place, it is level-1 base data — reference it, do not redeclare it.
