/// <mls fileReference="_102035_/l2/newRelease/tobe.test.ts" enhancement="_blank" />

import { applyDirectLanguages, languageCommands } from './helpers/directLanguages.js';
import { readDefsJson } from '/_102035_/l2/solution/fs.js';
import assert from 'node:assert/strict';
import test from 'node:test';
import { loadNs5Entities, loadNs5OracleSources } from '/_102035_/l2/solution/testing/ns5RealFixtures.test.js';
import {
  saveDirectLanguageMetadata,
  completeTobeImplementation,
  discardTobe,
  readNs5Overlay,
  recordTobeDiscard,
  recordTobeSave,
  saveTobeArtifact,
  NewReleaseSaveValidationError,
  tobeManifestFileInfo,
} from './tobe.js';
import { validateNs5Overlay } from '/_102035_/l2/solution/candidate/overlayValidation.js';
import {
  isNs5OntologyV3,
  NS5_TOBE_MANIFEST_SCHEMA_VERSION,
  ns5OntologyEntityIds,
  normalizeTobeArtifactPath,
  tobeArtifactFileInfo,
  type NewReleaseArtifact,
  type NewReleaseOverlaySources,
} from '/_102035_/l2/solution/candidate/tobePaths.js';
import { tabForArtifactPath } from './editContract.js';
import { sha256Tobe } from '/_102035_/l2/solution/candidate/tobeDiff.js';
import { L4SealedCandidateError, markL4Result, readActiveL4Change, readChangeRequest, readL4Release, readL4Revision, readSealedL4Candidate, resolveL4Folders, sealL4Revision } from '/_102035_/l2/solution/candidate/moduleRevision.js';
import { historicalReleaseId } from './helpers/context.js';
import { readChangeOrigins } from './helpers/changeOrigins.js';
import { readNs5Module } from './helpers/l4Reader.js';
import { bindStructuredEditsRequest, ChangeRequestDrafts, contextStillCurrent, listReleaseChoices, reuseHistoricalRelease, revisionsForKnob, saveChangeRequest, selectedRevisionIndex } from './helpers/revisionSelection.js';

test('v3 ontology index resolves descriptor rows to entity file ids without changing v2 ids', () => {
  const v3 = {
    schemaVersion: '2026-09-15-ns5-ontology-v3', moduleName: 'agendaClinica', businessDomain: 'Agenda',
    platformOntology: '/_102034_/l4/ontology/mdm.defs.ts', moduleNamespace: { key: 'agendaClinica', description: 'Módulo' },
    entities: [{ entityId: 'Paciente', kind: 'role', subtype: 'Person' }, { entityId: 'Consulta', kind: 'entity', class: 'core' }], relationships: [],
  } as const;
  assert.equal(isNs5OntologyV3(v3), true);
  assert.deepEqual(ns5OntologyEntityIds(v3), ['Paciente', 'Consulta']);
  assert.deepEqual(ns5OntologyEntityIds({
    schemaVersion: '2026-09-11-ns5-ontology-v2', moduleName: 'legacy', businessDomain: 'Legacy', entities: ['A'], relationships: [],
  }), ['A']);
});

test('manifest preserves first base hash and records each confirmed change', () => {
  const first = recordTobeSave(null, 'module.defs.ts', '$.title', 'sha256:first', 'user@example.com', '2026-09-13T00:00:00.000Z');
  const second = recordTobeSave(first, 'module.defs.ts', '$.sourcePrompt', 'sha256:later', 'user@example.com', '2026-09-13T00:01:00.000Z');
  assert.equal(second.schemaVersion, NS5_TOBE_MANIFEST_SCHEMA_VERSION);
  assert.equal(second.base['module.defs.ts'], 'sha256:first');
  assert.equal(second.changes.length, 2);
  assert.equal(recordTobeDiscard(second, 'module.defs.ts'), null);
});

test('artifact paths are allow-listed and map to an explicit project', () => {
  assert.equal(normalizeTobeArtifactPath('journeys/myJourney.defs.ts'), 'journeys/myJourney.defs.ts');
  assert.deepEqual(tobeArtifactFileInfo(102047, 'agendaClinica', 'journeys/myJourney.defs.ts', 'tobe'), {
    project: 102047,
    level: 4,
    folder: 'agendaClinica/tobe/plan/journeys',
    shortName: 'myJourney',
    extension: '.defs.ts',
  });
  assert.throws(() => normalizeTobeArtifactPath('../project.json'), /Unsupported tobe artifact path/);
  assert.throws(() => normalizeTobeArtifactPath('/module.defs.ts'), /Unsupported tobe artifact path/);
});

test('journey files and their index share the future journeys tab seam', () => {
  assert.equal(tabForArtifactPath('journeys/index.defs.ts'), 'journeys');
  assert.equal(tabForArtifactPath('journeys/cadastrarCliente.defs.ts'), 'journeys');
  assert.equal(tabForArtifactPath('module.defs.ts'), 'general');
});

function artifact<T>(path: NewReleaseArtifact<T>['path'], value: T): NewReleaseArtifact<T> {
  return { path, source: 'asis', value };
}

function realOverlay(): NewReleaseOverlaySources {
  const source = loadNs5OracleSources('ordenServicio5');
  const module = artifact('module.defs.ts', source.module);
  const journeyIndex = artifact('journeys/index.defs.ts', source.journeyIndex);
  const journeys = source.journeys.map(value => artifact(`journeys/${value.journeyId}.defs.ts` as const, value));
  const ontologyIndex = artifact('ontology/index.defs.ts', source.ontologyIndex);
  const entities = loadNs5Entities('ordenServicio5').map(value => artifact(`ontology/${value.entityId}.defs.ts` as const, value));
  const rules = artifact('rules.defs.ts', source.rules);
  const workflows = artifact('workflows.defs.ts', source.workflows);
  const access = artifact('access.defs.ts', source.access);
  const integration = artifact('integration.defs.ts', source.integration);
  return {
    module, journeyIndex, journeys, ontologyIndex, entities, rules, workflows, access, integration,
    all: [module, journeyIndex, ...journeys, ontologyIndex, ...entities, rules, workflows, access, integration],
  };
}

test('overlay gates and in-memory oracle accept a real NS5 fixture', async () => {
  const sources = realOverlay();
  const result = await validateNs5Overlay(sources, { registryModuleNames: ['ordenServicio5'] });
  assert.equal(result.oracle?.finalStatus, 'passed', result.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
  assert.equal(result.ok, true, result.issues.map(issue => `${issue.code}: ${issue.message}`).join('\n'));
});

test('overlay reports an invalid prepared artifact before apply or execute', async () => {
  const sources = realOverlay();
  sources.module.value = { ...sources.module.value!, defaultLanguage: 'fr' };
  const result = await validateNs5Overlay(sources, { registryModuleNames: ['ordenServicio5'] });
  assert.equal(result.ok, false);
  assert.ok(result.issues.some(issue => issue.code === 'NS5_MODULE_DEFAULT_LANGUAGE' && issue.artifact === 'module.defs.ts' && !issue.baseline));
});

test('overlay baseline ignores an error already on the module and still blocks a new one', async () => {
  const context = { registryModuleNames: ['ordenServicio5'] };
  const base = realOverlay();
  base.module.value = { ...base.module.value!, defaultLanguage: 'fr' };
  const same = realOverlay();
  same.module.value = { ...same.module.value!, defaultLanguage: 'fr' };
  const kept = await validateNs5Overlay(same, context, base);
  assert.ok(kept.issues.some(issue => issue.code === 'NS5_MODULE_DEFAULT_LANGUAGE' && issue.baseline === true));
  assert.equal(kept.coverage.module.status, 'checked');
  assert.equal(kept.ok, true, kept.issues.filter(issue => issue.severity === 'error' && !issue.baseline).map(issue => issue.code).join(','));

  const freshSource = realOverlay();
  freshSource.module.value = { ...freshSource.module.value!, defaultLanguage: 'fr' };
  const fresh = await validateNs5Overlay(freshSource, context, realOverlay());
  assert.ok(fresh.issues.some(issue => issue.code === 'NS5_MODULE_DEFAULT_LANGUAGE' && !issue.baseline));
  assert.equal(fresh.coverage.module.status, 'error');
  assert.equal(fresh.ok, false);

  const unbased = await validateNs5Overlay(freshSource, context);
  assert.equal(unbased.ok, false);
  assert.ok(unbased.issues.some(issue => issue.code === 'NS5_MODULE_DEFAULT_LANGUAGE' && !issue.baseline));
});

function installStorFixture(project: number, moduleName: string) {
  const source = loadNs5OracleSources(moduleName);
  const files: Record<string, any> = {};
  const contents = new Map<string, string>();
  const keyOf = (info: any) => `${info.project}:${info.level}:${info.folder || ''}:${info.shortName}${info.extension}`;
  const add = (path: NewReleaseArtifact<unknown>['path'], value: unknown) => {
    const info = tobeArtifactFileInfo(project, moduleName, path, 'asis');
    const key = keyOf(info);
    contents.set(key, `export const fixture = ${JSON.stringify(value, null, 2)} as const;\n`);
    files[key] = {
      ...info,
      status: 'unchanged',
      versionRef: '1',
      getContent: async () => contents.get(key) || '',
      getValueInfo: async () => ({ content: contents.get(key) || '' }),
    };
  };
  add('module.defs.ts', source.module);
  add('journeys/index.defs.ts', source.journeyIndex);
  source.journeys.forEach(value => add(`journeys/${value.journeyId}.defs.ts`, value));
  add('ontology/index.defs.ts', source.ontologyIndex);
  loadNs5Entities(moduleName).forEach(value => add(`ontology/${value.entityId}.defs.ts`, value));
  add('rules.defs.ts', source.rules);
  add('workflows.defs.ts', source.workflows);
  add('access.defs.ts', source.access);
  add('integration.defs.ts', source.integration);

  (globalThis as any).mls = {
    stor: {
      files,
      getKeyToFile: keyOf,
      addOrUpdateFile: async (info: any) => {
        const key = keyOf(info);
        const file = {
          ...info,
          status: 'new',
          versionRef: '0',
          getContent: async () => contents.get(key) || '',
          getValueInfo: async () => ({ content: contents.get(key) || '' }),
        };
        files[key] = file;
        return file;
      },
      localStor: {
        setContent: async (file: any, value: { content: string }) => {
          const key = keyOf(file);
          contents.set(key, value.content);
          files[key] = file;
          if (file.status !== 'new') file.status = 'changed';
        },
        listFolder: (wantedProject: number, level: number, folder: string) => Object.values(files)
          .filter((file: any) => file.project === wantedProject && file.level === level && (file.folder === folder || file.folder.startsWith(`${folder}/`))),
        deleteFile: async (file: any) => {
          const key = keyOf(file);
          delete files[key];
          contents.delete(key);
        },
      },
    },
    editor: { models: {}, getKeyModel: () => '' },
  };
  return { source, files, contents, keyOf, add };
}

test('p4_81 s4 discard leaves no new journey file behind', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const info = tobeArtifactFileInfo(project, moduleName, 'journeys/newJourney.defs.ts', 'tobe');
  const created = await (globalThis as any).mls.stor.addOrUpdateFile(info);
  await (globalThis as any).mls.stor.localStor.setContent(created, { content: 'export const fixture = {"journeyId":"newJourney"} as const;\n' });
  await discardTobe(project, moduleName);
  assert.equal(Object.values(fixture.files).some((file: any) => file.shortName === 'newJourney'), false);
  assert.equal(fixture.contents.has(fixture.keyOf(info)), false);
});

test('ui_maint_01', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const diskOnly = {
    project,
    level: 4,
    folder: `${moduleName}/tobe/plan`,
    shortName: 'diskOnly',
    extension: '.defs.ts',
    status: 'changed',
  };
  const localStor = (globalThis as any).mls.stor.localStor;
  const previous = localStor.listFolder;
  localStor.listFolder = (wantedProject: number, level: number, folder: string) => {
    const listed = previous(wantedProject, level, folder);
    const inPlan = diskOnly.folder === folder || diskOnly.folder.startsWith(`${folder}/`);
    return wantedProject === project && level === 4 && inPlan ? [...listed, diskOnly] : listed;
  };
  const discarded = await discardTobe(project, moduleName);
  assert.equal(discarded.deleted.some(path => path.includes('diskOnly')), false);
  assert.equal(Object.values(fixture.files).some((file: any) => file.shortName === 'diskOnly'), false);
});

test('runtime overlay saves one artifact, detects stale base, and discards with inventory', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const changed = { ...fixture.source.module, title: 'Prepared title' };
  await saveTobeArtifact(project, moduleName, 'module.defs.ts', changed, {
    jsonPath: '$.title',
    author: 'tester@example.com',
    now: '2026-09-13T01:00:00.000Z',
    expectedRevisionId: null,
  });

  const prepared = await readNs5Overlay(project, moduleName, 'tobe');
  assert.equal(prepared.sources.module.source, 'tobe');
  assert.equal(prepared.sources.module.value?.title, 'Prepared title');
  assert.equal(prepared.manifest?.changes.length, 1);
  assert.deepEqual(prepared.diffs[0]?.entries, [{ jsonPath: '$.title', before: fixture.source.module.title, after: 'Prepared title' }]);
  assert.deepEqual((await readChangeOrigins(project, moduleName)).map(row => ({ source: row.source, changes: row.changes })), [
    { source: 'manual', changes: [{ file: 'module.defs.ts', jsonPath: '$.title' }] },
  ]);

  const asisInfo = tobeArtifactFileInfo(project, moduleName, 'module.defs.ts', 'asis');
  fixture.contents.set(fixture.keyOf(asisInfo), `export const fixture = ${JSON.stringify({ ...fixture.source.module, title: 'Regenerated title' })} as const;`);
  const stale = await readNs5Overlay(project, moduleName, 'tobe');
  assert.deepEqual(stale.stalePaths, ['module.defs.ts']);

  const discarded = await discardTobe(project, moduleName, 'module.defs.ts');
  assert.equal(discarded.manifest, null);
  assert.equal(discarded.deleted.some(path => path.endsWith('/module.defs.ts')), false);
  const restored = await readNs5Overlay(project, moduleName, 'tobe');
  assert.equal(restored.sources.module.source, 'asis');
  assert.equal(restored.sources.module.value?.title, fixture.source.module.title);
  assert.equal(restored.diffs.length, 0);
  assert.deepEqual(await readChangeOrigins(project, moduleName), []);
  assert.ok(Object.values(fixture.files).some((file: any) => String(file.folder).includes('/tobe/plan')));
});

test('Current reads live L4 while preparation and history retain their own source and metadata', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const captured = { ...fixture.source.module, title: 'Captured title', description: 'Captured description' };
  fixture.add('module.defs.ts', captured);
  const snapshot = () => ({
    contents: [...fixture.contents],
    files: Object.entries(fixture.files).map(([key, file]) => [key, { ...file }]),
  });
  const beforePreparation = snapshot();
  const initial = await readNs5Overlay(project, moduleName, 'asis');
  assert.equal(initial.sources.module.value?.title, captured.title);
  assert.deepEqual(snapshot(), beforePreparation);
  const edited = { ...captured, title: 'Prepared title', description: 'Prepared description' };
  const saved = await saveTobeArtifact(project, moduleName, 'module.defs.ts', edited, {
    author: 'tester', expectedRevisionId: null,
  });
  assert.ok(saved.baseId && saved.changeId && saved.revisionId);
  fixture.add('module.defs.ts', { ...captured, title: 'Localizar paciente', description: 'Live description' });
  const beforeCurrentRead = snapshot();
  const current = await readNs5Overlay(project, moduleName, 'asis');
  assert.equal(current.sources.module.value?.title, 'Localizar paciente');
  assert.equal(current.sources.module.value?.description, 'Live description');
  assert.equal(current.sources.module.source, 'asis');
  assert.equal(current.manifest, null);
  assert.equal(current.changeId, null);
  assert.equal(current.revisionId, null);
  assert.equal(current.sealedRevision, null);
  assert.deepEqual(current.stalePaths, []);
  assert.deepEqual(current.diffs, []);
  const currentModule = await readNs5Module(project, moduleName, 'asis');
  assert.equal(currentModule.module?.title, 'Localizar paciente');
  assert.equal(currentModule.baseProvenance, null);
  assert.equal(currentModule.manifest, null);
  assert.equal(currentModule.changeId, null);
  assert.equal(currentModule.revisionId, null);
  assert.equal(currentModule.sealedRevision, null);
  assert.equal(currentModule.tobeChanges, 0);
  assert.deepEqual(currentModule.stalePaths, []);
  assert.deepEqual(currentModule.diffs, []);
  assert.deepEqual(snapshot(), beforeCurrentRead);
  const prepared = await readNs5Overlay(project, moduleName, 'tobe');
  assert.deepEqual(prepared.sources.module.value, edited);
  assert.equal(prepared.manifest?.baseId, saved.baseId);
  assert.equal(prepared.changeId, saved.changeId);
  assert.equal(prepared.revisionId, saved.revisionId);
  assert.deepEqual(prepared.stalePaths, ['module.defs.ts']);
  assert.deepEqual(prepared.diffs[0]?.entries, [
    { jsonPath: '$.description', before: captured.description, after: edited.description },
    { jsonPath: '$.title', before: captured.title, after: edited.title },
  ]);
  const preparedModule = await readNs5Module(project, moduleName, 'tobe');
  const capturedRelease = await readL4Release(project, moduleName, saved.baseId!);
  assert.ok(capturedRelease?.provenance);
  assert.deepEqual(preparedModule.baseProvenance, capturedRelease.provenance);
  assert.deepEqual(preparedModule.module, edited);
  assert.equal(preparedModule.changeId, saved.changeId);
  assert.equal(preparedModule.revisionId, saved.revisionId);
  assert.deepEqual(preparedModule.stalePaths, ['module.defs.ts']);
  const history = await readNs5Overlay(project, moduleName, `release:${saved.baseId}`);
  assert.deepEqual(history.sources.module.value, captured);
  assert.equal(history.manifest, null);
  assert.equal(history.changeId, null);
  assert.equal(history.revisionId, null);
  assert.deepEqual(history.stalePaths, []);
  const historicalModule = await readNs5Module(project, moduleName, `release:${saved.baseId}`);
  assert.deepEqual(historicalModule.module, captured);
  assert.equal(historicalModule.baseProvenance, null);
});

test('runtime full discard clears the preparation and a new edit captures the current L4', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const originals = new Map(fixture.contents);
  const oldModule = { ...fixture.source.module, title: 'Cancelled title' };
  const oldRules = { ...fixture.source.rules, rules: [] };
  const first = await saveTobeArtifact(project, moduleName, 'module.defs.ts', oldModule, { author: 'tester@example.com', expectedRevisionId: null });
  const second = await saveTobeArtifact(project, moduleName, 'rules.defs.ts', oldRules, {
    author: 'tester@example.com', expectedChangeId: first.changeId, expectedRevisionId: first.revisionId ?? null,
  });
  const request = await saveChangeRequest(project, moduleName, 'Cancelled request', second.changeId!, second.revisionId!);
  const oldPreparation = await readNs5Overlay(project, moduleName, 'tobe');
  assert.deepEqual(oldPreparation.sources.module.value, oldModule);
  assert.deepEqual(oldPreparation.sources.rules.value, oldRules);
  assert.equal(oldPreparation.sealedRevision?.request, 'Cancelled request');
  assert.equal(oldPreparation.changeId, first.changeId);
  assert.equal(oldPreparation.revisionId, request.revisionId);
  assert.ok(first.baseId);
  const history = new Map([...fixture.contents].filter(([key]) => key.includes(`${moduleName}/pipeline/releases/${first.baseId}`) || key.includes(`${moduleName}/pipeline/changes/${first.changeId}`)));
  assert.ok(history.size);
  for (const [key, content] of originals) assert.equal(fixture.contents.get(key), content);

  const liveModule = { ...fixture.source.module, title: 'Current title after regeneration', description: 'Current description after regeneration' };
  fixture.add('module.defs.ts', liveModule);
  const liveOriginals = new Map([...fixture.contents].filter(([key]) => originals.has(key)));
  const discarded = await discardTobe(project, moduleName);
  assert.equal(discarded.manifest, null);
  assert.ok(discarded.deleted.some(path => path.endsWith('/module.defs.ts')));
  assert.ok(discarded.deleted.some(path => path.endsWith('/rules.defs.ts')));
  assert.ok(discarded.deleted.some(path => path.endsWith('/tobe.json')));
  assert.equal(Object.values(fixture.files).some((file: any) => String(file.folder).includes('/tobe/plan')), false);
  assert.equal(await readActiveL4Change(project, moduleName), null);
  assert.equal(await readChangeRequest(project, moduleName), null);
  const current = await readNs5Overlay(project, moduleName, 'asis');
  assert.deepEqual(current.sources.module.value, liveModule);
  assert.deepEqual(current.sources.rules.value, fixture.source.rules);
  assert.equal(current.manifest, null);
  assert.equal(current.changeId, null);
  assert.equal(current.revisionId, null);
  for (const [key, content] of liveOriginals) assert.equal(fixture.contents.get(key), content);
  for (const [key, content] of history) assert.equal(fixture.contents.get(key), content);
  assert.deepEqual((await readNs5Overlay(project, moduleName, `release:${first.baseId}`)).sources.module.value, fixture.source.module);

  const newModule = { ...liveModule, description: 'New preparation description' };
  const fresh = await saveTobeArtifact(project, moduleName, 'module.defs.ts', newModule, {
    author: 'tester@example.com', expectedChangeId: null, expectedRevisionId: null, jsonPath: '$.description',
  });
  assert.ok(fresh.changeId && fresh.revisionId && fresh.baseId);
  assert.notEqual(fresh.changeId, first.changeId);
  assert.notEqual(fresh.revisionId, request.revisionId);
  assert.notEqual(fresh.baseId, first.baseId);
  const newPreparation = await readNs5Overlay(project, moduleName, 'tobe');
  assert.deepEqual(newPreparation.sources.module.value, newModule);
  assert.deepEqual(newPreparation.sources.rules.value, fixture.source.rules);
  assert.equal(newPreparation.sealedRevision?.request, '');
  assert.equal((await readChangeRequest(project, moduleName))?.text || '', '');
  assert.deepEqual(newPreparation.manifest?.base, { 'module.defs.ts': await sha256Tobe(liveModule) });
  assert.deepEqual(newPreparation.manifest?.changes.map(change => [change.path, change.jsonPath]), [['module.defs.ts', '$.description']]);
  assert.deepEqual(newPreparation.stalePaths, []);
  assert.deepEqual(newPreparation.diffs.map(diff => [diff.path, diff.entries]), [
    ['module.defs.ts', [{ jsonPath: '$.description', before: liveModule.description, after: newModule.description }]],
  ]);
  assert.deepEqual((await readNs5Overlay(project, moduleName, `release:${fresh.baseId}`)).sources.module.value, liveModule);
  for (const [key, content] of liveOriginals) assert.equal(fixture.contents.get(key), content);
  for (const [key, content] of history) assert.equal(fixture.contents.get(key), content);
});

function plantJson(fixture: { files: Record<string, any>; contents: Map<string, string>; keyOf: (info: any) => string }, info: { project: number; folder: string; shortName: string }, value: unknown) {
  const file = { project: info.project, level: 4, folder: info.folder, shortName: info.shortName, extension: '.json', status: 'unchanged', versionRef: '1' };
  const key = fixture.keyOf(file);
  fixture.contents.set(key, JSON.stringify(value));
  fixture.files[key] = {
    ...file,
    getContent: async () => fixture.contents.get(key) || '',
    getValueInfo: async () => ({ content: fixture.contents.get(key) || '' }),
  };
}

test('p4_83 s3c discard and completed apply remove tobe/candidate and leave the pipeline', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const saved = await saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'Prepared title' }, {
    author: 'tester@example.com', expectedRevisionId: null,
  });
  const candidate = { project, folder: `${moduleName}/tobe/candidate` };
  plantJson(fixture, { ...candidate, shortName: 'pointer' }, { changeId: saved.changeId, revisionId: 'rev-one' });
  plantJson(fixture, { project, folder: `${moduleName}/tobe/candidate/results`, shortName: 'result-one' }, { resultId: 'result-one' });
  plantJson(fixture, { project, folder: `${moduleName}/pipeline/changes`, shortName: 'keep' }, { keep: true });
  const outside = fixture.keyOf({ project, level: 4, folder: `${moduleName}/pipeline/changes`, shortName: 'keep', extension: '.json' });

  const discarded = await discardTobe(project, moduleName);
  assert.ok(discarded.deleted.some(path => path.endsWith('/tobe/candidate/pointer.json')));
  assert.ok(discarded.deleted.some(path => path.endsWith('/tobe/candidate/results/result-one.json')));
  assert.equal(Object.values(fixture.files).some((file: any) => String(file.folder).includes('/tobe/candidate')), false);
  assert.equal(fixture.contents.has(outside), true);

  const again = await saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'Applied title' }, {
    author: 'tester@example.com', expectedRevisionId: null,
  });
  const active = await readActiveL4Change(project, moduleName);
  assert.ok(active && again.changeId);
  plantJson(fixture, { project, folder: `${moduleName}/pipeline/changes/${again.changeId}`, shortName: 'change' }, {
    ...active, activeRevisionId: 'rev-apply', promotedRevisionId: 'rev-apply',
  });
  plantJson(fixture, { project, folder: `${moduleName}/pipeline/changes/${again.changeId}`, shortName: 'implementation' }, {
    revisionId: 'rev-apply',
    merged: { create: [], regenerateDefs: [], remove: [], materialize: [], runAgents: [], abend: [] },
    phases: [],
  });
  plantJson(fixture, { ...candidate, shortName: 'pointer' }, { changeId: again.changeId });
  plantJson(fixture, { project, folder: `${moduleName}/tobe/candidate/results`, shortName: 'result-apply' }, { resultId: 'result-apply' });
  await completeTobeImplementation(project, moduleName, again.changeId, 'rev-apply');
  assert.equal(Object.values(fixture.files).some((file: any) => String(file.folder).includes('/tobe/')), false);
  assert.equal(fixture.contents.has(outside), true);
});

test('base snapshot is complete, byte-stable and separate from the temporary candidate', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  fixture.add('workspace-model.defs.ts', { menu: [{ workspaceId: 'overview', label: 'Overview' }] });
  fixture.add('workspaces/overview.defs.ts', { workspaceId: 'overview', title: 'Overview' });
  const before = new Map(fixture.contents);
  const prepared = await readNs5Overlay(project, moduleName, 'tobe');
  assert.equal(prepared.diffs.length, 0);
  assert.ok(prepared.sources.all.every(item => item.source === 'asis'));
  const change = await readActiveL4Change(project, moduleName);
  assert.ok(change);
  const release = await readL4Release(project, moduleName, change.baseId);
  assert.ok(release);
  assert.equal(Object.keys(release.files).length, prepared.sources.all.length + 2);
  assert.equal(release.schemas['module.defs.ts'], fixture.source.module.schemaVersion);
  assert.equal(release.schemas['journeys/index.defs.ts'], fixture.source.journeyIndex.schemaVersion);
  assert.equal(release.schemas['workspace-model.defs.ts'], null);
  assert.equal(release.schemas['workspaces/overview.defs.ts'], null);
  const folders = resolveL4Folders(project, moduleName, change.baseId, change.changeId, 'rev-test');
  assert.notEqual(folders.originalL4Path, folders.temporaryL4Path);
  for (const [key, source] of before) {
    assert.equal(fixture.contents.get(key), source);
    const parts = key.split(':');
    const baseKey: string = `${project}:4:${parts[2].replace(moduleName, `${moduleName}/pipeline/releases/${change.baseId}/l4`)}:${parts[3]}`;
    const tempKey: string = `${project}:4:${parts[2].replace(moduleName, `${moduleName}/tobe/plan`)}:${parts[3]}`;
    assert.equal(fixture.contents.get(baseKey), source);
    assert.equal(fixture.contents.get(tempKey), source);
  }
  assert.throws(() => resolveL4Folders(project, '../escape', change.baseId), /Invalid module name/);
  assert.throws(() => resolveL4Folders(project, moduleName, '../escape'), /Invalid revision identifier/);
  const manifestKey = `${project}:4:${moduleName}/pipeline/releases/${change.baseId}:manifest.json`;
  const corrupted = JSON.parse(fixture.contents.get(manifestKey) || '{}');
  corrupted.schemas['module.defs.ts'] = 'unsupported-schema';
  fixture.contents.set(manifestKey, JSON.stringify(corrupted));
  assert.equal(await readL4Release(project, moduleName, change.baseId), null);
});

test('revision selection keeps stable release IDs and ignores stale module responses', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const prepared = await readNs5Overlay(project, moduleName, 'tobe');
  const choices = await listReleaseChoices(project, moduleName);
  assert.equal(choices.length, 1);
  const versions = revisionsForKnob(choices);
  assert.deepEqual(versions, ['asis', 'tobe', `release:${choices[0].baseId}`]);
  assert.equal(selectedRevisionIndex(versions, versions[2]), 3);
  assert.equal(selectedRevisionIndex(versions, 'release:removed'), 1);
  assert.equal(historicalReleaseId(versions[2]), choices[0].baseId);
  assert.throws(() => historicalReleaseId('release:../escape'), /Invalid release identifier/);
  assert.equal(contextStillCurrent({ project, moduleName, version: versions[2] }, { project, moduleName: 'other', version: versions[2] }), false);
  assert.equal(contextStillCurrent({ project, moduleName, version: versions[2] }, { project, moduleName, version: 'asis' }), false);
  assert.equal(contextStillCurrent({ project, moduleName, version: versions[2] }, { project, moduleName, version: versions[2] }), true);

  const changed = { ...fixture.source.module, title: 'New candidate' };
  await saveTobeArtifact(project, moduleName, 'module.defs.ts', changed, {
    author: 'tester', expectedChangeId: prepared.changeId, expectedRevisionId: prepared.revisionId,
  });
  const history = await readNs5Overlay(project, moduleName, versions[2]);
  assert.equal(history.sources.module.value?.title, fixture.source.module.title);
  assert.equal(history.changeId, null);
  assert.equal(history.manifest, null);
  await assert.rejects(() => readNs5Overlay(project, moduleName, 'release:missing'), /Historical release is incomplete/);
});

test('unsaved request draft stays with its candidate across a structured-edit reload and never leaks to another module', () => {
  const drafts = new ChangeRequestDrafts();
  const first = ChangeRequestDrafts.key(102047, 'agendaClinica', 'change-1');
  const other = ChangeRequestDrafts.key(102047, 'financeiro', 'change-2');
  drafts.remember(first, 'Draft after editing a rule', 'Previously saved');
  assert.equal(drafts.restore(other, 'Previously saved'), null);
  assert.equal(drafts.restore(first, 'Previously saved'), 'Draft after editing a rule');
  assert.equal(drafts.restore(ChangeRequestDrafts.key(102047, 'agendaClinica', 'change-3'), 'Previously saved'), null);
  assert.equal(drafts.restore(first, 'Another session saved a new request'), null);
  drafts.remember(first, 'Saved now', 'Previously saved');
  drafts.forget(first);
  assert.equal(drafts.restore(first, 'Saved now'), null);
});

test('a draft typed on Current follows only the candidate created by its first structured save', () => {
  const drafts = new ChangeRequestDrafts();
  const current = ChangeRequestDrafts.key(102047, 'agendaClinica', null);
  const candidate = ChangeRequestDrafts.key(102047, 'agendaClinica', 'change-1');
  const otherModule = ChangeRequestDrafts.key(102047, 'financeiro', 'change-1');
  const otherProject = ChangeRequestDrafts.key(102048, 'agendaClinica', 'change-1');
  drafts.remember(current, 'Keep this request while editing a rule', '');
  drafts.move(current, candidate);
  assert.equal(drafts.restore(candidate, ''), 'Keep this request while editing a rule');
  assert.equal(drafts.restore(current, ''), null);
  assert.equal(drafts.restore(otherModule, ''), null);
  assert.equal(drafts.restore(otherProject, ''), null);
});

test('text-only request survives reload, invalidates result, and stale save is rejected', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const first = await saveChangeRequest(project, moduleName, 'Change the welcome text', null, null);
  const textOnly = await readNs5Overlay(project, moduleName, 'tobe');
  assert.equal(textOnly.manifest, null);
  assert.equal(textOnly.sealedRevision?.request, 'Change the welcome text');
  assert.equal(textOnly.sealedRevision?.manifest.changeId, first.changeId);
  assert.equal(textOnly.sealedRevision?.manifest.revisionId, first.revisionId);
  assert.match(textOnly.sealedRevision?.manifest.requestHash || '', /^sha256:[a-f0-9]{64}$/u);
  assert.equal((await readChangeRequest(project, moduleName))?.text, 'Change the welcome text');
  assert.equal((await readChangeRequest(project, moduleName))?.resultCurrent, false);
  assert.equal(fixture.source.module.sourcePrompt, (await readNs5Overlay(project, moduleName, 'asis')).sources.module.value?.sourcePrompt);
  await markL4Result(project, moduleName, first.revisionId);
  assert.equal((await readChangeRequest(project, moduleName))?.resultCurrent, true);
  const second = await saveChangeRequest(project, moduleName, 'Adjust it again', first.changeId, first.revisionId);
  assert.notEqual(second.revisionId, first.revisionId);
  assert.equal((await readChangeRequest(project, moduleName))?.resultCurrent, false);
  await assert.rejects(() => saveChangeRequest(project, moduleName, 'Late write', first.changeId, first.revisionId), /revision conflict/);
});

test('reusing a historical base creates a candidate and never modifies the current source', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const first = await readNs5Overlay(project, moduleName, 'tobe');
  const baseId = (await readActiveL4Change(project, moduleName))!.baseId;
  await discardTobe(project, moduleName);
  const revisionId = await reuseHistoricalRelease(project, moduleName, `release:${baseId}`);
  assert.ok(revisionId);
  assert.notEqual((await readActiveL4Change(project, moduleName))?.changeId, first.changeId);
  assert.equal((await readNs5Overlay(project, moduleName, 'asis')).sources.module.value?.title, fixture.source.module.title);
  assert.equal((await readNs5Overlay(project, moduleName, 'tobe')).sources.module.value?.title, fixture.source.module.title);
  await assert.rejects(() => reuseHistoricalRelease(project, moduleName, `release:${baseId}`), /Discard the active candidate/);
});

test('revisions retain request separately, reject late saves, and keep prior snapshot after a failed write', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const first = await saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'First title' }, {
    author: 'tester@example.com', expectedRevisionId: null,
  });
  assert.ok(first.changeId && first.revisionId && first.baseId);
  const firstRevision = await readL4Revision(project, moduleName, first.changeId, first.revisionId);
  assert.equal(firstRevision?.changedPaths[0], 'module.defs.ts');
  assert.match(firstRevision?.requestHash || '', /^sha256:[a-f0-9]{64}$/u);
  await assert.rejects(() => saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'Late title' }, {
    author: 'tester@example.com', expectedRevisionId: null,
  }), /revision conflict/);
  const request = await sealL4Revision(project, moduleName, first.revisionId, 'Adjust the title');
  const changed = await readActiveL4Change(project, moduleName);
  assert.equal(changed?.requestRevision, 1);
  assert.equal(changed?.sourcePrompt, fixture.source.module.sourcePrompt);
  assert.equal(changed?.resultRevisionId, null);
  assert.equal(request.requestRevision, 1);
  assert.match(request.requestHash || '', /^sha256:[a-f0-9]{64}$/u);
  const requestKey = `${project}:4:${moduleName}/pipeline/changes/${first.changeId}/requests:request-1.json`;
  assert.equal(JSON.parse(fixture.contents.get(requestKey) || '{}').request, 'Adjust the title');
  const sealed = await readSealedL4Candidate(project, moduleName, first.changeId!, request.revisionId);
  assert.equal(sealed?.request, 'Adjust the title');
  assert.deepEqual(sealed?.sources.map(item => item.path), Object.keys(request.files).sort());
  assert.ok(sealed?.sources.every(item => item.source === fixture.contents.get(
    `${project}:4:${moduleName}/pipeline/changes/${first.changeId}/revisions/${request.revisionId}/l4${item.path.includes('/') ? `/${item.path.slice(0, item.path.lastIndexOf('/'))}` : ''}:${item.path.slice(item.path.lastIndexOf('/') + 1).replace('.defs.ts', '')}.defs.ts`,
  )));
  await assert.rejects(() => markL4Result(project, moduleName, first.revisionId!), /result is stale/);
  assert.equal((await markL4Result(project, moduleName, request.revisionId)).resultRevisionId, request.revisionId);
  const originalSet = (globalThis as any).mls.stor.localStor.setContent;
  (globalThis as any).mls.stor.localStor.setContent = async (file: any, value: { content: string }) => {
    if (String(file.folder).includes('/revisions/')) throw new Error('synthetic revision write failure');
    return originalSet(file, value);
  };
  await assert.rejects(() => saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'Failed title' }, {
    author: 'tester@example.com', expectedRevisionId: request.revisionId,
  }), /synthetic revision write failure/);
  assert.ok(await readL4Revision(project, moduleName, first.changeId, first.revisionId));
  assert.equal((await readActiveL4Change(project, moduleName))?.activeRevisionId, request.revisionId);
});

test('sealed migration boundary rejects a tampered request and a legacy manifest without request hash', async t => {
  await t.test('tampered request', async () => {
    const project = 102047;
    const moduleName = 'ordenServicio5';
    const fixture = installStorFixture(project, moduleName);
    const first = await saveTobeArtifact(project, moduleName, 'module.defs.ts', fixture.source.module, {
      author: 'tester@example.com', expectedRevisionId: null,
    });
    const revision = await sealL4Revision(project, moduleName, first.revisionId!, 'Original request');
    const requestKey = `${project}:4:${moduleName}/pipeline/changes/${revision.changeId}/requests:request-${revision.requestRevision}.json`;
    const record = JSON.parse(fixture.contents.get(requestKey) || '{}');
    fixture.contents.set(requestKey, JSON.stringify({ ...record, request: 'Tampered request' }));
    await assert.rejects(
      () => readSealedL4Candidate(project, moduleName, revision.changeId, revision.revisionId),
      (error: unknown) => error instanceof L4SealedCandidateError
        && error.code === 'candidate.request_integrity_failed',
    );
    const overlay = await readNs5Overlay(project, moduleName, 'tobe');
    assert.equal(overlay.sealedRevision, null);
    assert.equal(overlay.changeId, revision.changeId);
    assert.equal(overlay.revisionId, revision.revisionId);
    assert.ok(overlay.sources.module.value);
    assert.ok(overlay.errors.some(error => error.message === 'candidate.request_integrity_failed'));
    assert.equal((await readChangeRequest(project, moduleName))?.text, 'Tampered request');
  });

  await t.test('legacy manifest', async () => {
    const project = 102047;
    const moduleName = 'ordenServicio5';
    const fixture = installStorFixture(project, moduleName);
    const first = await saveTobeArtifact(project, moduleName, 'module.defs.ts', fixture.source.module, {
      author: 'tester@example.com', expectedRevisionId: null,
    });
    const manifestKey = `${project}:4:${moduleName}/pipeline/changes/${first.changeId}/revisions/${first.revisionId}:manifest.json`;
    const manifest = JSON.parse(fixture.contents.get(manifestKey) || '{}');
    delete manifest.requestHash;
    fixture.contents.set(manifestKey, JSON.stringify(manifest));
    assert.ok(await readL4Revision(project, moduleName, first.changeId!, first.revisionId!));
    await assert.rejects(
      () => readSealedL4Candidate(project, moduleName, first.changeId!, first.revisionId!),
      (error: unknown) => error instanceof L4SealedCandidateError
        && error.code === 'candidate.legacy_request_hash_missing',
    );
    const overlay = await readNs5Overlay(project, moduleName, 'tobe');
    assert.equal(overlay.sealedRevision, null);
    assert.equal(overlay.changeId, first.changeId);
    assert.equal(overlay.revisionId, first.revisionId);
    assert.ok(overlay.sources.module.value);
    assert.ok(overlay.errors.some(error => error.message === 'candidate.legacy_request_hash_missing'));
  });
});

test('sealed migration boundary hashes the exact source strings returned after revision verification', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const first = await saveTobeArtifact(project, moduleName, 'module.defs.ts', fixture.source.module, {
    author: 'tester@example.com', expectedRevisionId: null,
  });
  const sourceKey = `${project}:4:${moduleName}/pipeline/changes/${first.changeId}/revisions/${first.revisionId}/l4:module.defs.ts`;
  const file = fixture.files[sourceKey];
  const original = fixture.contents.get(sourceKey) || '';
  let reads = 0;
  file.getValueInfo = async () => ({
    content: ++reads === 1 ? original : original.replace('ordenServicio5', 'tamperedModule'),
  });

  await assert.rejects(
    () => readSealedL4Candidate(project, moduleName, first.changeId!, first.revisionId!),
    (error: unknown) => error instanceof L4SealedCandidateError
      && error.code === 'candidate.source_integrity_failed',
  );
  assert.equal(reads, 2);
});

test('pre-existing partial overlay survives first full-copy preparation', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const changed = { ...fixture.source.module, title: 'Prior draft' };
  const planned = tobeArtifactFileInfo(project, moduleName, 'module.defs.ts', 'tobe');
  const planFile = await (globalThis as any).mls.stor.addOrUpdateFile(planned);
  await (globalThis as any).mls.stor.localStor.setContent(planFile, { content: `export const fixture = ${JSON.stringify(changed)} as const;` });
  const baseHash = await sha256Tobe(fixture.source.module);
  const legacy = recordTobeSave(null, 'module.defs.ts', '$.title', baseHash, 'tester@example.com');
  const manifestInfo = tobeManifestFileInfo(project, moduleName);
  const manifestFile = await (globalThis as any).mls.stor.addOrUpdateFile(manifestInfo);
  await (globalThis as any).mls.stor.localStor.setContent(manifestFile, { content: JSON.stringify(legacy) });
  const prepared = await readNs5Overlay(project, moduleName, 'tobe');
  assert.equal(prepared.sources.module.value?.title, 'Prior draft');
  assert.equal(prepared.sources.module.source, 'tobe');
  assert.equal(prepared.diffs.length, 1);
  assert.ok(prepared.sources.all.slice(1).every(item => item.source === 'asis'));
});

test('stale legacy overlay cannot be promoted to a captured base', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const old = recordTobeSave(null, 'module.defs.ts', '$.title', 'sha256:obsolete', 'tester@example.com');
  const info = tobeManifestFileInfo(project, moduleName);
  const file = await (globalThis as any).mls.stor.addOrUpdateFile(info);
  await (globalThis as any).mls.stor.localStor.setContent(file, { content: JSON.stringify(old) });
  await assert.rejects(() => readNs5Overlay(project, moduleName, 'tobe'), /stale base/);
  assert.equal(Object.values(fixture.files).some((item: any) => String(item.folder).endsWith('/pipeline/releases')), false);
});

test('incomplete release capture never appears in the catalog', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const setContent = (globalThis as any).mls.stor.localStor.setContent;
  (globalThis as any).mls.stor.localStor.setContent = async (file: any, value: { content: string }) => {
    if (String(file.folder).includes('/pipeline/releases/') && file.shortName === 'manifest') throw new Error('synthetic capture failure');
    return setContent(file, value);
  };
  await assert.rejects(() => readNs5Overlay(project, moduleName, 'tobe'), /synthetic capture failure/);
  assert.equal(Object.values(fixture.files).some((file: any) => String(file.folder).endsWith('/pipeline/releases') && file.shortName === 'index'), false);
});

test('concurrent saves with the same expected revision admit only one writer', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const results = await Promise.allSettled([
    saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'Writer A' }, { author: 'tester', expectedRevisionId: null }),
    saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'Writer B' }, { author: 'tester', expectedRevisionId: null }),
  ]);
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 1);
  assert.equal(results.filter(result => result.status === 'rejected' && /revision conflict/.test(String(result.reason))).length, 1);
});

test('a save from an older change cannot enter a new candidate with the same null revision', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const first = await saveTobeArtifact(project, moduleName, 'module.defs.ts', fixture.source.module, {
    author: 'tester', expectedChangeId: null, expectedRevisionId: null,
  });
  await discardTobe(project, moduleName);
  const fresh = await readNs5Overlay(project, moduleName, 'tobe');
  assert.notEqual(fresh.changeId, first.changeId);
  assert.equal(fresh.revisionId, null);
  await assert.rejects(() => saveTobeArtifact(project, moduleName, 'module.defs.ts', fixture.source.module, {
    author: 'tester', expectedChangeId: first.changeId, expectedRevisionId: null,
  }), /L4 change conflict/);
});

test('fixed millisecond clock cannot reuse a change or revision id', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const actualNow = Date.now;
  Date.now = () => 1_780_000_000_000;
  try {
    const initial = await readNs5Overlay(project, moduleName, 'tobe');
    assert.ok(initial.changeId);
    await discardTobe(project, moduleName);
    const next = await readNs5Overlay(project, moduleName, 'tobe');
    assert.ok(next.changeId);
    assert.notEqual(initial.changeId, next.changeId);
    const earlierChangeKey = `${project}:4:${moduleName}/pipeline/changes/${initial.changeId}:change.json`;
    assert.ok(fixture.contents.has(earlierChangeKey));

    const first = await saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'Same tick' }, {
      author: 'tester', expectedChangeId: next.changeId, expectedRevisionId: null,
    });
    const second = await saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'Same tick' }, {
      author: 'tester', expectedChangeId: next.changeId, expectedRevisionId: first.revisionId!,
    });
    assert.notEqual(first.revisionId, second.revisionId);
    assert.ok(await readL4Revision(project, moduleName, next.changeId, first.revisionId!));
    assert.ok(await readL4Revision(project, moduleName, next.changeId, second.revisionId!));
  } finally {
    Date.now = actualNow;
  }
});


test('save rejects a new candidate error before any file or revision is written', async () => {
  const fixture = installStorFixture(102047, 'ordenServicio5');
  const before = [...fixture.contents];
  const keys = Object.keys(fixture.files);
  await assert.rejects(saveTobeArtifact(102047, 'ordenServicio5', 'module.defs.ts', {
    ...fixture.source.module, title: '', description: '',
  }, { expectedRevisionId: null }), (error: unknown) => {
    assert.ok(error instanceof NewReleaseSaveValidationError);
    assert.equal(error.reason, 'invalid');
    assert.ok(error.issues.some(issue => issue.severity === 'error'));
    return true;
  });
  assert.deepEqual([...fixture.contents], before);
  assert.deepEqual(Object.keys(fixture.files), keys);
});

test('save with incomplete validation coverage writes nothing', async () => {
  const fixture = installStorFixture(102047, 'ordenServicio5');
  const info = tobeArtifactFileInfo(102047, 'ordenServicio5', 'integration.defs.ts', 'asis');
  fixture.contents.delete(fixture.keyOf(info));
  delete fixture.files[fixture.keyOf(info)];
  const before = [...fixture.contents];
  const keys = Object.keys(fixture.files);
  await assert.rejects(saveTobeArtifact(102047, 'ordenServicio5', 'module.defs.ts', {
    ...fixture.source.module, title: 'Valid title',
  }, { expectedRevisionId: null }), (error: unknown) => {
    assert.ok(error instanceof NewReleaseSaveValidationError);
    assert.equal(error.reason, 'unavailable');
    return true;
  });
  assert.deepEqual([...fixture.contents], before);
  assert.deepEqual(Object.keys(fixture.files), keys);
});


test('structured values without request bind a valid review preflight without changing sourcePrompt', async () => {
  const project = 102047, moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const saved = await saveTobeArtifact(project, moduleName, 'module.defs.ts', { ...fixture.source.module, title: 'Edited values' },
    { expectedRevisionId: null, author: 'tester' });
  const bound = await bindStructuredEditsRequest(project, moduleName, saved.changeId!, saved.revisionId!, 'Review values already edited.');
  const overlay = await readNs5Overlay(project, moduleName, 'tobe');
  const { canStartReviewRun } = await import('./widgets/reviewModel.js');
  assert.equal(canStartReviewRun({ project, moduleName, changeId: bound.changeId, revisionId: bound.revisionId,
    request: bound.text, userId: 'tester', sealedRevision: overlay.sealedRevision, hasRun: false }), true);
  assert.equal(overlay.sources.module.value?.sourcePrompt, fixture.source.module.sourcePrompt);
  const again = await bindStructuredEditsRequest(project, moduleName, bound.changeId, bound.revisionId, 'Do not replace');
  assert.deepEqual(again, bound);
});

test('accepted application rejects structured saves and requests without writing; cleanup releases the next cycle', async () => {
  const project = 102047, moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const first = await saveChangeRequest(project, moduleName, 'First cycle', null, null);
  const info = { project, level: 4 as const, folder: `${moduleName}/pipeline/changes/${first.changeId}`, shortName: 'implementation', extension: '.json' };
  const { writeJson } = await import('/_102035_/l2/solution/fs.js');
  await writeJson(info, { changeId: first.changeId, revisionId: first.revisionId, acceptedAt: 'now', phases: [] });
  const before = [...fixture.contents.entries()];
  await assert.rejects(saveTobeArtifact(project, moduleName, 'module.defs.ts', fixture.source.module,
    { expectedRevisionId: first.revisionId, expectedChangeId: first.changeId }), /application_active/);
  await assert.rejects(saveChangeRequest(project, moduleName, 'Forbidden', first.changeId, first.revisionId), /application_active/);
  assert.deepEqual([...fixture.contents.entries()], before);
  const { deactivateL4Change } = await import('/_102035_/l2/solution/candidate/moduleRevision.js');
  await deactivateL4Change(project, moduleName);
  const next = await saveChangeRequest(project, moduleName, 'Second cycle', null, null);
  assert.notEqual(next.changeId, first.changeId);
});


test('direct languages preserve published and candidate business edits, reseal and leave history intact', async () => {
  const project = 102047, moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const initial = await readNs5Overlay(project, moduleName, 'tobe');
  const first = await sealL4Revision(project, moduleName, initial.revisionId);
  const original = await readL4Release(project, moduleName, first.baseId);
  const candidate = { ...fixture.source.module, title: 'Business draft' };
  const { editL4Candidate } = await import('/_102035_/l2/solution/candidate/moduleRevision.js');
  const { writeDefs } = await import('/_102035_/l2/solution/fs.js');
  const edited = await editL4Candidate(project, moduleName, first.revisionId, first.changeId, async () => {
    await writeDefs(tobeArtifactFileInfo(project, moduleName, 'module.defs.ts', 'tobe'), 'fixture', candidate, 'Ns5ModuleArtifact');
  });
  const revisionId = await saveDirectLanguageMetadata(project, moduleName, { productLanguages: ['en', 'fr'], defaultLanguage: 'fr' },
    { changeId: first.changeId, revisionId: edited.revision.revisionId });
  assert.notEqual(revisionId, edited.revision.revisionId);
  const published = await readDefsJson<any>(tobeArtifactFileInfo(project, moduleName, 'module.defs.ts', 'asis'));
  assert.equal(published.title, fixture.source.module.title);
  assert.deepEqual(published.productLanguages, ['en', 'fr']);
  const overlay = await readNs5Overlay(project, moduleName, 'tobe');
  assert.equal(overlay.sources.module.value?.title, 'Business draft');
  assert.equal(overlay.sources.module.value?.defaultLanguage, 'fr');
  assert.deepEqual(overlay.diffs.find(diff => diff.path === 'module.defs.ts')?.entries.map(entry => entry.jsonPath), ['$.title']);
  assert.deepEqual(await readL4Release(project, moduleName, first.baseId), original);
  assert.ok(await readSealedL4Candidate(project, moduleName, first.changeId, edited.revision.revisionId));
});

test('direct default-only metadata creates no candidate and invokes no producer; command deltas are scoped', async () => {
  const project = 102047, moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const target = { ...fixture.source.module, productLanguages: ['en', 'fr'], defaultLanguage: 'en' };
  fixture.add('module.defs.ts', target);
  let calls = 0;
  await applyDirectLanguages(project, moduleName, { ...target, defaultLanguage: 'fr' }, { changeId: null, revisionId: null }, () => {}, async () => { calls++; throw new Error('unexpected'); });
  assert.equal(calls, 0);
  assert.equal(await readActiveL4Change(project, moduleName), null);
  assert.deepEqual(languageCommands(project, moduleName, ['en', 'pt'], ['en', 'fr']).map(command => [command.agent, JSON.parse(command.payload)[0].languages.map((item: any) => item.code)]), [['agentAddLanguage', ['fr']], ['agentRemoveLanguage', ['pt']]]);
});

test('failed language producer is retained for retry without sending completed work again', async () => {
  const project = 102047, moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  fixture.add('module.defs.ts', { ...fixture.source.module, productLanguages: ['en', 'pt'], defaultLanguage: 'en' });
  const target = { ...fixture.source.module, productLanguages: ['en', 'fr'], defaultLanguage: 'en' };
  const commands: string[] = [];
  const execute = async (agent: string) => {
    commands.push(agent);
    return { task: { status: agent === 'agentRemoveLanguage' ? 'failed' : 'done', last_update_log: 'Producer failed' } as any, results: [] };
  };
  await assert.rejects(applyDirectLanguages(project, moduleName, target, { changeId: null, revisionId: null }, () => {}, execute), /Producer failed/);
  await applyDirectLanguages(project, moduleName, target, { changeId: null, revisionId: null }, () => {}, async agent => {
    commands.push(agent); return { task: { status: 'done' } as any, results: [] };
  });
  assert.deepEqual(commands, ['agentAddLanguage', 'agentRemoveLanguage', 'agentRemoveLanguage']);
  assert.equal((await readNs5Overlay(project, moduleName)).diffs.length, 0);
});


test('p4_81 s3 version 1 does not list a journey that exists only in tobe', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  const onlyTobe = tobeArtifactFileInfo(project, moduleName, 'journeys/soNoTobe.defs.ts', 'tobe');
  const source = 'export const fixture = {"journeyId":"soNoTobe"} as const;\n';
  fixture.files[fixture.keyOf(onlyTobe)] = {
    ...onlyTobe, status: 'unchanged',
    getContent: async () => source,
    getValueInfo: async () => ({ content: source }),
  };
  const indexInfo = tobeArtifactFileInfo(project, moduleName, 'journeys/index.defs.ts', 'asis');
  delete fixture.files[fixture.keyOf(indexInfo)];
  fixture.contents.delete(fixture.keyOf(indexInfo));
  const asis = await readNs5Overlay(project, moduleName, 'asis');
  assert.equal(asis.sources.journeys.some(item => item.path === 'journeys/soNoTobe.defs.ts'), false);
});

test('p4_81 s3 O que mudou shows an added journey and a removed one', async () => {
  const project = 102047;
  const moduleName = 'ordenServicio5';
  const fixture = installStorFixture(project, moduleName);
  await readNs5Overlay(project, moduleName, 'tobe');
  const kept = fixture.source.journeys[0];
  const removed = fixture.source.journeys[1];
  assert.ok(kept && removed);
  const index = {
    ...fixture.source.journeyIndex,
    journeys: [
      ...fixture.source.journeyIndex.journeys.filter(item => item.journeyId !== removed.journeyId),
      { ...fixture.source.journeyIndex.journeys[0], journeyId: 'soNoTobe', title: 'Nova' },
    ],
  };
  const journey = { ...kept, journeyId: 'soNoTobe', title: 'Nova' };
  const { writeDefs } = await import('/_102035_/l2/solution/fs.js');
  await writeDefs(tobeArtifactFileInfo(project, moduleName, 'journeys/index.defs.ts', 'tobe'), 'fixture', index, 'Ns5JourneyIndexArtifact');
  await writeDefs(tobeArtifactFileInfo(project, moduleName, 'journeys/soNoTobe.defs.ts', 'tobe'), 'fixture', journey, 'Ns5JourneyArtifact');
  const overlay = await readNs5Overlay(project, moduleName, 'tobe');
  const added = overlay.diffs.find(diff => diff.path === 'journeys/soNoTobe.defs.ts');
  assert.ok(added);
  assert.equal(added.entries.some(entry => entry.before !== undefined), false);
  assert.ok(added.entries.some(entry => entry.after !== undefined));
  const gone = overlay.diffs.find(diff => diff.path === `journeys/${removed.journeyId}.defs.ts`);
  assert.ok(gone);
  assert.ok(gone.entries.some(entry => entry.before !== undefined && entry.after === undefined));
  const version1 = await readNs5Overlay(project, moduleName, 'asis');
  assert.equal(version1.sources.journeys.some(item => item.path === 'journeys/soNoTobe.defs.ts'), false);
});

test('language-only change with an existing candidate leaves no review diff', async () => {
  const project = 102047, moduleName = 'ordenServicio5';
  installStorFixture(project, moduleName);
  const initial = await readNs5Overlay(project, moduleName, 'tobe');
  const revisionId = await saveDirectLanguageMetadata(project, moduleName, { productLanguages: ['en', 'fr'], defaultLanguage: 'fr' },
    { changeId: initial.changeId, revisionId: initial.revisionId });
  const overlay = await readNs5Overlay(project, moduleName, 'tobe');
  assert.equal(overlay.revisionId, revisionId);
  assert.equal(overlay.sources.module.source, 'asis');
  assert.deepEqual(overlay.diffs, []);
  assert.deepEqual(overlay.stalePaths, []);
});
