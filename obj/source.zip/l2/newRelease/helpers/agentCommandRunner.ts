/// <mls fileReference="_102035_/l2/newRelease/helpers/agentCommandRunner.ts" enhancement="_blank" />
import { environment } from '/_102036_/l2/environmentContract.js';
import { msgGetTaskUpdate } from '/_102036_/l2/shared/api.js';
import { getTemporaryContext, ensureUserId } from '/_102025_/l2/collabMessagesHelper.js';
import type { AIPayload, TaskData } from '/_102036_/l2/shared/interfaces.js';
import type { ImplementationRunnerDependencies } from '/_102035_/l2/newRelease/helpers/implementationRunner.js';
import { moduleThreadMemberRefusal, resolveModuleThread, type ModuleThreadRef } from '/_102035_/l2/newRelease/helpers/moduleThread.js';

/** Canonical result/clarification payloads, including nested agent interactions. */
export function taskResultTexts(task: TaskData): string[] {
  const output: string[] = [];
  function visit(steps: AIPayload[]) {
    for (const step of steps) {
      if (step.type === 'result') output.push(step.result);
      if (step.type === 'clarification') output.push(step.json || step.stepTitle || '');
      visit(step.nextSteps || []);
      visit(step.interaction?.payload || []);
    }
  }
  visit(task.iaCompressed?.nextSteps || []);
  return [...new Set(output)];
}

/** Sum only costs reported by completed task interactions. */
export function newReleaseTaskCost(task: TaskData): number | null {
  let total = 0;
  let found = false;
  function visit(steps: AIPayload[]) {
    for (const step of steps) {
      const cost = step.interaction?.cost;
      if (typeof cost === 'number' && Number.isFinite(cost)) { total += cost; found = true; }
      visit(step.nextSteps || []);
      visit(step.interaction?.payload || []);
    }
  }
  visit(task.iaCompressed?.nextSteps || []);
  return found ? total : null;
}

export interface NewReleaseRequestFileState {
  path: string;
  state: 'added' | 'changed' | 'removed';
}

export interface NewReleaseRequestSummary {
  fileStates?: NewReleaseRequestFileState[];
  summary?: string;
  assumptions?: string[];
  key: string;
  values: { reason?: string; question?: string; count?: number };
  retry: boolean;
}

/** Decode producer outcomes; indexes, proposals and successful intermediate gates stay out of the main flow. */
export function summarizeNewReleaseRequest(results: readonly string[], status: TaskData['status']): NewReleaseRequestSummary {
  let question = '';
  let refusal = '';
  let written: number | null = null;
  let fileStates: NewReleaseRequestFileState[] = [];
  let producerSummary = '';
  for (const result of results) {
    let value: unknown;
    try { value = JSON.parse(result); }
    catch {
      if (status === 'paused') question = result;
      else if (result.trim()) refusal = result;
      continue;
    }
    if (!value || typeof value !== 'object' || Array.isArray(value)) continue;
    const outcome = value as { written?: unknown; reason?: unknown; files?: unknown; fileStates?: unknown; summary?: unknown; triage?: { valid?: unknown; clarification?: unknown; reason?: unknown; assumptions?: unknown }; question?: unknown };
    if (typeof outcome.summary === 'string' && outcome.summary.trim()) producerSummary = outcome.summary.trim();
    if (typeof outcome.question === 'string') question = outcome.question;
    if (outcome.triage?.valid === false) {
      if (typeof outcome.triage.clarification === 'string') question = outcome.triage.clarification;
      if (typeof outcome.triage.reason === 'string') refusal = outcome.triage.reason;
    }
    if (outcome.written === false) {
      refusal = typeof outcome.reason === 'string' ? outcome.reason : '';
    }
    if (outcome.written === true) {
      written = Array.isArray(outcome.files) ? outcome.files.length : 0;
      fileStates = Array.isArray(outcome.fileStates) ? outcome.fileStates.filter((item): item is NewReleaseRequestFileState =>
        !!item && typeof item === 'object' && typeof item.path === 'string'
        && ['added', 'changed', 'removed'].includes(item.state)) : [];
    }
  }
  const display = separateAssumptions(producerSummary);
  const summary = display.summary ? { summary: display.summary } : {};
  if (question) return { key: 'request.question', values: { question }, retry: true, ...summary };
  if (refusal) return { key: 'request.refused', values: { reason: refusal }, retry: true, ...summary };
  if (status === 'failed') return { key: 'request.failed', values: {}, retry: true, ...summary };
  if (written !== null) return { key: 'request.success', values: { count: written }, retry: false,
    ...(fileStates.length ? { fileStates } : {}), ...(display.assumptions.length ? { assumptions: display.assumptions } : {}), ...summary };
  return { key: 'request.noResult', values: {}, retry: true, ...summary };
}

function separateAssumptions(summary: string): { summary: string; assumptions: string[] } {
  // The final write summary also includes access choices added after triage.
  const line = summary.split('\n').find(value => /^(?:Assumi|Assumed): /u.test(value));
  // The triage assumptions are predictions made before the edit; only what the producer says after editing is shown.
  if (!line) return { summary, assumptions: [] };
  return {
    summary: summary.split('\n').filter(value => value !== line).join('\n'),
    assumptions: line.slice(line.indexOf(': ') + 2).split('; ').map(value => value.trim()).filter(Boolean),
  };
}

export interface NewReleasePromptRequest { moduleName: string; request: string }

type CommandDependencies = ImplementationRunnerDependencies & {
  wait?: () => Promise<void>;
  project?: number;
  moduleThread?: (project: number, moduleName: string) => Promise<ModuleThreadRef>;
};

function commandTarget(agent: string, payload: string, projectOverride?: number): { project: number; moduleName: string } {
  const parsed: unknown = JSON.parse(payload);
  if (agent === 'agentNewReleasePrompt') {
    const body = parsed as { moduleName?: unknown };
    if (!body || typeof body !== 'object' || typeof body.moduleName !== 'string' || !body.moduleName) {
      throw new Error('new-release.thread_invalid:moduleName');
    }
    return { project: projectOverride ?? Number(mls.actualProject || 0), moduleName: body.moduleName };
  }
  const row = (Array.isArray(parsed) ? parsed[0] : parsed) as { projectId?: unknown; moduleName?: unknown } | null;
  if (!row || typeof row.moduleName !== 'string' || !row.moduleName) throw new Error('new-release.thread_invalid:moduleName');
  const project = typeof row.projectId === 'number' ? row.projectId : projectOverride ?? 0;
  return { project, moduleName: row.moduleName };
}

export async function runNewReleaseRequest(moduleName: string, request: string,
  progress: (task: TaskData) => void, dependencies: CommandDependencies = {}): Promise<{ task: TaskData; results: string[] }> {
  if (!request.trim()) throw new Error('new-release.request_empty');
  const payload: NewReleasePromptRequest = { moduleName, request };
  return runNewReleaseCommand('agentNewReleasePrompt', JSON.stringify(payload), progress, dependencies);
}

export async function runNewReleaseCommand(agent: 'agentNewReleasePrompt' | 'agentAddLanguage' | 'agentRemoveLanguage', payload: string,
  progress: (task: TaskData) => void, dependencies: CommandDependencies = {}): Promise<{ task: TaskData; results: string[] }> {
  const user = await (dependencies.userId ?? ensureUserId)();
  if (!user) throw new Error('implementation.user_unavailable');
  let resolved: { threadId: string } | undefined;
  if (dependencies.thread) resolved = await dependencies.thread();
  else {
    const target = commandTarget(agent, payload, dependencies.project);
    resolved = await (dependencies.moduleThread ?? resolveModuleThread)(target.project, target.moduleName);
  }
  if (!resolved?.threadId) throw new Error('implementation.thread_unavailable');
  const prompt = '@@' + agent + ' ' + payload;
  const context = (dependencies.context ?? getTemporaryContext)(resolved.threadId, user, prompt);
  try {
    await (dependencies.execute ?? ((agentName, ctx) => environment.agents.executeAgent(agentName, ctx)))(agent, context);
  } catch (error) {
    const reason = moduleThreadMemberRefusal(error);
    if (reason) throw new Error(`new-release.thread_forbidden:${reason}`);
    throw error;
  }
  if (!context.task?.PK) throw new Error('implementation.task_unavailable');
  let task = context.task;
  const identity = task.PK;
  const id = identity.replace(/^task(?:\/#?|#)/u, '');
  const messageId = task.messageid_created || `${context.message.threadId}/${context.message.orderAt || context.message.createAt}`;
  for (;;) {
    if (task.PK !== identity) throw new Error('implementation.task_mismatch');
    progress(task);
    if (['done', 'failed', 'paused'].includes(task.status)) return { task, results: taskResultTexts(task) };
    await (dependencies.wait ?? (() => new Promise<void>(resolve => setTimeout(resolve, 1500))))();
    task = await (dependencies.task ?? (async (userId, taskId, messageId) => {
      const read = await msgGetTaskUpdate({ userId, taskId, messageId });
      if (!read.success || !read.response?.task) throw new Error(read.error || 'implementation.task_unavailable');
      return read.response.task;
    }))(user, id, messageId);
  }
}
