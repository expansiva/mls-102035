import test from 'node:test';
import assert from 'node:assert/strict';
import type { InitialReviewDependencies } from './review.js';
import type { InitialImplementationPlan, L4ImplementationRecord } from '../../solution/candidate/moduleImplementation.js';
import type { L4SealedCandidateSnapshot, L4ChangeRecord, L4ReleaseManifest } from '../../solution/candidate/moduleRevision.js';

const documentStub = globalThis.document as Document & Record<string, unknown>;
documentStub.createTreeWalker = (() => ({ nextNode: () => null, currentNode: null })) as never;
documentStub.createElement = ((tag: string) => ({ tagName: tag.toUpperCase(), textContent: '' })) as never;
documentStub.createComment = (() => ({})) as never;
documentStub.head = { querySelector: () => null, appendChild: () => undefined } as never;
(globalThis as unknown as { window: typeof globalThis }).window = globalThis;
if (!globalThis.customElements) (globalThis as unknown as { customElements: unknown }).customElements = { define() {}, get() {} };
if (!globalThis.HTMLElement) (globalThis as unknown as { HTMLElement: unknown }).HTMLElement = class extends EventTarget {};
const storage = new Map<string, string>([['serviceCollabMessages', JSON.stringify({ userId: 'reviewer' })]]);
(globalThis as unknown as { localStorage: unknown }).localStorage = { getItem: (key: string) => storage.get(key) ?? null, setItem: (key: string, value: string) => storage.set(key, value), removeItem: (key: string) => storage.delete(key) };

const loader = require('node:module') as { _load: (request: string, ...args: unknown[]) => any };
const previousLoad = loader._load;
let reviewModule: typeof import('./review.ts');
try {
  loader._load = function (request, ...args) {
    if (request === '/_102020_/l2/aura/helpers/draftModuleDiscard.js') return { discardModuleInStudio: async () => { throw new Error('Unexpected real discard'); } };
    if (request === 'lit/decorators.js') return { customElement: () => () => undefined,
      property: () => () => undefined, state: () => () => undefined, query: () => () => undefined };
    return previousLoad.call(this, request, ...args);
  };
  reviewModule = require('./review.ts');
} finally { loader._load = previousLoad; }
const { applyInitialReview, reviewInitialCandidate, NewReleaseReview102035 } = reviewModule;
const { implementationCommands } = require('../../solution/candidate/moduleImplementation.ts') as typeof import('../../solution/candidate/moduleImplementation.ts');
const { L4_REVISION_SCHEMA } = require('../../solution/candidate/moduleRevision.ts') as typeof import('../../solution/candidate/moduleRevision.ts');

function setup(edited = false, fresh = true) {
  const calls: string[] = [];
  const project = 102035;
  const moduleName = 'fixture';
  const changeId = 'change1';
  const baseId = 'base1';
  const plan: InitialImplementationPlan = { project, moduleName, fresh, hashes: {
    'pool/l2/web/menu.json': 'menu-hash', 'pool/l1/web/needs.json': 'needs-hash', 'pool/l2/web/backend.json': 'backend-hash', 'pool/l2/web/effort.json': 'effort-hash',
  }, pipelines: { l1: 'l1-hash', l2: 'l2-hash' }, l4Hashes: { 'module.defs.ts': 'source-hash' } };
  const manifest = { schemaVersion: L4_REVISION_SCHEMA, project, moduleName, changeId, baseId,
    revisionId: 'rev1', createdAt: '', files: plan.l4Hashes, changedPaths: edited ? ['module.defs.ts'] : [], requestRevision: edited ? 1 : 0, requestHash: 'request-hash' };
  const sealed: L4SealedCandidateSnapshot = { manifest, request: edited ? 'saved structured edits' : '', sources: [] };
  const change: L4ChangeRecord = { schemaVersion: L4_REVISION_SCHEMA, project, moduleName, changeId, baseId,
    activeRevisionId: edited ? 'before-seal' : null, resultRevisionId: null, requestRevision: edited ? 1 : 0, sourcePrompt: '', updatedAt: '' };
  const release: L4ReleaseManifest = { schemaVersion: L4_REVISION_SCHEMA, project, moduleName, baseId,
    createdAt: '', files: plan.l4Hashes, schemas: {}, provenance: { status: 'unverified', label: '' } };
  let accepted: L4ImplementationRecord | undefined;
  const dependencies: InitialReviewDependencies = {
    plan: async () => { calls.push('plan'); return plan; },
    prepare: async () => { calls.push('prepare'); return { change, release, created: !edited }; },
    seal: async (_project, _module, expected) => { calls.push('seal'); assert.equal(expected, change.activeRevisionId); return manifest; },
    readSealed: async () => { calls.push('readSealed'); return sealed; },
    review: async (snapshot, userId) => { calls.push('review'); assert.equal(userId, 'reviewer'); return { ...snapshot, manifest: { ...snapshot.manifest, revisionId: 'reviewed' } }; },
    sealLayers: async () => { calls.push('layers'); return { schemaVersion: '2026-10-08-module-layers-v1', project, moduleName, baseId, createdAt: '', files: [] }; },
    promote: async (_project, _module, expectedChange, revisionId) => { calls.push('promote'); assert.equal(expectedChange, changeId); assert.equal(revisionId, edited ? 'reviewed' : 'rev1'); return { ...change, activeRevisionId: revisionId, promotedRevisionId: revisionId }; },
    accept: async (_project, _module, input) => {
      calls.push('accept'); assert.equal(input.kind, 'initial');
      if (input.kind !== 'initial') throw new Error('Expected initial acceptance');
      assert.deepEqual(input.plan, plan);
      accepted = { schemaVersion: '2026-10-08-nr-module-implementation-v1', changeId, revisionId: input.revisionId, acceptedBy: input.acceptedBy, acceptedAt: '',
        hashes: { plans: plan.hashes }, merged: { create: [], regenerateDefs: [], materialize: [], remove: [], runAgents: [], abend: [] },
        initial: { plan, replan: edited || !fresh, promotedAt: '' }, phases: [] };
      return accepted;
    },
  };
  return { calls, plan, change, sealed, dependencies, input: { project, moduleName, acceptedBy: 'reviewer', changeId: edited ? changeId : null, revisionId: edited ? 'before-seal' : null }, accepted: () => accepted };
}

for (const edited of [false, true]) test(`mr41 s3c Apply ${edited ? 'edited' : 'neutral'} creates and accepts initial revision in order`, async () => {
  const f = setup(edited);
  const record = await applyInitialReview(f.input, f.dependencies);
  assert.deepEqual(f.calls, ['plan', 'prepare', 'seal', 'readSealed', ...(edited ? ['review'] : []), 'layers', 'promote', 'accept']);
  assert.equal(record.revisionId, edited ? 'reviewed' : 'rev1');
  assert.equal(record.initial?.replan, edited);
  assert.equal(implementationCommands(record, 102035, 'fixture')[0].agent, edited ? 'agentPlannerL4' : 'agentDefsL2');
  assert.ok(implementationCommands(record, 102035, 'fixture').every(ref => !ref.command.includes('/candidate') && !ref.agent.startsWith('agentNewRelease')));
});

test('mr41 s3c old planning reaches acceptance with the original stale snapshot', async () => {
  const f = setup(false, false);
  const record = await applyInitialReview(f.input, f.dependencies);
  assert.equal(record.initial?.plan.fresh, false);
  assert.equal(implementationCommands(record, 102035, 'fixture')[0].command, '@@agentPlannerL4 fixture');
  assert.ok(!f.calls.includes('review'));
});

test('mr41 s3c refused reviewer stops before promotion and acceptance', async () => {
  const f = setup(true);
  f.dependencies.review = async () => { f.calls.push('review'); throw new Error('refused: invalid edit'); };
  await assert.rejects(applyInitialReview(f.input, f.dependencies), /refused/);
  assert.deepEqual(f.calls, ['plan', 'prepare', 'seal', 'readSealed', 'review']);
});

test('mr41 s3c changed active revision or changed screen context stops Apply', async () => {
  const f = setup();
  f.dependencies.current = () => f.calls.length < 2;
  await assert.rejects(applyInitialReview(f.input, f.dependencies), /implementation_conflict/);
  assert.ok(!f.calls.includes('promote'));
  const other = setup(true);
  other.input.revisionId = 'other';
  await assert.rejects(applyInitialReview(other.input, other.dependencies), /implementation_conflict/);
  assert.deepEqual(other.calls, ['plan', 'prepare']);
});

function widget() {
  const element = new NewReleaseReview102035();
  const review = element as unknown as Record<string, any>;
  review.project = 102035; review.moduleName = 'fixture'; review.version = 'asis';
  review.loading = false; review.hasRelease = false; review.initialPlan = setup().plan;
  review.data = { pipeline: { status: 'complete' }, validation: { ok: true }, diffs: [], changeId: null, revisionId: null };
  review.loadedFor = { project: review.project, moduleName: review.moduleName, version: review.version, data: review.data };
  review.t = (key: string) => key;
  return review;
}
function templateText(value: any): string {
  if (value?.strings) return value.strings.reduce((text: string, part: string, index: number) => text + part + templateText(value.values[index]), '');
  return Array.isArray(value) ? value.map(templateText).join('') : typeof value === 'string' ? value : '';
}

test('Copy review failure includes code, task, thread and run in full', async () => {
  const { createNewReleaseTranslator, loadNewReleaseMessages } = await import('../helpers/i18n.js');
  const review = widget();
  review.version = 'tobe';
  review.t = createNewReleaseTranslator(await loadNewReleaseMessages(102035, 'pt'));
  review.channelRun = {
    runId: 'review-550', status: 'failed', attempt: 1, errorCode: 'review-worker.candidate_result_missing',
    binding: { changeId: 'change-1', inputRevisionId: 'rev-1', requestRevision: 2 },
    executions: [{ taskId: 'task-20261103173810', threadId: 'thread-20261102193705', provider: 'openai', model: 'test-model', resultRunId: null }],
  };
  const view = templateText(review.renderReviewRun());
  assert.match(view, /Copiar/);
  const copied: string[] = [];
  const prior = Object.getOwnPropertyDescriptor(navigator, 'clipboard');
  Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: async (value: string) => { copied.push(value); } } });
  try {
    await review.copyReviewRun(review.channelRun);
    const report = JSON.parse(copied[0].split('\n').slice(1).join('\n'));
    assert.equal(report.errorCode, 'review-worker.candidate_result_missing');
    assert.equal(report.runId, 'review-550');
    assert.equal(report.taskId, 'task-20261103173810');
    assert.equal(report.threadId, 'thread-20261102193705');
    assert.equal(report.inputRevisionId, 'rev-1');
    assert.match(templateText(review.renderReviewRun()), /Copiado/);
  } finally {
    if (prior) Object.defineProperty(navigator, 'clipboard', prior);
    else delete (navigator as { clipboard?: unknown }).clipboard;
  }
});

test('mr41 s3c new planned module without active change enables Apply and keeps Calculate visible', () => {
  const review = widget();
  const action = review.actionPresentation(review.view(), true);
  assert.equal(action.kind, 'continue'); assert.equal(action.disabled, false);
  assert.equal(action.labelKey, 'review.implementation.accept');
  const output = templateText(review.render());
  assert.match(output, /review\.panels\.apply/);
  assert.match(output, /review\.calculate/);
  review.version = 'release:old';
  assert.notEqual(review.actionPresentation(review.view(), true).labelKey, 'review.implementation.accept');
});

test('mr41 s3c completed initial implementation shows unchanged with generated L2', async () => {
  const f = setup();
  const record = await applyInitialReview(f.input, f.dependencies);
  record.phases = implementationCommands(record, 102035, 'fixture').map((ref, index) => ({ ...ref, name: `runAgents:${index}`, attempt: 1, taskId: String(index), threadId: 'thread', messageId: 'message', status: 'done', startedAt: '' }));
  const review = widget();
  review.version = 'tobe'; review.hasRelease = true; review.implementation = record;
  review.data = { ...review.data, changeId: record.changeId, revisionId: record.revisionId };
  review.loadedFor = { project: review.project, moduleName: review.moduleName, version: review.version, data: review.data };
  assert.equal(review.implementationComplete(), true);
  assert.match(templateText(review.render()), /review\.release\.unchanged/);
});


test('mr41 s3c exact Apply click emits tobe only after persisting initial acceptance', async () => {
  const f = setup();
  const record = await applyInitialReview(f.input, f.dependencies);
  const review = widget();
  Object.defineProperty(review, 'isConnected', { value: true });
  let accepts = 0;
  review.initialApply = async (input: unknown) => { accepts++; assert.deepEqual(input, f.input); return record; };
  const previousDispatch = window.dispatchEvent;
  const events: CustomEvent[] = [];
  window.dispatchEvent = ((event: CustomEvent) => {
    if (event.type === 'nr-tobe-updated') assert.equal(review.implementation, record);
    events.push(event); return true;
  }) as typeof window.dispatchEvent;
  try {
    await review.runReviewPrimaryAction();
    assert.equal(accepts, 1);
    assert.deepEqual(events[0].detail, { project: 102035, moduleName: 'fixture', active: true });
    assert.equal(events[0].type, 'nr-implementation-state');
    assert.deepEqual(events[1].detail, { project: 102035, moduleName: 'fixture', version: 'tobe' });
    assert.equal(events[1].type, 'nr-tobe-updated');
    assert.equal(review.initialPlan, null);
    await review.runReviewPrimaryAction();
    assert.equal(accepts, 1);
    // The context owner now supplies tobe data. The persisted record is pending for load() to resume.
    review.version = 'tobe'; review.data = { ...review.data, changeId: record.changeId, revisionId: record.revisionId };
    assert.equal(review.implementationPending(), true);
  } finally { window.dispatchEvent = previousDispatch; }
});

test('the initial review runs on the thread of the module, by project and module name', async () => {
  const f = setup(true);
  const asked: Array<[number, string]> = [];
  await assert.rejects(reviewInitialCandidate(f.sealed, 'reviewer', {
    prepare: async () => ({ input: {} as never, userId: 'reviewer' }),
    moduleThread: async (project, moduleName) => { asked.push([project, moduleName]); return { threadId: 'module-thread' }; },
    context: (threadId, senderId, content) => ({ message: { threadId, senderId, content } } as never),
    execute: async () => { throw new Error('stop here'); },
  }), /stop here/);
  assert.deepEqual(asked, [[f.sealed.manifest.project, f.sealed.manifest.moduleName]]);
});

for (const reason of ['refused: invalid revision', 'failed: invalid revision']) {
  test(`mr41 s3c reviewer terminal done with ${reason.split(':')[0]} is rejected before reading output`, async () => {
    const f = setup(true);
    const commands: string[] = [];
    await assert.rejects(reviewInitialCandidate(f.sealed, 'reviewer', {
      prepare: async () => ({ input: {} as never, userId: 'reviewer' }),
      thread: async () => ({ threadId: 'thread' }),
      context: (threadId, senderId, content) => ({ message: { threadId, senderId, content } } as never),
      execute: async (agent, context) => {
        assert.equal(agent, 'agentReviewSolution');
        commands.push(context.message.content);
        context.task = { PK: 'task/reviewer', status: 'in progress' } as never;
      },
      wait: async () => undefined,
      task: async () => ({ PK: 'task/reviewer', status: 'done' }) as never,
      message: async () => ({ taskResults: [reason] }) as never,
    }), { message: reason });
    assert.equal(commands.length, 1);
    assert.ok(!commands[0].includes('/candidate'));
    assert.match(commands[0], /expectedRevisionId/);
  });
}


test('mr41 s3c initial reviewer uses authoritative result with input pointer and real sealed pipeline gate', async () => {
  const { buildCandidateSnapshot } = require('../../solution/candidate/candidateGateway.ts') as typeof import('../../solution/candidate/candidateGateway.ts');
  const { readCandidateWorkerGate } = require('../helpers/candidateWorkerGate.ts') as typeof import('../helpers/candidateWorkerGate.ts');
  const f = setup(true);
  const suffix = '2b9774db38c20e91680bb38a671c1588';
  const outputId = `review-${suffix}`;
  const sources = (['module.defs.ts', 'journeys/index.defs.ts', 'ontology/index.defs.ts', 'rules.defs.ts', 'workflows.defs.ts', 'access.defs.ts', 'integration.defs.ts'] as const).map(path => ({ path, source: `export const fixture = '${path}';` }));
  const outputSnapshot = await buildCandidateSnapshot({ baseId: 'base1', requestRevision: 1, request: f.sealed.request, sources });
  const output = { ...f.sealed, sources, manifest: { ...f.sealed.manifest, revisionId: outputId,
    files: Object.fromEntries(outputSnapshot.files.map(file => [file.path, `sha256:${file.sha256}`])) } };
  const revision = { changeId: 'change1', revisionId: outputId, baseId: 'base1', manifestHash: outputSnapshot.hash };
  const seal = { schemaVersion: '2026-09-22-agent-review-planner-seal-v1', flowId: 'agentReviewSolution', moduleName: 'fixture', revision };
  const traceHash = Buffer.from(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(seal)))).toString('hex');
  const pipeline = { schemaVersion: '2026-09-22-agent-review-planner-pipeline-v1', flowId: 'agentReviewSolution', moduleName: 'fixture', status: 'complete', revision, reviewSeal: seal, reviewSealHash: traceHash };
  let adopted = 0;
  let resultStatus: 'completed' | 'failed' = 'completed';
  let published = false;
  const dependencies: import('./review.js').InitialSealDependencies = {
    prepare: async () => ({ input: { userId: 'reviewer', project: 102035, moduleName: 'fixture', changeId: 'change1', inputRevisionId: 'rev1', inputRevisionNumber: 1, inputSnapshotHash: 'sha256:input', baseId: 'base1', requestRevision: 1, requestHash: 'sha256:request', request: f.sealed.request }, userId: 'reviewer' }),
    thread: async () => ({ threadId: 'thread' }),
    context: (threadId, senderId, content) => ({ message: { threadId, senderId, content } } as never),
    execute: async (_agent, context) => { context.task = { PK: 'task/reviewer', status: 'done' } as never; },
    message: async () => ({ taskResults: ['review complete'] }) as never,
    candidate: async () => ({ status: 'read', pointer: published ? { changeId: 'change1', revisionId: outputId, snapshotHash: outputSnapshot.hash, revisionNumber: 2, source: { resultId: 'result1', resultHash: 'result-hash', revisionId: 'rev1', snapshotHash: 'input', revisionNumber: 1 } } : { changeId: 'change1', revisionId: 'rev1', snapshotHash: 'input', revisionNumber: 1 }, snapshot: outputSnapshot,
      result: { resultRevisionId: 'rev1', resultSnapshotHash: 'input', resultRevisionNumber: 1, resultId: 'result1', resultHash: 'result-hash', manifest: { runId: `result-${suffix}`, taskId: `task-${suffix}`, status: resultStatus, outputSnapshotHash: outputSnapshot.hash, artifacts: [], traceHash } } }),
    gate: async run => readCandidateWorkerGate(run, { readSourceText: async () => JSON.stringify(pipeline), readSealedL4Candidate: async () => output }),
    readSealed: async (_project, _module, _change, revisionId) => { assert.equal(revisionId, outputId); return output; },
    adopt: async (_project, _module, input) => { assert.deepEqual(input, { inputRevisionId: 'rev1', outputRevisionId: outputId }); adopted++; return { ...f.change, activeRevisionId: outputId, resultRevisionId: outputId }; },
    active: async () => ({ ...f.change, activeRevisionId: outputId, resultRevisionId: outputId }),
  };
  assert.equal((await reviewInitialCandidate(f.sealed, 'reviewer', dependencies)).manifest.revisionId, outputId);
  assert.equal(adopted, 1);
  published = true;
  assert.equal((await reviewInitialCandidate(f.sealed, 'reviewer', dependencies)).manifest.revisionId, outputId);
  assert.equal(adopted, 2);
  resultStatus = 'failed';
  await assert.rejects(reviewInitialCandidate(f.sealed, 'reviewer', dependencies), /implementation_conflict/);
  assert.equal(adopted, 2);
  resultStatus = 'completed';
  pipeline.status = 'failed';
  await assert.rejects(reviewInitialCandidate(f.sealed, 'reviewer', dependencies), /implementation_not_ready/);
  assert.equal(adopted, 2);
  pipeline.status = 'complete'; pipeline.reviewSealHash = 'foreign';
  await assert.rejects(reviewInitialCandidate(f.sealed, 'reviewer', dependencies), /implementation_not_ready/);
  assert.equal(adopted, 2);
});


test('mr41 s3c reloading after L2 generation keeps initial lifecycle until L1 materialization finishes', async () => {
  const f = setup();
  const record = await applyInitialReview(f.input, f.dependencies);
  record.phases = implementationCommands(record, 102035, 'fixture').slice(0, -1).map((ref, index) => ({ ...ref, name: `runAgents:${index}`, attempt: 1, taskId: String(index), threadId: 'thread', messageId: 'message', status: 'done', startedAt: '' }));
  const review = widget();
  review.version = 'tobe'; review.hasRelease = true; review.implementation = record;
  review.data = { ...review.data, changeId: record.changeId, revisionId: record.revisionId };
  review.loadedFor = { project: review.project, moduleName: review.moduleName, version: review.version, data: review.data };
  assert.equal(review.implementationComplete(), false);
  assert.equal(review.implementationPending(), true);
  assert.match(templateText(review.render()), /review\.release\.new/);
  assert.doesNotMatch(templateText(review.render()), /review\.release\.unchanged/);
});


test('mr41 s3c maintenance result retains blocked reason and maintenance handler without generated source fixture', async () => {
  const { mergeChangeEffort } = require('../../solution/gates/changeEffort/gate.ts') as typeof import('../../solution/gates/changeEffort/gate.ts');
  const golden = structuredClone(require('./fixtures/changeEffort-agendaClinica-regra-anotacao.json'));
  const blocked = structuredClone(golden);
  blocked.status = 'blocked';
  blocked.perItem[0].answers[0].status = 'abend';
  blocked.perItem[0].answers[0].abend = { reason: 'master unavailable' };
  blocked.merged = mergeChangeEffort(blocked.perItem);
  const review = widget();
  review.version = 'tobe'; review.data.resultCurrent = true; review.effortCurrent = true;
  review.changeEffortRead = { status: 'ok', path: 'effort', value: blocked };
  review.canImplement = () => false;
  assert.equal(review.actionPresentation(review.view(), true).descriptionKey, 'review.effort.status.blocked');
  let maintenance = 0;
  review.changeEffortRead = { status: 'ok', path: 'effort', value: golden };
  review.canImplement = () => true;
  review.acceptImplementation = async () => { maintenance++; };
  review.acceptInitialImplementation = async () => { assert.fail('Maintenance must retain its own handler'); };
  review.loadedFor = { project: review.project, moduleName: review.moduleName, version: review.version, data: review.data };
  await review.runReviewPrimaryAction();
  assert.equal(maintenance, 1);
});

test('mr41 s3c reviewer seal alone remains initial without maintenance effort', () => {
  const review = widget();
  review.version = 'tobe'; review.data.resultCurrent = true;
  review.changeEffortRead = { status: 'missing', path: 'effort' };
  assert.equal(review.actionPresentation(review.view(), true).descriptionKey, 'review.panels.fullGenerationBody');
});

test('review effort keeps coverage and backend without the actor menu', () => {
  const review = widget();
  review.hasRelease = true;
  review.renderChangeEffort = () => '';
  review.renderMenu = () => { throw new Error('actor menu must not render in review'); };
  review.renderBackend = () => 'backend remains';
  const ready = { kind: 'ready', status: 'simple', items: [], merged: null, untouched: null, errorCode: '' };
  review.effortRead = { status: 'missing', path: 'pool' };
  assert.equal(templateText(review.renderEffort(ready)), '');
  assert.match(templateText(review.renderEffortPanel({}, ready, true, [])), /review\.effort\.status\.simple/);
  assert.match(templateText(review.renderEffortPanel({}, ready, true, [])), /backend remains/);
  review.effortRead = { status: 'invalid', path: 'pool' };
  assert.match(templateText(review.renderEffort(ready)), /review\.backend\.effortInvalid/);
  assert.match(templateText(review.renderEffortPanel({}, ready, true, [])), /review\.backend\.effortInvalid/);
});

test('recalculating effort hides the previous summary and shows the active phase', () => {
  const review = widget();
  review.version = 'tobe'; review.hasRelease = true;
  review.data = { ...review.data, resultCurrent: true, changeId: 'change1', revisionId: 'rev1' };
  review.loadedFor = { project: review.project, moduleName: review.moduleName, version: review.version, data: review.data };
  review.effortRead = { status: 'ok', path: 'old', value: { screens: [{ name: 'OLD_EFFORT' }] } };
  review.effortRefreshPending = true;
  review.channelRun = { status: 'planning', runId: 'run1', executions: [], binding: {}, attempt: 2 };
  const output = templateText(review.render());
  assert.match(output, /review\.run\.phase\.planning/);
  assert.match(output, /<progress/);
  assert.ok(output.indexOf('</details>') < output.indexOf('class="nr-review__progress"'));
  assert.doesNotMatch(output, /OLD_EFFORT/);
});

test('Apply embeds the live task card, follows updates and replaces a retried task', () => {
  const review = widget();
  review.version = 'tobe'; review.hasRelease = true;
  const record: L4ImplementationRecord = { schemaVersion: '2026-10-08-nr-module-implementation-v1', changeId: 'change1', revisionId: 'rev1', acceptedBy: 'reviewer', acceptedAt: '', hashes: { changeEffort: 'hash' },
    merged: { create: [], regenerateDefs: [], materialize: [], remove: [], runAgents: [{ agent: 'agentAddLanguage', command: '@@agentAddLanguage []' }], abend: [] },
    phases: [{ name: 'runAgents:0', agent: 'agentAddLanguage', command: '@@agentAddLanguage []', attempt: 1,
      taskId: 'task1', threadId: 'thread1', messageId: 'thread1/message', status: 'running', startedAt: '' }] };
  review.implementation = record;
  review.data = { ...review.data, changeId: record.changeId, revisionId: record.revisionId };
  review.loadedFor = { project: review.project, moduleName: review.moduleName, version: review.version, data: review.data };
  const task = { PK: 'task1', status: 'in progress', last_updated: 1,
    iaCompressed: { nextSteps: [{ interaction: { cost: 0.08, payload: [] }, nextSteps: [] }] } };
  review.implementationTasks = { 'runAgents:0': task };
  review.implementationTaskChanges = { 'runAgents:0': 1 };
  const running = templateText(review.render());
  assert.match(running, /<collab-messages-task-102025/);
  assert.doesNotMatch(running, /nr-review__task-link/);
  assert.match(running, /<progress/);
  const card = review.renderImplementationTask('runAgents:0');
  assert.equal(card.values.find((value: any) => value?.task)?.task, task);
  const firstChanged = card.values.find((value: any) => value === 'task1:1');
  task.last_updated = 2;
  task.iaCompressed.nextSteps[0].interaction.cost = 0.12;
  review.implementationTaskChanges['runAgents:0'] = 2;
  const updated = review.renderImplementationTask('runAgents:0');
  assert.equal(updated.values.find((value: any) => value?.task)?.task, task);
  assert.equal(updated.values.find((value: any) => value === 'task1:2'), 'task1:2');
  assert.notEqual(firstChanged, 'task1:2');
  assert.equal(updated.values.find((value: any) => value?.task)?.task.iaCompressed.nextSteps[0].interaction.cost, 0.12);
  const previousDispatch = window.dispatchEvent;
  const events: CustomEvent[] = [];
  window.dispatchEvent = ((event: CustomEvent) => { events.push(event); return true; }) as typeof window.dispatchEvent;
  try { (updated.values.find((value: any) => typeof value === 'function') as () => void)(); }
  finally { window.dispatchEvent = previousDispatch; }
  assert.equal(events[0].type, 'thread-open');
  assert.deepEqual(events[0].detail, { threadId: 'thread1', taskId: 'task1' });
  record.phases[0].taskId = 'task2';
  assert.match(templateText(review.renderImplementationTask('runAgents:0')), /review\.implementation\.taskLoading/);
  review.implementationTasks = { 'runAgents:0': { ...task, PK: 'task2' } };
  assert.match(templateText(review.renderImplementationTask('runAgents:0')), /<collab-messages-task-102025/);
  record.phases[0].status = 'done';
  const complete = templateText(review.render());
  assert.match(complete, /review\.implementation\.completedBody/);
  assert.doesNotMatch(complete.slice(complete.indexOf('nr-review__implementation')), /<progress/);
});

test('task card waits for persisted snapshots and keeps the newest one after reload', async () => {
  const review = widget();
  let releaseFirst!: () => void;
  const firstWrite = new Promise<void>(resolve => { releaseFirst = resolve; });
  const persisted: string[] = [];
  const store = async (task: { PK: string; status: string }) => {
    persisted.push(`${task.PK}:${task.status}`);
    if (task.status === 'in progress') await firstWrite;
  };
  const running = { PK: '20261103185746.1001', status: 'in progress', last_updated: 1 };
  const done = { ...running, status: 'done', last_updated: 2 };
  const first = review.rememberImplementationTask('runAgents:0', running, review.loadToken, store);
  const second = review.rememberImplementationTask('runAgents:0', done, review.loadToken, store);
  await Promise.resolve();
  assert.equal(review.implementationTasks['runAgents:0'], undefined);
  releaseFirst();
  await Promise.all([first, second]);
  assert.deepEqual(persisted, [`${running.PK}:in progress`, `${running.PK}:done`]);
  assert.equal(review.implementationTasks['runAgents:0'], done);
});

for (const language of ['en', 'pt']) test(`menu closing receipt is localized in ${language} without changing other report lines`, async () => {
  const { createNewReleaseTranslator, loadNewReleaseMessages } = await import('../helpers/i18n.js');
  const review = widget();
  review.t = createNewReleaseTranslator(await loadNewReleaseMessages(102035, language));
  const notes = [
    ['removed', 'removed'], ['kept: absent', 'absent'],
    ['kept: finalize70 not approved', 'notApproved'], ['kept: l1 incomplete', 'incomplete'],
    ['kept: delete left the file', 'deleteFailed'], ['kept: EACCES: /pool/menu.json', 'technicalError'],
  ];
  for (const [note, key] of notes) {
    const body = 'Agent result\r\nmenu.json removed\r\nOther evidence';
    const report = `${body}\r\nmenu.json ${note}\r\n`;
    const translated = review.t(`review.implementation.menu.${key}`, { reason: 'EACCES: /pool/menu.json' });
    assert.equal(review.implementationReport(report), `${body}\r\n${translated}\r\n`);
    for (const complete of [false, true]) {
      const f = setup();
      const record = await applyInitialReview(f.input, f.dependencies);
      record.phases = [{ name: 'runAgents:0', agent: 'agentDefsL2', command: '', attempt: 1, taskId: '1', threadId: 'thread', messageId: 'message', status: 'done', startedAt: '', report }];
      review.implementation = record;
      review.hasImplementation = () => true;
      review.implementationComplete = () => complete;
      const output = templateText(review.renderImplementation('top'));
      assert.ok(output.includes(`${body}\r\n${translated}\r\n`));
      assert.equal(record.phases[0].report, report);
    }
  }
  for (const report of ['plain report', 'menu.json kept: absent\nmore evidence', 'prefix menu.json removed', '']) {
    assert.equal(review.implementationReport(report), report);
  }
});


test('task polling backs off, pauses manual checks, resumes on updates and resets by task', () => {
  const observe = reviewModule.observeImplementationTask;
  const now = 1800000000000;
  let polling = observe(null, 'task1', now, 'in progress', '', now);
  const intervals = [polling.interval];
  for (let index = 0; index < 6; index++) {
    polling = observe(polling, 'task1', now, 'in progress', '', now + index * 30000);
    intervals.push(polling.interval);
  }
  assert.deepEqual(intervals, [1500, 3000, 6000, 12000, 24000, 30000, 30000]);
  polling = observe(polling, 'task1', now, 'in progress', '', now + 600000);
  assert.equal(polling.paused, true);
  polling = observe(polling, 'task1', now, 'in progress', '', now + 610000);
  assert.equal(polling.paused, true);
  polling = observe(polling, 'task1', now + 610000, 'in progress', '', now + 610000);
  assert.equal(polling.paused, false);
  assert.equal(polling.interval, 1500);
  assert.equal(observe(polling, 'task1', now, 'done', '', now + 620000).paused, false);
  polling = observe(polling, 'task2', now + 620000, 'in progress', '', now + 620000);
  assert.equal(polling.taskId, 'task2');
  assert.equal(polling.interval, 1500);
  assert.equal(polling.paused, false);
  assert.equal(observe(null, 'old', now - 3600000, 'in progress', '', now).paused, true);
  assert.equal(observe(null, 'invalid', NaN, 'in progress', new Date(now - 600000).toISOString(), now).paused, true);
  const fallback = observe(null, 'invalid', 0, 'in progress', '', now);
  assert.equal(observe(fallback, 'invalid', 0, 'in progress', '', now + 600000).paused, true);
});


test('Apply stops timers after a stale snapshot, manual check stays single and done closes', async () => {
  const review = widget();
  const now = Date.now();
  let snapshotTime = now - 3600000;
  let done = false;
  let calls = 0;
  let finalized = 0;
  const timers: number[] = [];
  review.implementationContextCurrent = () => true;
  review.implementationPending = () => !done;
  review.implementationComplete = () => done;
  review.finalizeImplementation = async () => { finalized++; };
  review.data = { changeId: 'change1' };
  review.implementationRunner = { runNext: async () => {
    calls++;
    review.implementationPolling = reviewModule.observeImplementationTask(review.implementationPolling,
      'task1', snapshotTime, done ? 'done' : 'in progress', '', now);
    return { changeId: 'change1' };
  } };
  const setTimer = window.setTimeout;
  const clearTimer = window.clearTimeout;
  window.setTimeout = ((_callback: () => void, delay: number) => { timers.push(delay); return 1; }) as typeof window.setTimeout;
  window.clearTimeout = (() => undefined) as typeof window.clearTimeout;
  try {
    await review.advanceImplementation();
    assert.equal(calls, 1);
    assert.deepEqual(timers, []);
    review.hasImplementation = () => true;
    review.implementation = { merged: { materialize: [] }, phases: [] };
    review.implementationComplete = () => false;
    const panel = review.renderImplementation('top');
    assert.match(templateText(panel), /review.implementation.pollingPaused/);
    assert.match(templateText(panel), /review.implementation.checkNow/);
    const manual = panel.values.flatMap((value: any) => value?.values ?? []).find((value: any) => typeof value === 'function');
    assert.equal(typeof manual, 'function');
    await manual();
    assert.equal(calls, 2);
    assert.deepEqual(timers, []);
    snapshotTime = now;
    await manual();
    assert.equal(calls, 3);
    assert.deepEqual(timers, [1500]);
    done = true;
    let pendingChecks = 0;
    review.implementationPending = () => ++pendingChecks === 1;
    review.implementationComplete = () => done;
    await review.advanceImplementation();
    assert.equal(finalized, 1);
    assert.deepEqual(timers, [1500]);
  } finally {
    window.setTimeout = setTimer;
    window.clearTimeout = clearTimer;
  }
});

function failedImplementationWidget() {
  const review = widget();
  review.version = 'tobe';
  const f = setup();
  review.implementation = {
    changeId: 'change1', revisionId: 'rev1',
    initial: { plan: f.plan, replan: false },
    merged: { create: [], regenerateDefs: [], materialize: [], remove: [], runAgents: [], abend: [] },
    phases: [{ name: 'runAgents:0', status: 'failed', attempt: 1, error: 'refused: broken page' }],
  };
  review.data = { ...review.data, changeId: 'change1', revisionId: 'rev1' };
  review.loadedFor = { project: review.project, moduleName: review.moduleName, version: review.version, data: review.data };
  return review;
}

function discardClick(review: Record<string, any>): () => Promise<void> {
  function find(value: any): (() => Promise<void>) | undefined {
    if (value?.strings) {
      if (value.strings.join('').includes('@click=') && value.values.some((item: unknown) => item === 'review.implementation.discardModule')) {
        return value.values.find((item: unknown) => typeof item === 'function');
      }
      for (const item of value.values) { const found = find(item); if (found) return found; }
    }
    if (Array.isArray(value)) for (const item of value) { const found = find(item); if (found) return found; }
    return undefined;
  }
  const click = find(review.renderImplementation('top'));
  assert.ok(click, 'failed phase renders the discard button with its handler');
  return click;
}

test('mr51 failed phase discard button confirms, calls Studio once and reloads the published context', async () => {
  const review = failedImplementationWidget();
  const record = review.implementation;
  const calls: unknown[] = [];
  let finish!: () => void;
  const pending = new Promise<void>(resolve => { finish = resolve; });
  review.discardModule = async (...args: unknown[]) => { calls.push(args); await pending; };
  const prior = window.confirm;
  window.confirm = text => { calls.push(text); return true; };
  const onReload = (event: Event) => { calls.push((event as CustomEvent).detail); };
  const previousDispatch = window.dispatchEvent;
  window.dispatchEvent = event => { if (event.type === 'nr-tobe-updated') onReload(event); return true; };
  try {
    assert.match(templateText(review.renderImplementation('top')), /refused: broken page/);
    const click = discardClick(review);
    const running = click();
    assert.equal(review.discardBusy, true);
    await click();
    assert.deepEqual(calls, ['review.implementation.discardConfirm', [102035, 'fixture']]);
    finish(); await running;
    assert.deepEqual(calls.at(-1), { project: 102035, moduleName: 'fixture', version: 'asis' });
    assert.equal(review.discardBusy, false);
    assert.equal(review.implementation, record, 'the in-memory implementation is unchanged before the context owner handles the reload');
    review.implementation.phases[0].status = 'done';
    assert.doesNotMatch(templateText(review.renderImplementation('top')), /review.implementation.discardModule/);
  } finally { window.confirm = prior; window.dispatchEvent = previousDispatch; }
});

test('mr51 canceled or failed Studio discard never announces success and preserves the phase error', async () => {
  const review = failedImplementationWidget();
  const prior = window.confirm;
  const events: Event[] = [];
  const onReload = (event: Event) => { events.push(event); };
  const previousDispatch = window.dispatchEvent;
  window.dispatchEvent = event => { if (event.type === 'nr-tobe-updated') onReload(event); return true; };
  let calls = 0;
  review.discardModule = async () => { calls++; throw new Error('draft.not_owner'); };
  try {
    window.confirm = () => false;
    await discardClick(review)();
    assert.equal(calls, 0);
    window.confirm = () => true;
    const { createNewReleaseTranslator, loadNewReleaseMessages } = await import('../helpers/i18n.js');
    review.t = createNewReleaseTranslator(await loadNewReleaseMessages(102035, 'pt'));
    await review.discardFailedModule();
    assert.equal(calls, 1);
    assert.equal(events.length, 0);
    assert.equal(review.discardBusy, false);
    assert.match(templateText(review.renderImplementation('top')), /Você não é o dono deste rascunho/);
    assert.match(templateText(review.renderImplementation('top')), /refused: broken page/);
    assert.equal(review.implementationRestored, false);
  } finally { window.confirm = prior; window.dispatchEvent = previousDispatch; }
});

test('mr51 completed discard announces its captured module even after switching version', async () => {
  const review = failedImplementationWidget();
  const prior = window.confirm;
  const previousDispatch = window.dispatchEvent;
  const events: Event[] = [];
  window.confirm = () => true;
  window.dispatchEvent = event => { events.push(event); return true; };
  review.discardModule = async () => { review.version = 'release:old'; };
  try {
    await review.discardFailedModule();
    assert.equal(events.length, 1);
    assert.deepEqual((events[0] as CustomEvent).detail, { project: 102035, moduleName: 'fixture', version: 'asis' });
    assert.equal(review.discardBusy, false);
  } finally { window.confirm = prior; window.dispatchEvent = previousDispatch; }
});

test('mr51 loading another context clears its previous discard error', async () => {
  const review = failedImplementationWidget();
  review.discardError = 'previous discard failure';
  review.moduleName = '';
  await review.load();
  assert.equal(review.discardError, '');
});

test('mr51 a pending discard disables and rejects phase retry', async () => {
  const review = failedImplementationWidget();
  Object.defineProperty(review, 'isConnected', { value: true });
  review.implementation.phases[0].podeTentarDeNovo = true;
  let retries = 0;
  review.implementationRunner = { retryPhase: async () => { retries++; throw new Error('Unexpected retry'); } };
  let finish!: () => void;
  const pending = new Promise<void>(resolve => { finish = resolve; });
  review.discardModule = async () => pending;
  const prior = window.confirm;
  const previousDispatch = window.dispatchEvent;
  window.confirm = () => true;
  window.dispatchEvent = () => true;
  function retryDisabled(value: any): boolean | undefined {
    if (value?.strings) {
      if (value.strings.some((part: string) => part.includes('nr-review__implementation-retry'))) return value.values[0];
      for (const item of value.values) { const found = retryDisabled(item); if (found !== undefined) return found; }
    }
    if (Array.isArray(value)) for (const item of value) { const found = retryDisabled(item); if (found !== undefined) return found; }
    return undefined;
  }
  try {
    assert.equal(retryDisabled(review.renderImplementation('top')), false);
    const discarding = review.discardFailedModule();
    assert.equal(review.discardBusy, true);
    assert.equal(retryDisabled(review.renderImplementation('top')), true);
    await review.advanceImplementation(review.loadToken, 'runAgents:0');
    await review.runImplementation(review.loadToken, 'runAgents:0');
    assert.equal(retries, 0);
    assert.equal(review.implementationFlight, null);
    finish(); await discarding;
  } finally { finish(); window.confirm = prior; window.dispatchEvent = previousDispatch; }
});
