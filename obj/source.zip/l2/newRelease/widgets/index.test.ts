import test from 'node:test';
import assert from 'node:assert/strict';

const documentStub = globalThis.document as Document & Record<string, unknown>;
documentStub.createTreeWalker = (() => ({ nextNode: () => null, currentNode: null })) as never;
documentStub.createElement = ((tag: string) => ({ tagName: tag.toUpperCase(), textContent: '' })) as never;
documentStub.createComment = (() => ({})) as never;
documentStub.head = { querySelector: () => null, appendChild: () => undefined } as never;
(globalThis as unknown as { window: typeof globalThis }).window = globalThis;
if (!globalThis.customElements) (globalThis as unknown as { customElements: unknown }).customElements = { define() {}, get() {} };
if (!globalThis.HTMLElement) (globalThis as unknown as { HTMLElement: unknown }).HTMLElement = class extends EventTarget {};

const loader = require('node:module') as { _load: (request: string, ...args: unknown[]) => any };
const previousLoad = loader._load;
let indexModule: typeof import('./index.ts');
try {
  loader._load = function (request, ...args) {
    if (request === 'lit/decorators.js') return { customElement: () => () => undefined,
      property: () => () => undefined, state: () => () => undefined, query: () => () => undefined };
    return previousLoad.call(this, request, ...args);
  };
  indexModule = require('./index.ts');
} finally { loader._load = previousLoad; }

function templateText(value: any): string {
  if (value?.strings) return value.strings.reduce((text: string, part: string, index: number) => text + part + templateText(value.values[index]), '');
  return Array.isArray(value) ? value.map(templateText).join('') : typeof value === 'string' ? value : '';
}

test('change request controls do not submit empty text and clear prior-tab feedback', async () => {
  const index = new indexModule.NewReleaseIndex102035() as unknown as Record<string, any>;
  index.activeTab = 'journeys';
  index.savedRequest = '';
  index.requestText = '';
  assert.match(templateText(index.renderRequest()), /request\.unsaved/);
  index.savedRequest = 'Pedido anterior';
  index.requestText = '   ';
  assert.equal(index.canSubmitRequest(), false);
  index.requestText = 'Pedido anterior';
  assert.equal(index.canSubmitRequest(), false);
  index.requestText = 'Novo pedido';
  assert.equal(index.canSubmitRequest(), true);
  index.requestText = '   ';
  index.requestNeedsRetry = true;
  assert.equal(index.canSubmitRequest(), false);

  index.requestResult = 'Arquivos gravados';
  index.requestFileStates = [{ path: 'rules.defs.ts', state: 'changed' }];
  index.requestError = 'Erro anterior';
  index.requestFeedbackTab = 'journeys';
  index.canLeaveTab = () => true;
  index.activeEditor = () => null;
  await index.activateTab('rules');
  assert.equal(index.requestResult, '');
  assert.deepEqual(index.requestFileStates, []);
  assert.equal(index.requestError, '');
  assert.equal(index.requestFeedbackTab, null);
  index.requestResult = 'Resultado tardio da jornada';
  index.requestError = 'Erro tardio da jornada';
  assert.doesNotMatch(templateText(index.renderRequest()), /tardio da jornada/);
});


test('review counts new warnings and keeps previous observations in closed details', async () => {
  const { createNewReleaseTranslator, loadNewReleaseMessages } = await import('../helpers/i18n.ts');
  for (const [language, title, warnings, errors] of [
    ['en', 'Previous observations: 1', '1 warnings', '1 errors'],
    ['pt', 'Observações anteriores: 1', '1 avisos', '1 erros'],
  ]) {
    const index = new indexModule.NewReleaseIndex102035() as unknown as Record<string, any>;
    index.t = createNewReleaseTranslator(await loadNewReleaseMessages(102035, language));
    index.activeTab = 'review';
    index.version = 'tobe';
    index.data = {
      changeId: 'candidate', manifest: { changes: [], author: 'User', updatedAt: '2026-10-31T12:00:00Z' }, stalePaths: [],
      validation: { issues: [
        { severity: 'warning', artifact: 'workflows.json', path: '$.room', message: 'Previous message', baseline: true },
        { severity: 'warning', artifact: 'journeys.json', path: '$.steps', message: 'New message' },
        { severity: 'error', artifact: 'ontology.json', path: '$', message: 'Error message', baseline: true },
      ] },
    };
    const status = templateText(index.renderTobeStatus());
    assert.ok(status.includes(warnings), status);
    assert.ok(status.includes(errors), status);
    assert.ok(status.includes(`<span>${title}</span>`), status);
    const log = templateText(index.renderValidationLog());
    const [main, previous] = log.split('<details');
    assert.match(main, /New message/);
    assert.match(main, /Error message/);
    assert.doesNotMatch(main, /Previous message/);
    assert.ok(previous.includes(`<summary>${title}</summary>`));
    assert.match(previous, /workflows.json · \$\.room/);
    assert.match(previous, /Previous message/);
    assert.doesNotMatch(previous, /\bopen(?:=|\s|>)/);
    assert.doesNotMatch(previous, /is-warning/);
    index.data.validation.issues = [index.data.validation.issues[0]];
    assert.doesNotMatch(templateText(index.renderValidationLog()), /No warnings|Nenhum aviso/);
    index.data.validation.issues = [];
    assert.doesNotMatch(templateText(index.renderValidationLog()), /<details/);
  }
});
