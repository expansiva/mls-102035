/// <mls fileReference="_102035_/l2/newRelease/widgets/index.ts" enhancement="_102027_/l2/enhancementLit" />
import { ensureUserId } from '/_102025_/l2/collabMessagesHelper.js';
import { applyDirectLanguages, hasPendingLanguages } from '/_102035_/l2/newRelease/helpers/directLanguages.js';
import type { Ns5ModuleArtifact } from '/_102035_/l2/solution/types.js';
import { summarizeNewReleaseRequest, runNewReleaseRequest, type NewReleaseRequestFileState } from '/_102035_/l2/newRelease/helpers/agentCommandRunner.js';

import { html, nothing, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import {
  NEW_RELEASE_CONTEXT_EVENT,
  NEW_RELEASE_TOBE_UPDATED_EVENT,
  historicalReleaseId,
  type NewReleaseContext,
  type NewReleaseVersion,
} from '/_102035_/l2/newRelease/helpers/context.js';
import {
  readNs5Module,
  type NewReleaseModuleData,
} from '/_102035_/l2/newRelease/helpers/l4Reader.js';
import {
  createNewReleaseTranslator,
  loadNewReleaseMessages,
  observeNewReleaseLanguage,
  type NewReleaseTranslate,
} from '/_102035_/l2/newRelease/helpers/i18n.js';
import { sealL4Revision, readChangeRequest, readActiveL4Change } from '/_102035_/l2/solution/candidate/moduleRevision.js';
import { bindStructuredEditsRequest, ChangeRequestDrafts, contextStillCurrent, reuseHistoricalRelease, saveChangeRequest } from '/_102035_/l2/newRelease/helpers/revisionSelection.js';
import { discardTobe, saveTobeArtifact, NewReleaseSaveValidationError } from '/_102035_/l2/newRelease/tobe.js';
import { visibleDiffs } from '/_102035_/l2/newRelease/helpers/visibleDiffs.js';
import { type NewReleaseValidationIssue, type Ns5TobeArtifactPath } from '/_102035_/l2/solution/candidate/tobePaths.js';
import {
  NEW_RELEASE_CHANGED_EVENT,
  NEW_RELEASE_GENERAL_INDICATORS_EDIT_ID,
  tabForArtifactPath,
  type NewReleaseChangedDetail,
  type NewReleaseEditRequest,
  type NewReleaseTabPresentation,
} from '/_102035_/l2/newRelease/editContract.js';
import { textTree, filterTextTree, hasDraftChanges, type TextTreeNode } from '/_102035_/l2/newRelease/widgets/commonModel.js';
import '/_102035_/l2/newRelease/widgets/general.js';
import '/_102035_/l2/newRelease/widgets/access.js';
import '/_102035_/l2/newRelease/widgets/journeys.js';
import '/_102035_/l2/newRelease/widgets/ontology.js';
import '/_102035_/l2/newRelease/widgets/rules.js';
import '/_102035_/l2/newRelease/widgets/workflows.js';
import '/_102035_/l2/newRelease/widgets/integration.js';
import '/_102035_/l2/newRelease/widgets/review.js';

type NewReleaseTab = 'general' | 'journeys' | 'ontology' | 'access' | 'rules' | 'workflows' | 'integration' | 'review';

const TABS: NewReleaseTab[] = ['general', 'journeys', 'ontology', 'access', 'rules', 'workflows', 'integration', 'review'];

@customElement('new-release--widgets--index-102035')
export class NewReleaseIndex102035 extends StateLitElement {
  @property({ type: Number }) project = 0;
  @property({ type: String, attribute: 'module-name' }) moduleName = '';
  @property({ type: String }) version: NewReleaseVersion = 'asis';
  @property({ attribute: false }) data: NewReleaseModuleData | null = null;

  @state() private activeTab: NewReleaseTab = 'general';
  @state() private loading = true;
  @state() private changing = false;
  @state() private mutationError = '';
  @state() private languagePending = false;
  @state() private requestText = '';
  @state() private savedRequest = '';
  @state() private requestBusy = false;
  @state() private requestError = '';
  @state() private identityError = 'pending';
  private identityFlight?: Promise<void>;
  @state() private requestResult = '';
  @state() private requestFileStates: NewReleaseRequestFileState[] = [];
  private requestResultModule = '';
  @state() private requestNeedsRetry = false;

  @state() private presentation: 'graph' | 'text' | 'prompt' = 'graph';
  @state() private textSearch = '';
  @state() private textFilter = '';
  @state() private graphZoom = 1;
  @state() private tabDetail = false;

  private t: NewReleaseTranslate = key => key;
  private languageObserver?: MutationObserver;
  private loadToken = 0;
  private languageToken = 0;
  private validationTimer?: number;
  private mutationQueue: Promise<void> = Promise.resolve();
  private pendingMutations = 0;
  private expectedChangeId: string | null = null;
  private expectedRevisionId: string | null = null;
  private changeByModule = new Map<string, string | null>();
  private revisionByModule = new Map<string, string | null>();
  private requestDrafts = new ChangeRequestDrafts();
  private requestKey: string | null = null;
  private pendingEdit?: { project: number; moduleName: string; tab: NewReleaseTab; id: string };

  createRenderRoot() { return this; }

  private revisionError(error: unknown): string {
    if (error instanceof NewReleaseSaveValidationError) return this.t(`common.validation.${error.reason}`) + (error.reason === 'invalid' ? ` ${error.issues.map(issue => issue.message).join(' · ')}` : '');
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes('revision conflict') || message.includes('change conflict')) return this.t('request.conflict');
    if (message.startsWith('general.languages')) return this.t(message);
    if (message === 'new-release.application_active') return this.t('request.applicationActive');
    if (message === 'new-release.request_empty') return this.t('request.empty');
    if (message.startsWith('new-release.candidate_unindexed_file:')) return this.t('request.newArtifactUnsupported', { path: message.slice('new-release.candidate_unindexed_file:'.length) });
    if (message.startsWith('collab_messages_')) return this.t('request.identityUnavailable', { reason: message });
    if (message === 'implementation.user_unavailable') return this.t('request.userUnavailable');
    if (message.includes('Historical release is incomplete')) return this.t('request.historyUnavailable');
    if (message.includes('Historical inventory differs')) return this.t('request.historyIncompatible');
    if (message.includes('Discard the active candidate')) return this.t('request.activeCandidate');
    return message;
  }

  private async ensureIdentity(): Promise<void> {
    try {
      await ensureUserId();
      this.identityError = '';
    } catch (error) {
      console.error(error);
      this.identityError = error instanceof Error ? error.message : String(error);
    }
    this.requestUpdate();
  }

  connectedCallback() {
    super.connectedCallback();
    this.identityFlight ??= this.ensureIdentity();
    this.project = this.project || Number(mls.actualProject || 0);
    this.languageObserver = observeNewReleaseLanguage(() => this.loadLanguage());
    this.addEventListener('scroll', this.closeHintsOnScroll, true);
    this.addEventListener('nr-before-discard', this.beforeDiscard);
    this.addEventListener('nr-view-state', this.onViewState);
    this.addEventListener('nr-presentation-request', this.onPresentationRequest);
    this.addEventListener('nr-request-edit', this.onEditRequested);
    this.addEventListener('nr-request-change', this.openChangeRequest);
    this.addEventListener('input', this.refreshControls);
    this.addEventListener('change', this.refreshControls);
    this.addEventListener('click', this.refreshControls);
    this.addEventListener('nr-navigate', this.onNavigate as EventListener);
    this.addEventListener(NEW_RELEASE_CHANGED_EVENT, this.onArtifactChanged as EventListener);
    window.addEventListener(NEW_RELEASE_CONTEXT_EVENT, this.onContextChange as EventListener);
    window.addEventListener(NEW_RELEASE_TOBE_UPDATED_EVENT, this.onTobeUpdated as EventListener);
    void this.initialize();
  }

  disconnectedCallback() {
    this.languageObserver?.disconnect();
    if (this.validationTimer) window.clearTimeout(this.validationTimer);
    this.removeEventListener('scroll', this.closeHintsOnScroll, true);
    this.removeEventListener('nr-before-discard', this.beforeDiscard);
    this.removeEventListener('nr-view-state', this.onViewState);
    this.removeEventListener('nr-presentation-request', this.onPresentationRequest);
    this.removeEventListener('nr-request-edit', this.onEditRequested);
    this.removeEventListener('nr-request-change', this.openChangeRequest);
    this.removeEventListener('input', this.refreshControls);
    this.removeEventListener('change', this.refreshControls);
    this.removeEventListener('click', this.refreshControls);
    this.removeEventListener('nr-navigate', this.onNavigate as EventListener);
    this.removeEventListener(NEW_RELEASE_CHANGED_EVENT, this.onArtifactChanged as EventListener);
    window.removeEventListener(NEW_RELEASE_CONTEXT_EVENT, this.onContextChange as EventListener);
    window.removeEventListener(NEW_RELEASE_TOBE_UPDATED_EVENT, this.onTobeUpdated as EventListener);
    super.disconnectedCallback();
  }

  private async initialize() {
    await this.loadLanguage();
    await this.loadModule();
  }

  private async loadLanguage() {
    const token = ++this.languageToken;
    const project = this.project || Number(mls.actualProject || 0);
    const bundles = await loadNewReleaseMessages(project);
    if (token !== this.languageToken) return;
    this.t = createNewReleaseTranslator(bundles);
    this.requestUpdate();
  }

  private async loadModule() {
    const resultModule = `${this.project}/${this.moduleName}`;
    if (this.requestResultModule !== resultModule) {
      this.requestResult = '';
      this.requestFileStates = [];
      this.requestNeedsRetry = false;
      this.requestResultModule = resultModule;
    }
    this.requestDrafts.remember(this.requestKey, this.requestText, this.savedRequest);
    this.requestKey = null;
    if (this.validationTimer) {
      window.clearTimeout(this.validationTimer);
      this.validationTimer = undefined;
    }
    const token = ++this.loadToken;
    this.data = null;
    this.requestText = '';
    this.savedRequest = '';
    this.requestError = '';
    this.expectedChangeId = null;
    this.expectedRevisionId = null;
    if (!this.project || !this.moduleName) {
      this.data = null;
      this.loading = false;
      return;
    }
    this.loading = true;
    const context = { project: this.project, moduleName: this.moduleName, version: this.version };
    let data: NewReleaseModuleData;
    let request: Awaited<ReturnType<typeof readChangeRequest>> = null;
    try {
      data = await readNs5Module(context.project, context.moduleName, context.version);
      if (context.version === 'asis' || context.version === 'tobe') request = await readChangeRequest(context.project, context.moduleName);
    } catch (error) {
      if (token === this.loadToken && contextStillCurrent(context, this)) {
        if (this.pendingEdit?.project === context.project && this.pendingEdit.moduleName === context.moduleName && context.version === 'tobe') this.pendingEdit = undefined;
        this.mutationError = this.revisionError(error);
        this.loading = false;
      }
      return;
    }
    if (token !== this.loadToken || !contextStillCurrent(context, this)) return;
    const languagePending = !historicalReleaseId(context.version) && await hasPendingLanguages(context.project, context.moduleName);
    if (token !== this.loadToken || !contextStillCurrent(context, this)) return;
    this.data = data;
    this.languagePending = languagePending;
    this.expectedChangeId = data.changeId;
    this.expectedRevisionId = data.revisionId;
    this.changeByModule.set(`${this.project}/${this.moduleName}`, data.changeId);
    this.revisionByModule.set(`${this.project}/${this.moduleName}`, data.revisionId);
    this.savedRequest = request?.text ?? '';
    this.requestKey = context.version === 'asis' || context.version === 'tobe'
      ? ChangeRequestDrafts.key(context.project, context.moduleName, request?.changeId ?? data.changeId)
      : null;
    this.requestText = this.requestKey ? this.requestDrafts.restore(this.requestKey, this.savedRequest) ?? this.savedRequest : '';
    this.loading = false;
    if (this.pendingEdit && context.version === 'tobe') void this.resumePendingEdit(context, token);
  }

  private async resumePendingEdit(context: NewReleaseContext, token: number) {
    const pending = this.pendingEdit;
    if (!pending) return;
    if (pending.project !== context.project || pending.moduleName !== context.moduleName || pending.tab !== this.activeTab) { this.pendingEdit = undefined; return; }
    await this.updateComplete;
    const editor = this.activeEditor() as (HTMLElement & { updateComplete?: Promise<boolean> }) | null;
    await editor?.updateComplete;
    if (token !== this.loadToken || !contextStillCurrent(context, this) || this.activeTab !== pending.tab || this.pendingEdit !== pending) return;
    this.pendingEdit = undefined;
    if (pending.tab === 'general' && pending.id === NEW_RELEASE_GENERAL_INDICATORS_EDIT_ID) {
      (editor as (HTMLElement & { openIndicatorsForEdit?: () => void }) | null)?.openIndicatorsForEdit?.();
      return;
    }
    this.tabPresentation?.select(pending.id);
  }

  private onContextChange = (event: Event) => {
    const context = (event as CustomEvent<NewReleaseContext>).detail;
    if (!context?.project || !context.moduleName) return;
    if (this.pendingEdit && (context.project !== this.pendingEdit.project || context.moduleName !== this.pendingEdit.moduleName || context.version !== 'tobe')) this.pendingEdit = undefined;
    const projectChanged = context.project !== this.project;
    this.project = context.project;
    this.moduleName = context.moduleName;
    this.version = context.version;
    this.tabPresentation = undefined;
    this.tabDetail = false;
    this.expectedChangeId = null;
    this.expectedRevisionId = null;
    this.mutationError = '';
    this.requestBusy = false;
    this.changing = this.pendingMutations > 0;
    if (projectChanged) void this.loadLanguage();
    void this.loadModule();
  };

  private onNavigate = (event: Event) => {
    const tab = (event as CustomEvent<{ tab?: NewReleaseTab }>).detail?.tab;
    if (tab && TABS.includes(tab)) void this.activateTab(tab);
  };

  private async activateTab(tab: NewReleaseTab, focus = false) {
    if (tab !== this.activeTab && !this.canLeaveTab()) return;
    if (tab !== this.activeTab) this.pendingEdit = undefined;
    const previous = this.activeEditor();
    if (previous && tab !== this.activeTab) { previous.mode = 'view'; previous.dirty = false; }
    this.activeTab = tab;
    this.tabDetail = false;
    this.tabPresentation = undefined;
    this.textSearch = '';
    this.textFilter = '';
    this.graphZoom = 1;
    if (tab === 'review' && this.version === 'asis') {
      const context = { project: this.project, moduleName: this.moduleName, version: this.version };
      try {
        const candidate = await readActiveL4Change(context.project, context.moduleName);
        if (candidate && this.activeTab === 'review' && contextStillCurrent(context, this)) {
          window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { ...context, version: 'tobe' } }));
        }
      } catch (error) {
        if (this.activeTab === 'review' && contextStillCurrent(context, this)) this.mutationError = this.revisionError(error);
      }
    }
    if (!focus) return;
    await this.updateComplete;
    this.querySelector<HTMLButtonElement>(`#nr-tab-${tab}`)?.focus();
  }

  private tabPresentation?: NewReleaseTabPresentation;

  private editSnapshots = new WeakMap<HTMLElement, unknown>();

  private refreshControls = () => { queueMicrotask(() => {
    const editor = this.activeEditor();
    if (editor?.mode === 'edit' && !editor.dirty && editor.getDraft) this.editSnapshots.set(editor, structuredClone(editor.getDraft()));
    if (editor?.mode !== 'edit' && editor) this.editSnapshots.delete(editor);
    this.requestUpdate();
  }); };

  // Tabs can announce detail navigation without coupling their models to the container.
  private onPresentationRequest = (event: Event) => {
    const detail = (event as CustomEvent<import('/_102035_/l2/newRelease/editContract.js').NewReleasePresentationRequest>).detail;
    this.presentation = detail.mode;
  };
  private onEditRequested = (event: Event) => {
    const source = event.target as HTMLElement & { project?: number; moduleName?: string; version?: NewReleaseVersion };
    const id = (event as CustomEvent<NewReleaseEditRequest>).detail?.id;
    if (!id || this.version !== 'asis' || source.project !== this.project || source.moduleName !== this.moduleName || source.version !== 'asis') return;
    this.pendingEdit = { project: this.project, moduleName: this.moduleName, tab: this.activeTab, id };
    window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project: this.project, moduleName: this.moduleName } }));
  };
  private onViewState = (event: Event) => {
    this.tabPresentation = (event as CustomEvent<NewReleaseTabPresentation>).detail;
    this.tabDetail = !!this.tabPresentation?.detail;
  };

  private activeEditor() {
    return this.querySelector<HTMLElement & { mode?: string; dirty?: boolean; getDraft?: () => unknown }>(
      `.nr-index__revision-content new-release--widgets--${this.activeTab}-102035`,
    );
  }

  private beforeDiscard = (event: Event) => { if (!this.canLeaveTab()) event.preventDefault(); };

  private canLeaveTab(): boolean {
    const editor = this.activeEditor();
    if (!editor || editor.mode !== 'edit' || !editor.dirty) return true;
    if (editor.getDraft && this.editSnapshots.has(editor) && !hasDraftChanges(this.editSnapshots.get(editor), editor.getDraft())) return true;
    return window.confirm(this.t('common.discardChanges'));
  }

  private openChangeRequest = async (event?: Event) => {
    if (historicalReleaseId(this.version)) return;
    const text = (event as CustomEvent<{ text?: string }> | undefined)?.detail?.text;
    if (!this.requestText.trim()) this.requestText = text || this.t('common.requestTemplate', { tab: this.t(`tab.${this.activeTab}`) });
    this.presentation = 'prompt';
    await this.updateComplete;
    const panel = this.querySelector<HTMLDetailsElement>('.nr-index__request');
    if (panel) panel.open = true;
    this.querySelector<HTMLTextAreaElement>('#nr-change-request')?.focus();
    panel?.scrollIntoView({ block: 'nearest' });
  };

  private treeNodes(): TextTreeNode[] {
    if (this.tabPresentation) return this.tabPresentation.nodes;
    return (this.data?.artifacts.all ?? [])
      .filter(artifact => tabForArtifactPath(artifact.path) === this.activeTab)
      .map(artifact => textTree(artifact.path, artifact.value));
  }

  private renderTreeNode(node: TextTreeNode, depth = 0): unknown {
    const dot = node.changed ? html`<span class="nr-item__changed" role="img" aria-label=${this.t('tobe.itemChanged')} title=${this.t('tobe.itemChanged')}></span>` : nothing;
    if (!node.children.length && !(depth === 0 && this.tabPresentation && node.value)) return html`<li>${this.tabPresentation && (depth > 0 || node.value) ? html`<button class="nr-common__tree-select" type="button" @click=${() => { this.tabPresentation?.select(node.id); }}><span class="nr-common__tree-name">${node.label}</span>${dot}${node.suffix ? html`<span class="nr-common__tree-suffix">${node.suffix}</span>` : nothing}</button>` : html`<strong>${node.label}</strong>`}${node.value ? html`<span>${node.value}</span>` : nothing}</li>`;
    return html`<li><details ?open=${!!this.textSearch}><summary>${node.label}${dot}</summary><ul>${this.tabPresentation && node.value ? html`<li><button class="nr-common__tree-select" type="button" @click=${() => { this.tabPresentation?.select(node.id); }}>${this.t('common.details')}</button></li>` : nothing}${node.children.map(child => this.renderTreeNode(child, depth + 1))}</ul></details></li>`;
  }

  private closeHintsOnScroll = () => {
    this.querySelectorAll<HTMLDetailsElement>('details.nr-common__hint[open]').forEach(hint => { hint.open = false; });
    this.querySelectorAll<HTMLElement>('[popover][data-nr-hint]:popover-open').forEach(hint => hint.hidePopover());
  };

  private renderCommonControls() {
    if (this.activeTab === 'general' || this.activeTab === 'review') return nothing;
    const editing = this.activeEditor()?.mode === 'edit';
    const nested = this.tabDetail || editing;
    return html`<div class="nr-common__toolbar">
      ${nested || this.tabPresentation?.canBack ? html`<button type="button" @click=${() => {
        if (this.tabPresentation) { this.tabPresentation.back(); return; }
        if (!this.canLeaveTab()) return;
        const editor = this.activeEditor();
        if (editor?.mode === 'edit') { editor.mode = 'view'; editor.dirty = false; }
        editor?.dispatchEvent(new CustomEvent('nr-back'));
        this.tabDetail = false;
      }}>${this.t('common.back')}</button>` : nothing}
      ${!nested ? html`<div role="group" aria-label=${this.t('common.presentation')}>
        ${(['graph', 'text', 'prompt'] as const).map(view => html`<button type="button" aria-pressed=${this.presentation === view ? 'true' : 'false'} @click=${() => { this.presentation = view; }}>${this.t(`common.${view}`)}</button>`)}
      </div>` : nothing}
      ${this.presentation === 'graph' && !nested ? html`<div role="group" aria-label=${this.t('common.zoom')}>
        <button type="button" aria-label=${this.t('common.zoomOut')} ?disabled=${this.graphZoom <= .5} @click=${() => { this.graphZoom = Math.max(.5, this.graphZoom - .1); }}>−</button>
        <button type="button" aria-label=${this.t('common.zoomReset')} @click=${() => { this.graphZoom = 1; }}>${Math.round(this.graphZoom * 100)}%</button>
        <button type="button" aria-label=${this.t('common.zoomIn')} ?disabled=${this.graphZoom >= 2} @click=${() => { this.graphZoom = Math.min(2, this.graphZoom + .1); }}>+</button>
      </div>` : nothing}
      <details class="nr-common__hint"><summary aria-label=${this.t('common.help')}>?</summary><p>${this.t('common.hint')}</p></details>
    </div>`;
  }

  private renderTextTree() {
    const roots = this.treeNodes();
    const filters = this.tabPresentation?.filters;
    const selected = filters?.find(filter => filter.id === this.textFilter);
    const nodes = filterTextTree(selected ? roots.filter(root => selected.rootIds.includes(root.id)) : roots, this.textSearch, filters ? '' : this.textFilter);
    return html`<section class="nr-common__text">
      <label>${this.t('common.search')}<input type="search" .value=${this.textSearch} @input=${(event: Event) => { this.textSearch = (event.target as HTMLInputElement).value; }}></label>
      <label>${this.t('common.filter')}<select .value=${this.textFilter} @change=${(event: Event) => { this.textFilter = (event.target as HTMLSelectElement).value; }}><option value="">${this.t('common.all')}</option>${(filters || roots).map(root => html`<option value=${root.id}>${root.label}</option>`)}</select></label>
      ${nodes.length ? html`<ul>${nodes.map(node => this.renderTreeNode(node))}</ul>` : html`<p role="status">${this.t('common.noResults')}</p>`}
    </section>`;
  }

  private onTabKeydown = (event: KeyboardEvent) => {
    const current = TABS.indexOf(this.activeTab);
    let next = current;
    if (event.key === 'ArrowRight') next = (current + 1) % TABS.length;
    else if (event.key === 'ArrowLeft') next = (current + TABS.length - 1) % TABS.length;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = TABS.length - 1;
    else return;
    event.preventDefault();
    void this.activateTab(TABS[next], true);
  };

  private onTobeUpdated = (event: Event) => {
    const detail = (event as CustomEvent<{ project?: number; moduleName?: string; version?: NewReleaseVersion }>).detail;
    if (detail?.project !== this.project || detail?.moduleName !== this.moduleName) return;
    // The context owner will announce the selected version after refreshing its choices.
    if (detail.version === 'tobe' && this.version === 'asis') return;
    if (this.pendingEdit && this.version === 'asis') return;
    this.scheduleOverlayReload();
  };

  private scheduleOverlayReload() {
    if (this.validationTimer) window.clearTimeout(this.validationTimer);
    this.validationTimer = window.setTimeout(() => {
      this.validationTimer = undefined;
      void this.loadModule();
    }, 180);
  }

  private onArtifactChanged = (event: Event) => {
    const detail = (event as CustomEvent<NewReleaseChangedDetail>).detail;
    const source = event.target as HTMLElement & { project?: number; moduleName?: string; version?: NewReleaseVersion };
    if (!detail?.path || historicalReleaseId(this.version)
      || source.project !== this.project || source.moduleName !== this.moduleName || source.version !== this.version) return;
    event.preventDefault();
    const project = this.project;
    const moduleName = this.moduleName;
    const version = this.version;
    const moduleKey = `${project}/${moduleName}`;
    const initialChange = this.expectedChangeId;
    const initialRevision = this.expectedRevisionId;
    this.requestDrafts.remember(this.requestKey, this.requestText, this.savedRequest);
    this.pendingMutations += 1;
    this.changing = true;
    this.mutationError = '';
    this.mutationQueue = this.mutationQueue.then(async () => {
      try {
        if (!contextStillCurrent({ project, moduleName, version }, this)) { detail.complete?.(new Error(this.t('request.conflict'))); return; }
        if (detail.languageOnly && detail.path === 'module.defs.ts' && this.data?.module) {
          const value = detail.value as Ns5ModuleArtifact;
          const before = this.data.module;
          const normalized = { ...before, productLanguages: value.productLanguages, defaultLanguage: value.defaultLanguage };
          if (JSON.stringify(normalized) !== JSON.stringify(value)) throw new Error(this.t('general.languagesInvalid'));
          const revisionId = await applyDirectLanguages(project, moduleName, value, {
            changeId: this.changeByModule.has(moduleKey) ? this.changeByModule.get(moduleKey)! : initialChange,
            revisionId: this.revisionByModule.has(moduleKey) ? this.revisionByModule.get(moduleKey)! : initialRevision,
          }, key => { this.mutationError = this.t(key); });
          this.revisionByModule.set(moduleKey, revisionId);
          if (!contextStillCurrent({ project, moduleName, version }, this)) { detail.complete?.(new Error(this.t('request.conflict'))); return; }
          const refreshed = await readNs5Module(project, moduleName, version);
          const languagePending = await hasPendingLanguages(project, moduleName);
          if (!contextStillCurrent({ project, moduleName, version }, this)) { detail.complete?.(new Error(this.t('request.conflict'))); return; }
          this.expectedRevisionId = revisionId;
          this.data = refreshed;
          this.languagePending = languagePending;
          detail.complete?.();
          return;
        }
        const manifest = await saveTobeArtifact(project, moduleName, detail.path, detail.value, {
          jsonPath: detail.jsonPath,
          expectedChangeId: this.changeByModule.has(moduleKey) ? this.changeByModule.get(moduleKey)! : initialChange,
          expectedRevisionId: this.revisionByModule.has(moduleKey) ? this.revisionByModule.get(moduleKey)! : initialRevision,
        });
        if (manifest.changeId && manifest.revisionId) {
          const bound = await bindStructuredEditsRequest(project, moduleName, manifest.changeId, manifest.revisionId,
            this.t('request.structuredEdits'));
          manifest.revisionId = bound.revisionId;
          if (this.project === project && this.moduleName === moduleName) {
            const draft = this.requestText;
            const dirty = draft !== this.savedRequest;
            this.savedRequest = bound.text;
            if (!dirty) this.requestText = bound.text;
            else this.requestDrafts.remember(ChangeRequestDrafts.key(project, moduleName, bound.changeId), draft, bound.text);
          }
        }
        detail.complete?.();
        if (initialChange === null && manifest.changeId) {
          this.requestDrafts.move(
            ChangeRequestDrafts.key(project, moduleName, null),
            ChangeRequestDrafts.key(project, moduleName, manifest.changeId),
          );
        }
        this.changeByModule.set(moduleKey, manifest.changeId ?? null);
        this.revisionByModule.set(moduleKey, manifest.revisionId ?? null);
        if (this.project === project && this.moduleName === moduleName) {
          this.expectedChangeId = manifest.changeId ?? null;
          this.expectedRevisionId = manifest.revisionId ?? null;
          this.version = 'tobe';
          this.scheduleOverlayReload();
        }
      } catch (error) {
        detail.complete?.(new Error(this.revisionError(error)));
        if (this.project === project && this.moduleName === moduleName) {
          this.mutationError = this.revisionError(error);
          if (detail.path === 'module.defs.ts') {
            const active = await readActiveL4Change(project, moduleName);
            this.expectedRevisionId = active?.activeRevisionId ?? null;
            this.revisionByModule.set(moduleKey, this.expectedRevisionId);
            this.languagePending = await hasPendingLanguages(project, moduleName);
          }
        }
      } finally {
        this.pendingMutations -= 1;
        this.changing = this.pendingMutations > 0;
      }
    });
  };

  private async saveRequest() {
    if (this.requestBusy || this.changing || (this.requestText === this.savedRequest && !this.requestNeedsRetry)) return;
    const context = { project: this.project, moduleName: this.moduleName, version: this.version };
    const text = this.requestText.trim();
    if (!text) { this.requestError = this.t('request.empty'); return; }
    const expectedChange = this.expectedChangeId;
    const expectedRevision = this.expectedRevisionId;
    this.requestBusy = true;
    this.requestError = '';
    this.requestResult = '';
    this.requestFileStates = [];
    this.requestNeedsRetry = false;
    try {
      const saved = await saveChangeRequest(context.project, context.moduleName, text, expectedChange, expectedRevision);
      if (!contextStillCurrent(context, this)) return;
      this.expectedChangeId = saved.changeId;
      this.expectedRevisionId = saved.revisionId;
      this.changeByModule.set(`${context.project}/${context.moduleName}`, saved.changeId);
      this.revisionByModule.set(`${context.project}/${context.moduleName}`, saved.revisionId);
      this.savedRequest = text;
      const outcome = await runNewReleaseRequest(context.moduleName, text, task => {
        if (contextStillCurrent(context, this)) this.requestResult = this.t('request.running');
      });
      if (!contextStillCurrent(context, this)) return;
      const summary = summarizeNewReleaseRequest(outcome.results, outcome.task.status);
      this.requestResult = this.t(summary.key, summary.values);
      this.requestFileStates = summary.fileStates ?? [];
      this.requestNeedsRetry = summary.retry;
      if (outcome.task.status === 'failed') throw new Error(this.requestResult);
      const written = outcome.results.some(result => { try { return JSON.parse(result).written === true; } catch { return false; } });
      if (written) {
        const revision = await sealL4Revision(context.project, context.moduleName, saved.revisionId, text);
        this.expectedRevisionId = revision.revisionId;
        this.revisionByModule.set(`${context.project}/${context.moduleName}`, revision.revisionId);
      }
      this.requestDrafts.forget(this.requestKey);
      this.version = 'tobe';
      window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project: context.project, moduleName: context.moduleName } }));
      await this.loadModule();
    } catch (error) {
      if (contextStillCurrent(context, this)) {
        if (!this.requestNeedsRetry) {
          this.requestResult = '';
          this.requestFileStates = [];
        }
        this.requestNeedsRetry = true;
        this.requestError = this.revisionError(error);
      }
    } finally {
      if (this.project === context.project && this.moduleName === context.moduleName) this.requestBusy = false;
    }
  }

  private async retryLanguages() {
    if (!this.data?.module || this.changing || this.requestBusy || this.activeEditor()?.dirty || historicalReleaseId(this.version)) return;
    this.changing = true;
    try {
      await applyDirectLanguages(this.project, this.moduleName, this.data.module,
        { changeId: this.expectedChangeId, revisionId: this.expectedRevisionId }, key => { this.mutationError = this.t(key); });
      await this.loadModule();
    } catch (error) {
      this.mutationError = this.revisionError(error);
      const active = await readActiveL4Change(this.project, this.moduleName);
      this.expectedRevisionId = active?.activeRevisionId ?? null;
      this.revisionByModule.set(`${this.project}/${this.moduleName}`, this.expectedRevisionId);
    } finally { this.changing = false; }
  }

  private async reuseHistory() {
    if (!historicalReleaseId(this.version) || this.changing) return;
    const context = { project: this.project, moduleName: this.moduleName, version: this.version };
    this.changing = true;
    this.mutationError = '';
    try {
      try {
        await reuseHistoricalRelease(context.project, context.moduleName, context.version);
      } catch (error) {
        if (!(error instanceof Error) || !error.message.includes('Discard the active candidate')
          || !contextStillCurrent(context, this) || !window.confirm(this.t('request.replaceCandidateConfirm'))) throw error;
        await discardTobe(context.project, context.moduleName, undefined, false);
        if (!contextStillCurrent(context, this)) return;
        await reuseHistoricalRelease(context.project, context.moduleName, context.version);
      }
      if (!contextStillCurrent(context, this)) return;
      this.version = 'tobe';
      window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project: context.project, moduleName: context.moduleName } }));
      await this.loadModule();
    } catch (error) {
      if (this.project === context.project && this.moduleName === context.moduleName) this.mutationError = this.revisionError(error);
    } finally {
      this.changing = this.pendingMutations > 0;
    }
  }

  private tabIcon(tab: NewReleaseTab) {
    const common = (content: unknown) => svg`
      <svg viewBox="0 0 24 24" aria-hidden="true">${content}</svg>
    `;
    switch (tab) {
      case 'general': return common(svg`<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>`);
      case 'journeys': return common(svg`<circle cx="6" cy="17" r="2.5"/><circle cx="18" cy="7" r="2.5"/><path d="M8.5 16c4.5 0 2.5-8 7-8"/>`);
      case 'ontology': return common(svg`<circle cx="12" cy="5" r="3"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="18" r="3"/><path d="M10.7 7.7 7.4 15M13.3 7.7l3.3 7.3M9 18h6"/>`);
      case 'access': return common(svg`<path d="M12 3 20 6v5c0 5-3.2 8.5-8 10-4.8-1.5-8-5-8-10V6Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/>`);
      case 'rules': return common(svg`<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>`);
      case 'workflows': return common(svg`<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="12" cy="18" r="2.5"/><path d="M8.5 6h7M7.5 8l3.5 7.5M16.5 8 13 15.5"/>`);
      case 'integration': return common(svg`<path d="M9 8 6.5 5.5a3.5 3.5 0 0 0-5 5L5 14a3.5 3.5 0 0 0 5 0l1-1M15 16l2.5 2.5a3.5 3.5 0 0 0 5-5L19 10a3.5 3.5 0 0 0-5 0l-1 1M8 12h8"/>`);
      case 'review': return common(svg`<path d="M7 5h13M7 12h13M7 19h9"/><circle cx="4" cy="5" r="1.4"/><circle cx="4" cy="12" r="1.4"/><circle cx="4" cy="19" r="1.4"/>`);
    }
  }

  private renderTabs() {
    return html`
      <nav class="nr-index__tabs" role="tablist" aria-label=${this.t('a11y.tabs')} @keydown=${this.onTabKeydown}>
        ${TABS.map(tab => {
          const label = this.t(`tab.${tab}`);
          return html`
            <button
              id=${`nr-tab-${tab}`}
              type="button"
              role="tab"
              class=${this.activeTab === tab ? 'is-active' : ''}
              aria-label=${label}
              title=${label}
              aria-selected=${this.activeTab === tab ? 'true' : 'false'}
              aria-controls=${`nr-panel-${tab}`}
              tabindex=${this.activeTab === tab ? '0' : '-1'}
              @click=${() => void this.activateTab(tab)}
            ><span class="nr-tab__icon">${this.tabIcon(tab)}${this.tabHasTobe(tab) ? html`<i class="nr-tab__source" title=${this.t('tobe.tabSource')}></i>` : nothing}</span><span class="nr-tab__label">${label}</span></button>
          `;
        })}
      </nav>
    `;
  }

  private tabHasTobe(tab: NewReleaseTab): boolean {
    return !!this.data?.artifacts.all.some(artifact => artifact.source === 'tobe' && tabForArtifactPath(artifact.path) === tab);
  }

  private hasPreparedChanges(): boolean {
    return !!this.data?.changeId || !!this.data?.manifest?.changes.length;
  }

  private async cancelChanges() {
    if (this.version !== 'tobe' || !this.hasPreparedChanges() || this.loading || this.changing || this.requestBusy) return;
    if (!window.confirm(this.t('review.clearConfirm'))) return;
    const context = { project: this.project, moduleName: this.moduleName, version: this.version };
    const moduleKey = `${context.project}/${context.moduleName}`;
    const requestKeys = [this.requestKey,
      ChangeRequestDrafts.key(context.project, context.moduleName, this.expectedChangeId),
      ChangeRequestDrafts.key(context.project, context.moduleName, null)];
    this.pendingMutations += 1;
    this.changing = true;
    this.mutationError = '';
    try {
      await discardTobe(context.project, context.moduleName, undefined, false);
      for (const key of requestKeys) this.requestDrafts.forget(key);
      this.changeByModule.delete(moduleKey);
      this.revisionByModule.delete(moduleKey);
      if (!contextStillCurrent(context, this)) return;
      this.requestText = '';
      this.savedRequest = '';
      this.requestKey = null;
      this.requestError = '';
      this.expectedChangeId = null;
      this.expectedRevisionId = null;
      this.version = 'asis';
      window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project: context.project, moduleName: context.moduleName, version: 'asis' } }));
      await this.loadModule();
    } catch (error) {
      if (contextStillCurrent(context, this)) this.mutationError = this.revisionError(error);
    } finally {
      this.pendingMutations -= 1;
      this.changing = this.pendingMutations > 0;
    }
  }

  private async discardPaths(paths: Ns5TobeArtifactPath[]) {
    if (!paths.length || this.changing) return;
    if (!window.confirm(this.t('tobe.discardConfirm', { count: paths.length }))) return;
    this.changing = true;
    this.mutationError = '';
    try {
      for (const path of paths) await discardTobe(this.project, this.moduleName, path);
      if (!this.data?.manifest || Object.keys(this.data.manifest.base).length <= paths.length) this.version = 'asis';
      await this.loadModule();
    } catch (error) {
      this.mutationError = this.revisionError(error);
    } finally {
      this.changing = false;
    }
  }

  private validationIssues(): NewReleaseValidationIssue[] {
    return this.data?.validation.issues ?? [];
  }

  private formatDiffValue(value: unknown): string {
    if (value === undefined) return this.t('tobe.diffEmpty');
    const text = typeof value === 'string' ? value : JSON.stringify(value);
    return text.length > 140 ? `${text.slice(0, 137)}…` : text;
  }

  private renderTobeStatus() {
    const manifest = this.data?.manifest;
    if (!manifest) return nothing;
    const errors = this.validationIssues().filter(issue => issue.severity === 'error').length;
    const warnings = this.validationIssues().filter(issue => issue.severity === 'warning').length;
    return html`
      ${this.activeTab === 'review' ? html`<section class="nr-index__tobe" aria-label=${this.t('tobe.statusLabel')} aria-live="polite">
        <div class="nr-index__tobe-main">
          <strong>${this.t('status.tobe', { count: manifest.changes.length })}</strong>
          <span>${this.t('tobe.byline', {
            author: manifest.author,
            date: new Date(manifest.updatedAt).toLocaleString(document.documentElement.lang || 'pt-BR'),
          })}</span>
        </div>
        <div class="nr-index__tobe-health">
          <span class=${errors ? 'has-errors' : ''}>${this.t('summary.errors', { count: errors })}</span>
          <span class=${warnings ? 'has-warnings' : ''}>${this.t('summary.warnings', { count: warnings })}</span>
        </div>
      </section>` : nothing}
      ${this.data?.stalePaths.length ? html`
        <section class="nr-index__stale" role="alert">
          <div><strong>${this.t('tobe.staleTitle')}</strong><p>${this.t('tobe.staleBody')}</p></div>
          <div class="nr-index__stale-list">
            ${this.data.stalePaths.map(path => html`
              <span><code>${path}</code><button type="button" ?disabled=${this.changing} @click=${() => void this.discardPaths([path])}>${this.t('tobe.recopy')}</button></span>
            `)}
          </div>
        </section>
      ` : nothing}
    `;
  }

  private renderValidationLog() {
    if (this.activeTab !== 'review' || this.version !== 'tobe' || !this.hasPreparedChanges()) return nothing;
    const issues = this.validationIssues();
    return html`<section class="nr-index__log" aria-label=${this.t('review.log.title')}>
      <h2>${this.t('review.log.title')}</h2>
      ${issues.length ? html`<ul>${issues.map(issue => html`<li class=${`is-${issue.severity}`}>
        <div><strong>${this.t(`review.log.${issue.severity}`)}</strong><code>${issue.artifact}${issue.path && issue.path !== '$' ? ` · ${issue.path}` : ''}</code></div>
        <p>${issue.message}</p>
      </li>`)}</ul>` : html`<p>${this.t('review.log.empty')}</p>`}
    </section>`;
  }

  private renderDiffs() {
    const diffs = visibleDiffs(this.data?.diffs ?? [], this.activeTab);
    if (!diffs.length) return nothing;
    return html`
      <details class="nr-index__diff">
        <summary>${this.t('tobe.diffTitle', { count: diffs.reduce((total, item) => total + item.entries.length, 0) })}</summary>
        ${this.activeTab === 'review' && this.version === 'tobe' && this.hasPreparedChanges() ? html`
          <div class="nr-index__diff-actions"><button type="button" ?disabled=${this.loading || this.changing || this.requestBusy}
            @click=${() => void this.cancelChanges()}>${this.t('review.clearChanges')}</button></div>
        ` : nothing}
        ${diffs.map(diff => html`
          <section>
            <header>
              <code>${diff.path}</code>
              <div>
                <span>${this.t('tobe.diffCount', { count: diff.entries.length })}</span>
                <button type="button" ?disabled=${this.changing} @click=${() => void this.discardPaths([diff.path])}>${this.t('tobe.discardPath')}</button>
              </div>
            </header>
            <div class="nr-index__diff-lines">
              ${diff.entries.map(entry => html`
                <article>
                  <code>${entry.jsonPath}</code>
                  <span class="is-before">${this.formatDiffValue(entry.before)}</span>
                  <span aria-hidden="true">${this.t('tobe.diffArrow')}</span>
                  <span class="is-after">${this.formatDiffValue(entry.after)}</span>
                </article>
              `)}
            </div>
          </section>
        `)}
      </details>
    `;
  }

  private renderTabContent() {
    if (this.activeTab === 'general') {
      return html`
        <new-release--widgets--general-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--general-102035>
      `;
    }
    if (this.activeTab === 'ontology') {
      return html`
        <new-release--widgets--ontology-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--ontology-102035>
      `;
    }
    if (this.activeTab === 'journeys') {
      return html`
        <new-release--widgets--journeys-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--journeys-102035>
      `;
    }
    if (this.activeTab === 'access') {
      return html`
        <new-release--widgets--access-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--access-102035>
      `;
    }
    if (this.activeTab === 'rules') {
      return html`
        <new-release--widgets--rules-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--rules-102035>
      `;
    }
    if (this.activeTab === 'workflows') {
      return html`
        <new-release--widgets--workflows-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--workflows-102035>
      `;
    }
    if (this.activeTab === 'integration') {
      return html`
        <new-release--widgets--integration-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--integration-102035>
      `;
    }
    if (this.activeTab === 'review') {
      return html`
        ${this.renderDiffs()}
        <new-release--widgets--review-102035
          .identityError=${this.identityError}
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .request=${this.savedRequest}
          .t=${this.t}
        ></new-release--widgets--review-102035>
      `;
    }
    return html`
      <section class="nr-index__placeholder">
        <span class="nr-index__placeholder-mark" aria-hidden="true"></span>
        <div>
          <h2>${this.t('tab.placeholder.title', { tab: this.t(`tab.${this.activeTab}`) })}</h2>
          <p>${this.t('tab.placeholder.body')}</p>
        </div>
      </section>
    `;
  }

  private renderLoading() {
    return html`
      <div class="nr-index__loading" aria-live="polite">
        <span>${this.t('state.loading')}</span>
        <div></div><div></div><div></div>
      </div>
    `;
  }

  private renderRequest() {
    if (historicalReleaseId(this.version)) return html`
      <section class="nr-index__request nr-index__request--history">
        <div><strong>${this.t('request.historyTitle')}</strong><p>${this.t('request.historyBody')}</p></div>
        <button type="button" ?disabled=${this.changing} @click=${() => void this.reuseHistory()}>${this.t('request.reuseHistory')}</button>
      </section>
    `;
    return html`
      <details class="nr-index__request" ?open=${!this.savedRequest || !!this.requestResult || !!this.requestError}>
        <summary><strong>${this.t('request.title')}</strong><span>${this.requestBusy ? this.t('request.saving') : this.requestText === this.savedRequest ? this.t('request.saved') : this.t('request.unsaved')}</span></summary>
        <div class="nr-index__request-body">
          <p>${this.t('request.description')}</p>
          <label for="nr-change-request">${this.t('request.label')}</label>
          <textarea id="nr-change-request" .value=${this.requestText} ?disabled=${this.requestBusy} placeholder=${this.t('request.placeholder')} @input=${(event: Event) => { this.requestText = (event.currentTarget as HTMLTextAreaElement).value; }}></textarea>
          ${this.requestResult ? html`<pre aria-live="polite">${this.requestResult}</pre>` : nothing}
          ${this.requestFileStates.length ? html`<ul>${this.requestFileStates.map(item => html`<li><code>${item.path}</code> — ${this.t(`request.fileState.${item.state}`)}</li>`)}</ul>` : nothing}
          ${this.identityError ? html`<p class="nr-index__request-error" role="alert">${this.identityError === 'pending' ? this.t('request.identityPending') : this.t('request.identityUnavailable', { reason: this.identityError })}</p>` : nothing}
          ${this.requestError ? html`<p class="nr-index__request-error" role="alert">${this.requestError}</p>` : nothing}
          <div class="nr-index__request-actions">
            <button class="nr-request-action" type="button" ?disabled=${this.requestBusy || this.changing || (this.requestText === this.savedRequest && !this.requestNeedsRetry)} @click=${() => void this.saveRequest()}>${this.t('request.save')}</button>
          </div>
        </div>
      </details>
    `;
  }

  private renderEmpty() {
    return html`
      <section class="nr-index__empty">
        <span aria-hidden="true"></span>
        <h2>${this.t('state.emptyTitle')}</h2>
        <p>${this.t('state.emptyBody')}</p>
      </section>
    `;
  }

  render() {
    const historical = !!historicalReleaseId(this.version);
    const pendingChanges = !this.loading && this.version === 'tobe' && this.data?.module
      ? visibleDiffs(this.data.diffs, 'review').reduce((count, diff) => count + diff.entries.length, 0)
      : null;
    return html`
      <main class="nr-index" aria-busy=${this.loading ? 'true' : 'false'}>
        ${this.renderTabs()}
        ${pendingChanges !== null && (this.activeTab !== 'review' || pendingChanges === 0) ? html`<p class="nr-index__changes-summary" role="status">${this.t(
          pendingChanges === 0 ? 'tobe.noChanges' : pendingChanges === 1 ? 'tobe.onePendingChange' : 'tobe.pendingChanges',
          { count: pendingChanges },
        )}</p>` : nothing}

        ${!this.loading && this.data?.module && this.activeTab === 'general' ? this.renderRequest() : nothing}
        ${!this.loading && this.version !== 'tobe' && this.data?.baseProvenance?.status === 'unverified' ? html`<p class="nr-index__base-warning" role="status">${this.t('request.baseUnverified')}</p>` : nothing}

        ${this.renderTobeStatus()}

        ${this.loading ? this.renderLoading() : !this.data?.module ? this.renderEmpty() : html`
          ${this.languagePending ? html`<button type="button" class="nr-button" ?disabled=${this.changing || this.requestBusy || !!this.activeEditor()?.dirty} @click=${this.retryLanguages}>${this.t('general.languagesRetry')}</button>` : nothing}
          ${this.data.errors.length || this.mutationError ? html`
            <section class="nr-index__errors">
              ${this.data.errors.length ? html`<strong>${this.t('state.errorTitle')}</strong>` : nothing}
              ${this.mutationError ? html`<p>${this.mutationError}</p>` : nothing}
              ${this.data.errors.map(error => html`<p>${this.t('state.errorPath', { path: error.path, message: error.message })}</p>`)}
            </section>
          ` : nothing}
          <section
            id=${`nr-panel-${this.activeTab}`}
            class="nr-index__content"
            role="tabpanel"
            aria-labelledby=${`nr-tab-${this.activeTab}`}
            tabindex="0"
          ><fieldset class="nr-index__revision-content" ?disabled=${historical}>
            ${this.renderCommonControls()}
            ${this.presentation === 'prompt' && !this.tabDetail && this.activeTab !== 'review' && this.activeTab !== 'general' && this.activeEditor()?.mode !== 'edit' ? this.renderRequest() : nothing}
            <div class="nr-common__graph" ?hidden=${this.presentation !== 'graph' && !this.tabDetail && this.activeTab !== 'general' && this.activeTab !== 'review' && this.activeEditor()?.mode !== 'edit'}>
              <div style=${`zoom: ${this.activeTab === 'general' || this.activeTab === 'review' || this.tabDetail || this.activeEditor()?.mode === 'edit' ? 1 : this.graphZoom}`}>
                ${this.renderTabContent()}
              </div>
            </div>
            ${this.presentation === 'text' && !this.tabDetail && this.activeTab !== 'general' && this.activeTab !== 'review' && this.activeEditor()?.mode !== 'edit' ? this.renderTextTree() : nothing}
          </fieldset></section>
          ${this.activeTab !== 'review' ? this.renderDiffs() : nothing}
          ${this.renderValidationLog()}
        `}
      </main>
    `;
  }
}
