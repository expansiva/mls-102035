/// <mls fileReference="_102035_/l2/agentNewReleasePrompt/steps/gate40/gate40.test.ts" enhancement="_blank" />

import assert from 'node:assert/strict';
import test from 'node:test';
import { lintToolSchema } from '/_102025_/l2/toolSchemaLint.js';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import type { NrpModuleArtifacts } from '/_102035_/l2/agentNewReleasePrompt/helpers/compactIndex.js';
import { applyNrpMechanical } from '/_102035_/l2/agentNewReleasePrompt/helpers/mechanical.js';
import {
  buildNrpRepairHumanPrompt,
  buildNrpRepairTool,
  checkNrpGates,
  classifyNrpGateIssues,
  nrpAnnotateRepairRefusal,
  nrpFreshIssues,
  nrpGateAction,
  nrpIndexOnlyRepairMessage,
  nrpIssueKey,
  nrpIssueLines,
  nrpIssueOwner,
  nrpRepairRoundCounts,
  type NrpRepairRound,
  nrpKindCatalog,
  nrpMayWrite,
  type NrpGateIssue,
} from '/_102035_/l2/agentNewReleasePrompt/helpers/releaseGate.js';
import { fieldsOnlyHold } from '/_102035_/l2/agentNewReleasePrompt/steps/gate40/gate40.js';
import { normalizeNrpEdit, nrpFileScope, NrpEditRefusal } from '/_102035_/l2/agentNewReleasePrompt/steps/edit30/edit30.js';
import { nrpReport, planNrpPersistence } from '/_102035_/l2/agentNewReleasePrompt/steps/write50/write50.js';
import { NRP_ARTIFACT_KINDS, recordNrpTriageRefusal } from '/_102035_/l2/agentNewReleasePrompt/steps/triage20/triage20.js';
import { pipelineJsonFileForProject, type Ns5FileInfo } from '/_102035_/l2/solution/fs.js';
import { extractNs4ClassicJsonObject } from '/_102035_/l2/solution/helpers/ns4ClassicDefs.js';
import { ns5OntologyEntityIds, type Ns5OntologyAnyIndex } from '/_102035_/l2/solution/ontologyView.js';
import type {
  Ns5AccessArtifact,
  Ns5IntegrationArtifact,
  Ns5JourneyArtifact,
  Ns5JourneyIndexArtifact,
  Ns5ModuleArtifact,
  Ns5OntologyAnyEntity,
  Ns5RulesAny,
  Ns5WorkflowsArtifact,
} from '/_102035_/l2/solution/types.js';

const REQUEST = 'Priority becomes optional and, when omitted, defaults to medium.';

function failingRules(): NrpModuleArtifacts {
  return {
    module: { moduleName: 'sample', sourcePrompt: '' },
    journeyIndex: { journeys: [] },
    journeys: [],
    ontologyIndex: { entities: [] },
    entities: [],
    rules: {
      schemaVersion: '2026-09-16-ns5-rules-v2',
      moduleName: 'sample',
      rules: { BadId: '' },
    },
    workflows: { processes: [] },
    access: { actors: [], grants: [] },
    integration: { inbound: [], outbound: [], plugins: [] },
  } as unknown as NrpModuleArtifacts;
}

void test('a failing artifact is not written, and the repair sees the whole request', () => {
  const issues = checkNrpGates(failingRules(), ['rules']);
  assert.equal(issues.some(issue => issue.kind === 'rules' && issue.code === 'NS5_RULES_ID'), true);
  const repair = nrpGateAction(issues, ['rules'], []);
  assert.equal(repair.action, 'repair');
  assert.equal(repair.kind, 'rules');
  const human = buildNrpRepairHumanPrompt(REQUEST, 'rules', issues, [{ id: 'rules', artifact: failingRules().rules }]);
  assert.equal(human.includes(REQUEST), true);
  const tool = buildNrpRepairTool();
  assert.equal(tool.function.name, 'submitNrpEdit');
  assert.equal(lintToolSchema(JSON.stringify(tool.function.parameters)), null);
  const sameRound: NrpRepairRound = {
    kind: 'rules',
    keys: issues.filter(issue => issue.kind === 'rules').map(nrpIssueKey),
    lines: nrpIssueLines(issues, 'rules'),
  };
  const second = nrpGateAction(issues, ['rules'], [sameRound]);
  assert.equal(second.action, 'stop');
  assert.match(second.reason, /same errors/);
  assert.equal(nrpMayWrite(second.action), false);
  const plan = planNrpPersistence(false, ['rules.defs.ts', 'pipeline/newReleasePrompt.json']);
  assert.equal(plan.written, false);
  assert.deepEqual(plan.files, []);
  assert.equal(plan.reason, 'Verification failed. Nothing was written.');
});

const TAREFAS = join(dirname(fileURLToPath(import.meta.url)), '../../../solution/fixtures/finalize80/tarefas');

function tarefasDefs<T>(name: string): T {
  const source = readFileSync(join(TAREFAS, name), 'utf8');
  const json = extractNs4ClassicJsonObject(source);
  if (!json) throw new Error(`no JSON in ${name}`);
  return JSON.parse(json) as T;
}

function tarefasModule(): NrpModuleArtifacts {
  const journeyIndex = tarefasDefs<Ns5JourneyIndexArtifact>('journeys/index.defs.ts');
  const ontologyIndex = tarefasDefs<Ns5OntologyAnyIndex>('ontology/index.defs.ts');
  return {
    module: tarefasDefs<Ns5ModuleArtifact>('module.defs.ts'),
    journeyIndex,
    journeys: journeyIndex.journeys.map(entry => tarefasDefs<Ns5JourneyArtifact>(`journeys/${entry.journeyId}.defs.ts`)),
    ontologyIndex,
    entities: ns5OntologyEntityIds(ontologyIndex).map(entityId => tarefasDefs<Ns5OntologyAnyEntity>(`ontology/${entityId}.defs.ts`)),
    rules: tarefasDefs<Ns5RulesAny>('rules.defs.ts'),
    workflows: tarefasDefs<Ns5WorkflowsArtifact>('workflows.defs.ts'),
    access: tarefasDefs<Ns5AccessArtifact>('access.defs.ts'),
    integration: tarefasDefs<Ns5IntegrationArtifact>('integration.defs.ts'),
  };
}

function counts(issues: readonly NrpGateIssue[]): string {
  const byKind = new Map<string, number>();
  for (const issue of issues) byKind.set(issue.kind, (byKind.get(issue.kind) || 0) + 1);
  return [...byKind.entries()].map(([kind, count]) => `${kind}=${count}`).join(', ') || 'none';
}

void test('the tarefas fixture has no new gate error, and an edit that keeps it does not block', () => {
  const artifacts = tarefasModule();
  const baseline = checkNrpGates(artifacts, NRP_ARTIFACT_KINDS);
  const same = classifyNrpGateIssues(baseline, checkNrpGates(artifacts, NRP_ARTIFACT_KINDS));
  const fresh = nrpFreshIssues(same);
  assert.deepEqual(fresh, [], `new errors: ${fresh.map(issue => `${issue.kind} ${issue.code} ${issue.path}`).join('; ')}`);
  console.log(`[s3b] tarefas baseline ${baseline.length}: ${counts(baseline)}`);
  for (const issue of baseline) console.log(`[s3b] baseline ${issue.kind} ${issue.code} ${issue.path}`);
  const edited = applyNrpMechanical(artifacts, [
    { op: 'setScalar', targetId: 'Tarefa', fieldId: 'title', value: 'Tarefa' },
  ]).artifacts;
  const after = classifyNrpGateIssues(baseline, checkNrpGates(edited, NRP_ARTIFACT_KINDS));
  assert.equal(nrpFreshIssues(after).length, 0);
  assert.equal(nrpGateAction(after, ['ontology'], []).action, 'write');
  const journeyError: NrpGateIssue = {
    kind: 'coherence',
    code: 'I1',
    message: 'Unknown journey duplicarTarefa.',
    path: 'journeys/index.duplicarTarefa',
  };
  assert.equal(nrpIssueOwner(journeyError), 'journeys');
  const repairJourney = nrpGateAction([journeyError], ['rules', 'journeys'], []);
  assert.equal(repairJourney.action, 'repair');
  assert.equal(repairJourney.kind, 'journeys');
  const broken = tarefasModule();
  (broken.rules as { rules: Record<string, string> }).rules = { edicaoNaoMudaSituacao: 'Editar não muda a situação.' };
  broken.journeyIndex = {
    ...broken.journeyIndex,
    journeys: [...broken.journeyIndex.journeys, { journeyId: 'duplicarTarefa', actorRef: 'gestor', title: 'Duplicar' }],
  } as NrpModuleArtifacts['journeyIndex'];
  const scope = nrpFileScope(broken, 'journeys', {
    valid: true, reason: null, clarification: null, artifacts: ['rules', 'journeys'],
    targets: ['Tarefa', 'edicaoNaoMudaSituacao', 'duplicarTarefa'],
    intent: 'Duplicate a task.', mechanical: [], mechanicalOnly: false, assumptions: [],
  });
  const allowed = [...scope.present, ...scope.creates.filter(id => !scope.present.includes(id))];
  assert.equal(allowed.includes('duplicarTarefa'), true);
  assert.equal(allowed.includes('index'), true);
  assert.equal(allowed.includes('edicaoNaoMudaSituacao'), false);
  const human = buildNrpRepairHumanPrompt('Duplicate a task.', 'journeys', [journeyError], scope.files, allowed);
  assert.match(human, /Allowed files: .*duplicarTarefa/);
  assert.equal(human.includes('edicaoNaoMudaSituacao'), false);
  assert.equal(after.some(issue => issue.baseline), baseline.length > 0);
});

void test('a twin repair sees both journeys, and an index-only repair is refused', async () => {
  const artifacts = tarefasModule();
  const source = artifacts.journeys.find(journey => journey.journeyId === 'revisarTarefa');
  if (!source) throw new Error('revisarTarefa is missing from the tarefas fixture.');
  const clone = (id: string): Ns5JourneyArtifact => {
    const journey = JSON.parse(JSON.stringify(source)) as Ns5JourneyArtifact;
    journey.journeyId = id;
    journey.business.title = id;
    journey.business.steps = [
      ...journey.business.steps,
      { stepId: 'ver', kind: 'locate', entity: 'Tarefa', title: 'Ver', description: 'Localiza a tarefa.' },
    ];
    return journey;
  };
  artifacts.journeys.push(clone('cancelarTarefa'), clone('duplicarTarefa'));
  artifacts.journeyIndex = {
    ...artifacts.journeyIndex,
    journeys: [
      ...artifacts.journeyIndex.journeys,
      { journeyId: 'cancelarTarefa', actorRef: 'gestor', title: 'cancelarTarefa' },
      { journeyId: 'duplicarTarefa', actorRef: 'gestor', title: 'duplicarTarefa' },
    ],
  };
  const baseline = checkNrpGates(tarefasModule(), NRP_ARTIFACT_KINDS);
  const issues = classifyNrpGateIssues(baseline, checkNrpGates(artifacts, NRP_ARTIFACT_KINDS));
  const twin = nrpFreshIssues(issues).find(issue => issue.code === 'NS5_JOURNEY_TWIN');
  assert.ok(twin, nrpFreshIssues(issues).map(issue => `${issue.code} ${issue.message}`).join('; '));
  assert.match(twin.message, /cancelarTarefa/);
  assert.match(twin.message, /duplicarTarefa/);
  const catalog = nrpKindCatalog(artifacts, 'journeys');
  const human = buildNrpRepairHumanPrompt('The manager can duplicate a task.', 'journeys', issues, catalog);
  assert.match(human, /NS5_JOURNEY_TWIN/);
  assert.match(human, /cancelarTarefa, duplicarTarefa/);
  assert.match(human, /"journeyId":"cancelarTarefa"/);
  assert.match(human, /"journeyId":"duplicarTarefa"/);
  assert.match(human, /locate, inspect, act, decide, or handoff/);
  assert.match(human, /Do not invent a step kind/);
  let stored: unknown;
  const info = pipelineJsonFileForProject(1, 'sample', 'newReleasePrompt-refused');
  await recordNrpTriageRefusal(info, 'Pointer /journeys/14/business does not exist.', { operations: [] }, async (_file: Ns5FileInfo, value: unknown) => {
    stored = value;
  }, human);
  const recordedPrompt = (stored as { prompt: string }).prompt;
  assert.equal(recordedPrompt.includes('duplicarTarefa'), true);
  assert.equal(recordedPrompt.includes('Do not invent a step kind'), true);
  assert.equal(human.includes('Abrir uma tarefa e passar a vez para a execução.'), false);
  const recorded = {
    operations: [{
      file: 'duplicarTarefa',
      op: 'set',
      pointer: '/business/steps/2/entity',
      expectedJson: '"Tarefa"',
      valueJson: '"Lista"',
      reason: 'Change one cited journey so the pair no longer shares operations.',
    }],
  };
  const scope = { present: catalog.map(file => file.id), creates: [] as string[], files: catalog };
  const edited = normalizeNrpEdit('journeys', recorded, scope);
  assert.equal(edited.files.some(file => file.id === 'duplicarTarefa'), true);
  const next = {
    ...artifacts,
    journeys: artifacts.journeys.map(journey => {
      const hit = edited.files.find(file => file.id === journey.journeyId);
      return (hit ? hit.artifact : journey) as Ns5JourneyArtifact;
    }),
  };
  const fresh = nrpFreshIssues(classifyNrpGateIssues(baseline, checkNrpGates(next, NRP_ARTIFACT_KINDS)));
  assert.deepEqual(fresh.map(issue => `${issue.code} ${issue.path}: ${issue.message}`), []);
  const indexOnly = normalizeNrpEdit('journeys', {
    operations: [{
      file: 'index',
      op: 'add',
      pointer: '/journeys/-',
      expectedJson: '',
      valueJson: '{"journeyId":"outra","actorRef":"gestor","title":"Outra"}',
      reason: 'Repeat an index entry.',
    }],
  }, scope);
  const refusal = nrpIndexOnlyRepairMessage('journeys', [twin], indexOnly.files);
  assert.match(refusal || '', /Repair changed only the index/);
  assert.match(refusal || '', /one cited file/);
});

function repairRound(kind: NrpRepairRound['kind'], issues: readonly NrpGateIssue[]): NrpRepairRound {
  const owned = issues.filter(issue => nrpIssueOwner(issue) === kind);
  return { kind, keys: owned.map(nrpIssueKey), lines: nrpIssueLines(issues, kind) };
}

void test('a new error gets a second repair, the same error stops, and a third round never runs', () => {
  const twin: NrpGateIssue = {
    kind: 'coherence', code: 'NS5_JOURNEY_TWIN', message: 'Journeys are twins.', path: 'journeys',
  };
  const stepKind: NrpGateIssue = {
    kind: 'journeys', code: 'NS5_JOURNEY_STEP_KIND', message: 'Unknown step kind view.', path: 'journeys[0].steps[2].kind',
  };
  const changed: NrpGateIssue = {
    kind: 'journeys', code: 'NS5_OTHER', message: 'A different error.', path: 'journeys[0]',
  };
  assert.equal(nrpGateAction([stepKind], ['journeys'], [repairRound('journeys', [twin])]).action, 'repair');
  const same = nrpGateAction([stepKind], ['journeys'], [repairRound('journeys', [stepKind])]);
  assert.equal(same.action, 'stop');
  assert.match(same.reason, /same errors/);
  const third = nrpGateAction([changed], ['journeys'], [
    repairRound('journeys', [twin]),
    repairRound('journeys', [stepKind]),
  ]);
  assert.equal(third.action, 'stop');
  assert.match(third.reason, /2 rounds/);
  const kindCap = nrpGateAction(
    [{ kind: 'access', code: 'NS5_ACCESS', message: 'Grant is wrong.', path: 'grants[0]' }],
    ['rules', 'journeys', 'access'],
    [repairRound('rules', [twin]), repairRound('journeys', [stepKind])],
  );
  assert.equal(kindCap.action, 'stop');
  assert.match(kindCap.reason, /2 artifact kinds/);
  const human = buildNrpRepairHumanPrompt(
    'The manager can duplicate a task.',
    'journeys',
    [stepKind],
    [{ id: 'duplicarTarefa', artifact: { journeyId: 'duplicarTarefa' } }],
    [],
    null,
    nrpIssueLines([twin], 'journeys'),
  );
  assert.match(human, /NS5_JOURNEY_TWIN/);
  assert.match(human, /NS5_JOURNEY_STEP_KIND/);
  assert.match(human, /error set changed/);
  const report = nrpReport({
    moduleName: 'tarefas', project: 1, request: 'Duplicate.',
    triage: {
      valid: true, reason: null, clarification: null, artifacts: ['journeys'], targets: [],
      intent: 'Duplicate.', mechanical: [], mechanicalOnly: false, assumptions: [],
    },
    artifacts: tarefasModule(), applied: [], issues: [], allowWrite: true, modelCalls: 2,
    repairRounds: [repairRound('journeys', [twin]), repairRound('journeys', [stepKind])],
  }, { written: true, reason: null, files: [] });
  assert.deepEqual(report.repairRounds, { journeys: 2 });
  assert.deepEqual(nrpRepairRoundCounts([repairRound('rules', [twin])]), { rules: 1 });

  const artifacts = tarefasModule();
  const source = artifacts.journeys.find(journey => journey.journeyId === 'revisarTarefa');
  if (!source) throw new Error('revisarTarefa is missing from the tarefas fixture.');
  const clone = (id: string): Ns5JourneyArtifact => {
    const journey = JSON.parse(JSON.stringify(source)) as Ns5JourneyArtifact;
    journey.journeyId = id;
    journey.business.title = id;
    journey.business.steps = [
      ...journey.business.steps,
      { stepId: 'ver', kind: 'locate', entity: 'Tarefa', title: 'Ver', description: 'Localiza a tarefa.' },
    ];
    return journey;
  };
  artifacts.journeys.push(clone('cancelarTarefa'), clone('duplicarTarefa'));
  artifacts.journeyIndex = {
    ...artifacts.journeyIndex,
    journeys: [
      ...artifacts.journeyIndex.journeys,
      { journeyId: 'cancelarTarefa', actorRef: 'gestor', title: 'cancelarTarefa' },
      { journeyId: 'duplicarTarefa', actorRef: 'gestor', title: 'duplicarTarefa' },
    ],
  };
  const baseline = checkNrpGates(tarefasModule(), NRP_ARTIFACT_KINDS);
  const catalog = nrpKindCatalog(artifacts, 'journeys');
  const scope = { present: catalog.map(file => file.id), creates: [] as string[], files: catalog };
  const withView = applyJourneyOps(artifacts, scope, [{
    file: 'duplicarTarefa', op: 'set', pointer: '/business/steps/2/kind',
    expectedJson: '"locate"', valueJson: '"view"', reason: 'A first repair that trades the twin for a bad kind.',
  }]);
  const afterView = nrpFreshIssues(classifyNrpGateIssues(baseline, checkNrpGates(withView, NRP_ARTIFACT_KINDS)));
  assert.equal(afterView.some(issue => issue.code === 'NS5_JOURNEY_STEP_KIND'), true);
  assert.equal(afterView.some(issue => issue.code === 'NS5_JOURNEY_TWIN'), false);
  const round2 = nrpGateAction(afterView, ['journeys'], [repairRound('journeys', [twin])]);
  assert.equal(round2.action, 'repair');
  const viewed = nrpKindCatalog(withView, 'journeys');
  const fixed = applyJourneyOps(withView, {
    present: viewed.map(file => file.id),
    creates: [],
    files: viewed,
  }, [
    {
      file: 'duplicarTarefa', op: 'set', pointer: '/business/steps/2/kind',
      expectedJson: '"view"', valueJson: '"locate"', reason: 'Restore a known step kind.',
    },
    {
      file: 'duplicarTarefa', op: 'set', pointer: '/business/steps/2/entity',
      expectedJson: '"Tarefa"', valueJson: '"Lista"', reason: 'Separate the operations of one cited journey.',
    },
  ]);
  const left = nrpFreshIssues(classifyNrpGateIssues(baseline, checkNrpGates(fixed, NRP_ARTIFACT_KINDS)));
  assert.deepEqual(left.map(issue => `${issue.code} ${issue.path}`), []);
  assert.equal(nrpGateAction(left, ['journeys'], [
    repairRound('journeys', [twin]),
    repairRound('journeys', afterView),
  ]).action, 'write');
});

void test('a step-kind error names the journey file and the pointer inside it', () => {
  const artifacts = tarefasModule();
  const source = artifacts.journeys.find(journey => journey.journeyId === 'revisarTarefa');
  if (!source) throw new Error('revisarTarefa is missing from the tarefas fixture.');
  const journey = JSON.parse(JSON.stringify(source)) as Ns5JourneyArtifact;
  journey.journeyId = 'duplicarTarefa';
  journey.business.title = 'Duplicar tarefa';
  journey.business.steps = [
    ...journey.business.steps,
    { stepId: 'ver', kind: 'view', entity: 'Tarefa', title: 'Ver', description: 'Mostra a tarefa.' },
  ];
  artifacts.journeys.push(journey);
  const baseline = checkNrpGates(tarefasModule(), NRP_ARTIFACT_KINDS);
  const issues = nrpFreshIssues(classifyNrpGateIssues(baseline, checkNrpGates(artifacts, NRP_ARTIFACT_KINDS)));
  const stepKind = issues.find(issue => issue.code === 'NS5_JOURNEY_STEP_KIND');
  assert.ok(stepKind, issues.map(issue => `${issue.code} ${issue.path}`).join('; '));
  const catalog = nrpKindCatalog(artifacts, 'journeys');
  const human = buildNrpRepairHumanPrompt('The manager can duplicate a task.', 'journeys', issues, catalog);
  assert.match(human, /NS5_JOURNEY_STEP_KIND file: duplicarTarefa pointer: \/business\/steps\/2\/kind/);
  assert.match(human, /inside the named file/);
  const scope = { present: catalog.map(file => file.id), creates: [] as string[], files: catalog };
  let refused = '';
  try {
    normalizeNrpEdit('journeys', {
      operations: [{
        file: 'index',
        op: 'set',
        pointer: '/journeys/14/business',
        expectedJson: '{}',
        valueJson: '{}',
        reason: 'Edit the kind path.',
      }],
    }, scope);
  } catch (error) {
    assert.ok(error instanceof NrpEditRefusal);
    refused = nrpAnnotateRepairRefusal('journeys', issues, catalog, error.message);
  }
  assert.match(refused, /does not exist/);
  assert.match(refused, /Expected file: duplicarTarefa pointer: \/business\/steps\/2\/kind/);
});

void test('fieldsOnly hold ends the task with the question alone and no step waits for a human', () => {
  const question = 'Quem deve ver o campo Mesa.details.statusAtendimento? Nenhuma jornada do ator Garçom usa Mesa.';
  const intents = fieldsOnlyHold(
    { messageId: 'm', threadId: 't', taskId: 'task', parentStepId: 1 },
    { stepId: 4 } as mls.msg.AIAgentStep,
    2,
    question,
  );
  const steps = intents.filter(intent => intent.type === 'add-step').map(intent => intent.step);
  assert.equal(steps.some(step => step.type === 'clarification'), false);
  assert.equal(steps.some(step => step.status === 'waiting_human_input'), false);
  const result = steps.find(step => step.type === 'result');
  assert.deepEqual(JSON.parse(String(result && 'result' in result ? result.result : '')), { written: false, summary: question });
  assert.equal(steps.some(step => step.planning?.planId === 'write50'), false);
});

function applyJourneyOps(
  artifacts: NrpModuleArtifacts,
  scope: { present: string[]; creates: string[]; files: { id: string; artifact: unknown }[] },
  operations: Array<{ file: string; op: string; pointer: string; expectedJson: string; valueJson: string; reason: string }>,
): NrpModuleArtifacts {
  const edited = normalizeNrpEdit('journeys', { operations }, scope);
  return {
    ...artifacts,
    journeys: artifacts.journeys.map(journey => {
      const hit = edited.files.find(file => file.id === journey.journeyId);
      return (hit ? hit.artifact : journey) as Ns5JourneyArtifact;
    }),
  };
}
