/// <mls fileReference="_102035_/l2/agentReviewSolution/steps/review20/review20.test.ts" enhancement="_blank" />

import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import {
  recordReview20Refusal,
  REVIEW20_SCHEMA_VERSION,
  review20ClipNote,
  review20RefusalInfo,
  Review20ParseRefusal,
  stageReview20,
} from './review20.js';

const snapshot = { moduleName: 'agendaClinica', request: 'Use a clearer appointment label.', requestRevision: 2 };
const persisted = { revision: 2, request: snapshot.request };
const base = {
  'module.defs.ts': { moduleName: 'agendaClinica', schemaVersion: 'v1', title: 'Agenda', moduleId: 'mod-1', untouched: 'keep' },
  'journeys/index.defs.ts': { moduleName: 'agendaClinica', journeys: [{ journeyId: 'j-1', title: 'Mark visit' }] },
};
const candidate = {
  'module.defs.ts': { ...base['module.defs.ts'], title: 'Visit calendar' },
  'journeys/index.defs.ts': base['journeys/index.defs.ts'],
};

function applyResponse(overrides: Record<string, unknown> = {}) {
  return {
    schemaVersion: REVIEW20_SCHEMA_VERSION, decision: 'apply', clarification: '',
    operations: [{ artifactPath: 'module.defs.ts', op: 'replace', pointer: '/title',
      basis: 'refine-candidate-edit',
      expectedJson: '"Visit calendar"', valueJson: '"Appointments"', reason: 'Match the requested terminology.' }],
    ...overrides,
  };
}

test('review20 stages a bounded scalar correction and keeps input, IDs and unrelated artifacts intact', () => {
  const before = JSON.stringify(candidate);
  const result = stageReview20(snapshot, persisted, base, candidate, applyResponse());
  assert.equal(result.status, 'staged');
  assert.equal((result.proposal['module.defs.ts'] as { title: string }).title, 'Appointments');
  assert.equal(JSON.stringify(candidate), before);
  assert.deepEqual(result.proposal['journeys/index.defs.ts'], candidate['journeys/index.defs.ts']);
  assert.equal((result.proposal['module.defs.ts'] as { moduleId: string }).moduleId, 'mod-1');
  assert.deepEqual(Object.keys(result.explicitDiff), ['module.defs.ts']);
  assert.deepEqual(Object.keys(result.operationDiff), ['module.defs.ts']);
  assert.deepEqual(Object.keys(result.proposedDiff), ['module.defs.ts']);
});

test('review20 can stage the first scalar change when the candidate still equals the base', () => {
  const unchangedCandidate = JSON.parse(JSON.stringify(base)) as typeof base;
  const response = applyResponse({ operations: [{
    artifactPath: 'module.defs.ts', op: 'replace', pointer: '/title', basis: 'base-unchanged',
    expectedJson: '"Agenda"', valueJson: '"Appointments"', reason: 'Apply the persisted simple request.',
  }] });
  const result = stageReview20(snapshot, persisted, base, unchangedCandidate, response);
  assert.equal(result.status, 'staged');
  assert.equal((result.proposal['module.defs.ts'] as { title: string }).title, 'Appointments');
  assert.deepEqual(result.explicitDiff, {});
  assert.deepEqual(Object.keys(result.operationDiff), ['module.defs.ts']);
});

test('review20 protects a divergent manual field from a base-unchanged operation', () => {
  const response = applyResponse({ operations: [{
    artifactPath: 'module.defs.ts', op: 'replace', pointer: '/title', basis: 'base-unchanged',
    expectedJson: '"Visit calendar"', valueJson: '"Appointments"', reason: 'Apply initial wording.',
  }] });
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, response), /manual candidate edit conflict/);
});

test('review20 preserves an existing manual edit while changing another base-equal field', () => {
  const response = applyResponse({ operations: [{
    artifactPath: 'module.defs.ts', op: 'replace', pointer: '/untouched', basis: 'base-unchanged',
    expectedJson: '"keep"', valueJson: '"requested value"', reason: 'Apply the separate requested wording.',
  }] });
  const result = stageReview20(snapshot, persisted, base, candidate, response);
  assert.equal((result.proposal['module.defs.ts'] as { title: string }).title, 'Visit calendar');
  assert.equal((result.proposal['module.defs.ts'] as { untouched: string }).untouched, 'requested value');
});

test('review20 accepts a real PascalCase ontology entity path', () => {
  const entityBase = { ...base, 'ontology/Consulta.defs.ts': { entityId: 'Consulta', title: 'Consulta' } };
  const entityCandidate = JSON.parse(JSON.stringify(entityBase)) as typeof entityBase;
  const response = applyResponse({ operations: [{
    artifactPath: 'ontology/Consulta.defs.ts', op: 'replace', pointer: '/title', basis: 'base-unchanged',
    expectedJson: '"Consulta"', valueJson: '"Appointment"', reason: 'Apply the persisted terminology request.',
  }] });
  const result = stageReview20(snapshot, persisted, entityBase, entityCandidate, response);
  assert.equal((result.proposal['ontology/Consulta.defs.ts'] as { title: string }).title, 'Appointment');
});

test('review20 rejects an unsafe artifact path', () => {
  const unsafeBase = { ...base, 'ontology/../Consulta.defs.ts': { entityId: 'Consulta', title: 'Consulta' } };
  const unsafeCandidate = JSON.parse(JSON.stringify(unsafeBase)) as typeof unsafeBase;
  assert.throws(() => stageReview20(snapshot, persisted, unsafeBase, unsafeCandidate, applyResponse()), /invalid artifact path/);
});

test('review20 cuts a long clarification to a whole sentence and keeps a null or an apply question as a refusal', async () => {
  const sentence = 'Which label should clinicians see? ';
  const long = `${sentence}${'Extra detail. '.repeat(80)}`;
  assert.ok(long.length > 1000);
  const clipped = stageReview20(snapshot, persisted, base, candidate, {
    schemaVersion: REVIEW20_SCHEMA_VERSION, decision: 'clarification', clarification: long, operations: [],
  });
  assert.equal(clipped.status, 'clarification');
  assert.ok(clipped.clarification.length <= 1000);
  assert.ok(clipped.clarification.length < long.trim().length);
  assert.ok(long.trim().startsWith(clipped.clarification));
  assert.match(clipped.clarification, /[.?!]$/u);
  assert.match(review20ClipNote(clipped) || '', /cut to a whole sentence/u);

  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, {
    schemaVersion: REVIEW20_SCHEMA_VERSION, decision: 'clarification', clarification: null, operations: [],
  }), (error: unknown) => error instanceof Review20ParseRefusal
    && error.message === 'invalid clarification'
    && (error.raw as { clarification: unknown }).clarification === null);

  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, applyResponse({ clarification: 'Ask anyway.' })),
    (error: unknown) => error instanceof Review20ParseRefusal && /no clarification/u.test(error.message));

  const info = review20RefusalInfo(102047, 'agendaClinica');
  let written: unknown;
  const citation = await recordReview20Refusal(info, 'invalid clarification', { clarification: null, apiKey: 'sk-secret' }, async (_file, value) => {
    written = value;
  });
  assert.equal(citation, 'l4/agendaClinica/pipeline/review20-refused.json');
  assert.equal((written as { raw: { apiKey: string } }).raw.apiKey, '[redacted]');

  const prompt = readFileSync(new URL('./prompt.md', import.meta.url), 'utf8');
  const schema = readFileSync(new URL('../../schemas/review20.schema.json', import.meta.url), 'utf8');
  assert.match(prompt, /at most 1000 characters/u);
  assert.match(prompt, /clarification` is `""`/u);
  assert.match(schema, /at most 1000 characters/u);
  assert.equal(schema.includes('"maxLength"'), false);
});

test('review20 returns business ambiguity as a question without proposing an edit', () => {
  const result = stageReview20(snapshot, persisted, base, candidate, {
    schemaVersion: REVIEW20_SCHEMA_VERSION, decision: 'clarification',
    clarification: 'Which label should appear to clinicians?', operations: [],
  });
  assert.equal(result.status, 'clarification');
  assert.deepEqual(result.proposal, candidate);
  assert.deepEqual(result.operationDiff, {});
});

test('review20 rejects request detached from the sealed revision', () => {
  assert.throws(() => stageReview20(snapshot, { ...persisted, request: 'Another request' }, base, candidate, applyResponse()), /persisted candidate revision/);
  assert.throws(() => stageReview20(snapshot, { ...persisted, revision: 1 }, base, candidate, applyResponse()), /persisted candidate revision/);
  assert.throws(() => stageReview20({ ...snapshot, requestRevision: 0 }, persisted, base, candidate, applyResponse()), /persisted candidate revision/);
});

test('review20 rejects stale values, identity edits, invalid or blank output', () => {
  const operation = applyResponse().operations[0];
  const withOperation = (patch: Record<string, unknown>) => applyResponse({ operations: [{ ...operation, ...patch }] });
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, withOperation({ expectedJson: '"old"' })), /stale/);
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, withOperation({ pointer: '/moduleId', expectedJson: '"mod-1"' })), /identity/);
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, withOperation({ valueJson: '"  "' })), /nonblank/);
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, withOperation({ valueJson: '{"x":1}' })), /scalar/);
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, withOperation({ valueJson: '"Visit calendar"' })), /no-op/);
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, withOperation({ artifactPath: 'other/module.defs.ts' })), /invalid artifact path/);
});

test('mr_18 s1 strips the owning module root and applies the relative artifact path', () => {
  const snap = { moduleName: 'controleEstoque', request: snapshot.request, requestRevision: 2 };
  const rulesBase = { 'rules.defs.ts': { moduleName: 'controleEstoque', title: 'Estoque' } };
  const rulesCandidate = { 'rules.defs.ts': { ...rulesBase['rules.defs.ts'], title: 'Controle' } };
  const response = applyResponse({ operations: [{
    artifactPath: 'l4/controleEstoque/rules.defs.ts', op: 'replace', pointer: '/title',
    basis: 'refine-candidate-edit',
    expectedJson: '"Controle"', valueJson: '"Inventário"', reason: 'Use the requested label.',
  }] });
  const result = stageReview20(snap, persisted, rulesBase, rulesCandidate, response);
  assert.equal(result.status, 'staged');
  assert.equal((result.proposal['rules.defs.ts'] as { title: string }).title, 'Inventário');
});

test('mr_18 s1 rejects another module root and a path that escapes after the prefix', () => {
  const snap = { moduleName: 'controleEstoque', request: snapshot.request, requestRevision: 2 };
  const rulesBase = { 'rules.defs.ts': { moduleName: 'controleEstoque', title: 'Estoque' } };
  const rulesCandidate = { 'rules.defs.ts': { ...rulesBase['rules.defs.ts'], title: 'Controle' } };
  const operation = {
    artifactPath: 'rules.defs.ts', op: 'replace', pointer: '/title', basis: 'refine-candidate-edit',
    expectedJson: '"Controle"', valueJson: '"Inventário"', reason: 'Use the requested label.',
  };
  assert.throws(() => stageReview20(snap, persisted, rulesBase, rulesCandidate, applyResponse({
    operations: [{ ...operation, artifactPath: 'l4/outroModulo/rules.defs.ts' }],
  })), /invalid artifact path/);
  assert.throws(() => stageReview20(snap, persisted, rulesBase, rulesCandidate, applyResponse({
    operations: [{ ...operation, artifactPath: 'l4/controleEstoque/../x.defs.ts' }],
  })), /invalid artifact path/);
});

test('review20 rejects unknown response fields, malformed JSON pointers, duplicate operations and other module', () => {
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, applyResponse({ approved: true })), /unexpected fields/);
  const operation = applyResponse().operations[0];
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, applyResponse({ operations: [{ ...operation, pointer: '/~2title' }] })), /pointer escape/);
  assert.throws(() => stageReview20(snapshot, persisted, base, candidate, applyResponse({ operations: [operation, operation] })), /duplicate/);
  assert.throws(() => stageReview20(snapshot, persisted, base, { ...candidate, 'module.defs.ts': { ...candidate['module.defs.ts'], moduleName: 'other' } }, applyResponse()), /another module/);
  const withNewJourney = {
    ...candidate,
    'journeys/newJourney.defs.ts': { moduleName: 'agendaClinica', journeyId: 'newJourney' },
  };
  const staged = stageReview20(snapshot, persisted, base, withNewJourney, applyResponse());
  assert.equal(staged.status, 'staged');
  assert.ok(staged.explicitDiff['journeys/newJourney.defs.ts']?.some(entry => entry.before === undefined && entry.after !== undefined));
});
