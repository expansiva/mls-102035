declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4BuildStamp" {
    /**
     * A per-agent COPY of the same ~60 pure lines that live in agentChangeBackend and agentChangeFrontend.
     * Deliberate: importing one agent's helper from another inside 102020 would couple two independent
     * pipelines, and the previous round already decided against promoting this to a shared project.
     *
     * PROVENANCE of the running agent code: WHICH version of this agent produced this run.
     *
     * Not "is it stale?" — that question cannot be answered from inside the agent, and asking it produced a
     * wrong diagnosis once already. What happened on 2026-08-22 (run cb-run-…01-34-27, agentChangeBackend): the MDM F1 was in
     * nobody's build because it had never been committed. The `obj/compiled.zip` in play was perfectly
     * CONSISTENT — its `fileinfos.json` and its `.js` both sat on commit 308ab97 — and the run executed the
     * last PUBLISHED build, correctly. Measured, not argued (on the agentChangeBackend of the incident): the build recorded
     * `1ef6d903…` for one of its sources, exactly `git rev-parse 308ab97:<path>`, while the working copy on
     * the author's disk hashed to `5691b296…`. There was no build bug and nothing
     * to "recompile": what puts code on the platform is commit + push (the `build.yml` Action compiles and
     * commits `obj/compiled.zip`).
     *
     * So the useful line in a trace is not an alarm, it is an IDENTITY a human can match with git.
     *
     * WHAT THIS CANNOT DO — by construction, not by omission:
     *   - It cannot see work that was never committed and pushed: the platform has never seen it. No
     *     measurement from inside the agent finds it, by timestamp or by hash.
     *   - It cannot tell whether the built `.js` matches the `.ts` of the same commit. That would be a bug in
     *     the Action, and the place to catch it is there.
     *   - It is NOT a gate: it never blocks, never fails a run, and emits no warning. A source being edited
     *     locally is the NORMAL state of whoever is editing (a file "in development" keeps its local version
     *     instead of the build's `.js` — `cfe-collab-front-end/src/stor/stor.server.ts`), so treating that as
     *     an anomaly would be noise, not signal.
     */
    /** The project this agent's code lives in. */
    export const NS4_AGENT_PROJECT = 102035;
    /** Only this agent's own sources: another folder's version says nothing about which agent ran. */
    export const NS4_AGENT_SOURCE_PREFIX = "l2/agentNewSolution/";
    /**
     * The files a human checks first, in `git`. Kept short on purpose — the digest already covers everything;
     * these exist so a reader has something to paste into `git rev-parse <commit>:<path>` without unzipping.
     */
    export const NS4_BUILD_ANCHORS: readonly string[];
    /** One entry of the build's own manifest (`fileinfos.json` inside obj/compiled.zip). */
    export interface AgentBuildFile {
        shortPath: string;
        /** git blob OID of the source AT THE BUILD COMMIT. Verified: equals `git hash-object <file>`. */
        versionRef: string;
    }
    export interface AgentProvenance {
        project: number;
        /**
         * Stable digest of the agent's `shortPath:versionRef` pairs. Two runs with the same buildRef executed
         * the same code; different buildRefs executed different code. Match a single file with
         * `git rev-parse <commit>:<path>` (or `git hash-object <file>` for a working copy).
         */
        buildRef: string;
        /** How many of this agent's sources went into the digest. */
        files: number;
        /** versionRef per anchor file; `absent` when the manifest has no entry (e.g. a file never committed). */
        anchors: Record<string, string>;
        /**
         * Last push registered on the project. NOT the build time: the platform webhook writes it on every
         * push (`cbe-collab-back-end/.../executeOnProjectUpdated.ts`) and the backend uses it to invalidate the
         * zip cache, so a push that produces no new build already moves it.
         */
        lastPushAt: string | null;
        /** How many of this agent's sources are being edited locally. Informational: this is normal. */
        localEdits: number;
        error?: string;
    }
    /**
     * FNV-1a over the sorted `shortPath:versionRef` pairs. Local and pure on purpose: the digest has to be
     * reproducible in a test without a platform, and it only has to be stable, not cryptographic.
     */
    export function digestBuildFiles(files: readonly AgentBuildFile[]): string;
    /**
     * PURE. Builds the provenance from the manifest the browser already holds.
     *
     * The manifest is the right source precisely BECAUSE it is not perturbed by local editing: it is what
     * the build recorded. `mls.stor.files[].versionRef` is not usable here — a locally created file is
     * stamped `'0'` by `createStorFile`, so a digest over it would change as soon as anyone edits.
     */
    export function buildProvenance(project: number, files: readonly AgentBuildFile[], options: {
        prefix: string;
        anchors: readonly string[];
        lastPushAt?: string | null;
        localEdits?: number;
        error?: string;
    }): AgentProvenance;
    /** The one line a trace carries. No warning path: there is no measured signal that warrants one. */
    export function describeProvenance(provenance: AgentProvenance | null): string;
    /**
     * Read the provenance of the running agent. Fail-soft by contract: any throw becomes an empty
     * `buildRef` plus the reason, and never touches the run.
     */
    export function readAgentProvenance(project?: number): Promise<AgentProvenance>;
    /**
     * One line for a step trace. Informational by contract — there is no warning path here (see the
     * header): the stamp records WHICH code ran, it does not judge it. Do not print to the console
     * (ns_console_limpo): the dossier and the step status already carry it.
     */
    export function agentBuildTrace(logPrefix: string): Promise<string>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4WidgetPhrases" {
    /**
     * English catalogue slice for the E1-E6 clarification widgets.
     * Merged into NS4_PHRASES so the root planner translates widget chrome once per run.
     */
    export const NS4_WIDGET_PHRASES: {
        readonly 'widget.intake.adjustmentRequired': "Describe what should change before generating another proposal.";
        readonly 'widget.intake.processingApproval': "Validating initial definition…";
        readonly 'widget.intake.processingChanges': "Preparing a new review…";
        readonly 'widget.intake.processingCancel': "Cancelling execution…";
        readonly 'widget.intake.revise': "Review the items below";
        readonly 'widget.intake.cancel': "Cancel execution";
        readonly 'widget.intake.cancelTitle': "Cancel this execution?";
        readonly 'widget.intake.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.intake.keepWorking': "Keep working";
        readonly 'widget.journeys.subtitle': "These journeys will become the permanent source of truth for the product.";
        readonly 'widget.journeys.actor': "Actor";
        readonly 'widget.journeys.goal': "Goal";
        readonly 'widget.journeys.steps': "Steps";
        readonly 'widget.journeys.rules': "Rules";
        readonly 'widget.journeys.outcome': "Outcome and evidence";
        readonly 'widget.journeys.filters': "Filters";
        readonly 'widget.journeys.impact': "Impact";
        readonly 'widget.journeys.noPolicyDecision': "No policy decision was provided for this journey.";
        readonly 'widget.journeys.journeys': "Journeys";
        readonly 'widget.journeys.journeysFound': "journeys found";
        readonly 'widget.journeys.selectJourney': "Select a journey to review.";
        readonly 'widget.journeys.allActors': "All actors";
        readonly 'widget.journeys.actorMap': "Journey map by actor";
        readonly 'widget.journeys.actors': "actors";
        readonly 'widget.journeys.overview': "Overview";
        readonly 'widget.journeys.actual': "(actual)";
        readonly 'widget.journeys.rulesHelp': "Rules that must remain true in every execution of this journey.";
        readonly 'widget.journeys.adjustment': "What should change?";
        readonly 'widget.journeys.placeholder': "Describe the needed change without rewriting what is already correct.";
        readonly 'widget.journeys.requestChanges': "Request changes";
        readonly 'widget.journeys.approve': "Approve journeys";
        readonly 'widget.journeys.round': "Review";
        readonly 'widget.journeys.step': "Step";
        readonly 'widget.journeys.of': "of";
        readonly 'widget.journeys.adjustmentRequired': "Describe what must change before requesting another version.";
        readonly 'widget.journeys.processingApproval': "Validating journeys…";
        readonly 'widget.journeys.processingChanges': "Preparing a new review…";
        readonly 'widget.journeys.processingCancel': "Cancelling execution…";
        readonly 'widget.journeys.revise': "Review the items below";
        readonly 'widget.journeys.cancel': "Cancel execution";
        readonly 'widget.journeys.cancelTitle': "Cancel this execution?";
        readonly 'widget.journeys.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.journeys.keepWorking': "Keep working";
        readonly 'widget.journeys.assumedDecisions': "Assumed decisions";
        readonly 'widget.journeys.changeHint': "How to change later";
        readonly 'widget.accessMatrix.subtitle': "Review who may perform each capability and exactly which information may be disclosed.";
        readonly 'widget.accessMatrix.step': "Step";
        readonly 'widget.accessMatrix.of': "of";
        readonly 'widget.accessMatrix.round': "Review";
        readonly 'widget.accessMatrix.profiles': "Access profiles";
        readonly 'widget.accessMatrix.internal': "Internal";
        readonly 'widget.accessMatrix.external': "External";
        readonly 'widget.accessMatrix.actors': "E2 actors";
        readonly 'widget.accessMatrix.landing': "Starting point";
        readonly 'widget.accessMatrix.matrix': "Profile × authority matrix";
        readonly 'widget.accessMatrix.profileAccess': "Authorities for this profile";
        readonly 'widget.accessMatrix.authority': "Authority";
        readonly 'widget.accessMatrix.noAccess': "No access";
        readonly 'widget.accessMatrix.full': "Full record";
        readonly 'widget.accessMatrix.limited': "Limited";
        readonly 'widget.accessMatrix.details': "Access details";
        readonly 'widget.accessMatrix.reason': "Business reason";
        readonly 'widget.accessMatrix.scope': "Data scope";
        readonly 'widget.accessMatrix.disclosure': "Disclosure boundary";
        readonly 'widget.accessMatrix.allowed': "May expose";
        readonly 'widget.accessMatrix.denied': "Must not expose";
        readonly 'widget.accessMatrix.ruleRefs': "Rule references";
        readonly 'widget.accessMatrix.journeySteps': "Journey steps";
        readonly 'widget.accessMatrix.informationNeeds': "Information needs";
        readonly 'widget.accessMatrix.close': "Close";
        readonly 'widget.accessMatrix.adjustment': "What should change?";
        readonly 'widget.accessMatrix.placeholder': "Example: Add authority to view project budgets; some clients may see a summary without seeing the whole project.";
        readonly 'widget.accessMatrix.requestChanges': "Generate another proposal";
        readonly 'widget.accessMatrix.approve': "Approve access matrix";
        readonly 'widget.accessMatrix.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.accessMatrix.empty': "No access matrix available.";
        readonly 'widget.accessMatrix.processingApproval': "Validating access matrix…";
        readonly 'widget.accessMatrix.processingChanges': "Preparing a new review…";
        readonly 'widget.accessMatrix.processingCancel': "Cancelling execution…";
        readonly 'widget.accessMatrix.revise': "Review the items below";
        readonly 'widget.accessMatrix.cancel': "Cancel execution";
        readonly 'widget.accessMatrix.cancelTitle': "Cancel this execution?";
        readonly 'widget.accessMatrix.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.accessMatrix.keepWorking': "Keep working";
        readonly 'widget.ontology.subtitle': "Review the business data, constraints and relationships that frontend and backend will share.";
        readonly 'widget.ontology.step': "Step";
        readonly 'widget.ontology.of': "of";
        readonly 'widget.ontology.round': "Review";
        readonly 'widget.ontology.mode': "New solution";
        readonly 'widget.ontology.changes': "Changes in this round";
        readonly 'widget.ontology.entities': "Entities";
        readonly 'widget.ontology.fields': "Fields";
        readonly 'widget.ontology.relationships': "Relationships";
        readonly 'widget.ontology.lifecycle': "Lifecycle";
        readonly 'widget.ontology.ruleRefs': "Rule references";
        readonly 'widget.ontology.overview': "Overview";
        readonly 'widget.ontology.descriptions': "Descriptions";
        readonly 'widget.ontology.source': "Traceability";
        readonly 'widget.ontology.storage': "Persistence destination";
        readonly 'widget.ontology.required': "Required";
        readonly 'widget.ontology.optional': "Optional";
        readonly 'widget.ontology.constraints': "Field rules";
        readonly 'widget.ontology.persistenceMap': "Persistence map";
        readonly 'widget.ontology.persistenceHint': "Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.";
        readonly 'widget.ontology.targetMdm': "MDM · base records";
        readonly 'widget.ontology.targetModuleDatabase': "Module database · transactions";
        readonly 'widget.ontology.targetDerived': "Derived · no own table";
        readonly 'widget.ontology.targetExternal': "External · platform owned";
        readonly 'widget.ontology.targetEmbedded': "Embedded · owned value";
        readonly 'widget.ontology.scope': "Scope";
        readonly 'widget.ontology.mdmType': "MDM type";
        readonly 'widget.ontology.idField': "Identifier";
        readonly 'widget.ontology.reason': "Reason";
        readonly 'widget.ontology.fieldRulesHint': "Click a field name or description to edit it in place.";
        readonly 'widget.ontology.crossStore': "Cross-store";
        readonly 'widget.ontology.sourceRelationships': "As origin";
        readonly 'widget.ontology.destinationRelationships': "As destination";
        readonly 'widget.ontology.noRelationships': "No relationships for this table.";
        readonly 'widget.ontology.implementation': "Field binding";
        readonly 'widget.ontology.editInPlace': "Click to edit";
        readonly 'widget.ontology.direct': "Direct description edits";
        readonly 'widget.ontology.directHint': "Titles and descriptions are safe to edit here. Structural changes use the separate request panel.";
        readonly 'widget.ontology.entityTitle': "Entity title";
        readonly 'widget.ontology.entityDescription': "Entity description";
        readonly 'widget.ontology.fieldTitle': "Field title";
        readonly 'widget.ontology.fieldDescription': "Field description";
        readonly 'widget.ontology.structural': "What should change?";
        readonly 'widget.ontology.structuralHint': "Use the LLM for entities, fields, types, relationships, lifecycle or constraints.";
        readonly 'widget.ontology.placeholder': "Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.";
        readonly 'widget.ontology.request': "Generate another proposal";
        readonly 'widget.ontology.approve': "Approve ontology";
        readonly 'widget.ontology.requiredAdjustment': "Describe the structural change first.";
        readonly 'widget.ontology.empty': "No ontology proposal available.";
        readonly 'widget.ontology.processingApproval': "Validating ontology…";
        readonly 'widget.ontology.processingChanges': "Preparing a new review…";
        readonly 'widget.ontology.processingCancel': "Cancelling execution…";
        readonly 'widget.ontology.revise': "Review the items below";
        readonly 'widget.ontology.cancel': "Cancel execution";
        readonly 'widget.ontology.cancelTitle': "Cancel this execution?";
        readonly 'widget.ontology.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.ontology.keepWorking': "Keep working";
        readonly 'widget.ontology.assumedDecisions': "Assumed decisions";
        readonly 'widget.ontology.changeHint': "How to change later";
        readonly 'widget.rules.step': "👤 Step 5 of 6 — Business rules";
        readonly 'widget.rules.review': "Review";
        readonly 'widget.rules.rules': "rules";
        readonly 'widget.rules.search': "Search by ID or description";
        readonly 'widget.rules.noRule': "No rules found.";
        readonly 'widget.rules.adjustment': "What should change?";
        readonly 'widget.rules.placeholder': "Example: change clientAvailable to allow only one active client per project.";
        readonly 'widget.rules.request': "Generate another proposal";
        readonly 'widget.rules.approve': "Approve rules";
        readonly 'widget.rules.cancel': "Cancel execution";
        readonly 'widget.rules.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.rules.processingApproval': "Validating rules…";
        readonly 'widget.rules.processingChanges': "Preparing another review…";
        readonly 'widget.rules.processingCancel': "Cancelling execution…";
        readonly 'widget.rules.revise': "Review the items below";
        readonly 'widget.rules.cancelTitle': "Cancel this execution?";
        readonly 'widget.rules.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.rules.keepWorking': "Keep working";
        readonly 'widget.rules.hint': "Each permanent rule contains only a stable ID and one business description.";
        readonly 'widget.rules.edit': "Click to edit the description";
        readonly 'widget.composition.step': "👤 Step 6 of 6 — Additional modules and plugins";
        readonly 'widget.composition.review': "Review";
        readonly 'widget.composition.empty': "No additional horizontal module or plugin was recommended.";
        readonly 'widget.composition.horizontalModule': "Horizontal module";
        readonly 'widget.composition.plugin': "Plugin";
        readonly 'widget.composition.include': "Include";
        readonly 'widget.composition.defer': "Defer";
        readonly 'widget.composition.adjustment': "Would you like to change anything?";
        readonly 'widget.composition.placeholder': "Example: add, remove or defer a recommendation and explain why.";
        readonly 'widget.composition.request': "Generate another proposal";
        readonly 'widget.composition.approve': "Approve analysis";
        readonly 'widget.composition.cancel': "Cancel execution";
        readonly 'widget.composition.adjustmentRequired': "Describe the change before generating another proposal.";
        readonly 'widget.composition.processingApproval': "Validating analysis…";
        readonly 'widget.composition.processingChanges': "Preparing another review…";
        readonly 'widget.composition.processingCancel': "Cancelling execution…";
        readonly 'widget.composition.revise': "Review the items below";
        readonly 'widget.composition.cancelTitle': "Cancel this execution?";
        readonly 'widget.composition.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.composition.keepWorking': "Keep working";
        readonly 'widget.composition.hint': "This review is conservative: an empty list means the module can proceed without additional components.";
    };
    export const NS4_WIDGET_KEYS: {
        readonly intake: readonly ["adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking"];
        readonly journeys: readonly ["subtitle", "actor", "goal", "steps", "rules", "outcome", "filters", "impact", "noPolicyDecision", "journeys", "journeysFound", "selectJourney", "allActors", "actorMap", "actors", "overview", "actual", "rulesHelp", "adjustment", "placeholder", "requestChanges", "approve", "round", "step", "of", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking", "assumedDecisions", "changeHint"];
        readonly accessMatrix: readonly ["subtitle", "step", "of", "round", "profiles", "internal", "external", "actors", "landing", "matrix", "profileAccess", "authority", "noAccess", "full", "limited", "details", "reason", "scope", "disclosure", "allowed", "denied", "ruleRefs", "journeySteps", "informationNeeds", "close", "adjustment", "placeholder", "requestChanges", "approve", "adjustmentRequired", "empty", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking"];
        readonly ontology: readonly ["subtitle", "step", "of", "round", "mode", "changes", "entities", "fields", "relationships", "lifecycle", "ruleRefs", "overview", "descriptions", "source", "storage", "required", "optional", "constraints", "persistenceMap", "persistenceHint", "targetMdm", "targetModuleDatabase", "targetDerived", "targetExternal", "targetEmbedded", "scope", "mdmType", "idField", "reason", "fieldRulesHint", "crossStore", "sourceRelationships", "destinationRelationships", "noRelationships", "implementation", "editInPlace", "direct", "directHint", "entityTitle", "entityDescription", "fieldTitle", "fieldDescription", "structural", "structuralHint", "placeholder", "request", "approve", "requiredAdjustment", "empty", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking", "assumedDecisions", "changeHint"];
        readonly rules: readonly ["step", "review", "rules", "search", "noRule", "adjustment", "placeholder", "request", "approve", "cancel", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancelTitle", "cancelText", "keepWorking", "hint", "edit"];
        readonly composition: readonly ["step", "review", "empty", "horizontalModule", "plugin", "include", "defer", "adjustment", "placeholder", "request", "approve", "cancel", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancelTitle", "cancelText", "keepWorking", "hint"];
    };
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Text" {
    /**
     * Deterministic user-facing phrases of agentNewSolution. English is the only text in code.
     * The root planner translates the catalogue once per run into `presentation.phrases`; readers
     * fall back to this object when a key is missing. Placeholders `{name}` stay verbatim in every
     * language. Internal messages (throw, statusTask, trace) are English literals, not keys.
     */
    import { NS4_WIDGET_KEYS } from "_102035_/l2/agentNewSolution/helpers/ns4WidgetPhrases";
    export const NS4_PHRASE_MAX_LENGTH: 200;
    export const NS4_PHRASES: {
        readonly 'widget.intake.adjustmentRequired': "Describe what should change before generating another proposal.";
        readonly 'widget.intake.processingApproval': "Validating initial definition…";
        readonly 'widget.intake.processingChanges': "Preparing a new review…";
        readonly 'widget.intake.processingCancel': "Cancelling execution…";
        readonly 'widget.intake.revise': "Review the items below";
        readonly 'widget.intake.cancel': "Cancel execution";
        readonly 'widget.intake.cancelTitle': "Cancel this execution?";
        readonly 'widget.intake.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.intake.keepWorking': "Keep working";
        readonly 'widget.journeys.subtitle': "These journeys will become the permanent source of truth for the product.";
        readonly 'widget.journeys.actor': "Actor";
        readonly 'widget.journeys.goal': "Goal";
        readonly 'widget.journeys.steps': "Steps";
        readonly 'widget.journeys.rules': "Rules";
        readonly 'widget.journeys.outcome': "Outcome and evidence";
        readonly 'widget.journeys.filters': "Filters";
        readonly 'widget.journeys.impact': "Impact";
        readonly 'widget.journeys.noPolicyDecision': "No policy decision was provided for this journey.";
        readonly 'widget.journeys.journeys': "Journeys";
        readonly 'widget.journeys.journeysFound': "journeys found";
        readonly 'widget.journeys.selectJourney': "Select a journey to review.";
        readonly 'widget.journeys.allActors': "All actors";
        readonly 'widget.journeys.actorMap': "Journey map by actor";
        readonly 'widget.journeys.actors': "actors";
        readonly 'widget.journeys.overview': "Overview";
        readonly 'widget.journeys.actual': "(actual)";
        readonly 'widget.journeys.rulesHelp': "Rules that must remain true in every execution of this journey.";
        readonly 'widget.journeys.adjustment': "What should change?";
        readonly 'widget.journeys.placeholder': "Describe the needed change without rewriting what is already correct.";
        readonly 'widget.journeys.requestChanges': "Request changes";
        readonly 'widget.journeys.approve': "Approve journeys";
        readonly 'widget.journeys.round': "Review";
        readonly 'widget.journeys.step': "Step";
        readonly 'widget.journeys.of': "of";
        readonly 'widget.journeys.adjustmentRequired': "Describe what must change before requesting another version.";
        readonly 'widget.journeys.processingApproval': "Validating journeys…";
        readonly 'widget.journeys.processingChanges': "Preparing a new review…";
        readonly 'widget.journeys.processingCancel': "Cancelling execution…";
        readonly 'widget.journeys.revise': "Review the items below";
        readonly 'widget.journeys.cancel': "Cancel execution";
        readonly 'widget.journeys.cancelTitle': "Cancel this execution?";
        readonly 'widget.journeys.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.journeys.keepWorking': "Keep working";
        readonly 'widget.journeys.assumedDecisions': "Assumed decisions";
        readonly 'widget.journeys.changeHint': "How to change later";
        readonly 'widget.accessMatrix.subtitle': "Review who may perform each capability and exactly which information may be disclosed.";
        readonly 'widget.accessMatrix.step': "Step";
        readonly 'widget.accessMatrix.of': "of";
        readonly 'widget.accessMatrix.round': "Review";
        readonly 'widget.accessMatrix.profiles': "Access profiles";
        readonly 'widget.accessMatrix.internal': "Internal";
        readonly 'widget.accessMatrix.external': "External";
        readonly 'widget.accessMatrix.actors': "E2 actors";
        readonly 'widget.accessMatrix.landing': "Starting point";
        readonly 'widget.accessMatrix.matrix': "Profile × authority matrix";
        readonly 'widget.accessMatrix.profileAccess': "Authorities for this profile";
        readonly 'widget.accessMatrix.authority': "Authority";
        readonly 'widget.accessMatrix.noAccess': "No access";
        readonly 'widget.accessMatrix.full': "Full record";
        readonly 'widget.accessMatrix.limited': "Limited";
        readonly 'widget.accessMatrix.details': "Access details";
        readonly 'widget.accessMatrix.reason': "Business reason";
        readonly 'widget.accessMatrix.scope': "Data scope";
        readonly 'widget.accessMatrix.disclosure': "Disclosure boundary";
        readonly 'widget.accessMatrix.allowed': "May expose";
        readonly 'widget.accessMatrix.denied': "Must not expose";
        readonly 'widget.accessMatrix.ruleRefs': "Rule references";
        readonly 'widget.accessMatrix.journeySteps': "Journey steps";
        readonly 'widget.accessMatrix.informationNeeds': "Information needs";
        readonly 'widget.accessMatrix.close': "Close";
        readonly 'widget.accessMatrix.adjustment': "What should change?";
        readonly 'widget.accessMatrix.placeholder': "Example: Add authority to view project budgets; some clients may see a summary without seeing the whole project.";
        readonly 'widget.accessMatrix.requestChanges': "Generate another proposal";
        readonly 'widget.accessMatrix.approve': "Approve access matrix";
        readonly 'widget.accessMatrix.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.accessMatrix.empty': "No access matrix available.";
        readonly 'widget.accessMatrix.processingApproval': "Validating access matrix…";
        readonly 'widget.accessMatrix.processingChanges': "Preparing a new review…";
        readonly 'widget.accessMatrix.processingCancel': "Cancelling execution…";
        readonly 'widget.accessMatrix.revise': "Review the items below";
        readonly 'widget.accessMatrix.cancel': "Cancel execution";
        readonly 'widget.accessMatrix.cancelTitle': "Cancel this execution?";
        readonly 'widget.accessMatrix.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.accessMatrix.keepWorking': "Keep working";
        readonly 'widget.ontology.subtitle': "Review the business data, constraints and relationships that frontend and backend will share.";
        readonly 'widget.ontology.step': "Step";
        readonly 'widget.ontology.of': "of";
        readonly 'widget.ontology.round': "Review";
        readonly 'widget.ontology.mode': "New solution";
        readonly 'widget.ontology.changes': "Changes in this round";
        readonly 'widget.ontology.entities': "Entities";
        readonly 'widget.ontology.fields': "Fields";
        readonly 'widget.ontology.relationships': "Relationships";
        readonly 'widget.ontology.lifecycle': "Lifecycle";
        readonly 'widget.ontology.ruleRefs': "Rule references";
        readonly 'widget.ontology.overview': "Overview";
        readonly 'widget.ontology.descriptions': "Descriptions";
        readonly 'widget.ontology.source': "Traceability";
        readonly 'widget.ontology.storage': "Persistence destination";
        readonly 'widget.ontology.required': "Required";
        readonly 'widget.ontology.optional': "Optional";
        readonly 'widget.ontology.constraints': "Field rules";
        readonly 'widget.ontology.persistenceMap': "Persistence map";
        readonly 'widget.ontology.persistenceHint': "Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.";
        readonly 'widget.ontology.targetMdm': "MDM · base records";
        readonly 'widget.ontology.targetModuleDatabase': "Module database · transactions";
        readonly 'widget.ontology.targetDerived': "Derived · no own table";
        readonly 'widget.ontology.targetExternal': "External · platform owned";
        readonly 'widget.ontology.targetEmbedded': "Embedded · owned value";
        readonly 'widget.ontology.scope': "Scope";
        readonly 'widget.ontology.mdmType': "MDM type";
        readonly 'widget.ontology.idField': "Identifier";
        readonly 'widget.ontology.reason': "Reason";
        readonly 'widget.ontology.fieldRulesHint': "Click a field name or description to edit it in place.";
        readonly 'widget.ontology.crossStore': "Cross-store";
        readonly 'widget.ontology.sourceRelationships': "As origin";
        readonly 'widget.ontology.destinationRelationships': "As destination";
        readonly 'widget.ontology.noRelationships': "No relationships for this table.";
        readonly 'widget.ontology.implementation': "Field binding";
        readonly 'widget.ontology.editInPlace': "Click to edit";
        readonly 'widget.ontology.direct': "Direct description edits";
        readonly 'widget.ontology.directHint': "Titles and descriptions are safe to edit here. Structural changes use the separate request panel.";
        readonly 'widget.ontology.entityTitle': "Entity title";
        readonly 'widget.ontology.entityDescription': "Entity description";
        readonly 'widget.ontology.fieldTitle': "Field title";
        readonly 'widget.ontology.fieldDescription': "Field description";
        readonly 'widget.ontology.structural': "What should change?";
        readonly 'widget.ontology.structuralHint': "Use the LLM for entities, fields, types, relationships, lifecycle or constraints.";
        readonly 'widget.ontology.placeholder': "Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.";
        readonly 'widget.ontology.request': "Generate another proposal";
        readonly 'widget.ontology.approve': "Approve ontology";
        readonly 'widget.ontology.requiredAdjustment': "Describe the structural change first.";
        readonly 'widget.ontology.empty': "No ontology proposal available.";
        readonly 'widget.ontology.processingApproval': "Validating ontology…";
        readonly 'widget.ontology.processingChanges': "Preparing a new review…";
        readonly 'widget.ontology.processingCancel': "Cancelling execution…";
        readonly 'widget.ontology.revise': "Review the items below";
        readonly 'widget.ontology.cancel': "Cancel execution";
        readonly 'widget.ontology.cancelTitle': "Cancel this execution?";
        readonly 'widget.ontology.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.ontology.keepWorking': "Keep working";
        readonly 'widget.ontology.assumedDecisions': "Assumed decisions";
        readonly 'widget.ontology.changeHint': "How to change later";
        readonly 'widget.rules.step': "👤 Step 5 of 6 — Business rules";
        readonly 'widget.rules.review': "Review";
        readonly 'widget.rules.rules': "rules";
        readonly 'widget.rules.search': "Search by ID or description";
        readonly 'widget.rules.noRule': "No rules found.";
        readonly 'widget.rules.adjustment': "What should change?";
        readonly 'widget.rules.placeholder': "Example: change clientAvailable to allow only one active client per project.";
        readonly 'widget.rules.request': "Generate another proposal";
        readonly 'widget.rules.approve': "Approve rules";
        readonly 'widget.rules.cancel': "Cancel execution";
        readonly 'widget.rules.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.rules.processingApproval': "Validating rules…";
        readonly 'widget.rules.processingChanges': "Preparing another review…";
        readonly 'widget.rules.processingCancel': "Cancelling execution…";
        readonly 'widget.rules.revise': "Review the items below";
        readonly 'widget.rules.cancelTitle': "Cancel this execution?";
        readonly 'widget.rules.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.rules.keepWorking': "Keep working";
        readonly 'widget.rules.hint': "Each permanent rule contains only a stable ID and one business description.";
        readonly 'widget.rules.edit': "Click to edit the description";
        readonly 'widget.composition.step': "👤 Step 6 of 6 — Additional modules and plugins";
        readonly 'widget.composition.review': "Review";
        readonly 'widget.composition.empty': "No additional horizontal module or plugin was recommended.";
        readonly 'widget.composition.horizontalModule': "Horizontal module";
        readonly 'widget.composition.plugin': "Plugin";
        readonly 'widget.composition.include': "Include";
        readonly 'widget.composition.defer': "Defer";
        readonly 'widget.composition.adjustment': "Would you like to change anything?";
        readonly 'widget.composition.placeholder': "Example: add, remove or defer a recommendation and explain why.";
        readonly 'widget.composition.request': "Generate another proposal";
        readonly 'widget.composition.approve': "Approve analysis";
        readonly 'widget.composition.cancel': "Cancel execution";
        readonly 'widget.composition.adjustmentRequired': "Describe the change before generating another proposal.";
        readonly 'widget.composition.processingApproval': "Validating analysis…";
        readonly 'widget.composition.processingChanges': "Preparing another review…";
        readonly 'widget.composition.processingCancel': "Cancelling execution…";
        readonly 'widget.composition.revise': "Review the items below";
        readonly 'widget.composition.cancelTitle': "Cancel this execution?";
        readonly 'widget.composition.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.composition.keepWorking': "Keep working";
        readonly 'widget.composition.hint': "This review is conservative: an empty list means the module can proceed without additional components.";
        readonly 'catalogue.list.title': "List {entity}";
        readonly 'catalogue.list.story': "Find the record.";
        readonly 'catalogue.create.title': "Create {entity}";
        readonly 'catalogue.create.story': "Fill in the new record.";
        readonly 'catalogue.update.title': "Update {entity}";
        readonly 'catalogue.update.story': "Correct the chosen record.";
        readonly 'catalogue.section.recordList.intent': "Find {entity}.";
        readonly 'catalogue.section.recordForm.create.intent': "Create {entity}.";
        readonly 'catalogue.section.recordForm.edit.intent': "Create or correct {entity}.";
        readonly 'catalogue.purpose': "{entity} record catalogue.";
        readonly 'catalogue.delete.title': "Delete {entity}";
        readonly 'catalogue.delete.story': "Remove the chosen record.";
        readonly 'catalogue.inactivate.title': "Deactivate {entity}";
        readonly 'catalogue.inactivate.story': "Deactivate the record (history and references are preserved).";
        readonly 'catalogue.reactivate.title': "Reactivate {entity}";
        readonly 'catalogue.reactivate.story': "Reactivate a deactivated record.";
        readonly 'catalogue.get.title': "Get {entity}";
        readonly 'catalogue.get.story': "Read the record by id.";
        readonly 'catalogue.audience.question': "No journey operates {entity}: who maintains this catalogue?";
        readonly 'catalogue.audience.changeHint': "Add an E3 authority over {entity} to restrict this catalogue to a named profile.";
        readonly 'catalogue.list.search': "Search by {field}.";
        readonly 'catalogue.list.sortBy': "Field to sort the listing by.";
        readonly 'catalogue.list.sortOrder': "Sort direction.";
        readonly 'catalogue.list.page': "Listing page (1-based).";
        readonly 'catalogue.list.pageSize': "Page size (default 20, cap 200).";
        readonly 'journey.decide.description': "The decision taken.";
        readonly 'hub.purpose': "{entity} command centre.";
        readonly 'hub.section.collection.intent': "Portfolio and search.";
        readonly 'hub.section.record.intent': "The selected record and what revolves around it.";
        readonly 'projection.unjoined.question': "Use case {useCaseId} reads projection {projectionId} with no derived relationship to {entity}: E4 cannot join them. Omit from the output?";
        readonly 'projection.unjoined.changeHint': "Declare an E4 relationship with realization.kind derived between {projectionId} and {entity}.";
        readonly 'hub.composition.question': "The proposed composition for the {entity} dashboard did not respect the catalogue; use the default order?";
        readonly 'hub.composition.changeHint': "Review the order and highlights of the {entity} dashboard in the next round.";
        readonly 'workflow.unreachable.question': "How should the unreachable {entity}.{state} lifecycle state be handled?";
        readonly 'workflow.unreachable.changeHint': "Add an explicit E2 journey/operation that reaches {entity}.{state} before restoring it to the compiled workflow; the E4 ontology remains unchanged.";
        readonly 'workflow.predicate.question': "The {predicateId} criterion has no effect in this version — none of its states is reachable.";
        readonly 'workflow.predicate.changeHint': "Add an E2 journey that reaches one of {states}; the E5 rule and E4 ontology remain unchanged.";
        readonly 'workflow.omit.question': "{entity} has no operated state flow in this version.";
        readonly 'workflow.omit.changeHint': "Add an E2 journey that operates a {entity} transition; the E4 ontology remains unchanged.";
        readonly 'demotion.chosen': "Standard {entity} record catalogue";
        readonly 'demotion.alternative': "Keep {journey} as its own journey";
        readonly 'demotion.question': "{journey} has no decision and no handoff: should it become the standard {entity} record catalogue?";
        readonly 'dormant.question': "The {title} action stays visible, but transition {transitions} is not reachable in this version.";
        readonly 'route.ambiguous.question': "Which record should the {title} screen open directly?";
        readonly 'route.ambiguous.changeHint': "The {title} screen opens without a direct record link in this version; define a single target context to enable it.";
    };
    export type Ns4PhraseKey = keyof typeof NS4_PHRASES;
    export function isNs4PhraseKey(value: string): value is Ns4PhraseKey;
    export interface Ns4PhraseHolder {
        phrases?: Partial<Record<Ns4PhraseKey, string>>;
    }
    export interface Ns4PhrasesNormalization {
        phrases: Partial<Record<Ns4PhraseKey, string>>;
        warnings: string[];
    }
    export function ns4Text(presentation: Ns4PhraseHolder | undefined, key: Ns4PhraseKey, params?: Record<string, string>): string;
    type Ns4WidgetName = keyof typeof NS4_WIDGET_KEYS;
    export type Ns4WidgetLabelMap<W extends Ns4WidgetName> = {
        [K in (typeof NS4_WIDGET_KEYS)[W][number]]: string;
    };
    export function ns4WidgetLabels<W extends Ns4WidgetName>(presentation: Ns4PhraseHolder | undefined, widget: W): Ns4WidgetLabelMap<W>;
    export function normalizeNs4Phrases(value: unknown): Ns4PhrasesNormalization;
    export function ns4PlannerPhrasesAppendix(): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Core" {
    import { type Ns4PhraseKey } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    export const NS4_FLOW_ID: "agentNewSolution";
    export const NS4_FLOW_VERSION: "2026-08-14-ns4-flow-v40";
    export const NS4_E4_MAX_PARALLEL: 20;
    export const NS4_E7_MAX_PARALLEL: 20;
    export const NS4_E8_MAX_PARALLEL: 20;
    export const NS4_MODULE_SCHEMA_VERSION: "2026-08-06-ns4-module-v4";
    export const NS4_PIPELINE_SCHEMA_VERSION: "2026-08-06-ns4-pipeline-v5";
    export type Ns4PermanentFlowVersion = typeof NS4_FLOW_VERSION | '2026-08-14-ns4-flow-v39' | '2026-08-14-ns4-flow-v38' | '2026-08-14-ns4-flow-v37' | '2026-08-14-ns4-flow-v36' | '2026-08-14-ns4-flow-v35' | '2026-08-14-ns4-flow-v34' | '2026-08-13-ns4-flow-v33' | '2026-08-13-ns4-flow-v32' | '2026-08-13-ns4-flow-v31' | '2026-08-12-ns4-flow-v30' | '2026-08-11-ns4-flow-v24' | '2026-08-11-ns4-flow-v22' | '2026-08-10-ns4-flow-v21' | '2026-08-10-ns4-flow-v20' | '2026-08-09-ns4-flow-v19' | '2026-08-09-ns4-flow-v18' | '2026-08-08-ns4-flow-v17';
    export const NS4_PLAN_IDS: readonly ["e1-clarification", "e1-compile", "e2-journeys", "e3-access-matrix", "e4-ontology", "e5-rules", "e6-behaviors", "e7-realization", "e8-workspaces", "e9-navigation-compiler", "e10-validation"];
    export type Ns4PlanId = typeof NS4_PLAN_IDS[number];
    export const NS4_HUMAN_CHECKPOINT_ICON: "\uD83D\uDC64";
    export const NS4_AUTOMATED_JUDGE_ICON: "\uD83D\uDD0E";
    export type Ns4ApprovedBy = 'human' | 'auto';
    export type Ns4E1Status = 'running' | 'approved' | 'failed';
    export type Ns4E2Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E3Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E4Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E5Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E6Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E7Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E8Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E9Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E10Status = 'running' | 'approved' | 'failed';
    export type Ns4CompletedStepId = 'e1' | 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation';
    export type Ns4NextStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation' | 'complete';
    export interface Ns4ClarificationQuestion {
        type: 'open';
        question: string;
        answer: string;
    }
    export interface Ns4Clarification {
        planId: 'e1-clarification';
        userLanguage: string;
        title: string;
        legends: string[];
        questions: Record<string, Ns4ClarificationQuestion>;
    }
    export interface Ns4Presentation {
        userLanguage: string;
        stepTitles: Record<Ns4PlanId, string>;
        phrases?: Partial<Record<Ns4PhraseKey, string>>;
    }
    export interface Ns4RootPlan {
        validPrompt: boolean;
        invalidReason?: string;
        userPrompt: string;
        presentation: Ns4Presentation;
        clarification: Ns4Clarification;
        phraseWarnings?: string[];
    }
    export const NS4_TERMINAL_CANCEL_UNSUPPORTED = "Terminal cancellation still depends on explicit collab-messages support; this review was kept open without changing the pipeline.";
    export const NS4_DESCRIBE_REQUIRED_CHANGE = "Describe the required change before submitting.";
    export interface Ns4ModuleArtifact {
        schemaVersion: typeof NS4_MODULE_SCHEMA_VERSION;
        presentation: Ns4Presentation;
        module: {
            moduleName: string;
            title: string;
            purpose: string;
            languages: string[];
        };
        designContext: {
            initialPrompt: string;
            clarification: {
                mainActors: string;
                mainGoal: string;
                boundaries: string;
            };
        };
        reviewPolicy: {
            mode: 'guided' | 'smart' | 'automatic';
        };
        solutionStrategy: {
            mode: 'newSolution' | 'modernizePreserveDatabase' | 'modernizeEvolveDatabase' | 'replaceAndMigrateData';
            rationale: string;
            databaseChangePolicy: 'new' | 'forbidden' | 'additiveControlled' | 'replacement';
            modernization?: {
                sourceSystemName: string;
                sourceTechnology?: string;
                databaseEngine?: string;
                databaseVersion?: string;
                schemaAvailability: 'uploadAtE4' | 'metadataAtE4' | 'notAvailableYet';
                notes?: string;
            };
        };
        businessScope: {
            mainGoal: string;
            actors: Array<{
                actorId: string;
                title: string;
                kind: 'internal' | 'external' | 'system';
                expectedOutcome: string;
            }>;
            expectedOutcomes: Array<{
                outcomeId: string;
                title: string;
                description: string;
            }>;
            inScope: string[];
            outOfScope: string[];
        };
        localization: {
            productLanguages: string[];
            defaultLanguage: string;
            defaultLocale?: string;
            currency?: string;
            timeZone?: string;
            primaryMarket?: string;
        };
        declaredConstraints: {
            mandatoryIntegrations: Array<{
                dependencyId: string;
                title: string;
                kind: 'externalSystem' | 'platform' | 'unknown';
                reason: string;
            }>;
            regulatoryNotes?: string;
            criticalNotes?: string;
        };
        specStatus: {
            flowId: typeof NS4_FLOW_ID;
            /** v17 remains readable by tsc, but isNs4Pipeline deliberately rejects it for runtime resume. */
            flowVersion: Ns4PermanentFlowVersion;
            state: 'inProgress' | 'complete';
            artifactCompleteness: 'partial' | 'full';
            completedSteps: Array<{
                stepId: Ns4CompletedStepId;
                status: 'approved';
                approvedBy: Ns4ApprovedBy;
                approvedAt: string;
                /** Present when smart skipped the human checkpoint. */
                autoReason?: string;
            }>;
            nextStep: Ns4NextStep;
            updatedAt: string;
        };
    }
    export interface Ns4PipelineState {
        schemaVersion: typeof NS4_PIPELINE_SCHEMA_VERSION;
        flowId: typeof NS4_FLOW_ID;
        flowVersion: typeof NS4_FLOW_VERSION;
        moduleName: string;
        sourcePrompt: string;
        presentation: Ns4Presentation;
        status: 'inProgress' | 'complete' | 'failed';
        /** Audit of the last explicit regeneration: which step it restarted from, and when. */
        rebuiltFrom?: Ns4RebuildFrom;
        rebuiltAt?: string;
        /** Counts from `/rebuild all` (l1/l2/l4/l5 wipe). Survives on the regenerated pipeline for runNN_*.json. */
        rebuildAll?: Ns4RebuildAllReport;
        steps: {
            e1: {
                status: Ns4E1Status;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                skippedDefaults?: {
                    productLanguages: string[];
                    defaultLanguage: string;
                    moduleName: string;
                    i18nWarnings?: string[];
                };
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e2?: {
                status: Ns4E2Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e3?: {
                status: Ns4E3Status;
                reviewRound: number;
                draftPath?: string;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e4?: {
                status: Ns4E4Status;
                reviewRound: number;
                solutionMode: 'new';
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e5?: {
                status: Ns4E5Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e6?: {
                status: Ns4E6Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e7?: {
                status: Ns4E7Status;
                planPath?: string;
                artifactPaths?: string[];
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e8?: {
                status: Ns4E8Status;
                reviewRound: number;
                skeletonPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e9?: {
                status: Ns4E9Status;
                artifactPaths?: string[];
                repairStep?: 'e8-workspaces' | 'e9-navigation-compiler';
                error?: string;
                failedAt?: string;
                approvedAt?: string;
                updatedAt: string;
            };
            e10?: {
                status: Ns4E10Status;
                reportPath?: string;
                artifactPaths?: string[];
                repairStep?: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>;
                error?: string;
                failedAt?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                updatedAt: string;
            };
        };
        nextStep: Ns4NextStep;
        createdAt: string;
        updatedAt: string;
        /**
         * E9 audit: an E7 use case that did not become an operation. Only `degraded` is persisted at the
         * top level — a clean emit strips both fields so a prior-run `degraded` cannot come back.
         */
        useCases?: 'degraded';
        useCasesDropped?: {
            notEmitted: string[];
            approved: number;
            emitted: number;
            reasons?: Record<string, string>;
        };
        /** Recorded when `/fast` dispatches the next agent, so a re-entry of E10 does not send twice. */
        fastHandoff?: {
            to: string;
            message: string;
            at: string;
        };
    }
    export type Ns4ExistingAction = 'new' | 'resume-e1' | 'resume-e2' | 'resume-e3' | 'resume-e4' | 'resume-e5' | 'resume-e6' | 'resume-e7' | 'resume-e8' | 'resume-e9' | 'resume-e10' | 'resume-next' | 'collision';
    /** Steps a partial rebuild can start from. e1 is not one of them: restarting at e1 IS a total rebuild. */
    export type Ns4RebuildFrom = 'e2' | 'e3' | 'e4' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /** `/rebuild all` is its own mode: wipe l1/l2/l4 of the module, then regenerate from the stored prompt. */
    export type Ns4RebuildArg = Ns4RebuildFrom | 'all';
    export interface Ns4RebuildAllReport {
        at: string;
        deleted: {
            l1: number;
            l2: number;
            l4: number;
            l5: number;
        };
        sanitized: {
            projectJsonRemoved: number;
            configJsonRemoved: number;
        };
    }
    export interface Ns4Invocation {
        fast: boolean;
        /** Explicit regeneration intent. Never inferred from prose — prose only produces a graceful stop. */
        rebuild: boolean;
        /** Set by `/rebuild all` or `/rebuild <eN>`; empty means the existing total rebuild (l4/l5 only). */
        rebuildFrom: Ns4RebuildArg | '';
        /** Suppress the next-agent handoff. Independent of `/fast`; `/nochainlane` does not match. */
        nochain: boolean;
        prompt: string;
    }
    export function parseNs4Invocation(value: string): Ns4Invocation;
    /**
     * A prompt that ASKS for a rebuild in prose and names an existing module.
     *
     * The incident this exists for: `rebuild all criar um site chamado petShop , em …`. The module name sits
     * mid-sentence, so `resolveNs4ExistingModuleToken` (which requires the WHOLE prompt to be one token) read
     * it as a new module, E1 ran, and the existence backstop killed the task — the user asked to rebuild and
     * got a terminal error.
     *
     * BOTH signals are required. Scanning tokens for an existing module name on its own would hijack an
     * ordinary creation prompt that happens to mention one ("a schedule module for petShop"); demanding
     * an explicit rebuild word keeps every prompt without one canonicalized exactly as before. The outcome is
     * only ever a message teaching the flag — nothing is written or deleted on this path.
     *
     * The rebuild word may be a flag (`/rebuild`): the slash sits where a start-or-space used to be
     * required, so the canonical form never reached this helper. Natural-language synonyms are not a
     * command; the status task names `/rebuild`.
     */
    export function detectNs4RebuildIntentModule(value: string, existingModules: ReadonlySet<string>): string;
    export function formatNs4MissingRebuildModuleMessage(existingModules: ReadonlySet<string>): string;
    export function createNs4E2Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E1Step(reviewRound?: number, adjustment?: string, previousReview?: unknown, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E2GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, coverageRepairAttempt: number, gateFeedback: string, stepTitle?: string, coverageIssueIds?: string[], policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E2CoverageRepairStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, coverageFeedback: string, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E2CoverageJudgeStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, judgeAttempt: number, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E3Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /**
     * One bounded structural repair for E3, mirroring the E2 gate repair: the model
     * sees the numbered gate findings plus the persisted invalid draft and returns a
     * complete corrected matrix through the same gate.
     */
    export function createNs4E3GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4RepairStep(moduleName: string, reviewRound: number, repairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4FinalizeStep(moduleName: string, reviewRound: number, dependsOn: string[], entityRepairRound?: number, planRepairAttempt?: number, derivationRepairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E4RelationshipBindingStep(moduleName: string, reviewRound: number, bindingRepairAttempt?: number, gateFeedback?: string, entityRepairRound?: number): mls.msg.AIAgentStep;
    export function createNs4E4DerivationBindingStep(moduleName: string, reviewRound: number, derivationRepairAttempt?: number, gateFeedback?: string, entityRepairRound?: number, planRepairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E5Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E6Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E7Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export type Ns4StepOwner = 'e1' | 'e2' | 'e3' | 'e4' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /**
     * The dispatch table, next to the factories that mint the plan ids it matches. The router and the
     * factories drifted apart once — a factory emitting `e8-workspaces-round-1` against a router that
     * only knew `e8-workspaces` — and the step died before reaching any agent, with no trace to read.
     * One table, one truth, and a test that walks every factory through it.
     */
    export function resolveNs4StepOwner(planId: string): Ns4StepOwner | '';
    /**
     * The E8 plan ids live in ONE place, next to the factories that mint them. The router matched a
     * hand-written pattern once and stopped seeing the real step: a plan id the factory emits and the
     * router does not recognize is a step that dies without ever reaching its agent.
     */
    export function ns4E8StepPlanId(reviewRound: number): string;
    export function ns4E8HubRepairPlanId(reviewRound: number, attempt: number): string;
    export function isNs4E8PlanId(planId: string): boolean;
    export function createNs4E8Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /** The one bounded repair E8 still schedules: the hub composition over its closed catalogue. */
    export function createNs4E8HubCompositionRepairStep(moduleName: string, reviewRound: number, compositionAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E9Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E10Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export const NS4_DEFAULT_TITLES: Record<Ns4PlanId, string>;
    export function formatNs4VisibleStepTitle(planId: Ns4PlanId, title: string): string;
    export function plainNs4StepTitle(title: string): string;
    /** Dynamic E4 children do not retain planning.planId; hook args are their stable dispatcher key. */
    export function resolveNs4DynamicWorker(value: unknown): 'e4' | 'e7' | 'e8' | '';
    export interface Ns4DynamicWorkerRequest {
        worker: 'e4' | 'e7' | 'e8' | '';
        args: string;
    }
    /**
     * collab-messages supplies the selector as hook args before a parallel prompt, but may omit those
     * args in the after-prompt callback while retaining the selector in step.prompt. Both callbacks must
     * resolve through the same ordered fallback or a valid entity payload reaches the root planner.
     */
    export function resolveNs4DynamicWorkerRequest(args: unknown, stepPrompt: unknown): Ns4DynamicWorkerRequest;
    export function normalizeNs4RootPlan(payload: unknown, sourcePrompt: string): Ns4RootPlan;
    export function buildNs4PlannedSteps(plan: Ns4RootPlan): mls.msg.AIAgentStep[];
    export function isNs4ModuleToken(value: string): boolean;
    export function normalizeNs4ModuleName(value: unknown, fallback?: string): string;
    export function resolveNs4ExistingModuleToken(value: string, existingModules: ReadonlySet<string>): string;
    export function normalizeNs4Clarification(value: unknown): Ns4Clarification;
    export function buildNs4ModuleArtifact(sourcePrompt: string, clarificationInput: unknown, approvedBy: Ns4ApprovedBy, now?: string, presentation?: Ns4Presentation): Ns4ModuleArtifact;
    export function normalizeNs4Languages(value: unknown, fallback?: string): string[];
    export function createNs4Pipeline(moduleNameInput: string, sourcePrompt: string, now?: string, presentation?: Ns4Presentation): Ns4PipelineState;
    export function markNs4E1Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, autoReason?: string, skippedDefaults?: {
        productLanguages: string[];
        defaultLanguage: string;
        moduleName: string;
        i18nWarnings?: string[];
    }): Ns4PipelineState;
    export function markNs4FastHandoff(state: Ns4PipelineState, to: string, message: string, now?: string): Ns4PipelineState;
    export function markNs4E2Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E1Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E2Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    /** A changed approved E2 contract invalidates only downstream contracts derived from journeys. */
    export function markNs4E2ImpactStale(state: Ns4PipelineState, hasJourneyImpact: boolean, now?: string): Ns4PipelineState;
    export function markNs4ModuleE2Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, invalidateDownstream?: boolean, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E3Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E3WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E3Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E3Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE3Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E4Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E4WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E4Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE4Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E5Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E5WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E5Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E5Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE5Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E6Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E6WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E6Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E6Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE6Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E7Running(state: Ns4PipelineState, planPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E7Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E7Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE7Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E8Running(state: Ns4PipelineState, reviewRound?: number, skeletonPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E8Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E8Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE8Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function markNs4E9Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    export function markNs4E9Failed(state: Ns4PipelineState, failure: unknown, origin?: 'skeleton' | 'compiler', now?: string): Ns4PipelineState;
    export function markNs4E9Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE9Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E10Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    /**
     * E10 failed on a defect of the pipeline, not of the product: nothing upstream is stale, because
     * nothing upstream is wrong. The module waits on a fixed pipeline and re-validates from E10.
     */
    export function markNs4E10PipelineDefect(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Failed(state: Ns4PipelineState, failure: unknown, repairStep: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10RuntimeFailed(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, now?: string, reportPath?: string, artifactPaths?: string[]): Ns4PipelineState;
    export function markNs4ModuleE10Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function resolveNs4ExistingAction(moduleExists: boolean, pipeline: unknown, moduleArtifactExists: boolean): Ns4ExistingAction;
    /**
     * Everything a TOTAL rebuild archives: the module's whole l4 and l5 trees.
     *
     * The whole folder, not a list of known artifacts — that is the point. A previous run leaves drafts,
     * pipeline traces (`pipeline/msgtask*.json`) and per-entity defs whose names came from ITS ontology; a
     * selective delete keeps whatever the new run happens not to overwrite, and the module ends up a mix of
     * two generations. l2 is NOT touched: it belongs to agentChangeFrontend, which has its own rebuild.
     *
     * PURE over a `mls.stor.files`-shaped map so the selection is testable without the platform.
     */
    export function listNs4RebuildDeletionKeys(files: Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    } | undefined>, project: number, moduleName: string): string[];
    /** eN and every step after it. */
    export function ns4RebuildRange(from: Ns4RebuildFrom): Ns4RebuildFrom[];
    /**
     * Resets eN..e10 for a partial rebuild.
     *
     * The reset is EXPLICIT and stamped (`rebuiltFrom`/`rebuiltAt`), which is what keeps rule 11 intact: an
     * approved state is never regressed by a late callback, only by an intent the user typed. The step entries
     * are dropped rather than set to a status, because e2..e10 are optional and "absent" is exactly what
     * "not done yet" means in this pipeline.
     */
    export function resetNs4PipelineForRebuild(pipeline: Ns4PipelineState, from: Ns4RebuildFrom, rebuiltAt?: string): Ns4PipelineState;
    /**
     * Drops the rebuilt range from the permanent artifact's completedSteps.
     *
     * Without this the reset is undone silently: the invocation reconciles the pipeline from
     * `specStatus.completedSteps` whenever the artifact says approved and the file still exists, so the very
     * next invocation would re-mark e10 approved and answer "pipeline encerrado" to a second /rebuild e10.
     */
    export function clearNs4ModuleCompletedStepsFrom(artifact: Ns4ModuleArtifact, from: Ns4RebuildFrom): Ns4ModuleArtifact;
    export function isNs4Pipeline(value: unknown): value is Ns4PipelineState;
    export function humanizeNs4ModuleName(moduleName: string): string;
    /** Display names of the language in the user's language, its own language and English. */
    export function ns4LanguageMentioned(language: string, userLanguage: string, foldedText: string): boolean;
    /** Lower case without diacritics, so a folded language name matches with or without marks. */
    export function foldNs4Text(value: string): string;
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     * collabBoot.projectId is authoritative (cbeMiniCfe feeds mls.setActualProject from it);
     * mls.actualProject is the fallback when the boot payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ClassicDefs" {
    /**
     * The untyped defs shape of the classic L4 emission, and its reader — PURE, with no storage import.
     * It lives apart from ns4Fs.ts on purpose: ns4Fs pulls in libModel, whose top-level event listener
     * crashes the l2 test stub, and the write/read round trip of these files must stay testable.
     */
    export interface Ns4ClassicDefsFile {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export function ns4ClassicDefsSource(fileInfo: Ns4ClassicDefsFile, exportName: string, value: unknown): string;
    /** Reads a defs file back to its data, exactly as the storage reader does. */
    export function parseNs4ClassicDefsSource<T>(source: string): T | null;
    export function extractNs4ClassicJsonObject(source: string): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4RebuildAll" {
    import { type Ns4PipelineState, type Ns4RebuildAllReport } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type Ns4RebuildAllFile = {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    };
    export type Ns4RebuildAllPlan = {
        ok: true;
        prompt: string;
        keys: string[];
        report: Ns4RebuildAllReport;
        projectJson: Record<string, unknown> | null;
        configJson: Record<string, unknown> | null;
    } | {
        ok: false;
        reason: string;
        keys: string[];
    };
    /**
     * Exact module-folder prefix: the first path segment, after the same canonicalization every other
     * NS folder uses. Never `includes`, never a loose regex — `listaAssinatura` must not match
     * `listaAssinaturaAntiga`, and `todo` must not match `todoList` or anything else.
     */
    export function isNs4ExactModuleFolderPrefix(folder: string, moduleName: string): boolean;
    export function recoverNs4RebuildAllPrompt(input: {
        initialPrompt?: unknown;
        sourcePrompt?: unknown;
    }): {
        ok: true;
        prompt: string;
    } | {
        ok: false;
        reason: string;
    };
    /** l1, l2, l4 and per-module l5 of THAT module only. Project-level l5 (config.json, project.json) stays. */
    export function listNs4RebuildAllDeletionKeys(files: Record<string, Ns4RebuildAllFile | undefined>, project: number, moduleName: string): string[];
    export function countNs4RebuildAllByLayer(files: Record<string, Ns4RebuildAllFile | undefined>, keys: readonly string[]): Ns4RebuildAllReport['deleted'];
    export function stripNs4ModuleFromProjectJson(projectJson: unknown, moduleName: string): {
        value: Record<string, unknown> | null;
        removed: number;
    };
    export function stripNs4ModuleFromConfigJson(config: unknown, moduleName: string): {
        value: Record<string, unknown> | null;
        removed: number;
    };
    export function planNs4RebuildAll(input: {
        files: Record<string, Ns4RebuildAllFile | undefined>;
        project: number;
        moduleName: string;
        initialPrompt?: unknown;
        sourcePrompt?: unknown;
        projectJson?: unknown;
        configJson?: unknown;
        at?: string;
    }): Ns4RebuildAllPlan;
    export function stampNs4RebuildAll(pipeline: Ns4PipelineState, report: Ns4RebuildAllReport): Ns4PipelineState;
    export function parseNs4RebuildAllReport(value: unknown): Ns4RebuildAllReport | null;
    export function formatNs4RebuildAllNote(moduleName: string, report: Ns4RebuildAllReport): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ContentRead" {
    export interface Ns4ReadableFile {
        versionRef?: unknown;
        getValueInfo?: () => Promise<{
            content?: unknown;
        }>;
        getContent: () => Promise<unknown>;
    }
    export interface Ns4ContentReadResult {
        text: string | null;
        unavailableNewFile: boolean;
    }
    /** Local-first content resolution that never sends the unsaved versionRef=0 to a remote driver. */
    export function readNs4AvailableContent(file: Ns4ReadableFile, extension: string): Promise<Ns4ContentReadResult>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Resolve" {
    export type Ns4ResolutionClass = 'A' | 'B' | 'C';
    export interface Ns4SystemDecision {
        decisionId: string;
        stage: string;
        question: string;
        chosen: string;
        alternatives: string[];
        decidedBy: 'system';
        findingRef: string;
        changeHint: string;
    }
    interface Ns4ResolutionFindingBase {
        decisionId?: string;
        findingRef: string;
        stage: string;
        question: string;
        alternatives: string[];
        changeHint: string;
    }
    export interface Ns4TypeAFinding extends Ns4ResolutionFindingBase {
        classification: 'A';
    }
    export interface Ns4TypeBFinding extends Ns4ResolutionFindingBase {
        classification: 'B';
        /** The behavior already implicit in the generated artifact. */
        defaultChoice: string;
    }
    export interface Ns4TypeCFinding<TArtifact> extends Ns4ResolutionFindingBase {
        classification: 'C';
        deterministicChoice: string;
        apply: (artifact: TArtifact) => TArtifact;
    }
    export type Ns4ResolutionFinding<TArtifact> = Ns4TypeAFinding | Ns4TypeBFinding | Ns4TypeCFinding<TArtifact>;
    export interface Ns4ResolutionResult<TArtifact> {
        artifact: TArtifact;
        systemDecisions: Ns4SystemDecision[];
        unresolved: Array<Ns4TypeAFinding>;
    }
    /**
     * The single NS4 semantic-resolution boundary. Type A remains unresolved,
     * Type B records the generator's existing choice, and Type C applies its
     * caller-supplied mechanical patch before recording the decision.
     */
    export function resolveNs4Findings<TArtifact>(artifact: TArtifact, findings: Array<Ns4ResolutionFinding<TArtifact>>): Ns4ResolutionResult<TArtifact>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Context" {
    /**
     * The single place where journey contexts are derived. E2 owns narrative, sequence, step kind and
     * step entity; nothing declares a context id, a cardinality or a provider. Every consumer (E7, E8,
     * E9) reads the same derivation so a context can never mean two things in two steps.
     */
    export type Ns4ContextStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export interface Ns4DerivedContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        idFieldRef?: string;
    }
    export interface Ns4DerivedStepContexts {
        journeyId: string;
        stepId: string;
        stepRef: string;
        kind: Ns4ContextStepKind;
        entity: string;
        /** True when the step introduces its own entity instead of operating on an existing record. */
        creates: boolean;
        requires: Ns4DerivedContext[];
        provides: Ns4DerivedContext[];
    }
    export interface Ns4DerivedContextGraph {
        catalog: Ns4DerivedContext[];
        steps: Ns4DerivedStepContexts[];
        byStepRef: Map<string, Ns4DerivedStepContexts>;
        entryByJourneyId: Map<string, Ns4DerivedContext[]>;
    }
    export interface Ns4ContextJourneyStep {
        stepId: string;
        kind: Ns4ContextStepKind;
        entity: string;
        targetProfile?: string;
    }
    export interface Ns4ContextJourney {
        journeyId: string;
        business: {
            actorRef: string;
            entry: {
                mode: string;
                preferredFromJourneyRef?: string;
            };
            steps: Ns4ContextJourneyStep[];
        };
    }
    export interface Ns4ContextEntity {
        entityId: string;
        ownership?: string;
        storage?: {
            target?: string;
            scope?: string;
            idField?: string;
        };
        fields?: Array<{
            fieldId: string;
        }>;
    }
    export interface Ns4ContextRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
    }
    export interface Ns4ContextSources {
        journeys: {
            journeys: Ns4ContextJourney[];
        };
        ontology: {
            entities: Ns4ContextEntity[];
            relationships: Ns4ContextRelationship[];
        };
        access?: {
            profiles: Array<{
                profileId: string;
                actorRefs: string[];
            }>;
        };
    }
    /** A context id is a pure function of its entity, so the catalog and the E9 store are entity-keyed. */
    export function ns4ContextIdOf(entity: string): string;
    /**
     * Inspect of entity X that still has no selected X, while a later step locates X, is a collection
     * summary (counts of the listing) — not getById of one record. Identity-free by construction.
     */
    export function isNs4CollectionInspect(steps: ReadonlyArray<{
        kind: string;
        entity: string;
    }>, index: number): boolean;
    /**
     * Platform-owned records are supplied by the runtime session, never selected by the user, so they
     * are not a coordination requirement of a business step.
     */
    export function isNs4PlatformOwnedEntity(entity: Ns4ContextEntity): boolean;
    export function deriveNs4Contexts(sources: Ns4ContextSources): Ns4DerivedContextGraph;
    /** Business objects the ontology must realize: exactly the entities the journeys operate on. */
    export function collectNs4JourneyEntities(journeys: {
        journeys: Ns4ContextJourney[];
    }): string[];
}
declare module "_102035_/l2/agentNewSolution/steps/e2/coverageSignals" {
    export const NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL: "moduleWithoutDecide";
    export const NS4_E2_JOURNEY_WITHOUT_PROCESS_SIGNAL: "journeyWithoutProcess";
    export interface Ns4E2StepKindHistogram {
        locate: number;
        inspect: number;
        act: number;
        decide: number;
        handoff: number;
    }
    export type Ns4E2MechanicalFindingSeverity = 'registrar';
    export interface Ns4E2MechanicalCoverageFinding {
        signalId: typeof NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL;
        severity: Ns4E2MechanicalFindingSeverity;
    }
    export interface Ns4E2MechanicalCoverageReport {
        stepKindHistogram: Ns4E2StepKindHistogram;
        findings: Ns4E2MechanicalCoverageFinding[];
        /** Journeys that carry no process: pure capture or maintenance of one record catalogue. */
        captureOnlyJourneys: Array<{
            journeyId: string;
            entity: string;
        }>;
    }
    interface Ns4E2StepSource {
        journeys: Array<{
            journeyId?: unknown;
            business: {
                steps: Array<{
                    kind: unknown;
                    entity?: unknown;
                }>;
            };
        }>;
    }
    export function analyzeNs4E2MechanicalCoverage(source: Ns4E2StepSource): Ns4E2MechanicalCoverageReport;
    /**
     * A journey with no decision, no handoff and one single entity is the record catalogue of that
     * entity written as a flow. Tier 1 already owns that screen, so the module records the demotion as
     * a visible product choice instead of shipping the same catalogue twice.
     */
    export function ns4E2DemotionDecisionId(journeyId: string): string;
    export function isNs4E2DemotionDecisionId(decisionId: string): boolean;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/contracts" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import { type Ns4DerivedContext } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { Ns4E2StepKindHistogram } from "_102035_/l2/agentNewSolution/steps/e2/coverageSignals";
    export const NS4_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-v5";
    export const NS4_JOURNEY_INDEX_SCHEMA_VERSION: "2026-08-15-ns4-journey-index-v7";
    export const NS4_REALIZED_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-realized-v5";
    export const NS4_E2_IMPACT_REPORT_SCHEMA_VERSION: "2026-08-13-ns4-e2-impact-report-v2";
    export type Ns4JourneyEntryMode = 'coldStart' | 'contextRequired' | 'contextOrLookup' | 'eventDriven';
    export type Ns4JourneyStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export type Ns4FeaturePriority = 'now' | 'next' | 'later';
    /**
     * A step names what it does and to which business record. Everything about context — who provides
     * it, what it carries, how many — is derived by helpers/ns4Context.ts from this entity, the step
     * kind, the journey sequence and the approved ontology.
     */
    export interface Ns4JourneyStep {
        stepId: string;
        kind: Ns4JourneyStepKind;
        entity: string;
        title: string;
        description: string;
        featureRefs: string[];
        /** Only a handoff names the receiving E3 profile; it is the routing fact E9 compiles. */
        targetProfile?: string;
    }
    export interface Ns4JourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
        };
        steps: Ns4JourneyStep[];
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    /** Frozen shape of journeys written by flow versions before the context graph became derived. */
    export interface Ns4LegacyJourneyContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        description: string;
        stateRequirement?: string;
    }
    export interface Ns4LegacyJourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        prerequisites: Array<{
            journeyRef: string;
            reason: string;
            required: boolean;
            providesContext: string[];
        }>;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
            carries: Ns4LegacyJourneyContext[];
        };
        steps: Array<{
            stepId: string;
            kind: Ns4JourneyStepKind;
            intent: string;
            requiresContext: string[];
            providesContext: Ns4LegacyJourneyContext[];
            result: string;
            featureRefs: string[];
        }>;
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    export interface Ns4JourneyProposal {
        journeyId: string;
        business: Ns4JourneyBusiness;
        policyDecisions: Ns4PolicyDecision[];
    }
    /** A product choice made while generating a journey, before any human review. */
    export interface Ns4PolicyDecision {
        decisionId: string;
        question: string;
        chosen: string;
        alternatives: string[];
        /** Only the independent E2 judge may add this explanation. */
        impact?: string;
        relatedJourneyIds?: string[];
    }
    /** Durable audit record of the choice the reviewer approved. */
    export interface Ns4PolicyDecisionSelection {
        decisionId: string;
        generatedChoice: string;
        selectedChoice: string;
        selectedBy: 'human' | 'auto';
        selectedAt: string;
    }
    export interface Ns4E2Feature {
        featureId: string;
        title: string;
        priority: Ns4FeaturePriority;
        journeyStepRefs: string[];
    }
    export interface Ns4E2Review {
        planId: 'e2-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        journeys: Ns4JourneyProposal[];
        features: Ns4E2Feature[];
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4JourneyArtifactV5 extends Ns4JourneyProposal {
        schemaVersion: typeof NS4_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'pending';
            contexts: Record<string, never>;
        };
        realization: {
            status: 'pending';
            compiledFromBusinessHash: string;
            steps: never[];
            transitionRefs: never[];
        };
    }
    /** The derived context, plus the structural provenance E7 records for the compiled journey. */
    export interface Ns4JourneyResolvedContext extends Ns4DerivedContext {
        sourceRefs: string[];
        consumerStepRefs: string[];
    }
    export interface Ns4JourneyStepRealization {
        stepId: string;
        useCaseRefs: string[];
    }
    export interface Ns4JourneyArtifactV5Realized extends Omit<Ns4JourneyProposal, 'policyDecisions'> {
        schemaVersion: typeof NS4_REALIZED_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'compiled';
            contexts: Record<string, Ns4JourneyResolvedContext>;
        };
        realization: {
            status: 'compiled';
            compiledFromBusinessHash: string;
            steps: Ns4JourneyStepRealization[];
            transitionRefs: string[];
            realizationHash: string;
        };
    }
    /**
     * Compile-only compatibility for permanent artifacts written by previous flow versions. They are
     * never resumed or migrated; the union only keeps already-generated L4 modules type-safe.
     */
    export interface Ns4LegacyJourneyArtifact {
        schemaVersion: '2026-08-04-ns4-journey-v1' | '2026-08-09-ns4-journey-v2' | '2026-08-10-ns4-journey-v3' | '2026-08-10-ns4-journey-v4';
        journeyId: string;
        revision: number;
        business: Ns4LegacyJourneyBusiness | (Omit<Ns4LegacyJourneyBusiness, 'useRules'> & {
            businessRules: Array<{
                journeyRuleId: string;
                statement: string;
            }>;
        });
        policyDecisions?: Ns4PolicyDecision[];
        businessHash: string;
        resolution: {
            status: 'pending' | 'compiled';
            contexts: Record<string, unknown>;
        };
        realization: {
            status: 'pending' | 'compiled';
            compiledFromBusinessHash: string;
            steps: Array<{
                stepId: string;
                useCaseRefs: string[];
            }>;
            transitionRefs: string[];
            realizationHash?: string;
        };
    }
    export type Ns4JourneyArtifact = Ns4JourneyArtifactV5 | Ns4JourneyArtifactV5Realized | Ns4LegacyJourneyArtifact;
    /** A journey written by a previous flow version still declares its context graph; it is never compiled. */
    export function isNs4CurrentJourneyBusiness(value: Ns4JourneyArtifact['business']): value is Ns4JourneyBusiness;
    export interface Ns4JourneyIndex {
        schemaVersion: typeof NS4_JOURNEY_INDEX_SCHEMA_VERSION | '2026-08-14-ns4-journey-index-v6' | '2026-08-12-ns4-journey-index-v5' | '2026-08-10-ns4-journey-index-v4' | '2026-08-04-ns4-journey-index-v1' | '2026-08-10-ns4-journey-index-v3' | '2026-08-09-ns4-journey-index-v2';
        moduleName: string;
        approvedAt: string;
        approvedBy: 'human' | 'auto';
        journeys: Array<{
            journeyId: string;
            actorRef: string;
            title: string;
            goal: string;
            entryMode: Ns4JourneyEntryMode;
            businessHash: string;
            artifactPath: string;
            useCaseRefs?: string[];
        }>;
        features: Ns4E2Feature[];
        /**
         * The decisions themselves, next to the selections that answer them. This is their durable home:
         * the journey artifact carries a copy while E2 is still reviewing, and E7 rewrites the artifact as
         * realized-v5, which has no policyDecisions — everything read after E7 reads the index.
         */
        policyDecisions?: Ns4JourneyIndexPolicyDecision[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        systemDecisions?: Ns4SystemDecision[];
        realizationHash?: string;
    }
    /** A policy decision with the journey that owns it; the index is flat, journeys reference by id. */
    export interface Ns4JourneyIndexPolicyDecision extends Ns4PolicyDecision {
        journeyRef: string;
    }
    export interface Ns4E2ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E2Review;
        policyDecisionSelections: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>;
    }
    export interface Ns4E2ImpactReport {
        schemaVersion: typeof NS4_E2_IMPACT_REPORT_SCHEMA_VERSION;
        moduleName: string;
        generatedAt: string;
        stepKindHistogram: Ns4E2StepKindHistogram;
        changes: Array<{
            journeyId: string;
            reason: 'hashDivergent' | 'journeyNew' | 'journeyRemoved';
        }>;
        affectedSteps: Array<'e3-access-matrix' | 'e4-ontology' | 'e5-rules' | 'e7-realization'>;
    }
    export function normalizeNs4E2Review(value: unknown, fallbackModule?: string, presentation?: Ns4Presentation): Ns4E2Review;
    export function buildNs4JourneyArtifacts(review: Ns4E2Review): Promise<Ns4JourneyArtifactV5[]>;
    export function buildNs4JourneyIndex(moduleName: string, review: Ns4E2Review, artifacts: Ns4JourneyArtifactV5[], artifactPaths: string[], approvedBy: 'human' | 'auto', approvedAt: string, policyDecisionSelections?: Ns4PolicyDecisionSelection[]): Ns4JourneyIndex;
    export function buildNs4PolicyDecisionSelections(review: Ns4E2Review, selectedChoices: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>, selectedBy: 'human' | 'auto', selectedAt: string): Ns4PolicyDecisionSelection[];
    export function buildNs4E2ImpactReport(moduleName: string, previousIndex: Ns4JourneyIndex | null, artifacts: Array<Pick<Ns4JourneyArtifactV5, 'journeyId' | 'businessHash'>>, generatedAt: string, review: Pick<Ns4E2Review, 'journeys'>): Ns4E2ImpactReport;
    export function sha256Ns4(value: unknown): Promise<string>;
    export function stableNs4Stringify(value: unknown): string;
    /**
     * Turns a human-spaced or already technical business noun into the stable PascalCase id shared by
     * journeys and ontology entities. The transformation is intentionally lexical: it never translates
     * or substitutes a domain noun.
     */
    export function normalizeNs4BusinessObjectId(value: unknown): string;
    /**
     * A journey with no decision, no handoff and one single entity IS the record catalogue of that
     * entity. Tier 1 already owns that screen, so the module records the demotion as a visible product
     * choice at the E2 checkpoint instead of shipping the same catalogue twice. The decision is
     * deterministic: it is recomputed on every round and is never authored by the generator.
     */
    export function withNs4DemotionDecisions(journeys: Ns4JourneyProposal[], presentation?: Ns4Presentation): Ns4JourneyProposal[];
    /** The journeys the approved review demoted to the tier 1 record catalogue of their entity. */
    export function collectNs4DemotedJourneyIds(review: Pick<Ns4E2Review, 'journeys'>, selections?: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>): string[];
    /** Business objects that later ontology compilation must realize as entities or projections. */
    export function collectNs4RequiredJourneyBusinessObjects(review: Ns4E2Review): string[];
}
declare module "_102035_/l2/agentNewSolution/steps/e3/contracts" {
    export const NS4_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-09-ns4-access-matrix-v2";
    export const NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-10-ns4-access-matrix-v3";
    export const NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-13-ns4-access-matrix-v4";
    export type Ns4AccessProfileKind = 'internal' | 'external';
    export type Ns4AccessScopeMode = 'organization' | 'assigned' | 'own' | 'related' | 'public' | 'custom';
    export type Ns4DisclosureMode = 'fullRecord' | 'summaryOnly' | 'fieldsOnly' | 'aggregateOnly';
    export interface Ns4AccessProfile {
        profileId: string;
        title: string;
        kind: Ns4AccessProfileKind;
        description: string;
        actorRefs: string[];
        landingIntent: string;
    }
    export interface Ns4AccessAuthority {
        authorityRef: string;
        title: string;
        description: string;
        journeyStepRefs: string[];
        informationNeeds: string[];
    }
    export interface Ns4AccessGrant {
        profileRef: string;
        authorityRef: string;
        reason: string;
        dataScope: {
            mode: Ns4AccessScopeMode;
            description: string;
        };
        disclosure: {
            mode: Ns4DisclosureMode;
            description: string;
            allowedInformation: string[];
            deniedInformation: string[];
        };
        useRules: string[];
    }
    export interface Ns4E3Review {
        planId: 'e3-access-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        changeSummary: string[];
    }
    export interface Ns4E3ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E3Review;
    }
    export interface Ns4AccessMatrixArtifactV2 {
        schemaVersion: typeof NS4_ACCESS_MATRIX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        accessHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromAccessHash: string;
            operationAuthorityRefs: never[];
        };
    }
    export interface Ns4AccessUseCaseAuthorityRef {
        useCaseId: string;
        authorityRef: string;
        journeyStepRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV3 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'useCasesCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            operationAuthorityRefs: never[];
            realizationHash: string;
        };
    }
    export interface Ns4AccessOperationAuthorityRef {
        operationRef: string;
        route: string;
        workspaceId: string;
        functionId: string;
        useCaseId?: string;
        authorityRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV4 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'navigationCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            operationAuthorityRefs: Ns4AccessOperationAuthorityRef[];
            realizationHash: string;
        };
    }
    /** Compile-only compatibility for already generated v1 L4 artifacts. */
    export interface Ns4AccessMatrixArtifactV1 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'grants'> {
        schemaVersion: '2026-08-05-ns4-access-matrix-v1';
        grants: Array<Omit<Ns4AccessGrant, 'useRules'> & {
            constraints: string[];
        }>;
    }
    export type Ns4AccessMatrixArtifact = Ns4AccessMatrixArtifactV4 | Ns4AccessMatrixArtifactV3 | Ns4AccessMatrixArtifactV2 | Ns4AccessMatrixArtifactV1;
    export function normalizeNs4E3Review(value: unknown, fallbackModule?: string): Ns4E3Review;
    export function buildNs4AccessMatrixArtifact(review: Ns4E3Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4AccessMatrixArtifactV2>;
}
declare module "_102035_/l2/agentNewSolution/steps/e4/contracts" {
    import { type Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    export const NS4_ONTOLOGY_SCHEMA_VERSION: "2026-08-11-ns4-ontology-v6";
    export type Ns4EntityKind = 'core' | 'event' | 'supporting' | 'mdm' | 'projection' | 'valueObject';
    /**
     * Is this entity a PARTY — a natural person or an organization?
     *
     * The question decides where the record lives, and it cannot be answered by a name heuristic (the run of
     * buildFlowFsm sent Client and Project to MDM but left FieldWorker — a person — as a module table, seeded,
     * duplicating the organization's own people). Declaring it makes the rule mechanical: a party is master
     * data of the organization, so `storage.target` must be `mdm`, and the gate says so instead of hoping the
     * prompt was read.
     */
    export type Ns4EntityParty = 'person' | 'organization' | 'none';
    export type Ns4EntityOwnership = 'moduleOwned' | 'external' | 'derived';
    export type Ns4DerivationOp = 'count' | 'sum' | 'min' | 'max' | 'first' | 'groupKey';
    /** One output field of a derived projection, computed from the source named by `derivation.from`. */
    export interface Ns4DerivationAggregate {
        fieldId: string;
        op: Ns4DerivationOp;
        /** Source-entity field when the op needs one (`sum`/`min`/`max`/`first`/`groupKey`). Absent for `count`. */
        sourceField?: string;
        /**
         * Sign of a `sum` from an enum on the source. OPTIONAL so L4 written before this field keeps
         * compiling — nothing is ever migrated. Only valid with `op: 'sum'`; `field` is an enum of
         * `derivation.from`, and rows whose value is in `negativeValues` enter the sum negative.
         */
        signBy?: {
            field: string;
            negativeValues: string[];
        };
    }
    /**
     * How a derived projection is computed. OPTIONAL on the type so L4 written before this field keeps
     * compiling — nothing is ever migrated. The E4 gate requires it on every `kind: projection` +
     * `ownership: derived` this generator now produces.
     */
    export interface Ns4EntityDerivation {
        /** entityId of the persisted source; must exist in the same ontology. */
        from: string;
        /** Predicate on declared fields of the source (`status = valid`). Empty when unfiltered. */
        filter: string;
        /** One entry per output field of the projection. */
        aggregate: Ns4DerivationAggregate[];
    }
    export type Ns4ConstraintSource = 'database' | 'journey' | 'user' | 'inferred' | 'legacyCode';
    export type Ns4StorageTarget = 'mdm' | 'moduleDatabase' | 'derived' | 'external' | 'embedded';
    export type Ns4StorageScope = 'organization' | 'module' | 'platform' | 'none';
    export type Ns4RelationshipPersistenceMode = 'mdmRelationship' | 'moduleReference' | 'crossStoreReference' | 'derivedJoin' | 'externalReference' | 'embedded';
    export type Ns4RelationshipRealizationKind = 'fieldReference' | 'fieldCollection' | 'mdmRelationship' | 'derived' | 'externalReference' | 'embedded';
    export interface Ns4RelationshipEndpointBinding {
        entityId: string;
        fieldIds: string[];
    }
    /** Concrete implementation of one semantic edge using fields that already exist in E4 entities. */
    export interface Ns4RelationshipRealization {
        kind: Ns4RelationshipRealizationKind;
        ownerEntity: string;
        from: Ns4RelationshipEndpointBinding;
        to: Ns4RelationshipEndpointBinding;
        description: string;
    }
    export interface Ns4FieldConstraint {
        constraintId: string;
        kind: 'min' | 'max' | 'minLength' | 'maxLength' | 'pattern' | 'enum' | 'format' | 'unique' | 'custom';
        value: string;
        description: string;
        source: Ns4ConstraintSource;
    }
    /** Display text for one closed-domain code. Array-of-objects so the tool schema can stay additionalProperties:false. */
    export interface Ns4EnumLabel {
        code: string;
        label: string;
    }
    export interface Ns4OntologyField {
        fieldId: string;
        title: string;
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        required: boolean;
        description: string;
        constraints: Ns4FieldConstraint[];
        /**
         * The literal values of an enumerated field, derived from its enum constraint (or from the entity
         * lifecycle for a status field). It is what turns a decision into a closed selector on the page
         * instead of a free text box; the constraint stays as the human-readable rule.
         */
        enum?: string[];
        /**
         * User-language labels for `enum` codes. OPTIONAL on the type so L4 written before this field keeps
         * compiling — nothing is ever migrated. New E4 runs backfill any gap with a humanized code and a
         * non-blocking systemDecision; the model should still author the user's language.
         */
        enumLabels?: Ns4EnumLabel[];
    }
    export interface Ns4LifecyclePredicate {
        predicateId: string;
        description: string;
        stateIds: string[];
        source: Ns4ConstraintSource;
    }
    export interface Ns4OntologyEntity {
        entityId: string;
        title: string;
        description: string;
        kind: Ns4EntityKind;
        ownership: Ns4EntityOwnership;
        /**
         * A core entity with one fixed instance (a petition, an institutional page). OPTIONAL so L4
         * written before this field keeps compiling. E8 skips the record catalogue when it is present.
         */
        cardinality?: 'singleton';
        /**
         * Whether records of this entity may be corrected or removed after they exist. OPTIONAL so L4
         * written before this field keeps compiling — nothing is ever migrated; absent = editable.
         * `appendOnly` is a fact, a posting, a meter reading, a signature: E8 emits no update/delete.
         */
        mutability?: 'editable' | 'appendOnly';
        /**
         * Required by the gate for everything this generator now produces; OPTIONAL in the type so the L4
         * artifacts written before it (schema v6, no `party`) keep compiling — nothing is ever migrated.
         */
        party?: Ns4EntityParty;
        /**
         * Required by the gate when `kind === 'projection'` and `ownership === 'derived'`; OPTIONAL in the
         * type so L4 written before this field keeps compiling — nothing is ever migrated.
         */
        derivation?: Ns4EntityDerivation;
        sourceRefs: {
            journeyIds: string[];
            featureIds: string[];
            authorityRefs: string[];
        };
        fields: Ns4OntologyField[];
        lifecycleStates: string[];
        /** The lifecycle values as a literal union; mirrors lifecycleStates and is never a second truth. */
        statusEnum?: string[];
        /** User-language labels for `lifecycleStates`. OPTIONAL on the type; new E4 runs backfill a gap. */
        lifecycleLabels?: Ns4EnumLabel[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates: Ns4LifecyclePredicate[];
        useRules: string[];
        storage: {
            target: Ns4StorageTarget;
            scope: Ns4StorageScope;
            idField?: string;
            mdmType?: string;
            notes: string;
        };
    }
    export interface Ns4OntologyRelationship {
        relationshipId: string;
        fromEntity: string;
        toEntity: string;
        type: 'oneToOne' | 'oneToMany' | 'manyToOne' | 'manyToMany';
        required: boolean;
        description: string;
        persistence: {
            mode: Ns4RelationshipPersistenceMode;
        };
        /** Absent only in the compact overview; mandatory before review and permanent emission. */
        realization?: Ns4RelationshipRealization;
    }
    export type Ns4ResolvedOntologyRelationship = Ns4OntologyRelationship & {
        realization: Ns4RelationshipRealization;
    };
    export type Ns4OntologyEntityPlan = Omit<Ns4OntologyEntity, 'fields' | 'useRules'>;
    export interface Ns4E4PlanDraft {
        planId: 'e4-ontology-plan';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntityPlan[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
    }
    export interface Ns4E4EntityDraft {
        planId: 'e4-ontology-entity';
        moduleName: string;
        reviewRound: number;
        entityId: string;
        fields: Ns4OntologyField[];
        useRules: string[];
    }
    export interface Ns4E4RelationshipBinding {
        relationshipId: string;
        realization: Ns4RelationshipRealization;
    }
    export interface Ns4E4RelationshipBindingsDraft {
        planId: 'e4-relationship-bindings';
        moduleName: string;
        reviewRound: number;
        bindings: Ns4E4RelationshipBinding[];
    }
    export interface Ns4E4DerivationBinding {
        entityId: string;
        derivation: Ns4EntityDerivation;
    }
    export interface Ns4E4DerivationBindingsDraft {
        planId: 'e4-derivation-bindings';
        moduleName: string;
        reviewRound: number;
        bindings: Ns4E4DerivationBinding[];
        changeSummary?: string[];
    }
    export interface Ns4E4DerivationBindingIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E4DerivationFieldIdChange {
        entityId: string;
        before: string[];
        after: string[];
    }
    /** Binding-gate finding that the entity fan-out must repair — travels as a typed payload, not a loose string. */
    export interface Ns4E4EntityFeedback {
        entityId: string;
        feedback: string;
    }
    export interface Ns4E4Review {
        planId: 'e4-ontology-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntity[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
        /** Type C label backfills and Type B registrars such as NS4_E4_CORE_READ_ONLY. */
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4E4ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E4Review;
    }
    export interface Ns4OntologyEntityArtifactV5 extends Ns4OntologyEntity {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
    }
    /** Compile-only compatibility for already generated v3 L4 artifacts. */
    export interface Ns4OntologyEntityArtifactV4 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion'> {
        schemaVersion: '2026-08-09-ns4-ontology-v4';
    }
    export interface Ns4OntologyEntityArtifactV3 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion' | 'useRules'> {
        schemaVersion: '2026-08-08-ns4-ontology-v3';
        invariants: Array<{
            invariantId: string;
            description: string;
            source: Ns4ConstraintSource;
        }>;
    }
    export type Ns4OntologyEntityArtifact = Ns4OntologyEntityArtifactV5 | Ns4OntologyEntityArtifactV4 | Ns4OntologyEntityArtifactV3;
    interface Ns4OntologyIndexArtifactBase {
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        title: string;
        businessDomain: string;
        entities: Array<{
            entityId: string;
            title: string;
            kind: Ns4EntityKind;
            storage: Pick<Ns4OntologyEntity['storage'], 'target' | 'scope' | 'idField' | 'mdmType'>;
            definitionRef: string;
        }>;
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromOntologyHash: string;
        };
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4OntologyIndexArtifactV5 extends Ns4OntologyIndexArtifactBase {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        relationships: Ns4ResolvedOntologyRelationship[];
    }
    /** Compile-only compatibility for already generated v3/v4 L4 artifacts. */
    export interface Ns4OntologyIndexArtifactLegacy extends Ns4OntologyIndexArtifactBase {
        schemaVersion: '2026-08-09-ns4-ontology-v4' | '2026-08-08-ns4-ontology-v3';
        relationships: Ns4OntologyRelationship[];
    }
    export type Ns4OntologyIndexArtifact = Ns4OntologyIndexArtifactV5 | Ns4OntologyIndexArtifactLegacy;
    export function normalizeNs4E4Review(value: unknown, fallbackModule?: string): Ns4E4Review;
    /** `inProgress` → `In progress`. Fallback when the model omitted a user-language label. */
    export function humanizeNs4EnumCode(code: string): string;
    export function normalizeNs4E4PlanDraft(value: unknown, fallbackModule?: string): Ns4E4PlanDraft;
    export function normalizeNs4E4EntityDraft(value: unknown, moduleName: string, reviewRound: number, entityId: string): Ns4E4EntityDraft;
    /**
     * Removes the derived literal union from fields before they are echoed back to an entity worker.
     * The union is a projection E4 adds for the consumers; the worker's strict tool schema forbids the
     * key, so showing it in a prompt would invite an invalid repair answer.
     */
    export function stripNs4DerivedFieldUnions<T extends {
        fields?: unknown;
    }>(value: T): T;
    export function stripNs4DerivedFieldUnions(value: Ns4OntologyField[]): Ns4OntologyField[];
    export function assembleNs4E4Review(plan: Ns4E4PlanDraft, details: Ns4E4EntityDraft[]): Ns4E4Review;
    export function normalizeNs4E4RelationshipBindings(value: unknown, moduleName: string, reviewRound: number): Ns4E4RelationshipBindingsDraft;
    export function applyNs4E4RelationshipBindings(review: Ns4E4Review, draft: Ns4E4RelationshipBindingsDraft): Ns4E4Review;
    export function normalizeNs4E4DerivationBindings(value: unknown, moduleName: string, reviewRound: number): Ns4E4DerivationBindingsDraft;
    export function applyNs4E4DerivationBindings(plan: Ns4E4PlanDraft, payload: unknown): {
        plan: Ns4E4PlanDraft;
        issues: Ns4E4DerivationBindingIssue[];
        fieldIdChanges: Ns4E4DerivationFieldIdChange[];
    };
    export function buildNs4OntologyArtifacts(review: Ns4E4Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<{
        entities: Ns4OntologyEntityArtifactV5[];
        index: Ns4OntologyIndexArtifactV5;
    }>;
    export function normalizeDerivation(value: unknown): Ns4EntityDerivation | undefined;
}
declare module "_102035_/l2/agentNewSolution/steps/e5/contracts" {
    export const NS4_RULES_SCHEMA_VERSION: "2026-08-09-ns4-rules-v2";
    /** The permanent business-rule contract. Meaning lives here; consumers keep only the id. */
    export interface Ns4RuleDefinition {
        id: string;
        description: string;
    }
    export interface Ns4E5Review {
        planId: 'e5-rules-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        rules: Ns4RuleDefinition[];
        changeSummary: string[];
    }
    export interface Ns4E5ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E5Review;
    }
    export interface Ns4RulesArtifact {
        schemaVersion: typeof NS4_RULES_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        rules: Ns4RuleDefinition[];
        rulesHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromRulesHash: string;
        };
    }
    export function normalizeNs4E5Review(value: unknown, fallbackModule?: string): Ns4E5Review;
    export function buildNs4RulesArtifact(review: Ns4E5Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4RulesArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e6/contracts" {
    export const NS4_COMPOSITION_SCHEMA_VERSION: "2026-08-09-ns4-composition-v1";
    export type Ns4AdditionalCapabilityKind = 'horizontalModule' | 'plugin';
    export type Ns4AdditionalCapabilityDecision = 'include' | 'defer';
    export interface Ns4AdditionalCapability {
        id: string;
        kind: Ns4AdditionalCapabilityKind;
        title: string;
        purpose: string;
        decision: Ns4AdditionalCapabilityDecision;
    }
    export interface Ns4E6Review {
        planId: 'e6-composition-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        changeSummary: string[];
    }
    export interface Ns4E6ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E6Review;
    }
    export interface Ns4CompositionArtifact {
        schemaVersion: typeof NS4_COMPOSITION_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        compositionHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromCompositionHash: string;
        };
    }
    export function normalizeNs4E6Review(value: unknown, fallbackModule?: string): Ns4E6Review;
    export function buildNs4CompositionArtifact(review: Ns4E6Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4CompositionArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/reachability" {
    export interface Ns4ReachabilityTransition {
        fromStates: string[];
        toState: string;
    }
    /** The single E7 definition used by both workflow compilation and its post-resolution gate. */
    export function collectNs4ReachableWorkflowStates(initialState: string, transitions: Ns4ReachabilityTransition[]): Set<string>;
    /**
     * Shrinks unreachable states and their outgoing transitions until no new orphan target appears.
     * fromStates are alternatives, so a transition survives while at least one source remains.
     */
    export function shrinkNs4WorkflowToReachable<TTransition extends Ns4ReachabilityTransition>(initialState: string, sourceStates: string[], sourceTransitions: TTransition[]): {
        states: string[];
        transitions: TTransition[];
        removedStates: string[];
    };
}
declare module "_102035_/l2/agentNewSolution/steps/e7/contracts" {
    import type { Ns4E2Review, Ns4JourneyArtifact, Ns4JourneyArtifactV5Realized, Ns4JourneyIndex } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact, Ns4AccessMatrixArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import { type Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4DerivedContextGraph } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_USE_CASE_DRAFT_VERSION: "2026-08-10-ns4-usecase-draft-minimal-v3";
    export const NS4_USE_CASE_SCHEMA_VERSION: "2026-08-10-ns4-usecase-v3";
    export const NS4_USE_CASE_INDEX_SCHEMA_VERSION: "2026-08-10-ns4-usecase-index-v3";
    export const NS4_WORKFLOW_SCHEMA_VERSION: "2026-08-11-ns4-workflow-v4";
    export const NS4_WORKFLOW_INDEX_SCHEMA_VERSION: "2026-08-12-ns4-workflow-index-v5";
    export type Ns4UseCaseKind = 'query' | 'command';
    export type Ns4UseCaseFieldType = Ns4OntologyField['type'];
    export interface Ns4E7SourceHashes {
        journeys: Array<{
            journeyId: string;
            businessHash: string;
        }>;
        ontologyHash: string;
        rulesHash: string;
    }
    export interface Ns4E7PlanUseCase {
        useCaseId: string;
        title: string;
        kind: Ns4UseCaseKind;
        compiledFrom: string[];
        contexts: {
            requires: string[];
            provides: string[];
        };
    }
    export interface Ns4E7PlanDraft {
        planId: 'e7-realization-plan';
        moduleName: string;
        userLanguage: string;
        useCases: Ns4E7PlanUseCase[];
        sourceHashes: Ns4E7SourceHashes;
        presentation?: Ns4Presentation;
    }
    export interface Ns4UseCaseFieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4UseCaseInput {
        inputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseOutput {
        outputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        contextId?: string;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseEntityAccess {
        entityId: string;
        fieldRefs: string[];
    }
    export interface Ns4UseCaseTransition {
        transitionId: string;
        entityRef: string;
        fromStates: string[];
        toState: string;
        useRules: string[];
    }
    export interface Ns4UseCaseError {
        errorId: string;
        description: string;
        when: string;
        useRules: string[];
    }
    export interface Ns4UseCaseDraft extends Ns4E7PlanUseCase {
        draftVersion: typeof NS4_USE_CASE_DRAFT_VERSION;
        planId: 'e7-usecase';
        moduleName: string;
        description: string;
        contexts: {
            requires: string[];
            provides: string[];
        };
        entityRefs: string[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
    }
    export interface Ns4UseCaseArtifactV3 extends Omit<Ns4UseCaseDraft, 'planId' | 'draftVersion' | 'transitions'> {
        schemaVersion: typeof NS4_USE_CASE_SCHEMA_VERSION;
        transitionRefs: string[];
        useCaseHash: string;
    }
    export interface Ns4UseCaseIndexArtifactV3 {
        schemaVersion: typeof NS4_USE_CASE_INDEX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowTransition extends Ns4UseCaseTransition {
        useCaseId?: string;
        trigger?: 'system';
    }
    /** Lifecycle facts are owned by E4 and copied mechanically into E7 workflows. */
    export interface Ns4WorkflowLifecycleDefinition {
        states: string[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates?: Array<{
            predicateId: string;
            stateIds: string[];
        }>;
    }
    export interface Ns4WorkflowArtifactV2 {
        schemaVersion: typeof NS4_WORKFLOW_SCHEMA_VERSION;
        moduleName: string;
        workflowId: string;
        entityRef: string;
        initialState: string;
        terminalStates: string[];
        states: string[];
        transitions: Ns4WorkflowTransition[];
        workflowHash: string;
    }
    export interface Ns4WorkflowIndexArtifactV2 {
        schemaVersion: '2026-08-11-ns4-workflow-index-v4';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifactV3 extends Omit<Ns4WorkflowIndexArtifactV2, 'schemaVersion'> {
        schemaVersion: typeof NS4_WORKFLOW_INDEX_SCHEMA_VERSION;
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4UseCaseArtifact extends Ns4E7PlanUseCase {
        schemaVersion: '2026-08-10-ns4-usecase-v2';
        moduleName: string;
        description: string;
        inputs: Ns4UseCaseInput[];
        outputs: Ns4UseCaseOutput[];
        reads: Ns4UseCaseEntityAccess[];
        writes: Ns4UseCaseEntityAccess[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
        errors: Ns4UseCaseError[];
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCaseHash: string;
        generatedAt: string;
    }
    export interface Ns4UseCaseIndexArtifact {
        schemaVersion: '2026-08-10-ns4-usecase-index-v2';
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-v1';
        moduleName: string;
        userLanguage: string;
        workflowId: string;
        entityRef: string;
        states: string[];
        transitions: Ns4WorkflowTransition[];
        sourceHashes: Ns4E7SourceHashes;
        workflowHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-index-v1';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    /** Contexts come from the derivation, never from the journey text: E7 copies no declared name. */
    export function buildNs4E7Plan(moduleName: string, userLanguage: string, journeys: Ns4E2Review, sourceHashes: Ns4E7SourceHashes, contexts: Ns4DerivedContextGraph, presentation?: Ns4Presentation): Ns4E7PlanDraft;
    export function normalizeNs4UseCaseDraft(value: unknown, plan: Ns4E7PlanDraft, useCaseId: string): Ns4UseCaseDraft;
    export function buildNs4UseCaseArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], generatedAt: string): Promise<{
        artifacts: Ns4UseCaseArtifactV3[];
        index: Ns4UseCaseIndexArtifactV3;
    }>;
    export function buildNs4WorkflowArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], ontologyLifecycles: Map<string, Ns4WorkflowLifecycleDefinition>, generatedAt: string): Promise<{
        artifacts: Ns4WorkflowArtifactV2[];
        index: Ns4WorkflowIndexArtifactV3;
    }>;
    export function buildNs4RealizedJourneyArtifact(source: Ns4JourneyArtifact, useCases: Ns4UseCaseArtifactV3[], derived: Ns4DerivedContextGraph): Promise<Ns4JourneyArtifactV5Realized>;
    export function buildNs4RealizedJourneyIndex(source: Ns4JourneyIndex, journeys: Ns4JourneyArtifactV5Realized[]): Promise<Ns4JourneyIndex>;
    export function buildNs4RealizedAccessArtifact(source: Ns4AccessMatrixArtifact, useCases: Ns4UseCaseArtifactV3[]): Promise<Ns4AccessMatrixArtifactV3>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ForeignKeys" {
    /**
     * Where a foreign key POINTS.
     *
     * An input's `fieldRef` names the entity that OWNS the field (`BillingLaborAllocation.clientBillingSummaryId`),
     * never the entity the id refers to. Reading the target off that prefix is how the E8 picker check
     * ended up comparing an entity with itself and passing in silence, while 48 command inputs across 15
     * workspaces asked the user to pick a record the screen could not show. The target only exists in the
     * relationship graph, so it is resolved here, once, for every consumer.
     */
    export interface Ns4FkRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
        realization?: {
            ownerEntity?: string;
            from?: {
                fieldIds?: string[];
            };
        };
    }
    export interface Ns4FkParent {
        parent: string;
        fieldId: string;
        required: boolean;
    }
    /** Owner entity -> the parents it references, with the field that holds each id. */
    export function buildNs4ParentIndex(relationships: readonly Ns4FkRelationship[]): Map<string, Ns4FkParent[]>;
    /** The entity a given field of a given entity points at, or null when the field is not a key. */
    export function ns4FkParentOf(index: Map<string, Ns4FkParent[]>, entityId: string, fieldId: string): Ns4FkParent | null;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/contracts" {
    import type { Ns4E2Review, Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { type Ns4DerivedContext } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export interface Ns4E8HubScore {
        entityRef: string;
        score: number;
        anchoredJourneyCount: number;
        requiredRelationshipCount: number;
        projectionCount: number;
        locateUseCaseCount: number;
    }
    /** A workspace context is exactly the derived journey context; E8 never invents another shape. */
    export type Ns4WorkspaceContext = Ns4DerivedContext;
    /**
     * The E1 prose a contentPage may quote into organisms. Detection itself is structural
     * (public external grant + singleton read) — this blob is copy, not the door.
     */
    export interface Ns4E8ModuleSignals {
        title: string;
        purpose: string;
        mainGoal?: string;
        expectedOutcomes?: Array<{
            outcomeId?: string;
            title: string;
            description: string;
        }>;
        inScope?: string[];
        outOfScope?: string[];
        boundaries?: string;
    }
    /** The approved contracts every E8 derivation reads. */
    export interface Ns4E8Sources {
        journeys: Ns4E2Review;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        useCases: Ns4UseCaseArtifactV3[];
        workflows: Ns4WorkflowArtifactV2[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        module?: Ns4E8ModuleSignals;
        presentation?: Ns4Presentation;
    }
    export interface Ns4E8Edge {
        from: string;
        to: string;
        carries: string[];
        preferredFromJourneyRef?: string;
    }
    export function deriveE8HubScore(sources: Ns4E8Sources, derived?: import("/_102035_/l2/agentNewSolution/helpers/ns4Context.js").Ns4DerivedContextGraph): Ns4E8HubScore[];
    export function isPlatformOwnedEntity(entity: Ns4E4Review['entities'][number]): boolean;
    /**
     * Compile-only compatibility for workspaces written by the previous E8 model (runs 38-44). They are
     * never read or migrated — the union exists so already-generated L4 folders keep type-checking.
     */
    export interface Ns4WorkspaceArtifact {
        schemaVersion: string;
        moduleName: string;
        workspaceId: string;
        kind: string;
        title: string;
        description: string;
        anchorEntity?: string;
        profileRefs: string[];
        pageContext: Array<Record<string, unknown>>;
        scenarios: Array<Record<string, unknown>>;
        viewCall: {
            uses: Array<Record<string, unknown>>;
        };
        commands: string[];
        invalidations: Array<{
            useCaseId: string;
            sliceIds: string[];
        }>;
        skeletonHash: string;
        workspaceHash: string;
    }
    export interface Ns4WorkspaceIndex {
        schemaVersion: string;
        moduleName: string;
        userLanguage: string;
        workspaces: Array<Record<string, unknown>>;
        hubs: Array<Record<string, unknown>>;
        menu: Record<string, unknown>;
        skeletonHash: string;
        systemDecisions: Array<Record<string, unknown>>;
        approvedBy: string;
        approvedAt: string;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e8/model" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8Sources } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    export const NS4_E8_MODEL_VERSION: "2026-08-14-ns4-e8-model-v1";
    export type Ns4WorkspaceTier = 'recordCatalogue' | 'journey' | 'hub' | 'projection' | 'contentPage';
    /** Organisms of type `content` use these roles; they exist only on a `contentPage`. */
    export type Ns4E8ContentRole = 'hero' | 'richText' | 'imageSet' | 'ctaLink';
    /**
     * The only origins a page can render by, in the vocabulary the frontend actually reads from an
     * operation input: userInput is a form field, selectedEntity is a picker over a query on the page,
     * routeParam comes from the URL, and the rest is resolved at runtime and never rendered.
     */
    export type Ns4E8InputSource = 'userInput' | 'selectedEntity' | 'routeParam' | 'actorSession' | 'systemDefault';
    /**
     * The record-owner handle: a field that points at a `party: person` entity (its own identity, or a
     * foreign key to one) when every E3 grant that operates the record is `dataScope.mode: own` — or
     * when the session actor is that person (an `own`/`assigned`/`related` grant). Never a field name.
     */
    export function isNs4OwnerHandleInput(input: {
        fieldRef: Ns4E8FieldRef;
        inputId?: string;
    }, sources: Ns4E8Sources): boolean;
    export type Ns4E8AccessPatternKind = 'list' | 'getById' | 'create' | 'update' | 'delete' | 'transition' | 'commandInput';
    export interface Ns4E8FieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4E8Input {
        inputId: string;
        fieldRef: Ns4E8FieldRef;
        source: Ns4E8InputSource;
        required: boolean;
        description: string;
        /** The literal union of an enumerated field, carried from the approved ontology. */
        enumValues?: string[];
        /** Present when the input is not the borrowed fieldRef's type (`page`/`pageSize` are numbers). */
        type?: 'number' | 'boolean' | 'string';
    }
    /**
     * One operation of the module. A journey step compiles into the E7 use case it already owns; a
     * record catalogue synthesizes its five operations from the ontology (list, getById, create,
     * update, and delete or the mdm inactivate/reactivate pair), because E7 only compiles journeys
     * and a catalogue is not a journey. getById is emitted even when no page consumes it.
     */
    /**
     * Master-data semantics of one operation. Master data is referenced by other
     * records, so an mdm catalogue deactivates instead of deleting.
     *
     * It is ONE optional block on purpose. The backend generator reads this artifact
     * as JSON and its accessPattern vocabulary is a closed set, so the lifecycle pair
     * keeps `kind: 'update'` — a command that mutates one identified record, which the
     * consumer already understands — and the meaning travels here. A consumer that
     * ignores the block behaves exactly as before.
     */
    export interface Ns4E8MdmSemantics {
        /** The command replaces a hard delete: route it to the MDM record lifecycle. */
        lifecycle?: 'inactivate' | 'reactivate';
        /** Optional request flag on a list: absent means only active records. */
        activeFilterInput?: 'includeInactive';
        /**
         * Response member carrying the situation. Derived from the MDM record lifecycle,
         * so it is NOT an ontology field and deliberately has no field ref: the ontology
         * declares no `active` field and the model must not invent one.
         */
        situationOutput?: 'active';
    }
    export interface Ns4E8Operation {
        operationId: string;
        title: string;
        kind: 'query' | 'command';
        entityRef: string;
        entityRefs: string[];
        accessPattern: {
            kind: Ns4E8AccessPatternKind;
            pagination?: 'optional';
        };
        inputs: Ns4E8Input[];
        outputRefs: string[];
        useRules: string[];
        transitionRefs: string[];
        story: string[];
        /** Present when the operation is an approved E7 use case; absent when the catalogue derived it. */
        useCaseId?: string;
        /** Present only on a catalogue operation of an entity whose storage.target is mdm. */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4E8BffCall {
        bffId: string;
        kind: 'query' | 'command';
        operationId: string;
        outputKind: 'object' | 'list' | 'paginated';
        entityRef: string;
        /**
         * Which LOCAL call feeds each input of this one. Operations are shared and calls are per workspace,
         * so "where the user picks this record from" is a property of the call, never of the operation.
         * Without it the screen knows an id must be chosen and not which query to choose it from.
         */
        inputSources?: Array<{
            inputId: string;
            bffId: string;
        }>;
    }
    export type Ns4E8OrganismRole = 'primarySurface' | 'detailPanel' | 'filterControl' | 'contextualAction' | Ns4E8ContentRole;
    export interface Ns4E8Organism {
        role: Ns4E8OrganismRole;
        /** Present only on a content organism (hero/richText/imageSet/ctaLink). Never on a data-bound surface. */
        type?: 'content';
        dataSource?: string;
        action?: string;
        /** A picker is a query rendered to choose the record another call consumes. summary is counts of that list, not a row. */
        usage?: 'picker' | 'summary';
        /** Query bffId whose optional list inputs (search/sort) this filterControl drives. */
        attachTo?: string;
    }
    export interface Ns4E8Section {
        sectionId: string;
        intent: string;
        organisms: Ns4E8Organism[];
    }
    export interface Ns4E8ModelWorkspace {
        workspaceId: string;
        tier: Ns4WorkspaceTier;
        title: string;
        purpose: string;
        /** Classic workspace kind: operation, workflow, landing or record. */
        kind: 'operation' | 'workflow' | 'landing' | 'record';
        entity: string;
        workflowId?: string;
        actors: string[];
        profileRefs: string[];
        featureRefs: string[];
        hostedStepRefs: string[];
        journeyRef?: string;
        categoryRef: string;
        bffCalls: Ns4E8BffCall[];
        sections: Ns4E8Section[];
        /** Only a hub carries the closed catalogue its composition call may order and name. */
        hubCatalogue?: Ns4E8HubCatalogue;
        /** Workspaces this one links to; the site map turns them into navigation edges. */
        navigation?: Ns4E8NavigationTarget[];
    }
    export interface Ns4E8HubCatalogueItem {
        itemId: string;
        kind: 'projectionTile' | 'relatedList' | 'action' | 'pending';
        label: string;
        entityRef: string;
        /** The workspace the item belongs to; never invented by the composition call. */
        targetRef: string;
        /**
         * For an item the hub READS: the operation behind it. Operations are shared across the module and
         * calls are per workspace, so a tile becomes a local call of the hub over the same operation — an
         * organism only ever consumes a call of its own workspace.
         */
        sourceOperationId?: string;
        sourceBffId?: string;
        /** The shape the source call declares; a list read as an object would project a single record. */
        sourceOutputKind?: 'object' | 'list' | 'paginated';
        score: number;
    }
    /**
     * A journey reached from the hub is NAVIGATION, not an embedded command: it leaves the sections and
     * travels to the site map, carrying the prominence and order the composition chose.
     */
    export interface Ns4E8NavigationTarget {
        targetWorkspaceId: string;
        label: string;
        prominence: 'primary' | 'contextual';
        order: number;
    }
    export interface Ns4E8HubCatalogue {
        anchorEntity: string;
        items: Ns4E8HubCatalogueItem[];
    }
    export interface Ns4E8HubComposition {
        workspaceId: string;
        title: string;
        /** Catalogue item ids, in display order. Never a new id. */
        tileOrder: string[];
        primaryActionIds: string[];
        labels: Array<{
            itemId: string;
            label: string;
        }>;
        menuGroups: Array<{
            groupId: string;
            label: string;
            itemIds: string[];
        }>;
    }
    export interface Ns4E8MenuEntry {
        workspaceId: string;
        label: string;
        featureRef: string;
        tier: Ns4WorkspaceTier;
        profileRefs: string[];
    }
    export interface Ns4E8Model {
        planId: 'e8-workspace-model';
        schemaVersion: typeof NS4_E8_MODEL_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        hubEntity: string;
        workspaces: Ns4E8ModelWorkspace[];
        operations: Ns4E8Operation[];
        /** The menu lists places only: catalogues, hubs, projections and content pages. A journey is never a menu item. */
        menu: Ns4E8MenuEntry[];
        landings: Array<{
            profileRef: string;
            workspaceId: string;
        }>;
        systemDecisions: Ns4SystemDecision[];
        modelHash?: string;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e9/classic" {
    /**
     * E9 is a transpiler. It takes no screen decision: every workspace, call, section and operation was
     * already decided by E8. What lives here is the shape the consumers read — the classic L4 format
     * that agentChangeBackend and agentChangeFrontend already parse today.
     *
     * The one thing that must be exactly right is the `from` path of a projected field,
     * `"<operationId>.<inputId>"`, because both consumers trace an input's origin and an enumerated
     * field's literal union back through it (cbContracts.resolveBffProjection and
     * cfeL4Contract.bffCallCommandShape).
     */
    import type { Ns4E4Review } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4E8Input, Ns4E8MdmSemantics, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export const NS4_CLASSIC_WORKSPACE_VERSION: "2026-08-14-ns4-classic-workspace-v6";
    export const NS4_E9_OUTPUT_REF_UNKNOWN: "NS4_E9_OUTPUT_REF_UNKNOWN";
    export class Ns4E9OutputRefError extends Error {
        readonly code: "NS4_E9_OUTPUT_REF_UNKNOWN";
        constructor(ref: string);
    }
    export interface Ns4ClassicField {
        name: string;
        from: string;
        type?: string;
        required?: boolean;
        item?: {
            fields: Ns4ClassicField[];
        };
    }
    export interface Ns4ClassicBffCall {
        bffId: string;
        kind: 'query' | 'command';
        uses: Array<{
            operationId: string;
        }>;
        input: Array<{
            name: string;
            from: string;
            required?: boolean;
            source: string;
            sourceRef?: string;
            type: string;
            enumValues?: string[];
        }>;
        output: {
            kind: 'object' | 'list' | 'paginated';
            fields: Ns4ClassicField[];
        };
        route: string;
    }
    export interface Ns4ClassicWorkspace {
        workspaceId: string;
        title: string;
        actors: string[];
        kind: string;
        entity: string;
        workflowId?: string;
        bffCalls: Ns4ClassicBffCall[];
        sections: Array<{
            sectionId: string;
            intent: string;
            organisms: Array<Record<string, string>>;
        }>;
        operationIds: string[];
        purpose: string;
        presentation: {
            categoryRef: string;
            confidence: number;
            classificationNote: string;
        };
        sliceHash: string;
    }
    export interface Ns4ClassicOperation {
        operationId: string;
        title: string;
        actors: string[];
        entity: string;
        kind: string;
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        story: {
            actor: string;
            goal: string;
            steps: string[];
            outcome: string;
        };
        accessPattern: {
            kind: string;
            description: string;
            entity: string;
            keyField: string;
            pagination: string;
            selection: string;
            output: string[];
        };
        outputShape: {
            kind: 'object' | 'list' | 'paginated';
            fields: Array<{
                name: string;
                type: string;
                required: boolean;
                fieldRef?: string;
                item?: {
                    fields: Array<{
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    }>;
                };
            }>;
        };
        inputs: Array<{
            inputId: string;
            fieldRef: string;
            required: boolean;
            source: string;
            description: string;
            enumValues?: string[];
            type?: string;
        }>;
        pageId: string;
        commandName: string;
        bffName: string;
        /**
         * Carried verbatim from the model when the operation is a master-data catalogue
         * operation. It is what lets the backend generator route the lifecycle pair to
         * the MDM facade and keep the list active-only. Optional, so a consumer that
         * ignores it is unaffected.
         */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4ClassicSiteMap {
        moduleName: string;
        note: string;
        workspaces: Array<{
            workspaceId: string;
            title: string;
            actors: string[];
            kind: string;
            entity: string;
            operationIds: string[];
            purpose: string;
        }>;
        landings: Array<{
            actorId: string;
            workspaceId: string;
            reason: string;
        }>;
        navigationEdges: Array<{
            from: string;
            to: string;
            operationId: string;
            description: string;
            prominence?: 'primary' | 'contextual';
            order?: number;
        }>;
        workspaceIds: string[];
    }
    /** `<operationId>.<inputId>`: the only path both consumers know how to trace back. */
    export function ns4ClassicFrom(operationId: string, member: string): string;
    export function transposeNs4ClassicOperation(model: Ns4E8Model, operation: Ns4E8Operation, ontology: Ns4E4Review): Ns4ClassicOperation;
    export function transposeNs4ClassicWorkspace(model: Ns4E8Model, workspace: Ns4E8ModelWorkspace, operations: Map<string, Ns4E8Operation>, ontology: Ns4E4Review, sliceHash: string): Ns4ClassicWorkspace;
    type ClassicOutputField = {
        name: string;
        type: string;
        required: boolean;
        fieldRef: string;
    };
    /**
     * The wire shape is what E8 declared in outputRefs. A catalogue command whose refs are only the
     * identity still projects the entity fields it always did, so modules without a joined projection
     * keep today's outputShape. An unknown ref is a blocking E9 finding, never a silent `unknown`.
     */
    export function resolveClassicOutputFields(operation: Ns4E8Operation, ontology: Ns4E4Review): ClassicOutputField[];
    /** One TypeScript contract file per bffCall, byte-compatible with what the CFE reads today. */
    export function buildNs4ClassicContractSource(args: {
        moduleName: string;
        workspaceId: string;
        call: Ns4ClassicBffCall;
        fileRef: string;
        sourceRef: string;
    }): string;
    export function buildNs4ClassicSiteMap(model: Ns4E8Model, classic: Ns4ClassicWorkspace[]): Ns4ClassicSiteMap;
    /** Declared collection name on the wire — never the generic `items`. */
    export function collectionFieldName(entityId: string): string;
    export interface Ns4ClassicL4 {
        workspaces: Ns4ClassicWorkspace[];
        operations: Ns4ClassicOperation[];
        contracts: Array<{
            workspaceId: string;
            bffId: string;
            route: string;
            source: string;
        }>;
        siteMap: Ns4ClassicSiteMap;
    }
    /** The whole transposition: what E9 writes to L4 from an approved E8 model. */
    export function compileNs4ClassicL4(model: Ns4E8Model, ontology: Ns4E4Review): Promise<Ns4ClassicL4>;
    export type Ns4ClassicInput = Ns4E8Input;
}
declare module "_102035_/l2/agentNewSolution/steps/e10/contracts" {
    import { type Ns4JourneyIndex, type Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4OntologyIndexArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4UseCaseIndexArtifactV3, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4E8Model } from "_102035_/l2/agentNewSolution/steps/e8/model";
    import type { Ns4ClassicL4 } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_E10_VALIDATION_REPORT_VERSION: "2026-08-15-ns4-e10-validation-report-v2";
    export const NS4_L5_TODO_FRONTEND_VERSION: "2026-08-13-ns4-todo-frontend-v1";
    export const NS4_L5_TODO_BACKEND_VERSION: "2026-08-13-ns4-todo-backend-v1";
    export const NS4_L5_PROCESS_VERSION: "2026-08-13-ns4-process-v1";
    export const NS4_E10_MENU_LIMIT: 7;
    export type Ns4E10RepairStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler';
    /** E10 validates the approved E8 model against the classic L4 that E9 actually wrote to disk. */
    export interface Ns4E10Sources {
        moduleName: string;
        userLanguage: string;
        presentation?: Ns4Presentation;
        journeys: Ns4E2Review;
        journeyIndex: Ns4JourneyIndex;
        ontology: Ns4E4Review;
        ontologyIndex: Ns4OntologyIndexArtifact;
        rules: Ns4RulesArtifact;
        access: Ns4AccessMatrixArtifact;
        useCases: Ns4UseCaseArtifactV3[];
        useCaseIndex: Ns4UseCaseIndexArtifactV3;
        workflows: Ns4WorkflowArtifactV2[];
        workflowIndex: Ns4WorkflowIndexArtifactV2 | Ns4WorkflowIndexArtifactV3;
        model: Ns4E8Model;
        /** What E9 emitted, read back from L4: the staleness check compares it to a fresh compilation. */
        saved: Ns4ClassicL4;
    }
    export interface Ns4E10Issue {
        code: string;
        path: string;
        message: string;
        repairStep?: Ns4E10RepairStep;
    }
    export interface Ns4E10CheckSummary {
        checkId: 'A1-resolution' | 'A2-journeys' | 'A3-decisions' | 'A4-disclosure' | 'A5-fsm' | 'A6-staleness' | 'A7-warnings' | 'A8-dormant-commands';
        status: 'passed' | 'failed' | 'reported';
        errorCount: number;
        warningCount: number;
        registrarCount: number;
    }
    export interface Ns4L5NavigationItem {
        id: string;
        label: string;
        href: string;
        description: string;
        actors: string[];
        workspaceId: string;
        scenarioId: string;
        sectionId: string;
        hub?: string;
    }
    export interface Ns4L5HeaderLink {
        id: string;
        label: string;
        href: string;
        actors: string[];
        manageable: true;
        hub?: string;
    }
    export interface Ns4L5ModuleNavigation {
        moduleId: string;
        basePath: string;
        userLanguage: string;
        navigation: Ns4L5NavigationItem[];
        headerLinks: Ns4L5HeaderLink[];
    }
    export interface Ns4E10ValidationReport {
        schemaVersion: typeof NS4_E10_VALIDATION_REPORT_VERSION;
        moduleName: string;
        userLanguage: string;
        finalStatus: 'passed' | 'failed';
        checks: Ns4E10CheckSummary[];
        errors: Ns4E10Issue[];
        warnings: Ns4E10Issue[];
        registrars: Ns4E10Issue[];
        policyDecisions: Ns4PolicyDecisionSelection[];
        systemDecisions: Ns4SystemDecision[];
        repairStep?: Ns4E10RepairStep;
        /**
         * The failure is a defect of the pipeline itself, not of the product: no step can repair it, so
         * nothing is marked stale and the module waits for a fixed pipeline instead of re-running whole.
         */
        pipelineDefect?: true;
        sourceHashes: {
            journeys: Array<{
                journeyId: string;
                businessHash: string;
            }>;
            accessHash: string;
            ontologyHash: string;
            rulesHash: string;
        };
        counts: {
            journeys: number;
            workspaces: number;
            operations: number;
            contracts: number;
            decisions: number;
        };
        menuPreview: Ns4L5ModuleNavigation;
        reportHash: string;
    }
    /**
     * e10 always EMITS 'toCreate', but the todo file is the ledger the downstream agents own: changeBackend
     * and changeFrontend flip each owner to 'inProgress' and 'done' in place, keeping the `satisfies` the
     * generator wrote. Pinning the literal made the artifact stop type-checking as soon as work progressed —
     * 264 TS2322 in one module's todoFrontend. The type describes the file, so it carries the whole lifecycle.
     */
    export type Ns4L5OwnerStatus = 'toCreate' | 'inProgress' | 'done';
    export interface Ns4L5FrontendOwner {
        ownerType: 'workspace' | 'contract';
        ownerId: string;
        workspaceId: string;
        statusFrontend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5BackendOwner {
        ownerType: 'useCase';
        ownerId: string;
        statusBackend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5TodoFrontendArtifact {
        schemaVersion: typeof NS4_L5_TODO_FRONTEND_VERSION;
        layer: 'frontend';
        moduleName: string;
        owners: Ns4L5FrontendOwner[];
    }
    export interface Ns4L5TodoBackendArtifact {
        schemaVersion: typeof NS4_L5_TODO_BACKEND_VERSION;
        layer: 'backend';
        moduleName: string;
        owners: Ns4L5BackendOwner[];
    }
    export interface Ns4L5ProcessArtifact {
        schemaVersion: typeof NS4_L5_PROCESS_VERSION;
        moduleName: string;
        sourceHashes: Ns4E10ValidationReport['sourceHashes'];
        counts: Ns4E10ValidationReport['counts'];
        validation: {
            status: 'passed';
            reportPath: string;
            reportHash: string;
            warningCount: number;
            registrarCount: number;
        };
        next: {
            frontend: 'todoFrontend';
            backend: 'todoBackend';
        };
        processHash: string;
    }
    export interface Ns4E10Delivery {
        config: Record<string, unknown>;
        moduleNavigation: Ns4L5ModuleNavigation;
        todoFrontend: Ns4L5TodoFrontendArtifact;
        todoBackend: Ns4L5TodoBackendArtifact;
        process: Ns4L5ProcessArtifact;
    }
    /**
     * The L5 menu preview. The frontend rebuilds navigation as E8 `model.menu` ∩ materialized pages
     * (nodejsSaveConfigJson.ts), with `/<module>/<workspaceId>` as the href — this mirrors that
     * derivation so the report shows the menu the module will actually have.
     */
    export function compileNs4L5ModuleNavigation(sources: Ns4E10Sources): Ns4L5ModuleNavigation;
    export function compileNs4E10Delivery(sources: Ns4E10Sources, report: Ns4E10ValidationReport, existingConfig: unknown, projectId: number): Promise<Ns4E10Delivery>;
    export function mergeNs4L5Config(existing: unknown, projectId: number, moduleNavigation: Ns4L5ModuleNavigation): Record<string, unknown>;
}
declare module "_102035_/l2/agentNewSolution/types" {
    import type { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import type { Ns4JourneyArtifact, Ns4JourneyIndex } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyEntityArtifact, Ns4OntologyIndexArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4CompositionArtifact } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    import type { Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    export type { Ns4ApprovedBy, Ns4CompletedStepId, Ns4E1Status, Ns4E2Status, Ns4E3Status, Ns4E4Status, Ns4E5Status, Ns4E6Status, Ns4E7Status, Ns4E8Status, Ns4E9Status, Ns4E10Status, Ns4ModuleArtifact, Ns4NextStep, Ns4PipelineState, Ns4Presentation, } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type { Ns4E2Feature, Ns4E2Review, Ns4E2ReviewEvent, Ns4FeaturePriority, Ns4JourneyArtifact, Ns4JourneyBusiness, Ns4JourneyEntryMode, Ns4JourneyIndex, Ns4JourneyProposal, Ns4JourneyStep, Ns4JourneyStepKind, Ns4LegacyJourneyArtifact, Ns4LegacyJourneyBusiness, Ns4LegacyJourneyContext, Ns4PolicyDecision, Ns4PolicyDecisionSelection, } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    export type { Ns4AccessAuthority, Ns4AccessMatrixArtifactV4, Ns4AccessOperationAuthorityRef, Ns4AccessGrant, Ns4AccessMatrixArtifact, Ns4AccessProfile, Ns4AccessProfileKind, Ns4AccessScopeMode, Ns4DisclosureMode, Ns4E3Review, Ns4E3ReviewEvent, } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    export type { Ns4ConstraintSource, Ns4DerivationAggregate, Ns4DerivationOp, Ns4E4EntityDraft, Ns4E4PlanDraft, Ns4E4RelationshipBinding, Ns4E4RelationshipBindingsDraft, Ns4E4Review, Ns4E4ReviewEvent, Ns4EntityDerivation, Ns4EntityKind, Ns4EntityOwnership, Ns4FieldConstraint, Ns4LifecyclePredicate, Ns4OntologyEntity, Ns4OntologyEntityArtifact, Ns4OntologyEntityPlan, Ns4OntologyField, Ns4OntologyIndexArtifact, Ns4OntologyRelationship, Ns4RelationshipEndpointBinding, Ns4RelationshipPersistenceMode, Ns4RelationshipRealization, Ns4RelationshipRealizationKind, Ns4ResolvedOntologyRelationship, Ns4StorageScope, Ns4StorageTarget, } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export type { Ns4E5Review, Ns4E5ReviewEvent, Ns4RuleDefinition, Ns4RulesArtifact, } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    export type { Ns4AdditionalCapability, Ns4AdditionalCapabilityDecision, Ns4AdditionalCapabilityKind, Ns4CompositionArtifact, Ns4E6Review, Ns4E6ReviewEvent, } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    export type { Ns4E7PlanDraft, Ns4E7PlanUseCase, Ns4E7SourceHashes, Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseDraft, Ns4UseCaseEntityAccess, Ns4UseCaseError, Ns4UseCaseFieldRef, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4UseCaseInput, Ns4UseCaseKind, Ns4UseCaseOutput, Ns4UseCaseTransition, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3, Ns4WorkflowTransition, } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    export type { Ns4E8Edge, Ns4E8HubScore, Ns4E8ModuleSignals, Ns4E8Sources, Ns4WorkspaceArtifact, Ns4WorkspaceContext, Ns4WorkspaceIndex, } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    export type { Ns4E8BffCall, Ns4E8HubCatalogue, Ns4E8HubCatalogueItem, Ns4E8HubComposition, Ns4E8Input, Ns4E8InputSource, Ns4E8MenuEntry, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation, Ns4E8Organism, Ns4E8Section, Ns4WorkspaceTier, } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export type { Ns4ClassicBffCall, Ns4ClassicL4, Ns4ClassicOperation, Ns4ClassicSiteMap, Ns4ClassicWorkspace, } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    export type { Ns4E10CheckSummary, Ns4E10Delivery, Ns4E10Issue, Ns4E10RepairStep, Ns4E10ValidationReport, Ns4L5BackendOwner, Ns4L5FrontendOwner, Ns4L5HeaderLink, Ns4L5ModuleNavigation, Ns4L5NavigationItem, Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact, } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    export const NS4_PERMANENT_ARTIFACT_TYPE_NAMES: readonly ["Ns4ModuleArtifact", "Ns4JourneyArtifact", "Ns4JourneyIndex", "Ns4AccessMatrixArtifact", "Ns4OntologyEntityArtifact", "Ns4OntologyIndexArtifact", "Ns4RulesArtifact", "Ns4CompositionArtifact", "Ns4UseCaseArtifact", "Ns4UseCaseArtifactV3", "Ns4UseCaseIndexArtifact", "Ns4UseCaseIndexArtifactV3", "Ns4WorkflowArtifact", "Ns4WorkflowArtifactV2", "Ns4WorkflowIndexArtifact", "Ns4WorkflowIndexArtifactV2", "Ns4WorkflowIndexArtifactV3", "Ns4L5TodoFrontendArtifact", "Ns4L5TodoBackendArtifact", "Ns4L5ProcessArtifact"];
    export type Ns4PermanentArtifactTypeName = typeof NS4_PERMANENT_ARTIFACT_TYPE_NAMES[number];
    export interface Ns4PermanentArtifactByType {
        Ns4ModuleArtifact: Ns4ModuleArtifact;
        Ns4JourneyArtifact: Ns4JourneyArtifact;
        Ns4JourneyIndex: Ns4JourneyIndex;
        Ns4AccessMatrixArtifact: Ns4AccessMatrixArtifact;
        Ns4OntologyEntityArtifact: Ns4OntologyEntityArtifact;
        Ns4OntologyIndexArtifact: Ns4OntologyIndexArtifact;
        Ns4RulesArtifact: Ns4RulesArtifact;
        Ns4CompositionArtifact: Ns4CompositionArtifact;
        Ns4UseCaseArtifact: Ns4UseCaseArtifact;
        Ns4UseCaseArtifactV3: Ns4UseCaseArtifactV3;
        Ns4UseCaseIndexArtifact: Ns4UseCaseIndexArtifact;
        Ns4UseCaseIndexArtifactV3: Ns4UseCaseIndexArtifactV3;
        Ns4WorkflowArtifact: Ns4WorkflowArtifact;
        Ns4WorkflowArtifactV2: Ns4WorkflowArtifactV2;
        Ns4WorkflowIndexArtifact: Ns4WorkflowIndexArtifact;
        Ns4WorkflowIndexArtifactV2: Ns4WorkflowIndexArtifactV2;
        Ns4WorkflowIndexArtifactV3: Ns4WorkflowIndexArtifactV3;
        Ns4L5TodoFrontendArtifact: Ns4L5TodoFrontendArtifact;
        Ns4L5TodoBackendArtifact: Ns4L5TodoBackendArtifact;
        Ns4L5ProcessArtifact: Ns4L5ProcessArtifact;
    }
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4TypedDefs" {
    import type { Ns4PermanentArtifactByType, Ns4PermanentArtifactTypeName } from "_102035_/l2/agentNewSolution/types";
    export interface Ns4DefsFileReference {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export function renderNs4TypedDefsSource<T extends Ns4PermanentArtifactTypeName>(fileInfo: Ns4DefsFileReference, exportName: string, value: NoInfer<Ns4PermanentArtifactByType[T]>, artifactType: T): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Fs" {
    import { type Ns4RebuildAllReport } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { planNs4RebuildAll } from "_102035_/l2/agentNewSolution/helpers/ns4RebuildAll";
    import type { Ns4AccessMatrixArtifact, Ns4CompositionArtifact, Ns4JourneyArtifact, Ns4JourneyIndex, Ns4ModuleArtifact, Ns4OntologyEntityArtifact, Ns4OntologyIndexArtifact, Ns4PipelineState, Ns4RulesArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseIndexArtifactV3, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifactV3, Ns4E10ValidationReport, Ns4L5TodoFrontendArtifact, Ns4L5TodoBackendArtifact, Ns4L5ProcessArtifact } from "_102035_/l2/agentNewSolution/types";
    export type Ns4FileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export function ns4AgentFile(folder: string, shortName: string, extension: string): Ns4FileInfo;
    export function ns4ModuleFile(moduleName: string): Ns4FileInfo;
    export function ns4PipelineFile(moduleName: string): Ns4FileInfo;
    export function ns4PipelineJsonFile(moduleName: string, shortName: string): Ns4FileInfo;
    export function listNs4PipelineJsonShortNames(moduleName: string): string[];
    export function writeNs4Json(fileInfo: Ns4FileInfo, value: unknown): Promise<string>;
    export function ns4E2DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E2VersionedDraftFile(moduleName: string, reviewRound: number): Ns4FileInfo;
    export function ns4E2ImpactReportFile(moduleName: string): Ns4FileInfo;
    export function ns4E3DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4AccessMatrixFile(moduleName: string): Ns4FileInfo;
    export function ns4E4DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E4PlanDraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E4EntityDraftFile(moduleName: string, entityId: string): Ns4FileInfo;
    export function ns4E4RelationshipBindingsDraftFile(moduleName: string): Ns4FileInfo;
    export function ns4OntologyEntityFile(moduleName: string, entityId: string): Ns4FileInfo;
    export function ns4OntologyIndexFile(moduleName: string): Ns4FileInfo;
    export function ns4E5DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E5ApprovedFile(moduleName: string): Ns4FileInfo;
    export function ns4RulesFile(moduleName: string): Ns4FileInfo;
    export function ns4E6DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E6ApprovedFile(moduleName: string): Ns4FileInfo;
    export function ns4CompositionFile(moduleName: string): Ns4FileInfo;
    export function ns4E7PlanDraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E7UseCaseDraftFile(moduleName: string, useCaseId: string): Ns4FileInfo;
    export function ns4E7ValidationReportFile(moduleName: string): Ns4FileInfo;
    export function ns4UseCaseFile(moduleName: string, useCaseId: string): Ns4FileInfo;
    export function ns4UseCaseIndexFile(moduleName: string): Ns4FileInfo;
    export function ns4WorkflowFile(moduleName: string, workflowId: string): Ns4FileInfo;
    export function ns4WorkflowIndexFile(moduleName: string): Ns4FileInfo;
    export function ns4E8SkeletonDraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E8WorkspaceDraftFile(moduleName: string, workspaceId: string): Ns4FileInfo;
    export function ns4E8ValidationReportFile(moduleName: string): Ns4FileInfo;
    export function ns4WorkspaceFile(moduleName: string, workspaceId: string): Ns4FileInfo;
    /**
     * The approved workspace model is a PERMANENT artifact, not a pipeline draft: `pipeline/` is working
     * state for one run and is thrown away afterwards, while E9 and E10 read this model as the contract
     * of record. It sits at the module root, where neither consumer's folder scan picks it up.
     */
    export function ns4WorkspaceModelFile(moduleName: string): Ns4FileInfo;
    export function ns4OperationFile(moduleName: string, operationId: string): Ns4FileInfo;
    export function ns4SiteMapFile(moduleName: string): Ns4FileInfo;
    export function ns4ClassicContractFile(moduleName: string, workspaceId: string, bffId: string): Ns4FileInfo;
    export function ns4E10ValidationReportFile(moduleName: string): Ns4FileInfo;
    export function ns4L5ConfigFile(): Ns4FileInfo;
    export function ns4TodoFrontendFile(moduleName: string): Ns4FileInfo;
    export function ns4TodoBackendFile(moduleName: string): Ns4FileInfo;
    export function ns4ProcessFile(moduleName: string): Ns4FileInfo;
    export function ns4JourneyFile(moduleName: string, journeyId: string): Ns4FileInfo;
    export function ns4JourneyIndexFile(moduleName: string): Ns4FileInfo;
    export function readNs4AgentText(folder: string, shortName: string): Promise<string>;
    export function readNs4Pipeline(moduleName: string): Promise<Ns4PipelineState | null>;
    export function readNs4Module(moduleName: string): Promise<Ns4ModuleArtifact | null>;
    export function writeNs4Pipeline(state: Ns4PipelineState): Promise<string>;
    export function writeNs4Module(moduleName: string, artifact: Ns4ModuleArtifact): Promise<string>;
    export function writeNs4E2Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E2VersionedDraft(moduleName: string, reviewRound: number, draft: unknown): Promise<string>;
    export function writeNs4E2ImpactReport(moduleName: string, report: unknown): Promise<string>;
    export function writeNs4E3Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E4Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E4PlanDraft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E4EntityDraft(moduleName: string, entityId: string, draft: unknown): Promise<string>;
    export function writeNs4E4RelationshipBindingsDraft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E5Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E5Approved(moduleName: string, review: unknown): Promise<string>;
    export function writeNs4E6Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E6Approved(moduleName: string, review: unknown): Promise<string>;
    export function writeNs4E7PlanDraft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E7UseCaseDraft(moduleName: string, useCaseId: string, draft: unknown): Promise<string>;
    export function writeNs4E7ValidationReport(moduleName: string, report: unknown): Promise<string>;
    export function writeNs4E8SkeletonDraft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E8WorkspaceDraft(moduleName: string, workspaceId: string, draft: unknown): Promise<string>;
    export function writeNs4E8ValidationReport(moduleName: string, report: unknown): Promise<string>;
    export function writeNs4AccessMatrix(moduleName: string, artifact: Ns4AccessMatrixArtifact): Promise<string>;
    export function writeNs4OntologyEntity(moduleName: string, entityId: string, artifact: Ns4OntologyEntityArtifact): Promise<string>;
    export function writeNs4OntologyIndex(moduleName: string, artifact: Ns4OntologyIndexArtifact): Promise<string>;
    export function writeNs4Rules(moduleName: string, artifact: Ns4RulesArtifact): Promise<string>;
    export function writeNs4Composition(moduleName: string, artifact: Ns4CompositionArtifact): Promise<string>;
    export function writeNs4UseCase(moduleName: string, useCaseId: string, artifact: Ns4UseCaseArtifactV3): Promise<string>;
    export function writeNs4UseCaseIndex(moduleName: string, artifact: Ns4UseCaseIndexArtifactV3): Promise<string>;
    export function writeNs4Workflow(moduleName: string, workflowId: string, artifact: Ns4WorkflowArtifactV2): Promise<string>;
    export function writeNs4WorkflowIndex(moduleName: string, artifact: Ns4WorkflowIndexArtifactV3): Promise<string>;
    export function writeNs4E10ValidationReport(moduleName: string, report: Ns4E10ValidationReport): Promise<string>;
    export function ns4L5ProjectFile(projectId?: number): Ns4FileInfo;
    /** l5/project.json — organization-level, owned by the studio. E10 reads it and only ADDS what is absent. */
    export function readNs4L5Project(projectId?: number): Promise<Record<string, unknown> | null>;
    export function writeNs4L5Project(projectJson: Record<string, unknown>): Promise<string>;
    export function readNs4L5Config(): Promise<Record<string, unknown> | null>;
    export function writeNs4L5Config(config: Record<string, unknown>): Promise<string>;
    export function writeNs4TodoFrontend(moduleName: string, artifact: Ns4L5TodoFrontendArtifact): Promise<string>;
    export function writeNs4TodoBackend(moduleName: string, artifact: Ns4L5TodoBackendArtifact): Promise<string>;
    export function writeNs4Process(moduleName: string, artifact: Ns4L5ProcessArtifact): Promise<string>;
    export function writeNs4Journey(moduleName: string, journeyId: string, artifact: Ns4JourneyArtifact): Promise<string>;
    export function writeNs4JourneyIndex(moduleName: string, index: Ns4JourneyIndex): Promise<string>;
    export function ns4FileExists(fileInfo: Ns4FileInfo): boolean;
    /** Draft files of approved E7 use cases. Used by E9 only as an audit of what did not become an operation. */
    export function listNs4E7UseCaseDraftFiles(moduleName: string): Ns4FileInfo[];
    export function listNs4ModuleFolders(): Set<string>;
    export function readNs4Text(fileInfo: Ns4FileInfo, required: boolean): Promise<string>;
    export function readNs4DefsJson<T>(fileInfo: Ns4FileInfo, required?: boolean): Promise<T | null>;
    /**
     * The classic L4 emission of E9. These artifacts are plain data the consumers parse, so they are
     * written as untyped defs: the ns4 artifact interfaces describe the ns4 model, not the classic wire.
     */
    export function writeNs4ClassicWorkspace(moduleName: string, workspaceId: string, value: unknown): Promise<string>;
    export function writeNs4Operation(moduleName: string, operationId: string, value: unknown): Promise<string>;
    export function writeNs4SiteMap(moduleName: string, value: unknown): Promise<string>;
    /** A bffCall contract is already TypeScript source; E9 hands it over verbatim. */
    export function writeNs4ClassicContract(moduleName: string, workspaceId: string, bffId: string, source: string): Promise<string>;
    export function writeNs4WorkspaceModel(moduleName: string, model: unknown): Promise<string>;
    export function assertNs4ShortName(shortName: string): void;
    /**
     * Archives the module's whole l4/l5 through the platform channel (`libStor.deleteFile`): a persisted file
     * becomes `status: 'deleted'` and a never-saved one is removed. Nothing is unlinked outside that channel.
     */
    export function archiveNs4ModuleForRebuild(moduleName: string): Promise<string[]>;
    /**
     * `/rebuild all`: recover-prompt is the caller's job. This applies the already-planned wipe through
     * `libStor.deleteFile` (same channel as a total `/rebuild`) and writes the stripped project/config.
     */
    export function applyNs4RebuildAll(plan: Extract<ReturnType<typeof planNs4RebuildAll>, {
        ok: true;
    }>): Promise<Ns4RebuildAllReport>;
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getFCMTokenForBackend?(): Promise<string | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getFCMTokenForBackend: () => Promise<string>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "custom" | "default";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102036_/l2/shared/api" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
    export function msgApplyIntents(args: Omit<msg.RequestApplyIntents, "action">): Promise<msg.ResponseApplyIntents>;
    export function msgAppendLongTermMemory(args: Omit<msg.RequestAppendLongTermMemory, "action">): Promise<msg.ResponseAppendLongTermMemory>;
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { msgApplyIntents } from "_102036_/l2/shared/api";
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    /** Browser keeps IndexedDB. CLI calls setOrchestrationStorage before loadAgent/pooling. */
    export type OrchestrationStorage = {
        addOrUpdateTask(task: mls.msg.TaskData): Promise<void>;
        getTask(taskId: string): Promise<mls.msg.TaskData | undefined>;
        getMessage(messageId: string): Promise<mls.msg.Message | undefined>;
        addPooling(pooling: {
            taskId: string;
            userId: string;
            startAt: string;
        }): Promise<void>;
        deletePooling(taskId: string): Promise<void>;
        /**
         * The browser (IndexedDB) returns the updated thread; a host with no thread cache returns
         * nothing. Declared as the type the consumer actually needs — `unknown` compiled here and
         * broke at the two call sites that hand the result to `notifyThreadChange`.
         */
        updateThreadPendingTasks(threadId: string, taskId?: string): Promise<mls.msg.Thread | undefined>;
    };
    export function setOrchestrationStorage(next: OrchestrationStorage | null): void;
    type ApplyIntentsFn = typeof msgApplyIntents;
    /** CLI injects Bearer POST /msg. Browser never calls this. */
    export function setApplyIntents(fn: ApplyIntentsFn | null): void;
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    type OrchestrationListener = (event: OrchestrationEvent) => void;
    /** CLI / tests. Browser never subscribes — executeBeforePrompt still swallows the stream. */
    export function subscribeOrchestrationEvents(listener: OrchestrationListener): () => void;
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e1/contracts" {
    import { Ns4ApprovedBy, Ns4ModuleArtifact, Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type Ns4ReviewPolicy = 'guided' | 'smart' | 'automatic';
    export type Ns4SolutionStrategy = 'newSolution' | 'modernizePreserveDatabase' | 'modernizeEvolveDatabase' | 'replaceAndMigrateData';
    export type Ns4DatabaseChangePolicy = 'new' | 'forbidden' | 'additiveControlled' | 'replacement';
    export interface Ns4E1Review {
        planId: 'e1-review';
        reviewRound: number;
        userLanguage: string;
        reviewPolicy: {
            mode: Ns4ReviewPolicy;
        };
        module: {
            moduleName: string;
            title: string;
            purpose: string;
        };
        strategy: {
            mode: Ns4SolutionStrategy;
            rationale: string;
            databaseChangePolicy: Ns4DatabaseChangePolicy;
            modernization?: {
                sourceSystemName: string;
                sourceTechnology?: string;
                databaseEngine?: string;
                databaseVersion?: string;
                schemaAvailability: 'uploadAtE4' | 'metadataAtE4' | 'notAvailableYet';
                notes?: string;
            };
        };
        businessScope: {
            mainGoal: string;
            actors: Array<{
                actorId: string;
                title: string;
                kind: 'internal' | 'external' | 'system';
                expectedOutcome: string;
            }>;
            expectedOutcomes: Array<{
                outcomeId: string;
                title: string;
                description: string;
            }>;
            inScope: string[];
            outOfScope: string[];
        };
        localization: {
            productLanguages: string[];
            defaultLanguage: string;
            defaultLocale?: string;
            currency?: string;
            timeZone?: string;
            primaryMarket?: string;
        };
        declaredConstraints: {
            mandatoryIntegrations: Array<{
                dependencyId: string;
                title: string;
                kind: 'externalSystem' | 'platform' | 'unknown';
                reason: string;
            }>;
            regulatoryNotes?: string;
            criticalNotes?: string;
        };
        changeSummary: string[];
        /**
         * Product languages the normalizer discarded for lacking user provenance (run02 102047: the LLM
         * invented en/es for a pt-BR-only request). Trace-only: never copied into the l4 artifact.
         */
        i18nWarnings?: string[];
    }
    export interface Ns4E1ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E1Review;
    }
    export interface Ns4E1ReviewIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns4E1ReviewGate {
        ok: boolean;
        issues: Ns4E1ReviewIssue[];
    }
    export function normalizeNs4E1Review(value: unknown, fallback?: {
        userLanguage?: string;
        moduleName?: string;
        productLanguages?: string;
        mainActors?: string;
        mainGoal?: string;
        boundaries?: string;
        sourcePrompt?: string;
        /**
         * Under `/fast` the clarification answer is the planner's own proposal, never a user citation.
         * When true, language provenance comes only from `sourcePrompt` (and `userLanguage`).
         */
        answerIsProposal?: boolean;
    }): Ns4E1Review;
    export function policyFor(mode: Ns4SolutionStrategy): Ns4DatabaseChangePolicy;
    export function validateNs4E1Review(review: Ns4E1Review): Ns4E1ReviewGate;
    export function buildNs4ModuleArtifactFromReview(review: Ns4E1Review, sourcePrompt: string, approvedBy: Ns4ApprovedBy, presentation: Ns4Presentation, now?: string): Ns4ModuleArtifact;
}
declare module "_102035_/l2/agentNewSolution/widgets/clarification" {
    /** Public contract shared by the clarification widgets. The agent consumes it; it is not a widget-internal detail. */
    export type Ns4ClarificationAction = 'approve' | 'requestChanges' | 'cancel';
    export type Ns4ClarificationIssue = {
        code: string;
        message: string;
        path?: string;
    };
    export type Ns4ClarificationFeedback = {
        kind: 'error' | 'success' | 'information';
        message: string;
        issues?: Ns4ClarificationIssue[];
    };
    export type Ns4ClarificationEvent<TReview> = {
        action: Ns4ClarificationAction;
        review: TReview;
        adjustment: string;
    };
    export interface Ns4ClarificationWidgetApi {
        msgError: string;
        msgOk: string;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
    }
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Clarification" {
    import type { Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import type { Ns4ClarificationFeedback, Ns4ClarificationIssue } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export function bindNs4ClarificationWidget<T>(element: HTMLElement, value: T, presentation?: Ns4PhraseHolder): void;
    export function setNs4ClarificationFeedback(element: HTMLElement, feedback: Ns4ClarificationFeedback | null): void;
    export function setNs4ClarificationSubmitting(element: HTMLElement, submitting: boolean): void;
    export function showNs4ClarificationError(element: HTMLElement, error: unknown, issues?: Ns4ClarificationIssue[]): void;
}
declare module "_102035_/l2/agentNewSolution/steps/e1/gate" {
    import { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export interface Ns4GateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns4E1GateResult {
        ok: boolean;
        issues: Ns4GateIssue[];
    }
    export function validateNs4E1Module(artifact: Ns4ModuleArtifact): Ns4E1GateResult;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4FastHandoff" {
    /**
     * `/fast` chain + E1 skip. Pure: the finalize step and the E1 after-prompt hook decide from this;
     * sending the thread message is the agent's I/O, not this file's.
     */
    export const NS4_FAST_SKIP_REASON = "fast skipped clarification";
    export const NS4_FAST_HANDOFF_PLAN_ID = "fast-handoff-changeBackend";
    export const NS4_FAST_HANDOFF_AGENT = "agentChangeBackend";
    export interface Ns4E1SkippedDefaults {
        productLanguages: string[];
        defaultLanguage: string;
        moduleName: string;
        title: string;
        reviewPolicy: string;
        userLanguage: string;
        i18nWarnings?: string[];
    }
    export function isNs4FastMode(longMemory?: Record<string, unknown> | null): boolean;
    export function isNs4NochainMode(longMemory?: Record<string, unknown> | null): boolean;
    export function ns4NochainSuppressedNote(moduleName: string): string;
    export function ns4E1SkippedDefaults(review: {
        module: {
            moduleName: string;
            title: string;
        };
        localization: {
            productLanguages: readonly string[];
            defaultLanguage: string;
        };
        reviewPolicy: {
            mode: string;
        };
        userLanguage: string;
        i18nWarnings?: string[];
    }): Ns4E1SkippedDefaults;
    export function decideNs4E1Clarification(fast: boolean): 'skip' | 'open';
    export function buildNs4ChangeBackendHandoffMessage(moduleName: string): string;
    export function decideNs4FastHandoff(input: {
        fast: boolean;
        nochain: boolean;
        success: boolean;
        alreadyDispatched: boolean;
        moduleName: string;
    }): {
        dispatch: boolean;
        message: string;
        suppressed: boolean;
    };
    export type Ns4FastHandoffDegradation = {
        at: string;
        kind: 'fast-handoff-dispatch';
        reason: string;
    };
    export type Ns4FastHandoffSendResult = {
        dispatched: boolean;
        note: string;
        degradation: Ns4FastHandoffDegradation | null;
    };
    /**
     * Send + persist the `/fast` handoff. Never throws: a dispatch failure is a recorded
     * degradation so the parent step can complete (the NS work is already on disk).
     */
    export function sendNs4FastHandoff(input: {
        threadId: string | undefined;
        message: string;
        send: (threadId: string, message: string) => Promise<void>;
        persist: () => Promise<void>;
    }): Promise<Ns4FastHandoffSendResult>;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Intake" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4E1Review } from "_102035_/l2/agentNewSolution/steps/e1/contracts";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Intake102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E1Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        private adjustment;
        private submitting;
        private feedbackIssues;
        private cancelOpen;
        msgError: string;
        msgOk: string;
        private feedbackFocusPending;
        private cancelOrigin;
        private patch;
        private text;
        private updateInput;
        private selectStrategy;
        private selectReviewPolicy;
        private labels;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        updated(): void;
        private submit;
        private openCancel;
        private closeCancel;
        private trapCancel;
        private renderFeedback;
        private renderCancelDialog;
        render(): any;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-intake-102035': WidgetNs4Intake102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e1/agentNs4E1" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function loadNs4E1SystemPrompt(): Promise<string>;
    export function loadNs4StatusPrompt(message: string): Promise<string>;
    export function beforeNs4E1PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E1PromptStep(agent: unknown, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E1ClarificationStep(agent: unknown, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4StepTree" {
    /** Resolves the open phase that owns dynamically-created New Solution 4 steps. */
    export function resolveNs4MutableParent(allSteps: mls.msg.AIPayload[] | undefined, parentStep: mls.msg.AIAgentStep, phaseStep?: mls.msg.AIAgentStep): mls.msg.AIAgentStep;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/gate" {
    import { Ns4E2Review, Ns4JourneyProposal, Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    export const NS4_E2_DECIDE_ON_READ_MODEL: "NS4_E2_DECIDE_ON_READ_MODEL";
    export interface Ns4E2DecideOnReadModelStep {
        journeyId: string;
        stepId: string;
        entity: string;
        path: string;
    }
    export interface Ns4E2GateIssue {
        code: string;
        path: string;
        message: string;
        severity?: 'warning';
    }
    export interface Ns4E2GateResult {
        ok: boolean;
        issues: Ns4E2GateIssue[];
    }
    /**
     * The E2 gate is structural only. There is no declared context graph left to validate: contexts are
     * derived downstream by helpers/ns4Context.ts from the step entity, the step kind, the journey
     * sequence and the approved ontology.
     */
    /**
     * A decide step whose entity no act step in the module writes has no state of its own to
     * transition — the E2 stand-in for a projection, which E4 is the stage that can confirm.
     */
    export function ns4E2DecideOnReadModelSteps(review: Ns4E2Review): Ns4E2DecideOnReadModelStep[];
    export function validateNs4E2Review(review: Ns4E2Review): Ns4E2GateResult;
    /**
     * Selection integrity is separate from the structural review gate because an alternative is valid
     * at the human checkpoint but must become the generated choice in the next complete rewrite.
     */
    export function validateNs4E2PolicySelections(review: Ns4E2Review, selections: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>, requireHonored?: boolean): Ns4E2GateResult;
    /**
     * Operation set of a journey: sorted unique `kind:entity`. Titles and step ids do not count —
     * persona copies of the same flow (sign-as-morador vs sign-as-visitante) hash equal.
     */
    export function ns4E2JourneyOperationKey(journey: Ns4JourneyProposal): string;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/hookArgs" {
    export function resolveNs4E2HookArgs(args?: string, stepPrompt?: string): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ReviewPolicy" {
    /**
     * E2-E6 checkpoint policy.
     * `/fast` (longMemory.fastMode) or reviewPolicy.mode=automatic skip later reviews.
     * guided always opens. smart opens on Type A, Type B / a relevant decision, or
     * when the stage has no classified signal; it skips only-C (or empty classified)
     * stages and records autoReason "nenhum finding A" next to approvedBy=auto.
     * E1 still opens unless `/fast` (then it accepts the proposal and records the defaults).
     */
    export interface Ns4ReviewPolicyContext {
        task?: {
            iaCompressed?: {
                longMemory?: Record<string, unknown>;
            };
        };
    }
    export const NS4_SMART_SKIP_REASON: "nenhum finding A";
    export type Ns4SmartSignal = {
        available: false;
    } | {
        available: true;
        classA: boolean;
        classB: boolean;
    };
    export const NS4_UNAVAILABLE_SMART_SIGNAL: Ns4SmartSignal;
    export function isNs4AutomaticCheckpoint(context: Ns4ReviewPolicyContext, module?: {
        reviewPolicy?: {
            mode?: string;
        };
    } | null): boolean;
    export function decideNs4LaterCheckpoint(context: Ns4ReviewPolicyContext, module?: {
        reviewPolicy?: {
            mode?: string;
        };
    } | null, signal?: Ns4SmartSignal): {
        open: boolean;
        autoReason?: typeof NS4_SMART_SKIP_REASON;
    };
    /** E2 coverage records Type B as systemDecisions; journey policyDecisions are reversible choices. Type A does not reach the checkpoint. */
    export function ns4E2SmartSignal(review: {
        systemDecisions?: readonly unknown[];
        journeys?: readonly {
            policyDecisions?: readonly unknown[];
        }[];
    }): Ns4SmartSignal;
    /**
     * E4 has NO A/B vocabulary: its systemDecisions are Type C label backfills, and nothing else on the
     * review expresses "a human should look at this". That is absence of SIGNAL, not evidence that the
     * ontology is uncontroversial — so the checkpoint OPENS, per the rule "sem sinal, mostra".
     *
     * Reporting `available: true, classA/B: false` instead would hardcode "never open the ontology", and
     * because `smart` is the DEFAULT policy that would quietly remove the entity/enum review from every
     * run. When E4 gains real A/B findings, return them here and it joins the same decider.
     */
    export function ns4E4SmartSignal(_review?: {
        systemDecisions?: readonly unknown[];
    }): Ns4SmartSignal;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/coverageJudge" {
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E2MechanicalCoverageReport } from "_102035_/l2/agentNewSolution/steps/e2/coverageSignals";
    export const NS4_E2_MODULE_WITHOUT_DECIDE_POLICY_ID: "moduleWithoutDecidePolicy";
    export const NS4_E2_NO_DECISION_STEP_CHOICE: "noDecisionStepInThisModule";
    export const NS4_E2_ADD_DECISION_STEP_CHOICE: "addDecisionStep";
    export const NS4_E2_DEMOTE_DECIDE_TO_RULE_ID: "demoteDecideToRule";
    export const NS4_E2_KEEP_DECIDE_STEP_CHOICE: "keepDecideStep";
    export const NS4_E2_CONVERT_TO_ACT_WITH_RULE_CHOICE: "convertToActWithRule";
    export type Ns4E2CoverageCategory = 'missingJourney' | 'missingActorJourney' | 'missingRecipientJourney' | 'missingContextAcquisition' | 'missingLookupSource' | 'missingOutcomeCoverage' | 'moduleWithoutDecide' | 'contradictoryScope';
    export interface Ns4E2CoverageIssue {
        issueId: string;
        severity: 'blocking' | 'advisory';
        category: Ns4E2CoverageCategory;
        sourceEvidence: string;
        finding: string;
        repairInstruction: string;
        relatedJourneyIds: string[];
        question: string;
        alternatives: string[];
        defaultChoice: string;
    }
    export interface Ns4E2CoverageVerdict {
        planId: 'e2-coverage-judge';
        moduleName: string;
        reviewRound: number;
        complete: boolean;
        summary: string;
        issues: Ns4E2CoverageIssue[];
        policyDecisionImpacts: Array<{
            decisionId: string;
            impact: string;
            relatedJourneyIds: string[];
        }>;
    }
    export interface Ns4E2CoverageVerdictValidation {
        ok: boolean;
        errors: string[];
    }
    export function normalizeNs4E2CoverageVerdict(value: unknown, fallbackModule?: string, fallbackRound?: number): Ns4E2CoverageVerdict;
    export function validateNs4E2CoverageVerdict(verdict: Ns4E2CoverageVerdict, expectedModule: string, expectedRound: number, mechanicalCoverage?: Ns4E2MechanicalCoverageReport, review?: Ns4E2Review): Ns4E2CoverageVerdictValidation;
    export function applyNs4E2PolicyDecisionImpacts(review: Ns4E2Review, verdict: Ns4E2CoverageVerdict): Ns4E2Review;
    export function resolveNs4E2CoverageFindings(review: Ns4E2Review, verdict: Ns4E2CoverageVerdict): Ns4E2Review;
    export function resolveNs4E2CoverageJudgeFailure(review: Ns4E2Review): Ns4E2Review;
    /**
     * Deterministic registrars recorded after the structural gate / coverage judge. Neither is a
     * blocking issue and neither may ask the generator to invent a decide step.
     */
    export function applyNs4E2RegistrarDecisions(review: Ns4E2Review): Ns4E2Review;
    export function formatNs4E2CoverageRepairFeedback(verdict: Ns4E2CoverageVerdict): string;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/coverageRepair" {
    import { Ns4E2Feature, Ns4E2Review, Ns4JourneyProposal } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export interface Ns4E2CoveragePatch {
        planId: 'e2-coverage-patch';
        moduleName: string;
        reviewRound: number;
        journeyUpserts: Ns4JourneyProposal[];
        featureUpserts: Ns4E2Feature[];
    }
    export interface Ns4E2CoveragePatchValidation {
        ok: boolean;
        errors: string[];
    }
    export function normalizeNs4E2CoveragePatch(value: unknown, fallbackModule?: string, fallbackRound?: number, presentation?: Ns4Presentation): Ns4E2CoveragePatch;
    export function validateNs4E2CoveragePatch(patch: Ns4E2CoveragePatch, expectedModule: string, expectedRound: number, allowNoOp?: boolean): Ns4E2CoveragePatchValidation;
    export function applyNs4E2CoveragePatch(previous: Ns4E2Review, patch: Ns4E2CoveragePatch): Ns4E2Review;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Journeys" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Journeys102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E2Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        private adjustment;
        private submitting;
        private selectedActorRef;
        private selectedJourneyId;
        private activeTab;
        private selectedPolicyOptions;
        private feedbackIssues;
        private cancelOpen;
        msgError: string;
        msgOk: string;
        private feedbackFocusPending;
        private feedbackScrollPending;
        private cancelOrigin;
        private labels;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        updated(): void;
        private submit;
        private openCancel;
        private closeCancel;
        private trapCancel;
        private renderFeedback;
        private renderCancelDialog;
        render(): any;
        private selectActor;
        private actorLabel;
        private selectJourney;
        private view;
        private policyChanges;
        private submissionAdjustment;
        private policyDecisionSelections;
        private renderPolicySelector;
        private renderTab;
        private renderOverview;
        private renderSteps;
        private renderRules;
        private renderOutcome;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-journeys-102035': WidgetNs4Journeys102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e2/agentNs4E2" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E2PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E2PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E2ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ApprovedArtifacts" {
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import { Ns4E4Review, Ns4OntologyEntityArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export function readNs4ApprovedJourneys(moduleName: string): Promise<Ns4E2Review>;
    export function readNs4ApprovedAccess(moduleName: string): Promise<Ns4E3Review>;
    export function readNs4ApprovedOntology(moduleName: string): Promise<Ns4E4Review>;
    export function readNs4ApprovedOntologyEntity(moduleName: string, entityId: string): Promise<Ns4OntologyEntityArtifact | null>;
}
declare module "_102035_/l2/agentNewSolution/steps/e3/gate" {
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    export interface Ns4E3GateIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E3GateResult {
        ok: boolean;
        issues: Ns4E3GateIssue[];
    }
    export function validateNs4E3Review(review: Ns4E3Review, journeys?: Ns4E2Review): Ns4E3GateResult;
}
declare module "_102035_/l2/agentNewSolution/steps/e3/hookArgs" {
    export function resolveNs4E3HookArgs(args: unknown, prompt: unknown): string;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4AccessMatrix" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4AccessMatrix102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E3Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        private adjustment;
        private submitting;
        private selectedGrantKey;
        private feedbackIssues;
        private cancelOpen;
        msgError: string;
        msgOk: string;
        private feedbackFocusPending;
        private feedbackScrollPending;
        private cancelOrigin;
        private text;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        updated(): void;
        private submit;
        private openCancel;
        private closeCancel;
        private trapCancel;
        private renderFeedback;
        private renderCancelDialog;
        private grantKey;
        private selectedGrant;
        render(): any;
        private renderDetails;
        private renderMatrix;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-access-matrix-102035': WidgetNs4AccessMatrix102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e3/agentNs4E3" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E3PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E3PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E3ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4WorkerTools" {
    /**
     * Shared mechanics for strict artifact workers.  Step-specific artifact schemas stay under
     * `schemas/`; this helper only makes their result a payload that collab-messages can schedule.
     */
    export function createNs4FlexibleWorkerTool(toolName: string, description: string, artifactSchema: Record<string, unknown>): mls.msg.LLMTool;
    /** Keeps already persisted raw worker payloads resumable while new workers use the envelope. */
    export function unwrapNs4FlexibleWorkerPayload(value: unknown): unknown;
}
declare module "_102035_/l2/agentNewSolution/steps/e4/gate" {
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import { Ns4E4DerivationFieldIdChange, Ns4E4EntityDraft, Ns4E4PlanDraft, Ns4E4RelationshipBindingsDraft, Ns4E4Review, Ns4E4EntityFeedback } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export interface Ns4E4GateIssue {
        code: string;
        path: string;
        message: string;
        severity?: 'warning';
    }
    export interface Ns4E4GateResult {
        ok: boolean;
        issues: Ns4E4GateIssue[];
    }
    export interface Ns4E4GateOptions {
        requireRelationshipRealization?: boolean;
        /** E1 prompt + scope. The user request, not the ontology notes the model wrote about itself. */
        requestText?: string;
    }
    export function validateNs4E4Review(review: Ns4E4Review, journeys?: Ns4E2Review, access?: Ns4E3Review, options?: Ns4E4GateOptions): Ns4E4GateResult;
    /** Validates the frozen cross-entity decisions before expensive entity fan-out starts. */
    export function validateNs4E4Plan(plan: Ns4E4PlanDraft, journeys?: Ns4E2Review, access?: Ns4E3Review, options?: Ns4E4GateOptions): Ns4E4GateResult;
    /** Validates that the binding pass covered every frozen semantic relationship exactly once. */
    export function validateNs4E4RelationshipBindings(review: Ns4E4Review, draft: Ns4E4RelationshipBindingsDraft, journeys?: Ns4E2Review, access?: Ns4E3Review): Ns4E4GateResult;
    /** Validates one parallel entity result against the storage/lifecycle contract frozen by the plan. */
    export function validateNs4E4EntityDraft(plan: Ns4E4PlanDraft, detail: Ns4E4EntityDraft): Ns4E4GateResult;
    export function ns4E4BlockingDerivationIssues(issues: Ns4E4GateIssue[]): Ns4E4GateIssue[];
    export function ns4E4NonDerivationBlockingIssues(issues: Ns4E4GateIssue[]): Ns4E4GateIssue[];
    export type Ns4E4FinalizeDispatch = {
        action: 'pass';
    } | {
        action: 'bindDerivations';
        issues: Ns4E4GateIssue[];
    } | {
        action: 'planRepair';
    } | {
        action: 'fail';
    };
    export function ns4E4FinalizeDispatch(issues: Ns4E4GateIssue[], derivationRepairAttempt: number, planRepairAttempt: number, maxDerivationBindingRepairs?: number, maxPlanRepairs?: number): Ns4E4FinalizeDispatch;
    export function ns4E4EntityIdFromIssuePath(review: Ns4E4Review, path: string): string;
    /**
     * Records NS4_E4_CORE_READ_ONLY warnings as Type B system decisions (`keepCore`).
     * Does not change the ontology and does not block the run.
     */
    export function applyNs4E4CoreReadOnlyDecisions(review: Ns4E4Review, issues: Ns4E4GateIssue[]): Ns4E4Review;
    /**
     * OUTPUT_FIELD findings on projections whose repaired derivation changed an aggregate fieldId.
     * Empty means fail the run: the entity-repair budget is spent, or the field list did not change.
     */
    export function ns4E4DerivationOutputEscalation(review: Ns4E4Review, issues: Ns4E4GateIssue[], fieldIdChanges: Ns4E4DerivationFieldIdChange[], entityRepairRound: number, maxEntityRepairRounds?: number): Ns4E4EntityFeedback[];
    /**
     * Binding-step findings that the entity fan-out can repair. Empty means fail the run: either the
     * binding step can still fix the issue itself, or the entity-repair budget is already spent.
     */
    export function ns4E4BindingOwnerEscalation(review: Ns4E4Review, issues: Ns4E4GateIssue[], entityRepairRound: number, maxEntityRepairRounds?: number): Ns4E4EntityFeedback[];
    /**
     * The E1 request the derived-artifact guard classifies against. Ontology notes are not the request:
     * the model that invented an audit table will also invent audit prose about it.
     */
    export function ns4E4RequestText(module: {
        designContext?: {
            initialPrompt?: string;
            clarification?: {
                mainGoal?: string;
                boundaries?: string;
            };
        };
        businessScope?: {
            mainGoal?: string;
            inScope?: string[];
            expectedOutcomes?: Array<{
                title?: string;
                description?: string;
            }>;
        };
    } | null | undefined): string;
}
declare module "_102035_/l2/agentNewSolution/steps/e4/hookArgs" {
    export function resolveNs4E4HookArgs(args: unknown, prompt: unknown): string;
    /** Materialized parallel children have a selector arg but no prompt/planning metadata. */
    export function resolveNs4E4InvocationArgs(hookArgs: string, entityId: string): string;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Ontology" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { Ns4E4Review } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Ontology102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E4Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        private selectedEntityId;
        private activeTab;
        private adjustment;
        private submitting;
        private feedbackIssues;
        private cancelOpen;
        msgError: string;
        msgOk: string;
        private feedbackFocusPending;
        private feedbackScrollPending;
        private cancelOrigin;
        private text;
        private selectedEntity;
        private selectEntity;
        private storageLabel;
        private updateEntity;
        private updateField;
        private updateInlineField;
        private finishInlineEdit;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        updated(): void;
        private submit;
        private openCancel;
        private closeCancel;
        private trapCancel;
        private renderFeedback;
        private renderCancelDialog;
        render(): any;
        private renderEntity;
        private renderFields;
        private renderOverview;
        private renderRelationships;
        private renderRelationshipList;
        private renderDescriptions;
        private lifecycleLine;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-ontology-102035': WidgetNs4Ontology102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e4/agentNs4E4" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E4PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E4PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E4ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/steps/e5/gate" {
    import { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import { Ns4E4Review } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import { Ns4E5Review } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    export interface Ns4E5GateIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E5GateResult {
        ok: boolean;
        issues: Ns4E5GateIssue[];
    }
    export interface Ns4E5Sources {
        module: Ns4ModuleArtifact;
        journeys: Ns4E2Review;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
    }
    export function collectNs4ReferencedRuleIds(sources: Ns4E5Sources): string[];
    export function validateNs4E5Review(review: Ns4E5Review, sources: Ns4E5Sources): Ns4E5GateResult;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Rules" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4E5Review } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Rules102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E5Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        msgError: string;
        msgOk: string;
        private search;
        private selectedRuleId;
        private adjustment;
        private submitting;
        private feedbackIssues;
        private cancelOpen;
        private cancelOrigin;
        private text;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        private visibleRules;
        private selected;
        private updateDescription;
        private finishEdit;
        private submit;
        private openCancel;
        private closeCancel;
        render(): any;
        private renderFeedback;
        private renderCancelDialog;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-rules-102035': WidgetNs4Rules102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e5/agentNs4E5" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E5PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E5PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E5ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/steps/e6/gate" {
    import { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { Ns4E6Review } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    export interface Ns4E6GateIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E6GateResult {
        ok: boolean;
        issues: Ns4E6GateIssue[];
    }
    export function validateNs4E6Review(review: Ns4E6Review, module: Ns4ModuleArtifact): Ns4E6GateResult;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Composition" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4E6Review } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Composition102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E6Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        msgError: string;
        msgOk: string;
        private adjustment;
        private submitting;
        private feedbackIssues;
        private cancelOpen;
        private cancelOrigin;
        private text;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        private submit;
        private openCancel;
        private closeCancel;
        render(): any;
        private renderFeedback;
        private renderCancelDialog;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-composition-102035': WidgetNs4Composition102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e6/agentNs4E6" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E6PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E6PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E6ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/gate" {
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4E7PlanDraft, Ns4E7SourceHashes, Ns4UseCaseDraft, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    export interface Ns4E7LifecycleRepairOption {
        action: 'operateState' | 'shrinkLifecycle';
        owner: 'e2' | 'e4';
        instruction: string;
    }
    export interface Ns4E7GateIssue {
        code: string;
        path: string;
        message: string;
        severity?: 'warning';
        repairOptions?: [Ns4E7LifecycleRepairOption, Ns4E7LifecycleRepairOption];
    }
    export interface Ns4E7GateResult {
        ok: boolean;
        issues: Ns4E7GateIssue[];
    }
    export interface Ns4E7Sources {
        journeys: Ns4E2Review;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        rules: Ns4RulesArtifact;
        sourceHashes?: Ns4E7SourceHashes;
    }
    export function validateNs4E7Plan(plan: Ns4E7PlanDraft, sources: Ns4E7Sources): Ns4E7GateResult;
    export function validateNs4UseCaseDraft(plan: Ns4E7PlanDraft, draft: Ns4UseCaseDraft, sources: Ns4E7Sources): Ns4E7GateResult;
    export function validateNs4Workflows(workflows: Ns4WorkflowArtifactV2[], sources: Ns4E7Sources, useCaseIds: Iterable<string>, systemDecisions?: Ns4SystemDecision[]): Ns4E7GateResult;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/lifecycleResolution" {
    import type { Ns4E7GateIssue } from "_102035_/l2/agentNewSolution/steps/e7/gate";
    export interface Ns4E7LifecycleResolutionReview {
        planId: 'e7-lifecycle-resolution';
        moduleName: string;
        findings: Array<Ns4E7GateIssue & {
            findingId: string;
        }>;
    }
    export interface Ns4E7LifecycleResolutionEvent {
        moduleName: string;
        selections: Array<{
            findingId: string;
            action: 'operateState' | 'shrinkLifecycle';
        }>;
    }
    export function createNs4E7LifecycleResolutionReview(moduleName: string, issues: Ns4E7GateIssue[]): Ns4E7LifecycleResolutionReview;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/validationReport" {
    export const NS4_E7_VALIDATION_REPORT_VERSION: "2026-08-12-ns4-e7-validation-report-v4";
    interface Ns4E7ValidationAttemptLike {
        round: number;
    }
    export function isNs4E7ValidationReport(value: unknown, moduleName: string): value is {
        schemaVersion: typeof NS4_E7_VALIDATION_REPORT_VERSION;
        moduleName: string;
        attempts: Ns4E7ValidationAttemptLike[];
    };
    export function mergeNs4E7ValidationAttempts<T extends Ns4E7ValidationAttemptLike>(previous: readonly T[], attempt: T): T[];
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4LifecycleResolution" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import type { Ns4E7LifecycleResolutionReview } from "_102035_/l2/agentNewSolution/steps/e7/lifecycleResolution";
    export class WidgetNs4LifecycleResolution102035 extends StateLitElement {
        value: Ns4E7LifecycleResolutionReview | null;
        private choices;
        render(): any;
        private submit;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-lifecycle-resolution-102035': WidgetNs4LifecycleResolution102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e7/agentNs4E7" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E7PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E7PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E7ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/hubComposition" {
    import type { Ns4ResolutionResult } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8HubCatalogue, Ns4E8HubComposition, Ns4E8ModelWorkspace } from "_102035_/l2/agentNewSolution/steps/e8/model";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export interface Ns4E8CompositionIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E8CompositionResult {
        ok: boolean;
        issues: Ns4E8CompositionIssue[];
    }
    /** Score order, primary actions first: what the page looks like when nobody composes it. */
    export function defaultNs4HubComposition(workspace: Ns4E8ModelWorkspace): Ns4E8HubComposition;
    export function normalizeNs4HubComposition(value: unknown, workspaceId: string, fallbackTitle: string): Ns4E8HubComposition;
    export function validateNs4HubComposition(catalogue: Ns4E8HubCatalogue, composition: Ns4E8HubComposition): Ns4E8CompositionResult;
    /**
     * Applies a composition over the derived catalogue: order, promotion and labels — nothing else.
     *
     * Two rules of the classic format decide the shape of the result, and getting them wrong is what
     * broke run 46: an organism consumes a call of its OWN workspace, so an item the hub reads becomes a
     * LOCAL call over the same shared operation; and a journey is navigation, so it leaves the sections
     * for the site map instead of pretending to be an embedded command.
     */
    export function applyNs4HubComposition(workspace: Ns4E8ModelWorkspace, composition: Ns4E8HubComposition): Ns4E8ModelWorkspace;
    /**
     * The bounded resolution: an invalid composition after its single repair is never a run failure —
     * the deterministic score order wins and the choice is recorded.
     */
    export function resolveNs4HubCompositionFindings(workspace: Ns4E8ModelWorkspace, issues: Ns4E8CompositionIssue[], presentation?: Ns4Presentation): Ns4ResolutionResult<Ns4E8ModelWorkspace>;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/compositionProfiles" {
    /**
     * Composition profiles are data, not per-category code. A workspace looks up the profile of its
     * categoryRef (or `default`) and the compiler follows those flags. R1/R2/R3 of the default
     * profile stay in tiers.ts; this object only says WHAT a category is allowed to host.
     */
    export interface Ns4E8CompositionProfile {
        profileId: 'default' | 'contentLanding';
        contentOrganisms: boolean;
        hostedCommands: boolean;
        tiles: boolean;
        crud: boolean;
    }
    export const NS4_E8_COMPOSITION_PROFILES: Record<string, Ns4E8CompositionProfile>;
    export function ns4E8CompositionProfile(categoryRef: string): Ns4E8CompositionProfile;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/tiers" {
    import type { Ns4JourneyProposal } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4DerivedContextGraph } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import { type Ns4E8Sources } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    import { type Ns4E8HubCatalogue, type Ns4E8Model, type Ns4E8ModelWorkspace } from "_102035_/l2/agentNewSolution/steps/e8/model";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export function deriveNs4E8Model(sources: Ns4E8Sources, reviewRound?: number): Ns4E8Model;
    interface Ns4E8TierContext {
        sources: Ns4E8Sources;
        derived: Ns4DerivedContextGraph;
        presentation: Ns4Presentation | undefined;
        entities: Map<string, Ns4OntologyEntity>;
        hubEntity: string;
        catalogueEntities: Ns4OntologyEntity[];
        standaloneProjections: Ns4OntologyEntity[];
        compiledJourneys: Ns4JourneyProposal[];
        useCaseByStepRef: Map<string, Ns4UseCaseArtifactV3>;
        profilesByStepRef: Map<string, string[]>;
        sessionScopedProfiles: Set<string>;
        actorsByProfile: Map<string, string[]>;
        parentsOf: Map<string, Array<{
            parent: string;
            fieldId: string;
            required: boolean;
        }>>;
        transitionStates: Map<string, string[]>;
    }
    /**
     * The closed catalogue of the hub record page. Code decides WHAT may appear — projections anchored
     * on the hub, the satellites that point at it through a required relationship, the journeys anchored
     * on it and its pending decisions. The composition call may only order, promote and name these.
     */
    export function deriveNs4E8HubCatalogue(context: Ns4E8TierContext, workspaces: Ns4E8ModelWorkspace[]): Ns4E8HubCatalogue;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/modelGate" {
    import type { Ns4ResolutionResult } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8Sources } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    import { type Ns4E8Model } from "_102035_/l2/agentNewSolution/steps/e8/model";
    /**
     * How a broken organism reference can be repaired without an LLM. The gate DETECTS as strictly as
     * before; only the outcome changed — a screen missing one panel is a product, a dead run is not.
     */
    export type Ns4E8ModelResolution = {
        kind: 'wireLocalQuery';
        workspaceId: string;
        sectionId: string;
        organismIndex: number;
        reference: string;
        bffId: string;
        operationId: string;
        entityRef: string;
        outputKind: 'object' | 'list' | 'paginated';
    } | {
        kind: 'moveActionToNavigation';
        workspaceId: string;
        sectionId: string;
        organismIndex: number;
        reference: string;
        targetWorkspaceId: string;
        label: string;
    } | {
        kind: 'dropOrganism';
        workspaceId: string;
        sectionId: string;
        organismIndex: number;
        reference: string;
    };
    export interface Ns4E8ModelIssue {
        code: string;
        path: string;
        message: string;
        severity?: 'warning';
        resolution?: Ns4E8ModelResolution;
    }
    export interface Ns4E8ModelResult {
        ok: boolean;
        issues: Ns4E8ModelIssue[];
    }
    export function validateNs4E8Model(model: Ns4E8Model, sources: Ns4E8Sources): Ns4E8ModelResult;
    /**
     * Decide, record, continue. A reference the code can repair is repaired; a reference that points at
     * nothing loses its panel and says so; only a model that cannot render at all stays terminal.
     */
    export function resolveNs4E8ModelFindings(model: Ns4E8Model, issues: Ns4E8ModelIssue[]): Ns4ResolutionResult<Ns4E8Model>;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/agentNs4E8" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    /**
     * E8 compiles every workspace of the module deterministically. The only LLM call left composes the
     * hub record page over a closed catalogue; a module without a dominant anchor makes no call at all.
     * Labels are not asked for: every title already arrives localized from an approved E2/E4 artifact.
     */
    export function beforeNs4E8PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E8PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution/steps/e9/coverage" {
    /**
     * E9 audit: E7-approved use cases versus operations actually written. Loss is declared, never a
     * gate — pruning a use case with no screen can be the right call; pruning it in silence is the defect.
     */
    import type { Ns4PipelineState } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_USECASE_DROP_UNREFERENCED = "no workspace references the step";
    export const NS4_USECASE_DROP_DUPLICATE = "uniqueBy discarded a duplicate operationId";
    export interface Ns4ApprovedUseCase {
        useCaseId: string;
        compiledFrom: string[];
    }
    export interface Ns4UseCasesDropped {
        notEmitted: string[];
        approved: number;
        emitted: number;
        reasons?: Record<string, string>;
    }
    export type Ns4UseCaseCoverageVerdict = {
        useCases: 'ok';
        approved: number;
        emitted: number;
    } | {
        useCases: 'degraded';
        useCasesDropped: Ns4UseCasesDropped;
    };
    export function compareE7ToOperations(input: {
        approved: readonly Ns4ApprovedUseCase[];
        emittedOperationIds: readonly string[];
        hostedStepRefs?: readonly string[];
    }): Ns4UseCaseCoverageVerdict;
    export function useCaseCoverageLogLine(verdict: Ns4UseCaseCoverageVerdict): string;
    /** Strip a prior-run `degraded` first. A clean emit leaves no `useCases` / `useCasesDropped` on disk. */
    export function applyNs4UseCaseCoverage(state: Ns4PipelineState, verdict: Ns4UseCaseCoverageVerdict): Ns4PipelineState;
}
declare module "_102035_/l2/agentNewSolution/steps/e9/agentNs4E9" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E9PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E9PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution/steps/e10/publishable" {
    export type PublishableIssue = string;
    /** Canonical project kind. Lives in each project's `l5/project.json` as `projectType`. */
    export const PROJECT_TYPES: readonly ["lib", "master frontend", "master backend", "client"];
    export type PublishableProjectType = typeof PROJECT_TYPES[number];
    export function isPublishableProjectType(value: unknown): value is PublishableProjectType;
    /** The `projectType` field of an l5/project.json, or '' when absent/invalid. */
    export function readProjectTypeFromProjectJson(projectJson: unknown): PublishableProjectType | '';
    /** `102029` -> `{ root: '../mls-102029', type: … }` */
    export const PROJECT_ROOT_PREFIX = "../mls-";
    /**
     * The platform blocks E10 must NOT invent, with the default the platform ships.
     *
     * Kept here as ONE source (the step copies, never re-types them) and applied only when the block is
     * absent: a publisher who tuned `clientShell` keeps their version, and the finding tells
     * them a default was filled in.
     */
    export const PLATFORM_BLOCK_DEFAULTS: Record<string, unknown>;
    /** The module a generated project is born in: test database, curated seeds, badge on screen. */
    export const DEFAULT_PROJECT_APP_ENV = "presentation";
    /**
     * `workspaceDependencies` as the API reports it — the list is never written by hand and never filtered:
     * the build on the VM consumes exactly this to know which projects to fetch.
     */
    export function buildWorkspaceDependencies(dependencies: readonly number[]): string[];
    export interface ProjectsBlockResult {
        projects: Record<string, unknown>;
        issues: PublishableIssue[];
    }
    /**
     * `projects` covering every dependency plus the module's own project.
     *
     * The platform API still has no project kind (`IPrj_settings` is name/owner/dependencies). The
     * canonical source is `projectType` on that project's `l5/project.json`. Order: a type already in
     * this config is PRESERVED, then `typeById` (read from that project's project.json), then the
     * module's own project is `client`, else `lib` plus a finding. Guessing master frontend/backend
     * silently is what would produce a wrong root in the build.
     */
    export function buildProjectsBlock(existing: unknown, projectId: number, dependencies: readonly number[], typeById?: Readonly<Record<string, string>>): ProjectsBlockResult;
    export interface PlatformBlocksResult {
        config: Record<string, unknown>;
        issues: PublishableIssue[];
    }
    /** Fill an ABSENT platform block from the single source above, and say so. Present blocks are untouched. */
    export function applyPlatformBlockDefaults(config: Record<string, unknown>): PlatformBlocksResult;
    /**
     * `appEnv` in l5/project.json: written ONLY when absent. A publisher who moved a project to
     * `homologation` must not have it reset to `presentation` by the next generation.
     */
    export function ensureProjectAppEnv(projectJson: unknown): {
        projectJson: Record<string, unknown>;
        changed: boolean;
    };
    /**
     * `projectType` on the CURRENT project's l5/project.json: written ONLY when absent.
     * E10 of a generated module writes `client`. It never overwrites a type already set.
     */
    export function ensureProjectType(projectJson: unknown, type: PublishableProjectType): {
        projectJson: Record<string, unknown>;
        changed: boolean;
    };
    /**
     * `/rebuild all` strips this module from l5/project.json; E10 puts the name back (studio list)
     * without touching sibling entries or backend blocks other agents own.
     */
    export function ensureProjectModule(projectJson: unknown, moduleName: string): {
        projectJson: Record<string, unknown>;
        changed: boolean;
    };
    /** The module has to be listed in l5/project.json.modules — the studio reads that list, not the config. */
    export function collectProjectJsonIssues(projectJson: unknown, moduleName: string): PublishableIssue[];
    /**
     * The closing checklist: what a publish needs, checked at delivery time instead of failing later inside
     * the publish with no name attached.
     */
    export function collectPublishableConfigIssues(config: unknown, moduleName: string, dependencies: readonly number[]): PublishableIssue[];
}
declare module "_102035_/l2/agentNewSolution/steps/e10/gate" {
    import { type Ns4E10Sources, type Ns4E10ValidationReport } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    export function validateNs4E10(sources: Ns4E10Sources): Promise<Ns4E10ValidationReport>;
}
declare module "_102035_/l2/agentNewSolution/helpers/nsPipelineRun" {
    import type { Ns4PipelineState } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS_PIPELINE_AGENT_SLUG = "newsolution";
    export interface PipelineRunDegradation {
        at: string;
        kind: string;
        reason: string;
        path?: string;
    }
    export interface PipelineRunSummary {
        moduleName: string;
        agent: string;
        command: string;
        startedAt: string | null;
        finishedAt: string;
        verdict: 'completed' | 'failed' | 'degraded';
        reason: string;
        counts: Record<string, unknown>;
        degradations: PipelineRunDegradation[];
    }
    export function nextPipelineRunNn(existingShortNames: readonly string[], agentSlug: string): string;
    export function buildNsRunSummary(input: {
        pipeline: Ns4PipelineState | null;
        moduleName: string;
        longMemory?: Record<string, unknown> | null;
        verdict: 'completed' | 'failed' | 'degraded';
        reason: string;
        extraDegradations?: PipelineRunDegradation[];
    }): PipelineRunSummary;
    export function saveNsRunSummary(summary: PipelineRunSummary): Promise<string | null>;
}
declare module "_102025_/l2/shared/api" {
    export * from "_102036_/l2/shared/api";
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from "_102036_/l2/shared/interfaces";
    export * from "_102036_/l2/shared/interfaces";
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module "_102036_/l2/shared/interfaces" {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    /** Ephemeral step title on the client. No server, store, or intents. */
    export const STEP_TITLE_LOCAL_EVENT = "step-title-local";
    export const LOCAL_STEP_TITLE_MIN_MS = 500;
    export interface LocalStepTitleDetail {
        taskPK: string;
        stepId: number;
        title: string;
    }
    type LocalStepTitleThrottle = {
        at: number;
        title: string;
    };
    /** Pure tick decision: at most one event per step per ~500ms, drop a repeated same title. */
    export function shouldEmitLocalStepTitle(last: LocalStepTitleThrottle | undefined, now: number, title: string, minIntervalMs?: number): boolean;
    export function getLocalStepTitleEventScope(): Window | undefined;
    /**
     * Paint a step title in the open task UI. Fail-soft: no window (headless/CLI) is a silent no-op;
     * any throw is swallowed — an ornament must never kill a run.
     */
    export function changeLocalStepTitle(taskPK: string, stepId: number, title: string): void;
    /** Main-thread tick while a worker/await holds. No-op (and no timer) without window. */
    export function startLocalStepTitleTick(taskPK: string, stepId: number, makeTitle: (elapsedSec: number) => string, intervalMs?: number): () => void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from "_102036_/l2/collabMessagesIndexedDB";
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<string>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<void>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<msg.Thread>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: string;
        agentId: string;
        connectorId: string;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e10/agentNs4E10" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E10PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E10PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution/agentNewSolution" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { Ns4RootPlan } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export function createAgent(): IAgentAsync;
    export const NS4_AGENT_BUILD = "build-59 (2026-08-15) tier workspace model, classic L4 emission and one dispatch table";
    export function getNs4RootPlan(context: mls.msg.ExecutionContext, rootHint?: mls.msg.AIAgentStep): Ns4RootPlan;
}
declare module "_102035_/l2/agentNewSolution/helpers/routeOf" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8Edge, Ns4WorkspaceContext } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    /**
     * routeOf outlived the workspace model that used to feed it: the classic L4 format carries a call
     * key (`<module>.<workspaceId>.<bffId>`), not a URL pattern, and the frontend derives the page URL
     * itself. The projection is kept — it is the one total URL derivation the module ever agreed on —
     * and now declares the shapes it needs instead of importing a model that no longer exists.
     */
    interface Ns4E8SkeletonWorkspace {
        workspaceId: string;
        kind: 'hub' | 'place';
        anchorEntity?: string;
        pageContext: Ns4WorkspaceContext[];
    }
    interface Ns4WorkspaceScenario {
        scenarioId: string;
        kind: string;
        title: string;
        useCaseIds: string[];
        selectionContexts: Ns4WorkspaceContext[];
    }
    export interface Ns4RouteUseCase {
        useCaseId: string;
        entityRefs: string[];
    }
    type Ns4RouteWorkspace = Pick<Ns4E8SkeletonWorkspace, 'workspaceId' | 'kind' | 'anchorEntity' | 'pageContext'>;
    export interface Ns4RouteProjection {
        routePattern: string;
        pathContextIds: string[];
        selectionContextIds: string[];
        systemDecisions: Ns4SystemDecision[];
    }
    /** Total structural URL projection shared by the E8 preview and the E9 compiler. */
    export function routeOf(moduleName: string, workspace: Ns4RouteWorkspace, scenario: Ns4WorkspaceScenario | undefined, graph: {
        workspaces: Ns4RouteWorkspace[];
        edges: Ns4E8Edge[];
        useCases: Ns4RouteUseCase[];
    }, presentation?: Ns4Presentation): Ns4RouteProjection;
}
declare module "_102035_/l2/agentNewSolution/steps/e3/fixtures/duplicateGrantFixture" {
    export const ns4E3DuplicateGrantPayload: {
        readonly planId: "e3-access-review";
        readonly moduleName: "petShop";
        readonly userLanguage: "pt-BR";
        readonly title: "Matriz de acesso do Pet Shop";
        readonly reviewRound: 1;
        readonly profiles: readonly [{
            readonly profileId: "admin";
            readonly title: "Administrador da loja";
            readonly kind: "internal";
            readonly description: "Responsável pela operação da loja, pela agenda, pelas decisões de agendamento e pelo registro presencial do atendimento.";
            readonly actorRefs: readonly ["admin"];
            readonly landingIntent: "Acessar a visão operacional para organizar a agenda e conduzir os atendimentos.";
        }, {
            readonly profileId: "cliente";
            readonly title: "Cliente";
            readonly kind: "external";
            readonly description: "Pessoa que mantém os próprios pets, solicita serviços e acompanha exclusivamente os atendimentos vinculados a eles.";
            readonly actorRefs: readonly ["cliente"];
            readonly landingIntent: "Conhecer a loja, manter os próprios pets, solicitar agendamentos e acompanhar seus atendimentos.";
        }];
        readonly authorities: readonly [{
            readonly authorityRef: "petshop:admin";
            readonly title: "Operar a gestão do Pet Shop";
            readonly description: "Permite administrar a agenda e executar os registros operacionais dos atendimentos da loja.";
            readonly journeyStepRefs: readonly ["approveServiceAppointment.locatePendingServiceAppointment", "approveServiceAppointment.approveServiceAppointment", "rejectServiceAppointment.locatePendingServiceAppointment", "rejectServiceAppointment.rejectServiceAppointment", "recordPetArrival.locateConfirmedServiceAppointment", "recordPetArrival.recordPetArrival", "startServiceExecution.locateArrivedServiceAppointment", "startServiceExecution.startServiceExecution", "attachBeforeServiceImage.locateStartedServiceExecution", "attachBeforeServiceImage.attachBeforeServiceImage", "finishServiceExecution.locateStartedServiceExecution", "finishServiceExecution.finishServiceExecution", "attachAfterServiceImage.locateCompletedServiceExecution", "attachAfterServiceImage.attachAfterServiceImage", "recordInStorePayment.locateCompletedServiceAppointment", "recordInStorePayment.recordInStorePayment", "recordPetCollection.locatePaidServiceAppointment", "recordPetCollection.recordPetCollection", "planServiceUnavailability.locateServiceHours", "planServiceUnavailability.createAvailabilityBlock", "registerServiceHours.createServiceHours"];
            readonly informationNeeds: readonly [];
        }, {
            readonly authorityRef: "petshop:cliente";
            readonly title: "Utilizar serviços e acompanhar os próprios pets";
            readonly description: "Permite consultar informações públicas da loja, manter os próprios dados e pets, solicitar serviços e acompanhar exclusivamente os atendimentos relacionados aos próprios pets.";
            readonly journeyStepRefs: readonly ["exploreInstitutionalHome.inspectInstitutionalHome", "requestServiceAppointment.locatePet", "requestServiceAppointment.locateServiceOffering", "requestServiceAppointment.locateAppointmentSlot", "requestServiceAppointment.createServiceAppointment", "viewPetCareOverview.locatePet", "viewPetCareOverview.inspectPetCareOverview", "registerCustomerProfile.createCustomerProfile", "registerPet.locateCustomerProfile", "registerPet.createPet"];
            readonly informationNeeds: readonly ["Informações institucionais e serviços oferecidos pelo Pet Shop", "Horários disponíveis para novas solicitações", "Cadastro e lista dos pets da própria pessoa cliente", "Status, histórico, pendências e imagens vinculados aos próprios pets", "Solicitações de agendamento realizadas para os próprios pets"];
        }];
        readonly grants: readonly [{
            readonly profileRef: "admin";
            readonly authorityRef: "petshop:admin";
            readonly reason: "O administrador precisa conduzir integralmente a operação da loja, desde a configuração da agenda até a retirada presencial do pet.";
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todos os horários, indisponibilidades, solicitações, atendimentos, pets, imagens e pagamentos presenciais pertencentes à organização ativa.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "A operação exige acesso aos registros completos necessários para decidir agendamentos, atender o pet e registrar cada etapa presencial.";
            };
            readonly useRules: readonly ["activeOrganizationRequired", "adminOnlyAppointmentDecision", "adminOnlyOperationalRegistration", "paymentMustBeRecordedBeforePetCollection"];
        }, {
            readonly profileRef: "cliente";
            readonly authorityRef: "petshop:cliente";
            readonly reason: "O cliente precisa conhecer a loja e selecionar um serviço e um horário que possam ser solicitados, sem acessar dados operacionais da organização.";
            readonly dataScope: {
                readonly mode: "public";
                readonly description: "Somente conteúdo institucional publicado, serviços oferecidos e horários disponibilizados publicamente para novas solicitações.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Expõe apenas as informações necessárias para apresentação da loja e criação de uma solicitação de agendamento.";
                readonly allowedInformation: readonly ["Apresentação institucional publicada", "Serviços oferecidos ao público", "Descrição pública dos serviços", "Horários disponíveis para solicitação"];
                readonly deniedInformation: readonly ["Dados de outros clientes e pets", "Solicitações de outros clientes", "Agenda operacional completa", "Indisponibilidades com detalhes internos", "Dados de pagamento", "Anotações internas da loja"];
            };
            readonly useRules: readonly ["onlyPublishedInstitutionalContent", "onlyAvailableAppointmentSlots"];
        }, {
            readonly profileRef: "cliente";
            readonly authorityRef: "petshop:cliente";
            readonly reason: "O cliente precisa criar e manter o próprio cadastro, cadastrar seus pets e solicitar atendimentos em nome deles.";
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Somente o cadastro da pessoa autenticada, os pets por ela mantidos e as solicitações de agendamento criadas para esses pets.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Expõe os registros completos próprios necessários para manter o cadastro, os pets e as solicitações de serviço.";
            };
            readonly useRules: readonly ["authenticatedCustomerRequired", "customerProfileMustBelongToAuthenticatedPerson", "petMustBelongToAuthenticatedCustomer", "appointmentMustReferenceCustomersOwnPet"];
        }, {
            readonly profileRef: "cliente";
            readonly authorityRef: "petshop:cliente";
            readonly reason: "O cliente precisa acompanhar pela web a evolução e o histórico dos atendimentos vinculados aos próprios pets.";
            readonly dataScope: {
                readonly mode: "related";
                readonly description: "Somente atendimentos, execuções, pendências e imagens relacionados a pets pertencentes ao cadastro da pessoa cliente autenticada.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Expõe o acompanhamento do pet sem revelar informações internas da operação ou dados de terceiros.";
                readonly allowedInformation: readonly ["Identificação e dados cadastrais do próprio pet", "Status da própria solicitação de agendamento", "Confirmação ou recusa do próprio agendamento", "Registro de chegada do próprio pet", "Início e conclusão do serviço do próprio pet", "Últimas execuções e pendências do próprio pet", "Situação de pagamento do próprio atendimento", "Registro de retirada do próprio pet", "Imagens opcionais de antes e depois vinculadas ao próprio pet"];
                readonly deniedInformation: readonly ["Dados de outros clientes e pets", "Agenda geral da loja", "Detalhes de indisponibilidades internas", "Dados financeiros internos", "Dados de pagamento de outros atendimentos", "Anotações internas da loja", "Registros completos de atendimentos não relacionados aos próprios pets"];
            };
            readonly useRules: readonly ["petOwnershipRequired", "relatedServiceRecordRequired", "onlyCustomerVisibleServiceImages"];
        }];
        readonly changeSummary: readonly ["Proposta inicial da matriz com os dois perfis solicitados: Administrador da loja e Cliente.", "O administrador recebe acesso organizacional à operação; o cliente recebe acesso limitado a conteúdo público, registros próprios e atendimentos relacionados aos próprios pets.", "A consulta do cliente foi delimitada para não expor agenda interna, dados de terceiros, informações financeiras internas ou anotações operacionais da loja."];
    };
    export const ns4E3RepairedGrantPayload: Record<string, unknown>;
    /**
     * The E2 journeys this matrix was approved against, derived from the very
     * journeyStepRefs the real authorities carry — so E3 coverage is consistent by
     * construction and these tests isolate the grant rule instead of tripping on
     * unrelated coverage findings.
     */
    export const ns4E3PetShopJourneysInput: Record<string, unknown>;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/attachPetServiceImageWorkspace" {
    export const attachPetServiceImageWorkspace: {
        readonly workspaceId: "attachPetServiceImage";
        readonly title: "Anexar imagem do atendimento do pet";
        readonly actors: readonly ["clienteResponsavel"];
        readonly kind: "operation";
        readonly entity: "ServiceImage";
        readonly bffCalls: readonly [{
            readonly bffId: "qryLocatePet";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "locatePet";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "petId";
                    readonly from: "locatePet.$items.petId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly from: "locatePet.$items.name";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.qryLocatePet";
        }, {
            readonly bffId: "qryLocateServiceExecution";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "locateServiceExecution";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "locateServiceExecution.$items.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "locateServiceExecution.$items.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "locateServiceExecution.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "locateServiceExecution.$items.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "locateServiceExecution.$items.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "locateServiceExecution.$items.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "locateServiceExecution.$items.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.qryLocateServiceExecution";
        }, {
            readonly bffId: "cmdDecideImageMoment";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "decideImageMoment";
            }];
            readonly input: readonly [{
                readonly name: "petPetId";
                readonly from: "decideImageMoment.petPetId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryCustomerPicker";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "decideImageMoment.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateServiceExecution";
                readonly type: "string";
            }, {
                readonly name: "serviceImageServiceImageId";
                readonly from: "decideImageMoment.serviceImageServiceImageId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceImageId";
                    readonly from: "decideImageMoment.serviceImageId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petId";
                    readonly from: "decideImageMoment.petId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceExecutionId";
                    readonly from: "decideImageMoment.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "imageMoment";
                    readonly from: "decideImageMoment.imageMoment";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "mediaReference";
                    readonly from: "decideImageMoment.mediaReference";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.cmdDecideImageMoment";
        }, {
            readonly bffId: "cmdAttachServiceImage";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "attachServiceImage";
            }];
            readonly input: readonly [{
                readonly name: "petPetId";
                readonly from: "attachServiceImage.petPetId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryCustomerPicker";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "attachServiceImage.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateServiceExecution";
                readonly type: "string";
            }, {
                readonly name: "serviceImageServiceImageId";
                readonly from: "attachServiceImage.serviceImageServiceImageId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }, {
                readonly name: "imageMoment";
                readonly from: "attachServiceImage.imageMoment";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }, {
                readonly name: "mediaReference";
                readonly from: "attachServiceImage.mediaReference";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceImageId";
                    readonly from: "attachServiceImage.serviceImageId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petId";
                    readonly from: "attachServiceImage.petId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceExecutionId";
                    readonly from: "attachServiceImage.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "imageMoment";
                    readonly from: "attachServiceImage.imageMoment";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "mediaReference";
                    readonly from: "attachServiceImage.mediaReference";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.cmdAttachServiceImage";
        }, {
            readonly bffId: "qryCustomerPicker";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "listCustomer";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "customerId";
                    readonly from: "listCustomer.$items.customerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "platformUserId";
                    readonly from: "listCustomer.$items.platformUserId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "fullName";
                    readonly from: "listCustomer.$items.fullName";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.qryCustomerPicker";
        }];
        readonly sections: readonly [{
            readonly sectionId: "locatePet";
            readonly intent: "Um pet da lista pessoal do cliente está selecionado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryLocatePet";
                readonly usage: "picker";
            }];
        }, {
            readonly sectionId: "locateServiceExecution";
            readonly intent: "Uma execução de serviço do pet está selecionada para receber a imagem.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryLocateServiceExecution";
                readonly usage: "picker";
            }];
        }, {
            readonly sectionId: "decideImageMoment";
            readonly intent: "A imagem é identificada como registro de antes ou de depois do serviço.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdDecideImageMoment";
            }, {
                readonly role: "filterControl";
                readonly dataSource: "qryCustomerPicker";
                readonly usage: "picker";
            }];
        }, {
            readonly sectionId: "attachServiceImage";
            readonly intent: "A imagem opcional fica anexada ao atendimento selecionado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdAttachServiceImage";
            }];
        }];
        readonly operationIds: readonly ["attachServiceImage", "decideImageMoment", "listCustomer", "locatePet", "locateServiceExecution"];
        readonly purpose: "Adicionar opcionalmente uma imagem de antes ou depois de um serviço de um pet.";
        readonly presentation: {
            readonly categoryRef: "approvalWorkflow";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the journey tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:c88db383";
    };
    export default attachPetServiceImageWorkspace;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/consultInstitutionalHomeWorkspace" {
    export const consultInstitutionalHomeWorkspace: {
        readonly workspaceId: "consultInstitutionalHome";
        readonly title: "Conhecer o pet shop";
        readonly actors: readonly ["clienteResponsavel"];
        readonly kind: "operation";
        readonly entity: "InstitutionalPresentation";
        readonly bffCalls: readonly [{
            readonly bffId: "qryInspectInstitutionalPresentation";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "inspectInstitutionalPresentation";
            }];
            readonly input: readonly [{
                readonly name: "institutionalPresentationInstitutionalPresentationId";
                readonly from: "inspectInstitutionalPresentation.institutionalPresentationInstitutionalPresentationId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "institutionalPresentationId";
                    readonly from: "inspectInstitutionalPresentation.institutionalPresentationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "businessName";
                    readonly from: "inspectInstitutionalPresentation.businessName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "headline";
                    readonly from: "inspectInstitutionalPresentation.headline";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "presentationText";
                    readonly from: "inspectInstitutionalPresentation.presentationText";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.consultInstitutionalHome.qryInspectInstitutionalPresentation";
        }];
        readonly sections: readonly [{
            readonly sectionId: "inspectInstitutionalPresentation";
            readonly intent: "A pessoa visualiza a apresentação institucional e as informações de atendimento do pet shop.";
            readonly organisms: readonly [{
                readonly role: "detailPanel";
                readonly dataSource: "qryInspectInstitutionalPresentation";
            }];
        }];
        readonly operationIds: readonly ["inspectInstitutionalPresentation"];
        readonly purpose: "Consultar a apresentação institucional do pet shop antes de utilizar seus serviços.";
        readonly presentation: {
            readonly categoryRef: "processWizard";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the journey tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:b6fdbe28";
    };
    export default consultInstitutionalHomeWorkspace;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/inspectInstitutionalPresentationOperation" {
    export const operationInspectInstitutionalPresentation: {
        readonly operationId: "inspectInstitutionalPresentation";
        readonly title: "Conhecer o pet shop";
        readonly actors: readonly ["clienteResponsavel"];
        readonly entity: "InstitutionalPresentation";
        readonly kind: "query";
        readonly reads: readonly ["BusinessHours", "InstitutionalPresentation"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "clienteResponsavel";
            readonly goal: "Conhecer o pet shop";
            readonly steps: readonly ["Conhecer o pet shop", "A pessoa visualiza a apresentação institucional e as informações de atendimento do pet shop."];
            readonly outcome: "A pessoa visualiza a apresentação institucional e as informações de atendimento do pet shop.";
        };
        readonly accessPattern: {
            readonly kind: "getById";
            readonly description: "Conhecer o pet shop";
            readonly entity: "InstitutionalPresentation";
            readonly keyField: "InstitutionalPresentation.institutionalPresentationId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["InstitutionalPresentation.institutionalPresentationId", "InstitutionalPresentation.businessName", "InstitutionalPresentation.headline", "InstitutionalPresentation.presentationText"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "institutionalPresentationId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "InstitutionalPresentation.institutionalPresentationId";
            }, {
                readonly name: "businessName";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "InstitutionalPresentation.businessName";
            }, {
                readonly name: "headline";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "InstitutionalPresentation.headline";
            }, {
                readonly name: "presentationText";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "InstitutionalPresentation.presentationText";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "institutionalPresentationInstitutionalPresentationId";
            readonly fieldRef: "InstitutionalPresentation.institutionalPresentationId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Apresentação institucional";
        }];
        readonly pageId: "consultInstitutionalHome";
        readonly commandName: "qryInspectInstitutionalPresentation";
        readonly bffName: "qryInspectInstitutionalPresentation";
    };
    export default operationInspectInstitutionalPresentation;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/locateConfirmedServiceAppointmentOperation" {
    export const operationLocateConfirmedServiceAppointment: {
        readonly operationId: "locateConfirmedServiceAppointment";
        readonly title: "Localizar agendamento confirmado";
        readonly actors: readonly ["administradorPetShop"];
        readonly entity: "ServiceAppointment";
        readonly kind: "query";
        readonly reads: readonly ["ServiceAppointment"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["onlyConfirmedAppointmentsCanStartService"];
        readonly story: {
            readonly actor: "administradorPetShop";
            readonly goal: "Localizar agendamento confirmado";
            readonly steps: readonly ["Localizar agendamento confirmado", "Um agendamento confirmado está selecionado para o atendimento presencial."];
            readonly outcome: "Um agendamento confirmado está selecionado para o atendimento presencial.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly description: "Localizar agendamento confirmado";
            readonly entity: "ServiceAppointment";
            readonly keyField: "ServiceAppointment.serviceAppointmentId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["ServiceAppointment.serviceAppointmentId", "ServiceAppointment.status", "ServiceAppointment.petId", "ServiceAppointment.serviceId", "ServiceAppointment.requestedStartAt", "ServiceAppointment.requestedEndAt", "ServiceAppointment.refusalReason"];
        };
        readonly outputShape: {
            readonly kind: "list";
            readonly fields: readonly [{
                readonly name: "serviceAppointmentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.serviceAppointmentId";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.status";
            }, {
                readonly name: "petId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.petId";
            }, {
                readonly name: "serviceId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.serviceId";
            }, {
                readonly name: "requestedStartAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.requestedStartAt";
            }, {
                readonly name: "requestedEndAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.requestedEndAt";
            }, {
                readonly name: "refusalReason";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "ServiceAppointment.refusalReason";
            }];
        };
        readonly inputs: readonly [];
        readonly pageId: "recordInStoreServiceAttendance";
        readonly commandName: "qryLocateConfirmedServiceAppointment";
        readonly bffName: "qryLocateConfirmedServiceAppointment";
    };
    export default operationLocateConfirmedServiceAppointment;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/recordInStoreServiceAttendanceWorkspace" {
    export const recordInStoreServiceAttendanceWorkspace: {
        readonly workspaceId: "recordInStoreServiceAttendance";
        readonly title: "Registrar atendimento presencial do pet";
        readonly actors: readonly ["administradorPetShop"];
        readonly kind: "workflow";
        readonly entity: "ServiceExecution";
        readonly workflowId: "serviceExecutionLifecycle";
        readonly bffCalls: readonly [{
            readonly bffId: "qryLocateConfirmedServiceAppointment";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "locateConfirmedServiceAppointment";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "serviceAppointmentId";
                    readonly from: "locateConfirmedServiceAppointment.$items.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "locateConfirmedServiceAppointment.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petId";
                    readonly from: "locateConfirmedServiceAppointment.$items.petId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceId";
                    readonly from: "locateConfirmedServiceAppointment.$items.serviceId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "requestedStartAt";
                    readonly from: "locateConfirmedServiceAppointment.$items.requestedStartAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "requestedEndAt";
                    readonly from: "locateConfirmedServiceAppointment.$items.requestedEndAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "refusalReason";
                    readonly from: "locateConfirmedServiceAppointment.$items.refusalReason";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.qryLocateConfirmedServiceAppointment";
        }, {
            readonly bffId: "cmdRegisterPetArrival";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerPetArrival";
            }];
            readonly input: readonly [{
                readonly name: "serviceAppointmentServiceAppointmentId";
                readonly from: "registerPetArrival.serviceAppointmentServiceAppointmentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateConfirmedServiceAppointment";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "registerPetArrival.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "registerPetArrival.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerPetArrival.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "registerPetArrival.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "registerPetArrival.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "registerPetArrival.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "registerPetArrival.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterPetArrival";
        }, {
            readonly bffId: "cmdRegisterServiceStart";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerServiceStart";
            }];
            readonly input: readonly [{
                readonly name: "serviceAppointmentServiceAppointmentId";
                readonly from: "registerServiceStart.serviceAppointmentServiceAppointmentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateConfirmedServiceAppointment";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "registerServiceStart.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "registerServiceStart.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "registerServiceStart.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerServiceStart.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "registerServiceStart.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "registerServiceStart.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "registerServiceStart.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "registerServiceStart.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterServiceStart";
        }, {
            readonly bffId: "cmdRegisterServiceCompletion";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerServiceCompletion";
            }];
            readonly input: readonly [{
                readonly name: "serviceAppointmentServiceAppointmentId";
                readonly from: "registerServiceCompletion.serviceAppointmentServiceAppointmentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateConfirmedServiceAppointment";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "registerServiceCompletion.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "registerServiceCompletion.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "registerServiceCompletion.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerServiceCompletion.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "registerServiceCompletion.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "registerServiceCompletion.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "registerServiceCompletion.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "registerServiceCompletion.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterServiceCompletion";
        }, {
            readonly bffId: "cmdRegisterInStorePayment";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerInStorePayment";
            }];
            readonly input: readonly [{
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "registerInStorePayment.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "inStorePaymentId";
                    readonly from: "registerInStorePayment.inStorePaymentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceExecutionId";
                    readonly from: "registerInStorePayment.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerInStorePayment.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "confirmedAt";
                    readonly from: "registerInStorePayment.confirmedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterInStorePayment";
        }, {
            readonly bffId: "cmdRegisterPetPickup";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerPetPickup";
            }];
            readonly input: readonly [{
                readonly name: "serviceAppointmentServiceAppointmentId";
                readonly from: "registerPetPickup.serviceAppointmentServiceAppointmentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateConfirmedServiceAppointment";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "registerPetPickup.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "registerPetPickup.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "registerPetPickup.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerPetPickup.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "registerPetPickup.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "registerPetPickup.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "registerPetPickup.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "registerPetPickup.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterPetPickup";
        }, {
            readonly bffId: "cmdHandoffCompletedService";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "handoffCompletedService";
            }];
            readonly input: readonly [{
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "handoffCompletedService.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "handoffCompletedService.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "handoffCompletedService.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "handoffCompletedService.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "handoffCompletedService.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "handoffCompletedService.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "handoffCompletedService.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "handoffCompletedService.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdHandoffCompletedService";
        }];
        readonly sections: readonly [{
            readonly sectionId: "locateConfirmedServiceAppointment";
            readonly intent: "Um agendamento confirmado está selecionado para o atendimento presencial.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryLocateConfirmedServiceAppointment";
                readonly usage: "picker";
            }];
        }, {
            readonly sectionId: "registerPetArrival";
            readonly intent: "A execução do serviço é aberta com o registro de que o pet foi levado à loja.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterPetArrival";
            }];
        }, {
            readonly sectionId: "registerServiceStart";
            readonly intent: "A execução passa a indicar que o serviço do pet foi iniciado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterServiceStart";
            }];
        }, {
            readonly sectionId: "registerServiceCompletion";
            readonly intent: "A execução passa a indicar que o serviço foi concluído.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterServiceCompletion";
            }];
        }, {
            readonly sectionId: "registerInStorePayment";
            readonly intent: "A confirmação do pagamento presencial do atendimento fica registrada.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterInStorePayment";
            }];
        }, {
            readonly sectionId: "registerPetPickup";
            readonly intent: "A execução registra que o cliente buscou o pet na loja.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterPetPickup";
            }];
        }, {
            readonly sectionId: "handoffCompletedService";
            readonly intent: "O atendimento concluído fica disponível para consulta pelo cliente no site.";
            readonly organisms: readonly [{
                readonly role: "contextualAction";
                readonly action: "cmdHandoffCompletedService";
            }];
        }];
        readonly operationIds: readonly ["handoffCompletedService", "locateConfirmedServiceAppointment", "registerInStorePayment", "registerPetArrival", "registerPetPickup", "registerServiceCompletion", "registerServiceStart"];
        readonly purpose: "Registrar a chegada, o início, a conclusão, a retirada e o pagamento presencial de um serviço confirmado.";
        readonly presentation: {
            readonly categoryRef: "processWizard";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the journey tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:151f986f";
    };
    export default recordInStoreServiceAttendanceWorkspace;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/registerServiceStartOperation" {
    export const operationRegisterServiceStart: {
        readonly operationId: "registerServiceStart";
        readonly title: "Registrar início do serviço";
        readonly actors: readonly ["administradorPetShop"];
        readonly entity: "ServiceExecution";
        readonly kind: "commandInput";
        readonly reads: readonly ["ServiceAppointment", "ServiceExecution"];
        readonly writes: readonly ["ServiceExecution"];
        readonly rulesApplied: readonly ["onlyConfirmedAppointmentsCanStartService"];
        readonly story: {
            readonly actor: "administradorPetShop";
            readonly goal: "Registrar início do serviço";
            readonly steps: readonly ["Registrar início do serviço", "A execução passa a indicar que o serviço do pet foi iniciado."];
            readonly outcome: "A execução passa a indicar que o serviço do pet foi iniciado.";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly description: "Registrar início do serviço";
            readonly entity: "ServiceExecution";
            readonly keyField: "ServiceExecution.serviceExecutionId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["ServiceExecution.serviceExecutionId", "ServiceExecution.serviceAppointmentId", "ServiceExecution.status", "ServiceExecution.arrivedAt", "ServiceExecution.serviceStartedAt", "ServiceExecution.completedAt", "ServiceExecution.pickedUpAt"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "serviceExecutionId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceExecution.serviceExecutionId";
            }, {
                readonly name: "serviceAppointmentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceExecution.serviceAppointmentId";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceExecution.status";
            }, {
                readonly name: "arrivedAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceExecution.arrivedAt";
            }, {
                readonly name: "serviceStartedAt";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "ServiceExecution.serviceStartedAt";
            }, {
                readonly name: "completedAt";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "ServiceExecution.completedAt";
            }, {
                readonly name: "pickedUpAt";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "ServiceExecution.pickedUpAt";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "serviceAppointmentServiceAppointmentId";
            readonly fieldRef: "ServiceAppointment.serviceAppointmentId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Solicitação de agendamento";
        }, {
            readonly inputId: "serviceExecutionServiceExecutionId";
            readonly fieldRef: "ServiceExecution.serviceExecutionId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Execução de serviço";
        }];
        readonly pageId: "recordInStoreServiceAttendance";
        readonly commandName: "cmdRegisterServiceStart";
        readonly bffName: "cmdRegisterServiceStart";
    };
    export default operationRegisterServiceStart;
}
