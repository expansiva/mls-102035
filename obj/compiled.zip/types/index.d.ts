declare module "_102035_/l1/pizzaria/module" {
    export interface PizzariaPedido {
        id: string;
        status: 'recebido' | 'em preparo' | 'pronto' | 'saiu para entrega' | 'entregue';
        criadoEm: any;
        atualizadoEm: any;
        itens: any;
        responsavelAtendimento?: string;
        observacoes?: string;
        formaPagamento?: string;
        statusPagamento?: 'pendente' | 'pago' | 'parcial' | 'cancelado';
        observacaoCritica?: string;
    }
    export interface PizzariaItemPedido {
        id: string;
        pedidoId: string;
        nome: string;
        quantidade: number;
        observacoes?: string;
    }
    export interface PizzariaProducao {
        id: string;
        pedidoId: string;
        statusProducao: 'em preparo' | 'pronto';
        inicioEm?: any;
        fimEm?: any;
        cozinheiroResponsavelId?: string;
    }
    export interface PizzariaEntrega {
        id: string;
        pedidoId: string;
        entregadorId?: string;
        statusEntrega: 'saiu para entrega' | 'entregue';
        inicioEm?: any;
        fimEm?: any;
    }
    export interface PizzariaUsuario {
        id: string;
        nome: string;
        perfil: 'admin' | 'atendente' | 'cozinheiro' | 'entregador';
    }
    export interface PizzariaUpdatePedidoParams {
        id: string;
        status?: PizzariaPedido['status'];
        criadoEm?: any;
        atualizadoEm?: any;
        itens?: any;
        responsavelAtendimento?: string;
        observacoes?: string;
        formaPagamento?: string;
        statusPagamento?: PizzariaPedido['statusPagamento'];
        observacaoCritica?: string;
        author?: string;
    }
    export interface PizzariaUpdateItemPedidoParams {
        id: string;
        pedidoId?: string;
        nome?: string;
        quantidade?: number;
        observacoes?: string;
        author?: string;
    }
    export interface PizzariaUpdateProducaoParams {
        id: string;
        pedidoId?: string;
        statusProducao?: PizzariaProducao['statusProducao'];
        inicioEm?: any;
        fimEm?: any;
        cozinheiroResponsavelId?: string;
        author?: string;
    }
    export interface PizzariaUpdateEntregaParams {
        id: string;
        pedidoId?: string;
        entregadorId?: string;
        statusEntrega?: PizzariaEntrega['statusEntrega'];
        inicioEm?: any;
        fimEm?: any;
        author?: string;
    }
    export interface PizzariaUpdateUsuarioParams {
        id: string;
        nome?: string;
        perfil?: PizzariaUsuario['perfil'];
        author?: string;
    }
    export interface PizzariaSeedResult {
        insertedCount: number;
        totalCount: number;
        seededAt: string;
    }
}
declare module "_102035_/l1/pizzaria/layer_1_external/persistence" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const tableDefinitions: TableDefinition[];
}
declare module "_102035_/l1/pizzaria/layer_2_controller/displayCozinha" {
    import { PizzariaPedido, PizzariaProducao, PizzariaUpdateProducaoParams } from "_102035_/l1/pizzaria/module";
    import { type BffHandler, type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function getResumoProducaoCozinha(ctx: RequestContext, input?: {
        cozinhaId?: string;
    }): Promise<PizzariaPedido | undefined>;
    export function listarPedidosCozinha(ctx: RequestContext, input?: {
        status?: string[];
        prioridade?: string;
        cozinhaId?: string;
    }): Promise<PizzariaPedido[]>;
    export function getPedidoCozinhaDetalhe(ctx: RequestContext, input?: {
        pedidoId?: string;
    }): Promise<PizzariaPedido | undefined>;
    export function load(ctx: RequestContext, input: PizzariaUpdateProducaoParams): Promise<PizzariaProducao>;
    export function updateStatus(ctx: RequestContext, input: PizzariaUpdateProducaoParams): Promise<PizzariaProducao>;
    export function assignCook(ctx: RequestContext, input: PizzariaUpdateProducaoParams): Promise<PizzariaProducao>;
    export const displayCozinhaGetResumoProducaoCozinhaHandler: BffHandler;
    export const displayCozinhaListarPedidosCozinhaHandler: BffHandler;
    export const displayCozinhaGetPedidoCozinhaDetalheHandler: BffHandler;
    export const displayCozinhaLoadHandler: BffHandler;
    export const displayCozinhaUpdateStatusHandler: BffHandler;
    export const displayCozinhaAssignCookHandler: BffHandler;
}
declare module "_102035_/l1/pizzaria/layer_2_controllers/router" {
    import type { BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function createPizzariaRouter(): Map<string, BffHandler>;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102035_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102035_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102035_/l2/pizzaria/confirmacaoImpressaoComanda.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/displayCozinha.defs" {
    export const definition: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: ({
                sectionName: string;
                mode: string;
                organisms: {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                        }[];
                        params: {
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                contextKey: string;
                            };
                        }[];
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                }[];
            } | {
                sectionName: string;
                mode: string;
                organisms: {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        itemFields: ({
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            isNested?: undefined;
                            nestedCollection?: undefined;
                        } | {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            isNested: boolean;
                            nestedCollection: {
                                stateKeySuffix: string;
                                itemFields: {
                                    entityField: string;
                                    entity: string;
                                    priority: string;
                                    usage: string;
                                }[];
                            };
                        })[];
                        params: ({
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                stateKey: string;
                                contextKey?: undefined;
                            };
                        } | {
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                contextKey: string;
                                stateKey?: undefined;
                            };
                        })[];
                        editable: boolean;
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: any[];
                    emits: ({
                        event: string;
                        payload: string;
                        writesState: string;
                    } | {
                        event: string;
                        payload: string;
                        writesState?: undefined;
                    })[];
                }[];
            } | {
                sectionName: string;
                mode: string;
                organisms: {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: ({
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            isNested?: undefined;
                            nestedCollection?: undefined;
                        } | {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            isNested: boolean;
                            nestedCollection: {
                                stateKeySuffix: string;
                                itemFields: {
                                    entityField: string;
                                    entity: string;
                                    priority: string;
                                    usage: string;
                                }[];
                            };
                        })[];
                        params: {
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                stateKey: string;
                            };
                        }[];
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                    }[];
                }[];
            })[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue: string;
            }[];
        }[];
    };
    export const contractSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/pizzaria/displayCozinha.defs.ts).definition]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l1/pizzaria/module.ts)]]\n```\n";
    export const sharedSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/pizzaria/displayCozinha.defs.ts).definition]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l1/pizzaria/module.ts)]]\n```\n\n";
    export const desktopLayoutSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/pizzaria/displayCozinha.defs.ts).definition]]\n```\n\n## Base Class\n```JSON\n    [[(_102035_/l2/pizzaria/web/shared/displayCozinha.ts)]]\n```\n";
    export const materializeIndex: {
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
    }[];
}
declare module "_102035_/l2/pizzaria/index" { }
declare module "_102035_/l2/pizzaria/loginAdmin.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/loginInterno.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/metasTempoConfiguracao.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/metasTempoMonitoramento.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/module.defs" {
    export const ontology: {
        meta: {
            userLanguage: string;
            moduleName: string;
            userPromptOriginal: string;
            userPromptFinal: string;
        };
        ontology: {
            entities: {
                Pedido: {
                    description: string;
                    fields: {
                        id: {
                            type: string;
                        };
                        status: {
                            type: string;
                            values: string[];
                        };
                        criadoEm: {
                            type: string;
                        };
                        atualizadoEm: {
                            type: string;
                        };
                        itens: {
                            type: string;
                            constraints: string;
                        };
                        responsavelAtendimento: {
                            type: string;
                            required: boolean;
                        };
                        observacoes: {
                            type: string;
                            required: boolean;
                        };
                        formaPagamento: {
                            type: string;
                            required: boolean;
                        };
                        statusPagamento: {
                            type: string;
                            values: string[];
                            required: boolean;
                        };
                        observacaoCritica: {
                            type: string;
                            required: boolean;
                            constraints: string;
                        };
                    };
                    rules: string[];
                };
                ItemPedido: {
                    description: string;
                    fields: {
                        id: {
                            type: string;
                        };
                        pedidoId: {
                            type: string;
                        };
                        nome: {
                            type: string;
                        };
                        quantidade: {
                            type: string;
                        };
                        observacoes: {
                            type: string;
                            required: boolean;
                        };
                    };
                    rules: string[];
                };
                Producao: {
                    description: string;
                    fields: {
                        id: {
                            type: string;
                        };
                        pedidoId: {
                            type: string;
                        };
                        statusProducao: {
                            type: string;
                            values: string[];
                        };
                        inicioEm: {
                            type: string;
                            required: boolean;
                        };
                        fimEm: {
                            type: string;
                            required: boolean;
                        };
                        cozinheiroResponsavelId: {
                            type: string;
                            required: boolean;
                        };
                    };
                    rules: string[];
                };
                Entrega: {
                    description: string;
                    fields: {
                        id: {
                            type: string;
                        };
                        pedidoId: {
                            type: string;
                        };
                        entregadorId: {
                            type: string;
                            required: boolean;
                        };
                        statusEntrega: {
                            type: string;
                            values: string[];
                        };
                        inicioEm: {
                            type: string;
                            required: boolean;
                        };
                        fimEm: {
                            type: string;
                            required: boolean;
                        };
                    };
                    rules: string[];
                };
                Usuario: {
                    description: string;
                    fields: {
                        id: {
                            type: string;
                        };
                        nome: {
                            type: string;
                        };
                        perfil: {
                            type: string;
                            values: string[];
                        };
                    };
                    rules: string[];
                };
            };
        };
        rules: {
            rulePerfisAcesso: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleModuloInterno: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleTomProfissionalConcisao: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleIdiomaPt: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleProcessosPrincipais: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleImpressaoComanda: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleDisplayCozinha: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            rulePedidoStatusPermitidos: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleMetasTempoEtapas: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleResponsavelObrigatorioParaAvancarStatus: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleRegistroPagamentoPedido: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleComunicacaoObservacaoCritica: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
        };
        capabilities: {
            gerirPedidos: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            controlarProducao: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            gerirEntregas: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            imprimirComanda: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            administrarAcesso: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            monitorarMetasTempo: {
                description: string;
                usesRules: string[];
                isOptional: boolean;
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
        };
    };
}
declare module "_102035_/l2/pizzaria/module" {
    import type { AuraModuleFrontendDefinition } from '_102029_/l2/contracts/bootstrap';
    export const moduleGenome: {
        readonly page11: {
            readonly device: "desktop";
            readonly layout: "standard";
        };
        readonly page21: {
            readonly device: "mobile";
            readonly layout: "standard";
        };
    };
    export const moduleStates: {};
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102035_/l2/pizzaria/painelEntregas.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/painelPrincipalPedidos.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/painelProducao.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/pedidoDetalhe.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/pedidoEditor.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/pedidoPagamento.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/usuarioEditor.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/usuariosDashboard.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
    };
}
declare module "_102035_/l2/pizzaria/web/shared/displayCozinha" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { BffClientOptions } from '_102029_/l2/bffClient';
    import type { PizzariaItemPedido, PizzariaPedido, PizzariaProducao, PizzariaUpdateProducaoParams } from "_102035_/l1/pizzaria/module";
    const message_en: {
        brand: string;
        pageTitle: string;
        pageSubtitle: string;
        loadingGetResumoProducaoCozinha: string;
        loadingListarPedidosCozinha: string;
        loadingGetPedidoCozinhaDetalhe: string;
        couldNotLoad: string;
        loadingUpdateStatus: string;
        couldNotUpdateStatus: string;
        updatedStatusSuccessfully: string;
        loadingAssignCook: string;
        couldNotAssignCook: string;
        assignedCookSuccessfully: string;
        itemsAvailable: string;
        reload: string;
        save: string;
        saving: string;
        confirm: string;
        confirming: string;
        fieldStatus: string;
        fieldStatusProducao: string;
        fieldCriadoEm: string;
        fieldAtualizadoEm: string;
        fieldObservacoes: string;
        fieldObservacaoCritica: string;
        fieldResponsavelAtendimento: string;
        fieldInicioEm: string;
        fieldFimEm: string;
        fieldCozinheiroResponsavelId: string;
        fieldItens: string;
        fieldItemNome: string;
        fieldItemQuantidade: string;
        fieldItemObservacoes: string;
    };
    type MessageType = typeof message_en;
    type DisplayCozinhaResumo = {
        status: PizzariaPedido['status'];
        criadoEm?: any;
        statusProducao: PizzariaProducao['statusProducao'];
    };
    type PedidoCozinhaItem = Pick<PizzariaItemPedido, 'nome' | 'quantidade' | 'observacoes'>;
    type PedidoCozinhaListItem = Pick<PizzariaPedido, 'id' | 'status' | 'criadoEm' | 'atualizadoEm' | 'observacoes' | 'observacaoCritica' | 'responsavelAtendimento'> & Pick<PizzariaProducao, 'statusProducao' | 'inicioEm' | 'fimEm' | 'cozinheiroResponsavelId'> & {
        itens?: PedidoCozinhaItem[];
    };
    type PedidoCozinhaDetalhe = Pick<PizzariaPedido, 'id' | 'status' | 'criadoEm' | 'observacoes' | 'observacaoCritica'> & Pick<PizzariaProducao, 'statusProducao' | 'inicioEm' | 'fimEm' | 'cozinheiroResponsavelId'> & {
        itens?: PedidoCozinhaItem[];
    };
    export class PizzariaDisplayCozinhaBase extends CollabLitElement {
        static properties: {
            resumo: {
                state: boolean;
            };
            cozinha: {
                state: boolean;
            };
            pedidoDetalhe: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
        };
        resumo: DisplayCozinhaResumo | undefined;
        cozinha: PedidoCozinhaListItem[];
        pedidoDetalhe: PedidoCozinhaDetalhe | undefined;
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        constructor();
        connectedCallback(): void;
        protected loadInitialData(_params?: undefined, options?: BffClientOptions): Promise<void>;
        loadGetResumoProducaoCozinha(params?: {
            cozinhaId: string;
        }, options?: BffClientOptions): Promise<void>;
        loadListarPedidosCozinha(params?: {
            status: string[];
            prioridade: string;
            cozinhaId: string;
        }, options?: BffClientOptions): Promise<void>;
        loadGetPedidoCozinhaDetalhe(params?: {
            pedidoId: string;
        }, options?: BffClientOptions): Promise<void>;
        updateStatus(params: PizzariaUpdateProducaoParams, signal?: AbortSignal): Promise<void>;
        assignCook(params: PizzariaUpdateProducaoParams, signal?: AbortSignal): Promise<void>;
        handleUpdateStatusClick(params: PizzariaUpdateProducaoParams): void;
        handleAssignCookClick(params: PizzariaUpdateProducaoParams): void;
    }
}
declare module "_102035_/l2/pizzaria/web/desktop/page11/displayCozinha" {
    import { PizzariaDisplayCozinhaBase } from "_102035_/l2/pizzaria/web/shared/displayCozinha";
    export class PizzariaWebDesktopDisplayCozinhaPage extends PizzariaDisplayCozinhaBase {
        render(): any;
    }
}
