declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4BuildStamp" {
    /**
     * A per-agent COPY of the same ~60 pure lines that live in agentChangeBackend and agentChangeFrontend.
     * Deliberate: importing one agent's helper from another inside 102020 would couple two independent
     * pipelines, and the previous round already decided against promoting this to a shared project.
     *
     * PROVENANCE of the running agent code: WHICH version of this agent produced this run.
     *
     * Not "is it stale?" — that question cannot be answered from inside the agent, and asking it produced a
     * wrong diagnosis once already. What happened on 2026-08-22 (run cb-run-…01-34-27, agentChangeBackend): the MDM F1 was in
     * nobody's build because it had never been committed. The `obj/compiled.zip` in play was perfectly
     * CONSISTENT — its `fileinfos.json` and its `.js` both sat on commit 308ab97 — and the run executed the
     * last PUBLISHED build, correctly. Measured, not argued (on the agentChangeBackend of the incident): the build recorded
     * `1ef6d903…` for one of its sources, exactly `git rev-parse 308ab97:<path>`, while the working copy on
     * the author's disk hashed to `5691b296…`. There was no build bug and nothing
     * to "recompile": what puts code on the platform is commit + push (the `build.yml` Action compiles and
     * commits `obj/compiled.zip`).
     *
     * So the useful line in a trace is not an alarm, it is an IDENTITY a human can match with git.
     *
     * WHAT THIS CANNOT DO — by construction, not by omission:
     *   - It cannot see work that was never committed and pushed: the platform has never seen it. No
     *     measurement from inside the agent finds it, by timestamp or by hash.
     *   - It cannot tell whether the built `.js` matches the `.ts` of the same commit. That would be a bug in
     *     the Action, and the place to catch it is there.
     *   - It is NOT a gate: it never blocks, never fails a run, and emits no warning. A source being edited
     *     locally is the NORMAL state of whoever is editing (a file "in development" keeps its local version
     *     instead of the build's `.js` — `cfe-collab-front-end/src/stor/stor.server.ts`), so treating that as
     *     an anomaly would be noise, not signal.
     */
    /** The project this agent's code lives in. */
    export const NS4_AGENT_PROJECT = 102035;
    /** Only this agent's own sources: another folder's version says nothing about which agent ran. */
    export const NS4_AGENT_SOURCE_PREFIX = "l2/agentNewSolution/";
    /**
     * The files a human checks first, in `git`. Kept short on purpose — the digest already covers everything;
     * these exist so a reader has something to paste into `git rev-parse <commit>:<path>` without unzipping.
     */
    export const NS4_BUILD_ANCHORS: readonly string[];
    /** One entry of the build's own manifest (`fileinfos.json` inside obj/compiled.zip). */
    export interface AgentBuildFile {
        shortPath: string;
        /** git blob OID of the source AT THE BUILD COMMIT. Verified: equals `git hash-object <file>`. */
        versionRef: string;
    }
    export interface AgentProvenance {
        project: number;
        /**
         * Stable digest of the agent's `shortPath:versionRef` pairs. Two runs with the same buildRef executed
         * the same code; different buildRefs executed different code. Match a single file with
         * `git rev-parse <commit>:<path>` (or `git hash-object <file>` for a working copy).
         */
        buildRef: string;
        /** How many of this agent's sources went into the digest. */
        files: number;
        /** versionRef per anchor file; `absent` when the manifest has no entry (e.g. a file never committed). */
        anchors: Record<string, string>;
        /**
         * Last push registered on the project. NOT the build time: the platform webhook writes it on every
         * push (`cbe-collab-back-end/.../executeOnProjectUpdated.ts`) and the backend uses it to invalidate the
         * zip cache, so a push that produces no new build already moves it.
         */
        lastPushAt: string | null;
        /** How many of this agent's sources are being edited locally. Informational: this is normal. */
        localEdits: number;
        error?: string;
    }
    /**
     * FNV-1a over the sorted `shortPath:versionRef` pairs. Local and pure on purpose: the digest has to be
     * reproducible in a test without a platform, and it only has to be stable, not cryptographic.
     */
    export function digestBuildFiles(files: readonly AgentBuildFile[]): string;
    /**
     * PURE. Builds the provenance from the manifest the browser already holds.
     *
     * The manifest is the right source precisely BECAUSE it is not perturbed by local editing: it is what
     * the build recorded. `mls.stor.files[].versionRef` is not usable here — a locally created file is
     * stamped `'0'` by `createStorFile`, so a digest over it would change as soon as anyone edits.
     */
    export function buildProvenance(project: number, files: readonly AgentBuildFile[], options: {
        prefix: string;
        anchors: readonly string[];
        lastPushAt?: string | null;
        localEdits?: number;
        error?: string;
    }): AgentProvenance;
    /** The one line a trace carries. No warning path: there is no measured signal that warrants one. */
    export function describeProvenance(provenance: AgentProvenance | null): string;
    /**
     * Read the provenance of the running agent. Fail-soft by contract: any throw becomes an empty
     * `buildRef` plus the reason, and never touches the run.
     */
    export function readAgentProvenance(project?: number): Promise<AgentProvenance>;
    /**
     * One line for a step trace. Informational by contract — there is no warning path here (see the
     * header): the stamp records WHICH code ran, it does not judge it. Do not print to the console
     * (ns_console_limpo): the dossier and the step status already carry it.
     */
    export function agentBuildTrace(logPrefix: string): Promise<string>;
}
declare module "_102034_/l1/mdm/defs/level1Types" {
    /**
     * Level-1 ontology artifacts emitted from this engine into l4/organization/ontology.
     * Agents read the generated defs; they do not re-parse these types.
     */
    /** Schema of the platform level-1 ontology defs. Bumped when the subtype set or field shape changes. */
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    /** Closed platform subtype set. Grows only on a platform release, never per module. */
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    export type Ns4Level1Subtype = typeof NS4_LEVEL1_SUBTYPE_VALUES[number];
    export interface Ns4Level1Field {
        fieldId: string;
        type: string;
        required: boolean;
    }
    export interface Ns4Level1RelationshipRef {
        type: string;
        from: readonly string[];
        to: readonly string[];
        bidirectional: boolean;
    }
    export interface Ns4Level1AllowedRelationship {
        type: string;
        as: 'from' | 'to' | 'both';
        otherSubtypes: readonly string[];
    }
    export interface Ns4Level1EntityArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtype: string;
        identification: readonly Ns4Level1Field[];
        baseFields: readonly Ns4Level1Field[];
        allowedRelationships: readonly Ns4Level1AllowedRelationship[];
        compactRelationshipKeys: readonly string[];
    }
    export interface Ns4Level1IndexArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        level1SchemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtypes: readonly Ns4Level1Subtype[];
        docTypes: readonly string[];
        mdmStatuses: readonly string[];
        relationshipTypes: readonly Ns4Level1RelationshipRef[];
    }
    export interface MdmPlatformService {
        service: string;
        table?: string;
        tables?: readonly string[];
        rows?: string;
        indexes?: readonly string[];
        operations?: readonly string[];
        useFor?: readonly string[];
        notFor?: readonly string[];
        catalog?: string;
        compactRefs?: string;
        storage?: string;
        rule?: string;
        pending?: readonly string[];
    }
    export interface MdmPlatformCatalogArtifact {
        catalogVersion: string;
        layers: readonly {
            layer: string;
            owner: string;
            where: string;
            fields: readonly string[];
            note: string;
        }[];
        visibility: {
            rule: string;
            read: string;
            unrestricted: string;
            write: string;
        };
        identity: {
            who: string;
            whereThePersonExists: string;
            login: {
                storage: string;
                row: {
                    entityType: string;
                    entityId: string;
                    namespace: string;
                    tag: string;
                    module: string;
                };
                lookup: string;
                invariant: string;
                pending: readonly string[];
            };
            otherIdentifiers: string;
            neverInModule: readonly string[];
        };
        roles: {
            meaning: string;
            tag: string;
            createOrAttach: readonly string[];
            ontologyRules: readonly string[];
            actorsAreNotRoles: string;
        };
        services: readonly MdmPlatformService[];
        lookups: readonly {
            lookup: string;
            cost: string;
        }[];
        invariants: readonly string[];
    }
}
declare module "_102035_/l2/agentNewSolution/helpers/organizationTypes" {
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from "_102034_/l1/mdm/defs/level1Types";
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    /** Schema of the per-project solution registry written by E10. */
    export const NS4_SOLUTION_REGISTRY_SCHEMA_VERSION: "ns4-solution-registry-v1";
    export interface Ns4SolutionRegistryActor {
        actorId: string;
        kind: string;
    }
    export interface Ns4SolutionRegistryRole {
        mdmSubtype: string;
        role: string;
        namespace: string;
    }
    export interface Ns4SolutionRegistryGeneralField {
        fieldId: string;
        type: string;
        promotedBy: string;
        since: string;
    }
    export interface Ns4SolutionRegistryModule {
        moduleName: string;
        actors: Ns4SolutionRegistryActor[];
        roles: Ns4SolutionRegistryRole[];
        generalFields: Ns4SolutionRegistryGeneralField[];
        updatedAt: string;
    }
    export interface Ns4SolutionRegistryArtifact {
        schemaVersion: typeof NS4_SOLUTION_REGISTRY_SCHEMA_VERSION;
        level1SchemaVersion: string;
        modules: Ns4SolutionRegistryModule[];
    }
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     * collabBoot.projectId is authoritative (cbeMiniCfe feeds mls.setActualProject from it);
     * mls.actualProject is the fallback when the boot payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ClassicDefs" {
    /**
     * The untyped defs shape of the classic L4 emission, and its reader — PURE, with no storage import.
     * It lives apart from ns4Fs.ts on purpose: ns4Fs pulls in libModel, whose top-level event listener
     * crashes the l2 test stub, and the write/read round trip of these files must stay testable.
     */
    export interface Ns4ClassicDefsFile {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export function ns4ClassicDefsSource(fileInfo: Ns4ClassicDefsFile, exportName: string, value: unknown): string;
    /** Reads a defs file back to its data, exactly as the storage reader does. */
    export function parseNs4ClassicDefsSource<T>(source: string): T | null;
    export function extractNs4ClassicJsonObject(source: string): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4WidgetPhrases" {
    /**
     * English catalogue slice for the E1-E6 clarification widgets.
     * Merged into NS4_PHRASES so the root planner translates widget chrome once per run.
     */
    export const NS4_WIDGET_PHRASES: {
        readonly 'widget.intake.adjustmentRequired': "Describe what should change before generating another proposal.";
        readonly 'widget.intake.processingApproval': "Validating initial definition…";
        readonly 'widget.intake.processingChanges': "Preparing a new review…";
        readonly 'widget.intake.processingCancel': "Cancelling execution…";
        readonly 'widget.intake.revise': "Review the items below";
        readonly 'widget.intake.cancel': "Cancel execution";
        readonly 'widget.intake.cancelTitle': "Cancel this execution?";
        readonly 'widget.intake.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.intake.keepWorking': "Keep working";
        readonly 'widget.journeys.subtitle': "These journeys will become the permanent source of truth for the product.";
        readonly 'widget.journeys.actor': "Actor";
        readonly 'widget.journeys.goal': "Goal";
        readonly 'widget.journeys.steps': "Steps";
        readonly 'widget.journeys.rules': "Rules";
        readonly 'widget.journeys.outcome': "Outcome and evidence";
        readonly 'widget.journeys.filters': "Filters";
        readonly 'widget.journeys.impact': "Impact";
        readonly 'widget.journeys.noPolicyDecision': "No policy decision was provided for this journey.";
        readonly 'widget.journeys.journeys': "Journeys";
        readonly 'widget.journeys.journeysFound': "journeys found";
        readonly 'widget.journeys.selectJourney': "Select a journey to review.";
        readonly 'widget.journeys.allActors': "All actors";
        readonly 'widget.journeys.actorMap': "Journey map by actor";
        readonly 'widget.journeys.actors': "actors";
        readonly 'widget.journeys.overview': "Overview";
        readonly 'widget.journeys.actual': "(actual)";
        readonly 'widget.journeys.rulesHelp': "Rules that must remain true in every execution of this journey.";
        readonly 'widget.journeys.adjustment': "What should change?";
        readonly 'widget.journeys.placeholder': "Describe the needed change without rewriting what is already correct.";
        readonly 'widget.journeys.requestChanges': "Request changes";
        readonly 'widget.journeys.approve': "Approve journeys";
        readonly 'widget.journeys.round': "Review";
        readonly 'widget.journeys.step': "Step";
        readonly 'widget.journeys.of': "of";
        readonly 'widget.journeys.adjustmentRequired': "Describe what must change before requesting another version.";
        readonly 'widget.journeys.processingApproval': "Validating journeys…";
        readonly 'widget.journeys.processingChanges': "Preparing a new review…";
        readonly 'widget.journeys.processingCancel': "Cancelling execution…";
        readonly 'widget.journeys.revise': "Review the items below";
        readonly 'widget.journeys.cancel': "Cancel execution";
        readonly 'widget.journeys.cancelTitle': "Cancel this execution?";
        readonly 'widget.journeys.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.journeys.keepWorking': "Keep working";
        readonly 'widget.journeys.assumedDecisions': "Assumed decisions";
        readonly 'widget.journeys.changeHint': "How to change later";
        readonly 'widget.accessMatrix.subtitle': "Review who may perform each capability and exactly which information may be disclosed.";
        readonly 'widget.accessMatrix.step': "Step";
        readonly 'widget.accessMatrix.of': "of";
        readonly 'widget.accessMatrix.round': "Review";
        readonly 'widget.accessMatrix.profiles': "Access profiles";
        readonly 'widget.accessMatrix.internal': "Internal";
        readonly 'widget.accessMatrix.external': "External";
        readonly 'widget.accessMatrix.actors': "E2 actors";
        readonly 'widget.accessMatrix.landing': "Starting point";
        readonly 'widget.accessMatrix.matrix': "Profile × authority matrix";
        readonly 'widget.accessMatrix.profileAccess': "Authorities for this profile";
        readonly 'widget.accessMatrix.authority': "Authority";
        readonly 'widget.accessMatrix.noAccess': "No access";
        readonly 'widget.accessMatrix.full': "Full record";
        readonly 'widget.accessMatrix.limited': "Limited";
        readonly 'widget.accessMatrix.details': "Access details";
        readonly 'widget.accessMatrix.reason': "Business reason";
        readonly 'widget.accessMatrix.scope': "Data scope";
        readonly 'widget.accessMatrix.disclosure': "Disclosure boundary";
        readonly 'widget.accessMatrix.allowed': "May expose";
        readonly 'widget.accessMatrix.denied': "Must not expose";
        readonly 'widget.accessMatrix.ruleRefs': "Rule references";
        readonly 'widget.accessMatrix.journeySteps': "Journey steps";
        readonly 'widget.accessMatrix.informationNeeds': "Information needs";
        readonly 'widget.accessMatrix.close': "Close";
        readonly 'widget.accessMatrix.adjustment': "What should change?";
        readonly 'widget.accessMatrix.placeholder': "Example: Add authority to view project budgets; some clients may see a summary without seeing the whole project.";
        readonly 'widget.accessMatrix.requestChanges': "Generate another proposal";
        readonly 'widget.accessMatrix.approve': "Approve access matrix";
        readonly 'widget.accessMatrix.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.accessMatrix.empty': "No access matrix available.";
        readonly 'widget.accessMatrix.processingApproval': "Validating access matrix…";
        readonly 'widget.accessMatrix.processingChanges': "Preparing a new review…";
        readonly 'widget.accessMatrix.processingCancel': "Cancelling execution…";
        readonly 'widget.accessMatrix.revise': "Review the items below";
        readonly 'widget.accessMatrix.cancel': "Cancel execution";
        readonly 'widget.accessMatrix.cancelTitle': "Cancel this execution?";
        readonly 'widget.accessMatrix.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.accessMatrix.keepWorking': "Keep working";
        readonly 'widget.ontology.subtitle': "Review the business data, constraints and relationships that frontend and backend will share.";
        readonly 'widget.ontology.step': "Step";
        readonly 'widget.ontology.of': "of";
        readonly 'widget.ontology.round': "Review";
        readonly 'widget.ontology.mode': "New solution";
        readonly 'widget.ontology.changes': "Changes in this round";
        readonly 'widget.ontology.entities': "Entities";
        readonly 'widget.ontology.fields': "Fields";
        readonly 'widget.ontology.relationships': "Relationships";
        readonly 'widget.ontology.lifecycle': "Lifecycle";
        readonly 'widget.ontology.ruleRefs': "Rule references";
        readonly 'widget.ontology.overview': "Overview";
        readonly 'widget.ontology.descriptions': "Descriptions";
        readonly 'widget.ontology.source': "Traceability";
        readonly 'widget.ontology.storage': "Persistence destination";
        readonly 'widget.ontology.required': "Required";
        readonly 'widget.ontology.optional': "Optional";
        readonly 'widget.ontology.constraints': "Field rules";
        readonly 'widget.ontology.persistenceMap': "Persistence map";
        readonly 'widget.ontology.persistenceHint': "Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.";
        readonly 'widget.ontology.targetMdm': "MDM · base records";
        readonly 'widget.ontology.targetModuleDatabase': "Module database · transactions";
        readonly 'widget.ontology.targetDerived': "Derived · no own table";
        readonly 'widget.ontology.targetExternal': "External · platform owned";
        readonly 'widget.ontology.targetEmbedded': "Embedded · owned value";
        readonly 'widget.ontology.scope': "Scope";
        readonly 'widget.ontology.mdmType': "MDM type";
        readonly 'widget.ontology.idField': "Identifier";
        readonly 'widget.ontology.reason': "Reason";
        readonly 'widget.ontology.fieldRulesHint': "Click a field name or description to edit it in place.";
        readonly 'widget.ontology.crossStore': "Cross-store";
        readonly 'widget.ontology.sourceRelationships': "As origin";
        readonly 'widget.ontology.destinationRelationships': "As destination";
        readonly 'widget.ontology.noRelationships': "No relationships for this table.";
        readonly 'widget.ontology.implementation': "Field binding";
        readonly 'widget.ontology.editInPlace': "Click to edit";
        readonly 'widget.ontology.direct': "Direct description edits";
        readonly 'widget.ontology.directHint': "Titles and descriptions are safe to edit here. Structural changes use the separate request panel.";
        readonly 'widget.ontology.entityTitle': "Entity title";
        readonly 'widget.ontology.entityDescription': "Entity description";
        readonly 'widget.ontology.fieldTitle': "Field title";
        readonly 'widget.ontology.fieldDescription': "Field description";
        readonly 'widget.ontology.structural': "What should change?";
        readonly 'widget.ontology.structuralHint': "Use the LLM for entities, fields, types, relationships, lifecycle or constraints.";
        readonly 'widget.ontology.placeholder': "Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.";
        readonly 'widget.ontology.request': "Generate another proposal";
        readonly 'widget.ontology.approve': "Approve ontology";
        readonly 'widget.ontology.requiredAdjustment': "Describe the structural change first.";
        readonly 'widget.ontology.empty': "No ontology proposal available.";
        readonly 'widget.ontology.processingApproval': "Validating ontology…";
        readonly 'widget.ontology.processingChanges': "Preparing a new review…";
        readonly 'widget.ontology.processingCancel': "Cancelling execution…";
        readonly 'widget.ontology.revise': "Review the items below";
        readonly 'widget.ontology.cancel': "Cancel execution";
        readonly 'widget.ontology.cancelTitle': "Cancel this execution?";
        readonly 'widget.ontology.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.ontology.keepWorking': "Keep working";
        readonly 'widget.ontology.assumedDecisions': "Assumed decisions";
        readonly 'widget.ontology.changeHint': "How to change later";
        readonly 'widget.rules.step': "👤 Step 5 of 6 — Business rules";
        readonly 'widget.rules.review': "Review";
        readonly 'widget.rules.rules': "rules";
        readonly 'widget.rules.search': "Search by ID or description";
        readonly 'widget.rules.noRule': "No rules found.";
        readonly 'widget.rules.adjustment': "What should change?";
        readonly 'widget.rules.placeholder': "Example: change clientAvailable to allow only one active client per project.";
        readonly 'widget.rules.request': "Generate another proposal";
        readonly 'widget.rules.approve': "Approve rules";
        readonly 'widget.rules.cancel': "Cancel execution";
        readonly 'widget.rules.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.rules.processingApproval': "Validating rules…";
        readonly 'widget.rules.processingChanges': "Preparing another review…";
        readonly 'widget.rules.processingCancel': "Cancelling execution…";
        readonly 'widget.rules.revise': "Review the items below";
        readonly 'widget.rules.cancelTitle': "Cancel this execution?";
        readonly 'widget.rules.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.rules.keepWorking': "Keep working";
        readonly 'widget.rules.hint': "Each permanent rule contains only a stable ID and one business description.";
        readonly 'widget.rules.edit': "Click to edit the description";
        readonly 'widget.composition.step': "👤 Step 6 of 6 — Additional modules and plugins";
        readonly 'widget.composition.review': "Review";
        readonly 'widget.composition.empty': "No additional horizontal module or plugin was recommended.";
        readonly 'widget.composition.horizontalModule': "Horizontal module";
        readonly 'widget.composition.plugin': "Plugin";
        readonly 'widget.composition.include': "Include";
        readonly 'widget.composition.defer': "Defer";
        readonly 'widget.composition.adjustment': "Would you like to change anything?";
        readonly 'widget.composition.placeholder': "Example: add, remove or defer a recommendation and explain why.";
        readonly 'widget.composition.request': "Generate another proposal";
        readonly 'widget.composition.approve': "Approve analysis";
        readonly 'widget.composition.cancel': "Cancel execution";
        readonly 'widget.composition.adjustmentRequired': "Describe the change before generating another proposal.";
        readonly 'widget.composition.processingApproval': "Validating analysis…";
        readonly 'widget.composition.processingChanges': "Preparing another review…";
        readonly 'widget.composition.processingCancel': "Cancelling execution…";
        readonly 'widget.composition.revise': "Review the items below";
        readonly 'widget.composition.cancelTitle': "Cancel this execution?";
        readonly 'widget.composition.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.composition.keepWorking': "Keep working";
        readonly 'widget.composition.hint': "This review is conservative: an empty list means the module can proceed without additional components.";
    };
    export const NS4_WIDGET_KEYS: {
        readonly intake: readonly ["adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking"];
        readonly journeys: readonly ["subtitle", "actor", "goal", "steps", "rules", "outcome", "filters", "impact", "noPolicyDecision", "journeys", "journeysFound", "selectJourney", "allActors", "actorMap", "actors", "overview", "actual", "rulesHelp", "adjustment", "placeholder", "requestChanges", "approve", "round", "step", "of", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking", "assumedDecisions", "changeHint"];
        readonly accessMatrix: readonly ["subtitle", "step", "of", "round", "profiles", "internal", "external", "actors", "landing", "matrix", "profileAccess", "authority", "noAccess", "full", "limited", "details", "reason", "scope", "disclosure", "allowed", "denied", "ruleRefs", "journeySteps", "informationNeeds", "close", "adjustment", "placeholder", "requestChanges", "approve", "adjustmentRequired", "empty", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking"];
        readonly ontology: readonly ["subtitle", "step", "of", "round", "mode", "changes", "entities", "fields", "relationships", "lifecycle", "ruleRefs", "overview", "descriptions", "source", "storage", "required", "optional", "constraints", "persistenceMap", "persistenceHint", "targetMdm", "targetModuleDatabase", "targetDerived", "targetExternal", "targetEmbedded", "scope", "mdmType", "idField", "reason", "fieldRulesHint", "crossStore", "sourceRelationships", "destinationRelationships", "noRelationships", "implementation", "editInPlace", "direct", "directHint", "entityTitle", "entityDescription", "fieldTitle", "fieldDescription", "structural", "structuralHint", "placeholder", "request", "approve", "requiredAdjustment", "empty", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking", "assumedDecisions", "changeHint"];
        readonly rules: readonly ["step", "review", "rules", "search", "noRule", "adjustment", "placeholder", "request", "approve", "cancel", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancelTitle", "cancelText", "keepWorking", "hint", "edit"];
        readonly composition: readonly ["step", "review", "empty", "horizontalModule", "plugin", "include", "defer", "adjustment", "placeholder", "request", "approve", "cancel", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancelTitle", "cancelText", "keepWorking", "hint"];
    };
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Text" {
    /**
     * Deterministic user-facing phrases of agentNewSolution. English is the only text in code.
     * The root planner translates the catalogue once per run into `presentation.phrases`; readers
     * fall back to this object when a key is missing. Placeholders `{name}` stay verbatim in every
     * language. Internal messages (throw, statusTask, trace) are English literals, not keys.
     */
    import { NS4_WIDGET_KEYS } from "_102035_/l2/agentNewSolution/helpers/ns4WidgetPhrases";
    export const NS4_PHRASE_MAX_LENGTH: 200;
    export const NS4_PHRASES: {
        readonly 'widget.intake.adjustmentRequired': "Describe what should change before generating another proposal.";
        readonly 'widget.intake.processingApproval': "Validating initial definition…";
        readonly 'widget.intake.processingChanges': "Preparing a new review…";
        readonly 'widget.intake.processingCancel': "Cancelling execution…";
        readonly 'widget.intake.revise': "Review the items below";
        readonly 'widget.intake.cancel': "Cancel execution";
        readonly 'widget.intake.cancelTitle': "Cancel this execution?";
        readonly 'widget.intake.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.intake.keepWorking': "Keep working";
        readonly 'widget.journeys.subtitle': "These journeys will become the permanent source of truth for the product.";
        readonly 'widget.journeys.actor': "Actor";
        readonly 'widget.journeys.goal': "Goal";
        readonly 'widget.journeys.steps': "Steps";
        readonly 'widget.journeys.rules': "Rules";
        readonly 'widget.journeys.outcome': "Outcome and evidence";
        readonly 'widget.journeys.filters': "Filters";
        readonly 'widget.journeys.impact': "Impact";
        readonly 'widget.journeys.noPolicyDecision': "No policy decision was provided for this journey.";
        readonly 'widget.journeys.journeys': "Journeys";
        readonly 'widget.journeys.journeysFound': "journeys found";
        readonly 'widget.journeys.selectJourney': "Select a journey to review.";
        readonly 'widget.journeys.allActors': "All actors";
        readonly 'widget.journeys.actorMap': "Journey map by actor";
        readonly 'widget.journeys.actors': "actors";
        readonly 'widget.journeys.overview': "Overview";
        readonly 'widget.journeys.actual': "(actual)";
        readonly 'widget.journeys.rulesHelp': "Rules that must remain true in every execution of this journey.";
        readonly 'widget.journeys.adjustment': "What should change?";
        readonly 'widget.journeys.placeholder': "Describe the needed change without rewriting what is already correct.";
        readonly 'widget.journeys.requestChanges': "Request changes";
        readonly 'widget.journeys.approve': "Approve journeys";
        readonly 'widget.journeys.round': "Review";
        readonly 'widget.journeys.step': "Step";
        readonly 'widget.journeys.of': "of";
        readonly 'widget.journeys.adjustmentRequired': "Describe what must change before requesting another version.";
        readonly 'widget.journeys.processingApproval': "Validating journeys…";
        readonly 'widget.journeys.processingChanges': "Preparing a new review…";
        readonly 'widget.journeys.processingCancel': "Cancelling execution…";
        readonly 'widget.journeys.revise': "Review the items below";
        readonly 'widget.journeys.cancel': "Cancel execution";
        readonly 'widget.journeys.cancelTitle': "Cancel this execution?";
        readonly 'widget.journeys.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.journeys.keepWorking': "Keep working";
        readonly 'widget.journeys.assumedDecisions': "Assumed decisions";
        readonly 'widget.journeys.changeHint': "How to change later";
        readonly 'widget.accessMatrix.subtitle': "Review who may perform each capability and exactly which information may be disclosed.";
        readonly 'widget.accessMatrix.step': "Step";
        readonly 'widget.accessMatrix.of': "of";
        readonly 'widget.accessMatrix.round': "Review";
        readonly 'widget.accessMatrix.profiles': "Access profiles";
        readonly 'widget.accessMatrix.internal': "Internal";
        readonly 'widget.accessMatrix.external': "External";
        readonly 'widget.accessMatrix.actors': "E2 actors";
        readonly 'widget.accessMatrix.landing': "Starting point";
        readonly 'widget.accessMatrix.matrix': "Profile × authority matrix";
        readonly 'widget.accessMatrix.profileAccess': "Authorities for this profile";
        readonly 'widget.accessMatrix.authority': "Authority";
        readonly 'widget.accessMatrix.noAccess': "No access";
        readonly 'widget.accessMatrix.full': "Full record";
        readonly 'widget.accessMatrix.limited': "Limited";
        readonly 'widget.accessMatrix.details': "Access details";
        readonly 'widget.accessMatrix.reason': "Business reason";
        readonly 'widget.accessMatrix.scope': "Data scope";
        readonly 'widget.accessMatrix.disclosure': "Disclosure boundary";
        readonly 'widget.accessMatrix.allowed': "May expose";
        readonly 'widget.accessMatrix.denied': "Must not expose";
        readonly 'widget.accessMatrix.ruleRefs': "Rule references";
        readonly 'widget.accessMatrix.journeySteps': "Journey steps";
        readonly 'widget.accessMatrix.informationNeeds': "Information needs";
        readonly 'widget.accessMatrix.close': "Close";
        readonly 'widget.accessMatrix.adjustment': "What should change?";
        readonly 'widget.accessMatrix.placeholder': "Example: Add authority to view project budgets; some clients may see a summary without seeing the whole project.";
        readonly 'widget.accessMatrix.requestChanges': "Generate another proposal";
        readonly 'widget.accessMatrix.approve': "Approve access matrix";
        readonly 'widget.accessMatrix.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.accessMatrix.empty': "No access matrix available.";
        readonly 'widget.accessMatrix.processingApproval': "Validating access matrix…";
        readonly 'widget.accessMatrix.processingChanges': "Preparing a new review…";
        readonly 'widget.accessMatrix.processingCancel': "Cancelling execution…";
        readonly 'widget.accessMatrix.revise': "Review the items below";
        readonly 'widget.accessMatrix.cancel': "Cancel execution";
        readonly 'widget.accessMatrix.cancelTitle': "Cancel this execution?";
        readonly 'widget.accessMatrix.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.accessMatrix.keepWorking': "Keep working";
        readonly 'widget.ontology.subtitle': "Review the business data, constraints and relationships that frontend and backend will share.";
        readonly 'widget.ontology.step': "Step";
        readonly 'widget.ontology.of': "of";
        readonly 'widget.ontology.round': "Review";
        readonly 'widget.ontology.mode': "New solution";
        readonly 'widget.ontology.changes': "Changes in this round";
        readonly 'widget.ontology.entities': "Entities";
        readonly 'widget.ontology.fields': "Fields";
        readonly 'widget.ontology.relationships': "Relationships";
        readonly 'widget.ontology.lifecycle': "Lifecycle";
        readonly 'widget.ontology.ruleRefs': "Rule references";
        readonly 'widget.ontology.overview': "Overview";
        readonly 'widget.ontology.descriptions': "Descriptions";
        readonly 'widget.ontology.source': "Traceability";
        readonly 'widget.ontology.storage': "Persistence destination";
        readonly 'widget.ontology.required': "Required";
        readonly 'widget.ontology.optional': "Optional";
        readonly 'widget.ontology.constraints': "Field rules";
        readonly 'widget.ontology.persistenceMap': "Persistence map";
        readonly 'widget.ontology.persistenceHint': "Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.";
        readonly 'widget.ontology.targetMdm': "MDM · base records";
        readonly 'widget.ontology.targetModuleDatabase': "Module database · transactions";
        readonly 'widget.ontology.targetDerived': "Derived · no own table";
        readonly 'widget.ontology.targetExternal': "External · platform owned";
        readonly 'widget.ontology.targetEmbedded': "Embedded · owned value";
        readonly 'widget.ontology.scope': "Scope";
        readonly 'widget.ontology.mdmType': "MDM type";
        readonly 'widget.ontology.idField': "Identifier";
        readonly 'widget.ontology.reason': "Reason";
        readonly 'widget.ontology.fieldRulesHint': "Click a field name or description to edit it in place.";
        readonly 'widget.ontology.crossStore': "Cross-store";
        readonly 'widget.ontology.sourceRelationships': "As origin";
        readonly 'widget.ontology.destinationRelationships': "As destination";
        readonly 'widget.ontology.noRelationships': "No relationships for this table.";
        readonly 'widget.ontology.implementation': "Field binding";
        readonly 'widget.ontology.editInPlace': "Click to edit";
        readonly 'widget.ontology.direct': "Direct description edits";
        readonly 'widget.ontology.directHint': "Titles and descriptions are safe to edit here. Structural changes use the separate request panel.";
        readonly 'widget.ontology.entityTitle': "Entity title";
        readonly 'widget.ontology.entityDescription': "Entity description";
        readonly 'widget.ontology.fieldTitle': "Field title";
        readonly 'widget.ontology.fieldDescription': "Field description";
        readonly 'widget.ontology.structural': "What should change?";
        readonly 'widget.ontology.structuralHint': "Use the LLM for entities, fields, types, relationships, lifecycle or constraints.";
        readonly 'widget.ontology.placeholder': "Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.";
        readonly 'widget.ontology.request': "Generate another proposal";
        readonly 'widget.ontology.approve': "Approve ontology";
        readonly 'widget.ontology.requiredAdjustment': "Describe the structural change first.";
        readonly 'widget.ontology.empty': "No ontology proposal available.";
        readonly 'widget.ontology.processingApproval': "Validating ontology…";
        readonly 'widget.ontology.processingChanges': "Preparing a new review…";
        readonly 'widget.ontology.processingCancel': "Cancelling execution…";
        readonly 'widget.ontology.revise': "Review the items below";
        readonly 'widget.ontology.cancel': "Cancel execution";
        readonly 'widget.ontology.cancelTitle': "Cancel this execution?";
        readonly 'widget.ontology.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.ontology.keepWorking': "Keep working";
        readonly 'widget.ontology.assumedDecisions': "Assumed decisions";
        readonly 'widget.ontology.changeHint': "How to change later";
        readonly 'widget.rules.step': "👤 Step 5 of 6 — Business rules";
        readonly 'widget.rules.review': "Review";
        readonly 'widget.rules.rules': "rules";
        readonly 'widget.rules.search': "Search by ID or description";
        readonly 'widget.rules.noRule': "No rules found.";
        readonly 'widget.rules.adjustment': "What should change?";
        readonly 'widget.rules.placeholder': "Example: change clientAvailable to allow only one active client per project.";
        readonly 'widget.rules.request': "Generate another proposal";
        readonly 'widget.rules.approve': "Approve rules";
        readonly 'widget.rules.cancel': "Cancel execution";
        readonly 'widget.rules.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.rules.processingApproval': "Validating rules…";
        readonly 'widget.rules.processingChanges': "Preparing another review…";
        readonly 'widget.rules.processingCancel': "Cancelling execution…";
        readonly 'widget.rules.revise': "Review the items below";
        readonly 'widget.rules.cancelTitle': "Cancel this execution?";
        readonly 'widget.rules.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.rules.keepWorking': "Keep working";
        readonly 'widget.rules.hint': "Each permanent rule contains only a stable ID and one business description.";
        readonly 'widget.rules.edit': "Click to edit the description";
        readonly 'widget.composition.step': "👤 Step 6 of 6 — Additional modules and plugins";
        readonly 'widget.composition.review': "Review";
        readonly 'widget.composition.empty': "No additional horizontal module or plugin was recommended.";
        readonly 'widget.composition.horizontalModule': "Horizontal module";
        readonly 'widget.composition.plugin': "Plugin";
        readonly 'widget.composition.include': "Include";
        readonly 'widget.composition.defer': "Defer";
        readonly 'widget.composition.adjustment': "Would you like to change anything?";
        readonly 'widget.composition.placeholder': "Example: add, remove or defer a recommendation and explain why.";
        readonly 'widget.composition.request': "Generate another proposal";
        readonly 'widget.composition.approve': "Approve analysis";
        readonly 'widget.composition.cancel': "Cancel execution";
        readonly 'widget.composition.adjustmentRequired': "Describe the change before generating another proposal.";
        readonly 'widget.composition.processingApproval': "Validating analysis…";
        readonly 'widget.composition.processingChanges': "Preparing another review…";
        readonly 'widget.composition.processingCancel': "Cancelling execution…";
        readonly 'widget.composition.revise': "Review the items below";
        readonly 'widget.composition.cancelTitle': "Cancel this execution?";
        readonly 'widget.composition.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.composition.keepWorking': "Keep working";
        readonly 'widget.composition.hint': "This review is conservative: an empty list means the module can proceed without additional components.";
        readonly 'catalogue.list.title': "List {entity}";
        readonly 'catalogue.list.story': "Find the record.";
        readonly 'catalogue.create.title': "Create {entity}";
        readonly 'catalogue.create.story': "Fill in the new record.";
        readonly 'catalogue.update.title': "Update {entity}";
        readonly 'catalogue.update.story': "Correct the chosen record.";
        readonly 'catalogue.section.recordList.intent': "Find {entity}.";
        readonly 'catalogue.section.recordForm.create.intent': "Create {entity}.";
        readonly 'catalogue.section.recordForm.edit.intent': "Create or correct {entity}.";
        readonly 'catalogue.purpose': "{entity} record catalogue.";
        readonly 'catalogue.delete.title': "Delete {entity}";
        readonly 'catalogue.delete.story': "Remove the chosen record.";
        readonly 'catalogue.inactivate.title': "Deactivate {entity}";
        readonly 'catalogue.inactivate.story': "Deactivate the record (history and references are preserved).";
        readonly 'catalogue.reactivate.title': "Reactivate {entity}";
        readonly 'catalogue.reactivate.story': "Reactivate a deactivated record.";
        readonly 'catalogue.get.title': "Get {entity}";
        readonly 'catalogue.get.story': "Read the record by id.";
        readonly 'catalogue.audience.question': "No journey operates {entity}: who maintains this catalogue?";
        readonly 'catalogue.audience.changeHint': "Add an E3 authority over {entity} to restrict this catalogue to a named profile.";
        readonly 'catalogue.list.search': "Search by {field}.";
        readonly 'catalogue.list.sortBy': "Field to sort the listing by.";
        readonly 'catalogue.list.sortOrder': "Sort direction.";
        readonly 'catalogue.list.page': "Listing page (1-based).";
        readonly 'catalogue.list.pageSize': "Page size (default 20, cap 200).";
        readonly 'journey.decide.description': "The decision taken.";
        readonly 'hub.purpose': "{entity} command centre.";
        readonly 'hub.section.collection.intent': "Portfolio and search.";
        readonly 'hub.section.record.intent': "The selected record and what revolves around it.";
        readonly 'projection.unjoined.question': "Use case {useCaseId} reads projection {projectionId} with no derived relationship to {entity}: E4 cannot join them. Omit from the output?";
        readonly 'projection.unjoined.changeHint': "Declare an E4 relationship with realization.kind derived between {projectionId} and {entity}.";
        readonly 'hub.composition.question': "The proposed composition for the {entity} dashboard did not respect the catalogue; use the default order?";
        readonly 'hub.composition.changeHint': "Review the order and highlights of the {entity} dashboard in the next round.";
        readonly 'workflow.unreachable.question': "How should the unreachable {entity}.{state} lifecycle state be handled?";
        readonly 'workflow.unreachable.changeHint': "Add an explicit E2 journey/operation that reaches {entity}.{state} before restoring it to the compiled workflow; the E4 ontology remains unchanged.";
        readonly 'workflow.predicate.question': "The {predicateId} criterion has no effect in this version — none of its states is reachable.";
        readonly 'workflow.predicate.changeHint': "Add an E2 journey that reaches one of {states}; the E5 rule and E4 ontology remain unchanged.";
        readonly 'workflow.omit.question': "{entity} has no operated state flow in this version.";
        readonly 'workflow.omit.changeHint': "Add an E2 journey that operates a {entity} transition; the E4 ontology remains unchanged.";
        readonly 'actor.drop.question': "Actor {actor} was inferred and has no exclusive step. Drop it?";
        readonly 'actor.drop.changeHint': "An inferred external actor whose steps another actor already performs is a persona, not an access role.";
        readonly 'actor.keep.question': "Actor {actor} was inferred and has exclusive steps. Keep it?";
        readonly 'actor.keep.changeHint': "The model invented this actor; exclusive steps are the reason it remains.";
        readonly 'actor.system.question': "Actor {actor} is a system integration point, not a persona. Keep it?";
        readonly 'actor.system.changeHint': "A kind:system actor is an inbound integration, not a demographic persona.";
        readonly 'demotion.chosen': "Standard {entity} record catalogue";
        readonly 'demotion.alternative': "Keep {journey} as its own journey";
        readonly 'demotion.question': "{journey} has no decision and no handoff: should it become the standard {entity} record catalogue?";
        readonly 'dormant.question': "The {title} action stays visible, but transition {transitions} is not reachable in this version.";
        readonly 'dormant.unwritten.question': "State {entity}.{state} is reached only by a transition whose use case does not write {entity}.";
        readonly 'state.unreachable.question': "State {entity}.{state} ({reachedBy}) has no reachable transition. Connect the command that writes it.";
        readonly 'state.filtered.question': "Operation {operation} filters by unreachable state {entity}.{state}.";
        readonly 'writes.beyond.question': "Use case {useCase} records {entities}, which the journey did not name as affected. Keep those writes?";
        readonly 'writes.beyond.changeHint': "Drop the extra writes on {useCase} or add {entities} to the act step affects list.";
        readonly 'route.ambiguous.question': "Which record should the {title} screen open directly?";
        readonly 'route.ambiguous.changeHint': "The {title} screen opens without a direct record link in this version; define a single target context to enable it.";
    };
    export type Ns4PhraseKey = keyof typeof NS4_PHRASES;
    export function isNs4PhraseKey(value: string): value is Ns4PhraseKey;
    export interface Ns4PhraseHolder {
        phrases?: Partial<Record<Ns4PhraseKey, string>>;
    }
    export interface Ns4PhrasesNormalization {
        phrases: Partial<Record<Ns4PhraseKey, string>>;
        warnings: string[];
    }
    export function ns4Text(presentation: Ns4PhraseHolder | undefined, key: Ns4PhraseKey, params?: Record<string, string>): string;
    type Ns4WidgetName = keyof typeof NS4_WIDGET_KEYS;
    export type Ns4WidgetLabelMap<W extends Ns4WidgetName> = {
        [K in (typeof NS4_WIDGET_KEYS)[W][number]]: string;
    };
    export function ns4WidgetLabels<W extends Ns4WidgetName>(presentation: Ns4PhraseHolder | undefined, widget: W): Ns4WidgetLabelMap<W>;
    export function normalizeNs4Phrases(value: unknown): Ns4PhrasesNormalization;
    export function ns4PlannerPhrasesAppendix(): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Core" {
    import { type Ns4PhraseKey } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    export const NS4_FLOW_ID: "agentNewSolution";
    export const NS4_FLOW_VERSION: "2026-09-08-ns4-flow-v41";
    export const NS4_E4_MAX_PARALLEL: 20;
    export const NS4_E7_MAX_PARALLEL: 20;
    export const NS4_E8_MAX_PARALLEL: 20;
    export const NS4_MODULE_SCHEMA_VERSION: "2026-08-06-ns4-module-v4";
    export const NS4_PIPELINE_SCHEMA_VERSION: "2026-08-06-ns4-pipeline-v5";
    export type Ns4PermanentFlowVersion = typeof NS4_FLOW_VERSION | '2026-08-14-ns4-flow-v40' | '2026-08-14-ns4-flow-v39' | '2026-08-14-ns4-flow-v38' | '2026-08-14-ns4-flow-v37' | '2026-08-14-ns4-flow-v36' | '2026-08-14-ns4-flow-v35' | '2026-08-14-ns4-flow-v34' | '2026-08-13-ns4-flow-v33' | '2026-08-13-ns4-flow-v32' | '2026-08-13-ns4-flow-v31' | '2026-08-12-ns4-flow-v30' | '2026-08-11-ns4-flow-v24' | '2026-08-11-ns4-flow-v22' | '2026-08-10-ns4-flow-v21' | '2026-08-10-ns4-flow-v20' | '2026-08-09-ns4-flow-v19' | '2026-08-09-ns4-flow-v18' | '2026-08-08-ns4-flow-v17';
    export const NS4_PLAN_IDS: readonly ["e1-clarification", "e1-compile", "e2-journeys", "e3-access-matrix", "e4-ontology", "e4b-access-realization", "e5-rules", "e6-behaviors", "e7-realization", "e8-workspaces", "e9-navigation-compiler", "e10-validation"];
    export type Ns4PlanId = typeof NS4_PLAN_IDS[number];
    export const NS4_HUMAN_CHECKPOINT_ICON: "\uD83D\uDC64";
    export const NS4_AUTOMATED_JUDGE_ICON: "\uD83D\uDD0E";
    export type Ns4ApprovedBy = 'human' | 'auto';
    export type Ns4E1Status = 'running' | 'approved' | 'failed';
    export type Ns4E2Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E3Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E4Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E4BStatus = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E5Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E6Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E7Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E8Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E9Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E10Status = 'running' | 'approved' | 'failed';
    export type Ns4CompletedStepId = 'e1' | 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation';
    export type Ns4NextStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation' | 'complete';
    export interface Ns4ClarificationQuestion {
        type: 'open';
        question: string;
        answer: string;
    }
    export interface Ns4Clarification {
        planId: 'e1-clarification';
        userLanguage: string;
        title: string;
        legends: string[];
        questions: Record<string, Ns4ClarificationQuestion>;
    }
    export interface Ns4Presentation {
        userLanguage: string;
        stepTitles: Record<Ns4PlanId, string>;
        phrases?: Partial<Record<Ns4PhraseKey, string>>;
    }
    export interface Ns4RootPlan {
        validPrompt: boolean;
        invalidReason?: string;
        userPrompt: string;
        presentation: Ns4Presentation;
        clarification: Ns4Clarification;
        phraseWarnings?: string[];
    }
    export const NS4_TERMINAL_CANCEL_UNSUPPORTED = "Terminal cancellation still depends on explicit collab-messages support; this review was kept open without changing the pipeline.";
    export const NS4_DESCRIBE_REQUIRED_CHANGE = "Describe the required change before submitting.";
    export interface Ns4ModuleArtifact {
        schemaVersion: typeof NS4_MODULE_SCHEMA_VERSION;
        presentation: Ns4Presentation;
        module: {
            moduleName: string;
            title: string;
            purpose: string;
            languages: string[];
        };
        designContext: {
            initialPrompt: string;
            clarification: {
                mainActors: string;
                mainGoal: string;
                boundaries: string;
            };
        };
        reviewPolicy: {
            mode: 'guided' | 'smart' | 'automatic';
        };
        solutionStrategy: {
            mode: 'newSolution' | 'modernizePreserveDatabase' | 'modernizeEvolveDatabase' | 'replaceAndMigrateData';
            rationale: string;
            databaseChangePolicy: 'new' | 'forbidden' | 'additiveControlled' | 'replacement';
            modernization?: {
                sourceSystemName: string;
                sourceTechnology?: string;
                databaseEngine?: string;
                databaseVersion?: string;
                schemaAvailability: 'uploadAtE4' | 'metadataAtE4' | 'notAvailableYet';
                notes?: string;
            };
        };
        businessScope: {
            mainGoal: string;
            actors: Array<{
                actorId: string;
                title: string;
                kind: 'internal' | 'external' | 'system';
                origin: 'named' | 'inferred';
                expectedOutcome: string;
            }>;
            expectedOutcomes: Array<{
                outcomeId: string;
                title: string;
                description: string;
            }>;
            inScope: string[];
            outOfScope: string[];
        };
        localization: {
            productLanguages: string[];
            defaultLanguage: string;
            defaultLocale?: string;
            currency?: string;
            timeZone?: string;
            primaryMarket?: string;
        };
        declaredConstraints: {
            mandatoryIntegrations: Array<{
                dependencyId: string;
                title: string;
                kind: 'externalSystem' | 'platform' | 'unknown';
                reason: string;
            }>;
            regulatoryNotes?: string;
            criticalNotes?: string;
        };
        specStatus: {
            flowId: typeof NS4_FLOW_ID;
            /** v17 remains readable by tsc, but isNs4Pipeline deliberately rejects it for runtime resume. */
            flowVersion: Ns4PermanentFlowVersion;
            state: 'inProgress' | 'complete';
            artifactCompleteness: 'partial' | 'full';
            completedSteps: Array<{
                stepId: Ns4CompletedStepId;
                status: 'approved';
                approvedBy: Ns4ApprovedBy;
                approvedAt: string;
                /** Present when smart skipped the human checkpoint. */
                autoReason?: string;
            }>;
            nextStep: Ns4NextStep;
            updatedAt: string;
        };
    }
    export interface Ns4PipelineState {
        schemaVersion: typeof NS4_PIPELINE_SCHEMA_VERSION;
        flowId: typeof NS4_FLOW_ID;
        flowVersion: typeof NS4_FLOW_VERSION;
        moduleName: string;
        sourcePrompt: string;
        presentation: Ns4Presentation;
        status: 'inProgress' | 'complete' | 'failed';
        /** Audit of the last explicit regeneration: which step it restarted from, and when. */
        rebuiltFrom?: Ns4RebuildFrom;
        rebuiltAt?: string;
        /** Counts from `/rebuild all` (l1/l2/l4/l5 wipe). Survives on the regenerated pipeline for runNN_*.json. */
        rebuildAll?: Ns4RebuildAllReport;
        steps: {
            e1: {
                status: Ns4E1Status;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                skippedDefaults?: {
                    productLanguages: string[];
                    defaultLanguage: string;
                    moduleName: string;
                    i18nWarnings?: string[];
                };
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e2?: {
                status: Ns4E2Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e3?: {
                status: Ns4E3Status;
                reviewRound: number;
                draftPath?: string;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e4?: {
                status: Ns4E4Status;
                reviewRound: number;
                solutionMode: 'new';
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e4b?: {
                status: Ns4E4BStatus;
                artifactPaths?: string[];
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                repairStep?: 'e4-ontology' | 'e4b-access-realization';
                updatedAt: string;
            };
            e5?: {
                status: Ns4E5Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e6?: {
                status: Ns4E6Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e7?: {
                status: Ns4E7Status;
                planPath?: string;
                artifactPaths?: string[];
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e8?: {
                status: Ns4E8Status;
                reviewRound: number;
                skeletonPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e9?: {
                status: Ns4E9Status;
                artifactPaths?: string[];
                repairStep?: 'e8-workspaces' | 'e9-navigation-compiler';
                error?: string;
                failedAt?: string;
                approvedAt?: string;
                updatedAt: string;
            };
            e10?: {
                status: Ns4E10Status;
                reportPath?: string;
                artifactPaths?: string[];
                repairStep?: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>;
                error?: string;
                failedAt?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                updatedAt: string;
            };
        };
        nextStep: Ns4NextStep;
        createdAt: string;
        updatedAt: string;
        /**
         * E9 audit: an E7 use case that did not become an operation. Only `degraded` is persisted at the
         * top level — a clean emit strips both fields so a prior-run `degraded` cannot come back.
         */
        useCases?: 'degraded';
        useCasesDropped?: {
            notEmitted: string[];
            approved: number;
            emitted: number;
            reasons?: Record<string, string>;
        };
        /** Recorded when `/fast` dispatches the next agent, so a re-entry of E10 does not send twice. */
        fastHandoff?: {
            to: string;
            message: string;
            at: string;
        };
    }
    export type Ns4ExistingAction = 'new' | 'resume-e1' | 'resume-e2' | 'resume-e3' | 'resume-e4' | 'resume-e4b' | 'resume-e5' | 'resume-e6' | 'resume-e7' | 'resume-e8' | 'resume-e9' | 'resume-e10' | 'resume-next' | 'collision';
    /** Steps a partial rebuild can start from. e1 is not one of them: restarting at e1 IS a total rebuild. */
    export type Ns4RebuildFrom = 'e2' | 'e3' | 'e4' | 'e4b' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /** `/rebuild all` is its own mode: wipe l1/l2/l4 of the module, then regenerate from the stored prompt. */
    export type Ns4RebuildArg = Ns4RebuildFrom | 'all';
    export interface Ns4RebuildAllReport {
        at: string;
        deleted: {
            l1: number;
            l2: number;
            l4: number;
            l5: number;
        };
        sanitized: {
            projectJsonRemoved: number;
            configJsonRemoved: number;
        };
    }
    export interface Ns4Invocation {
        fast: boolean;
        /** Explicit regeneration intent. Never inferred from prose — prose only produces a graceful stop. */
        rebuild: boolean;
        /** Set by `/rebuild all` or `/rebuild <eN>`; empty means the existing total rebuild (l4/l5 only). */
        rebuildFrom: Ns4RebuildArg | '';
        /** Suppress the next-agent handoff. Independent of `/fast`; `/nochainlane` does not match. */
        nochain: boolean;
        prompt: string;
    }
    export function parseNs4Invocation(value: string): Ns4Invocation;
    /**
     * A prompt that ASKS for a rebuild in prose and names an existing module.
     *
     * The incident this exists for: `rebuild all criar um site chamado petShop , em …`. The module name sits
     * mid-sentence, so `resolveNs4ExistingModuleToken` (which requires the WHOLE prompt to be one token) read
     * it as a new module, E1 ran, and the existence backstop killed the task — the user asked to rebuild and
     * got a terminal error.
     *
     * BOTH signals are required. Scanning tokens for an existing module name on its own would hijack an
     * ordinary creation prompt that happens to mention one ("a schedule module for petShop"); demanding
     * an explicit rebuild word keeps every prompt without one canonicalized exactly as before. The outcome is
     * only ever a message teaching the flag — nothing is written or deleted on this path.
     *
     * The rebuild word may be a flag (`/rebuild`): the slash sits where a start-or-space used to be
     * required, so the canonical form never reached this helper. Natural-language synonyms are not a
     * command; the status task names `/rebuild`.
     */
    export function detectNs4RebuildIntentModule(value: string, existingModules: ReadonlySet<string>): string;
    export function formatNs4MissingRebuildModuleMessage(existingModules: ReadonlySet<string>): string;
    export function createNs4E2Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E1Step(reviewRound?: number, adjustment?: string, previousReview?: unknown, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E2GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, coverageRepairAttempt: number, gateFeedback: string, stepTitle?: string, coverageIssueIds?: string[], policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E2CoverageRepairStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, coverageFeedback: string, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E2CoverageJudgeStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, judgeAttempt: number, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E3Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /**
     * One bounded structural repair for E3, mirroring the E2 gate repair: the model
     * sees the numbered gate findings plus the persisted invalid draft and returns a
     * complete corrected matrix through the same gate.
     */
    export function createNs4E3GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4RepairStep(moduleName: string, reviewRound: number, repairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4FinalizeStep(moduleName: string, reviewRound: number, dependsOn: string[], entityRepairRound?: number, planRepairAttempt?: number, derivationRepairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E4RelationshipBindingStep(moduleName: string, reviewRound: number, bindingRepairAttempt?: number, gateFeedback?: string, entityRepairRound?: number): mls.msg.AIAgentStep;
    export function createNs4E4DerivationBindingStep(moduleName: string, reviewRound: number, derivationRepairAttempt?: number, gateFeedback?: string, entityRepairRound?: number, planRepairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E4BStep(moduleName?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E5Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E6Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E7Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export type Ns4StepOwner = 'e1' | 'e2' | 'e3' | 'e4' | 'e4b' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /**
     * The dispatch table, next to the factories that mint the plan ids it matches. The router and the
     * factories drifted apart once — a factory emitting `e8-workspaces-round-1` against a router that
     * only knew `e8-workspaces` — and the step died before reaching any agent, with no trace to read.
     * One table, one truth, and a test that walks every factory through it.
     */
    export function resolveNs4StepOwner(planId: string): Ns4StepOwner | '';
    /**
     * The E8 plan ids live in ONE place, next to the factories that mint them. The router matched a
     * hand-written pattern once and stopped seeing the real step: a plan id the factory emits and the
     * router does not recognize is a step that dies without ever reaching its agent.
     */
    export function ns4E8StepPlanId(reviewRound: number): string;
    export function ns4E8HubRepairPlanId(reviewRound: number, attempt: number): string;
    export function isNs4E8PlanId(planId: string): boolean;
    export function createNs4E8Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /** The one bounded repair E8 still schedules: the hub composition over its closed catalogue. */
    export function createNs4E8HubCompositionRepairStep(moduleName: string, reviewRound: number, compositionAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E9Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E10Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export const NS4_DEFAULT_TITLES: Record<Ns4PlanId, string>;
    export function formatNs4VisibleStepTitle(planId: Ns4PlanId, title: string): string;
    export function plainNs4StepTitle(title: string): string;
    /** Dynamic E4 children do not retain planning.planId; hook args are their stable dispatcher key. */
    export function resolveNs4DynamicWorker(value: unknown): 'e4' | 'e7' | 'e8' | '';
    export interface Ns4DynamicWorkerRequest {
        worker: 'e4' | 'e7' | 'e8' | '';
        args: string;
    }
    /**
     * collab-messages supplies the selector as hook args before a parallel prompt, but may omit those
     * args in the after-prompt callback while retaining the selector in step.prompt. Both callbacks must
     * resolve through the same ordered fallback or a valid entity payload reaches the root planner.
     */
    export function resolveNs4DynamicWorkerRequest(args: unknown, stepPrompt: unknown): Ns4DynamicWorkerRequest;
    export function normalizeNs4RootPlan(payload: unknown, sourcePrompt: string): Ns4RootPlan;
    export function buildNs4PlannedSteps(plan: Ns4RootPlan): mls.msg.AIAgentStep[];
    export function isNs4ModuleToken(value: string): boolean;
    export function normalizeNs4ModuleName(value: unknown, fallback?: string): string;
    export function resolveNs4ExistingModuleToken(value: string, existingModules: ReadonlySet<string>): string;
    export function normalizeNs4Clarification(value: unknown): Ns4Clarification;
    export function buildNs4ModuleArtifact(sourcePrompt: string, clarificationInput: unknown, approvedBy: Ns4ApprovedBy, now?: string, presentation?: Ns4Presentation): Ns4ModuleArtifact;
    export function normalizeNs4Languages(value: unknown, fallback?: string): string[];
    export function createNs4Pipeline(moduleNameInput: string, sourcePrompt: string, now?: string, presentation?: Ns4Presentation): Ns4PipelineState;
    export function markNs4E1Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, autoReason?: string, skippedDefaults?: {
        productLanguages: string[];
        defaultLanguage: string;
        moduleName: string;
        i18nWarnings?: string[];
    }): Ns4PipelineState;
    export function markNs4FastHandoff(state: Ns4PipelineState, to: string, message: string, now?: string): Ns4PipelineState;
    export function markNs4E2Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E1Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E2Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    /** A changed approved E2 contract invalidates only downstream contracts derived from journeys. */
    export function markNs4E2ImpactStale(state: Ns4PipelineState, hasJourneyImpact: boolean, now?: string): Ns4PipelineState;
    export function markNs4ModuleE2Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, invalidateDownstream?: boolean, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E3Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E3WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E3Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E3Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE3Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E4Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E4WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E4Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE4Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E4Stale(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4BRunning(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    export function markNs4E4BFailed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4BApproved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE4BApproved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E5Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E5WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E5Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E5Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE5Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E6Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E6WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E6Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E6Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE6Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E7Running(state: Ns4PipelineState, planPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E7Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E7Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE7Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E8Running(state: Ns4PipelineState, reviewRound?: number, skeletonPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E8Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E8Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE8Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function markNs4E9Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    export function markNs4E9Failed(state: Ns4PipelineState, failure: unknown, origin?: 'skeleton' | 'compiler', now?: string): Ns4PipelineState;
    export function markNs4E9Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE9Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E10Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    /**
     * E10 failed on a defect of the pipeline, not of the product: nothing upstream is stale, because
     * nothing upstream is wrong. The module waits on a fixed pipeline and re-validates from E10.
     */
    export function markNs4E10PipelineDefect(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Failed(state: Ns4PipelineState, failure: unknown, repairStep: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10RuntimeFailed(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, now?: string, reportPath?: string, artifactPaths?: string[]): Ns4PipelineState;
    export function markNs4ModuleE10Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function resolveNs4ExistingAction(moduleExists: boolean, pipeline: unknown, moduleArtifactExists: boolean): Ns4ExistingAction;
    /**
     * Everything a TOTAL rebuild archives: the module's whole l4 and l5 trees.
     *
     * The whole folder, not a list of known artifacts — that is the point. A previous run leaves drafts,
     * pipeline traces (`pipeline/msgtask*.json`) and per-entity defs whose names came from ITS ontology; a
     * selective delete keeps whatever the new run happens not to overwrite, and the module ends up a mix of
     * two generations. l2 is NOT touched: it belongs to agentChangeFrontend, which has its own rebuild.
     *
     * PURE over a `mls.stor.files`-shaped map so the selection is testable without the platform.
     */
    export function listNs4RebuildDeletionKeys(files: Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    } | undefined>, project: number, moduleName: string): string[];
    /** eN and every step after it. */
    export function ns4RebuildRange(from: Ns4RebuildFrom): Ns4RebuildFrom[];
    /**
     * Resets eN..e10 for a partial rebuild.
     *
     * The reset is EXPLICIT and stamped (`rebuiltFrom`/`rebuiltAt`), which is what keeps rule 11 intact: an
     * approved state is never regressed by a late callback, only by an intent the user typed. The step entries
     * are dropped rather than set to a status, because e2..e10 are optional and "absent" is exactly what
     * "not done yet" means in this pipeline.
     */
    export function resetNs4PipelineForRebuild(pipeline: Ns4PipelineState, from: Ns4RebuildFrom, rebuiltAt?: string): Ns4PipelineState;
    /**
     * Drops the rebuilt range from the permanent artifact's completedSteps.
     *
     * Without this the reset is undone silently: the invocation reconciles the pipeline from
     * `specStatus.completedSteps` whenever the artifact says approved and the file still exists, so the very
     * next invocation would re-mark e10 approved and answer "pipeline encerrado" to a second /rebuild e10.
     */
    export function clearNs4ModuleCompletedStepsFrom(artifact: Ns4ModuleArtifact, from: Ns4RebuildFrom): Ns4ModuleArtifact;
    export function isNs4Pipeline(value: unknown): value is Ns4PipelineState;
    export function humanizeNs4ModuleName(moduleName: string): string;
    /** Display names of the language in the user's language, its own language and English. */
    export function ns4LanguageMentioned(language: string, userLanguage: string, foldedText: string): boolean;
    /** Lower case without diacritics, so a folded language name matches with or without marks. */
    export function foldNs4Text(value: string): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4RebuildAll" {
    import { type Ns4PipelineState, type Ns4RebuildAllReport } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type Ns4RebuildAllFile = {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    };
    export type Ns4RebuildAllPlan = {
        ok: true;
        prompt: string;
        keys: string[];
        report: Ns4RebuildAllReport;
        projectJson: Record<string, unknown> | null;
        configJson: Record<string, unknown> | null;
    } | {
        ok: false;
        reason: string;
        keys: string[];
    };
    /**
     * Exact module-folder prefix: the first path segment, after the same canonicalization every other
     * NS folder uses. Never `includes`, never a loose regex — `listaAssinatura` must not match
     * `listaAssinaturaAntiga`, and `todo` must not match `todoList` or anything else.
     */
    export function isNs4ExactModuleFolderPrefix(folder: string, moduleName: string): boolean;
    export function recoverNs4RebuildAllPrompt(input: {
        initialPrompt?: unknown;
        sourcePrompt?: unknown;
    }): {
        ok: true;
        prompt: string;
    } | {
        ok: false;
        reason: string;
    };
    /** l1, l2, l4 and per-module l5 of THAT module only. Project-level l5 (config.json, project.json) stays. */
    export function listNs4RebuildAllDeletionKeys(files: Record<string, Ns4RebuildAllFile | undefined>, project: number, moduleName: string): string[];
    export function countNs4RebuildAllByLayer(files: Record<string, Ns4RebuildAllFile | undefined>, keys: readonly string[]): Ns4RebuildAllReport['deleted'];
    export function stripNs4ModuleFromProjectJson(projectJson: unknown, moduleName: string): {
        value: Record<string, unknown> | null;
        removed: number;
    };
    export function stripNs4ModuleFromConfigJson(config: unknown, moduleName: string): {
        value: Record<string, unknown> | null;
        removed: number;
    };
    export function planNs4RebuildAll(input: {
        files: Record<string, Ns4RebuildAllFile | undefined>;
        project: number;
        moduleName: string;
        initialPrompt?: unknown;
        sourcePrompt?: unknown;
        projectJson?: unknown;
        configJson?: unknown;
        at?: string;
    }): Ns4RebuildAllPlan;
    export function stampNs4RebuildAll(pipeline: Ns4PipelineState, report: Ns4RebuildAllReport): Ns4PipelineState;
    export function parseNs4RebuildAllReport(value: unknown): Ns4RebuildAllReport | null;
    export function formatNs4RebuildAllNote(moduleName: string, report: Ns4RebuildAllReport): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ContentRead" {
    export interface Ns4ReadableFile {
        versionRef?: unknown;
        getValueInfo?: () => Promise<{
            content?: unknown;
        }>;
        getContent: () => Promise<unknown>;
    }
    export interface Ns4ContentReadResult {
        text: string | null;
        unavailableNewFile: boolean;
    }
    /** Local-first content resolution that never sends the unsaved versionRef=0 to a remote driver. */
    export function readNs4AvailableContent(file: Ns4ReadableFile, extension: string): Promise<Ns4ContentReadResult>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Resolve" {
    export type Ns4ResolutionClass = 'A' | 'B' | 'C';
    export interface Ns4SystemDecision {
        decisionId: string;
        stage: string;
        question: string;
        chosen: string;
        alternatives: string[];
        decidedBy: 'system';
        findingRef: string;
        changeHint: string;
    }
    interface Ns4ResolutionFindingBase {
        decisionId?: string;
        findingRef: string;
        stage: string;
        question: string;
        alternatives: string[];
        changeHint: string;
    }
    export interface Ns4TypeAFinding extends Ns4ResolutionFindingBase {
        classification: 'A';
    }
    export interface Ns4TypeBFinding extends Ns4ResolutionFindingBase {
        classification: 'B';
        /** The behavior already implicit in the generated artifact. */
        defaultChoice: string;
    }
    export interface Ns4TypeCFinding<TArtifact> extends Ns4ResolutionFindingBase {
        classification: 'C';
        deterministicChoice: string;
        apply: (artifact: TArtifact) => TArtifact;
    }
    export type Ns4ResolutionFinding<TArtifact> = Ns4TypeAFinding | Ns4TypeBFinding | Ns4TypeCFinding<TArtifact>;
    export interface Ns4ResolutionResult<TArtifact> {
        artifact: TArtifact;
        systemDecisions: Ns4SystemDecision[];
        unresolved: Array<Ns4TypeAFinding>;
    }
    /**
     * The single NS4 semantic-resolution boundary. Type A remains unresolved,
     * Type B records the generator's existing choice, and Type C applies its
     * caller-supplied mechanical patch before recording the decision.
     */
    export function resolveNs4Findings<TArtifact>(artifact: TArtifact, findings: Array<Ns4ResolutionFinding<TArtifact>>): Ns4ResolutionResult<TArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e4/contracts" {
    import { type Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4Level1Subtype } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export const NS4_ONTOLOGY_SCHEMA_VERSION: "2026-09-08-ns4-ontology-v7";
    export const NS4_ONTOLOGY_SCHEMA_VERSION_V6: "2026-08-11-ns4-ontology-v6";
    export type { Ns4Level1Subtype };
    /** Human-text JSON paths the importer may rewrite. Union of entity + index shapes that share this schemaVersion. */
    export const TEXT_PATHS_2026_09_08_ns4_ontology_v7: string[];
    export const TEXT_PATHS_2026_08_11_ns4_ontology_v6: string[];
    export const TEXT_PATHS_2026_08_09_ns4_ontology_v4: string[];
    export const TEXT_PATHS_2026_08_08_ns4_ontology_v3: string[];
    export type Ns4EntityKind = 'core' | 'event' | 'supporting' | 'mdm' | 'projection' | 'valueObject';
    /**
     * Is this entity a PARTY — a natural person or an organization?
     *
     * The question decides where the record lives, and it cannot be answered by a name heuristic (the run of
     * buildFlowFsm sent Client and Project to MDM but left FieldWorker — a person — as a module table, seeded,
     * duplicating the organization's own people). Declaring it makes the rule mechanical: a party is master
     * data of the organization, so `storage.target` must be `mdm`, and the gate says so instead of hoping the
     * prompt was read.
     */
    export type Ns4EntityParty = 'person' | 'organization' | 'none';
    export type Ns4EntityOwnership = 'moduleOwned' | 'external' | 'derived';
    export type Ns4DerivationOp = 'count' | 'sum' | 'min' | 'max' | 'first' | 'groupKey';
    /** One output field of a derived projection, computed from the source named by `derivation.from`. */
    export interface Ns4DerivationAggregate {
        fieldId: string;
        op: Ns4DerivationOp;
        /** Source-entity field when the op needs one (`sum`/`min`/`max`/`first`/`groupKey`). Absent for `count`. */
        sourceField?: string;
        /**
         * Sign of a `sum` from an enum on the source. OPTIONAL so L4 written before this field keeps
         * compiling — nothing is ever migrated. Only valid with `op: 'sum'`; `field` is an enum of
         * `derivation.from`, and rows whose value is in `negativeValues` enter the sum negative.
         */
        signBy?: {
            field: string;
            negativeValues: string[];
        };
    }
    /**
     * How a derived projection is computed. OPTIONAL on the type so L4 written before this field keeps
     * compiling — nothing is ever migrated. The E4 gate requires it on every `kind: projection` +
     * `ownership: derived` this generator now produces.
     */
    export interface Ns4EntityDerivation {
        /** entityId of the persisted source; must exist in the same ontology. */
        from: string;
        /** Predicate on declared fields of the source (`status = valid`). Empty when unfiltered. */
        filter: string;
        /** One entry per output field of the projection. */
        aggregate: Ns4DerivationAggregate[];
    }
    export type Ns4ConstraintSource = 'database' | 'journey' | 'user' | 'inferred' | 'legacyCode';
    export type Ns4StorageTarget = 'mdm' | 'moduleDatabase' | 'derived' | 'external' | 'embedded';
    export type Ns4StorageScope = 'organization' | 'module' | 'platform' | 'none';
    export type Ns4RelationshipPersistenceMode = 'mdmRelationship' | 'moduleReference' | 'crossStoreReference' | 'derivedJoin' | 'externalReference' | 'embedded';
    export type Ns4RelationshipRealizationKind = 'fieldReference' | 'fieldCollection' | 'mdmRelationship' | 'derived' | 'externalReference' | 'embedded';
    export interface Ns4RelationshipEndpointBinding {
        entityId: string;
        fieldIds: string[];
    }
    /** Concrete implementation of one semantic edge using fields that already exist in E4 entities. */
    export interface Ns4RelationshipRealization {
        kind: Ns4RelationshipRealizationKind;
        ownerEntity: string;
        from: Ns4RelationshipEndpointBinding;
        to: Ns4RelationshipEndpointBinding;
        description: string;
    }
    export interface Ns4FieldConstraint {
        constraintId: string;
        kind: 'min' | 'max' | 'minLength' | 'maxLength' | 'pattern' | 'enum' | 'format' | 'unique' | 'custom';
        value: string;
        description: string;
        source: Ns4ConstraintSource;
    }
    /** Display text for one closed-domain code. Array-of-objects so the tool schema can stay additionalProperties:false. */
    export interface Ns4EnumLabel {
        code: string;
        label: string;
    }
    export interface Ns4OntologyField {
        fieldId: string;
        title: string;
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        required: boolean;
        description: string;
        constraints: Ns4FieldConstraint[];
        /**
         * The literal values of an enumerated field, derived from its enum constraint (or from the entity
         * lifecycle for a status field). It is what turns a decision into a closed selector on the page
         * instead of a free text box; the constraint stays as the human-readable rule.
         */
        enum?: string[];
        /**
         * User-language labels for `enum` codes. OPTIONAL on the type so L4 written before this field keeps
         * compiling — nothing is ever migrated. New E4 runs backfill any gap with a humanized code and a
         * non-blocking systemDecision; the model should still author the user's language.
         */
        enumLabels?: Ns4EnumLabel[];
    }
    export interface Ns4LifecyclePredicate {
        predicateId: string;
        description: string;
        stateIds: string[];
        source: Ns4ConstraintSource;
    }
    /** How a lifecycle state is reached. A gate reads this without an LLM. */
    export type Ns4LifecycleReachedBy = 'actor' | 'command' | 'time';
    /**
     * One lifecycle state of an entity. A bare string in authored JSON is `reachedBy: 'actor'`.
     * `time` is computed on read and is never a workflow transition; it requires `ruleRef`.
     */
    export interface Ns4LifecycleState {
        state: string;
        reachedBy: Ns4LifecycleReachedBy;
        ruleRef?: string;
    }
    export interface Ns4OntologyEntity {
        entityId: string;
        title: string;
        description: string;
        kind: Ns4EntityKind;
        ownership: Ns4EntityOwnership;
        /**
         * A core entity with one fixed instance (a petition, an institutional page). OPTIONAL so L4
         * written before this field keeps compiling. E8 skips the record catalogue when it is present.
         */
        cardinality?: 'singleton';
        /**
         * Whether records of this entity may be corrected or removed after they exist. OPTIONAL so L4
         * written before this field keeps compiling — nothing is ever migrated; absent = editable.
         * `appendOnly` is a fact, a posting, a meter reading, a signature: E8 emits no update/delete.
         */
        mutability?: 'editable' | 'appendOnly';
        /**
         * Required by the gate for everything this generator now produces; OPTIONAL in the type so the L4
         * artifacts written before it (schema v6, no `party`) keep compiling — nothing is ever migrated.
         */
        party?: Ns4EntityParty;
        /**
         * Required by the gate when `kind === 'projection'` and `ownership === 'derived'`; OPTIONAL in the
         * type so L4 written before this field keeps compiling — nothing is ever migrated.
         */
        derivation?: Ns4EntityDerivation;
        /**
         * Required by the gate when `kind === 'mdm'`; OPTIONAL in the type so L4 written before this field
         * (schema v6) keeps compiling — nothing is ever migrated.
         */
        mdmSubtype?: Ns4Level1Subtype;
        /**
         * Module role tag `<moduleName>.<EntityId>`. Derived by the generator; not authored by the model.
         * OPTIONAL so L4 written before this field keeps compiling.
         */
        role?: string;
        /**
         * The field a person reads to recognise the record. A fieldId of this entity, or of the level-1
         * subtype when `kind === 'mdm'`. OPTIONAL in the type so v6 L4 keeps compiling; the gate requires it.
         */
        displayField?: string;
        sourceRefs: {
            journeyIds: string[];
            featureIds: string[];
            authorityRefs: string[];
        };
        fields: Ns4OntologyField[];
        lifecycleStates: Ns4LifecycleState[];
        /** The lifecycle values as a literal union; mirrors lifecycleStates and is never a second truth. */
        statusEnum?: string[];
        /** User-language labels for `lifecycleStates`. OPTIONAL on the type; new E4 runs backfill a gap. */
        lifecycleLabels?: Ns4EnumLabel[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates: Ns4LifecyclePredicate[];
        useRules: string[];
        storage: {
            target: Ns4StorageTarget;
            scope: Ns4StorageScope;
            idField?: string;
            mdmType?: string;
            notes: string;
        };
    }
    export interface Ns4OntologyRelationship {
        relationshipId: string;
        fromEntity: string;
        toEntity: string;
        type: 'oneToOne' | 'oneToMany' | 'manyToOne' | 'manyToMany';
        required: boolean;
        description: string;
        persistence: {
            mode: Ns4RelationshipPersistenceMode;
        };
        /** Absent only in the compact overview; mandatory before review and permanent emission. */
        realization?: Ns4RelationshipRealization;
    }
    export type Ns4ResolvedOntologyRelationship = Ns4OntologyRelationship & {
        realization: Ns4RelationshipRealization;
    };
    export type Ns4OntologyEntityPlan = Omit<Ns4OntologyEntity, 'fields' | 'useRules'>;
    export interface Ns4E4PlanDraft {
        planId: 'e4-ontology-plan';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntityPlan[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
    }
    export interface Ns4E4EntityDraft {
        planId: 'e4-ontology-entity';
        moduleName: string;
        reviewRound: number;
        entityId: string;
        fields: Ns4OntologyField[];
        useRules: string[];
        /** Field ids the model proposes for the organization `general` layer. Not stored on the entity. */
        promoteToGeneral?: string[];
    }
    export interface Ns4E4RelationshipBinding {
        relationshipId: string;
        realization: Ns4RelationshipRealization;
    }
    export interface Ns4E4RelationshipBindingsDraft {
        planId: 'e4-relationship-bindings';
        moduleName: string;
        reviewRound: number;
        bindings: Ns4E4RelationshipBinding[];
    }
    export interface Ns4E4DerivationBinding {
        entityId: string;
        derivation: Ns4EntityDerivation;
    }
    export interface Ns4E4DerivationBindingsDraft {
        planId: 'e4-derivation-bindings';
        moduleName: string;
        reviewRound: number;
        bindings: Ns4E4DerivationBinding[];
        changeSummary?: string[];
    }
    export interface Ns4E4DerivationBindingIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E4DerivationFieldIdChange {
        entityId: string;
        before: string[];
        after: string[];
    }
    /** Binding-gate finding that the entity fan-out must repair — travels as a typed payload, not a loose string. */
    export interface Ns4E4EntityFeedback {
        entityId: string;
        feedback: string;
    }
    export interface Ns4E4Review {
        planId: 'e4-ontology-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntity[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
        /** Type C label backfills and Type B registrars such as NS4_E4_CORE_READ_ONLY. */
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4E4ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E4Review;
    }
    export interface Ns4OntologyEntityArtifactV5 extends Ns4OntologyEntity {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
    }
    /** Compile-only compatibility for L4 written against ontology v6. Nothing is migrated. */
    export interface Ns4OntologyEntityArtifactV6 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion'> {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION_V6;
    }
    /** Compile-only compatibility for already generated v3 L4 artifacts. */
    export interface Ns4OntologyEntityArtifactV4 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion'> {
        schemaVersion: '2026-08-09-ns4-ontology-v4';
    }
    export interface Ns4OntologyEntityArtifactV3 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion' | 'useRules'> {
        schemaVersion: '2026-08-08-ns4-ontology-v3';
        invariants: Array<{
            invariantId: string;
            description: string;
            source: Ns4ConstraintSource;
        }>;
    }
    export type Ns4OntologyEntityArtifact = Ns4OntologyEntityArtifactV5 | Ns4OntologyEntityArtifactV6 | Ns4OntologyEntityArtifactV4 | Ns4OntologyEntityArtifactV3;
    interface Ns4OntologyIndexArtifactBase {
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        title: string;
        businessDomain: string;
        entities: Array<{
            entityId: string;
            title: string;
            kind: Ns4EntityKind;
            storage: Pick<Ns4OntologyEntity['storage'], 'target' | 'scope' | 'idField' | 'mdmType'>;
            definitionRef: string;
        }>;
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromOntologyHash: string;
        };
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4OntologyIndexArtifactV5 extends Ns4OntologyIndexArtifactBase {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        relationships: Ns4ResolvedOntologyRelationship[];
    }
    /** Compile-only compatibility for L4 written against ontology v6. Nothing is migrated. */
    export interface Ns4OntologyIndexArtifactV6 extends Omit<Ns4OntologyIndexArtifactV5, 'schemaVersion'> {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION_V6;
    }
    /** Compile-only compatibility for already generated v3/v4 L4 artifacts. */
    export interface Ns4OntologyIndexArtifactLegacy extends Ns4OntologyIndexArtifactBase {
        schemaVersion: '2026-08-09-ns4-ontology-v4' | '2026-08-08-ns4-ontology-v3';
        relationships: Ns4OntologyRelationship[];
    }
    export type Ns4OntologyIndexArtifact = Ns4OntologyIndexArtifactV5 | Ns4OntologyIndexArtifactV6 | Ns4OntologyIndexArtifactLegacy;
    export function normalizeNs4E4Review(value: unknown, fallbackModule?: string): Ns4E4Review;
    /** `inProgress` → `In progress`. Fallback when the model omitted a user-language label. */
    export function humanizeNs4EnumCode(code: string): string;
    export function normalizeNs4E4PlanDraft(value: unknown, fallbackModule?: string): Ns4E4PlanDraft;
    export function normalizeNs4E4EntityDraft(value: unknown, moduleName: string, reviewRound: number, entityId: string): Ns4E4EntityDraft;
    /**
     * Removes the derived literal union from fields before they are echoed back to an entity worker.
     * The union is a projection E4 adds for the consumers; the worker's strict tool schema forbids the
     * key, so showing it in a prompt would invite an invalid repair answer.
     */
    export function stripNs4DerivedFieldUnions<T extends {
        fields?: unknown;
    }>(value: T): T;
    export function stripNs4DerivedFieldUnions(value: Ns4OntologyField[]): Ns4OntologyField[];
    export function assembleNs4E4Review(plan: Ns4E4PlanDraft, details: Ns4E4EntityDraft[]): Ns4E4Review;
    export function normalizeNs4E4RelationshipBindings(value: unknown, moduleName: string, reviewRound: number): Ns4E4RelationshipBindingsDraft;
    export function applyNs4E4RelationshipBindings(review: Ns4E4Review, draft: Ns4E4RelationshipBindingsDraft): Ns4E4Review;
    export function normalizeNs4E4DerivationBindings(value: unknown, moduleName: string, reviewRound: number): Ns4E4DerivationBindingsDraft;
    export function applyNs4E4DerivationBindings(plan: Ns4E4PlanDraft, payload: unknown): {
        plan: Ns4E4PlanDraft;
        issues: Ns4E4DerivationBindingIssue[];
        fieldIdChanges: Ns4E4DerivationFieldIdChange[];
    };
    export function buildNs4OntologyArtifacts(review: Ns4E4Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<{
        entities: Ns4OntologyEntityArtifactV5[];
        index: Ns4OntologyIndexArtifactV5;
    }>;
    export function normalizeDerivation(value: unknown): Ns4EntityDerivation | undefined;
    /** Bare string = `actor`. After normalize, every entity carries objects. */
    export function normalizeLifecycleStates(value: unknown): Ns4LifecycleState[];
    export function lifecycleStateIds(states: ReadonlyArray<string | Ns4LifecycleState>): string[];
    export function hasLifecycleState(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): boolean;
    export function lifecycleReachedBy(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): Ns4LifecycleReachedBy;
    export function lifecycleRuleRef(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): string;
    export function isTimeLifecycleState(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): boolean;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4EntityFields" {
    /**
     * Fields an NS artifact may name on an entity: declared `fields[]` plus the logical identity
     * `storage.idField` when that id is absent from the list (mdm after n04 is namespace-only).
     * Structural: never inferred from a field name.
     */
    import type { Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export const NS4_IDENTITY_FIELD_DESCRIPTION = "Logical record identity. Required uuid named by storage.idField.";
    export type Ns4EntityFieldsSource = {
        entityId?: string;
        kind?: string;
        fields?: ReadonlyArray<{
            fieldId: string;
            type?: Ns4OntologyField['type'];
            required?: boolean;
            description?: string;
            title?: string;
            constraints?: Ns4OntologyField['constraints'];
            enum?: string[];
            enumLabels?: Ns4OntologyField['enumLabels'];
        }>;
        storage?: {
            idField?: string;
        } | null;
    };
    export function ns4EntityIdField(entity: Ns4EntityFieldsSource | undefined | null): string;
    export function ns4ResolvableFields(entity: Ns4EntityFieldsSource | undefined | null): Ns4OntologyField[];
    export function ns4ResolvableFieldIds(entity: Ns4EntityFieldsSource | undefined | null): Set<string>;
    export function ns4ResolvableFieldOf(entity: Ns4EntityFieldsSource | undefined | null, fieldId: string): Ns4OntologyField | undefined;
    /** Compact entity payload for the E4 relationship-binding prompt: exact available fields. */
    export function ns4BindingPromptEntity(entity: Ns4EntityFieldsSource & {
        entityId: string;
    }): {
        entityId: string;
        kind?: string;
        storage: Ns4EntityFieldsSource['storage'];
        fields: Array<{
            fieldId: string;
            type: Ns4OntologyField['type'];
            required: boolean;
            description: string;
        }>;
    };
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Context" {
    export type Ns4ContextStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export interface Ns4DerivedContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        idFieldRef?: string;
    }
    export interface Ns4DerivedStepContexts {
        journeyId: string;
        stepId: string;
        stepRef: string;
        kind: Ns4ContextStepKind;
        entity: string;
        /** True when the step introduces its own entity instead of operating on an existing record. */
        creates: boolean;
        requires: Ns4DerivedContext[];
        provides: Ns4DerivedContext[];
    }
    export interface Ns4DerivedContextGraph {
        catalog: Ns4DerivedContext[];
        steps: Ns4DerivedStepContexts[];
        byStepRef: Map<string, Ns4DerivedStepContexts>;
        entryByJourneyId: Map<string, Ns4DerivedContext[]>;
    }
    export interface Ns4ContextJourneyStep {
        stepId: string;
        kind: Ns4ContextStepKind;
        entity: string;
        affects?: string[];
        targetProfile?: string;
    }
    export interface Ns4ContextJourney {
        journeyId: string;
        business: {
            actorRef: string;
            entry: {
                mode: string;
                preferredFromJourneyRef?: string;
            };
            steps: Ns4ContextJourneyStep[];
        };
    }
    export interface Ns4ContextEntity {
        entityId: string;
        ownership?: string;
        storage?: {
            target?: string;
            scope?: string;
            idField?: string;
        };
        fields?: Array<{
            fieldId: string;
        }>;
    }
    export interface Ns4ContextRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
    }
    export interface Ns4ContextSources {
        journeys: {
            journeys: Ns4ContextJourney[];
        };
        ontology: {
            entities: Ns4ContextEntity[];
            relationships: Ns4ContextRelationship[];
        };
        access?: {
            profiles: Array<{
                profileId: string;
                actorRefs: string[];
            }>;
        };
    }
    /** A context id is a pure function of its entity, so the catalog and the E9 store are entity-keyed. */
    export function ns4ContextIdOf(entity: string): string;
    /**
     * Inspect of entity X that still has no selected X, while a later step locates X, is a collection
     * summary (counts of the listing) — not getById of one record. Identity-free by construction.
     */
    export function isNs4CollectionInspect(steps: ReadonlyArray<{
        kind: string;
        entity: string;
    }>, index: number): boolean;
    /**
     * Platform-owned records are supplied by the runtime session, never selected by the user, so they
     * are not a coordination requirement of a business step.
     */
    export function isNs4PlatformOwnedEntity(entity: Ns4ContextEntity): boolean;
    export function deriveNs4Contexts(sources: Ns4ContextSources): Ns4DerivedContextGraph;
    /** Business objects the ontology must realize: exactly the entities the journeys operate on. */
    export function collectNs4JourneyEntities(journeys: {
        journeys: Ns4ContextJourney[];
    }): string[];
}
declare module "_102035_/l2/agentNewSolution/steps/e2/coverageSignals" {
    export const NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL: "moduleWithoutDecide";
    export const NS4_E2_JOURNEY_WITHOUT_PROCESS_SIGNAL: "journeyWithoutProcess";
    export interface Ns4E2StepKindHistogram {
        locate: number;
        inspect: number;
        act: number;
        decide: number;
        handoff: number;
    }
    export type Ns4E2MechanicalFindingSeverity = 'registrar';
    export interface Ns4E2MechanicalCoverageFinding {
        signalId: typeof NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL;
        severity: Ns4E2MechanicalFindingSeverity;
    }
    export interface Ns4E2MechanicalCoverageReport {
        stepKindHistogram: Ns4E2StepKindHistogram;
        findings: Ns4E2MechanicalCoverageFinding[];
        /** Journeys that carry no process: pure capture or maintenance of one record catalogue. */
        captureOnlyJourneys: Array<{
            journeyId: string;
            entity: string;
        }>;
    }
    interface Ns4E2StepSource {
        journeys: Array<{
            journeyId?: unknown;
            business: {
                steps: Array<{
                    kind: unknown;
                    entity?: unknown;
                    affects?: unknown;
                }>;
            };
        }>;
    }
    export function analyzeNs4E2MechanicalCoverage(source: Ns4E2StepSource): Ns4E2MechanicalCoverageReport;
    /**
     * A journey with no decision, no handoff and one single entity is the record catalogue of that
     * entity written as a flow. Tier 1 already owns that screen, so the module records the demotion as
     * a visible product choice instead of shipping the same catalogue twice.
     */
    export function ns4E2DemotionDecisionId(journeyId: string): string;
    export function isNs4E2DemotionDecisionId(decisionId: string): boolean;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/contracts" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import { type Ns4DerivedContext } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { Ns4E2StepKindHistogram } from "_102035_/l2/agentNewSolution/steps/e2/coverageSignals";
    export const NS4_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-v5";
    export const NS4_JOURNEY_INDEX_SCHEMA_VERSION: "2026-08-15-ns4-journey-index-v7";
    export const NS4_REALIZED_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-realized-v5";
    export const NS4_E2_IMPACT_REPORT_SCHEMA_VERSION: "2026-08-13-ns4-e2-impact-report-v2";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_14_ns4_journey_v5: string[];
    export const TEXT_PATHS_2026_08_14_ns4_journey_realized_v5: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_v3: string[];
    export const TEXT_PATHS_2026_08_09_ns4_journey_v2: string[];
    export const TEXT_PATHS_2026_08_04_ns4_journey_v1: string[];
    export const TEXT_PATHS_2026_08_15_ns4_journey_index_v7: string[];
    export const TEXT_PATHS_2026_08_14_ns4_journey_index_v6: string[];
    export const TEXT_PATHS_2026_08_12_ns4_journey_index_v5: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_index_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_index_v3: string[];
    export const TEXT_PATHS_2026_08_09_ns4_journey_index_v2: string[];
    export const TEXT_PATHS_2026_08_04_ns4_journey_index_v1: string[];
    export type Ns4JourneyEntryMode = 'coldStart' | 'contextRequired' | 'contextOrLookup' | 'eventDriven';
    export type Ns4JourneyStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export type Ns4FeaturePriority = 'now' | 'next' | 'later';
    /**
     * A step names what it does and to which business record. Everything about context — who provides
     * it, what it carries, how many — is derived by helpers/ns4Context.ts from this entity, the step
     * kind, the journey sequence and the approved ontology.
     */
    export interface Ns4JourneyStep {
        stepId: string;
        kind: Ns4JourneyStepKind;
        entity: string;
        /**
         * Other business objects this act also changes. Same vocabulary as `entity`
         * (PascalCase ids, no fields, no transition). Absent when the step records only `entity`.
         */
        affects?: string[];
        title: string;
        description: string;
        featureRefs: string[];
        /** Only a handoff names the receiving E3 profile; it is the routing fact E9 compiles. */
        targetProfile?: string;
    }
    export interface Ns4JourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
        };
        steps: Ns4JourneyStep[];
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    /** Frozen shape of journeys written by flow versions before the context graph became derived. */
    export interface Ns4LegacyJourneyContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        description: string;
        stateRequirement?: string;
    }
    export interface Ns4LegacyJourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        prerequisites: Array<{
            journeyRef: string;
            reason: string;
            required: boolean;
            providesContext: string[];
        }>;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
            carries: Ns4LegacyJourneyContext[];
        };
        steps: Array<{
            stepId: string;
            kind: Ns4JourneyStepKind;
            intent: string;
            requiresContext: string[];
            providesContext: Ns4LegacyJourneyContext[];
            result: string;
            featureRefs: string[];
        }>;
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    export interface Ns4JourneyProposal {
        journeyId: string;
        business: Ns4JourneyBusiness;
        policyDecisions: Ns4PolicyDecision[];
    }
    /** A product choice made while generating a journey, before any human review. */
    export interface Ns4PolicyDecision {
        decisionId: string;
        question: string;
        chosen: string;
        alternatives: string[];
        /** Only the independent E2 judge may add this explanation. */
        impact?: string;
        relatedJourneyIds?: string[];
    }
    /** Durable audit record of the choice the reviewer approved. */
    export interface Ns4PolicyDecisionSelection {
        decisionId: string;
        generatedChoice: string;
        selectedChoice: string;
        selectedBy: 'human' | 'auto';
        selectedAt: string;
    }
    export interface Ns4E2Feature {
        featureId: string;
        title: string;
        priority: Ns4FeaturePriority;
        journeyStepRefs: string[];
    }
    export interface Ns4E2Review {
        planId: 'e2-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        journeys: Ns4JourneyProposal[];
        features: Ns4E2Feature[];
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4JourneyArtifactV5 extends Ns4JourneyProposal {
        schemaVersion: typeof NS4_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'pending';
            contexts: Record<string, never>;
        };
        realization: {
            status: 'pending';
            compiledFromBusinessHash: string;
            steps: never[];
            transitionRefs: never[];
        };
    }
    /** The derived context, plus the structural provenance E7 records for the compiled journey. */
    export interface Ns4JourneyResolvedContext extends Ns4DerivedContext {
        sourceRefs: string[];
        consumerStepRefs: string[];
    }
    export interface Ns4JourneyStepRealization {
        stepId: string;
        useCaseRefs: string[];
    }
    export interface Ns4JourneyArtifactV5Realized extends Omit<Ns4JourneyProposal, 'policyDecisions'> {
        schemaVersion: typeof NS4_REALIZED_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'compiled';
            contexts: Record<string, Ns4JourneyResolvedContext>;
        };
        realization: {
            status: 'compiled';
            compiledFromBusinessHash: string;
            steps: Ns4JourneyStepRealization[];
            transitionRefs: string[];
            realizationHash: string;
        };
    }
    /**
     * Compile-only compatibility for permanent artifacts written by previous flow versions. They are
     * never resumed or migrated; the union only keeps already-generated L4 modules type-safe.
     */
    export interface Ns4LegacyJourneyArtifact {
        schemaVersion: '2026-08-04-ns4-journey-v1' | '2026-08-09-ns4-journey-v2' | '2026-08-10-ns4-journey-v3' | '2026-08-10-ns4-journey-v4';
        journeyId: string;
        revision: number;
        business: Ns4LegacyJourneyBusiness | (Omit<Ns4LegacyJourneyBusiness, 'useRules'> & {
            businessRules: Array<{
                journeyRuleId: string;
                statement: string;
            }>;
        });
        policyDecisions?: Ns4PolicyDecision[];
        businessHash: string;
        resolution: {
            status: 'pending' | 'compiled';
            contexts: Record<string, unknown>;
        };
        realization: {
            status: 'pending' | 'compiled';
            compiledFromBusinessHash: string;
            steps: Array<{
                stepId: string;
                useCaseRefs: string[];
            }>;
            transitionRefs: string[];
            realizationHash?: string;
        };
    }
    export type Ns4JourneyArtifact = Ns4JourneyArtifactV5 | Ns4JourneyArtifactV5Realized | Ns4LegacyJourneyArtifact;
    /** A journey written by a previous flow version still declares its context graph; it is never compiled. */
    export function isNs4CurrentJourneyBusiness(value: Ns4JourneyArtifact['business']): value is Ns4JourneyBusiness;
    export interface Ns4JourneyIndex {
        schemaVersion: typeof NS4_JOURNEY_INDEX_SCHEMA_VERSION | '2026-08-14-ns4-journey-index-v6' | '2026-08-12-ns4-journey-index-v5' | '2026-08-10-ns4-journey-index-v4' | '2026-08-04-ns4-journey-index-v1' | '2026-08-10-ns4-journey-index-v3' | '2026-08-09-ns4-journey-index-v2';
        moduleName: string;
        approvedAt: string;
        approvedBy: 'human' | 'auto';
        journeys: Array<{
            journeyId: string;
            actorRef: string;
            title: string;
            goal: string;
            entryMode: Ns4JourneyEntryMode;
            businessHash: string;
            artifactPath: string;
            useCaseRefs?: string[];
        }>;
        features: Ns4E2Feature[];
        /**
         * The decisions themselves, next to the selections that answer them. This is their durable home:
         * the journey artifact carries a copy while E2 is still reviewing, and E7 rewrites the artifact as
         * realized-v5, which has no policyDecisions — everything read after E7 reads the index.
         */
        policyDecisions?: Ns4JourneyIndexPolicyDecision[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        systemDecisions?: Ns4SystemDecision[];
        realizationHash?: string;
    }
    /** A policy decision with the journey that owns it; the index is flat, journeys reference by id. */
    export interface Ns4JourneyIndexPolicyDecision extends Ns4PolicyDecision {
        journeyRef: string;
    }
    export interface Ns4E2ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E2Review;
        policyDecisionSelections: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>;
    }
    export interface Ns4E2ImpactReport {
        schemaVersion: typeof NS4_E2_IMPACT_REPORT_SCHEMA_VERSION;
        moduleName: string;
        generatedAt: string;
        stepKindHistogram: Ns4E2StepKindHistogram;
        changes: Array<{
            journeyId: string;
            reason: 'hashDivergent' | 'journeyNew' | 'journeyRemoved';
        }>;
        affectedSteps: Array<'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e7-realization'>;
    }
    export function normalizeNs4E2Review(value: unknown, fallbackModule?: string, presentation?: Ns4Presentation): Ns4E2Review;
    export function buildNs4JourneyArtifacts(review: Ns4E2Review): Promise<Ns4JourneyArtifactV5[]>;
    export function buildNs4JourneyIndex(moduleName: string, review: Ns4E2Review, artifacts: Ns4JourneyArtifactV5[], artifactPaths: string[], approvedBy: 'human' | 'auto', approvedAt: string, policyDecisionSelections?: Ns4PolicyDecisionSelection[]): Ns4JourneyIndex;
    export function buildNs4PolicyDecisionSelections(review: Ns4E2Review, selectedChoices: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>, selectedBy: 'human' | 'auto', selectedAt: string): Ns4PolicyDecisionSelection[];
    export function buildNs4E2ImpactReport(moduleName: string, previousIndex: Ns4JourneyIndex | null, artifacts: Array<Pick<Ns4JourneyArtifactV5, 'journeyId' | 'businessHash'>>, generatedAt: string, review: Pick<Ns4E2Review, 'journeys'>): Ns4E2ImpactReport;
    export function sha256Ns4(value: unknown): Promise<string>;
    export function stableNs4Stringify(value: unknown): string;
    /**
     * Turns a human-spaced or already technical business noun into the stable PascalCase id shared by
     * journeys and ontology entities. The transformation is intentionally lexical: it never translates
     * or substitutes a domain noun.
     */
    export function normalizeNs4BusinessObjectId(value: unknown): string;
    /**
     * A journey with no decision, no handoff and one single entity IS the record catalogue of that
     * entity. Tier 1 already owns that screen, so the module records the demotion as a visible product
     * choice at the E2 checkpoint instead of shipping the same catalogue twice. The decision is
     * deterministic: it is recomputed on every round and is never authored by the generator.
     */
    export function withNs4DemotionDecisions(journeys: Ns4JourneyProposal[], presentation?: Ns4Presentation): Ns4JourneyProposal[];
    /** The journeys the approved review demoted to the tier 1 record catalogue of their entity. */
    export function collectNs4DemotedJourneyIds(review: Pick<Ns4E2Review, 'journeys'>, selections?: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>): string[];
    /** Business objects that later ontology compilation must realize as entities or projections. */
    export function collectNs4RequiredJourneyBusinessObjects(review: Ns4E2Review): string[];
}
declare module "_102035_/l2/agentNewSolution/steps/e3/contracts" {
    export const NS4_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-09-ns4-access-matrix-v2";
    export const NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-10-ns4-access-matrix-v3";
    export const NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-13-ns4-access-matrix-v4";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_09_ns4_access_matrix_v2: string[];
    export const TEXT_PATHS_2026_08_10_ns4_access_matrix_v3: string[];
    export const TEXT_PATHS_2026_08_13_ns4_access_matrix_v4: string[];
    export const TEXT_PATHS_2026_08_05_ns4_access_matrix_v1: string[];
    export type Ns4AccessProfileKind = 'internal' | 'external';
    export type Ns4AccessScopeMode = 'organization' | 'assigned' | 'own' | 'related' | 'public' | 'custom';
    export type Ns4DisclosureMode = 'fullRecord' | 'summaryOnly' | 'fieldsOnly' | 'aggregateOnly';
    export interface Ns4AccessProfile {
        profileId: string;
        title: string;
        kind: Ns4AccessProfileKind;
        description: string;
        actorRefs: string[];
        landingIntent: string;
    }
    export interface Ns4AccessAuthority {
        authorityRef: string;
        title: string;
        description: string;
        journeyStepRefs: string[];
        informationNeeds: string[];
    }
    export interface Ns4AccessGrant {
        profileRef: string;
        authorityRef: string;
        reason: string;
        dataScope: {
            mode: Ns4AccessScopeMode;
            description: string;
        };
        disclosure: {
            mode: Ns4DisclosureMode;
            description: string;
            allowedInformation: string[];
            deniedInformation: string[];
        };
        useRules: string[];
    }
    export interface Ns4E3Review {
        planId: 'e3-access-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        changeSummary: string[];
    }
    export interface Ns4E3ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E3Review;
    }
    export interface Ns4AccessMatrixArtifactV2 {
        schemaVersion: typeof NS4_ACCESS_MATRIX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        accessHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromAccessHash: string;
            operationAuthorityRefs: never[];
        };
    }
    export interface Ns4AccessUseCaseAuthorityRef {
        useCaseId: string;
        authorityRef: string;
        journeyStepRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV3 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'useCasesCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            realizationHash: string;
        };
    }
    export interface Ns4AccessOperationAuthorityRef {
        operationRef: string;
        route: string;
        workspaceId: string;
        functionId: string;
        useCaseId?: string;
        authorityRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV4 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'navigationCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            operationAuthorityRefs: Ns4AccessOperationAuthorityRef[];
            realizationHash: string;
        };
    }
    /** Compile-only compatibility for already generated v1 L4 artifacts. */
    export interface Ns4AccessMatrixArtifactV1 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'grants'> {
        schemaVersion: '2026-08-05-ns4-access-matrix-v1';
        grants: Array<Omit<Ns4AccessGrant, 'useRules'> & {
            constraints: string[];
        }>;
    }
    export type Ns4AccessMatrixArtifact = Ns4AccessMatrixArtifactV4 | Ns4AccessMatrixArtifactV3 | Ns4AccessMatrixArtifactV2 | Ns4AccessMatrixArtifactV1;
    export function normalizeNs4E3Review(value: unknown, fallbackModule?: string): Ns4E3Review;
    export function buildNs4AccessMatrixArtifact(review: Ns4E3Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4AccessMatrixArtifactV2>;
}
declare module "_102035_/l2/agentNewSolution/steps/e4b/contracts" {
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessGrant, Ns4AccessScopeMode, Ns4DisclosureMode, Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4DerivationAggregate, Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export const NS4_ACCESS_BINDINGS_SCHEMA_VERSION: "2026-09-08-ns4-access-bindings-v1";
    export const NS4_PERSON_LOGIN_FIELD: "platformUserId";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_09_08_ns4_access_bindings_v1: string[];
    export const NS4_SYNTH_AUTHORITY_PREFIX: "synth:";
    export const NS4_LIMITED_DISCLOSURE_MODES: readonly Ns4DisclosureMode[];
    export type Ns4AnchorDirection = 'forward' | 'incoming';
    export interface Ns4AccessAnchorHop {
        entityRef: string;
        fieldId: string;
        targetEntityRef: string;
        direction: Ns4AnchorDirection;
    }
    export interface Ns4AccessAnchor {
        hops: Ns4AccessAnchorHop[];
        terminus: {
            entityRef: string;
            fieldId: typeof NS4_PERSON_LOGIN_FIELD;
        };
    }
    export interface Ns4AccessBinding {
        profileRef: string;
        authorityRef: string;
        entityRef: string;
        dataScope: {
            mode: Ns4AccessScopeMode;
            description: string;
        };
        disclosure: {
            mode: Ns4DisclosureMode;
            description: string;
            allowedInformation: string[];
            deniedInformation: string[];
        };
        anchor: Ns4AccessAnchor | null;
        /** Present when `anchor` is null: organization / custom / public have no person path. */
        anchorReason?: string;
        /**
         * Machine artifact (E4B): entityId of the disclosure projection for a limited external grant.
         * Not a field on the human grant.
         */
        projectionRef?: string;
        /**
         * Machine artifact (E4B): field ids the model excluded from the disclosure view, for a human to read.
         * Not a field on the human grant.
         */
        excludedFields?: string[];
    }
    export interface Ns4SynthesizedAuthority {
        authorityRef: string;
        entityRef: string;
        profileRef: string;
        dataScope: Ns4AccessBinding['dataScope'];
        disclosure: Ns4AccessBinding['disclosure'];
        sourceGrant: {
            profileRef: string;
            authorityRef: string;
        };
        anchor: Ns4AccessAnchor | null;
    }
    export interface Ns4AccessBindingsArtifact {
        schemaVersion: typeof NS4_ACCESS_BINDINGS_SCHEMA_VERSION;
        moduleName: string;
        compiledFromAccessHash: string;
        compiledFromOntologyHash: string;
        bindings: Ns4AccessBinding[];
        synthesizedAuthorities: Ns4SynthesizedAuthority[];
        bindingsHash: string;
    }
    export interface Ns4E4BProjectionProposal {
        fields: string[];
        excludedFields: string[];
        /** aggregateOnly: derivation ops. Absent for a field-subset view (`op: first` per field). */
        aggregate?: Ns4DerivationAggregate[];
    }
    export interface Ns4E4BProposal {
        profileRef: string;
        authorityRef: string;
        entityRef: string;
        hops: Ns4AccessAnchorHop[];
        /** The model names a field the ontology does not have; the gate turns this into a finding. */
        missingField?: {
            entityRef: string;
            fieldId: string;
        };
        /** Disclosure view extracted from grant prose. Machine artifact, not a human grant field. */
        projection?: Ns4E4BProjectionProposal;
    }
    export interface Ns4E4BSources {
        moduleName: string;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        journeys: Ns4E2Review;
        accessHash: string;
        ontologyHash: string;
        /** Optional: E5 has not run yet on a first pass; present on resume/rebuild. */
        rules?: Array<{
            id: string;
            description: string;
        }>;
    }
    export interface Ns4E4BFinding {
        code: string;
        path: string;
        message: string;
        repairStep?: 'e4-ontology' | 'e4b-access-realization';
    }
    export interface Ns4E4BCompileResult {
        artifact: Ns4AccessBindingsArtifact;
        /** Disclosure views to persist as `ontology/<Entity><Profile>View.defs.ts`. Not added to the E4 index. */
        projections: Ns4OntologyEntity[];
        findings: Ns4E4BFinding[];
    }
    export function ns4SynthesizedAuthorityRef(entityRef: string, profileRef: string): string;
    export function ns4DisclosureProjectionId(entityRef: string, profileRef: string): string;
    export function ns4NeedsDisclosureProjection(grant: Ns4AccessGrant, profileKind: string | undefined): boolean;
    export function ns4GrantCoversEntity(grant: Ns4AccessGrant, entityRef: string, access: Pick<Ns4E3Review, 'authorities'>, journeys: Pick<Ns4E2Review, 'journeys'>): boolean;
    export function ns4EntityIdsCoveredByGrant(grant: Ns4AccessGrant, access: Pick<Ns4E3Review, 'authorities'>, journeys: Pick<Ns4E2Review, 'journeys'>): string[];
    /** Catalogue audience: profiles with an organization-scope grant covering the entity. */
    export function ns4CatalogueProfileIds(entityRef: string, access: Pick<Ns4E3Review, 'grants' | 'authorities'>, journeys: Pick<Ns4E2Review, 'journeys'>): string[];
    export function ns4JourneyAuthorityRefs(compiledFrom: string[], access: Pick<Ns4E3Review, 'authorities'>): string[];
    export function compileNs4AccessBindings(sources: Ns4E4BSources, proposals?: Ns4E4BProposal[]): Promise<Ns4E4BCompileResult>;
    export function isPersonEntity(entity: Ns4OntologyEntity): boolean;
    export interface Ns4AccessFieldEdge {
        entityRef: string;
        fieldId: string;
        targetEntityRef: string;
        direction: Ns4AnchorDirection;
    }
    export function ns4AccessFieldGraph(ontology: Pick<Ns4E4Review, 'relationships'>): Ns4AccessFieldEdge[];
    export function checkAnchorPath(hops: Ns4AccessAnchorHop[], startEntity: string, graph: Ns4AccessFieldEdge[], personEntities: Set<string>, path: string): {
        anchor?: Ns4AccessAnchor;
        finding?: Ns4E4BFinding;
    };
    export function missingFieldFinding(path: string, entityRef: string, fieldId: string): Ns4E4BFinding;
}
declare module "_102035_/l2/agentNewSolution/steps/e5/contracts" {
    export const NS4_RULES_SCHEMA_VERSION: "2026-08-09-ns4-rules-v2";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_09_ns4_rules_v2: string[];
    /** The permanent business-rule contract. Meaning lives here; consumers keep only the id. */
    export interface Ns4RuleDefinition {
        id: string;
        description: string;
    }
    export interface Ns4E5Review {
        planId: 'e5-rules-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        rules: Ns4RuleDefinition[];
        changeSummary: string[];
    }
    export interface Ns4E5ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E5Review;
    }
    export interface Ns4RulesArtifact {
        schemaVersion: typeof NS4_RULES_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        rules: Ns4RuleDefinition[];
        rulesHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromRulesHash: string;
        };
    }
    export function normalizeNs4E5Review(value: unknown, fallbackModule?: string): Ns4E5Review;
    export function buildNs4RulesArtifact(review: Ns4E5Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4RulesArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e6/contracts" {
    export const NS4_COMPOSITION_SCHEMA_VERSION: "2026-08-09-ns4-composition-v1";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_09_ns4_composition_v1: string[];
    export type Ns4AdditionalCapabilityKind = 'horizontalModule' | 'plugin';
    export type Ns4AdditionalCapabilityDecision = 'include' | 'defer';
    export interface Ns4AdditionalCapability {
        id: string;
        kind: Ns4AdditionalCapabilityKind;
        title: string;
        purpose: string;
        decision: Ns4AdditionalCapabilityDecision;
        /** True when the capability is already realized by a sibling module (reuse, never a new module). */
        existing?: boolean;
    }
    export interface Ns4E6Review {
        planId: 'e6-composition-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        changeSummary: string[];
    }
    export interface Ns4E6ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E6Review;
    }
    export interface Ns4CompositionArtifact {
        schemaVersion: typeof NS4_COMPOSITION_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        compositionHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromCompositionHash: string;
        };
    }
    export function normalizeNs4E6Review(value: unknown, fallbackModule?: string): Ns4E6Review;
    export function buildNs4CompositionArtifact(review: Ns4E6Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4CompositionArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/contracts" {
    import type { Ns4E2Review, Ns4JourneyArtifact, Ns4JourneyArtifactV5Realized, Ns4JourneyIndex } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact, Ns4AccessMatrixArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import { type Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4DerivedContextGraph } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_USE_CASE_DRAFT_VERSION: "2026-09-09-ns4-usecase-draft-v4";
    export const NS4_USE_CASE_SCHEMA_VERSION: "2026-09-09-ns4-usecase-v4";
    export const NS4_USE_CASE_INDEX_SCHEMA_VERSION: "2026-09-09-ns4-usecase-index-v4";
    export const NS4_WORKFLOW_SCHEMA_VERSION: "2026-08-11-ns4-workflow-v4";
    export const NS4_WORKFLOW_INDEX_SCHEMA_VERSION: "2026-08-12-ns4-workflow-index-v5";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_09_09_ns4_usecase_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_usecase_v3: string[];
    export const TEXT_PATHS_2026_08_10_ns4_usecase_v2: string[];
    export const TEXT_PATHS_2026_09_09_ns4_usecase_index_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_usecase_index_v2: string[];
    /** Workflow artifacts are ids and transitions; no human prose. */
    export const TEXT_PATHS_2026_08_11_ns4_workflow_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_workflow_v1: string[];
    export const TEXT_PATHS_2026_08_12_ns4_workflow_index_v5: string[];
    export const TEXT_PATHS_2026_08_11_ns4_workflow_index_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_workflow_index_v1: string[];
    export type Ns4UseCaseKind = 'query' | 'command';
    export type Ns4UseCaseFieldType = Ns4OntologyField['type'];
    export interface Ns4E7SourceHashes {
        journeys: Array<{
            journeyId: string;
            businessHash: string;
        }>;
        ontologyHash: string;
        rulesHash: string;
    }
    export interface Ns4E7PlanUseCase {
        useCaseId: string;
        title: string;
        kind: Ns4UseCaseKind;
        compiledFrom: string[];
        contexts: {
            requires: string[];
            provides: string[];
        };
    }
    export interface Ns4E7PlanDraft {
        planId: 'e7-realization-plan';
        moduleName: string;
        userLanguage: string;
        useCases: Ns4E7PlanUseCase[];
        sourceHashes: Ns4E7SourceHashes;
        presentation?: Ns4Presentation;
    }
    export interface Ns4UseCaseFieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4UseCaseInput {
        inputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseOutput {
        outputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        contextId?: string;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseEntityAccess {
        entityId: string;
        fieldRefs: string[];
    }
    /** Entities this behavior records. fieldRefs optional: omit when the whole record is written. */
    export interface Ns4UseCaseWrite {
        entityId: string;
        fieldRefs?: string[];
    }
    export interface Ns4UseCaseTransition {
        transitionId: string;
        entityRef: string;
        fromStates: string[];
        toState: string;
        useRules: string[];
    }
    export interface Ns4UseCaseError {
        errorId: string;
        description: string;
        when: string;
        useRules: string[];
    }
    export interface Ns4UseCaseDraft extends Ns4E7PlanUseCase {
        draftVersion: typeof NS4_USE_CASE_DRAFT_VERSION;
        planId: 'e7-usecase';
        moduleName: string;
        description: string;
        contexts: {
            requires: string[];
            provides: string[];
        };
        entityRefs: string[];
        writes: Ns4UseCaseWrite[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
    }
    export interface Ns4UseCaseArtifactV3 extends Omit<Ns4UseCaseDraft, 'planId' | 'draftVersion' | 'transitions'> {
        schemaVersion: typeof NS4_USE_CASE_SCHEMA_VERSION;
        transitionRefs: string[];
        useCaseHash: string;
    }
    export interface Ns4UseCaseIndexArtifactV3 {
        schemaVersion: typeof NS4_USE_CASE_INDEX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4WorkflowTransition extends Ns4UseCaseTransition {
        useCaseId?: string;
        trigger?: 'system';
    }
    /** Lifecycle facts are owned by E4 and copied mechanically into E7 workflows. */
    export interface Ns4WorkflowLifecycleDefinition {
        states: string[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates?: Array<{
            predicateId: string;
            stateIds: string[];
        }>;
        /** Per-state `reachedBy`. Absent keys default to `actor`. `time` never enters the workflow. */
        reachedBy?: Record<string, 'actor' | 'command' | 'time'>;
    }
    export function workflowLifecycleOf(entity: {
        lifecycleStates: Array<string | {
            state: string;
            reachedBy: 'actor' | 'command' | 'time';
        }>;
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates?: Array<{
            predicateId: string;
            stateIds: string[];
        }>;
    }): Ns4WorkflowLifecycleDefinition;
    export interface Ns4WorkflowArtifactV2 {
        schemaVersion: typeof NS4_WORKFLOW_SCHEMA_VERSION;
        moduleName: string;
        workflowId: string;
        entityRef: string;
        initialState: string;
        terminalStates: string[];
        states: string[];
        transitions: Ns4WorkflowTransition[];
        workflowHash: string;
    }
    export interface Ns4WorkflowIndexArtifactV2 {
        schemaVersion: '2026-08-11-ns4-workflow-index-v4';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifactV3 extends Omit<Ns4WorkflowIndexArtifactV2, 'schemaVersion'> {
        schemaVersion: typeof NS4_WORKFLOW_INDEX_SCHEMA_VERSION;
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4UseCaseArtifact extends Ns4E7PlanUseCase {
        schemaVersion: '2026-08-10-ns4-usecase-v2';
        moduleName: string;
        description: string;
        inputs: Ns4UseCaseInput[];
        outputs: Ns4UseCaseOutput[];
        reads: Ns4UseCaseEntityAccess[];
        writes: Ns4UseCaseEntityAccess[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
        errors: Ns4UseCaseError[];
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCaseHash: string;
        generatedAt: string;
    }
    export interface Ns4UseCaseIndexArtifact {
        schemaVersion: '2026-08-10-ns4-usecase-index-v2';
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-v1';
        moduleName: string;
        userLanguage: string;
        workflowId: string;
        entityRef: string;
        states: string[];
        transitions: Ns4WorkflowTransition[];
        sourceHashes: Ns4E7SourceHashes;
        workflowHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-index-v1';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    /** Contexts come from the derivation, never from the journey text: E7 copies no declared name. */
    export function buildNs4E7Plan(moduleName: string, userLanguage: string, journeys: Ns4E2Review, sourceHashes: Ns4E7SourceHashes, contexts: Ns4DerivedContextGraph, presentation?: Ns4Presentation): Ns4E7PlanDraft;
    export function normalizeNs4UseCaseDraft(value: unknown, plan: Ns4E7PlanDraft, useCaseId: string): Ns4UseCaseDraft;
    export function buildNs4UseCaseArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], generatedAt: string, systemDecisions?: Ns4SystemDecision[]): Promise<{
        artifacts: Ns4UseCaseArtifactV3[];
        index: Ns4UseCaseIndexArtifactV3;
    }>;
    export function buildNs4WorkflowArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], ontologyLifecycles: Map<string, Ns4WorkflowLifecycleDefinition>, generatedAt: string): Promise<{
        artifacts: Ns4WorkflowArtifactV2[];
        index: Ns4WorkflowIndexArtifactV3;
    }>;
    export function buildNs4RealizedJourneyArtifact(source: Ns4JourneyArtifact, useCases: Ns4UseCaseArtifactV3[], derived: Ns4DerivedContextGraph): Promise<Ns4JourneyArtifactV5Realized>;
    export function buildNs4RealizedJourneyIndex(source: Ns4JourneyIndex, journeys: Ns4JourneyArtifactV5Realized[]): Promise<Ns4JourneyIndex>;
    export function buildNs4RealizedAccessArtifact(source: Ns4AccessMatrixArtifact, useCases: Ns4UseCaseArtifactV3[]): Promise<Ns4AccessMatrixArtifactV3>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ForeignKeys" {
    /**
     * Where a foreign key POINTS.
     *
     * An input's `fieldRef` names the entity that OWNS the field (`BillingLaborAllocation.clientBillingSummaryId`),
     * never the entity the id refers to. Reading the target off that prefix is how the E8 picker check
     * ended up comparing an entity with itself and passing in silence, while 48 command inputs across 15
     * workspaces asked the user to pick a record the screen could not show. The target only exists in the
     * relationship graph, so it is resolved here, once, for every consumer.
     */
    export interface Ns4FkRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
        realization?: {
            ownerEntity?: string;
            from?: {
                fieldIds?: string[];
            };
        };
    }
    export interface Ns4FkParent {
        parent: string;
        fieldId: string;
        required: boolean;
    }
    /** Owner entity -> the parents it references, with the field that holds each id. */
    export function buildNs4ParentIndex(relationships: readonly Ns4FkRelationship[]): Map<string, Ns4FkParent[]>;
    /** The entity a given field of a given entity points at, or null when the field is not a key. */
    export function ns4FkParentOf(index: Map<string, Ns4FkParent[]>, entityId: string, fieldId: string): Ns4FkParent | null;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/contracts" {
    import type { Ns4E2Review, Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { type Ns4DerivedContext } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import type { Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export { TEXT_PATHS_2026_08_14_ns4_e8_model_v1 } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export interface Ns4E8HubScore {
        entityRef: string;
        score: number;
        anchoredJourneyCount: number;
        requiredRelationshipCount: number;
        projectionCount: number;
        locateUseCaseCount: number;
    }
    /** A workspace context is exactly the derived journey context; E8 never invents another shape. */
    export type Ns4WorkspaceContext = Ns4DerivedContext;
    /**
     * The E1 prose a contentPage may quote into organisms. Detection itself is structural
     * (public external grant + singleton read) — this blob is copy, not the door.
     */
    export interface Ns4E8ModuleSignals {
        title: string;
        purpose: string;
        mainGoal?: string;
        expectedOutcomes?: Array<{
            outcomeId?: string;
            title: string;
            description: string;
        }>;
        inScope?: string[];
        outOfScope?: string[];
        boundaries?: string;
    }
    /** The approved contracts every E8 derivation reads. */
    export interface Ns4E8Sources {
        journeys: Ns4E2Review;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        useCases: Ns4UseCaseArtifactV3[];
        workflows: Ns4WorkflowArtifactV2[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        module?: Ns4E8ModuleSignals;
        presentation?: Ns4Presentation;
        accessBindings?: Ns4AccessBindingsArtifact;
        /** Disclosure views loaded by projectionRef; not listed on the E4 ontology index. */
        disclosureProjections?: Ns4OntologyEntity[];
    }
    /** E9/E10 compile against the E4 index plus disclosure views that E8 already pointed at. */
    export function ns4OntologyWithDisclosure(ontology: Ns4E4Review, projections?: readonly Ns4OntologyEntity[]): Ns4E4Review;
    export interface Ns4E8Edge {
        from: string;
        to: string;
        carries: string[];
        preferredFromJourneyRef?: string;
    }
    export function deriveE8HubScore(sources: Ns4E8Sources, derived?: import("/_102035_/l2/agentNewSolution/helpers/ns4Context.js").Ns4DerivedContextGraph): Ns4E8HubScore[];
    export function isPlatformOwnedEntity(entity: Ns4E4Review['entities'][number]): boolean;
    /**
     * Compile-only compatibility for workspaces written by the previous E8 model (runs 38-44). They are
     * never read or migrated — the union exists so already-generated L4 folders keep type-checking.
     */
    export interface Ns4WorkspaceArtifact {
        schemaVersion: string;
        moduleName: string;
        workspaceId: string;
        kind: string;
        title: string;
        description: string;
        anchorEntity?: string;
        profileRefs: string[];
        pageContext: Array<Record<string, unknown>>;
        scenarios: Array<Record<string, unknown>>;
        viewCall: {
            uses: Array<Record<string, unknown>>;
        };
        commands: string[];
        invalidations: Array<{
            useCaseId: string;
            sliceIds: string[];
        }>;
        skeletonHash: string;
        workspaceHash: string;
    }
    export interface Ns4WorkspaceIndex {
        schemaVersion: string;
        moduleName: string;
        userLanguage: string;
        workspaces: Array<Record<string, unknown>>;
        hubs: Array<Record<string, unknown>>;
        menu: Record<string, unknown>;
        skeletonHash: string;
        systemDecisions: Array<Record<string, unknown>>;
        approvedBy: string;
        approvedAt: string;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e8/model" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8Sources } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    export const NS4_E8_MODEL_VERSION: "2026-08-14-ns4-e8-model-v1";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_14_ns4_e8_model_v1: string[];
    export type Ns4WorkspaceTier = 'recordCatalogue' | 'journey' | 'hub' | 'projection' | 'contentPage';
    /** Organisms of type `content` use these roles; they exist only on a `contentPage`. */
    export type Ns4E8ContentRole = 'hero' | 'richText' | 'imageSet' | 'ctaLink';
    /**
     * The only origins a page can render by, in the vocabulary the frontend actually reads from an
     * operation input: userInput is a form field, selectedEntity is a picker over a query on the page,
     * routeParam comes from the URL, and the rest is resolved at runtime and never rendered.
     */
    export type Ns4E8InputSource = 'userInput' | 'selectedEntity' | 'routeParam' | 'actorSession' | 'systemDefault';
    /**
     * The record-owner handle: a field that points at a `party: person` entity (its own identity, or a
     * foreign key to one) when every E3 grant that operates the record is `dataScope.mode: own` — or
     * when the session actor is that person (an `own`/`assigned`/`related` grant). Never a field name.
     */
    export function isNs4OwnerHandleInput(input: {
        fieldRef: Ns4E8FieldRef;
        inputId?: string;
    }, sources: Ns4E8Sources): boolean;
    export type Ns4E8AccessPatternKind = 'list' | 'getById' | 'create' | 'update' | 'delete' | 'transition' | 'commandInput';
    export interface Ns4E8FieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4E8Input {
        inputId: string;
        fieldRef: Ns4E8FieldRef;
        source: Ns4E8InputSource;
        required: boolean;
        description: string;
        /** The literal union of an enumerated field, carried from the approved ontology. */
        enumValues?: string[];
        /** Present when the input is not the borrowed fieldRef's type (`page`/`pageSize` are numbers). */
        type?: 'number' | 'boolean' | 'string';
    }
    /**
     * One operation of the module. A journey step compiles into the E7 use case it already owns; a
     * record catalogue synthesizes its five operations from the ontology (list, getById, create,
     * update, and delete or the mdm inactivate/reactivate pair), because E7 only compiles journeys
     * and a catalogue is not a journey. getById is emitted even when no page consumes it.
     */
    /**
     * Master-data semantics of one operation. Master data is referenced by other
     * records, so an mdm catalogue deactivates instead of deleting.
     *
     * It is ONE optional block on purpose. The backend generator reads this artifact
     * as JSON and its accessPattern vocabulary is a closed set, so the lifecycle pair
     * keeps `kind: 'update'` — a command that mutates one identified record, which the
     * consumer already understands — and the meaning travels here. A consumer that
     * ignores the block behaves exactly as before.
     */
    export interface Ns4E8MdmSemantics {
        /** The command replaces a hard delete: route it to the MDM record lifecycle. */
        lifecycle?: 'inactivate' | 'reactivate';
        /** Optional request flag on a list: absent means only active records. */
        activeFilterInput?: 'includeInactive';
        /**
         * Response member carrying the situation. Derived from the MDM record lifecycle,
         * so it is NOT an ontology field and deliberately has no field ref: the ontology
         * declares no `active` field and the model must not invent one.
         */
        situationOutput?: 'active';
    }
    export interface Ns4E8Operation {
        operationId: string;
        title: string;
        kind: 'query' | 'command';
        entityRef: string;
        entityRefs: string[];
        accessPattern: {
            kind: Ns4E8AccessPatternKind;
            pagination?: 'optional';
        };
        inputs: Ns4E8Input[];
        outputRefs: string[];
        useRules: string[];
        transitionRefs: string[];
        story: string[];
        /** Present when the operation is an approved E7 use case; absent when the catalogue derived it. */
        useCaseId?: string;
        /** E3 authority refs or synthesized `synth:<entity>:<profile>` ids. Never empty. */
        authorityRefs: string[];
        /** Present only on a catalogue operation of an entity whose storage.target is mdm. */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4E8BffCall {
        bffId: string;
        kind: 'query' | 'command';
        operationId: string;
        outputKind: 'object' | 'list' | 'paginated';
        entityRef: string;
        /**
         * Which LOCAL call feeds each input of this one. Operations are shared and calls are per workspace,
         * so "where the user picks this record from" is a property of the call, never of the operation.
         * Without it the screen knows an id must be chosen and not which query to choose it from.
         */
        inputSources?: Array<{
            inputId: string;
            bffId: string;
        }>;
    }
    export type Ns4E8OrganismRole = 'primarySurface' | 'detailPanel' | 'filterControl' | 'contextualAction' | Ns4E8ContentRole;
    export interface Ns4E8Organism {
        role: Ns4E8OrganismRole;
        /** Present only on a content organism (hero/richText/imageSet/ctaLink). Never on a data-bound surface. */
        type?: 'content';
        dataSource?: string;
        action?: string;
        /** A picker is a query rendered to choose the record another call consumes. summary is counts of that list, not a row. */
        usage?: 'picker' | 'summary';
        /** Query bffId whose optional list inputs (search/sort) this filterControl drives. */
        attachTo?: string;
    }
    export interface Ns4E8Section {
        sectionId: string;
        intent: string;
        organisms: Ns4E8Organism[];
    }
    export interface Ns4E8ModelWorkspace {
        workspaceId: string;
        tier: Ns4WorkspaceTier;
        title: string;
        purpose: string;
        /** Classic workspace kind: operation, workflow, landing or record. */
        kind: 'operation' | 'workflow' | 'landing' | 'record';
        entity: string;
        workflowId?: string;
        actors: string[];
        profileRefs: string[];
        featureRefs: string[];
        hostedStepRefs: string[];
        journeyRef?: string;
        categoryRef: string;
        bffCalls: Ns4E8BffCall[];
        sections: Ns4E8Section[];
        /** Only a hub carries the closed catalogue its composition call may order and name. */
        hubCatalogue?: Ns4E8HubCatalogue;
        /** Workspaces this one links to; the site map turns them into navigation edges. */
        navigation?: Ns4E8NavigationTarget[];
    }
    export interface Ns4E8HubCatalogueItem {
        itemId: string;
        kind: 'projectionTile' | 'relatedList' | 'action' | 'pending';
        label: string;
        entityRef: string;
        /** The workspace the item belongs to; never invented by the composition call. */
        targetRef: string;
        /**
         * For an item the hub READS: the operation behind it. Operations are shared across the module and
         * calls are per workspace, so a tile becomes a local call of the hub over the same operation — an
         * organism only ever consumes a call of its own workspace.
         */
        sourceOperationId?: string;
        sourceBffId?: string;
        /** The shape the source call declares; a list read as an object would project a single record. */
        sourceOutputKind?: 'object' | 'list' | 'paginated';
        score: number;
    }
    /**
     * A journey reached from the hub is NAVIGATION, not an embedded command: it leaves the sections and
     * travels to the site map, carrying the prominence and order the composition chose.
     */
    export interface Ns4E8NavigationTarget {
        targetWorkspaceId: string;
        label: string;
        prominence: 'primary' | 'contextual';
        order: number;
    }
    export interface Ns4E8HubCatalogue {
        anchorEntity: string;
        items: Ns4E8HubCatalogueItem[];
    }
    export interface Ns4E8HubComposition {
        workspaceId: string;
        title: string;
        /** Catalogue item ids, in display order. Never a new id. */
        tileOrder: string[];
        primaryActionIds: string[];
        labels: Array<{
            itemId: string;
            label: string;
        }>;
        menuGroups: Array<{
            groupId: string;
            label: string;
            itemIds: string[];
        }>;
    }
    export interface Ns4E8MenuEntry {
        workspaceId: string;
        label: string;
        featureRef: string;
        tier: Ns4WorkspaceTier;
        profileRefs: string[];
    }
    export interface Ns4E8Model {
        planId: 'e8-workspace-model';
        schemaVersion: typeof NS4_E8_MODEL_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        hubEntity: string;
        workspaces: Ns4E8ModelWorkspace[];
        operations: Ns4E8Operation[];
        /** The menu lists places only: catalogues, hubs, projections and content pages. A journey is never a menu item. */
        menu: Ns4E8MenuEntry[];
        landings: Ns4E8Landing[];
        systemDecisions: Ns4SystemDecision[];
        modelHash?: string;
    }
    /**
     * Why this profile lands on this workspace. Closed machine token — never prose, never
     * `landingIntent` (that stays E3 copy for the human and the CF).
     */
    export type Ns4E8LandingReason = 'exclusive' | 'firstJourney' | 'rank';
    export interface Ns4E8Landing {
        profileRef: string;
        workspaceId: string;
        reason: Ns4E8LandingReason;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e9/classic" {
    import { type Ns4AccessMatrixArtifact, type Ns4AccessMatrixArtifactV4 } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review, Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4E8Input, Ns4E8MdmSemantics, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export const NS4_CLASSIC_WORKSPACE_VERSION: "2026-08-14-ns4-classic-workspace-v6";
    export const NS4_E9_OUTPUT_REF_UNKNOWN: "NS4_E9_OUTPUT_REF_UNKNOWN";
    /** Human-text JSON paths the importer may rewrite. Classic L4 has no schemaVersion on operations/siteMap. */
    export const TEXT_PATHS_2026_08_14_ns4_classic_workspace_v6: string[];
    export const TEXT_PATHS_CLASSIC_WORKSPACE: string[];
    export const TEXT_PATHS_CLASSIC_OPERATION: string[];
    export const TEXT_PATHS_CLASSIC_SITE_MAP: string[];
    export class Ns4E9OutputRefError extends Error {
        readonly code: "NS4_E9_OUTPUT_REF_UNKNOWN";
        constructor(ref: string);
    }
    export interface Ns4ClassicField {
        name: string;
        from: string;
        type?: string;
        required?: boolean;
        item?: {
            fields: Ns4ClassicField[];
        };
    }
    export interface Ns4ClassicBffCall {
        bffId: string;
        kind: 'query' | 'command';
        uses: Array<{
            operationId: string;
        }>;
        input: Array<{
            name: string;
            from: string;
            required?: boolean;
            source: string;
            sourceRef?: string;
            type: string;
            enumValues?: string[];
        }>;
        output: {
            kind: 'object' | 'list' | 'paginated';
            fields: Ns4ClassicField[];
        };
        route: string;
    }
    export interface Ns4ClassicWorkspace {
        workspaceId: string;
        title: string;
        actors: string[];
        kind: string;
        entity: string;
        workflowId?: string;
        bffCalls: Ns4ClassicBffCall[];
        sections: Array<{
            sectionId: string;
            intent: string;
            organisms: Array<Record<string, string>>;
        }>;
        operationIds: string[];
        purpose: string;
        presentation: {
            categoryRef: string;
            confidence: number;
            classificationNote: string;
        };
        sliceHash: string;
    }
    export interface Ns4ClassicOperation {
        operationId: string;
        title: string;
        actors: string[];
        entity: string;
        kind: string;
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        story: {
            actor: string;
            goal: string;
            steps: string[];
            outcome: string;
        };
        accessPattern: {
            kind: string;
            description: string;
            entity: string;
            keyField: string;
            pagination: string;
            selection: string;
            output: string[];
        };
        outputShape: {
            kind: 'object' | 'list' | 'paginated';
            fields: Array<{
                name: string;
                type: string;
                required: boolean;
                fieldRef?: string;
                item?: {
                    fields: Array<{
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    }>;
                };
            }>;
        };
        inputs: Array<{
            inputId: string;
            fieldRef: string;
            required: boolean;
            source: string;
            description: string;
            enumValues?: string[];
            type?: string;
        }>;
        pageId: string;
        commandName: string;
        bffName: string;
        /**
         * Carried verbatim from the model when the operation is a master-data catalogue
         * operation. It is what lets the backend generator route the lifecycle pair to
         * the MDM facade and keep the list active-only. Optional, so a consumer that
         * ignores it is unaffected.
         */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4ClassicSiteMap {
        moduleName: string;
        note: string;
        workspaces: Array<{
            workspaceId: string;
            title: string;
            actors: string[];
            kind: string;
            entity: string;
            operationIds: string[];
            purpose: string;
        }>;
        landings: Array<{
            actorId: string;
            workspaceId: string;
            reason: string;
        }>;
        navigationEdges: Array<{
            from: string;
            to: string;
            operationId: string;
            description: string;
            prominence?: 'primary' | 'contextual';
            order?: number;
        }>;
        workspaceIds: string[];
    }
    /** `<operationId>.<inputId>`: the only path both consumers know how to trace back. */
    export function ns4ClassicFrom(operationId: string, member: string): string;
    export type Ns4ClassicUseCaseWrites = Array<{
        useCaseId: string;
        writes?: Array<{
            entityId: string;
        }>;
    }>;
    export function transposeNs4ClassicOperation(model: Ns4E8Model, operation: Ns4E8Operation, ontology: Ns4E4Review, useCases?: Ns4ClassicUseCaseWrites): Ns4ClassicOperation;
    export function transposeNs4ClassicWorkspace(model: Ns4E8Model, workspace: Ns4E8ModelWorkspace, operations: Map<string, Ns4E8Operation>, ontology: Ns4E4Review, sliceHash: string): Ns4ClassicWorkspace;
    export function fieldTypeOf(ontology: Ns4E4Review, entityId: string, fieldId: string): Ns4OntologyField['type'];
    type ClassicOutputField = {
        name: string;
        type: string;
        required: boolean;
        fieldRef: string;
    };
    /**
     * The wire shape is what E8 declared in outputRefs. A catalogue command whose refs are only the
     * identity still projects the entity fields it always did, so modules without a joined projection
     * keep today's outputShape. An unknown ref is a blocking E9 finding, never a silent `unknown`.
     */
    export function resolveClassicOutputFields(operation: Ns4E8Operation, ontology: Ns4E4Review): ClassicOutputField[];
    /** One TypeScript contract file per bffCall, byte-compatible with what the CFE reads today. */
    export function buildNs4ClassicContractSource(args: {
        moduleName: string;
        workspaceId: string;
        call: Ns4ClassicBffCall;
        fileRef: string;
        sourceRef: string;
    }): string;
    export function buildNs4ClassicSiteMap(model: Ns4E8Model, classic: Ns4ClassicWorkspace[]): Ns4ClassicSiteMap;
    /** Declared collection name on the wire — never the generic `items`. */
    export function collectionFieldName(entityId: string): string;
    export interface Ns4ClassicL4 {
        workspaces: Ns4ClassicWorkspace[];
        operations: Ns4ClassicOperation[];
        contracts: Array<{
            workspaceId: string;
            bffId: string;
            route: string;
            source: string;
        }>;
        siteMap: Ns4ClassicSiteMap;
    }
    export function buildNs4NavigationRealizedAccess(source: Ns4AccessMatrixArtifact, model: Ns4E8Model, classic: Ns4ClassicL4): Promise<Ns4AccessMatrixArtifactV4>;
    /** The whole transposition: what E9 writes to L4 from an approved E8 model. */
    export function compileNs4ClassicL4(model: Ns4E8Model, ontology: Ns4E4Review, useCases?: Ns4ClassicUseCaseWrites): Promise<Ns4ClassicL4>;
    export type Ns4ClassicInput = Ns4E8Input;
}
declare module "_102035_/l2/agentNewSolution/steps/e10/contracts" {
    import { type Ns4JourneyIndex, type Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import type { Ns4OntologyIndexArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4UseCaseIndexArtifactV3, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4E8Model } from "_102035_/l2/agentNewSolution/steps/e8/model";
    import type { Ns4ClassicL4 } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_E10_VALIDATION_REPORT_VERSION: "2026-08-15-ns4-e10-validation-report-v2";
    export const NS4_L5_TODO_FRONTEND_VERSION: "2026-08-13-ns4-todo-frontend-v1";
    export const NS4_L5_TODO_BACKEND_VERSION: "2026-08-13-ns4-todo-backend-v1";
    export const NS4_L5_PROCESS_VERSION: "2026-08-13-ns4-process-v1";
    export const NS4_E10_MENU_LIMIT: 7;
    export type Ns4E10RepairStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler';
    /** E10 validates the approved E8 model against the classic L4 that E9 actually wrote to disk. */
    export interface Ns4E10Sources {
        moduleName: string;
        userLanguage: string;
        presentation?: Ns4Presentation;
        journeys: Ns4E2Review;
        journeyIndex: Ns4JourneyIndex;
        ontology: Ns4E4Review;
        ontologyIndex: Ns4OntologyIndexArtifact;
        rules: Ns4RulesArtifact;
        access: Ns4AccessMatrixArtifact;
        accessBindings?: Ns4AccessBindingsArtifact;
        disclosureProjections?: Ns4OntologyEntity[];
        useCases: Ns4UseCaseArtifactV3[];
        useCaseIndex: Ns4UseCaseIndexArtifactV3;
        workflows: Ns4WorkflowArtifactV2[];
        workflowIndex: Ns4WorkflowIndexArtifactV2 | Ns4WorkflowIndexArtifactV3;
        model: Ns4E8Model;
        /** What E9 emitted, read back from L4: the staleness check compares it to a fresh compilation. */
        saved: Ns4ClassicL4;
    }
    export interface Ns4E10Issue {
        code: string;
        path: string;
        message: string;
        repairStep?: Ns4E10RepairStep;
    }
    export interface Ns4E10CheckSummary {
        checkId: 'A1-resolution' | 'A2-journeys' | 'A3-decisions' | 'A4-disclosure' | 'A5-fsm' | 'A6-staleness' | 'A7-warnings' | 'A8-dormant-commands' | 'A9-authority';
        status: 'passed' | 'failed' | 'reported';
        errorCount: number;
        warningCount: number;
        registrarCount: number;
    }
    export interface Ns4L5NavigationItem {
        id: string;
        label: string;
        href: string;
        description: string;
        actors: string[];
        workspaceId: string;
        scenarioId: string;
        sectionId: string;
        hub?: string;
    }
    export interface Ns4L5HeaderLink {
        id: string;
        label: string;
        href: string;
        actors: string[];
        manageable: true;
        hub?: string;
    }
    export interface Ns4L5ModuleNavigation {
        moduleId: string;
        basePath: string;
        userLanguage: string;
        navigation: Ns4L5NavigationItem[];
        headerLinks: Ns4L5HeaderLink[];
    }
    export interface Ns4E10ValidationReport {
        schemaVersion: typeof NS4_E10_VALIDATION_REPORT_VERSION;
        moduleName: string;
        userLanguage: string;
        finalStatus: 'passed' | 'failed';
        checks: Ns4E10CheckSummary[];
        errors: Ns4E10Issue[];
        warnings: Ns4E10Issue[];
        registrars: Ns4E10Issue[];
        policyDecisions: Ns4PolicyDecisionSelection[];
        systemDecisions: Ns4SystemDecision[];
        repairStep?: Ns4E10RepairStep;
        /**
         * The failure is a defect of the pipeline itself, not of the product: no step can repair it, so
         * nothing is marked stale and the module waits for a fixed pipeline instead of re-running whole.
         */
        pipelineDefect?: true;
        sourceHashes: {
            journeys: Array<{
                journeyId: string;
                businessHash: string;
            }>;
            accessHash: string;
            ontologyHash: string;
            rulesHash: string;
        };
        counts: {
            journeys: number;
            workspaces: number;
            operations: number;
            contracts: number;
            decisions: number;
        };
        menuPreview: Ns4L5ModuleNavigation;
        reportHash: string;
    }
    /**
     * e10 always EMITS 'toCreate', but the todo file is the ledger the downstream agents own: changeBackend
     * and changeFrontend flip each owner to 'inProgress' and 'done' in place, keeping the `satisfies` the
     * generator wrote. Pinning the literal made the artifact stop type-checking as soon as work progressed —
     * 264 TS2322 in one module's todoFrontend. The type describes the file, so it carries the whole lifecycle.
     */
    export type Ns4L5OwnerStatus = 'toCreate' | 'inProgress' | 'done';
    export interface Ns4L5FrontendOwner {
        ownerType: 'workspace' | 'contract';
        ownerId: string;
        workspaceId: string;
        statusFrontend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5BackendOwner {
        ownerType: 'useCase';
        ownerId: string;
        statusBackend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5TodoFrontendArtifact {
        schemaVersion: typeof NS4_L5_TODO_FRONTEND_VERSION;
        layer: 'frontend';
        moduleName: string;
        owners: Ns4L5FrontendOwner[];
    }
    export interface Ns4L5TodoBackendArtifact {
        schemaVersion: typeof NS4_L5_TODO_BACKEND_VERSION;
        layer: 'backend';
        moduleName: string;
        owners: Ns4L5BackendOwner[];
    }
    export interface Ns4L5ProcessArtifact {
        schemaVersion: typeof NS4_L5_PROCESS_VERSION;
        moduleName: string;
        sourceHashes: Ns4E10ValidationReport['sourceHashes'];
        counts: Ns4E10ValidationReport['counts'];
        validation: {
            status: 'passed';
            reportPath: string;
            reportHash: string;
            warningCount: number;
            registrarCount: number;
        };
        next: {
            frontend: 'todoFrontend';
            backend: 'todoBackend';
        };
        processHash: string;
    }
    export interface Ns4E10Delivery {
        config: Record<string, unknown>;
        moduleNavigation: Ns4L5ModuleNavigation;
        todoFrontend: Ns4L5TodoFrontendArtifact;
        todoBackend: Ns4L5TodoBackendArtifact;
        process: Ns4L5ProcessArtifact;
    }
    /**
     * The L5 menu preview. The frontend rebuilds navigation as E8 `model.menu` ∩ materialized pages
     * (nodejsSaveConfigJson.ts), with `/<module>/<workspaceId>` as the href — this mirrors that
     * derivation so the report shows the menu the module will actually have.
     */
    export function compileNs4L5ModuleNavigation(sources: Ns4E10Sources): Ns4L5ModuleNavigation;
    export function compileNs4E10Delivery(sources: Ns4E10Sources, report: Ns4E10ValidationReport, existingConfig: unknown, projectId: number): Promise<Ns4E10Delivery>;
    export function mergeNs4L5Config(existing: unknown, projectId: number, moduleNavigation: Ns4L5ModuleNavigation): Record<string, unknown>;
}
declare module "_102035_/l2/agentNewSolution/steps/e1/contracts" {
    import { Ns4ApprovedBy, Ns4ModuleArtifact, Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type Ns4ReviewPolicy = 'guided' | 'smart' | 'automatic';
    export type Ns4SolutionStrategy = 'newSolution' | 'modernizePreserveDatabase' | 'modernizeEvolveDatabase' | 'replaceAndMigrateData';
    export type Ns4DatabaseChangePolicy = 'new' | 'forbidden' | 'additiveControlled' | 'replacement';
    export type Ns4ActorKind = 'internal' | 'external' | 'system';
    export type Ns4ActorOrigin = 'named' | 'inferred';
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_06_ns4_module_v4: string[];
    /** E1 business actor. `origin` is `named` only when the request itself names the profile. */
    export interface Ns4BusinessActor {
        actorId: string;
        title: string;
        kind: Ns4ActorKind;
        origin: Ns4ActorOrigin;
        expectedOutcome: string;
    }
    export interface Ns4E1Review {
        planId: 'e1-review';
        reviewRound: number;
        userLanguage: string;
        reviewPolicy: {
            mode: Ns4ReviewPolicy;
        };
        module: {
            moduleName: string;
            title: string;
            purpose: string;
        };
        strategy: {
            mode: Ns4SolutionStrategy;
            rationale: string;
            databaseChangePolicy: Ns4DatabaseChangePolicy;
            modernization?: {
                sourceSystemName: string;
                sourceTechnology?: string;
                databaseEngine?: string;
                databaseVersion?: string;
                schemaAvailability: 'uploadAtE4' | 'metadataAtE4' | 'notAvailableYet';
                notes?: string;
            };
        };
        businessScope: {
            mainGoal: string;
            actors: Ns4BusinessActor[];
            expectedOutcomes: Array<{
                outcomeId: string;
                title: string;
                description: string;
            }>;
            inScope: string[];
            outOfScope: string[];
        };
        localization: {
            productLanguages: string[];
            defaultLanguage: string;
            defaultLocale?: string;
            currency?: string;
            timeZone?: string;
            primaryMarket?: string;
        };
        declaredConstraints: {
            mandatoryIntegrations: Array<{
                dependencyId: string;
                title: string;
                kind: 'externalSystem' | 'platform' | 'unknown';
                reason: string;
            }>;
            regulatoryNotes?: string;
            criticalNotes?: string;
        };
        changeSummary: string[];
        /**
         * Product languages the normalizer discarded for lacking user provenance (run02 102047: the LLM
         * invented en/es for a pt-BR-only request). Trace-only: never copied into the l4 artifact.
         */
        i18nWarnings?: string[];
    }
    export interface Ns4E1ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E1Review;
    }
    export interface Ns4E1ReviewIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns4E1ReviewGate {
        ok: boolean;
        issues: Ns4E1ReviewIssue[];
    }
    export function normalizeNs4E1Review(value: unknown, fallback?: {
        userLanguage?: string;
        moduleName?: string;
        productLanguages?: string;
        mainActors?: string;
        mainGoal?: string;
        boundaries?: string;
        sourcePrompt?: string;
        /**
         * Under `/fast` the clarification answer is the planner's own proposal, never a user citation.
         * When true, language provenance comes only from `sourcePrompt` (and `userLanguage`).
         */
        answerIsProposal?: boolean;
    }): Ns4E1Review;
    export function policyFor(mode: Ns4SolutionStrategy): Ns4DatabaseChangePolicy;
    export function validateNs4E1Review(review: Ns4E1Review): Ns4E1ReviewGate;
    export function buildNs4ModuleArtifactFromReview(review: Ns4E1Review, sourcePrompt: string, approvedBy: Ns4ApprovedBy, presentation: Ns4Presentation, now?: string): Ns4ModuleArtifact;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4TextPaths" {
    import { TEXT_PATHS_CLASSIC_OPERATION, TEXT_PATHS_CLASSIC_SITE_MAP, TEXT_PATHS_CLASSIC_WORKSPACE } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    export const TEXT_PATHS_VERSION: "2026-09-09-n14";
    export const TEXT_PATHS_BY_SCHEMA: Record<string, readonly string[]>;
    export function textPathsForArtifact(relativePath: string, artifact: unknown): readonly string[];
    export function schemaVersionOf(value: unknown): string;
    export interface StringHit {
        path: string;
        value: string;
    }
    export function walkStrings(value: unknown, prefix?: string): StringHit[];
    export function pathMatches(path: string, pattern: string): boolean;
    export function isCoveredPath(path: string, patterns: readonly string[]): boolean;
    export function extractI18n(artifact: unknown, patterns: readonly string[]): Record<string, string>;
    export function injectI18n<T>(artifact: T, i18n: Record<string, string>): T;
    export function uncoveredNonAscii(artifact: unknown, patterns: readonly string[]): StringHit[];
    export { TEXT_PATHS_CLASSIC_OPERATION, TEXT_PATHS_CLASSIC_SITE_MAP, TEXT_PATHS_CLASSIC_WORKSPACE };
}
declare module "_102035_/l2/agentNewSolution/types" {
    import type { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import type { Ns4JourneyArtifact, Ns4JourneyIndex } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyEntityArtifact, Ns4OntologyIndexArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4CompositionArtifact } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    import type { Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    import type { Ns4Level1EntityArtifact, Ns4Level1IndexArtifact, Ns4SolutionRegistryArtifact } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export type { Ns4ActorKind, Ns4ActorOrigin, Ns4BusinessActor, } from "_102035_/l2/agentNewSolution/steps/e1/contracts";
    export type { Ns4ApprovedBy, Ns4CompletedStepId, Ns4E1Status, Ns4E2Status, Ns4E3Status, Ns4E4Status, Ns4E4BStatus, Ns4E5Status, Ns4E6Status, Ns4E7Status, Ns4E8Status, Ns4E9Status, Ns4E10Status, Ns4ModuleArtifact, Ns4NextStep, Ns4PipelineState, Ns4Presentation, } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type { Ns4E2Feature, Ns4E2Review, Ns4E2ReviewEvent, Ns4FeaturePriority, Ns4JourneyArtifact, Ns4JourneyBusiness, Ns4JourneyEntryMode, Ns4JourneyIndex, Ns4JourneyProposal, Ns4JourneyStep, Ns4JourneyStepKind, Ns4LegacyJourneyArtifact, Ns4LegacyJourneyBusiness, Ns4LegacyJourneyContext, Ns4PolicyDecision, Ns4PolicyDecisionSelection, } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    export type { Ns4AccessAuthority, Ns4AccessMatrixArtifactV4, Ns4AccessOperationAuthorityRef, Ns4AccessGrant, Ns4AccessMatrixArtifact, Ns4AccessProfile, Ns4AccessProfileKind, Ns4AccessScopeMode, Ns4DisclosureMode, Ns4E3Review, Ns4E3ReviewEvent, } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    export type { Ns4ConstraintSource, Ns4DerivationAggregate, Ns4DerivationOp, Ns4E4EntityDraft, Ns4E4PlanDraft, Ns4E4RelationshipBinding, Ns4E4RelationshipBindingsDraft, Ns4E4Review, Ns4E4ReviewEvent, Ns4EntityDerivation, Ns4EntityKind, Ns4EntityOwnership, Ns4FieldConstraint, Ns4LifecyclePredicate, Ns4LifecycleReachedBy, Ns4LifecycleState, Ns4OntologyEntity, Ns4OntologyEntityArtifact, Ns4OntologyEntityPlan, Ns4OntologyField, Ns4OntologyIndexArtifact, Ns4OntologyRelationship, Ns4RelationshipEndpointBinding, Ns4RelationshipPersistenceMode, Ns4RelationshipRealization, Ns4RelationshipRealizationKind, Ns4ResolvedOntologyRelationship, Ns4StorageScope, Ns4StorageTarget, } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export type { Ns4AccessAnchor, Ns4AccessAnchorHop, Ns4AccessBinding, Ns4AccessBindingsArtifact, Ns4SynthesizedAuthority, } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    export type { Ns4E5Review, Ns4E5ReviewEvent, Ns4RuleDefinition, Ns4RulesArtifact, } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    export type { Ns4AdditionalCapability, Ns4AdditionalCapabilityDecision, Ns4AdditionalCapabilityKind, Ns4CompositionArtifact, Ns4E6Review, Ns4E6ReviewEvent, } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    export type { Ns4E7PlanDraft, Ns4E7PlanUseCase, Ns4E7SourceHashes, Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseDraft, Ns4UseCaseEntityAccess, Ns4UseCaseError, Ns4UseCaseFieldRef, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4UseCaseInput, Ns4UseCaseKind, Ns4UseCaseOutput, Ns4UseCaseTransition, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3, Ns4WorkflowTransition, } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    export type { Ns4E8Edge, Ns4E8HubScore, Ns4E8ModuleSignals, Ns4E8Sources, Ns4WorkspaceArtifact, Ns4WorkspaceContext, Ns4WorkspaceIndex, } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    export type { Ns4E8BffCall, Ns4E8HubCatalogue, Ns4E8HubCatalogueItem, Ns4E8HubComposition, Ns4E8Input, Ns4E8InputSource, Ns4E8MenuEntry, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation, Ns4E8Organism, Ns4E8Section, Ns4WorkspaceTier, } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export type { Ns4ClassicBffCall, Ns4ClassicL4, Ns4ClassicOperation, Ns4ClassicSiteMap, Ns4ClassicWorkspace, } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    export type { Ns4E10CheckSummary, Ns4E10Delivery, Ns4E10Issue, Ns4E10RepairStep, Ns4E10ValidationReport, Ns4L5BackendOwner, Ns4L5FrontendOwner, Ns4L5HeaderLink, Ns4L5ModuleNavigation, Ns4L5NavigationItem, Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact, } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    export type { Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, Ns4SolutionRegistryActor, Ns4SolutionRegistryArtifact, Ns4SolutionRegistryGeneralField, Ns4SolutionRegistryModule, Ns4SolutionRegistryRole, } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, NS4_SOLUTION_REGISTRY_SCHEMA_VERSION, } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export { TEXT_PATHS_BY_SCHEMA, TEXT_PATHS_VERSION, textPathsForArtifact, } from "_102035_/l2/agentNewSolution/helpers/ns4TextPaths";
    export const NS4_PERMANENT_ARTIFACT_TYPE_NAMES: readonly ["Ns4ModuleArtifact", "Ns4JourneyArtifact", "Ns4JourneyIndex", "Ns4AccessMatrixArtifact", "Ns4AccessBindingsArtifact", "Ns4OntologyEntityArtifact", "Ns4OntologyIndexArtifact", "Ns4RulesArtifact", "Ns4CompositionArtifact", "Ns4UseCaseArtifact", "Ns4UseCaseArtifactV3", "Ns4UseCaseIndexArtifact", "Ns4UseCaseIndexArtifactV3", "Ns4WorkflowArtifact", "Ns4WorkflowArtifactV2", "Ns4WorkflowIndexArtifact", "Ns4WorkflowIndexArtifactV2", "Ns4WorkflowIndexArtifactV3", "Ns4L5TodoFrontendArtifact", "Ns4L5TodoBackendArtifact", "Ns4L5ProcessArtifact", "Ns4Level1EntityArtifact", "Ns4Level1IndexArtifact", "Ns4SolutionRegistryArtifact"];
    export type Ns4PermanentArtifactTypeName = typeof NS4_PERMANENT_ARTIFACT_TYPE_NAMES[number];
    export interface Ns4PermanentArtifactByType {
        Ns4ModuleArtifact: Ns4ModuleArtifact;
        Ns4JourneyArtifact: Ns4JourneyArtifact;
        Ns4JourneyIndex: Ns4JourneyIndex;
        Ns4AccessMatrixArtifact: Ns4AccessMatrixArtifact;
        Ns4AccessBindingsArtifact: Ns4AccessBindingsArtifact;
        Ns4OntologyEntityArtifact: Ns4OntologyEntityArtifact;
        Ns4OntologyIndexArtifact: Ns4OntologyIndexArtifact;
        Ns4RulesArtifact: Ns4RulesArtifact;
        Ns4CompositionArtifact: Ns4CompositionArtifact;
        Ns4UseCaseArtifact: Ns4UseCaseArtifact;
        Ns4UseCaseArtifactV3: Ns4UseCaseArtifactV3;
        Ns4UseCaseIndexArtifact: Ns4UseCaseIndexArtifact;
        Ns4UseCaseIndexArtifactV3: Ns4UseCaseIndexArtifactV3;
        Ns4WorkflowArtifact: Ns4WorkflowArtifact;
        Ns4WorkflowArtifactV2: Ns4WorkflowArtifactV2;
        Ns4WorkflowIndexArtifact: Ns4WorkflowIndexArtifact;
        Ns4WorkflowIndexArtifactV2: Ns4WorkflowIndexArtifactV2;
        Ns4WorkflowIndexArtifactV3: Ns4WorkflowIndexArtifactV3;
        Ns4L5TodoFrontendArtifact: Ns4L5TodoFrontendArtifact;
        Ns4L5TodoBackendArtifact: Ns4L5TodoBackendArtifact;
        Ns4L5ProcessArtifact: Ns4L5ProcessArtifact;
        Ns4Level1EntityArtifact: Ns4Level1EntityArtifact;
        Ns4Level1IndexArtifact: Ns4Level1IndexArtifact;
        Ns4SolutionRegistryArtifact: Ns4SolutionRegistryArtifact;
    }
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4TypedDefs" {
    import type { Ns4PermanentArtifactByType, Ns4PermanentArtifactTypeName } from "_102035_/l2/agentNewSolution/types";
    export interface Ns4DefsFileReference {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export function renderNs4TypedDefsSource<T extends Ns4PermanentArtifactTypeName>(fileInfo: Ns4DefsFileReference, exportName: string, value: NoInfer<Ns4PermanentArtifactByType[T]>, artifactType: T): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Fs" {
    import { type Ns4RebuildAllReport } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { planNs4RebuildAll } from "_102035_/l2/agentNewSolution/helpers/ns4RebuildAll";
    import type { Ns4AccessBindingsArtifact, Ns4AccessMatrixArtifact, Ns4CompositionArtifact, Ns4JourneyArtifact, Ns4JourneyIndex, Ns4ModuleArtifact, Ns4OntologyEntityArtifact, Ns4OntologyIndexArtifact, Ns4PipelineState, Ns4RulesArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseIndexArtifactV3, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifactV3, Ns4E10ValidationReport, Ns4L5TodoFrontendArtifact, Ns4L5TodoBackendArtifact, Ns4L5ProcessArtifact, Ns4SolutionRegistryArtifact } from "_102035_/l2/agentNewSolution/types";
    export type Ns4FileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export function ns4AgentFile(folder: string, shortName: string, extension: string): Ns4FileInfo;
    export function ns4ModuleFile(moduleName: string): Ns4FileInfo;
    export function ns4SolutionRegistryFile(): Ns4FileInfo;
    export function ns4Level1IndexFile(): Ns4FileInfo;
    export function ns4Level1EntityFile(subtype: string): Ns4FileInfo;
    export function ns4PipelineFile(moduleName: string): Ns4FileInfo;
    export function ns4PipelineJsonFile(moduleName: string, shortName: string): Ns4FileInfo;
    export function listNs4PipelineJsonShortNames(moduleName: string): string[];
    export function writeNs4Json(fileInfo: Ns4FileInfo, value: unknown): Promise<string>;
    export function ns4E2DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E2VersionedDraftFile(moduleName: string, reviewRound: number): Ns4FileInfo;
    export function ns4E2ImpactReportFile(moduleName: string): Ns4FileInfo;
    export function ns4E3DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4AccessMatrixFile(moduleName: string): Ns4FileInfo;
    export function ns4AccessBindingsFile(moduleName: string): Ns4FileInfo;
    export function ns4E4DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E4PlanDraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E4EntityDraftFile(moduleName: string, entityId: string): Ns4FileInfo;
    export function ns4E4RelationshipBindingsDraftFile(moduleName: string): Ns4FileInfo;
    export function ns4OntologyEntityFile(moduleName: string, entityId: string): Ns4FileInfo;
    export function ns4OntologyIndexFile(moduleName: string): Ns4FileInfo;
    export function ns4E5DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E5ApprovedFile(moduleName: string): Ns4FileInfo;
    export function ns4RulesFile(moduleName: string): Ns4FileInfo;
    export function ns4E6DraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E6ApprovedFile(moduleName: string): Ns4FileInfo;
    export function ns4CompositionFile(moduleName: string): Ns4FileInfo;
    export function ns4E7PlanDraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E7UseCaseDraftFile(moduleName: string, useCaseId: string): Ns4FileInfo;
    export function ns4E7ValidationReportFile(moduleName: string): Ns4FileInfo;
    export function ns4UseCaseFile(moduleName: string, useCaseId: string): Ns4FileInfo;
    export function ns4UseCaseIndexFile(moduleName: string): Ns4FileInfo;
    export function ns4WorkflowFile(moduleName: string, workflowId: string): Ns4FileInfo;
    export function ns4WorkflowIndexFile(moduleName: string): Ns4FileInfo;
    export function ns4E8SkeletonDraftFile(moduleName: string): Ns4FileInfo;
    export function ns4E8WorkspaceDraftFile(moduleName: string, workspaceId: string): Ns4FileInfo;
    export function ns4E8ValidationReportFile(moduleName: string): Ns4FileInfo;
    export function ns4WorkspaceFile(moduleName: string, workspaceId: string): Ns4FileInfo;
    /**
     * The approved workspace model is a PERMANENT artifact, not a pipeline draft: `pipeline/` is working
     * state for one run and is thrown away afterwards, while E9 and E10 read this model as the contract
     * of record. It sits at the module root, where neither consumer's folder scan picks it up.
     */
    export function ns4WorkspaceModelFile(moduleName: string): Ns4FileInfo;
    export function ns4OperationFile(moduleName: string, operationId: string): Ns4FileInfo;
    export function ns4SiteMapFile(moduleName: string): Ns4FileInfo;
    export function ns4ClassicContractFile(moduleName: string, workspaceId: string, bffId: string): Ns4FileInfo;
    export function ns4E10ValidationReportFile(moduleName: string): Ns4FileInfo;
    export function ns4L5ConfigFile(): Ns4FileInfo;
    export function ns4TodoFrontendFile(moduleName: string): Ns4FileInfo;
    export function ns4TodoBackendFile(moduleName: string): Ns4FileInfo;
    export function ns4ProcessFile(moduleName: string): Ns4FileInfo;
    export function ns4JourneyFile(moduleName: string, journeyId: string): Ns4FileInfo;
    export function ns4JourneyIndexFile(moduleName: string): Ns4FileInfo;
    export function readNs4AgentText(folder: string, shortName: string): Promise<string>;
    export function readNs4Pipeline(moduleName: string): Promise<Ns4PipelineState | null>;
    export function readNs4Module(moduleName: string): Promise<Ns4ModuleArtifact | null>;
    export function writeNs4Pipeline(state: Ns4PipelineState): Promise<string>;
    export function writeNs4Module(moduleName: string, artifact: Ns4ModuleArtifact): Promise<string>;
    export function writeNs4E2Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E2VersionedDraft(moduleName: string, reviewRound: number, draft: unknown): Promise<string>;
    export function writeNs4E2ImpactReport(moduleName: string, report: unknown): Promise<string>;
    export function writeNs4E3Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E4Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E4PlanDraft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E4EntityDraft(moduleName: string, entityId: string, draft: unknown): Promise<string>;
    export function writeNs4E4RelationshipBindingsDraft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E5Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E5Approved(moduleName: string, review: unknown): Promise<string>;
    export function writeNs4E6Draft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E6Approved(moduleName: string, review: unknown): Promise<string>;
    export function writeNs4E7PlanDraft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E7UseCaseDraft(moduleName: string, useCaseId: string, draft: unknown): Promise<string>;
    export function writeNs4E7ValidationReport(moduleName: string, report: unknown): Promise<string>;
    export function writeNs4E8SkeletonDraft(moduleName: string, draft: unknown): Promise<string>;
    export function writeNs4E8WorkspaceDraft(moduleName: string, workspaceId: string, draft: unknown): Promise<string>;
    export function writeNs4E8ValidationReport(moduleName: string, report: unknown): Promise<string>;
    export function writeNs4AccessMatrix(moduleName: string, artifact: Ns4AccessMatrixArtifact): Promise<string>;
    export function writeNs4AccessBindings(moduleName: string, artifact: Ns4AccessBindingsArtifact): Promise<string>;
    export function writeNs4OntologyEntity(moduleName: string, entityId: string, artifact: Ns4OntologyEntityArtifact): Promise<string>;
    export function writeNs4OntologyIndex(moduleName: string, artifact: Ns4OntologyIndexArtifact): Promise<string>;
    export function writeNs4Rules(moduleName: string, artifact: Ns4RulesArtifact): Promise<string>;
    export function writeNs4Composition(moduleName: string, artifact: Ns4CompositionArtifact): Promise<string>;
    export function writeNs4UseCase(moduleName: string, useCaseId: string, artifact: Ns4UseCaseArtifactV3): Promise<string>;
    export function writeNs4UseCaseIndex(moduleName: string, artifact: Ns4UseCaseIndexArtifactV3): Promise<string>;
    export function writeNs4Workflow(moduleName: string, workflowId: string, artifact: Ns4WorkflowArtifactV2): Promise<string>;
    export function writeNs4WorkflowIndex(moduleName: string, artifact: Ns4WorkflowIndexArtifactV3): Promise<string>;
    export function writeNs4E10ValidationReport(moduleName: string, report: Ns4E10ValidationReport): Promise<string>;
    export function ns4L5ProjectFile(projectId?: number): Ns4FileInfo;
    /** l5/project.json — organization-level, owned by the studio. E10 reads it and only ADDS what is absent. */
    export function readNs4L5Project(projectId?: number): Promise<Record<string, unknown> | null>;
    export function writeNs4L5Project(projectJson: Record<string, unknown>): Promise<string>;
    export function readNs4L5Config(): Promise<Record<string, unknown> | null>;
    export function writeNs4L5Config(config: Record<string, unknown>): Promise<string>;
    export function writeNs4TodoFrontend(moduleName: string, artifact: Ns4L5TodoFrontendArtifact): Promise<string>;
    export function writeNs4TodoBackend(moduleName: string, artifact: Ns4L5TodoBackendArtifact): Promise<string>;
    export function writeNs4Process(moduleName: string, artifact: Ns4L5ProcessArtifact): Promise<string>;
    export function readNs4SolutionRegistry(): Promise<Ns4SolutionRegistryArtifact | null>;
    export function writeNs4SolutionRegistry(artifact: Ns4SolutionRegistryArtifact): Promise<string>;
    export function writeNs4Journey(moduleName: string, journeyId: string, artifact: Ns4JourneyArtifact): Promise<string>;
    export function writeNs4JourneyIndex(moduleName: string, index: Ns4JourneyIndex): Promise<string>;
    export function ns4FileExists(fileInfo: Ns4FileInfo): boolean;
    /** Draft files of approved E7 use cases. Used by E9 only as an audit of what did not become an operation. */
    export function listNs4E7UseCaseDraftFiles(moduleName: string): Ns4FileInfo[];
    export function listNs4ModuleFolders(): Set<string>;
    export function readNs4Text(fileInfo: Ns4FileInfo, required: boolean): Promise<string>;
    export function readNs4DefsJson<T>(fileInfo: Ns4FileInfo, required?: boolean): Promise<T | null>;
    /**
     * The classic L4 emission of E9. These artifacts are plain data the consumers parse, so they are
     * written as untyped defs: the ns4 artifact interfaces describe the ns4 model, not the classic wire.
     */
    export function writeNs4ClassicWorkspace(moduleName: string, workspaceId: string, value: unknown): Promise<string>;
    export function writeNs4Operation(moduleName: string, operationId: string, value: unknown): Promise<string>;
    export function writeNs4SiteMap(moduleName: string, value: unknown): Promise<string>;
    /** A bffCall contract is already TypeScript source; E9 hands it over verbatim. */
    export function writeNs4ClassicContract(moduleName: string, workspaceId: string, bffId: string, source: string): Promise<string>;
    export function writeNs4WorkspaceModel(moduleName: string, model: unknown): Promise<string>;
    export function assertNs4ShortName(shortName: string): void;
    /**
     * Archives the module's whole l4/l5 through the platform channel (`libStor.deleteFile`): a persisted file
     * becomes `status: 'deleted'` and a never-saved one is removed. Nothing is unlinked outside that channel.
     *
     * 11/09/2026: on the host CLI this was a rewrite, not an unlink (same class as Q1 / ns5_11).
     * NS4 is frozen — do not change this path. Host `localStor.deleteFile` + libStor capability
     * branch fix the class for NS5 and later callers; NS4 still uses the Studio trash write.
     */
    export function archiveNs4ModuleForRebuild(moduleName: string): Promise<string[]>;
    /**
     * `/rebuild all`: recover-prompt is the caller's job. This applies the already-planned wipe through
     * `libStor.deleteFile` (same channel as a total `/rebuild`) and writes the stripped project/config.
     */
    export function applyNs4RebuildAll(plan: Extract<ReturnType<typeof planNs4RebuildAll>, {
        ok: true;
    }>): Promise<Ns4RebuildAllReport>;
}
declare module "_102035_/l2/agentExportSolution/helpers/storedZip" {
    export interface ZipEntry {
        path: string;
        content: string | Uint8Array;
    }
    export function encodeStoredZip(entries: ZipEntry[]): Uint8Array;
    export function decodeStoredZip(bytes: Uint8Array): Array<{
        path: string;
        content: Uint8Array;
    }>;
    export function zipBytesToBinaryString(bytes: Uint8Array): string;
}
declare module "_102035_/l2/agentExportSolution/helpers/packSolution" {
    import { TEXT_PATHS_VERSION } from "_102035_/l2/agentNewSolution/helpers/ns4TextPaths";
    import { type ZipEntry } from "_102035_/l2/agentExportSolution/helpers/storedZip";
    export const SOLUTION_MANIFEST_SCHEMA: "2026-09-09-solution-v1";
    export const PROJECT_PLACEHOLDER: "{project}";
    export interface SolutionModuleInput {
        moduleName: string;
        sourceLanguage: string;
        sourcePrompt: string;
        files: Array<{
            relativePath: string;
            content: string;
        }>;
    }
    export interface SolutionPackInput {
        modules: SolutionModuleInput[];
        sourceProjectId: number;
        level1SchemaVersion: string;
        level1Roles: Array<{
            mdmSubtype: string;
            role: string;
            namespace: string;
        }>;
        actors: Array<{
            moduleName: string;
            actorId: string;
            kind: string;
        }>;
        platformCommit: string;
        catalogDescription?: string;
    }
    export interface SolutionManifest {
        schemaVersion: typeof SOLUTION_MANIFEST_SCHEMA;
        textPathsVersion: typeof TEXT_PATHS_VERSION;
        platformCommit: string;
        sourceProjectPlaceholder: typeof PROJECT_PLACEHOLDER;
        level1SchemaVersion: string;
        sourceLanguage: string;
        catalog: {
            description: string;
        };
        modules: Array<{
            moduleName: string;
            order: number;
            sourceLanguage: string;
            sourcePrompt: string;
            schemaVersionByArtifact: Record<string, string>;
        }>;
        level1Roles: SolutionPackInput['level1Roles'];
        actors: SolutionPackInput['actors'];
    }
    export interface PackedSolution {
        manifest: SolutionManifest;
        files: ZipEntry[];
        /** module → language → file-relative → json-path → text */
        i18n: Record<string, Record<string, Record<string, Record<string, string>>>>;
    }
    export function parseExportInvocation(userPrompt: string): string[];
    export function packSolution(input: SolutionPackInput): PackedSolution;
    export function packSolutionZip(packed: PackedSolution): Uint8Array;
    export function parseArtifact(source: string): Record<string, unknown> | null;
    export function stripRecomputableHashes<T>(value: T): T;
    export function recomputeArtifactHashes(artifact: Record<string, unknown>): Promise<Record<string, unknown>>;
    export function reinjectPackedModule(packedFiles: ZipEntry[], moduleName: string, language: string, i18n: Record<string, string>): ZipEntry[];
    export function restoreL4Header(source: string, projectId: number): string;
    export function normalizeL4Header(source: string, sourceProjectId: number): string;
    export function isPipelinePath(relativePath: string): boolean;
}
declare module "_102035_/l2/agentExportSolution/agentExportSolution" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { parseExportInvocation } from "_102035_/l2/agentExportSolution/helpers/packSolution";
    export function createAgent(): IAgentAsync;
    export { parseExportInvocation };
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/module.defs" {
    export const ordenServicioEsModule: {
        readonly schemaVersion: "2026-08-06-ns4-module-v4";
        readonly presentation: {
            readonly userLanguage: "es";
            readonly stepTitles: {
                readonly "e1-clarification": "Defina el módulo";
                readonly "e1-compile": "Compile el módulo";
                readonly "e2-journeys": "Revise las jornadas";
                readonly "e3-access-matrix": "Revise los accesos";
                readonly "e4-ontology": "Revise los datos";
                readonly "e4b-access-realization": "Realice los accesos";
                readonly "e5-rules": "Revise las reglas";
                readonly "e6-behaviors": "Revise módulos y plugins";
                readonly "e7-realization": "Revise la realización";
                readonly "e8-workspaces": "Revise los espacios";
                readonly "e9-navigation-compiler": "Compile la navegación";
                readonly "e10-validation": "Valide la solución";
            };
            readonly phrases: {
                readonly "catalogue.list.title": "Listar {entity}";
                readonly "catalogue.create.story": "Completar el registro nuevo.";
            };
        };
        readonly module: {
            readonly moduleName: "ordenServicioEs";
            readonly title: "Orden de servicio";
            readonly purpose: "Registrar la recepción de un aparato y dejar la orden disponible para diagnóstico.";
            readonly languages: ["es"];
        };
        readonly designContext: {
            readonly initialPrompt: "crear el módulo ordenServicio, en español, para un servicio técnico de electrónica.";
            readonly clarification: {
                readonly mainActors: "recepcionista, técnico y cliente";
                readonly mainGoal: "Abrir una orden de servicio con los datos del cliente y el aparato.";
                readonly boundaries: "Sin pago, garantía ni stock de piezas.";
            };
        };
        readonly reviewPolicy: {
            readonly mode: "automatic";
        };
        readonly solutionStrategy: {
            readonly mode: "newSolution";
            readonly rationale: "Solución nueva para el taller.";
            readonly databaseChangePolicy: "new";
        };
        readonly businessScope: {
            readonly mainGoal: "Registrar la recepción del aparato y dejar la orden disponible.";
            readonly actors: [{
                readonly actorId: "recepcionista";
                readonly title: "Recepcionista";
                readonly kind: "internal";
                readonly origin: "named";
                readonly expectedOutcome: "La orden queda abierta.";
            }, {
                readonly actorId: "tecnico";
                readonly title: "Técnico";
                readonly kind: "internal";
                readonly origin: "named";
                readonly expectedOutcome: "El diagnóstico queda registrado.";
            }, {
                readonly actorId: "cliente";
                readonly title: "Cliente";
                readonly kind: "external";
                readonly origin: "named";
                readonly expectedOutcome: "Consulta sólo sus propias órdenes.";
            }];
            readonly expectedOutcomes: [{
                readonly outcomeId: "ordenAbierta";
                readonly title: "Orden abierta";
                readonly description: "Existe una orden con cliente, aparato y defecto.";
            }];
            readonly inScope: ["Recepción del aparato", "Diagnóstico y presupuesto"];
            readonly outOfScope: ["Pago", "Garantía"];
        };
        readonly localization: {
            readonly productLanguages: ["es"];
            readonly defaultLanguage: "es";
            readonly primaryMarket: "España";
        };
        readonly declaredConstraints: {
            readonly mandatoryIntegrations: [];
            readonly regulatoryNotes: "El cliente no ve el costo interno.";
            readonly criticalNotes: "Fotos del aparato en la recepción.";
        };
        readonly specStatus: {
            readonly flowId: "agentNewSolution";
            readonly flowVersion: "2026-09-08-ns4-flow-v41";
            readonly state: "complete";
            readonly artifactCompleteness: "full";
            readonly completedSteps: [];
            readonly nextStep: "complete";
            readonly updatedAt: "2026-09-09T00:00:00.000Z";
        };
    };
    export type OrdenServicioEsModuleType = typeof ordenServicioEsModule;
    export default ordenServicioEsModule;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/siteMap.defs" {
    export const ordenServicioEsSiteMap: {
        readonly moduleName: "ordenServicioEs";
        readonly note: "Site map (permanent page index) — workspaces, landings and advisory edges.";
        readonly workspaces: readonly [{
            readonly workspaceId: "ordenServicioHub";
            readonly title: "Panel de órdenes";
            readonly actors: readonly ["recepcionista"];
            readonly kind: "landing";
            readonly entity: "OrdenServicio";
            readonly operationIds: readonly ["createOrdenServicio"];
            readonly purpose: "Central de comando de la orden de servicio.";
        }];
        readonly landings: readonly [{
            readonly actorId: "recepcionista";
            readonly workspaceId: "ordenServicioHub";
            readonly reason: "Central de comando de la orden de servicio.";
        }];
        readonly navigationEdges: readonly [];
        readonly workspaceIds: readonly ["ordenServicioHub"];
    };
    export default ordenServicioEsSiteMap;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/workspace-model.defs" {
    export const ordenServicioEsWorkspaceModel: {
        readonly planId: "e8-workspace-model";
        readonly schemaVersion: "2026-08-14-ns4-e8-model-v1";
        readonly moduleName: "ordenServicioEs";
        readonly userLanguage: "es";
        readonly title: "Espacios de trabajo";
        readonly reviewRound: 1;
        readonly hubEntity: "OrdenServicio";
        readonly workspaces: readonly [{
            readonly workspaceId: "ordenServicioHub";
            readonly tier: "hub";
            readonly title: "Panel de órdenes";
            readonly purpose: "Central de comando de la orden de servicio.";
            readonly kind: "landing";
            readonly entity: "OrdenServicio";
            readonly actors: readonly ["recepcionista"];
            readonly profileRefs: readonly ["recepcionista"];
            readonly featureRefs: readonly [];
            readonly hostedStepRefs: readonly [];
            readonly categoryRef: "entityHub";
            readonly bffCalls: readonly [];
            readonly sections: readonly [{
                readonly sectionId: "lista";
                readonly intent: "Encontrar la orden y su presupuesto.";
                readonly organisms: readonly [];
            }];
        }];
        readonly operations: readonly [{
            readonly operationId: "createOrdenServicio";
            readonly title: "Crear orden de servicio";
            readonly kind: "command";
            readonly entityRef: "OrdenServicio";
            readonly entityRefs: readonly ["OrdenServicio"];
            readonly accessPattern: {
                readonly kind: "create";
            };
            readonly inputs: readonly [{
                readonly inputId: "defectoInformado";
                readonly fieldRef: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldId: "defectoInformado";
                };
                readonly source: "userInput";
                readonly required: true;
                readonly description: "El defecto que el cliente describe.";
            }];
            readonly outputRefs: readonly [];
            readonly useRules: readonly [];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Completar el registro nuevo."];
            readonly authorityRefs: readonly ["ordenservicioes:abrir"];
        }];
        readonly menu: readonly [{
            readonly workspaceId: "ordenServicioHub";
            readonly label: "Órdenes";
            readonly featureRef: "abrirOrden";
            readonly tier: "hub";
            readonly profileRefs: readonly ["recepcionista"];
        }];
        readonly landings: readonly [{
            readonly profileRef: "recepcionista";
            readonly workspaceId: "ordenServicioHub";
            readonly reason: "exclusive";
        }];
        readonly systemDecisions: readonly [];
    };
    export default ordenServicioEsWorkspaceModel;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/access/access-bindings.defs" {
    export const ordenServicioEsAccessBindings: {
        readonly schemaVersion: "2026-09-08-ns4-access-bindings-v1";
        readonly moduleName: "ordenServicioEs";
        readonly compiledFromAccessHash: "sha256:00";
        readonly compiledFromOntologyHash: "sha256:00";
        readonly bindings: [{
            readonly profileRef: "cliente";
            readonly authorityRef: "ordenservicioes:abrir";
            readonly entityRef: "OrdenServicio";
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Sólo las órdenes del propio cliente.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Estado, diagnóstico y valor del presupuesto.";
                readonly allowedInformation: ["Estado", "Diagnóstico", "Valor del presupuesto"];
                readonly deniedInformation: ["Costo interno de las piezas"];
            };
            readonly anchor: any;
            readonly anchorReason: "El cliente entra por el usuario de la plataforma.";
        }];
        readonly synthesizedAuthorities: [];
        readonly bindingsHash: "sha256:00";
    };
    export type OrdenServicioEsAccessBindingsType = typeof ordenServicioEsAccessBindings;
    export default ordenServicioEsAccessBindings;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/access/access-matrix.defs" {
    export const ordenServicioEsAccessMatrix: {
        readonly schemaVersion: "2026-08-09-ns4-access-matrix-v2";
        readonly moduleName: "ordenServicioEs";
        readonly userLanguage: "es";
        readonly title: "Matriz de acceso — Orden de servicio";
        readonly profiles: [{
            readonly profileId: "recepcionista";
            readonly title: "Recepcionista";
            readonly kind: "internal";
            readonly description: "Abre órdenes y entrega el aparato.";
            readonly actorRefs: ["recepcionista"];
            readonly landingIntent: "Abrir una orden de recepción.";
        }, {
            readonly profileId: "cliente";
            readonly title: "Cliente";
            readonly kind: "external";
            readonly description: "Consulta sólo sus propias órdenes.";
            readonly actorRefs: ["cliente"];
            readonly landingIntent: "Ver el estado de mis órdenes y el presupuesto.";
        }];
        readonly authorities: [{
            readonly authorityRef: "ordenservicioes:abrir";
            readonly title: "Abrir orden";
            readonly description: "Permite registrar la recepción del aparato.";
            readonly journeyStepRefs: ["abrirOrden.registrarOrden"];
            readonly informationNeeds: ["Datos del cliente y del aparato"];
        }];
        readonly grants: [{
            readonly profileRef: "recepcionista";
            readonly authorityRef: "ordenservicioes:abrir";
            readonly reason: "El recepcionista abre la orden en el mostrador.";
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todas las órdenes del taller.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Registro completo, incluido el costo interno.";
                readonly allowedInformation: ["Todo el registro"];
                readonly deniedInformation: [];
            };
            readonly useRules: [];
        }, {
            readonly profileRef: "cliente";
            readonly authorityRef: "ordenservicioes:abrir";
            readonly reason: "El cliente consulta el presupuesto desde el portal.";
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Sólo las órdenes del propio cliente.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Estado, diagnóstico y valor del presupuesto.";
                readonly allowedInformation: ["Estado", "Diagnóstico", "Valor del presupuesto"];
                readonly deniedInformation: ["Costo interno de las piezas", "Anotaciones técnicas internas"];
            };
            readonly useRules: ["clienteSoloConsultaSusOrdenes"];
        }];
        readonly accessHash: "sha256:00";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-09T00:00:00.000Z";
        readonly realization: {
            readonly status: "pending";
            readonly compiledFromAccessHash: "sha256:00";
            readonly operationAuthorityRefs: [];
        };
    };
    export type OrdenServicioEsAccessMatrixType = typeof ordenServicioEsAccessMatrix;
    export default ordenServicioEsAccessMatrix;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/composition/additional-capabilities.defs" {
    export const ordenServicioEsAdditionalCapabilities: {
        readonly schemaVersion: "2026-08-09-ns4-composition-v1";
        readonly moduleName: "ordenServicioEs";
        readonly userLanguage: "es";
        readonly analysisSummary: "No hace falta un módulo hermano: el taller opera solo la orden de servicio.";
        readonly recommendations: [];
        readonly compositionHash: "sha256:00";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-09T00:00:00.000Z";
        readonly realization: {
            readonly status: "pending";
            readonly compiledFromCompositionHash: "sha256:00";
        };
    };
    export type OrdenServicioEsAdditionalCapabilitiesType = typeof ordenServicioEsAdditionalCapabilities;
    export default ordenServicioEsAdditionalCapabilities;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/journeys/abrirOrden.defs" {
    export const abrirOrdenJourney: {
        readonly schemaVersion: "2026-08-14-ns4-journey-v5";
        readonly journeyId: "abrirOrden";
        readonly revision: 1;
        readonly business: {
            readonly actorRef: "recepcionista";
            readonly title: "Abrir orden de servicio";
            readonly goal: "Registrar la recepción del aparato y dejar la orden disponible.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "registrarOrden";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly title: "Registrar orden";
                readonly description: "Captura cliente, aparato, defecto informado y fotos.";
                readonly featureRefs: ["abrirOrden"];
            }];
            readonly outcome: {
                readonly statement: "Existe una orden con cliente, aparato y defecto.";
                readonly evidence: ["La orden queda abierta para diagnóstico."];
            };
            readonly useRules: ["clienteSoloConsultaSusOrdenes"];
        };
        readonly policyDecisions: [];
        readonly businessHash: "sha256:00";
        readonly resolution: {
            readonly status: "pending";
            readonly contexts: {};
        };
        readonly realization: {
            readonly status: "pending";
            readonly compiledFromBusinessHash: "sha256:00";
            readonly steps: [];
            readonly transitionRefs: [];
        };
    };
    export type AbrirOrdenJourneyType = typeof abrirOrdenJourney;
    export default abrirOrdenJourney;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/journeys/index.defs" {
    export const ordenServicioEsJourneyIndex: {
        readonly schemaVersion: "2026-08-15-ns4-journey-index-v7";
        readonly moduleName: "ordenServicioEs";
        readonly approvedAt: "2026-09-09T00:00:00.000Z";
        readonly approvedBy: "auto";
        readonly journeys: [{
            readonly journeyId: "abrirOrden";
            readonly actorRef: "recepcionista";
            readonly title: "Abrir orden de servicio";
            readonly goal: "Registrar la recepción del aparato y dejar la orden disponible.";
            readonly entryMode: "coldStart";
            readonly businessHash: "sha256:00";
            readonly artifactPath: "l4/ordenServicioEs/journeys/abrirOrden.defs.ts";
        }];
        readonly features: [{
            readonly featureId: "abrirOrden";
            readonly title: "Abrir orden";
            readonly priority: "now";
            readonly journeyStepRefs: ["abrirOrden.registrarOrden"];
        }];
        readonly systemDecisions: [{
            readonly decisionId: "keepReceptionPhotos";
            readonly stage: "e2";
            readonly question: "¿Las fotos de recepción son obligatorias?";
            readonly chosen: "Sí, al menos una foto del aparato.";
            readonly alternatives: ["Sí, al menos una foto del aparato.", "Opcional"];
            readonly decidedBy: "system";
            readonly findingRef: "photos";
            readonly changeHint: "Pida no exigir fotos si el taller no las usa.";
        }];
    };
    export type OrdenServicioEsJourneyIndexType = typeof ordenServicioEsJourneyIndex;
    export default ordenServicioEsJourneyIndex;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/ontology/OrdenServicio.defs" {
    export const ordenServicioEsEntityOrdenServicio: {
        readonly schemaVersion: "2026-09-08-ns4-ontology-v7";
        readonly moduleName: "ordenServicioEs";
        readonly userLanguage: "es";
        readonly solutionMode: "new";
        readonly entityId: "OrdenServicio";
        readonly title: "Orden de servicio";
        readonly description: "Registro de recepción, diagnóstico y presupuesto de un aparato.";
        readonly kind: "core";
        readonly ownership: "moduleOwned";
        readonly party: "none";
        readonly sourceRefs: {
            readonly journeyIds: ["abrirOrden"];
            readonly featureIds: ["abrirOrden"];
            readonly authorityRefs: ["ordenservicioes:abrir"];
        };
        readonly fields: [{
            readonly fieldId: "ordenServicioId";
            readonly title: "Identificador de la orden";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador estable de la orden de servicio.";
            readonly constraints: [];
        }, {
            readonly fieldId: "defectoInformado";
            readonly title: "Defecto informado";
            readonly type: "text";
            readonly required: true;
            readonly description: "El defecto que el cliente describe en la recepción.";
            readonly constraints: [];
        }];
        readonly lifecycleStates: [{
            readonly state: "abierta";
            readonly reachedBy: "actor";
        }, {
            readonly state: "cerrada";
            readonly reachedBy: "actor";
        }];
        readonly lifecycleLabels: [{
            readonly code: "abierta";
            readonly label: "Abierta";
        }, {
            readonly code: "cerrada";
            readonly label: "Cerrada";
        }];
        readonly lifecyclePredicates: [];
        readonly useRules: ["clienteSoloConsultaSusOrdenes"];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "ordenServicioId";
            readonly notes: "Tabla del módulo, no del maestro.";
        };
        readonly ontologyHash: "sha256:00";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-09T00:00:00.000Z";
    };
    export type OrdenServicioEsEntityOrdenServicioType = typeof ordenServicioEsEntityOrdenServicio;
    export default ordenServicioEsEntityOrdenServicio;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/ontology/index.defs" {
    export const ordenServicioEsOntologyIndex: {
        readonly schemaVersion: "2026-09-08-ns4-ontology-v7";
        readonly moduleName: "ordenServicioEs";
        readonly userLanguage: "es";
        readonly solutionMode: "new";
        readonly title: "Ontología — Orden de servicio";
        readonly businessDomain: "Taller de electrónica: recepción, diagnóstico y presupuesto.";
        readonly entities: [{
            readonly entityId: "OrdenServicio";
            readonly title: "Orden de servicio";
            readonly kind: "core";
            readonly storage: {
                readonly target: "moduleDatabase";
                readonly scope: "module";
                readonly idField: "ordenServicioId";
            };
            readonly definitionRef: "l4/ordenServicioEs/ontology/OrdenServicio.defs.ts";
        }];
        readonly relationships: [{
            readonly relationshipId: "ordenTieneCliente";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "Cliente";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada orden pertenece a un único cliente.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["clienteId"];
                };
                readonly to: {
                    readonly entityId: "Cliente";
                    readonly fieldIds: ["clienteId"];
                };
                readonly description: "La orden apunta al cliente dueño del aparato.";
            };
        }];
        readonly ontologyHash: "sha256:00";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-09T00:00:00.000Z";
        readonly realization: {
            readonly status: "pending";
            readonly compiledFromOntologyHash: "sha256:00";
        };
    };
    export type OrdenServicioEsOntologyIndexType = typeof ordenServicioEsOntologyIndex;
    export default ordenServicioEsOntologyIndex;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/operations/createOrdenServicio.defs" {
    export const operationCreateOrdenServicio: {
        readonly operationId: "createOrdenServicio";
        readonly title: "Crear orden de servicio";
        readonly actors: readonly ["recepcionista"];
        readonly entity: "OrdenServicio";
        readonly kind: "create";
        readonly reads: readonly ["OrdenServicio"];
        readonly writes: readonly ["OrdenServicio"];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "recepcionista";
            readonly goal: "Crear orden de servicio";
            readonly steps: readonly ["Completar el registro nuevo."];
            readonly outcome: "La orden queda abierta.";
        };
        readonly accessPattern: {
            readonly kind: "create";
            readonly description: "Crear orden de servicio";
            readonly entity: "OrdenServicio";
            readonly keyField: "OrdenServicio.ordenServicioId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["OrdenServicio.ordenServicioId"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [];
        };
        readonly inputs: readonly [{
            readonly inputId: "defectoInformado";
            readonly fieldRef: "OrdenServicio.defectoInformado";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "El defecto que el cliente describe en la recepción.";
        }];
        readonly pageId: "ordenServicioHub";
        readonly commandName: "cmdCreateOrdenServicio";
        readonly bffName: "cmdCreateOrdenServicio";
    };
    export default operationCreateOrdenServicio;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/rules/rules.defs" {
    export const ordenServicioEsRules: {
        readonly schemaVersion: "2026-08-09-ns4-rules-v2";
        readonly moduleName: "ordenServicioEs";
        readonly userLanguage: "es";
        readonly rules: [{
            readonly id: "clienteSoloConsultaSusOrdenes";
            readonly description: "El cliente ve sólo sus propias órdenes, sin el costo interno de las piezas ni las anotaciones técnicas.";
        }];
        readonly rulesHash: "sha256:00";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-09T00:00:00.000Z";
        readonly realization: {
            readonly status: "pending";
            readonly compiledFromRulesHash: "sha256:00";
        };
    };
    export type OrdenServicioEsRulesType = typeof ordenServicioEsRules;
    export default ordenServicioEsRules;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/usecases/index.defs" {
    export const ordenServicioEsUseCaseIndex: {
        readonly schemaVersion: "2026-09-09-ns4-usecase-index-v4";
        readonly moduleName: "ordenServicioEs";
        readonly userLanguage: "es";
        readonly sourceHashes: {
            readonly journeys: [{
                readonly journeyId: "abrirOrden";
                readonly businessHash: "sha256:00";
            }];
            readonly ontologyHash: "sha256:00";
            readonly rulesHash: "sha256:00";
        };
        readonly useCases: [{
            readonly useCaseId: "registrarOrden";
            readonly title: "Registrar orden de servicio";
            readonly kind: "command";
            readonly compiledFrom: ["abrirOrden.registrarOrden"];
            readonly useCaseHash: "sha256:00";
            readonly artifactPath: "l4/ordenServicioEs/usecases/registrarOrden.defs.ts";
        }];
        readonly realizationHash: "sha256:00";
        readonly generatedAt: "2026-09-09T00:00:00.000Z";
        readonly systemDecisions: [];
    };
    export type OrdenServicioEsUseCaseIndexType = typeof ordenServicioEsUseCaseIndex;
    export default ordenServicioEsUseCaseIndex;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/usecases/registrarOrden.defs" {
    export const registrarOrdenUseCase: {
        readonly schemaVersion: "2026-09-09-ns4-usecase-v4";
        readonly moduleName: "ordenServicioEs";
        readonly useCaseId: "registrarOrden";
        readonly title: "Registrar orden de servicio";
        readonly kind: "command";
        readonly compiledFrom: ["abrirOrden.registrarOrden"];
        readonly description: "Registra la recepción del aparato con cliente, defecto informado y fotos.";
        readonly contexts: {
            readonly requires: [];
            readonly provides: ["selectedOrdenServicio"];
        };
        readonly entityRefs: ["OrdenServicio"];
        readonly writes: [{
            readonly entityId: "OrdenServicio";
        }];
        readonly useRules: ["clienteSoloConsultaSusOrdenes"];
        readonly transitionRefs: [];
        readonly useCaseHash: "sha256:00";
    };
    export type RegistrarOrdenUseCaseType = typeof registrarOrdenUseCase;
    export default registrarOrdenUseCase;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/workflows/ordenServicioLifecycle.defs" {
    export const ordenServicioLifecycleWorkflow: {
        readonly schemaVersion: "2026-08-11-ns4-workflow-v4";
        readonly moduleName: "ordenServicioEs";
        readonly workflowId: "ordenServicioLifecycle";
        readonly entityRef: "OrdenServicio";
        readonly initialState: "abierta";
        readonly terminalStates: ["cerrada"];
        readonly states: ["abierta", "cerrada"];
        readonly transitions: [];
        readonly workflowHash: "sha256:00";
    };
    export type OrdenServicioLifecycleWorkflowType = typeof ordenServicioLifecycleWorkflow;
    export default ordenServicioLifecycleWorkflow;
}
declare module "_102035_/l2/agentExportSolution/fixtures/ordenServicioEs/workspaces/ordenServicioHub.defs" {
    export const ordenServicioHubWorkspace: {
        readonly workspaceId: "ordenServicioHub";
        readonly title: "Panel de órdenes";
        readonly actors: readonly ["recepcionista"];
        readonly kind: "landing";
        readonly entity: "OrdenServicio";
        readonly bffCalls: readonly [];
        readonly sections: readonly [{
            readonly sectionId: "lista";
            readonly intent: "Encontrar la orden y su presupuesto.";
            readonly organisms: readonly [];
        }];
        readonly operationIds: readonly ["createOrdenServicio"];
        readonly purpose: "Central de comando de la orden de servicio.";
        readonly presentation: {
            readonly categoryRef: "entityHub";
            readonly confidence: 1;
            readonly classificationNote: "Hub de la orden.";
        };
        readonly sliceHash: "sha256:00";
    };
    export default ordenServicioHubWorkspace;
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
        senderDeviceId?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        subscription?: PushSubscriptionData;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface PushSubscriptionData {
        endpoint: string;
        keys: {
            p256dh: string;
            auth: string;
        };
        expirationTime?: number | null;
    }
    export interface UserNotifications {
        deviceId: string;
        subscription: PushSubscriptionData;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message, PushSubscriptionData } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getPushSubscriptionForBackend?(): Promise<PushSubscriptionData | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getPushSubscriptionForBackend: () => Promise<PushSubscriptionData>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "custom" | "default";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102036_/l2/shared/api" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
    export function msgApplyIntents(args: Omit<msg.RequestApplyIntents, "action">): Promise<msg.ResponseApplyIntents>;
    export function msgAppendLongTermMemory(args: Omit<msg.RequestAppendLongTermMemory, "action">): Promise<msg.ResponseAppendLongTermMemory>;
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { msgApplyIntents } from "_102036_/l2/shared/api";
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    /** Browser keeps IndexedDB. CLI calls setOrchestrationStorage before loadAgent/pooling. */
    export type OrchestrationStorage = {
        addOrUpdateTask(task: mls.msg.TaskData): Promise<void>;
        getTask(taskId: string): Promise<mls.msg.TaskData | undefined>;
        getMessage(messageId: string): Promise<mls.msg.Message | undefined>;
        addPooling(pooling: {
            taskId: string;
            userId: string;
            startAt: string;
        }): Promise<void>;
        deletePooling(taskId: string): Promise<void>;
        /**
         * The browser (IndexedDB) returns the updated thread; a host with no thread cache returns
         * nothing. Declared as the type the consumer actually needs — `unknown` compiled here and
         * broke at the two call sites that hand the result to `notifyThreadChange`.
         */
        updateThreadPendingTasks(threadId: string, taskId?: string): Promise<mls.msg.Thread | undefined>;
    };
    export function setOrchestrationStorage(next: OrchestrationStorage | null): void;
    type ApplyIntentsFn = typeof msgApplyIntents;
    /** CLI injects Bearer POST /msg. Browser never calls this. */
    export function setApplyIntents(fn: ApplyIntentsFn | null): void;
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    type OrchestrationListener = (event: OrchestrationEvent) => void;
    /** CLI / tests. Browser never subscribes — executeBeforePrompt still swallows the stream. */
    export function subscribeOrchestrationEvents(listener: OrchestrationListener): () => void;
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102035_/l2/agentNewSolution/widgets/clarification" {
    /** Public contract shared by the clarification widgets. The agent consumes it; it is not a widget-internal detail. */
    export type Ns4ClarificationAction = 'approve' | 'requestChanges' | 'cancel';
    export type Ns4ClarificationIssue = {
        code: string;
        message: string;
        path?: string;
    };
    export type Ns4ClarificationFeedback = {
        kind: 'error' | 'success' | 'information';
        message: string;
        issues?: Ns4ClarificationIssue[];
    };
    export type Ns4ClarificationEvent<TReview> = {
        action: Ns4ClarificationAction;
        review: TReview;
        adjustment: string;
    };
    export interface Ns4ClarificationWidgetApi {
        msgError: string;
        msgOk: string;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
    }
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Clarification" {
    import type { Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import type { Ns4ClarificationFeedback, Ns4ClarificationIssue } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export function bindNs4ClarificationWidget<T>(element: HTMLElement, value: T, presentation?: Ns4PhraseHolder): void;
    export function setNs4ClarificationFeedback(element: HTMLElement, feedback: Ns4ClarificationFeedback | null): void;
    export function setNs4ClarificationSubmitting(element: HTMLElement, submitting: boolean): void;
    export function showNs4ClarificationError(element: HTMLElement, error: unknown, issues?: Ns4ClarificationIssue[]): void;
}
declare module "_102035_/l2/agentNewSolution/helpers/organizationContext" {
    import type { MdmPlatformCatalogArtifact, Ns4Level1EntityArtifact, Ns4Level1IndexArtifact, Ns4SolutionRegistryArtifact } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export function formatNs4E1OrganizationContext(registry: Ns4SolutionRegistryArtifact | null): string;
    export function formatNs4E6OrganizationContext(registry: Ns4SolutionRegistryArtifact | null): string;
    export function formatNs4E4OrganizationContext(registry: Ns4SolutionRegistryArtifact | null): string;
    export function formatPlatformCatalogPrompt(platform: MdmPlatformCatalogArtifact): string;
    export function formatNs4Level1CatalogPrompt(catalog: {
        index: Ns4Level1IndexArtifact;
        entities: readonly Ns4Level1EntityArtifact[];
        platform?: MdmPlatformCatalogArtifact;
    }): string;
}
declare module "_102035_/l2/agentNewSolution/steps/e1/gate" {
    import { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export interface Ns4GateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns4E1GateResult {
        ok: boolean;
        issues: Ns4GateIssue[];
    }
    export function validateNs4E1Module(artifact: Ns4ModuleArtifact): Ns4E1GateResult;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4FastHandoff" {
    /**
     * `/fast` chain + E1 skip. Pure: the finalize step and the E1 after-prompt hook decide from this;
     * sending the thread message is the agent's I/O, not this file's.
     */
    export const NS4_FAST_SKIP_REASON = "fast skipped clarification";
    export const NS4_FAST_HANDOFF_PLAN_ID = "fast-handoff-changeBackend";
    export const NS4_FAST_HANDOFF_AGENT = "agentChangeBackend";
    export interface Ns4E1SkippedDefaults {
        productLanguages: string[];
        defaultLanguage: string;
        moduleName: string;
        title: string;
        reviewPolicy: string;
        userLanguage: string;
        i18nWarnings?: string[];
    }
    export function isNs4FastMode(longMemory?: Record<string, unknown> | null): boolean;
    export function isNs4NochainMode(longMemory?: Record<string, unknown> | null): boolean;
    export function ns4NochainSuppressedNote(moduleName: string): string;
    export function ns4E1SkippedDefaults(review: {
        module: {
            moduleName: string;
            title: string;
        };
        localization: {
            productLanguages: readonly string[];
            defaultLanguage: string;
        };
        reviewPolicy: {
            mode: string;
        };
        userLanguage: string;
        i18nWarnings?: string[];
    }): Ns4E1SkippedDefaults;
    export function decideNs4E1Clarification(fast: boolean): 'skip' | 'open';
    export function buildNs4ChangeBackendHandoffMessage(moduleName: string): string;
    export function decideNs4FastHandoff(input: {
        fast: boolean;
        nochain: boolean;
        success: boolean;
        alreadyDispatched: boolean;
        moduleName: string;
    }): {
        dispatch: boolean;
        message: string;
        suppressed: boolean;
    };
    export type Ns4FastHandoffDegradation = {
        at: string;
        kind: 'fast-handoff-dispatch';
        reason: string;
    };
    export type Ns4FastHandoffSendResult = {
        dispatched: boolean;
        note: string;
        degradation: Ns4FastHandoffDegradation | null;
    };
    /**
     * Send + persist the `/fast` handoff. Never throws: a dispatch failure is a recorded
     * degradation so the parent step can complete (the NS work is already on disk).
     */
    export function sendNs4FastHandoff(input: {
        threadId: string | undefined;
        message: string;
        send: (threadId: string, message: string) => Promise<void>;
        persist: () => Promise<void>;
    }): Promise<Ns4FastHandoffSendResult>;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Intake" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4E1Review } from "_102035_/l2/agentNewSolution/steps/e1/contracts";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Intake102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E1Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        private adjustment;
        private submitting;
        private feedbackIssues;
        private cancelOpen;
        msgError: string;
        msgOk: string;
        private feedbackFocusPending;
        private cancelOrigin;
        private patch;
        private text;
        private updateInput;
        private selectStrategy;
        private selectReviewPolicy;
        private labels;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        updated(): void;
        private submit;
        private openCancel;
        private closeCancel;
        private trapCancel;
        private renderFeedback;
        private renderCancelDialog;
        render(): any;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-intake-102035': WidgetNs4Intake102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e1/agentNs4E1" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function loadNs4E1SystemPrompt(): Promise<string>;
    export function loadNs4StatusPrompt(message: string): Promise<string>;
    export function beforeNs4E1PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E1PromptStep(agent: unknown, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E1ClarificationStep(agent: unknown, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4StepTree" {
    /** Resolves the open phase that owns dynamically-created New Solution 4 steps. */
    export function resolveNs4MutableParent(allSteps: mls.msg.AIPayload[] | undefined, parentStep: mls.msg.AIAgentStep, phaseStep?: mls.msg.AIAgentStep): mls.msg.AIAgentStep;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/gate" {
    import type { Ns4BusinessActor } from "_102035_/l2/agentNewSolution/steps/e1/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { Ns4E2Review, Ns4JourneyProposal, Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    export const NS4_E2_DROP_INFERRED_ACTOR_CHOICE: "drop";
    export const NS4_E2_KEEP_INFERRED_ACTOR_CHOICE: "keep";
    export const NS4_E2_DECIDE_ON_READ_MODEL: "NS4_E2_DECIDE_ON_READ_MODEL";
    export interface Ns4E2DecideOnReadModelStep {
        journeyId: string;
        stepId: string;
        entity: string;
        path: string;
    }
    export interface Ns4E2GateIssue {
        code: string;
        path: string;
        message: string;
        severity?: 'warning';
    }
    export interface Ns4E2GateResult {
        ok: boolean;
        issues: Ns4E2GateIssue[];
    }
    /**
     * The E2 gate is structural only. There is no declared context graph left to validate: contexts are
     * derived downstream by helpers/ns4Context.ts from the step entity, the step kind, the journey
     * sequence and the approved ontology.
     */
    /**
     * A decide step whose entity no act step in the module writes has no state of its own to
     * transition — the E2 stand-in for a projection, which E4 is the stage that can confirm.
     */
    export function ns4E2DecideOnReadModelSteps(review: Ns4E2Review): Ns4E2DecideOnReadModelStep[];
    export function validateNs4E2Review(review: Ns4E2Review): Ns4E2GateResult;
    /**
     * Selection integrity is separate from the structural review gate because an alternative is valid
     * at the human checkpoint but must become the generated choice in the next complete rewrite.
     */
    export function validateNs4E2PolicySelections(review: Ns4E2Review, selections: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>, requireHonored?: boolean): Ns4E2GateResult;
    /**
     * Operation set of a journey: sorted unique `kind:entity`. Titles and step ids do not count —
     * persona copies of the same flow (sign-as-morador vs sign-as-visitante) hash equal.
     */
    export function ns4E2JourneyOperationKey(journey: Ns4JourneyProposal): string;
    export function ns4E2DropInferredActorDecisionId(actorId: string): string;
    export function ns4E2KeepInferredActorDecisionId(actorId: string): string;
    export function ns4E2SystemActorKeptDecisionId(actorId: string): string;
    export function isNs4E2DropInferredActorDecisionId(decisionId: string): boolean;
    export function ns4E2DroppedInferredActorIds(review: Pick<Ns4E2Review, 'systemDecisions'>): string[];
    /**
     * Inferred external actor whose steps are all also performed by another actor (or who has no
     * steps) is a persona: drop their journeys. kind:system is an integration point, never a persona.
     * origin is the only structured signal — no regex over titles.
     */
    export function applyNs4E2InferredActorDecisions(review: Ns4E2Review, actors: readonly Ns4BusinessActor[], presentation?: Ns4Presentation): Ns4E2Review;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/hookArgs" {
    export function resolveNs4E2HookArgs(args?: string, stepPrompt?: string): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ReviewPolicy" {
    /**
     * E2-E6 checkpoint policy.
     * `/fast` (longMemory.fastMode) or reviewPolicy.mode=automatic skip later reviews.
     * guided always opens. smart opens on Type A, Type B / a relevant decision, or
     * when the stage has no classified signal; it skips only-C (or empty classified)
     * stages and records autoReason "nenhum finding A" next to approvedBy=auto.
     * E1 still opens unless `/fast` (then it accepts the proposal and records the defaults).
     */
    export interface Ns4ReviewPolicyContext {
        task?: {
            iaCompressed?: {
                longMemory?: Record<string, unknown>;
            };
        };
    }
    export const NS4_SMART_SKIP_REASON: "nenhum finding A";
    export type Ns4SmartSignal = {
        available: false;
    } | {
        available: true;
        classA: boolean;
        classB: boolean;
    };
    export const NS4_UNAVAILABLE_SMART_SIGNAL: Ns4SmartSignal;
    export function isNs4AutomaticCheckpoint(context: Ns4ReviewPolicyContext, module?: {
        reviewPolicy?: {
            mode?: string;
        };
    } | null): boolean;
    export function decideNs4LaterCheckpoint(context: Ns4ReviewPolicyContext, module?: {
        reviewPolicy?: {
            mode?: string;
        };
    } | null, signal?: Ns4SmartSignal): {
        open: boolean;
        autoReason?: typeof NS4_SMART_SKIP_REASON;
    };
    /** E2 coverage records Type B as systemDecisions; journey policyDecisions are reversible choices. Type A does not reach the checkpoint. */
    export function ns4E2SmartSignal(review: {
        systemDecisions?: readonly unknown[];
        journeys?: readonly {
            policyDecisions?: readonly unknown[];
        }[];
    }): Ns4SmartSignal;
    /**
     * E4 has NO A/B vocabulary: its systemDecisions are Type C label backfills, and nothing else on the
     * review expresses "a human should look at this". That is absence of SIGNAL, not evidence that the
     * ontology is uncontroversial — so the checkpoint OPENS, per the rule "sem sinal, mostra".
     *
     * Reporting `available: true, classA/B: false` instead would hardcode "never open the ontology", and
     * because `smart` is the DEFAULT policy that would quietly remove the entity/enum review from every
     * run. When E4 gains real A/B findings, return them here and it joins the same decider.
     */
    export function ns4E4SmartSignal(_review?: {
        systemDecisions?: readonly unknown[];
    }): Ns4SmartSignal;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/coverageJudge" {
    import type { Ns4BusinessActor } from "_102035_/l2/agentNewSolution/steps/e1/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E2MechanicalCoverageReport } from "_102035_/l2/agentNewSolution/steps/e2/coverageSignals";
    export const NS4_E2_MODULE_WITHOUT_DECIDE_POLICY_ID: "moduleWithoutDecidePolicy";
    export const NS4_E2_NO_DECISION_STEP_CHOICE: "noDecisionStepInThisModule";
    export const NS4_E2_ADD_DECISION_STEP_CHOICE: "addDecisionStep";
    export const NS4_E2_DEMOTE_DECIDE_TO_RULE_ID: "demoteDecideToRule";
    export const NS4_E2_KEEP_DECIDE_STEP_CHOICE: "keepDecideStep";
    export const NS4_E2_CONVERT_TO_ACT_WITH_RULE_CHOICE: "convertToActWithRule";
    export type Ns4E2CoverageCategory = 'missingJourney' | 'missingActorJourney' | 'missingRecipientJourney' | 'missingContextAcquisition' | 'missingLookupSource' | 'missingOutcomeCoverage' | 'moduleWithoutDecide' | 'contradictoryScope';
    export interface Ns4E2CoverageIssue {
        issueId: string;
        severity: 'blocking' | 'advisory';
        category: Ns4E2CoverageCategory;
        sourceEvidence: string;
        finding: string;
        repairInstruction: string;
        relatedJourneyIds: string[];
        question: string;
        alternatives: string[];
        defaultChoice: string;
    }
    export interface Ns4E2CoverageVerdict {
        planId: 'e2-coverage-judge';
        moduleName: string;
        reviewRound: number;
        complete: boolean;
        summary: string;
        issues: Ns4E2CoverageIssue[];
        policyDecisionImpacts: Array<{
            decisionId: string;
            impact: string;
            relatedJourneyIds: string[];
        }>;
    }
    export interface Ns4E2CoverageVerdictValidation {
        ok: boolean;
        errors: string[];
    }
    export function normalizeNs4E2CoverageVerdict(value: unknown, fallbackModule?: string, fallbackRound?: number): Ns4E2CoverageVerdict;
    export function validateNs4E2CoverageVerdict(verdict: Ns4E2CoverageVerdict, expectedModule: string, expectedRound: number, mechanicalCoverage?: Ns4E2MechanicalCoverageReport, review?: Ns4E2Review): Ns4E2CoverageVerdictValidation;
    export function applyNs4E2PolicyDecisionImpacts(review: Ns4E2Review, verdict: Ns4E2CoverageVerdict): Ns4E2Review;
    export function resolveNs4E2CoverageFindings(review: Ns4E2Review, verdict: Ns4E2CoverageVerdict): Ns4E2Review;
    export function resolveNs4E2CoverageJudgeFailure(review: Ns4E2Review): Ns4E2Review;
    /**
     * Deterministic registrars recorded after the structural gate / coverage judge. Neither is a
     * blocking issue and neither may ask the generator to invent a decide step.
     */
    export function applyNs4E2RegistrarDecisions(review: Ns4E2Review, actors?: readonly Ns4BusinessActor[], presentation?: Ns4Presentation): Ns4E2Review;
    export function formatNs4E2CoverageRepairFeedback(verdict: Ns4E2CoverageVerdict): string;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/coverageRepair" {
    import { Ns4E2Feature, Ns4E2Review, Ns4JourneyProposal } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export interface Ns4E2CoveragePatch {
        planId: 'e2-coverage-patch';
        moduleName: string;
        reviewRound: number;
        journeyUpserts: Ns4JourneyProposal[];
        featureUpserts: Ns4E2Feature[];
    }
    export interface Ns4E2CoveragePatchValidation {
        ok: boolean;
        errors: string[];
    }
    export function normalizeNs4E2CoveragePatch(value: unknown, fallbackModule?: string, fallbackRound?: number, presentation?: Ns4Presentation): Ns4E2CoveragePatch;
    export function validateNs4E2CoveragePatch(patch: Ns4E2CoveragePatch, expectedModule: string, expectedRound: number, allowNoOp?: boolean): Ns4E2CoveragePatchValidation;
    export function applyNs4E2CoveragePatch(previous: Ns4E2Review, patch: Ns4E2CoveragePatch): Ns4E2Review;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Journeys" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Journeys102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E2Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        private adjustment;
        private submitting;
        private selectedActorRef;
        private selectedJourneyId;
        private activeTab;
        private selectedPolicyOptions;
        private feedbackIssues;
        private cancelOpen;
        msgError: string;
        msgOk: string;
        private feedbackFocusPending;
        private feedbackScrollPending;
        private cancelOrigin;
        private labels;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        updated(): void;
        private submit;
        private openCancel;
        private closeCancel;
        private trapCancel;
        private renderFeedback;
        private renderCancelDialog;
        render(): any;
        private selectActor;
        private actorLabel;
        private selectJourney;
        private view;
        private policyChanges;
        private submissionAdjustment;
        private policyDecisionSelections;
        private renderPolicySelector;
        private renderTab;
        private renderOverview;
        private renderSteps;
        private renderRules;
        private renderOutcome;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-journeys-102035': WidgetNs4Journeys102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e2/agentNs4E2" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E2PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E2PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E2ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ApprovedArtifacts" {
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import { Ns4E4Review, Ns4OntologyEntity, Ns4OntologyEntityArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export function readNs4ApprovedJourneys(moduleName: string): Promise<Ns4E2Review>;
    export function readNs4ApprovedAccess(moduleName: string): Promise<Ns4E3Review>;
    export function readNs4ApprovedOntology(moduleName: string): Promise<Ns4E4Review>;
    export function readNs4ApprovedOntologyEntity(moduleName: string, entityId: string): Promise<Ns4OntologyEntityArtifact | null>;
    /** Disclosure views live as ontology defs but are absent from the E4 index; load them by projectionRef. */
    export function readNs4DisclosureProjections(moduleName: string, accessBindings: Ns4AccessBindingsArtifact | undefined): Promise<Ns4OntologyEntity[]>;
}
declare module "_102035_/l2/agentNewSolution/steps/e3/gate" {
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    export interface Ns4E3GateIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E3GateResult {
        ok: boolean;
        issues: Ns4E3GateIssue[];
    }
    export function validateNs4E3Review(review: Ns4E3Review, journeys?: Ns4E2Review): Ns4E3GateResult;
}
declare module "_102035_/l2/agentNewSolution/steps/e3/hookArgs" {
    export function resolveNs4E3HookArgs(args: unknown, prompt: unknown): string;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4AccessMatrix" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4AccessMatrix102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E3Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        private adjustment;
        private submitting;
        private selectedGrantKey;
        private feedbackIssues;
        private cancelOpen;
        msgError: string;
        msgOk: string;
        private feedbackFocusPending;
        private feedbackScrollPending;
        private cancelOrigin;
        private text;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        updated(): void;
        private submit;
        private openCancel;
        private closeCancel;
        private trapCancel;
        private renderFeedback;
        private renderCancelDialog;
        private grantKey;
        private selectedGrant;
        render(): any;
        private renderDetails;
        private renderMatrix;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-access-matrix-102035': WidgetNs4AccessMatrix102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e3/agentNs4E3" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E3PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E3PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E3ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4WorkerTools" {
    /**
     * Shared mechanics for strict artifact workers.  Step-specific artifact schemas stay under
     * `schemas/`; this helper only makes their result a payload that collab-messages can schedule.
     */
    export function createNs4FlexibleWorkerTool(toolName: string, description: string, artifactSchema: Record<string, unknown>): mls.msg.LLMTool;
    /** Keeps already persisted raw worker payloads resumable while new workers use the envelope. */
    export function unwrapNs4FlexibleWorkerPayload(value: unknown): unknown;
}
declare module "_102034_/l4/organization/ontology/index.defs" {
    export const organizationLevel1Index: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly level1SchemaVersion: "ns4-level1-v2";
        readonly subtypes: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
        readonly docTypes: readonly ["SSN", "EIN", "Passport", "DriversLicense", "NationalId", "CPF", "CNPJ", "VAT", "Other"];
        readonly mdmStatuses: readonly ["Active", "Inactive", "Merged", "Blocked"];
        readonly relationshipTypes: readonly [{
            readonly type: "Owns";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment"];
            readonly bidirectional: false;
        }, {
            readonly type: "Employs";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Person"];
            readonly bidirectional: false;
        }, {
            readonly type: "OffersProduct";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Product"];
            readonly bidirectional: false;
        }, {
            readonly type: "OffersService";
            readonly from: readonly ["Company", "Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
        }, {
            readonly type: "StocksAt";
            readonly from: readonly ["Product", "AssetEquipment"];
            readonly to: readonly ["Location"];
            readonly bidirectional: false;
        }, {
            readonly type: "Teaches";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
        }, {
            readonly type: "HappensAt";
            readonly from: readonly ["Service"];
            readonly to: readonly ["Location"];
            readonly bidirectional: false;
        }, {
            readonly type: "FranchiseOf";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
        }, {
            readonly type: "BelongsToGroup";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
        }, {
            readonly type: "PartOfUnit";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
        }, {
            readonly type: "ManagedBy";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company", "Service"];
            readonly bidirectional: false;
        }, {
            readonly type: "ReportsTo";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person"];
            readonly bidirectional: false;
        }, {
            readonly type: "AssignedTo";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company", "Service"];
            readonly bidirectional: false;
        }, {
            readonly type: "Attends";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
        }, {
            readonly type: "SuppliesProduct";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Product"];
            readonly bidirectional: false;
        }, {
            readonly type: "PartnersWith";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
        }, {
            readonly type: "Family";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person"];
            readonly bidirectional: true;
        }, {
            readonly type: "GuardianOf";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person", "Animal"];
            readonly bidirectional: false;
        }, {
            readonly type: "CustomerOf";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
        }, {
            readonly type: "SupplierOf";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
        }, {
            readonly type: "MemberOf";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
        }, {
            readonly type: "HoldsAccount";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["BankAccount"];
            readonly bidirectional: false;
        }, {
            readonly type: "SubsidiaryOf";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
        }, {
            readonly type: "LocatedAt";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["AssetProperty"];
            readonly bidirectional: false;
        }, {
            readonly type: "Signed";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["Document"];
            readonly bidirectional: false;
        }, {
            readonly type: "HasContact";
            readonly from: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
            readonly to: readonly ["ContactChannel"];
            readonly bidirectional: false;
        }];
    };
    export type OrganizationLevel1IndexType = typeof organizationLevel1Index;
    export default organizationLevel1Index;
}
declare module "_102034_/l4/organization/ontology/platform.defs" {
    export const mdmPlatformCatalog: {
        readonly catalogVersion: "2026-09-11-mdm-platform-v1";
        readonly layers: readonly [{
            readonly layer: "identification";
            readonly owner: "platform";
            readonly where: "index columns";
            readonly fields: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "countryCode", "tags"];
            readonly note: "docType/docId is the legal document, UNIQUE among permanent records. Never a login.";
        }, {
            readonly layer: "base";
            readonly owner: "platform";
            readonly where: "typed keys of the subtype in the document";
            readonly fields: readonly ["contacts[]", "addresses[]", "aliases[]", "relationshipRefs", "subtype-specific fields"];
            readonly note: "Never redeclared by a module.";
        }, {
            readonly layer: "general";
            readonly owner: "organization";
            readonly where: "document key general";
            readonly fields: readonly ["promoted fields"];
            readonly note: "A field that more than one module needed; promoted by the organization; schema in the solution registry.";
        }, {
            readonly layer: "module";
            readonly owner: "the module";
            readonly where: "document key <moduleId>";
            readonly fields: readonly ["namespace fields only"];
            readonly note: "Only what nobody else needs. Never identity, document, contact, login.";
        }];
        readonly visibility: {
            readonly rule: "keys open, content closed";
            readonly read: "identification + base + general + details[ctx.moduleId] + namespaces[] (names of the other module keys, no content)";
            readonly unrestricted: "no moduleId or moduleId === 'organization' reads the full document";
            readonly write: "platform keys + general + details[ctx.moduleId]; any other module key → MDM_FOREIGN_NAMESPACE (400)";
        };
        readonly identity: {
            readonly who: "JWT: sub, email, authorities <moduleId>:<actorId>";
            readonly whereThePersonExists: "record tags/moduleTypes <moduleId>.<EntityId> and details[<moduleId>]";
            readonly login: {
                readonly storage: "mdm_tag row";
                readonly row: {
                    readonly entityType: "MdmEntity";
                    readonly entityId: "<mdmId>";
                    readonly namespace: "login";
                    readonly tag: "<login e-mail>";
                    readonly module: "organization";
                };
                readonly lookup: "findTagsByTag(entityType, tag, module) — indexed columns";
                readonly invariant: "one login e-mail → one record; one record → at most one login row";
                readonly pending: readonly ["uniqueness of (namespace=login, tag) across entities", "facade findByTag / setLogin", "invitation writes collab-auth role + login row + attachRole"];
            };
            readonly otherIdentifiers: "one mdm_tag row per identifier, one namespace each (external system id, badge, card)";
            readonly neverInModule: readonly ["login", "document", "contact"];
        };
        readonly roles: {
            readonly meaning: "kind: mdm in a module ontology = a role of that module over a level-1 subtype";
            readonly tag: "<moduleId>.<EntityId>";
            readonly createOrAttach: readonly ["findByDocument(docType, docId) or findByContact(type, value)", "create({ details }) when absent — dedups by document, returns alreadyExists", "attachRole(mdmId, role, namespace?)"];
            readonly ontologyRules: readonly ["fields[] holds namespace fields only", "storage.idField is the MDM id and stays outside fields[]", "displayField is a level-1 field or a namespace field", "no lifecycleStates, no transitions — activity is the MDM status"];
            readonly actorsAreNotRoles: "a profile (receptionist, manager) becomes a Person record only when the business records something about that person";
        };
        readonly services: readonly [{
            readonly service: "tags";
            readonly table: "mdm_tag";
            readonly rows: "many per record";
            readonly indexes: readonly ["(entityType, tag, module)", "(entityType, namespace, module)", "(module, tag)", "unique (entityType, entityId, tag, module)"];
            readonly operations: readonly ["mdm.tag.add", "mdm.tag.remove", "mdm.tag.findByEntity", "mdm.tag.findByTag"];
            readonly useFor: readonly ["secondary identifiers (login, external ids)", "module markers with a value"];
            readonly notFor: readonly ["role tags — those live in record tags[] via attachRole"];
        }, {
            readonly service: "relationships";
            readonly table: "mdm_relationship";
            readonly rows: "typed, versioned, validFrom/validTo, status";
            readonly operations: readonly ["mdm.relationship.create", "mdm.relationship.list", "mdm.relationship.update", "facade link / unlink / relatedOfMany"];
            readonly catalog: "RelationshipCatalog in ontology.ts (26 types)";
            readonly compactRefs: "relationshipRefs.<key>[] on the record for fast reads";
            readonly useFor: readonly ["a fact about two master records (responsible for, customer of, supplies)"];
            readonly notFor: readonly ["a module join entity between two master records"];
        }, {
            readonly service: "prospects";
            readonly table: "mdm_prospect_index";
            readonly rows: "transient records, duplicates allowed, TTL";
            readonly operations: readonly ["mdm.prospect.create", "mdm.prospect.get", "mdm.prospect.list", "mdm.prospect.update", "mdm.prospect.promoteToEntity"];
            readonly useFor: readonly ["leads and unqualified records before deduplication"];
        }, {
            readonly service: "comments";
            readonly operations: readonly ["mdm.comment.add", "mdm.comment.edit", "mdm.comment.remove", "mdm.comment.findByEntity"];
            readonly useFor: readonly ["notes on a master record"];
            readonly notFor: readonly ["a module Comment entity about a master record"];
        }, {
            readonly service: "attachments";
            readonly operations: readonly ["mdm.attachment.attach", "mdm.attachment.detach", "mdm.attachment.findByEntity"];
            readonly storage: "S3-backed";
            readonly useFor: readonly ["files of a master record (photos, documents)"];
            readonly notFor: readonly ["a module Photo/File entity about a master record"];
        }, {
            readonly service: "audit";
            readonly tables: readonly ["mdm audit log (every MDM write, via runMonitoredWrite)", "status history"];
            readonly operations: readonly ["audit.home.load", "audit.auditLog.load", "audit.auditLog.details", "audit.statusHistory.load"];
            readonly rule: "modules never create their own audit, log or history entities for master records";
            readonly pending: readonly ["audit of module-table writes is a platform decision, not a module entity"];
        }, {
            readonly service: "statusHistory";
            readonly operations: readonly ["mdm.statusHistory.findByEntity", "mdm.statusHistory.findLatest"];
            readonly useFor: readonly ["when a master record changed status, by whom"];
        }, {
            readonly service: "numberSequence";
            readonly operations: readonly ["mdm.numberSequence.next"];
            readonly useFor: readonly ["sequential business numbers (order number, invoice number)"];
            readonly notFor: readonly ["a module counter table"];
        }, {
            readonly service: "kv";
            readonly operations: readonly ["mdm.kv.get", "mdm.kv.put"];
            readonly useFor: readonly ["small organization-wide settings"];
            readonly notFor: readonly ["business entities"];
        }];
        readonly lookups: readonly [{
            readonly lookup: "get / getMany / hydrateMany by mdmId";
            readonly cost: "O(1) per id";
        }, {
            readonly lookup: "listByType(subtype, …)";
            readonly cost: "indexed";
        }, {
            readonly lookup: "findTagsByTag(entityType, tag, module)";
            readonly cost: "indexed — use for identifiers looked up per request";
        }, {
            readonly lookup: "findByDocument(docType, docId)";
            readonly cost: "full scan today — not for a per-request path";
        }, {
            readonly lookup: "findByContact(type, value)";
            readonly cost: "full scan today — not for a per-request path";
        }];
        readonly invariants: readonly ["a master record is never deleted: inactivate / reactivate; delete is soft (status, mergedInto)", "one legal document → one permanent record; dedup on create; merge keeps mergedInto", "a module writes only its namespace (and general when promoted)", "writes are versioned (version / expectedVersion)", "countryCode comes from the organization (ctx.organization.countryCode), never from UI language", "dependency is always module → MDM; the MDM knows no module"];
    };
    export type MdmPlatformCatalogType = typeof mdmPlatformCatalog;
    export default mdmPlatformCatalog;
}
declare module "_102034_/l4/organization/ontology/Animal.defs" {
    export const level1Animal: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "Animal";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "species";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "breed";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "birthDate";
            readonly type: "string (ISO date) | null";
            readonly required: false;
        }, {
            readonly fieldId: "sex";
            readonly type: "'Male' | 'Female' | 'Unknown' | null";
            readonly required: false;
        }, {
            readonly fieldId: "color";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "microchip";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "registrationNumber";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "isNeutered";
            readonly type: "boolean | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "GuardianOf";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["guardians", "contacts"];
    };
    export type Level1AnimalType = typeof level1Animal;
    export default level1Animal;
}
declare module "_102034_/l4/organization/ontology/AssetEquipment.defs" {
    export const level1AssetEquipment: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "AssetEquipment";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "serialNumber";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "brand";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "model";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "category";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "acquisitionDate";
            readonly type: "string (ISO date) | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "Owns";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person", "Company"];
        }, {
            readonly type: "StocksAt";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Location"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["owners", "stockLocations", "contacts"];
    };
    export type Level1AssetEquipmentType = typeof level1AssetEquipment;
    export default level1AssetEquipment;
}
declare module "_102034_/l4/organization/ontology/AssetGeneric.defs" {
    export const level1AssetGeneric: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "AssetGeneric";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "assetCategory";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "serialNumber";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "manufacturer";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "model";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "Owns";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person", "Company"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["owners", "contacts"];
    };
    export type Level1AssetGenericType = typeof level1AssetGeneric;
    export default level1AssetGeneric;
}
declare module "_102034_/l4/organization/ontology/AssetProperty.defs" {
    export const level1AssetProperty: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "AssetProperty";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "registrationNumber";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "propertyAddress";
            readonly type: "Address | null";
            readonly required: false;
        }, {
            readonly fieldId: "areaSqft";
            readonly type: "number | null";
            readonly required: false;
        }, {
            readonly fieldId: "areaM2";
            readonly type: "number | null";
            readonly required: false;
        }, {
            readonly fieldId: "propertyType";
            readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
            readonly required: false;
        }, {
            readonly fieldId: "taxParcelId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "Owns";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person", "Company"];
        }, {
            readonly type: "LocatedAt";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person", "Company"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["owners", "locatedEntities", "contacts"];
    };
    export type Level1AssetPropertyType = typeof level1AssetProperty;
    export default level1AssetProperty;
}
declare module "_102034_/l4/organization/ontology/AssetVehicle.defs" {
    export const level1AssetVehicle: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "AssetVehicle";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "plate";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "vin";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "brand";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "model";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "year";
            readonly type: "number | null";
            readonly required: false;
        }, {
            readonly fieldId: "color";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "fuelType";
            readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "Owns";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person", "Company"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["owners", "contacts"];
    };
    export type Level1AssetVehicleType = typeof level1AssetVehicle;
    export default level1AssetVehicle;
}
declare module "_102034_/l4/organization/ontology/BankAccount.defs" {
    export const level1BankAccount: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "BankAccount";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "bankRoutingNumber";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "bankName";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "accountNumber";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "accountType";
            readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
            readonly required: false;
        }, {
            readonly fieldId: "swift";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "iban";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "pixKey";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "pixKeyType";
            readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
            readonly required: false;
        }, {
            readonly fieldId: "isVerified";
            readonly type: "boolean";
            readonly required: true;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "HoldsAccount";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person", "Company"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["accountHolders", "contacts"];
    };
    export type Level1BankAccountType = typeof level1BankAccount;
    export default level1BankAccount;
}
declare module "_102034_/l4/organization/ontology/Company.defs" {
    export const level1Company: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "Company";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "companyKind";
            readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
            readonly required: true;
        }, {
            readonly fieldId: "parentCompanyId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "externalCode";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "tradeName";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "legalName";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "legalType";
            readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
            readonly required: false;
        }, {
            readonly fieldId: "foundingDate";
            readonly type: "string (ISO date) | null";
            readonly required: false;
        }, {
            readonly fieldId: "taxRegime";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "industryCode";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "website";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "Owns";
            readonly as: "from";
            readonly otherSubtypes: readonly ["AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment"];
        }, {
            readonly type: "Employs";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "OffersProduct";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Product"];
        }, {
            readonly type: "OffersService";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Service"];
        }, {
            readonly type: "FranchiseOf";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "BelongsToGroup";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "PartOfUnit";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "ManagedBy";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "AssignedTo";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "SuppliesProduct";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Product"];
        }, {
            readonly type: "PartnersWith";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "CustomerOf";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Person", "Company"];
        }, {
            readonly type: "SupplierOf";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "MemberOf";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "HoldsAccount";
            readonly as: "from";
            readonly otherSubtypes: readonly ["BankAccount"];
        }, {
            readonly type: "SubsidiaryOf";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "LocatedAt";
            readonly as: "from";
            readonly otherSubtypes: readonly ["AssetProperty"];
        }, {
            readonly type: "Signed";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Document"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["ownedAssets", "employees", "offeredProducts", "offeredServices", "franchisors", "franchisees", "groupParents", "groupMembers", "unitParents", "unitChildren", "managers", "assignees", "suppliedProducts", "partners", "suppliers", "customers", "members", "bankAccounts", "parentCompanies", "subsidiaries", "locations", "documents", "contacts"];
    };
    export type Level1CompanyType = typeof level1Company;
    export default level1Company;
}
declare module "_102034_/l4/organization/ontology/ContactChannel.defs" {
    export const level1ContactChannel: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "ContactChannel";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "contactType";
            readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
            readonly required: true;
        }, {
            readonly fieldId: "value";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "isVerified";
            readonly type: "boolean";
            readonly required: true;
        }, {
            readonly fieldId: "verifiedAt";
            readonly type: "timestamp | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "HasContact";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["contacts", "contactOwners"];
    };
    export type Level1ContactChannelType = typeof level1ContactChannel;
    export default level1ContactChannel;
}
declare module "_102034_/l4/organization/ontology/Document.defs" {
    export const level1Document: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "Document";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "originModule";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docCategory";
            readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
            readonly required: true;
        }, {
            readonly fieldId: "storageBucket";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "storagePath";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "fileName";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "mimeType";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "fileSizeKb";
            readonly type: "number | null";
            readonly required: false;
        }, {
            readonly fieldId: "issuedAt";
            readonly type: "string (ISO date) | null";
            readonly required: false;
        }, {
            readonly fieldId: "expiresAt";
            readonly type: "string (ISO date) | null";
            readonly required: false;
        }, {
            readonly fieldId: "issuer";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "Signed";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person", "Company"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["signedBy", "contacts"];
    };
    export type Level1DocumentType = typeof level1Document;
    export default level1Document;
}
declare module "_102034_/l4/organization/ontology/Location.defs" {
    export const level1Location: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "Location";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "locationType";
            readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
            readonly required: true;
        }, {
            readonly fieldId: "locationCode";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "parentLocationId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "capacity";
            readonly type: "number | null";
            readonly required: false;
        }, {
            readonly fieldId: "propertyAddress";
            readonly type: "Address | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "StocksAt";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Product", "AssetEquipment"];
        }, {
            readonly type: "HappensAt";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Service"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["stockedItems", "scheduledServices", "contacts"];
    };
    export type Level1LocationType = typeof level1Location;
    export default level1Location;
}
declare module "_102034_/l4/organization/ontology/Person.defs" {
    export const level1Person: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "Person";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "birthDate";
            readonly type: "string (ISO date) | null";
            readonly required: false;
        }, {
            readonly fieldId: "gender";
            readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
            readonly required: false;
        }, {
            readonly fieldId: "nationality";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "occupation";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "photoUrl";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "privacyConsent";
            readonly type: "PrivacyConsent | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "Owns";
            readonly as: "from";
            readonly otherSubtypes: readonly ["AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment"];
        }, {
            readonly type: "Employs";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "OffersService";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Service"];
        }, {
            readonly type: "Teaches";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Service"];
        }, {
            readonly type: "ManagedBy";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Company", "Service"];
        }, {
            readonly type: "ReportsTo";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "AssignedTo";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Company", "Service"];
        }, {
            readonly type: "Attends";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Service"];
        }, {
            readonly type: "PartnersWith";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "Family";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "GuardianOf";
            readonly as: "both";
            readonly otherSubtypes: readonly ["Person", "Animal"];
        }, {
            readonly type: "CustomerOf";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "MemberOf";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "HoldsAccount";
            readonly as: "from";
            readonly otherSubtypes: readonly ["BankAccount"];
        }, {
            readonly type: "LocatedAt";
            readonly as: "from";
            readonly otherSubtypes: readonly ["AssetProperty"];
        }, {
            readonly type: "Signed";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Document"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["ownedAssets", "employers", "offeredServices", "taughtServices", "managedOrganizations", "reportManagers", "reports", "assignments", "attendedServices", "partners", "family", "pets", "guardians", "suppliers", "memberships", "bankAccounts", "locations", "documents", "contacts"];
    };
    export type Level1PersonType = typeof level1Person;
    export default level1Person;
}
declare module "_102034_/l4/organization/ontology/Product.defs" {
    export const level1Product: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "Product";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "sku";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "productType";
            readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
            readonly required: false;
        }, {
            readonly fieldId: "category";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "brand";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "unitOfMeasure";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "isInventoried";
            readonly type: "boolean";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "OffersProduct";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "StocksAt";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Location"];
        }, {
            readonly type: "SuppliesProduct";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Company"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["productSuppliers", "stockLocations", "productVendors", "contacts"];
    };
    export type Level1ProductType = typeof level1Product;
    export default level1Product;
}
declare module "_102034_/l4/organization/ontology/Service.defs" {
    export const level1Service: {
        readonly schemaVersion: "ns4-level1-v2";
        readonly subtype: "Service";
        readonly identification: readonly [{
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "docType";
            readonly type: "DocType | null";
            readonly required: false;
        }, {
            readonly fieldId: "docId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "countryCode";
            readonly type: "string";
            readonly required: true;
        }, {
            readonly fieldId: "tags";
            readonly type: "string[]";
            readonly required: true;
        }];
        readonly baseFields: readonly [{
            readonly fieldId: "aliases";
            readonly type: "string[]";
            readonly required: true;
        }, {
            readonly fieldId: "contacts";
            readonly type: "ContactSummaryValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "addresses";
            readonly type: "AddressValue[]";
            readonly required: true;
        }, {
            readonly fieldId: "relationshipRefs";
            readonly type: "CompactRelationshipRefs";
            readonly required: true;
        }, {
            readonly fieldId: "serviceCode";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "serviceKind";
            readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
            readonly required: false;
        }, {
            readonly fieldId: "parentServiceId";
            readonly type: "string | null";
            readonly required: false;
        }, {
            readonly fieldId: "serviceType";
            readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
            readonly required: false;
        }, {
            readonly fieldId: "durationMinutes";
            readonly type: "number | null";
            readonly required: false;
        }, {
            readonly fieldId: "deliveryMode";
            readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
            readonly required: false;
        }, {
            readonly fieldId: "notes";
            readonly type: "string | null";
            readonly required: false;
        }];
        readonly allowedRelationships: readonly [{
            readonly type: "OffersService";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Company", "Person"];
        }, {
            readonly type: "Teaches";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "HappensAt";
            readonly as: "from";
            readonly otherSubtypes: readonly ["Location"];
        }, {
            readonly type: "ManagedBy";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "AssignedTo";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "Attends";
            readonly as: "to";
            readonly otherSubtypes: readonly ["Person"];
        }, {
            readonly type: "HasContact";
            readonly as: "from";
            readonly otherSubtypes: readonly ["ContactChannel"];
        }];
        readonly compactRelationshipKeys: readonly ["serviceProviders", "instructors", "serviceLocations", "managers", "assignees", "attendees", "contacts"];
    };
    export type Level1ServiceType = typeof level1Service;
    export default level1Service;
}
declare module "_102035_/l2/agentNewSolution/helpers/level1Catalog" {
    import { type MdmPlatformCatalogArtifact, type Ns4Level1EntityArtifact, type Ns4Level1IndexArtifact, type Ns4Level1Subtype } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export function ns4Level1Catalog(): {
        index: Ns4Level1IndexArtifact;
        entities: readonly Ns4Level1EntityArtifact[];
        platform: MdmPlatformCatalogArtifact;
    };
    export function ns4Level1PlatformCatalog(): MdmPlatformCatalogArtifact;
    export function ns4Level1Subtypes(): readonly Ns4Level1Subtype[];
    export function ns4Level1IsSubtype(value: string): value is Ns4Level1Subtype;
    export function ns4Level1Entity(subtype: string): Ns4Level1EntityArtifact | undefined;
    /** Identification ∪ base field ids of a level-1 subtype. Empty when the subtype is unknown. */
    export function ns4Level1FieldIds(subtype: string): ReadonlySet<string>;
    export function ns4Level1FieldSlot(subtype: string, fieldId: string): 'identification' | 'base' | undefined;
}
declare module "_102035_/l2/agentNewSolution/steps/e4/gate" {
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import { Ns4E4DerivationFieldIdChange, Ns4E4EntityDraft, Ns4E4PlanDraft, Ns4E4RelationshipBindingsDraft, Ns4E4Review, Ns4E4EntityFeedback } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export interface Ns4E4GateIssue {
        code: string;
        path: string;
        message: string;
        severity?: 'warning';
    }
    export interface Ns4E4GateResult {
        ok: boolean;
        issues: Ns4E4GateIssue[];
    }
    export interface Ns4E4GateOptions {
        requireRelationshipRealization?: boolean;
        /** E1 prompt + scope. Kept for callers; lexical derived-artifact classification was removed. */
        requestText?: string;
        /** Overview has placeholder fields; skip checks that need the entity worker's field list. */
        planOverview?: boolean;
    }
    export function validateNs4E4Review(review: Ns4E4Review, journeys?: Ns4E2Review, access?: Ns4E3Review, options?: Ns4E4GateOptions): Ns4E4GateResult;
    /** Validates the frozen cross-entity decisions before expensive entity fan-out starts. */
    export function validateNs4E4Plan(plan: Ns4E4PlanDraft, journeys?: Ns4E2Review, access?: Ns4E3Review, options?: Ns4E4GateOptions): Ns4E4GateResult;
    /** Validates that the binding pass covered every frozen semantic relationship exactly once. */
    export function validateNs4E4RelationshipBindings(review: Ns4E4Review, draft: Ns4E4RelationshipBindingsDraft, journeys?: Ns4E2Review, access?: Ns4E3Review): Ns4E4GateResult;
    /** Validates one parallel entity result against the storage/lifecycle contract frozen by the plan. */
    export function validateNs4E4EntityDraft(plan: Ns4E4PlanDraft, detail: Ns4E4EntityDraft): Ns4E4GateResult;
    export function ns4E4BlockingDerivationIssues(issues: Ns4E4GateIssue[]): Ns4E4GateIssue[];
    export function ns4E4NonDerivationBlockingIssues(issues: Ns4E4GateIssue[]): Ns4E4GateIssue[];
    export type Ns4E4FinalizeDispatch = {
        action: 'pass';
    } | {
        action: 'bindDerivations';
        issues: Ns4E4GateIssue[];
    } | {
        action: 'planRepair';
    } | {
        action: 'fail';
    };
    export function ns4E4FinalizeDispatch(issues: Ns4E4GateIssue[], derivationRepairAttempt: number, planRepairAttempt: number, maxDerivationBindingRepairs?: number, maxPlanRepairs?: number): Ns4E4FinalizeDispatch;
    export function ns4E4EntityIdFromIssuePath(review: Ns4E4Review, path: string): string;
    /**
     * Records NS4_E4_CORE_READ_ONLY warnings as Type B system decisions (`keepCore`).
     * Does not change the ontology and does not block the run.
     */
    export function applyNs4E4CoreReadOnlyDecisions(review: Ns4E4Review, issues: Ns4E4GateIssue[]): Ns4E4Review;
    /**
     * OUTPUT_FIELD findings on projections whose repaired derivation changed an aggregate fieldId.
     * Empty means fail the run: the entity-repair budget is spent, or the field list did not change.
     */
    export function ns4E4DerivationOutputEscalation(review: Ns4E4Review, issues: Ns4E4GateIssue[], fieldIdChanges: Ns4E4DerivationFieldIdChange[], entityRepairRound: number, maxEntityRepairRounds?: number): Ns4E4EntityFeedback[];
    /**
     * Binding-step findings that the entity fan-out can repair. Empty means fail the run: either the
     * binding step can still fix the issue itself, or the entity-repair budget is already spent.
     */
    export function ns4E4BindingOwnerEscalation(review: Ns4E4Review, issues: Ns4E4GateIssue[], entityRepairRound: number, maxEntityRepairRounds?: number): Ns4E4EntityFeedback[];
    /**
     * The E1 request text (prompt + scope). Kept as a typed reader for callers that still pass it
     * through gate options; classification by artifact name was removed.
     */
    export function ns4E4RequestText(module: {
        designContext?: {
            initialPrompt?: string;
            clarification?: {
                mainGoal?: string;
                boundaries?: string;
            };
        };
        businessScope?: {
            mainGoal?: string;
            inScope?: string[];
            expectedOutcomes?: Array<{
                title?: string;
                description?: string;
            }>;
        };
    } | null | undefined): string;
}
declare module "_102035_/l2/agentNewSolution/steps/e4/hookArgs" {
    export function resolveNs4E4HookArgs(args: unknown, prompt: unknown): string;
    /** Materialized parallel children have a selector arg but no prompt/planning metadata. */
    export function resolveNs4E4InvocationArgs(hookArgs: string, entityId: string): string;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Ontology" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { Ns4E4Review } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Ontology102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E4Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        private selectedEntityId;
        private activeTab;
        private adjustment;
        private submitting;
        private feedbackIssues;
        private cancelOpen;
        msgError: string;
        msgOk: string;
        private feedbackFocusPending;
        private feedbackScrollPending;
        private cancelOrigin;
        private text;
        private selectedEntity;
        private selectEntity;
        private storageLabel;
        private updateEntity;
        private updateField;
        private updateInlineField;
        private finishInlineEdit;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        updated(): void;
        private submit;
        private openCancel;
        private closeCancel;
        private trapCancel;
        private renderFeedback;
        private renderCancelDialog;
        render(): any;
        private renderEntity;
        private renderFields;
        private renderOverview;
        private renderRelationships;
        private renderRelationshipList;
        private renderDescriptions;
        private lifecycleLine;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-ontology-102035': WidgetNs4Ontology102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e4/agentNs4E4" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E4PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E4PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E4ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/steps/e4b/gate" {
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import { type Ns4AccessBindingsArtifact, type Ns4E4BFinding } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    export interface Ns4E4BGateSources {
        access: Pick<Ns4E3Review, 'moduleName' | 'grants' | 'authorities' | 'profiles'>;
        ontology: Pick<Ns4E4Review, 'moduleName' | 'entities' | 'relationships'>;
        journeys: Pick<Ns4E2Review, 'journeys'>;
    }
    export interface Ns4E4BGateResult {
        ok: boolean;
        issues: Ns4E4BFinding[];
    }
    export function validateNs4AccessBindings(artifact: Ns4AccessBindingsArtifact, sources: Ns4E4BGateSources, projections?: readonly Ns4OntologyEntity[]): Ns4E4BGateResult;
}
declare module "_102035_/l2/agentNewSolution/steps/e4b/agentNs4E4B" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E4BPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E4BPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution/steps/e5/gate" {
    import { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import { Ns4E4Review } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import { Ns4E5Review } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    export interface Ns4E5GateIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E5GateResult {
        ok: boolean;
        issues: Ns4E5GateIssue[];
    }
    export interface Ns4E5Sources {
        module: Ns4ModuleArtifact;
        journeys: Ns4E2Review;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
    }
    export function collectNs4ReferencedRuleIds(sources: Ns4E5Sources): string[];
    export function validateNs4E5Review(review: Ns4E5Review, sources: Ns4E5Sources): Ns4E5GateResult;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Rules" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4E5Review } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Rules102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E5Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        msgError: string;
        msgOk: string;
        private search;
        private selectedRuleId;
        private adjustment;
        private submitting;
        private feedbackIssues;
        private cancelOpen;
        private cancelOrigin;
        private text;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        private visibleRules;
        private selected;
        private updateDescription;
        private finishEdit;
        private submit;
        private openCancel;
        private closeCancel;
        render(): any;
        private renderFeedback;
        private renderCancelDialog;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-rules-102035': WidgetNs4Rules102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e5/agentNs4E5" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E5PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E5PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E5ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/steps/e6/gate" {
    import { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { Ns4E6Review } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    export interface Ns4E6GateIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E6GateResult {
        ok: boolean;
        issues: Ns4E6GateIssue[];
    }
    export function validateNs4E6Review(review: Ns4E6Review, module: Ns4ModuleArtifact): Ns4E6GateResult;
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4Composition" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { type Ns4PhraseHolder } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    import { Ns4E6Review } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    import { Ns4ClarificationFeedback, Ns4ClarificationWidgetApi } from "_102035_/l2/agentNewSolution/widgets/clarification";
    export class WidgetNs4Composition102035 extends StateLitElement implements Ns4ClarificationWidgetApi {
        value: Ns4E6Review | null;
        presentation: Ns4PhraseHolder | undefined;
        readonly: boolean;
        msgError: string;
        msgOk: string;
        private adjustment;
        private submitting;
        private feedbackIssues;
        private cancelOpen;
        private cancelOrigin;
        private text;
        setFeedback(feedback: Ns4ClarificationFeedback | null): void;
        setSubmitting(submitting: boolean): void;
        private submit;
        private openCancel;
        private closeCancel;
        render(): any;
        private renderFeedback;
        private renderCancelDialog;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-composition-102035': WidgetNs4Composition102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e6/agentNs4E6" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E6PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E6PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E6ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/reachability" {
    export interface Ns4ReachabilityTransition {
        fromStates: string[];
        toState: string;
    }
    /** The single E7 definition used by both workflow compilation and its post-resolution gate. */
    export function collectNs4ReachableWorkflowStates(initialState: string, transitions: Ns4ReachabilityTransition[]): Set<string>;
    /**
     * Shrinks unreachable states and their outgoing transitions until no new orphan target appears.
     * fromStates are alternatives, so a transition survives while at least one source remains.
     */
    export function shrinkNs4WorkflowToReachable<TTransition extends Ns4ReachabilityTransition>(initialState: string, sourceStates: string[], sourceTransitions: TTransition[]): {
        states: string[];
        transitions: TTransition[];
        removedStates: string[];
    };
}
declare module "_102035_/l2/agentNewSolution/steps/e7/gate" {
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4E7PlanDraft, Ns4E7SourceHashes, Ns4UseCaseDraft, Ns4UseCaseWrite, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export interface Ns4E7LifecycleRepairOption {
        action: 'operateState' | 'shrinkLifecycle';
        owner: 'e2' | 'e4';
        instruction: string;
    }
    export interface Ns4E7GateIssue {
        code: string;
        path: string;
        message: string;
        severity?: 'warning';
        repairOptions?: [Ns4E7LifecycleRepairOption, Ns4E7LifecycleRepairOption];
    }
    export interface Ns4E7GateResult {
        ok: boolean;
        issues: Ns4E7GateIssue[];
    }
    export interface Ns4E7Sources {
        journeys: Ns4E2Review;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        rules: Ns4RulesArtifact;
        sourceHashes?: Ns4E7SourceHashes;
    }
    export function validateNs4E7Plan(plan: Ns4E7PlanDraft, sources: Ns4E7Sources): Ns4E7GateResult;
    export function validateNs4UseCaseDraft(plan: Ns4E7PlanDraft, draft: Ns4UseCaseDraft, sources: Ns4E7Sources): Ns4E7GateResult;
    /** Entities the journey and the transitions already named as recorded by this behavior. */
    export function ns4E7RequiredWriteEntities(draft: Pick<Ns4UseCaseDraft, 'kind' | 'compiledFrom' | 'transitions'>, sources: Ns4E7Sources): string[];
    export function ns4E7DeclaredWriteEntities(writes: Ns4UseCaseWrite[] | undefined): string[];
    /** Extra writes the model recorded beyond journey intent; visible, alternative "drop". */
    export function ns4E7WriteIntentDecisions(drafts: Ns4UseCaseDraft[], sources: Ns4E7Sources, presentation?: Ns4Presentation): Ns4SystemDecision[];
    export function validateNs4Workflows(workflows: Ns4WorkflowArtifactV2[], sources: Ns4E7Sources, useCaseIds: Iterable<string>, systemDecisions?: Ns4SystemDecision[]): Ns4E7GateResult;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/lifecycleResolution" {
    import type { Ns4E7GateIssue } from "_102035_/l2/agentNewSolution/steps/e7/gate";
    export interface Ns4E7LifecycleResolutionReview {
        planId: 'e7-lifecycle-resolution';
        moduleName: string;
        findings: Array<Ns4E7GateIssue & {
            findingId: string;
        }>;
    }
    export interface Ns4E7LifecycleResolutionEvent {
        moduleName: string;
        selections: Array<{
            findingId: string;
            action: 'operateState' | 'shrinkLifecycle';
        }>;
    }
    export function createNs4E7LifecycleResolutionReview(moduleName: string, issues: Ns4E7GateIssue[]): Ns4E7LifecycleResolutionReview;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/validationReport" {
    export const NS4_E7_VALIDATION_REPORT_VERSION: "2026-08-12-ns4-e7-validation-report-v4";
    interface Ns4E7ValidationAttemptLike {
        round: number;
    }
    export function isNs4E7ValidationReport(value: unknown, moduleName: string): value is {
        schemaVersion: typeof NS4_E7_VALIDATION_REPORT_VERSION;
        moduleName: string;
        attempts: Ns4E7ValidationAttemptLike[];
    };
    export function mergeNs4E7ValidationAttempts<T extends Ns4E7ValidationAttemptLike>(previous: readonly T[], attempt: T): T[];
}
declare module "_102035_/l2/agentNewSolution/widgets/widgetNs4LifecycleResolution" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import type { Ns4E7LifecycleResolutionReview } from "_102035_/l2/agentNewSolution/steps/e7/lifecycleResolution";
    export class WidgetNs4LifecycleResolution102035 extends StateLitElement {
        value: Ns4E7LifecycleResolutionReview | null;
        private choices;
        render(): any;
        private submit;
    }
    global {
        interface HTMLElementTagNameMap {
            'widget-ns4-lifecycle-resolution-102035': WidgetNs4LifecycleResolution102035;
        }
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e7/agentNs4E7" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E7PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E7PromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function beforeNs4E7ClarificationStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown): Promise<HTMLElement>;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/hubComposition" {
    import type { Ns4ResolutionResult } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8HubCatalogue, Ns4E8HubComposition, Ns4E8ModelWorkspace } from "_102035_/l2/agentNewSolution/steps/e8/model";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export interface Ns4E8CompositionIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E8CompositionResult {
        ok: boolean;
        issues: Ns4E8CompositionIssue[];
    }
    /** Score order, primary actions first: what the page looks like when nobody composes it. */
    export function defaultNs4HubComposition(workspace: Ns4E8ModelWorkspace): Ns4E8HubComposition;
    export function normalizeNs4HubComposition(value: unknown, workspaceId: string, fallbackTitle: string): Ns4E8HubComposition;
    export function validateNs4HubComposition(catalogue: Ns4E8HubCatalogue, composition: Ns4E8HubComposition): Ns4E8CompositionResult;
    /**
     * Applies a composition over the derived catalogue: order, promotion and labels — nothing else.
     *
     * Two rules of the classic format decide the shape of the result, and getting them wrong is what
     * broke run 46: an organism consumes a call of its OWN workspace, so an item the hub reads becomes a
     * LOCAL call over the same shared operation; and a journey is navigation, so it leaves the sections
     * for the site map instead of pretending to be an embedded command.
     */
    export function applyNs4HubComposition(workspace: Ns4E8ModelWorkspace, composition: Ns4E8HubComposition): Ns4E8ModelWorkspace;
    /**
     * The bounded resolution: an invalid composition after its single repair is never a run failure —
     * the deterministic score order wins and the choice is recorded.
     */
    export function resolveNs4HubCompositionFindings(workspace: Ns4E8ModelWorkspace, issues: Ns4E8CompositionIssue[], presentation?: Ns4Presentation): Ns4ResolutionResult<Ns4E8ModelWorkspace>;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/compositionProfiles" {
    /**
     * Composition profiles are data, not per-category code. A workspace looks up the profile of its
     * categoryRef (or `default`) and the compiler follows those flags. R1/R2/R3 of the default
     * profile stay in tiers.ts; this object only says WHAT a category is allowed to host.
     */
    export interface Ns4E8CompositionProfile {
        profileId: 'default' | 'contentLanding';
        contentOrganisms: boolean;
        hostedCommands: boolean;
        tiles: boolean;
        crud: boolean;
    }
    export const NS4_E8_COMPOSITION_PROFILES: Record<string, Ns4E8CompositionProfile>;
    export function ns4E8CompositionProfile(categoryRef: string): Ns4E8CompositionProfile;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/tiers" {
    import type { Ns4JourneyProposal } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4DerivedContextGraph } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import { type Ns4E8Sources } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    import { type Ns4E8HubCatalogue, type Ns4E8Landing, type Ns4E8Model, type Ns4E8ModelWorkspace } from "_102035_/l2/agentNewSolution/steps/e8/model";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export function deriveNs4E8Model(sources: Ns4E8Sources, reviewRound?: number): Ns4E8Model;
    interface Ns4E8TierContext {
        sources: Ns4E8Sources;
        derived: Ns4DerivedContextGraph;
        presentation: Ns4Presentation | undefined;
        entities: Map<string, Ns4OntologyEntity>;
        hubEntity: string;
        catalogueEntities: Ns4OntologyEntity[];
        standaloneProjections: Ns4OntologyEntity[];
        compiledJourneys: Ns4JourneyProposal[];
        useCaseByStepRef: Map<string, Ns4UseCaseArtifactV3>;
        profilesByStepRef: Map<string, string[]>;
        sessionScopedProfiles: Set<string>;
        actorsByProfile: Map<string, string[]>;
        parentsOf: Map<string, Array<{
            parent: string;
            fieldId: string;
            required: boolean;
        }>>;
        transitionStates: Map<string, string[]>;
    }
    /**
     * The closed catalogue of the hub record page. Code decides WHAT may appear — projections anchored
     * on the hub, the satellites that point at it through a required relationship, the journeys anchored
     * on it and its pending decisions. The composition call may only order, promote and name these.
     */
    export function deriveNs4E8HubCatalogue(context: Ns4E8TierContext, workspaces: Ns4E8ModelWorkspace[]): Ns4E8HubCatalogue;
    /**
     * Per profile, in this order, with no LLM and without reading `landingIntent`:
     * 1. exclusive — non-journey whose profileRefs is exactly [profile], by tierRank then id
     * 2. firstJourney — journey workspace that hosts the first step of that profile's first journey
     *    (journeys/index order)
     * 3. rank — first non-journey that includes the profile, by the same tierRank as before
     */
    export function buildLandings(workspaces: Ns4E8ModelWorkspace[], sources: Ns4E8Sources): Ns4E8Landing[];
}
declare module "_102035_/l2/agentNewSolution/steps/e8/modelGate" {
    import type { Ns4ResolutionResult } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8Sources } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    import { type Ns4E8Model } from "_102035_/l2/agentNewSolution/steps/e8/model";
    /**
     * How a broken organism reference can be repaired without an LLM. The gate DETECTS as strictly as
     * before; only the outcome changed — a screen missing one panel is a product, a dead run is not.
     */
    export type Ns4E8ModelResolution = {
        kind: 'wireLocalQuery';
        workspaceId: string;
        sectionId: string;
        organismIndex: number;
        reference: string;
        bffId: string;
        operationId: string;
        entityRef: string;
        outputKind: 'object' | 'list' | 'paginated';
    } | {
        kind: 'moveActionToNavigation';
        workspaceId: string;
        sectionId: string;
        organismIndex: number;
        reference: string;
        targetWorkspaceId: string;
        label: string;
    } | {
        kind: 'dropOrganism';
        workspaceId: string;
        sectionId: string;
        organismIndex: number;
        reference: string;
    };
    export interface Ns4E8ModelIssue {
        code: string;
        path: string;
        message: string;
        severity?: 'warning';
        resolution?: Ns4E8ModelResolution;
    }
    export interface Ns4E8ModelResult {
        ok: boolean;
        issues: Ns4E8ModelIssue[];
    }
    export function validateNs4E8Model(model: Ns4E8Model, sources: Ns4E8Sources): Ns4E8ModelResult;
    /**
     * Decide, record, continue. A reference the code can repair is repaired; a reference that points at
     * nothing loses its panel and says so; only a model that cannot render at all stays terminal.
     */
    export function resolveNs4E8ModelFindings(model: Ns4E8Model, issues: Ns4E8ModelIssue[]): Ns4ResolutionResult<Ns4E8Model>;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/agentNs4E8" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    /**
     * E8 compiles every workspace of the module deterministically. The only LLM call left composes the
     * hub record page over a closed catalogue; a module without a dominant anchor makes no call at all.
     * Labels are not asked for: every title already arrives localized from an approved E2/E4 artifact.
     */
    export function beforeNs4E8PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E8PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution/steps/e9/coverage" {
    /**
     * E9 audit: E7-approved use cases versus operations actually written. Loss is declared, never a
     * gate — pruning a use case with no screen can be the right call; pruning it in silence is the defect.
     */
    import type { Ns4PipelineState } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_USECASE_DROP_UNREFERENCED = "no workspace references the step";
    export const NS4_USECASE_DROP_DUPLICATE = "uniqueBy discarded a duplicate operationId";
    export interface Ns4ApprovedUseCase {
        useCaseId: string;
        compiledFrom: string[];
    }
    export interface Ns4UseCasesDropped {
        notEmitted: string[];
        approved: number;
        emitted: number;
        reasons?: Record<string, string>;
    }
    export type Ns4UseCaseCoverageVerdict = {
        useCases: 'ok';
        approved: number;
        emitted: number;
    } | {
        useCases: 'degraded';
        useCasesDropped: Ns4UseCasesDropped;
    };
    export function compareE7ToOperations(input: {
        approved: readonly Ns4ApprovedUseCase[];
        emittedOperationIds: readonly string[];
        hostedStepRefs?: readonly string[];
    }): Ns4UseCaseCoverageVerdict;
    export function useCaseCoverageLogLine(verdict: Ns4UseCaseCoverageVerdict): string;
    /** Strip a prior-run `degraded` first. A clean emit leaves no `useCases` / `useCasesDropped` on disk. */
    export function applyNs4UseCaseCoverage(state: Ns4PipelineState, verdict: Ns4UseCaseCoverageVerdict): Ns4PipelineState;
}
declare module "_102035_/l2/agentNewSolution/steps/e9/agentNs4E9" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E9PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E9PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution/steps/e10/publishable" {
    export type PublishableIssue = string;
    /** Canonical project kind. Lives in each project's `l5/project.json` as `projectType`. */
    export const PROJECT_TYPES: readonly ["lib", "master frontend", "master backend", "client"];
    export type PublishableProjectType = typeof PROJECT_TYPES[number];
    export function isPublishableProjectType(value: unknown): value is PublishableProjectType;
    /** The `projectType` field of an l5/project.json, or '' when absent/invalid. */
    export function readProjectTypeFromProjectJson(projectJson: unknown): PublishableProjectType | '';
    /** `102029` -> `{ root: '../mls-102029', type: … }` */
    export const PROJECT_ROOT_PREFIX = "../mls-";
    /**
     * The platform blocks E10 must NOT invent, with the default the platform ships.
     *
     * Kept here as ONE source (the step copies, never re-types them) and applied only when the block is
     * absent: a publisher who tuned `clientShell` keeps their version, and the finding tells
     * them a default was filled in.
     */
    export const PLATFORM_BLOCK_DEFAULTS: Record<string, unknown>;
    /** The module a generated project is born in: test database, curated seeds, badge on screen. */
    export const DEFAULT_PROJECT_APP_ENV = "presentation";
    /**
     * `workspaceDependencies` as the API reports it — the list is never written by hand and never filtered:
     * the build on the VM consumes exactly this to know which projects to fetch.
     */
    export function buildWorkspaceDependencies(dependencies: readonly number[]): string[];
    export interface ProjectsBlockResult {
        projects: Record<string, unknown>;
        issues: PublishableIssue[];
    }
    /**
     * `projects` covering every dependency plus the module's own project.
     *
     * The platform API still has no project kind (`IPrj_settings` is name/owner/dependencies). The
     * canonical source is `projectType` on that project's `l5/project.json`. Order: a type already in
     * this config is PRESERVED, then `typeById` (read from that project's project.json), then the
     * module's own project is `client`, else `lib` plus a finding. Guessing master frontend/backend
     * silently is what would produce a wrong root in the build.
     */
    export function buildProjectsBlock(existing: unknown, projectId: number, dependencies: readonly number[], typeById?: Readonly<Record<string, string>>): ProjectsBlockResult;
    export interface PlatformBlocksResult {
        config: Record<string, unknown>;
        issues: PublishableIssue[];
    }
    /** Fill an ABSENT platform block from the single source above, and say so. Present blocks are untouched. */
    export function applyPlatformBlockDefaults(config: Record<string, unknown>): PlatformBlocksResult;
    /**
     * `appEnv` in l5/project.json: written ONLY when absent. A publisher who moved a project to
     * `homologation` must not have it reset to `presentation` by the next generation.
     */
    export function ensureProjectAppEnv(projectJson: unknown): {
        projectJson: Record<string, unknown>;
        changed: boolean;
    };
    /**
     * `projectType` on the CURRENT project's l5/project.json: written ONLY when absent.
     * E10 of a generated module writes `client`. It never overwrites a type already set.
     */
    export function ensureProjectType(projectJson: unknown, type: PublishableProjectType): {
        projectJson: Record<string, unknown>;
        changed: boolean;
    };
    /**
     * `/rebuild all` strips this module from l5/project.json; E10 puts the name back (studio list)
     * without touching sibling entries or backend blocks other agents own.
     */
    export function ensureProjectModule(projectJson: unknown, moduleName: string): {
        projectJson: Record<string, unknown>;
        changed: boolean;
    };
    /** The module has to be listed in l5/project.json.modules — the studio reads that list, not the config. */
    export function collectProjectJsonIssues(projectJson: unknown, moduleName: string): PublishableIssue[];
    /**
     * The closing checklist: what a publish needs, checked at delivery time instead of failing later inside
     * the publish with no name attached.
     */
    export function collectPublishableConfigIssues(config: unknown, moduleName: string, dependencies: readonly number[]): PublishableIssue[];
}
declare module "_102035_/l2/agentNewSolution/steps/e10/gate" {
    import { type Ns4E10Sources, type Ns4E10ValidationReport } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    export function validateNs4E10(sources: Ns4E10Sources): Promise<Ns4E10ValidationReport>;
}
declare module "_102035_/l2/agentNewSolution/helpers/nsPipelineRun" {
    import type { Ns4PipelineState } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS_PIPELINE_AGENT_SLUG = "newsolution";
    export interface PipelineRunDegradation {
        at: string;
        kind: string;
        reason: string;
        path?: string;
    }
    export interface PipelineRunSummary {
        moduleName: string;
        agent: string;
        command: string;
        startedAt: string | null;
        finishedAt: string;
        verdict: 'completed' | 'failed' | 'degraded';
        reason: string;
        counts: Record<string, unknown>;
        degradations: PipelineRunDegradation[];
    }
    export function nextPipelineRunNn(existingShortNames: readonly string[], agentSlug: string): string;
    export function buildNsRunSummary(input: {
        pipeline: Ns4PipelineState | null;
        moduleName: string;
        longMemory?: Record<string, unknown> | null;
        verdict: 'completed' | 'failed' | 'degraded';
        reason: string;
        extraDegradations?: PipelineRunDegradation[];
    }): PipelineRunSummary;
    export function saveNsRunSummary(summary: PipelineRunSummary): Promise<string | null>;
}
declare module "_102035_/l2/agentNewSolution/helpers/organizationRegistry" {
    import { type Ns4SolutionRegistryArtifact, type Ns4SolutionRegistryModule } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export function emptyNs4SolutionRegistry(level1SchemaVersion?: string): Ns4SolutionRegistryArtifact;
    /**
     * Replace only the named module block. Other modules keep their object identity so a stable
     * stringify leaves them byte-identical.
     */
    export function upsertNs4SolutionRegistryModule(registry: Ns4SolutionRegistryArtifact, block: Ns4SolutionRegistryModule): Ns4SolutionRegistryArtifact;
    export function inferNs4RegistryMdmSubtype(entity: {
        party?: string;
        mdmSubtype?: string;
    }): string | null;
    export function buildNs4SolutionRegistryModuleBlock(input: {
        moduleName: string;
        actors: Array<{
            actorId: string;
            kind: string;
        }>;
        entities: Array<{
            entityId: string;
            kind?: string;
            party?: string;
            mdmSubtype?: string;
            storage?: {
                target?: string;
                mdmType?: string;
            };
        }>;
        generalFields?: Ns4SolutionRegistryModule['generalFields'];
        updatedAt: string;
    }): Ns4SolutionRegistryModule;
    export function serializeNs4SolutionRegistry(registry: Ns4SolutionRegistryArtifact): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/registryGate" {
    import { type Ns4SolutionRegistryArtifact } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export interface Ns4RegistryGateIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4RegistryGateResult {
        ok: boolean;
        issues: Ns4RegistryGateIssue[];
    }
    export function validateNs4SolutionRegistry(registry: Ns4SolutionRegistryArtifact, level1Subtypes: readonly string[]): Ns4RegistryGateResult;
}
declare module "_102025_/l2/shared/api" {
    export * from "_102036_/l2/shared/api";
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from "_102036_/l2/shared/interfaces";
    export * from "_102036_/l2/shared/interfaces";
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module "_102036_/l2/shared/interfaces" {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    /** Ephemeral step title on the client. No server, store, or intents. */
    export const STEP_TITLE_LOCAL_EVENT = "step-title-local";
    export const LOCAL_STEP_TITLE_MIN_MS = 500;
    export interface LocalStepTitleDetail {
        taskPK: string;
        stepId: number;
        title: string;
    }
    type LocalStepTitleThrottle = {
        at: number;
        title: string;
    };
    /** Pure tick decision: at most one event per step per ~500ms, drop a repeated same title. */
    export function shouldEmitLocalStepTitle(last: LocalStepTitleThrottle | undefined, now: number, title: string, minIntervalMs?: number): boolean;
    export function getLocalStepTitleEventScope(): Window | undefined;
    /**
     * Paint a step title in the open task UI. Fail-soft: no window (headless/CLI) is a silent no-op;
     * any throw is swallowed — an ornament must never kill a run.
     */
    export function changeLocalStepTitle(taskPK: string, stepId: number, title: string): void;
    /** Main-thread tick while a worker/await holds. No-op (and no timer) without window. */
    export function startLocalStepTitleTick(taskPK: string, stepId: number, makeTitle: (elapsedSec: number) => string, intervalMs?: number): () => void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    /** Existing share-link format from createMessageLink: `#message/{threadId}` or `#message/{threadId}/{messageId}`. */
    export function threadOpenFromHash(hash: string): {
        threadId: string;
        messageId?: string;
    } | undefined;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from "_102036_/l2/collabMessagesIndexedDB";
}
declare module "_102025_/l2/notificationsRuntime" {
    import type { CollabMessagesEnvironment } from "_102036_/l2/environmentContract";
    /** Bounded poll matching the runtime shell mls-lib load window (~20s at 300ms). */
    export const MLS_LIB_RETRY_MS = 300;
    export const MLS_LIB_RETRIES = 67;
    export function hasPushSubscriptionCapability(): boolean;
    export function isNotificationPermissionDenied(): boolean;
    export const notificationsRuntime: NonNullable<CollabMessagesEnvironment["notifications"]>;
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<msg.PushSubscriptionData>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<void>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<msg.Thread>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: string;
        agentId: string;
        connectorId: string;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e10/agentNs4E10" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs4E10PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs4E10PromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution/agentNewSolution" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { Ns4RootPlan } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export function createAgent(): IAgentAsync;
    export const NS4_AGENT_BUILD = "build-59 (2026-08-15) tier workspace model, classic L4 emission and one dispatch table";
    export function getNs4RootPlan(context: mls.msg.ExecutionContext, rootHint?: mls.msg.AIAgentStep): Ns4RootPlan;
}
declare module "_102035_/l2/agentNewSolution/helpers/routeOf" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8Edge, Ns4WorkspaceContext } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    /**
     * routeOf outlived the workspace model that used to feed it: the classic L4 format carries a call
     * key (`<module>.<workspaceId>.<bffId>`), not a URL pattern, and the frontend derives the page URL
     * itself. The projection is kept — it is the one total URL derivation the module ever agreed on —
     * and now declares the shapes it needs instead of importing a model that no longer exists.
     */
    interface Ns4E8SkeletonWorkspace {
        workspaceId: string;
        kind: 'hub' | 'place';
        anchorEntity?: string;
        pageContext: Ns4WorkspaceContext[];
    }
    interface Ns4WorkspaceScenario {
        scenarioId: string;
        kind: string;
        title: string;
        useCaseIds: string[];
        selectionContexts: Ns4WorkspaceContext[];
    }
    export interface Ns4RouteUseCase {
        useCaseId: string;
        entityRefs: string[];
    }
    type Ns4RouteWorkspace = Pick<Ns4E8SkeletonWorkspace, 'workspaceId' | 'kind' | 'anchorEntity' | 'pageContext'>;
    export interface Ns4RouteProjection {
        routePattern: string;
        pathContextIds: string[];
        selectionContextIds: string[];
        systemDecisions: Ns4SystemDecision[];
    }
    /** Total structural URL projection shared by the E8 preview and the E9 compiler. */
    export function routeOf(moduleName: string, workspace: Ns4RouteWorkspace, scenario: Ns4WorkspaceScenario | undefined, graph: {
        workspaces: Ns4RouteWorkspace[];
        edges: Ns4E8Edge[];
        useCases: Ns4RouteUseCase[];
    }, presentation?: Ns4Presentation): Ns4RouteProjection;
}
declare module "_102035_/l2/agentNewSolution/steps/e3/fixtures/duplicateGrantFixture" {
    export const ns4E3DuplicateGrantPayload: {
        readonly planId: "e3-access-review";
        readonly moduleName: "petShop";
        readonly userLanguage: "pt-BR";
        readonly title: "Matriz de acesso do Pet Shop";
        readonly reviewRound: 1;
        readonly profiles: readonly [{
            readonly profileId: "admin";
            readonly title: "Administrador da loja";
            readonly kind: "internal";
            readonly description: "Responsável pela operação da loja, pela agenda, pelas decisões de agendamento e pelo registro presencial do atendimento.";
            readonly actorRefs: readonly ["admin"];
            readonly landingIntent: "Acessar a visão operacional para organizar a agenda e conduzir os atendimentos.";
        }, {
            readonly profileId: "cliente";
            readonly title: "Cliente";
            readonly kind: "external";
            readonly description: "Pessoa que mantém os próprios pets, solicita serviços e acompanha exclusivamente os atendimentos vinculados a eles.";
            readonly actorRefs: readonly ["cliente"];
            readonly landingIntent: "Conhecer a loja, manter os próprios pets, solicitar agendamentos e acompanhar seus atendimentos.";
        }];
        readonly authorities: readonly [{
            readonly authorityRef: "petshop:admin";
            readonly title: "Operar a gestão do Pet Shop";
            readonly description: "Permite administrar a agenda e executar os registros operacionais dos atendimentos da loja.";
            readonly journeyStepRefs: readonly ["approveServiceAppointment.locatePendingServiceAppointment", "approveServiceAppointment.approveServiceAppointment", "rejectServiceAppointment.locatePendingServiceAppointment", "rejectServiceAppointment.rejectServiceAppointment", "recordPetArrival.locateConfirmedServiceAppointment", "recordPetArrival.recordPetArrival", "startServiceExecution.locateArrivedServiceAppointment", "startServiceExecution.startServiceExecution", "attachBeforeServiceImage.locateStartedServiceExecution", "attachBeforeServiceImage.attachBeforeServiceImage", "finishServiceExecution.locateStartedServiceExecution", "finishServiceExecution.finishServiceExecution", "attachAfterServiceImage.locateCompletedServiceExecution", "attachAfterServiceImage.attachAfterServiceImage", "recordInStorePayment.locateCompletedServiceAppointment", "recordInStorePayment.recordInStorePayment", "recordPetCollection.locatePaidServiceAppointment", "recordPetCollection.recordPetCollection", "planServiceUnavailability.locateServiceHours", "planServiceUnavailability.createAvailabilityBlock", "registerServiceHours.createServiceHours"];
            readonly informationNeeds: readonly [];
        }, {
            readonly authorityRef: "petshop:cliente";
            readonly title: "Utilizar serviços e acompanhar os próprios pets";
            readonly description: "Permite consultar informações públicas da loja, manter os próprios dados e pets, solicitar serviços e acompanhar exclusivamente os atendimentos relacionados aos próprios pets.";
            readonly journeyStepRefs: readonly ["exploreInstitutionalHome.inspectInstitutionalHome", "requestServiceAppointment.locatePet", "requestServiceAppointment.locateServiceOffering", "requestServiceAppointment.locateAppointmentSlot", "requestServiceAppointment.createServiceAppointment", "viewPetCareOverview.locatePet", "viewPetCareOverview.inspectPetCareOverview", "registerCustomerProfile.createCustomerProfile", "registerPet.locateCustomerProfile", "registerPet.createPet"];
            readonly informationNeeds: readonly ["Informações institucionais e serviços oferecidos pelo Pet Shop", "Horários disponíveis para novas solicitações", "Cadastro e lista dos pets da própria pessoa cliente", "Status, histórico, pendências e imagens vinculados aos próprios pets", "Solicitações de agendamento realizadas para os próprios pets"];
        }];
        readonly grants: readonly [{
            readonly profileRef: "admin";
            readonly authorityRef: "petshop:admin";
            readonly reason: "O administrador precisa conduzir integralmente a operação da loja, desde a configuração da agenda até a retirada presencial do pet.";
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todos os horários, indisponibilidades, solicitações, atendimentos, pets, imagens e pagamentos presenciais pertencentes à organização ativa.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "A operação exige acesso aos registros completos necessários para decidir agendamentos, atender o pet e registrar cada etapa presencial.";
            };
            readonly useRules: readonly ["activeOrganizationRequired", "adminOnlyAppointmentDecision", "adminOnlyOperationalRegistration", "paymentMustBeRecordedBeforePetCollection"];
        }, {
            readonly profileRef: "cliente";
            readonly authorityRef: "petshop:cliente";
            readonly reason: "O cliente precisa conhecer a loja e selecionar um serviço e um horário que possam ser solicitados, sem acessar dados operacionais da organização.";
            readonly dataScope: {
                readonly mode: "public";
                readonly description: "Somente conteúdo institucional publicado, serviços oferecidos e horários disponibilizados publicamente para novas solicitações.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Expõe apenas as informações necessárias para apresentação da loja e criação de uma solicitação de agendamento.";
                readonly allowedInformation: readonly ["Apresentação institucional publicada", "Serviços oferecidos ao público", "Descrição pública dos serviços", "Horários disponíveis para solicitação"];
                readonly deniedInformation: readonly ["Dados de outros clientes e pets", "Solicitações de outros clientes", "Agenda operacional completa", "Indisponibilidades com detalhes internos", "Dados de pagamento", "Anotações internas da loja"];
            };
            readonly useRules: readonly ["onlyPublishedInstitutionalContent", "onlyAvailableAppointmentSlots"];
        }, {
            readonly profileRef: "cliente";
            readonly authorityRef: "petshop:cliente";
            readonly reason: "O cliente precisa criar e manter o próprio cadastro, cadastrar seus pets e solicitar atendimentos em nome deles.";
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Somente o cadastro da pessoa autenticada, os pets por ela mantidos e as solicitações de agendamento criadas para esses pets.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Expõe os registros completos próprios necessários para manter o cadastro, os pets e as solicitações de serviço.";
            };
            readonly useRules: readonly ["authenticatedCustomerRequired", "customerProfileMustBelongToAuthenticatedPerson", "petMustBelongToAuthenticatedCustomer", "appointmentMustReferenceCustomersOwnPet"];
        }, {
            readonly profileRef: "cliente";
            readonly authorityRef: "petshop:cliente";
            readonly reason: "O cliente precisa acompanhar pela web a evolução e o histórico dos atendimentos vinculados aos próprios pets.";
            readonly dataScope: {
                readonly mode: "related";
                readonly description: "Somente atendimentos, execuções, pendências e imagens relacionados a pets pertencentes ao cadastro da pessoa cliente autenticada.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Expõe o acompanhamento do pet sem revelar informações internas da operação ou dados de terceiros.";
                readonly allowedInformation: readonly ["Identificação e dados cadastrais do próprio pet", "Status da própria solicitação de agendamento", "Confirmação ou recusa do próprio agendamento", "Registro de chegada do próprio pet", "Início e conclusão do serviço do próprio pet", "Últimas execuções e pendências do próprio pet", "Situação de pagamento do próprio atendimento", "Registro de retirada do próprio pet", "Imagens opcionais de antes e depois vinculadas ao próprio pet"];
                readonly deniedInformation: readonly ["Dados de outros clientes e pets", "Agenda geral da loja", "Detalhes de indisponibilidades internas", "Dados financeiros internos", "Dados de pagamento de outros atendimentos", "Anotações internas da loja", "Registros completos de atendimentos não relacionados aos próprios pets"];
            };
            readonly useRules: readonly ["petOwnershipRequired", "relatedServiceRecordRequired", "onlyCustomerVisibleServiceImages"];
        }];
        readonly changeSummary: readonly ["Proposta inicial da matriz com os dois perfis solicitados: Administrador da loja e Cliente.", "O administrador recebe acesso organizacional à operação; o cliente recebe acesso limitado a conteúdo público, registros próprios e atendimentos relacionados aos próprios pets.", "A consulta do cliente foi delimitada para não expor agenda interna, dados de terceiros, informações financeiras internas ou anotações operacionais da loja."];
    };
    export const ns4E3RepairedGrantPayload: Record<string, unknown>;
    /**
     * The E2 journeys this matrix was approved against, derived from the very
     * journeyStepRefs the real authorities carry — so E3 coverage is consistent by
     * construction and these tests isolate the grant rule instead of tripping on
     * unrelated coverage findings.
     */
    export const ns4E3PetShopJourneysInput: Record<string, unknown>;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/attachPetServiceImageWorkspace" {
    export const attachPetServiceImageWorkspace: {
        readonly workspaceId: "attachPetServiceImage";
        readonly title: "Anexar imagem do atendimento do pet";
        readonly actors: readonly ["clienteResponsavel"];
        readonly kind: "operation";
        readonly entity: "ServiceImage";
        readonly bffCalls: readonly [{
            readonly bffId: "qryLocatePet";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "locatePet";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "petId";
                    readonly from: "locatePet.$items.petId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly from: "locatePet.$items.name";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.qryLocatePet";
        }, {
            readonly bffId: "qryLocateServiceExecution";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "locateServiceExecution";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "locateServiceExecution.$items.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "locateServiceExecution.$items.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "locateServiceExecution.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "locateServiceExecution.$items.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "locateServiceExecution.$items.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "locateServiceExecution.$items.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "locateServiceExecution.$items.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.qryLocateServiceExecution";
        }, {
            readonly bffId: "cmdDecideImageMoment";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "decideImageMoment";
            }];
            readonly input: readonly [{
                readonly name: "petPetId";
                readonly from: "decideImageMoment.petPetId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryCustomerPicker";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "decideImageMoment.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateServiceExecution";
                readonly type: "string";
            }, {
                readonly name: "serviceImageServiceImageId";
                readonly from: "decideImageMoment.serviceImageServiceImageId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceImageId";
                    readonly from: "decideImageMoment.serviceImageId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petId";
                    readonly from: "decideImageMoment.petId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceExecutionId";
                    readonly from: "decideImageMoment.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "imageMoment";
                    readonly from: "decideImageMoment.imageMoment";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "mediaReference";
                    readonly from: "decideImageMoment.mediaReference";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.cmdDecideImageMoment";
        }, {
            readonly bffId: "cmdAttachServiceImage";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "attachServiceImage";
            }];
            readonly input: readonly [{
                readonly name: "petPetId";
                readonly from: "attachServiceImage.petPetId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryCustomerPicker";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "attachServiceImage.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateServiceExecution";
                readonly type: "string";
            }, {
                readonly name: "serviceImageServiceImageId";
                readonly from: "attachServiceImage.serviceImageServiceImageId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }, {
                readonly name: "imageMoment";
                readonly from: "attachServiceImage.imageMoment";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }, {
                readonly name: "mediaReference";
                readonly from: "attachServiceImage.mediaReference";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceImageId";
                    readonly from: "attachServiceImage.serviceImageId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petId";
                    readonly from: "attachServiceImage.petId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceExecutionId";
                    readonly from: "attachServiceImage.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "imageMoment";
                    readonly from: "attachServiceImage.imageMoment";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "mediaReference";
                    readonly from: "attachServiceImage.mediaReference";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.cmdAttachServiceImage";
        }, {
            readonly bffId: "qryCustomerPicker";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "listCustomer";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "customerId";
                    readonly from: "listCustomer.$items.customerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "platformUserId";
                    readonly from: "listCustomer.$items.platformUserId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "fullName";
                    readonly from: "listCustomer.$items.fullName";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.attachPetServiceImage.qryCustomerPicker";
        }];
        readonly sections: readonly [{
            readonly sectionId: "locatePet";
            readonly intent: "Um pet da lista pessoal do cliente está selecionado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryLocatePet";
                readonly usage: "picker";
            }];
        }, {
            readonly sectionId: "locateServiceExecution";
            readonly intent: "Uma execução de serviço do pet está selecionada para receber a imagem.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryLocateServiceExecution";
                readonly usage: "picker";
            }];
        }, {
            readonly sectionId: "decideImageMoment";
            readonly intent: "A imagem é identificada como registro de antes ou de depois do serviço.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdDecideImageMoment";
            }, {
                readonly role: "filterControl";
                readonly dataSource: "qryCustomerPicker";
                readonly usage: "picker";
            }];
        }, {
            readonly sectionId: "attachServiceImage";
            readonly intent: "A imagem opcional fica anexada ao atendimento selecionado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdAttachServiceImage";
            }];
        }];
        readonly operationIds: readonly ["attachServiceImage", "decideImageMoment", "listCustomer", "locatePet", "locateServiceExecution"];
        readonly purpose: "Adicionar opcionalmente uma imagem de antes ou depois de um serviço de um pet.";
        readonly presentation: {
            readonly categoryRef: "approvalWorkflow";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the journey tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:c88db383";
    };
    export default attachPetServiceImageWorkspace;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/consultInstitutionalHomeWorkspace" {
    export const consultInstitutionalHomeWorkspace: {
        readonly workspaceId: "consultInstitutionalHome";
        readonly title: "Conhecer o pet shop";
        readonly actors: readonly ["clienteResponsavel"];
        readonly kind: "operation";
        readonly entity: "InstitutionalPresentation";
        readonly bffCalls: readonly [{
            readonly bffId: "qryInspectInstitutionalPresentation";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "inspectInstitutionalPresentation";
            }];
            readonly input: readonly [{
                readonly name: "institutionalPresentationInstitutionalPresentationId";
                readonly from: "inspectInstitutionalPresentation.institutionalPresentationInstitutionalPresentationId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "institutionalPresentationId";
                    readonly from: "inspectInstitutionalPresentation.institutionalPresentationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "businessName";
                    readonly from: "inspectInstitutionalPresentation.businessName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "headline";
                    readonly from: "inspectInstitutionalPresentation.headline";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "presentationText";
                    readonly from: "inspectInstitutionalPresentation.presentationText";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.consultInstitutionalHome.qryInspectInstitutionalPresentation";
        }];
        readonly sections: readonly [{
            readonly sectionId: "inspectInstitutionalPresentation";
            readonly intent: "A pessoa visualiza a apresentação institucional e as informações de atendimento do pet shop.";
            readonly organisms: readonly [{
                readonly role: "detailPanel";
                readonly dataSource: "qryInspectInstitutionalPresentation";
            }];
        }];
        readonly operationIds: readonly ["inspectInstitutionalPresentation"];
        readonly purpose: "Consultar a apresentação institucional do pet shop antes de utilizar seus serviços.";
        readonly presentation: {
            readonly categoryRef: "processWizard";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the journey tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:b6fdbe28";
    };
    export default consultInstitutionalHomeWorkspace;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/inspectInstitutionalPresentationOperation" {
    export const operationInspectInstitutionalPresentation: {
        readonly operationId: "inspectInstitutionalPresentation";
        readonly title: "Conhecer o pet shop";
        readonly actors: readonly ["clienteResponsavel"];
        readonly entity: "InstitutionalPresentation";
        readonly kind: "query";
        readonly reads: readonly ["BusinessHours", "InstitutionalPresentation"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "clienteResponsavel";
            readonly goal: "Conhecer o pet shop";
            readonly steps: readonly ["Conhecer o pet shop", "A pessoa visualiza a apresentação institucional e as informações de atendimento do pet shop."];
            readonly outcome: "A pessoa visualiza a apresentação institucional e as informações de atendimento do pet shop.";
        };
        readonly accessPattern: {
            readonly kind: "getById";
            readonly description: "Conhecer o pet shop";
            readonly entity: "InstitutionalPresentation";
            readonly keyField: "InstitutionalPresentation.institutionalPresentationId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["InstitutionalPresentation.institutionalPresentationId", "InstitutionalPresentation.businessName", "InstitutionalPresentation.headline", "InstitutionalPresentation.presentationText"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "institutionalPresentationId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "InstitutionalPresentation.institutionalPresentationId";
            }, {
                readonly name: "businessName";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "InstitutionalPresentation.businessName";
            }, {
                readonly name: "headline";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "InstitutionalPresentation.headline";
            }, {
                readonly name: "presentationText";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "InstitutionalPresentation.presentationText";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "institutionalPresentationInstitutionalPresentationId";
            readonly fieldRef: "InstitutionalPresentation.institutionalPresentationId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Apresentação institucional";
        }];
        readonly pageId: "consultInstitutionalHome";
        readonly commandName: "qryInspectInstitutionalPresentation";
        readonly bffName: "qryInspectInstitutionalPresentation";
    };
    export default operationInspectInstitutionalPresentation;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/locateConfirmedServiceAppointmentOperation" {
    export const operationLocateConfirmedServiceAppointment: {
        readonly operationId: "locateConfirmedServiceAppointment";
        readonly title: "Localizar agendamento confirmado";
        readonly actors: readonly ["administradorPetShop"];
        readonly entity: "ServiceAppointment";
        readonly kind: "query";
        readonly reads: readonly ["ServiceAppointment"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["onlyConfirmedAppointmentsCanStartService"];
        readonly story: {
            readonly actor: "administradorPetShop";
            readonly goal: "Localizar agendamento confirmado";
            readonly steps: readonly ["Localizar agendamento confirmado", "Um agendamento confirmado está selecionado para o atendimento presencial."];
            readonly outcome: "Um agendamento confirmado está selecionado para o atendimento presencial.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly description: "Localizar agendamento confirmado";
            readonly entity: "ServiceAppointment";
            readonly keyField: "ServiceAppointment.serviceAppointmentId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["ServiceAppointment.serviceAppointmentId", "ServiceAppointment.status", "ServiceAppointment.petId", "ServiceAppointment.serviceId", "ServiceAppointment.requestedStartAt", "ServiceAppointment.requestedEndAt", "ServiceAppointment.refusalReason"];
        };
        readonly outputShape: {
            readonly kind: "list";
            readonly fields: readonly [{
                readonly name: "serviceAppointmentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.serviceAppointmentId";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.status";
            }, {
                readonly name: "petId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.petId";
            }, {
                readonly name: "serviceId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.serviceId";
            }, {
                readonly name: "requestedStartAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.requestedStartAt";
            }, {
                readonly name: "requestedEndAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceAppointment.requestedEndAt";
            }, {
                readonly name: "refusalReason";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "ServiceAppointment.refusalReason";
            }];
        };
        readonly inputs: readonly [];
        readonly pageId: "recordInStoreServiceAttendance";
        readonly commandName: "qryLocateConfirmedServiceAppointment";
        readonly bffName: "qryLocateConfirmedServiceAppointment";
    };
    export default operationLocateConfirmedServiceAppointment;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/recordInStoreServiceAttendanceWorkspace" {
    export const recordInStoreServiceAttendanceWorkspace: {
        readonly workspaceId: "recordInStoreServiceAttendance";
        readonly title: "Registrar atendimento presencial do pet";
        readonly actors: readonly ["administradorPetShop"];
        readonly kind: "workflow";
        readonly entity: "ServiceExecution";
        readonly workflowId: "serviceExecutionLifecycle";
        readonly bffCalls: readonly [{
            readonly bffId: "qryLocateConfirmedServiceAppointment";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "locateConfirmedServiceAppointment";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "serviceAppointmentId";
                    readonly from: "locateConfirmedServiceAppointment.$items.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "locateConfirmedServiceAppointment.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petId";
                    readonly from: "locateConfirmedServiceAppointment.$items.petId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceId";
                    readonly from: "locateConfirmedServiceAppointment.$items.serviceId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "requestedStartAt";
                    readonly from: "locateConfirmedServiceAppointment.$items.requestedStartAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "requestedEndAt";
                    readonly from: "locateConfirmedServiceAppointment.$items.requestedEndAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "refusalReason";
                    readonly from: "locateConfirmedServiceAppointment.$items.refusalReason";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.qryLocateConfirmedServiceAppointment";
        }, {
            readonly bffId: "cmdRegisterPetArrival";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerPetArrival";
            }];
            readonly input: readonly [{
                readonly name: "serviceAppointmentServiceAppointmentId";
                readonly from: "registerPetArrival.serviceAppointmentServiceAppointmentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateConfirmedServiceAppointment";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "registerPetArrival.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "registerPetArrival.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerPetArrival.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "registerPetArrival.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "registerPetArrival.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "registerPetArrival.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "registerPetArrival.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterPetArrival";
        }, {
            readonly bffId: "cmdRegisterServiceStart";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerServiceStart";
            }];
            readonly input: readonly [{
                readonly name: "serviceAppointmentServiceAppointmentId";
                readonly from: "registerServiceStart.serviceAppointmentServiceAppointmentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateConfirmedServiceAppointment";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "registerServiceStart.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "registerServiceStart.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "registerServiceStart.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerServiceStart.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "registerServiceStart.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "registerServiceStart.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "registerServiceStart.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "registerServiceStart.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterServiceStart";
        }, {
            readonly bffId: "cmdRegisterServiceCompletion";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerServiceCompletion";
            }];
            readonly input: readonly [{
                readonly name: "serviceAppointmentServiceAppointmentId";
                readonly from: "registerServiceCompletion.serviceAppointmentServiceAppointmentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateConfirmedServiceAppointment";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "registerServiceCompletion.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "registerServiceCompletion.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "registerServiceCompletion.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerServiceCompletion.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "registerServiceCompletion.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "registerServiceCompletion.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "registerServiceCompletion.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "registerServiceCompletion.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterServiceCompletion";
        }, {
            readonly bffId: "cmdRegisterInStorePayment";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerInStorePayment";
            }];
            readonly input: readonly [{
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "registerInStorePayment.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "inStorePaymentId";
                    readonly from: "registerInStorePayment.inStorePaymentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceExecutionId";
                    readonly from: "registerInStorePayment.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerInStorePayment.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "confirmedAt";
                    readonly from: "registerInStorePayment.confirmedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterInStorePayment";
        }, {
            readonly bffId: "cmdRegisterPetPickup";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "registerPetPickup";
            }];
            readonly input: readonly [{
                readonly name: "serviceAppointmentServiceAppointmentId";
                readonly from: "registerPetPickup.serviceAppointmentServiceAppointmentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryLocateConfirmedServiceAppointment";
                readonly type: "string";
            }, {
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "registerPetPickup.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "registerPetPickup.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "registerPetPickup.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "registerPetPickup.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "registerPetPickup.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "registerPetPickup.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "registerPetPickup.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "registerPetPickup.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdRegisterPetPickup";
        }, {
            readonly bffId: "cmdHandoffCompletedService";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "handoffCompletedService";
            }];
            readonly input: readonly [{
                readonly name: "serviceExecutionServiceExecutionId";
                readonly from: "handoffCompletedService.serviceExecutionServiceExecutionId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "serviceExecutionId";
                    readonly from: "handoffCompletedService.serviceExecutionId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceAppointmentId";
                    readonly from: "handoffCompletedService.serviceAppointmentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "handoffCompletedService.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "arrivedAt";
                    readonly from: "handoffCompletedService.arrivedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "serviceStartedAt";
                    readonly from: "handoffCompletedService.serviceStartedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "completedAt";
                    readonly from: "handoffCompletedService.completedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pickedUpAt";
                    readonly from: "handoffCompletedService.pickedUpAt";
                    readonly type: "string";
                    readonly required: false;
                }];
            };
            readonly route: "petShop.recordInStoreServiceAttendance.cmdHandoffCompletedService";
        }];
        readonly sections: readonly [{
            readonly sectionId: "locateConfirmedServiceAppointment";
            readonly intent: "Um agendamento confirmado está selecionado para o atendimento presencial.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryLocateConfirmedServiceAppointment";
                readonly usage: "picker";
            }];
        }, {
            readonly sectionId: "registerPetArrival";
            readonly intent: "A execução do serviço é aberta com o registro de que o pet foi levado à loja.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterPetArrival";
            }];
        }, {
            readonly sectionId: "registerServiceStart";
            readonly intent: "A execução passa a indicar que o serviço do pet foi iniciado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterServiceStart";
            }];
        }, {
            readonly sectionId: "registerServiceCompletion";
            readonly intent: "A execução passa a indicar que o serviço foi concluído.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterServiceCompletion";
            }];
        }, {
            readonly sectionId: "registerInStorePayment";
            readonly intent: "A confirmação do pagamento presencial do atendimento fica registrada.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterInStorePayment";
            }];
        }, {
            readonly sectionId: "registerPetPickup";
            readonly intent: "A execução registra que o cliente buscou o pet na loja.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRegisterPetPickup";
            }];
        }, {
            readonly sectionId: "handoffCompletedService";
            readonly intent: "O atendimento concluído fica disponível para consulta pelo cliente no site.";
            readonly organisms: readonly [{
                readonly role: "contextualAction";
                readonly action: "cmdHandoffCompletedService";
            }];
        }];
        readonly operationIds: readonly ["handoffCompletedService", "locateConfirmedServiceAppointment", "registerInStorePayment", "registerPetArrival", "registerPetPickup", "registerServiceCompletion", "registerServiceStart"];
        readonly purpose: "Registrar a chegada, o início, a conclusão, a retirada e o pagamento presencial de um serviço confirmado.";
        readonly presentation: {
            readonly categoryRef: "processWizard";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the journey tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:151f986f";
    };
    export default recordInStoreServiceAttendanceWorkspace;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/fixtures/registerServiceStartOperation" {
    export const operationRegisterServiceStart: {
        readonly operationId: "registerServiceStart";
        readonly title: "Registrar início do serviço";
        readonly actors: readonly ["administradorPetShop"];
        readonly entity: "ServiceExecution";
        readonly kind: "commandInput";
        readonly reads: readonly ["ServiceAppointment", "ServiceExecution"];
        readonly writes: readonly ["ServiceExecution"];
        readonly rulesApplied: readonly ["onlyConfirmedAppointmentsCanStartService"];
        readonly story: {
            readonly actor: "administradorPetShop";
            readonly goal: "Registrar início do serviço";
            readonly steps: readonly ["Registrar início do serviço", "A execução passa a indicar que o serviço do pet foi iniciado."];
            readonly outcome: "A execução passa a indicar que o serviço do pet foi iniciado.";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly description: "Registrar início do serviço";
            readonly entity: "ServiceExecution";
            readonly keyField: "ServiceExecution.serviceExecutionId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["ServiceExecution.serviceExecutionId", "ServiceExecution.serviceAppointmentId", "ServiceExecution.status", "ServiceExecution.arrivedAt", "ServiceExecution.serviceStartedAt", "ServiceExecution.completedAt", "ServiceExecution.pickedUpAt"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "serviceExecutionId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceExecution.serviceExecutionId";
            }, {
                readonly name: "serviceAppointmentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceExecution.serviceAppointmentId";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceExecution.status";
            }, {
                readonly name: "arrivedAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ServiceExecution.arrivedAt";
            }, {
                readonly name: "serviceStartedAt";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "ServiceExecution.serviceStartedAt";
            }, {
                readonly name: "completedAt";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "ServiceExecution.completedAt";
            }, {
                readonly name: "pickedUpAt";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "ServiceExecution.pickedUpAt";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "serviceAppointmentServiceAppointmentId";
            readonly fieldRef: "ServiceAppointment.serviceAppointmentId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Solicitação de agendamento";
        }, {
            readonly inputId: "serviceExecutionServiceExecutionId";
            readonly fieldRef: "ServiceExecution.serviceExecutionId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Execução de serviço";
        }];
        readonly pageId: "recordInStoreServiceAttendance";
        readonly commandName: "cmdRegisterServiceStart";
        readonly bffName: "cmdRegisterServiceStart";
    };
    export default operationRegisterServiceStart;
}
declare module "_102035_/l2/solution/types" {
    /** Schema ids for NS5 source artifacts. Bumped when a field is added or removed. */
    export const NS5_MODULE_SCHEMA_VERSION: "2026-09-10-ns5-module-v1";
    export const NS5_JOURNEY_SCHEMA_VERSION: "2026-09-10-ns5-journey-v1";
    export const NS5_ONTOLOGY_SCHEMA_VERSION: "2026-09-10-ns5-ontology-v1";
    export const NS5_RULES_SCHEMA_VERSION: "2026-09-10-ns5-rules-v1";
    export const NS5_WORKFLOWS_SCHEMA_VERSION: "2026-09-10-ns5-workflows-v1";
    export const NS5_ACCESS_SCHEMA_VERSION: "2026-09-10-ns5-access-v1";
    export const NS5_INTEGRATION_SCHEMA_VERSION: "2026-09-10-ns5-integration-v1";
    export const NS5_PIPELINE_SCHEMA_VERSION: "2026-09-10-ns5-pipeline-v1";
    export const NS5_STEP_IDS: readonly ["module10", "journeys20", "ontology30", "rules40", "workflows50", "access60", "integration70", "finalize80"];
    export type Ns5StepId = typeof NS5_STEP_IDS[number];
    export interface Ns5ModuleActor {
        /** journeys20 binds actorRef; access60 binds profile.actorRefs; finalize80 checks coverage. */
        actorId: string;
        /** journeys20 drops inferred external without an exclusive step; integration70 treats system as a signal. */
        kind: 'internal' | 'external' | 'system';
        /** journeys20 removes inferred external without a private step; module10 only records the origin. */
        origin: 'named' | 'inferred';
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Planner / UI; no generator reads this as structure. */
        description: string;
    }
    export interface Ns5ModuleArtifact {
        /** Gate of module10; later steps refuse a different version. */
        schemaVersion: typeof NS5_MODULE_SCHEMA_VERSION;
        /** Folder name; every later step and the registry key off this. */
        moduleName: string;
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Phrases catalogue and later prompts write user-facing text in this language. */
        userLanguage: string;
        /** module10 gate; defaultLanguage must be in this list. */
        productLanguages: string[];
        /** Fallback language when a phrase is missing. */
        defaultLanguage: string;
        /** Resume and /rebuild all recover the original request from here. */
        sourcePrompt: string;
        /** journeys20, access60, finalize80 iterate this list. */
        actors: Ns5ModuleActor[];
        scope: {
            /** Human boundary; no generator reads this as structure. */
            inScope: string[];
            /** Human boundary; no generator reads this as structure. */
            outOfScope: string[];
        };
        /** Organization-wide aggregates; ontology30 writes this at the end of the fan-out. */
        details?: Record<string, string>;
    }
    export interface Ns5JourneyStep {
        /** workflows50 may point a task at this id. */
        stepId: string;
        /** journeys20 gate; finalize80 maps act/decide onto ontology transitions. */
        kind: 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
        /** ontology30 must declare this UpperCamel id; finalize80 checks it exists. */
        entity: string;
        /** ontology30 must declare each extra entity the step also changes. */
        affects?: string[];
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** workflows50 requires a process covering this handoff; must be an actorId. */
        handoffTo?: string;
    }
    export interface Ns5JourneyArtifact {
        /** Gate of journeys20. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Index order, workflows50.journeyRef. */
        journeyId: string;
        business: {
            /** Must be an actorId from module.defs.ts. */
            actorRef: string;
            /** Planner / UI. */
            title: string;
            /** Planner / UI. */
            goal: string;
            entry: {
                /** journeys20 gate; no screen meaning. */
                mode: 'coldStart' | 'contextOrLookup' | 'fromNotification';
            };
            /** ontology30 collects entity names; finalize80 is the oracle for act/decide. */
            steps: Ns5JourneyStep[];
            outcome: {
                /** Planner / UI. */
                statement: string;
                /** Planner / UI. */
                evidence: string[];
            };
        };
        /** Staleness: journeys20 rewrite vs finalize80. */
        businessHash: string;
    }
    export interface Ns5SystemDecision {
        /** dropInferredActor<Actor> after journeys20. */
        decisionId: string;
        /** Mechanical choice. */
        chosen: string;
        /** Visible alternative; not offered as a widget. */
        alternatives: string[];
        decidedBy: 'system';
    }
    export interface Ns5JourneyIndexEntry {
        /** File name under journeys/. */
        journeyId: string;
        /** Must be an actorId that survived inferred-actor drop. */
        actorRef: string;
        /** Planner / UI. */
        title: string;
    }
    export interface Ns5JourneyIndexArtifact {
        /** Gate of journeys20; same version as each journey file. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Declaration order; ontology30 and access60 read this list. */
        journeys: Ns5JourneyIndexEntry[];
        /** journeys20 records dropInferredActor<Actor> here. */
        systemDecisions: Ns5SystemDecision[];
    }
    export interface Ns5OntologyField {
        /** Grants and rules name Entidade.campo using this id. */
        fieldId: string;
        /** Planner / UI. */
        title: string;
        /** Backend storage and grant field resolution. */
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        /** Backend required-on-write; ontology30 gate. */
        required: boolean;
        /** Literal union that reaches the page through the ontology. */
        enum?: string[];
        /** Planner / UI. */
        description: string;
    }
    export interface Ns5OntologyEntityArtifact {
        /** Gate of ontology30. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / storage.mdmType prefix. */
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** ontology30 gate vs storage.target; mdm has no lifecycle. */
        kind: 'core' | 'event' | 'supporting' | 'mdm' | 'valueObject';
        /** access60 own-anchor search; registry role inference. */
        party: 'person' | 'organization' | 'none';
        /** Required on kind mdm; must be a level-1 subtype. */
        mdmSubtype?: string;
        /** Resolvable field (own or level-1 identification/base). */
        displayField: string;
        /** Namespace-only on mdm; identity lives in storage.idField. */
        fields: Ns5OntologyField[];
        /** Calculated values; backend persists JSON column details; rules may cite details.<name>. */
        details?: Record<string, string>;
        /** finalize80 reachability; a screen may only request a declared transition. */
        lifecycleStates: Array<{
            state: string;
            reachedBy: 'actor' | 'command' | 'time';
        }>;
        /** finalize80 maps journey act/decide onto these; ruleRefs cite rules.defs.ts. */
        transitions: Array<{
            transitionId: string;
            from: string[];
            to: string;
            by: string[] | 'system' | 'time';
            description: string;
            /** Optional citations; finalize80 I4 checks each id exists in rules.defs.ts. */
            ruleRefs?: string[];
        }>;
        storage: {
            /** Must match kind (mdm => mdm). */
            target: 'moduleDatabase' | 'mdm' | 'external';
            /** mdm is organization. */
            scope: string;
            /** Identity field; outside fields[] on mdm. */
            idField: string;
            /** '<mod>.<Entity>' on mdm, consumed by the registry. */
            mdmType?: string;
        };
        /** appendOnly entities have no lifecycle; E-like backends skip update/delete. */
        mutability?: 'appendOnly';
    }
    export interface Ns5OntologyRelationship {
        /** Index identity. */
        relationshipId: string;
        /** Must be an entityId in this index. */
        fromEntity: string;
        /** Must be an entityId in this index. */
        toEntity: string;
        /** Structural type of the link. */
        type: string;
        /** access60 own-anchor walk follows required edges. */
        required: boolean;
        persistence: {
            mode: 'moduleReference' | 'crossStoreReference' | 'mdmRelationship' | 'externalReference';
        };
        realization: {
            kind: string;
            ownerEntity: string;
            from: {
                entityId: string;
                fieldIds: string[];
            };
            to: {
                entityId: string;
                fieldIds: string[];
            };
        };
    }
    export interface Ns5OntologyIndexArtifact {
        /** Gate of ontology30 bindings. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / registry. */
        moduleName: string;
        /** Planner / UI. */
        businessDomain: string;
        /** Order of entity files; finalize80 coverage. */
        entities: string[];
        /** n15 field endpoints; access60 anchorPath. */
        relationships: Ns5OntologyRelationship[];
        /** ontology30: platform-service candidates (attachments/comments). Omitted when none. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export interface Ns5Rule {
        /** Cited by transitions.ruleRefs and later screens/endpoints. */
        ruleId: string;
        /** The only copy of the rule text. */
        description: string;
    }
    export interface Ns5RulesArtifact {
        /** Gate of rules40. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Catalog of {ruleId, description}; I4 checks cited ruleRefs exist. */
        rules: Ns5Rule[];
    }
    export interface Ns5WorkflowTask {
        /** Graph node id. */
        taskId: string;
        /** Gate: human requires actorRef. */
        kind: 'human' | 'system' | 'wait';
        /** Actor of a human task. */
        actorRef?: string;
        /** Must exist in the journey index. */
        journeyRef?: string;
        /** Must exist on that journey. */
        stepRef?: string;
        /** Acyclic unless a wait is on the cycle. */
        next: string[];
        /** Planner / UI. */
        description: string;
    }
    export interface Ns5WorkflowProcess {
        /** Index identity. */
        processId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** finalize80 I6: every journey handoff appears in some process. */
        tasks: Ns5WorkflowTask[];
    }
    export interface Ns5WorkflowsArtifact {
        /** Gate of workflows50. Empty list is valid. */
        schemaVersion: typeof NS5_WORKFLOWS_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Orchestration only; not the entity FSM. */
        processes: Ns5WorkflowProcess[];
    }
    export interface Ns5AccessProfile {
        /** grants.profileRef. */
        profileId: string;
        /** Must be actorIds from module.defs.ts. */
        actorRefs: string[];
        /** External profiles need their own grant; anonymous is public-only. */
        kind: 'internal' | 'external' | 'anonymous';
    }
    export interface Ns5AccessAuthority {
        /** grants.authorityRef. */
        authorityId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
    }
    export interface Ns5AccessDataScope {
        /** own|assigned|related require anchorEntity. Other modes drop it before the gate. */
        mode: 'own' | 'assigned' | 'related' | 'public' | 'organization' | 'custom';
        /** party:person entity reachable from each entityRef. The path is derived, not stored. */
        anchorEntity?: string;
        /** Prose for custom; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessDisclosure {
        /** fieldsOnly|summaryOnly require a proper (not the full resolvable set) allowedFields or deniedFields list. */
        mode: 'fullRecord' | 'fieldsOnly' | 'summaryOnly' | 'aggregateOnly';
        /** Entity.field the backend includes. */
        allowedFields?: string[];
        /** Entity.field the backend strips. */
        deniedFields?: string[];
        /** Prose; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessGrant {
        /** Index identity. */
        grantId: string;
        /** Must be a profileId. */
        profileRef: string;
        /** Must be an authorityId. */
        authorityRef: string;
        /** Must be entityIds. */
        entityRefs: string[];
        dataScope: Ns5AccessDataScope;
        disclosure: Ns5AccessDisclosure;
    }
    export interface Ns5AccessArtifact {
        /** Gate of access60. */
        schemaVersion: typeof NS5_ACCESS_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** finalize80 I3: every actor has a profile. */
        profiles: Ns5AccessProfile[];
        /** grants.authorityRef. */
        authorities: Ns5AccessAuthority[];
        /** Backend applies scope and disclosure from these rows. */
        grants: Ns5AccessGrant[];
    }
    export interface Ns5IntegrationItem {
        /** Index identity. */
        id: string;
        /** Gate vs registry / plugin catalogue. */
        kind: 'moduleEndpoint' | 'event' | 'external';
        /** For inbound: source module or system. */
        from?: string;
        /** For outbound: destination module or system. */
        to?: string;
        /** Planner / UI. */
        description: string;
        /** Must be entityIds. */
        entityRefs: string[];
    }
    export interface Ns5IntegrationPlugin {
        /** Must be in the platform plugin catalogue. */
        pluginId: string;
        /** Planner / UI. */
        description: string;
        /** Must be entityIds. */
        entityRefs: string[];
    }
    export interface Ns5IntegrationArtifact {
        /** Gate of integration70. Empty lists are valid. */
        schemaVersion: typeof NS5_INTEGRATION_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** What this module receives. */
        inbound: Ns5IntegrationItem[];
        /** What this module publishes. */
        outbound: Ns5IntegrationItem[];
        /** Platform plugins this module uses. */
        plugins: Ns5IntegrationPlugin[];
    }
    export type Ns5PipelineStatus = 'inProgress' | 'awaitingStep' | 'complete' | 'failed';
    export interface Ns5PipelineStepState {
        /** Monotonic: approved is never overwritten by running/failed. */
        status: 'running' | 'approved' | 'failed';
        updatedAt: string;
        artifactPaths?: string[];
        error?: string;
        /** Set when /fast auto-approves; later steps and the supervisor read this. */
        autoReason?: string;
        /** journeys20: count of decide steps in the module. Zero is valid. */
        decideStepCount?: number;
        /** ontology30: entityIds no journey cites. Supporting/valueObject may be legitimate. */
        uncitedEntities?: string[];
        /**
         * ontology30: entity ids `liftNs5AggregateOnlyEntities` absorbed into `module.details`.
         * finalize80 I1 accepts a journey `entity`/`affects` that names one of these when
         * `module.details` still has the corresponding aggregate keys.
         */
        liftedAggregateEntities?: string[];
        /** workflows50: true when processes is [] because no handoff, foreign-by transition or cross-actor decide. */
        noProcessSignal?: boolean;
        /** integration70: true when inbound/outbound/plugins are [] because no system actor and no plugin-catalog term. */
        noIntegrationSignal?: boolean;
    }
    export interface Ns5Invocation {
        /** /fast skips reserved clarification anchors. */
        fast: boolean;
        /** /module value when given; module10 proposes lowerCamel otherwise. */
        module: string;
        /** /rebuild all of that module's l4 tree. */
        rebuildAll: boolean;
    }
    export interface Ns5RebuildAllReport {
        /** How many l4/<module> files were unlinked. */
        deleted: number;
        at: string;
    }
    export interface Ns5PipelineState {
        /** Gate of the skeleton; later steps refuse a different version. */
        schemaVersion: typeof NS5_PIPELINE_SCHEMA_VERSION;
        /** Must be agentNewSolution5. */
        flowId: 'agentNewSolution5';
        /** Folder this pipeline belongs to. */
        moduleName: string;
        /** Supervisor reads awaitingStep when status is awaitingStep. */
        status: Ns5PipelineStatus;
        /** First unimplemented step id; supervisor proof for ns5_01. */
        awaitingStep?: Ns5StepId;
        /** Per-step checkpoint; empty at create. */
        steps: Partial<Record<Ns5StepId, Ns5PipelineStepState>>;
        /** Original user prompt after flags are stripped. */
        sourcePrompt: string;
        /** Flags used for this run. */
        invocation: Ns5Invocation;
        /** Set when this pipeline was created by /rebuild all. */
        rebuildAll?: Ns5RebuildAllReport;
        updatedAt: string;
    }
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from "_102034_/l1/mdm/defs/level1Types";
}
declare module "_102035_/l2/solution/fs" {
    import type { Ns4SolutionRegistryArtifact } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    import type { Ns5PipelineState, Ns5StepId } from "_102035_/l2/solution/types";
    export type Ns5FileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export function normalizeModuleName(value: unknown, fallback?: string): string;
    export function moduleFile(moduleName: string): Ns5FileInfo;
    export function journeyFile(moduleName: string, journeyId: string): Ns5FileInfo;
    export function journeyIndexFile(moduleName: string): Ns5FileInfo;
    export function ontologyEntityFile(moduleName: string, entityId: string): Ns5FileInfo;
    export function ontologyIndexFile(moduleName: string): Ns5FileInfo;
    export function rulesFile(moduleName: string): Ns5FileInfo;
    export function workflowsFile(moduleName: string): Ns5FileInfo;
    export function accessFile(moduleName: string): Ns5FileInfo;
    export function integrationFile(moduleName: string): Ns5FileInfo;
    export function pipelineFile(moduleName: string): Ns5FileInfo;
    export function pipelineJsonFile(moduleName: string, shortName: string): Ns5FileInfo;
    export function finalizeReportFile(moduleName: string): Ns5FileInfo;
    export function listPipelineJsonShortNames(moduleName: string): string[];
    export function draftFile(moduleName: string, step: Ns5StepId | string): Ns5FileInfo;
    export function agentFile(folder: string, shortName: string, extension: string): Ns5FileInfo;
    export function registryFile(): Ns5FileInfo;
    export function displayPath(fileInfo: Ns5FileInfo): string;
    export function assertShortName(shortName: string): void;
    export function fileExists(fileInfo: Ns5FileInfo): boolean;
    export function listModuleFolders(): Set<string>;
    export function isExactModuleFolder(folder: string, moduleName: string): boolean;
    export function listModuleL4Keys(files: Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    } | undefined>, project: number, moduleName: string): string[];
    export type Ns5DefsKind = 'journeys' | 'ontology';
    /** shortNames of `.defs.ts` in `l4/<mod>/<kind>/`, including status=deleted and host disk. */
    export function listModuleDefsShortNames(moduleName: string, kind: Ns5DefsKind): string[];
    export function ns5DefsOrphans(diskShortNames: string[], indexIds: string[]): string[];
    export function reconcileModuleDefs(moduleName: string, kind: Ns5DefsKind, indexIds: string[]): Promise<string[]>;
    export function deleteModuleL4(moduleName: string): Promise<string[]>;
    export function readJson<T>(fileInfo: Ns5FileInfo): Promise<T | null>;
    export function writeJson(fileInfo: Ns5FileInfo, value: unknown): Promise<string>;
    export function writeDefs(fileInfo: Ns5FileInfo, exportName: string, value: unknown, typeName: string): Promise<string>;
    export function renderDefsSource(fileInfo: Ns5FileInfo, exportName: string, value: unknown, typeName: string): string;
    export function readPipeline(moduleName: string): Promise<Ns5PipelineState | null>;
    export function writePipeline(state: Ns5PipelineState): Promise<string>;
    export function readAgentText(folder: string, shortName: string, extension?: string): Promise<string>;
    export function readAgentJson<T>(folder: string, shortName: string, extension?: string): Promise<T>;
    export function readDefsJson<T>(fileInfo: Ns5FileInfo): Promise<T | null>;
    export function readSolutionRegistry(): Promise<Ns4SolutionRegistryArtifact | null>;
}
declare module "_102035_/l2/agentNewSolution5/helpers/ns5Core" {
    import { NS5_STEP_IDS, type Ns5Invocation, type Ns5PipelineState, type Ns5PipelineStepState, type Ns5StepId } from "_102035_/l2/solution/types";
    export const NS5_FLOW_ID: "agentNewSolution5";
    export const NS5_FLOW_VERSION: "2026-09-10-ns5-flow-v1";
    export const NS5_AGENT_NAME: "agentNewSolution5";
    export { NS5_STEP_IDS };
    export type { Ns5StepId };
    export const NS5_STEP_TITLES: Record<Ns5StepId, string>;
    export const NS5_STEP_DEPENDS_ON: Record<Ns5StepId, readonly string[]>;
    export interface Ns5ParsedInvocation {
        fast: boolean;
        rebuildAll: boolean;
        module: string;
        prompt: string;
    }
    export function isNs5StepId(value: string): value is Ns5StepId;
    /**
     * Maps child planIds (repair/transport, ontology fan-out, bindings, finalize) back to the owning
     * step. Done-anchors and reserved clarification ids stay unmatched so they are not dispatched.
     */
    export function ownerStepId(planId: string): Ns5StepId | '';
    /** Parallel ontology children are scheduled as `entity:<PascalId>` (prompt and/or hook args). */
    export function ns5OntologyEntitySelector(value: unknown): string;
    export function parseNs5Invocation(value: string): Ns5ParsedInvocation;
    export function createEmptyPipeline(moduleName: string, sourcePrompt: string, invocation: Ns5Invocation, now?: string): Ns5PipelineState;
    export function createNs5AgentStep(stepId: Ns5StepId, moduleName: string): mls.msg.AIAgentStep;
    export function buildNs5PlannedSteps(moduleName: string): mls.msg.AIAgentStep[];
    export function existingModuleName(moduleName: string): string;
    export function startNs5Pipeline(moduleName: string, sourcePrompt: string, invocation: Ns5Invocation, rebuildAll: boolean): Promise<Ns5PipelineState>;
    export function moduleTokenOk(moduleName: string): boolean;
    export function createNs5RetryStep(stepId: Ns5StepId, moduleName: string, kind: 'repair' | 'transport', attempt: number, extra?: Record<string, unknown>): mls.msg.AIAgentStep;
    export function nextNs5RunNn(existingShortNames: readonly string[]): string;
    export function markNs5Complete(pipeline: Ns5PipelineState, now?: string): Ns5PipelineState;
    export function markNs5Step(pipeline: Ns5PipelineState, stepId: Ns5StepId, next: Ns5PipelineStepState): Ns5PipelineState;
}
declare module "_102035_/l2/agentNewSolution5/helpers/ns5Dispatch" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import type { Ns5PipelineState, Ns5StepId } from "_102035_/l2/solution/types";
    export type Ns5StepBeforePrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export type Ns5StepAfterPrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export type Ns5StepBeforeClarification = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: unknown) => Promise<HTMLElement>;
    export interface Ns5StepHooks {
        beforePromptStep?: Ns5StepBeforePrompt;
        afterPromptStep?: Ns5StepAfterPrompt;
        beforeClarificationStep?: Ns5StepBeforeClarification;
    }
    /** Filled by later specs. A missing entry means the step is not implemented yet. */
    export const NS5_STEP_HOOKS: Partial<Record<Ns5StepId, Ns5StepHooks>>;
    export function planIdOf(step: mls.msg.AIAgentStep): string;
    export function hooksFor(planId: string, ...selectors: unknown[]): Ns5StepHooks | undefined;
    export function markAwaitingStep(pipeline: Ns5PipelineState, stepId: Ns5StepId): Promise<Ns5PipelineState>;
    export function updateStatus(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg: string): mls.msg.AgentIntentUpdateStatus;
    export function drainWaitingSiblings(context: mls.msg.ExecutionContext, current: mls.msg.AIAgentStep, hookSequential: number, traceMsg: string, opts?: {
        onlyUnimplemented?: boolean;
    }): mls.msg.AgentIntentUpdateStatus[];
}
declare module "_102035_/l2/agentNewSolution5/helpers/ns5Skills" {
    /** First heading of `skills/mdm.md`; injected system prompts start with this line. */
    export const NS5_MDM_SKILL_HEADING = "# MDM \u2014 how the platform keeps people, companies, products and places";
    export function readNs5MdmSkill(): Promise<string>;
    /** Prepends the MDM skill as the first block of a step system prompt. */
    export function composeNs5SystemPrompt(skillText: string, stepPrompt: string): string;
}
declare module "_102035_/l2/solution/lib" {
    /**
     * Neutral re-exports of pure NS4 helpers. The NS4 files stay in place; NS5 steps import from here.
     */
    export { ns4ResolvableFields as resolvableFields, ns4ResolvableFieldIds as resolvableFieldIds, ns4ResolvableFieldOf as resolvableFieldOf, ns4EntityIdField as entityIdField, ns4BindingPromptEntity as bindingPromptEntity, NS4_IDENTITY_FIELD_DESCRIPTION as IDENTITY_FIELD_DESCRIPTION, } from "_102035_/l2/agentNewSolution/helpers/ns4EntityFields";
    export type { Ns4EntityFieldsSource as EntityFieldsSource } from "_102035_/l2/agentNewSolution/helpers/ns4EntityFields";
    export { ns4Level1Catalog as level1Catalog, ns4Level1PlatformCatalog as level1PlatformCatalog, ns4Level1Subtypes as level1Subtypes, ns4Level1IsSubtype as level1IsSubtype, ns4Level1Entity as level1Entity, ns4Level1FieldIds as level1FieldIds, ns4Level1FieldSlot as level1FieldSlot, } from "_102035_/l2/agentNewSolution/helpers/level1Catalog";
    export { NS4_LEVEL1_SCHEMA_VERSION as LEVEL1_SCHEMA_VERSION, NS4_SOLUTION_REGISTRY_SCHEMA_VERSION as SOLUTION_REGISTRY_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES as LEVEL1_SUBTYPE_VALUES, } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export type { Ns4Level1Subtype as Level1Subtype, Ns4Level1Field as Level1Field, Ns4Level1EntityArtifact as Level1EntityArtifact, Ns4Level1IndexArtifact as Level1IndexArtifact, MdmPlatformCatalogArtifact as PlatformCatalogArtifact, Ns4SolutionRegistryActor as SolutionRegistryActor, Ns4SolutionRegistryRole as SolutionRegistryRole, Ns4SolutionRegistryModule as SolutionRegistryModule, Ns4SolutionRegistryArtifact as SolutionRegistryArtifact, } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export { emptyNs4SolutionRegistry as emptySolutionRegistry, upsertNs4SolutionRegistryModule as upsertSolutionRegistryModule, inferNs4RegistryMdmSubtype as inferRegistryMdmSubtype, buildNs4SolutionRegistryModuleBlock as buildSolutionRegistryModuleBlock, serializeNs4SolutionRegistry as serializeSolutionRegistry, } from "_102035_/l2/agentNewSolution/helpers/organizationRegistry";
    export { validateNs4SolutionRegistry as validateSolutionRegistry, } from "_102035_/l2/agentNewSolution/helpers/registryGate";
    export type { Ns4RegistryGateIssue as SolutionRegistryGateIssue, Ns4RegistryGateResult as SolutionRegistryGateResult, } from "_102035_/l2/agentNewSolution/helpers/registryGate";
    export { NS4_PHRASES as phrases, NS4_PHRASE_MAX_LENGTH as PHRASE_MAX_LENGTH, isNs4PhraseKey as isPhraseKey, ns4Text as text, ns4WidgetLabels as widgetLabels, normalizeNs4Phrases as normalizePhrases, ns4PlannerPhrasesAppendix as plannerPhrasesAppendix, } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    export type { Ns4PhraseKey as PhraseKey, Ns4PhraseHolder as PhraseHolder, Ns4PhrasesNormalization as PhrasesNormalization, } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    export { createNs4FlexibleWorkerTool as createStrictArtifactTool, unwrapNs4FlexibleWorkerPayload as unwrapArtifactPayload, } from "_102035_/l2/agentNewSolution/helpers/ns4WorkerTools";
    export { readNs4L5Config as readL5Config, writeNs4L5Config as writeL5Config, readNs4L5Project as readL5Project, writeNs4L5Project as writeL5Project, writeNs4SolutionRegistry as writeSolutionRegistry, } from "_102035_/l2/agentNewSolution/helpers/ns4Fs";
    export { applyPlatformBlockDefaults, buildProjectsBlock, buildWorkspaceDependencies, collectProjectJsonIssues, collectPublishableConfigIssues, ensureProjectAppEnv, ensureProjectModule, ensureProjectType, readProjectTypeFromProjectJson, } from "_102035_/l2/agentNewSolution/steps/e10/publishable";
    export type { PublishableIssue, PublishableProjectType } from "_102035_/l2/agentNewSolution/steps/e10/publishable";
}
declare module "_102035_/l2/agentNewSolution5/steps/module10/contracts" {
    import { type Ns5ModuleArtifact } from "_102035_/l2/solution/types";
    export interface Ns5ModuleNormalizeOptions {
        sourcePrompt: string;
        /** When set, the artifact moduleName must match this token. */
        fixedModuleName?: string;
    }
    export interface Ns5ModuleNormalization {
        artifact: Ns5ModuleArtifact;
        i18nWarnings: string[];
    }
    export function buildNs5ModuleTool(schema: Record<string, unknown>, createTool: (name: string, description: string, artifactSchema: Record<string, unknown>) => mls.msg.LLMTool): mls.msg.LLMTool;
    export function normalizeNs5ModuleArtifact(value: unknown, options: Ns5ModuleNormalizeOptions): Ns5ModuleNormalization;
}
declare module "_102035_/l2/agentNewSolution5/steps/module10/gate" {
    import { type Ns5ModuleArtifact } from "_102035_/l2/solution/types";
    export interface Ns5ModuleGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns5ModuleGateResult {
        ok: boolean;
        issues: Ns5ModuleGateIssue[];
    }
    export interface Ns5ModuleGateContext {
        /** When the invocation fixed /module, the artifact must use that token. */
        fixedModuleName?: string;
    }
    export function validateNs5ModuleArtifact(artifact: Ns5ModuleArtifact, context?: Ns5ModuleGateContext): Ns5ModuleGateResult;
    export function formatNs5ModuleGate(issues: Ns5ModuleGateIssue[]): string;
}
declare module "_102035_/l2/agentNewSolution5/steps/module10/agentNs5Module" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function buildNs5ModuleHumanPrompt(input: {
        sourcePrompt: string;
        fixedModuleName: string;
        organizationContext: string;
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function beforeNs5ModulePromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs5ModulePromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/contracts" {
    import { type Ns5JourneyArtifact, type Ns5JourneyIndexArtifact, type Ns5SystemDecision } from "_102035_/l2/solution/types";
    export interface Ns5JourneyDraft {
        journeyId: string;
        business: Ns5JourneyArtifact['business'];
    }
    export interface Ns5JourneysNormalization {
        journeys: Ns5JourneyDraft[];
    }
    export function buildNs5JourneysTool(schema: Record<string, unknown>, createTool: (name: string, description: string, artifactSchema: Record<string, unknown>) => mls.msg.LLMTool): mls.msg.LLMTool;
    export function normalizeNs5JourneysPayload(value: unknown): Ns5JourneysNormalization;
    export function hashNs5Journey(draft: Ns5JourneyDraft): Promise<Ns5JourneyArtifact>;
    export function buildNs5JourneyIndex(moduleName: string, artifacts: Ns5JourneyArtifact[], systemDecisions: Ns5SystemDecision[]): Ns5JourneyIndexArtifact;
    export function countNs5DecideSteps(journeys: Array<{
        business: {
            steps: Array<{
                kind: string;
            }>;
        };
    }>): number;
    export function ns5JourneyOperationKey(journey: Ns5JourneyDraft): string;
    export function sha256Ns5(value: unknown): Promise<string>;
    /** Lexical PascalCase id. Does not translate or substitute a domain noun. */
    export function normalizeEntityId(value: unknown): string;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/gate" {
    import type { Ns5JourneyDraft } from "_102035_/l2/agentNewSolution5/steps/journeys20/contracts";
    import type { Ns5ModuleActor, Ns5SystemDecision } from "_102035_/l2/solution/types";
    export const NS5_JOURNEY_DROP_CHOICE: "drop";
    export const NS5_JOURNEY_KEEP_CHOICE: "keep";
    export interface Ns5JourneyGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns5JourneyGateResult {
        ok: boolean;
        issues: Ns5JourneyGateIssue[];
    }
    export interface Ns5JourneyGateContext {
        actors: readonly Ns5ModuleActor[];
        moduleName?: string;
    }
    export interface Ns5InferredActorDrop {
        journeys: Ns5JourneyDraft[];
        actors: Ns5ModuleActor[];
        systemDecisions: Ns5SystemDecision[];
        droppedActorIds: string[];
    }
    export function validateNs5Journeys(journeys: Ns5JourneyDraft[], context: Ns5JourneyGateContext): Ns5JourneyGateResult;
    export function formatNs5JourneyGate(issues: Ns5JourneyGateIssue[]): string;
    export function ns5DropInferredActorDecisionId(actorId: string): string;
    /**
     * Inferred external actor whose steps are all also performed by another actor (or who has no
     * steps) is a persona: drop the actor and their journeys. kind:system stays. origin is the only
     * structured signal.
     */
    export function applyNs5InferredActorDrop(journeys: Ns5JourneyDraft[], actors: readonly Ns5ModuleActor[]): Ns5InferredActorDrop;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/agentNs5Journeys" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import type { Ns5ModuleActor } from "_102035_/l2/solution/types";
    export function buildNs5JourneysHumanPrompt(input: {
        sourcePrompt: string;
        userLanguage: string;
        actors: Ns5ModuleActor[];
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function beforeNs5JourneysPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs5JourneysPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/contracts" {
    import { type Ns5ModuleArtifact, type Ns5OntologyEntityArtifact, type Ns5OntologyField, type Ns5OntologyIndexArtifact, type Ns5OntologyRelationship } from "_102035_/l2/solution/types";
    export const NS5_ONTOLOGY_MAX_PARALLEL: 20;
    export const NS5_ONTOLOGY_KINDS: readonly ["core", "event", "supporting", "mdm", "valueObject"];
    export const NS5_ONTOLOGY_PARTIES: readonly ["person", "organization", "none"];
    export const NS5_ONTOLOGY_FIELD_TYPES: readonly ["uuid", "string", "text", "number", "integer", "boolean", "money", "date", "datetime", "json"];
    export const NS5_ONTOLOGY_STORAGE_TARGETS: readonly ["moduleDatabase", "mdm", "external"];
    export const NS5_ONTOLOGY_RELATIONSHIP_TYPES: readonly ["oneToOne", "oneToMany", "manyToOne", "manyToMany"];
    export const NS5_ONTOLOGY_PERSISTENCE_MODES: readonly ["moduleReference", "crossStoreReference", "mdmRelationship", "externalReference"];
    export const NS5_ONTOLOGY_REALIZATION_KINDS: readonly ["fieldReference", "fieldCollection", "mdmRelationship", "externalReference"];
    export const NS5_ONTOLOGY_REACHED_BY: readonly ["actor", "command", "time"];
    export type Ns5OntologyKind = typeof NS5_ONTOLOGY_KINDS[number];
    export type Ns5OntologyParty = typeof NS5_ONTOLOGY_PARTIES[number];
    export type Ns5OntologyFieldType = typeof NS5_ONTOLOGY_FIELD_TYPES[number];
    export type Ns5OntologyStorageTarget = typeof NS5_ONTOLOGY_STORAGE_TARGETS[number];
    export type Ns5OntologyRelationshipType = typeof NS5_ONTOLOGY_RELATIONSHIP_TYPES[number];
    export type Ns5OntologyPersistenceMode = typeof NS5_ONTOLOGY_PERSISTENCE_MODES[number];
    export type Ns5OntologyRealizationKind = typeof NS5_ONTOLOGY_REALIZATION_KINDS[number];
    export type Ns5OntologyReachedBy = typeof NS5_ONTOLOGY_REACHED_BY[number];
    export type Ns5OntologyTransitionBy = string[] | 'system' | 'time';
    export interface Ns5OntologyPlanEntity {
        entityId: string;
        title: string;
        description: string;
        kind: Ns5OntologyKind;
        party: Ns5OntologyParty;
        mdmSubtype?: string;
        displayField: string;
        mutability?: 'appendOnly';
        storage: Ns5OntologyEntityArtifact['storage'];
    }
    export interface Ns5OntologyPlanRelationship {
        relationshipId: string;
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
        persistence: {
            mode: Ns5OntologyPersistenceMode;
        };
    }
    export interface Ns5OntologyPlanDraft {
        moduleName: string;
        businessDomain: string;
        entities: Ns5OntologyPlanEntity[];
        relationships: Ns5OntologyPlanRelationship[];
        /** Organization-wide aggregates; copied onto module.defs.ts at persist. */
        moduleDetails?: Record<string, string>;
        /**
         * Ids removed by `liftNs5AggregateOnlyEntities` after fan-out. Not an LLM field;
         * normalize drops it. The ontology gate skips `NS5_ONTOLOGY_JOURNEY_ENTITY` for these
         * names so a locate→inspect of the former panel still closes ontology30.
         */
        liftedAggregateEntities?: string[];
    }
    export interface Ns5OntologyEntityDraft {
        entityId: string;
        fields: Ns5OntologyField[];
        details?: Record<string, string>;
        lifecycleStates: Ns5OntologyEntityArtifact['lifecycleStates'];
        transitions: Ns5OntologyEntityArtifact['transitions'];
    }
    export interface Ns5OntologyBinding {
        relationshipId: string;
        realization: Ns5OntologyRelationship['realization'];
    }
    export interface Ns5OntologyBindingsDraft {
        bindings: Ns5OntologyBinding[];
    }
    export interface Ns5OntologyAssembly {
        entities: Ns5OntologyEntityArtifact[];
        index: Ns5OntologyIndexArtifact;
    }
    export function buildNs5OntologyPlanTool(schema: Record<string, unknown>, createTool: (name: string, description: string, artifactSchema: Record<string, unknown>) => mls.msg.LLMTool): mls.msg.LLMTool;
    export function buildNs5OntologyEntityTool(schema: Record<string, unknown>, createTool: (name: string, description: string, artifactSchema: Record<string, unknown>) => mls.msg.LLMTool): mls.msg.LLMTool;
    export function buildNs5OntologyBindingsTool(schema: Record<string, unknown>, createTool: (name: string, description: string, artifactSchema: Record<string, unknown>) => mls.msg.LLMTool): mls.msg.LLMTool;
    export function normalizeNs5OntologyPlan(value: unknown, moduleName: string, journeys?: ReadonlyArray<Ns5LifecycleJourneyView>): Ns5OntologyPlanDraft;
    /** Copies organization-wide aggregates onto the module envelope. Empty omits the field. */
    export function applyNs5ModuleDetails(module: Ns5ModuleArtifact, details: Record<string, string> | undefined): Ns5ModuleArtifact;
    /** Journey slice the aggregate-only predicate reads (act on the entity or in affects). */
    export type Ns5AggregateJourneyView = {
        business: {
            steps: ReadonlyArray<{
                kind: string;
                entity: string;
                affects?: string[];
            }>;
        };
    };
    export function ns5EntityHasActOrAffects(journeys: ReadonlyArray<Ns5AggregateJourneyView>, entityId: string): boolean;
    /**
     * Same predicate as `NS5_ONTOLOGY_AGGREGATE_ONLY_ENTITY`: core/supporting, details
     * not empty, no journey `act` on it or in `affects`.
     */
    export function isNs5AggregateOnlyEntity(entity: {
        entityId: string;
        kind: string;
        details?: Record<string, string>;
    }, journeys: ReadonlyArray<Ns5AggregateJourneyView>): boolean;
    export interface Ns5AggregateLiftIssue {
        severity: 'error';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns5AggregateLiftResult {
        plan: Ns5OntologyPlanDraft;
        details: Ns5OntologyEntityDraft[];
        liftedEntityIds: string[];
        issues: Ns5AggregateLiftIssue[];
    }
    /**
     * After entity fan-out: move aggregate-only entities into `plan.moduleDetails` and
     * drop them from the plan. A relationship to another entity is not lifted (the gate
     * stays as the net). Two lifted entities claiming the same details key is an error;
     * a key already on `moduleDetails` is kept, not overwritten.
     */
    export function liftNs5AggregateOnlyEntities(plan: Ns5OntologyPlanDraft, details: Ns5OntologyEntityDraft[], journeys: ReadonlyArray<Ns5AggregateJourneyView>): Ns5AggregateLiftResult;
    export function normalizeNs5OntologyEntity(value: unknown, entityId: string): Ns5OntologyEntityDraft;
    export function normalizeNs5OntologyBindings(value: unknown): Ns5OntologyBindingsDraft;
    export function assembleNs5Ontology(plan: Ns5OntologyPlanDraft, details: Ns5OntologyEntityDraft[], bindings?: Ns5OntologyBindingsDraft): Ns5OntologyAssembly;
    export function applyNs5OntologyBindings(plan: Ns5OntologyPlanDraft, entities: Ns5OntologyEntityArtifact[], bindings?: Ns5OntologyBindingsDraft): {
        entities: Ns5OntologyEntityArtifact[];
        relationships: Ns5OntologyRelationship[];
    };
    export function collectNs5CitedEntities(journeys: ReadonlyArray<{
        business: {
            steps: ReadonlyArray<{
                entity: string;
                affects?: string[];
            }>;
        };
    }>): Set<string>;
    /** Journey view the lifecycle walk understands. Caller supplies index order. */
    export interface Ns5LifecycleJourneyView {
        business: {
            steps: ReadonlyArray<{
                kind: string;
                entity: string;
            }>;
        };
    }
    /**
     * Structural I2 signal for one entity: a second `act` (after the first create) requires
     * declared transitions; a `decide` requires a branching origin. Same walk finalize80.checkI2
     * uses — ontology30 imports this; finalize80 must not recompute it.
     */
    export interface Ns5LifecycleSignal {
        requiresTransitions: boolean;
        requiresBranching: boolean;
    }
    export function collectNs5LifecycleSignal(journeys: ReadonlyArray<Ns5LifecycleJourneyView>, entityId: string): Ns5LifecycleSignal;
    export function ns5LifecycleHasBranchingOrigin(entity: {
        transitions: ReadonlyArray<{
            from: readonly string[];
        }>;
    }): boolean;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/gate" {
    import type { Ns5JourneyArtifact, Ns5ModuleActor, Ns5OntologyEntityArtifact, Ns5OntologyIndexArtifact, Ns5OntologyRelationship } from "_102035_/l2/solution/types";
    import { type Ns5OntologyAssembly, type Ns5OntologyBindingsDraft, type Ns5OntologyEntityDraft, type Ns5OntologyPlanDraft } from "_102035_/l2/agentNewSolution5/steps/ontology30/contracts";
    export interface Ns5OntologyGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns5OntologyGateResult {
        ok: boolean;
        issues: Ns5OntologyGateIssue[];
        uncitedEntities: string[];
    }
    export interface Ns5OntologyGateContext {
        moduleName: string;
        actors: readonly Ns5ModuleActor[];
        journeys?: ReadonlyArray<Pick<Ns5JourneyArtifact, 'business'>>;
        planOverview?: boolean;
        requireRelationshipRealization?: boolean;
        requireJourneyCitation?: boolean;
        /** Entity ids ontology30 lifted into module.details; citation check skips them. */
        liftedAggregateEntityIds?: readonly string[];
    }
    export function validateNs5OntologyPlan(plan: Ns5OntologyPlanDraft, context: Ns5OntologyGateContext): Ns5OntologyGateResult;
    export function validateNs5OntologyEntity(plan: Ns5OntologyPlanDraft, detail: Ns5OntologyEntityDraft, context: Ns5OntologyGateContext): Ns5OntologyGateResult;
    export function validateNs5OntologyBindings(plan: Ns5OntologyPlanDraft, details: Ns5OntologyEntityDraft[], bindings: Ns5OntologyBindingsDraft, context: Ns5OntologyGateContext): Ns5OntologyGateResult;
    export function validateNs5OntologyAssembly(assembled: Ns5OntologyAssembly, context: Ns5OntologyGateContext): Ns5OntologyGateResult;
    export const NS5_PLATFORM_SERVICE_KEEP: "keepEntity";
    export const NS5_PLATFORM_SERVICE_USE: "usePlatformService";
    export function collectNs5PlatformServiceCandidates(entities: readonly Ns5OntologyEntityArtifact[], relationships: readonly Pick<Ns5OntologyRelationship, 'fromEntity' | 'toEntity' | 'type'>[]): string[];
    export function applyNs5PlatformServiceCandidateDecisions(index: Ns5OntologyIndexArtifact, entities: readonly Ns5OntologyEntityArtifact[]): Ns5OntologyIndexArtifact;
    export function formatNs5OntologyGate(issues: Ns5OntologyGateIssue[]): string;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/agentNs5Ontology" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import type { Ns5JourneyArtifact, Ns5ModuleActor, Ns5OntologyEntityArtifact } from "_102035_/l2/solution/types";
    import { type Ns5OntologyPlanDraft } from "_102035_/l2/agentNewSolution5/steps/ontology30/contracts";
    export function buildNs5OntologyPlanHumanPrompt(input: {
        sourcePrompt: string;
        userLanguage: string;
        actors: Ns5ModuleActor[];
        journeys: Ns5JourneyArtifact[];
        level1Catalog: string;
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function buildNs5OntologyEntityHumanPrompt(input: {
        sourcePrompt: string;
        userLanguage: string;
        actors: Ns5ModuleActor[];
        journeys: Ns5JourneyArtifact[];
        plan: Ns5OntologyPlanDraft;
        entityId: string;
        level1Catalog: string;
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function buildNs5OntologyBindingsHumanPrompt(input: {
        plan: Ns5OntologyPlanDraft;
        entities: Ns5OntologyEntityArtifact[];
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function beforeNs5OntologyPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs5OntologyPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution5/steps/rules40/contracts" {
    import { type Ns5Rule, type Ns5RulesArtifact } from "_102035_/l2/solution/types";
    export interface Ns5RulesNormalization {
        rules: Ns5Rule[];
    }
    export interface Ns5RulesRefCatalog {
        entityIds: string[];
        fieldRefs: string[];
        transitionRefs: string[];
        journeyIds: string[];
        timeTransitionRefs: string[];
    }
    export interface Ns5RulesEntityView {
        entityId: string;
        fields: ReadonlyArray<{
            fieldId: string;
        }>;
        details?: Record<string, string>;
        storage?: {
            idField: string;
        };
        transitions: ReadonlyArray<{
            transitionId: string;
            by: string[] | 'system' | 'time';
        }>;
    }
    export function buildNs5RulesTool(schema: Record<string, unknown>, createTool: (name: string, description: string, artifactSchema: Record<string, unknown>) => mls.msg.LLMTool): mls.msg.LLMTool;
    export function normalizeNs5RulesPayload(value: unknown): Ns5RulesNormalization;
    export function buildNs5RulesArtifact(moduleName: string, rules: Ns5Rule[]): Ns5RulesArtifact;
    export function collectNs5RulesRefCatalog(entities: readonly Ns5RulesEntityView[], journeys: ReadonlyArray<{
        journeyId: string;
    }>): Ns5RulesRefCatalog;
    export function ns5FieldRefExists(ref: string, entity: Ns5RulesEntityView): boolean;
    export function splitFieldRef(ref: string): {
        entityId: string;
        fieldId: string;
        detailsName: string;
    } | null;
    export function splitTransitionRef(ref: string): {
        entityId: string;
        transitionId: string;
    } | null;
}
declare module "_102035_/l2/agentNewSolution5/steps/rules40/gate" {
    import type { Ns5Rule } from "_102035_/l2/solution/types";
    export interface Ns5RulesGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns5RulesGateResult {
        ok: boolean;
        issues: Ns5RulesGateIssue[];
    }
    export interface Ns5RulesGateContext {
        moduleName?: string;
    }
    export function validateNs5Rules(rules: Ns5Rule[], _context?: Ns5RulesGateContext): Ns5RulesGateResult;
    export function formatNs5RulesGate(issues: Ns5RulesGateIssue[]): string;
}
declare module "_102035_/l2/agentNewSolution5/steps/rules40/agentNs5Rules" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import type { Ns5JourneyArtifact, Ns5OntologyEntityArtifact } from "_102035_/l2/solution/types";
    export function buildNs5RulesHumanPrompt(input: {
        sourcePrompt: string;
        userLanguage: string;
        journeys: Ns5JourneyArtifact[];
        entities: Ns5OntologyEntityArtifact[];
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function beforeNs5RulesPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs5RulesPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution5/steps/workflows50/contracts" {
    import { type Ns5WorkflowProcess, type Ns5WorkflowsArtifact } from "_102035_/l2/solution/types";
    export interface Ns5WorkflowsNormalization {
        processes: Ns5WorkflowProcess[];
    }
    export interface Ns5WorkflowsJourneyView {
        journeyId: string;
        business: {
            actorRef: string;
            steps: ReadonlyArray<{
                stepId: string;
                kind: string;
                entity: string;
                affects?: string[];
                handoffTo?: string;
                title?: string;
                description?: string;
            }>;
        };
    }
    export interface Ns5WorkflowsEntityView {
        entityId: string;
        transitions: ReadonlyArray<{
            transitionId: string;
            by: string[] | 'system' | 'time';
        }>;
    }
    export interface Ns5ProcessSignal {
        kind: 'handoff' | 'foreignBy' | 'crossActorDecide';
        journeyId?: string;
        stepId?: string;
        entityId?: string;
        transitionId?: string;
    }
    export interface Ns5HandoffRef {
        journeyId: string;
        stepId: string;
        handoffTo: string;
    }
    export function buildNs5WorkflowsTool(schema: Record<string, unknown>, createTool: (name: string, description: string, artifactSchema: Record<string, unknown>) => mls.msg.LLMTool): mls.msg.LLMTool;
    export function normalizeNs5WorkflowsPayload(value: unknown): Ns5WorkflowsNormalization;
    export function buildNs5WorkflowsArtifact(moduleName: string, processes: Ns5WorkflowProcess[]): Ns5WorkflowsArtifact;
    export function collectNs5ProcessSignals(journeys: readonly Ns5WorkflowsJourneyView[], entities: readonly Ns5WorkflowsEntityView[]): Ns5ProcessSignal[];
    export function collectNs5Handoffs(journeys: readonly Ns5WorkflowsJourneyView[]): Ns5HandoffRef[];
    export function collectNs5WorkflowsRefCatalog(journeys: readonly Ns5WorkflowsJourneyView[], actorIds: readonly string[]): {
        actorIds: string[];
        journeyIds: string[];
        stepRefs: string[];
        handoffs: Ns5HandoffRef[];
    };
}
declare module "_102035_/l2/agentNewSolution5/steps/workflows50/gate" {
    import type { Ns5WorkflowProcess } from "_102035_/l2/solution/types";
    import { type Ns5WorkflowsEntityView, type Ns5WorkflowsJourneyView } from "_102035_/l2/agentNewSolution5/steps/workflows50/contracts";
    export interface Ns5WorkflowsGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns5WorkflowsGateResult {
        ok: boolean;
        issues: Ns5WorkflowsGateIssue[];
    }
    export interface Ns5WorkflowsGateContext {
        moduleName?: string;
        actorIds: readonly string[];
        journeys: readonly Ns5WorkflowsJourneyView[];
        entities: readonly Ns5WorkflowsEntityView[];
    }
    export function validateNs5Workflows(processes: Ns5WorkflowProcess[], context: Ns5WorkflowsGateContext): Ns5WorkflowsGateResult;
    export function formatNs5WorkflowsGate(issues: Ns5WorkflowsGateIssue[]): string;
}
declare module "_102035_/l2/agentNewSolution5/steps/workflows50/agentNs5Workflows" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import type { Ns5JourneyArtifact, Ns5OntologyEntityArtifact } from "_102035_/l2/solution/types";
    export function buildNs5WorkflowsHumanPrompt(input: {
        sourcePrompt: string;
        userLanguage: string;
        actorIds: string[];
        journeys: Ns5JourneyArtifact[];
        entities: Ns5OntologyEntityArtifact[];
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function beforeNs5WorkflowsPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs5WorkflowsPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution5/steps/access60/contracts" {
    import { type Ns5AccessArtifact, type Ns5AccessAuthority, type Ns5AccessGrant, type Ns5AccessProfile } from "_102035_/l2/solution/types";
    export const NS5_ACCESS_MAX_ANCHOR_HOPS: 6;
    export const NS5_ACCESS_PROFILE_KINDS: readonly ["internal", "external", "anonymous"];
    export const NS5_ACCESS_SCOPE_MODES: readonly ["own", "assigned", "related", "public", "organization", "custom"];
    export const NS5_ACCESS_DISCLOSURE_MODES: readonly ["fullRecord", "fieldsOnly", "summaryOnly", "aggregateOnly"];
    export const NS5_ACCESS_PERSON_SCOPE_MODES: readonly ["own", "assigned", "related"];
    export const NS5_ACCESS_LIMITED_DISCLOSURE_MODES: readonly ["fieldsOnly", "summaryOnly"];
    export type Ns5AccessProfileKind = typeof NS5_ACCESS_PROFILE_KINDS[number];
    export type Ns5AccessScopeMode = typeof NS5_ACCESS_SCOPE_MODES[number];
    export type Ns5AccessDisclosureMode = typeof NS5_ACCESS_DISCLOSURE_MODES[number];
    export interface Ns5AccessNormalization {
        profiles: Ns5AccessProfile[];
        authorities: Ns5AccessAuthority[];
        grants: Ns5AccessGrant[];
    }
    export type Ns5AccessFormNormalizationKind = 'disclosureFullRecord' | 'dropAnchorEntity';
    /** Deterministic form change recorded on the access60 draft, not on the artifact. */
    export interface Ns5AccessFormNormalization {
        kind: Ns5AccessFormNormalizationKind;
        grantId: string;
        detail: string;
    }
    export interface Ns5AccessEntityView {
        entityId: string;
        party: 'person' | 'organization' | 'none' | string;
        fields: ReadonlyArray<{
            fieldId: string;
        }>;
        details?: Record<string, string>;
        storage?: {
            idField: string;
        };
    }
    export interface Ns5AccessRelationshipView {
        relationshipId: string;
        fromEntity: string;
        toEntity: string;
        required: boolean;
    }
    export interface Ns5AccessAnchorHop {
        fromEntity: string;
        toEntity: string;
        relationshipId: string;
    }
    export interface Ns5AccessRefCatalog {
        actorIds: string[];
        entityIds: string[];
        fieldRefs: string[];
        personEntityIds: string[];
        journeyActorIds: string[];
    }
    export function buildNs5AccessTool(schema: Record<string, unknown>, createTool: (name: string, description: string, artifactSchema: Record<string, unknown>) => mls.msg.LLMTool): mls.msg.LLMTool;
    export function normalizeNs5AccessPayload(value: unknown): Ns5AccessNormalization;
    /**
     * Post-LLM form cleanup: fieldsOnly with no real restriction becomes fullRecord;
     * anchorEntity is dropped unless the scope is own/assigned/related.
     */
    export function applyNs5AccessFormNormalizations(grants: Ns5AccessGrant[], entities: readonly Ns5AccessEntityView[]): {
        grants: Ns5AccessGrant[];
        normalizations: Ns5AccessFormNormalization[];
    };
    export function grantResolvableFieldRefs(grant: Pick<Ns5AccessGrant, 'entityRefs'>, entityById: Map<string, Ns5AccessEntityView>): string[];
    export function disclosureListIsProprio(list: readonly string[], total: readonly string[]): boolean;
    export function buildNs5AccessArtifact(moduleName: string, profiles: Ns5AccessProfile[], authorities: Ns5AccessAuthority[], grants: Ns5AccessGrant[]): Ns5AccessArtifact;
    export function collectNs5AccessRefCatalog(actors: ReadonlyArray<{
        actorId: string;
    }>, entities: readonly Ns5AccessEntityView[], journeys: ReadonlyArray<{
        business: {
            actorRef: string;
        };
    }>): Ns5AccessRefCatalog;
    /**
     * Shortest path of required relationships from `fromEntity` to `anchorEntity`.
     * Empty array when they are the same entity. Null when unreachable.
     * The path is derived for the gate and the backend; it is never stored on the grant.
     */
    export function anchorPath(fromEntity: string, anchorEntity: string, relationships: readonly Ns5AccessRelationshipView[], maxHops?: 6): Ns5AccessAnchorHop[] | null;
    export function ns5AccessFieldRefExists(ref: string, entity: Ns5AccessEntityView): boolean;
    export function ns5AccessResolvableFieldRefs(entity: Ns5AccessEntityView): string[];
    export function splitAccessFieldRef(ref: string): {
        entityId: string;
        fieldId: string;
        detailsName: string;
    } | null;
    export function isAccessFieldRef(ref: string): boolean;
    export function isPersonScopeMode(mode: string): boolean;
    export function isLimitedDisclosureMode(mode: string): boolean;
}
declare module "_102035_/l2/agentNewSolution5/steps/access60/gate" {
    import type { Ns5AccessAuthority, Ns5AccessGrant, Ns5AccessProfile } from "_102035_/l2/solution/types";
    import { type Ns5AccessEntityView, type Ns5AccessRelationshipView } from "_102035_/l2/agentNewSolution5/steps/access60/contracts";
    export interface Ns5AccessGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns5AccessGateResult {
        ok: boolean;
        issues: Ns5AccessGateIssue[];
    }
    export interface Ns5AccessGateContext {
        moduleName?: string;
        actorIds: readonly string[];
        entities: readonly Ns5AccessEntityView[];
        relationships: readonly Ns5AccessRelationshipView[];
        journeys: ReadonlyArray<{
            journeyId: string;
            business: {
                actorRef: string;
            };
        }>;
    }
    export function validateNs5Access(profiles: Ns5AccessProfile[], authorities: Ns5AccessAuthority[], grants: Ns5AccessGrant[], context: Ns5AccessGateContext): Ns5AccessGateResult;
    export function formatNs5AccessGate(issues: Ns5AccessGateIssue[]): string;
}
declare module "_102035_/l2/agentNewSolution5/steps/access60/agentNs5Access" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import type { Ns5JourneyArtifact, Ns5OntologyEntityArtifact, Ns5OntologyRelationship } from "_102035_/l2/solution/types";
    export function buildNs5AccessHumanPrompt(input: {
        sourcePrompt: string;
        userLanguage: string;
        actors: ReadonlyArray<{
            actorId: string;
            kind: string;
            title: string;
            description: string;
        }>;
        journeys: Ns5JourneyArtifact[];
        entities: Ns5OntologyEntityArtifact[];
        relationships: Ns5OntologyRelationship[];
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function beforeNs5AccessPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs5AccessPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution5/steps/integration70/contracts" {
    import { type Ns5IntegrationArtifact, type Ns5IntegrationItem, type Ns5IntegrationPlugin } from "_102035_/l2/solution/types";
    /**
     * Closed platform plugin catalog. E6 recommendations of kind plugin are free-form ids; NS5
     * reuses the ids E6 has actually named (ce11: stripe / cardPayment). Domain vocabulary does
     * not belong here.
     */
    export const NS5_PLUGIN_CATALOG: readonly [{
        readonly pluginId: "stripe";
        readonly terms: readonly ["stripe"];
    }, {
        readonly pluginId: "cardPayment";
        readonly terms: readonly ["cardPayment", "card payment"];
    }];
    export const NS5_PLUGIN_IDS: readonly string[];
    export type Ns5IntegrationItemKind = 'moduleEndpoint' | 'event' | 'external';
    export interface Ns5IntegrationNormalization {
        inbound: Ns5IntegrationItem[];
        outbound: Ns5IntegrationItem[];
        plugins: Ns5IntegrationPlugin[];
    }
    export interface Ns5IntegrationActorView {
        actorId: string;
        kind: string;
    }
    export interface Ns5IntegrationEntityView {
        entityId: string;
    }
    export interface Ns5IntegrationSignal {
        kind: 'systemActor' | 'pluginTerm';
        actorId?: string;
        pluginId?: string;
        term?: string;
    }
    export function buildNs5IntegrationTool(schema: Record<string, unknown>, createTool: (name: string, description: string, artifactSchema: Record<string, unknown>) => mls.msg.LLMTool): mls.msg.LLMTool;
    export function normalizeNs5IntegrationPayload(value: unknown): Ns5IntegrationNormalization;
    export function buildNs5IntegrationArtifact(moduleName: string, inbound: Ns5IntegrationItem[], outbound: Ns5IntegrationItem[], plugins: Ns5IntegrationPlugin[]): Ns5IntegrationArtifact;
    export function collectNs5IntegrationSignals(actors: readonly Ns5IntegrationActorView[], sourcePrompt: string): Ns5IntegrationSignal[];
    export function isNs5PluginId(value: string): boolean;
    export function promptMentionsTerm(sourcePrompt: string, term: string): boolean;
}
declare module "_102035_/l2/agentNewSolution5/steps/integration70/gate" {
    import type { Ns5IntegrationItem, Ns5IntegrationPlugin } from "_102035_/l2/solution/types";
    import { type Ns5IntegrationActorView, type Ns5IntegrationEntityView } from "_102035_/l2/agentNewSolution5/steps/integration70/contracts";
    export interface Ns5IntegrationGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns5IntegrationGateResult {
        ok: boolean;
        issues: Ns5IntegrationGateIssue[];
    }
    export interface Ns5IntegrationGateContext {
        moduleName?: string;
        actors: readonly Ns5IntegrationActorView[];
        entities: readonly Ns5IntegrationEntityView[];
        registryModuleNames: readonly string[];
        sourcePrompt: string;
    }
    export function validateNs5Integration(inbound: Ns5IntegrationItem[], outbound: Ns5IntegrationItem[], plugins: Ns5IntegrationPlugin[], context: Ns5IntegrationGateContext): Ns5IntegrationGateResult;
    export function formatNs5IntegrationGate(issues: Ns5IntegrationGateIssue[]): string;
}
declare module "_102035_/l2/agentNewSolution5/steps/integration70/agentNs5Integration" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function buildNs5IntegrationHumanPrompt(input: {
        sourcePrompt: string;
        userLanguage: string;
        actors: ReadonlyArray<{
            actorId: string;
            kind: string;
            title: string;
            description: string;
        }>;
        entityIds: string[];
        registryModuleNames: string[];
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function beforeNs5IntegrationPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs5IntegrationPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution5/steps/finalize80/contracts" {
    import type { Ns5AccessArtifact, Ns5IntegrationArtifact, Ns5JourneyArtifact, Ns5JourneyIndexArtifact, Ns5ModuleArtifact, Ns5OntologyEntityArtifact, Ns5OntologyIndexArtifact, Ns5RulesArtifact, Ns5WorkflowsArtifact } from "_102035_/l2/solution/types";
    export const NS5_FINALIZE_REPORT_SCHEMA_VERSION: "2026-09-10-ns5-finalize-report-v1";
    export const NS5_ORACLE_CHECK_IDS: readonly ["I1", "I2", "I3", "I4", "I5", "I6", "I7"];
    export type Ns5OracleCheckId = typeof NS5_ORACLE_CHECK_IDS[number];
    export const NS5_FINALIZE_I7_ORPHAN_FILE: "NS5_FINALIZE_I7_ORPHAN_FILE";
    export const NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION: "NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION";
    export type Ns5OracleIssueCode = `NS5_FINALIZE_${Exclude<Ns5OracleCheckId, 'I7'>}` | typeof NS5_FINALIZE_I7_ORPHAN_FILE | typeof NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION;
    export interface Ns5OracleSources {
        module: Ns5ModuleArtifact;
        journeys: Ns5JourneyArtifact[];
        journeyIndex: Ns5JourneyIndexArtifact;
        entities: Ns5OntologyEntityArtifact[];
        ontologyIndex: Ns5OntologyIndexArtifact;
        rules: Ns5RulesArtifact;
        workflows: Ns5WorkflowsArtifact;
        access: Ns5AccessArtifact;
        integration: Ns5IntegrationArtifact;
        /** shortNames of `journeys/*.defs.ts` on disk (including `index`). Omit to skip I7. */
        journeyDiskFiles?: string[];
        /** shortNames of `ontology/*.defs.ts` on disk (including `index`). Omit to skip I7. */
        ontologyDiskFiles?: string[];
        /**
         * From `pipeline.json` ontology30: entity ids absorbed into `module.details`.
         * I1 treats a journey `entity`/`affects` of one of these as a module.details ref
         * when that map still has keys.
         */
        liftedAggregateEntities?: string[];
    }
    export interface Ns5OracleIssue {
        checkId: Ns5OracleCheckId;
        code: Ns5OracleIssueCode;
        path: string;
        message: string;
    }
    export interface Ns5OracleCheckSummary {
        checkId: Ns5OracleCheckId;
        status: 'passed' | 'failed' | 'warned';
        errorCount: number;
        warningCount: number;
    }
    export interface Ns5FinalizeReport {
        schemaVersion: typeof NS5_FINALIZE_REPORT_SCHEMA_VERSION;
        moduleName: string;
        finalStatus: 'passed' | 'failed';
        checks: Ns5OracleCheckSummary[];
        errors: Ns5OracleIssue[];
        warnings: Ns5OracleIssue[];
        counts: {
            actors: number;
            journeys: number;
            entities: number;
            rules: number;
            processes: number;
            profiles: number;
            grants: number;
        };
    }
    export function oracleCode(checkId: Ns5OracleCheckId): Ns5OracleIssue['code'];
    export function buildNs5FinalizeReport(moduleName: string, errors: Ns5OracleIssue[], warnings: Ns5OracleIssue[], counts: Ns5FinalizeReport['counts']): Ns5FinalizeReport;
    export function formatNs5Oracle(report: Ns5FinalizeReport): string;
    export function ensureConfigListsModule(config: Record<string, unknown>, moduleName: string, userLanguage: string, projectId: number): Record<string, unknown>;
}
declare module "_102035_/l2/agentNewSolution5/steps/finalize80/gate" {
    import { type Ns5FinalizeReport, type Ns5OracleSources } from "_102035_/l2/agentNewSolution5/steps/finalize80/contracts";
    export function runNs5Oracle(sources: Ns5OracleSources): Ns5FinalizeReport;
}
declare module "_102035_/l2/agentNewSolution5/steps/finalize80/agentNs5Finalize" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeNs5FinalizePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterNs5FinalizePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102035_/l2/agentNewSolution5/agentNewSolution5" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import "_102035_/l2/agentNewSolution5/steps/module10/agentNs5Module";
    import "_102035_/l2/agentNewSolution5/steps/journeys20/agentNs5Journeys";
    import "_102035_/l2/agentNewSolution5/steps/ontology30/agentNs5Ontology";
    import "_102035_/l2/agentNewSolution5/steps/rules40/agentNs5Rules";
    import "_102035_/l2/agentNewSolution5/steps/workflows50/agentNs5Workflows";
    import "_102035_/l2/agentNewSolution5/steps/access60/agentNs5Access";
    import "_102035_/l2/agentNewSolution5/steps/integration70/agentNs5Integration";
    import "_102035_/l2/agentNewSolution5/steps/finalize80/agentNs5Finalize";
    export function createAgent(): IAgentAsync;
}
declare module "_102035_/l2/agentNewSolution5/steps/access60/fixtures/comandaRestaurante5-access.defs" {
    export const comandaRestaurante5Access: {
        readonly schemaVersion: "2026-09-10-ns5-access-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly profiles: [{
            readonly profileId: "garcomAtendimento";
            readonly actorRefs: ["garcom"];
            readonly kind: "internal";
        }, {
            readonly profileId: "caixaFechamento";
            readonly actorRefs: ["caixa"];
            readonly kind: "internal";
        }];
        readonly authorities: [{
            readonly authorityId: "consultarCardapio";
            readonly title: "Consultar cardápio";
            readonly description: "Consulta os itens e preços disponíveis no cardápio.";
        }, {
            readonly authorityId: "gerirAtendimentoMesa";
            readonly title: "Gerir atendimento da mesa";
            readonly description: "Localiza mesas e abre ou consulta comandas durante o atendimento.";
        }, {
            readonly authorityId: "gerirItensComanda";
            readonly title: "Gerir itens da comanda";
            readonly description: "Registra itens pedidos e cancela lançamentos feitos por engano em comandas abertas.";
        }, {
            readonly authorityId: "conferirEfecharConta";
            readonly title: "Conferir e fechar conta";
            readonly description: "Consulta a comanda e seus valores para conferir e encerrar a conta após a quitação.";
        }, {
            readonly authorityId: "concederDescontoPontual";
            readonly title: "Conceder desconto pontual";
            readonly description: "Registra descontos pontuais em uma comanda durante a conferência.";
        }, {
            readonly authorityId: "registrarPagamento";
            readonly title: "Registrar pagamento";
            readonly description: "Registra pagamentos totais ou divididos destinados à comanda.";
        }];
        readonly grants: [{
            readonly grantId: "garcomConsultaCardapio";
            readonly profileRef: "garcomAtendimento";
            readonly authorityRef: "consultarCardapio";
            readonly entityRefs: ["ItemCardapio"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Itens do cardápio disponibilizados pelo restaurante.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Identificação e preço de venda dos itens do cardápio.";
            };
        }, {
            readonly grantId: "garcomGerenciaAtendimento";
            readonly profileRef: "garcomAtendimento";
            readonly authorityRef: "gerirAtendimentoMesa";
            readonly entityRefs: ["Mesa", "Comanda"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Mesas e comandas do restaurante necessárias ao atendimento.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Identificação da mesa e dados operacionais da comanda.";
                readonly allowedFields: ["Mesa.id", "Comanda.id", "Comanda.numero", "Comanda.mesa", "Comanda.status"];
            };
        }, {
            readonly grantId: "garcomGerenciaItens";
            readonly profileRef: "garcomAtendimento";
            readonly authorityRef: "gerirItensComanda";
            readonly entityRefs: ["ItemComanda"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Itens lançados nas comandas do restaurante.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Dados necessários para registrar, identificar e cancelar itens da comanda.";
            };
        }, {
            readonly grantId: "caixaConfereEfechaConta";
            readonly profileRef: "caixaFechamento";
            readonly authorityRef: "conferirEfecharConta";
            readonly entityRefs: ["Comanda", "ItemComanda"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Comandas e respectivos itens apresentados para conferência e fechamento.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Dados completos de consumo, cancelamentos e valores para conferir e encerrar a conta.";
            };
        }, {
            readonly grantId: "caixaConcedeDesconto";
            readonly profileRef: "caixaFechamento";
            readonly authorityRef: "concederDescontoPontual";
            readonly entityRefs: ["Desconto"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Descontos pontuais concedidos nas comandas do restaurante.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Dados necessários para registrar e consultar descontos pontuais.";
            };
        }, {
            readonly grantId: "caixaRegistraPagamento";
            readonly profileRef: "caixaFechamento";
            readonly authorityRef: "registrarPagamento";
            readonly entityRefs: ["Pagamento"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Pagamentos recebidos para as comandas do restaurante.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Dados necessários para registrar e consultar pagamentos recebidos.";
            };
        }];
    };
    export type ComandaRestaurante5AccessType = typeof comandaRestaurante5Access;
    export default comandaRestaurante5Access;
}
declare module "_102035_/l2/agentNewSolution5/steps/access60/fixtures/ordenServicio5-access.defs" {
    export const ordenServicio5Access: {
        readonly schemaVersion: "2026-09-10-ns5-access-v1";
        readonly moduleName: "ordenServicio5";
        readonly profiles: [{
            readonly profileId: "recepcionista";
            readonly actorRefs: ["recepcionista"];
            readonly kind: "internal";
        }, {
            readonly profileId: "tecnico";
            readonly actorRefs: ["tecnico"];
            readonly kind: "internal";
        }, {
            readonly profileId: "cliente";
            readonly actorRefs: ["cliente"];
            readonly kind: "external";
        }];
        readonly authorities: [{
            readonly authorityId: "gestionarRecepcionYentrega";
            readonly title: "Gestionar recepción y entrega";
            readonly description: "Registrar la recepción de aparatos y completar su entrega al cliente.";
        }, {
            readonly authorityId: "analizarYpresupuestar";
            readonly title: "Analizar y presupuestar órdenes";
            readonly description: "Analizar aparatos recibidos y registrar diagnósticos, piezas y presupuestos.";
        }, {
            readonly authorityId: "repararOrden";
            readonly title: "Reparar y dejar lista una orden";
            readonly description: "Registrar la reparación autorizada y marcar la orden como lista para entrega.";
        }, {
            readonly authorityId: "consultarYresponderPresupuesto";
            readonly title: "Consultar y responder presupuestos";
            readonly description: "Consultar el diagnóstico y presupuesto de las órdenes propias y aprobarlos o rechazarlos.";
        }];
        readonly grants: [{
            readonly grantId: "recepcionGestionaRecepcionYentrega";
            readonly profileRef: "recepcionista";
            readonly authorityRef: "gestionarRecepcionYentrega";
            readonly entityRefs: ["OrdenServicio", "Cliente", "Aparato", "DefectoInformado", "FotoOrden", "EntregaAparato"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Órdenes y registros de recepción o entrega gestionados por el servicio técnico.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Puede consultar y registrar los datos necesarios para recibir y entregar aparatos, sin acceso a información técnica ni costos internos.";
                readonly allowedFields: ["OrdenServicio.id", "OrdenServicio.numeroOrden", "OrdenServicio.clienteId", "OrdenServicio.aparatoId", "OrdenServicio.defectoInformadoId", "OrdenServicio.fotoOrdenIds", "OrdenServicio.entregaAparatoId", "OrdenServicio.status", "Cliente.id", "Aparato.id", "DefectoInformado.id", "DefectoInformado.descripcion", "FotoOrden.id", "FotoOrden.nombreArchivo", "FotoOrden.urlArchivo", "FotoOrden.tipoMime", "EntregaAparato.id", "EntregaAparato.fechaEntrega"];
            };
        }, {
            readonly grantId: "tecnicoAnalizaYpresupuesta";
            readonly profileRef: "tecnico";
            readonly authorityRef: "analizarYpresupuestar";
            readonly entityRefs: ["OrdenServicio", "Aparato", "DefectoInformado", "FotoOrden", "Diagnostico", "PiezaNecesaria", "Presupuesto"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Órdenes del servicio técnico que requieren análisis o presupuesto.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Puede consultar la recepción y registrar toda la información técnica y económica necesaria para el presupuesto.";
                readonly allowedFields: ["OrdenServicio.id", "OrdenServicio.numeroOrden", "OrdenServicio.aparatoId", "OrdenServicio.defectoInformadoId", "OrdenServicio.fotoOrdenIds", "OrdenServicio.diagnosticoId", "OrdenServicio.presupuestoId", "OrdenServicio.status", "Aparato.id", "DefectoInformado.id", "DefectoInformado.descripcion", "FotoOrden.id", "FotoOrden.nombreArchivo", "FotoOrden.urlArchivo", "FotoOrden.tipoMime", "Diagnostico.id", "Diagnostico.descripcion", "PiezaNecesaria.id", "PiezaNecesaria.nombrePieza", "PiezaNecesaria.cantidad", "PiezaNecesaria.costoInterno", "Presupuesto.id", "Presupuesto.valorCliente", "Presupuesto.piezasNecesarias", "Presupuesto.status"];
            };
        }, {
            readonly grantId: "tecnicoReparaOrden";
            readonly profileRef: "tecnico";
            readonly authorityRef: "repararOrden";
            readonly entityRefs: ["OrdenServicio", "Aparato", "Diagnostico", "PiezaNecesaria", "Presupuesto", "Reparacion"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Órdenes cuyo presupuesto fue aprobado y están disponibles para reparación.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Puede consultar el diagnóstico, las piezas y la autorización, y registrar el trabajo técnico realizado.";
                readonly allowedFields: ["OrdenServicio.id", "OrdenServicio.numeroOrden", "OrdenServicio.aparatoId", "OrdenServicio.diagnosticoId", "OrdenServicio.presupuestoId", "OrdenServicio.reparacionId", "OrdenServicio.status", "Aparato.id", "Diagnostico.id", "Diagnostico.descripcion", "PiezaNecesaria.id", "PiezaNecesaria.nombrePieza", "PiezaNecesaria.cantidad", "PiezaNecesaria.costoInterno", "Presupuesto.id", "Presupuesto.valorCliente", "Presupuesto.piezasNecesarias", "Presupuesto.status", "Reparacion.id", "Reparacion.detalleTrabajo"];
            };
        }, {
            readonly grantId: "clienteConsultaYrespondePresupuesto";
            readonly profileRef: "cliente";
            readonly authorityRef: "consultarYresponderPresupuesto";
            readonly entityRefs: ["OrdenServicio"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Solo órdenes vinculadas al cliente que accede al portal.";
                readonly anchorEntity: "Cliente";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Puede ver el estado, diagnóstico y valor del presupuesto de sus órdenes, y registrar su respuesta, sin acceso a costos internos, piezas ni anotaciones técnicas.";
                readonly allowedFields: ["OrdenServicio.id", "OrdenServicio.numeroOrden", "OrdenServicio.diagnosticoId", "OrdenServicio.presupuestoId", "OrdenServicio.status", "Diagnostico.id", "Diagnostico.descripcion", "Presupuesto.id", "Presupuesto.valorCliente", "Presupuesto.status"];
                readonly deniedFields: ["Presupuesto.piezasNecesarias"];
            };
        }];
    };
    export type OrdenServicio5AccessType = typeof ordenServicio5Access;
    export default ordenServicio5Access;
}
declare module "_102035_/l2/agentNewSolution5/steps/access60/fixtures/live/comandaRestaurante5-access.defs" {
    export const comandaRestaurante5Access: {
        readonly schemaVersion: "2026-09-10-ns5-access-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly profiles: [{
            readonly profileId: "garcom";
            readonly actorRefs: ["garcom"];
            readonly kind: "internal";
        }, {
            readonly profileId: "caixa";
            readonly actorRefs: ["caixa"];
            readonly kind: "internal";
        }];
        readonly authorities: [{
            readonly authorityId: "gerenciarComandasEmAtendimento";
            readonly title: "Gerenciar comandas em atendimento";
            readonly description: "Permite abrir comandas em mesas, consultar o cardápio e registrar ou cancelar itens lançados nas comandas.";
        }, {
            readonly authorityId: "fecharContas";
            readonly title: "Fechar contas";
            readonly description: "Permite conferir comandas, registrar descontos pontuais, receber pagamentos divididos e encerrar contas quitadas.";
        }];
        readonly grants: [{
            readonly grantId: "garcomGerenciaComandas";
            readonly profileRef: "garcom";
            readonly authorityRef: "gerenciarComandasEmAtendimento";
            readonly entityRefs: ["Mesa", "ItemCardapio", "Comanda", "ItemComanda"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Comandas, mesas, itens do cardápio e lançamentos do restaurante necessários ao atendimento das mesas.";
                readonly anchorEntity: "Comanda";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Acesso completo aos registros necessários para abrir comandas e lançar ou cancelar itens.";
            };
        }, {
            readonly grantId: "caixaFechaContas";
            readonly profileRef: "caixa";
            readonly authorityRef: "fecharContas";
            readonly entityRefs: ["Comanda", "ItemComanda", "Desconto", "Pagamento"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Comandas e seus lançamentos, descontos e pagamentos do restaurante necessários à conferência e ao fechamento.";
                readonly anchorEntity: "Comanda";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Acesso completo aos registros necessários para conferir, descontar, receber pagamentos e encerrar comandas.";
            };
        }];
    };
    export type ComandaRestaurante5AccessType = typeof comandaRestaurante5Access;
    export default comandaRestaurante5Access;
}
declare module "_102035_/l2/agentNewSolution5/steps/access60/fixtures/live/mensalidadesAcademia-access.defs" {
    export const mensalidadesAcademiaAccess: {
        readonly schemaVersion: "2026-09-10-ns5-access-v1";
        readonly moduleName: "mensalidadesAcademia";
        readonly profiles: [{
            readonly profileId: "recepcao";
            readonly actorRefs: ["recepcao"];
            readonly kind: "internal";
        }, {
            readonly profileId: "gerencia";
            readonly actorRefs: ["gerencia"];
            readonly kind: "internal";
        }, {
            readonly profileId: "aluno";
            readonly actorRefs: ["aluno"];
            readonly kind: "external";
        }];
        readonly authorities: [{
            readonly authorityId: "gerirMatriculas";
            readonly title: "Gerenciar matrículas";
            readonly description: "Cadastrar alunos, consultar planos disponíveis e iniciar matrículas.";
        }, {
            readonly authorityId: "registrarPagamentos";
            readonly title: "Registrar pagamentos";
            readonly description: "Consultar mensalidades e registrar os pagamentos recebidos.";
        }, {
            readonly authorityId: "gerirPlanos";
            readonly title: "Gerenciar planos";
            readonly description: "Cadastrar e atualizar os planos oferecidos pela academia.";
        }, {
            readonly authorityId: "gerarEcentralizarMensalidades";
            readonly title: "Gerar e acompanhar mensalidades";
            readonly description: "Gerar mensalidades do mês e consultar os indicadores mensais financeiros e de alunos.";
        }, {
            readonly authorityId: "cancelarPropriaMatricula";
            readonly title: "Cancelar própria matrícula";
            readonly description: "Consultar e cancelar a matrícula ativa do próprio aluno.";
        }];
        readonly grants: [{
            readonly grantId: "recepcaoGerirMatriculas";
            readonly profileRef: "recepcao";
            readonly authorityRef: "gerirMatriculas";
            readonly entityRefs: ["Plano", "Aluno", "Matricula"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Planos, alunos e matrículas da academia.";
                readonly anchorEntity: "Aluno";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Dados necessários para selecionar planos, cadastrar alunos e iniciar matrículas.";
                readonly allowedFields: ["Plano.id", "Plano.periodicity", "Plano.amount", "Plano.dueDay", "Aluno.id", "Matricula.id", "Matricula.startDate", "Matricula.aluno", "Matricula.plano", "Matricula.status"];
            };
        }, {
            readonly grantId: "recepcaoRegistrarPagamentos";
            readonly profileRef: "recepcao";
            readonly authorityRef: "registrarPagamentos";
            readonly entityRefs: ["Mensalidade", "Pagamento"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Mensalidades e pagamentos registrados pela academia.";
                readonly anchorEntity: "Aluno";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Dados necessários para localizar mensalidades, conferir valores e registrar pagamentos.";
                readonly allowedFields: ["Mensalidade.id", "Mensalidade.referenceMonth", "Mensalidade.matricula", "Mensalidade.amount", "Mensalidade.dueDate", "Mensalidade.details.totalPaid", "Mensalidade.details.outstandingAmount", "Mensalidade.details.paymentSituation", "Pagamento.id", "Pagamento.mensalidade", "Pagamento.paymentDate", "Pagamento.amount", "Pagamento.paymentMethod"];
            };
        }, {
            readonly grantId: "gerenciaGerirPlanos";
            readonly profileRef: "gerencia";
            readonly authorityRef: "gerirPlanos";
            readonly entityRefs: ["Plano"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todos os planos configurados pela academia.";
                readonly anchorEntity: "Aluno";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Dados completos dos planos para cadastro e atualização.";
                readonly allowedFields: ["Plano.id", "Plano.periodicity", "Plano.amount", "Plano.dueDay"];
            };
        }, {
            readonly grantId: "gerenciaGerarEacompanharMensalidades";
            readonly profileRef: "gerencia";
            readonly authorityRef: "gerarEcentralizarMensalidades";
            readonly entityRefs: ["Plano", "Matricula", "Mensalidade", "PainelMensalidades"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Matrículas, planos, mensalidades e consolidações mensais de toda a academia.";
                readonly anchorEntity: "Aluno";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Dados necessários para gerar cobranças mensais e acompanhar os indicadores consolidados.";
                readonly allowedFields: ["Plano.id", "Plano.periodicity", "Plano.amount", "Plano.dueDay", "Matricula.id", "Matricula.startDate", "Matricula.aluno", "Matricula.plano", "Matricula.status", "Mensalidade.id", "Mensalidade.referenceMonth", "Mensalidade.matricula", "Mensalidade.amount", "Mensalidade.dueDate", "Mensalidade.details.totalPaid", "Mensalidade.details.outstandingAmount", "Mensalidade.details.paymentSituation", "PainelMensalidades.id", "PainelMensalidades.referenceMonth", "PainelMensalidades.mensalidades", "PainelMensalidades.details.totalAreceber", "PainelMensalidades.details.totalRecebido", "PainelMensalidades.details.quantidadeAlunosAtivos", "PainelMensalidades.details.quantidadeAlunosBloqueados", "PainelMensalidades.details.quantidadeAlunosInadimplentes"];
            };
        }, {
            readonly grantId: "alunoCancelarPropriaMatricula";
            readonly profileRef: "aluno";
            readonly authorityRef: "cancelarPropriaMatricula";
            readonly entityRefs: ["Matricula"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Somente a matrícula vinculada ao próprio aluno.";
                readonly anchorEntity: "Aluno";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Dados necessários para verificar e cancelar a própria matrícula.";
                readonly allowedFields: ["Matricula.id", "Matricula.startDate", "Matricula.plano", "Matricula.status"];
            };
        }];
    };
    export type MensalidadesAcademiaAccessType = typeof mensalidadesAcademiaAccess;
    export default mensalidadesAcademiaAccess;
}
declare module "_102035_/l2/agentNewSolution5/steps/access60/fixtures/live/ordenServicio5-access.defs" {
    export const ordenServicio5Access: {
        readonly schemaVersion: "2026-09-10-ns5-access-v1";
        readonly moduleName: "ordenServicio5";
        readonly profiles: [{
            readonly profileId: "recepcionista";
            readonly actorRefs: ["recepcionista"];
            readonly kind: "internal";
        }, {
            readonly profileId: "tecnico";
            readonly actorRefs: ["tecnico"];
            readonly kind: "internal";
        }, {
            readonly profileId: "cliente";
            readonly actorRefs: ["cliente"];
            readonly kind: "external";
        }];
        readonly authorities: [{
            readonly authorityId: "registrarRecepcion";
            readonly title: "Registrar recepción de orden";
            readonly description: "Registrar la recepción del aparato, los datos de la orden, el defecto informado y las fotos asociadas.";
        }, {
            readonly authorityId: "entregarYfinalizar";
            readonly title: "Entregar y finalizar orden";
            readonly description: "Consultar las órdenes disponibles para retiro, registrar la entrega del aparato y finalizar la orden.";
        }, {
            readonly authorityId: "analizarYpresupuestar";
            readonly title: "Analizar y presupuestar orden";
            readonly description: "Consultar órdenes para análisis y registrar el diagnóstico, las piezas necesarias, sus costos internos y el presupuesto para el cliente.";
        }, {
            readonly authorityId: "registrarReparacion";
            readonly title: "Registrar reparación terminada";
            readonly description: "Consultar órdenes aprobadas y registrar la reparación realizada para dejarlas listas para entrega.";
        }, {
            readonly authorityId: "consultarMisOrdenes";
            readonly title: "Consultar mis órdenes";
            readonly description: "Consultar el estado, el diagnóstico y el valor del presupuesto de las órdenes propias.";
        }, {
            readonly authorityId: "responderPresupuesto";
            readonly title: "Responder presupuesto";
            readonly description: "Aprobar o rechazar el presupuesto de una orden propia.";
        }];
        readonly grants: [{
            readonly grantId: "recepcionistaRegistrarRecepcion";
            readonly profileRef: "recepcionista";
            readonly authorityRef: "registrarRecepcion";
            readonly entityRefs: ["OrdenServicio", "Cliente", "Aparato", "FotoOrdenServicio"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Órdenes y registros de recepción de toda la organización.";
                readonly anchorEntity: "Cliente";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Datos necesarios para registrar la recepción de una orden y sus fotos.";
                readonly allowedFields: ["OrdenServicio.id", "OrdenServicio.orderNumber", "OrdenServicio.cliente", "OrdenServicio.aparato", "OrdenServicio.reportedDefect", "OrdenServicio.receivedAt", "OrdenServicio.status", "Cliente.id", "Aparato.id", "FotoOrdenServicio.id"];
            };
        }, {
            readonly grantId: "recepcionistaEntregarYfinalizar";
            readonly profileRef: "recepcionista";
            readonly authorityRef: "entregarYfinalizar";
            readonly entityRefs: ["OrdenServicio", "Cliente", "Aparato", "Presupuesto", "EntregaAparato"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Órdenes de toda la organización que deben ser entregadas o finalizadas.";
                readonly anchorEntity: "Cliente";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Información necesaria para verificar el retiro, registrar la entrega y finalizar la orden, sin acceso al importe del presupuesto.";
                readonly allowedFields: ["OrdenServicio.id", "OrdenServicio.orderNumber", "OrdenServicio.cliente", "OrdenServicio.aparato", "OrdenServicio.entregaAparato", "OrdenServicio.status", "Cliente.id", "Aparato.id", "Presupuesto.status", "EntregaAparato.id", "EntregaAparato.deliveryDate"];
                readonly deniedFields: ["Presupuesto.quoteAmount"];
            };
        }, {
            readonly grantId: "tecnicoAnalizarYpresupuestar";
            readonly profileRef: "tecnico";
            readonly authorityRef: "analizarYpresupuestar";
            readonly entityRefs: ["OrdenServicio", "Cliente", "Aparato", "FotoOrdenServicio", "Diagnostico", "PiezaNecesaria", "Presupuesto"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Órdenes de toda la organización pendientes de análisis o presupuesto.";
                readonly anchorEntity: "Cliente";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Acceso completo a la información técnica y económica necesaria para analizar y presupuestar.";
            };
        }, {
            readonly grantId: "tecnicoRegistrarReparacion";
            readonly profileRef: "tecnico";
            readonly authorityRef: "registrarReparacion";
            readonly entityRefs: ["OrdenServicio", "Diagnostico", "PiezaNecesaria", "Presupuesto", "Reparacion"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Órdenes de toda la organización con presupuesto aprobado que requieren reparación.";
                readonly anchorEntity: "Cliente";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Acceso completo a la información técnica necesaria para realizar y registrar la reparación.";
            };
        }, {
            readonly grantId: "clienteConsultarMisOrdenes";
            readonly profileRef: "cliente";
            readonly authorityRef: "consultarMisOrdenes";
            readonly entityRefs: ["OrdenServicio"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Solo las órdenes vinculadas al cliente que consulta.";
                readonly anchorEntity: "Cliente";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Estado, síntesis del diagnóstico y valor del presupuesto de las órdenes propias, sin información técnica interna.";
                readonly allowedFields: ["OrdenServicio.id", "OrdenServicio.orderNumber", "OrdenServicio.status", "Diagnostico.diagnosisSummary", "Presupuesto.quoteAmount", "Presupuesto.status"];
                readonly deniedFields: ["OrdenServicio.cliente", "OrdenServicio.aparato", "OrdenServicio.reportedDefect", "OrdenServicio.receivedAt", "OrdenServicio.diagnostico", "OrdenServicio.presupuesto", "OrdenServicio.reparacion", "OrdenServicio.entregaAparato", "Diagnostico.diagnosisDetail", "Diagnostico.technicalNotes", "Diagnostico.requiredParts", "Presupuesto.id"];
            };
        }, {
            readonly grantId: "clienteResponderPresupuesto";
            readonly profileRef: "cliente";
            readonly authorityRef: "responderPresupuesto";
            readonly entityRefs: ["OrdenServicio"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Solo los presupuestos asociados a órdenes vinculadas al cliente que responde.";
                readonly anchorEntity: "Cliente";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Información necesaria para aprobar o rechazar el presupuesto de una orden propia.";
                readonly allowedFields: ["OrdenServicio.id", "OrdenServicio.orderNumber", "OrdenServicio.status", "Presupuesto.quoteAmount", "Presupuesto.status"];
                readonly deniedFields: ["OrdenServicio.cliente", "OrdenServicio.aparato", "OrdenServicio.reportedDefect", "OrdenServicio.receivedAt", "OrdenServicio.diagnostico", "OrdenServicio.presupuesto", "OrdenServicio.reparacion", "OrdenServicio.entregaAparato", "Presupuesto.id"];
            };
        }];
    };
    export type OrdenServicio5AccessType = typeof ordenServicio5Access;
    export default ordenServicio5Access;
}
declare module "_102035_/l2/agentNewSolution5/steps/finalize80/fixtures/acompanharIndicadoresDaAcademia.defs" {
    export const acompanharIndicadoresDaAcademiaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "acompanharIndicadoresDaAcademia";
        readonly business: {
            readonly actorRef: "gerencia";
            readonly title: "Acompanhar indicadores financeiros e de alunos";
            readonly goal: "Consultar os totais financeiros do mês e a situação dos alunos da academia.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "inspecionarPainelGerencial";
                readonly kind: "inspect";
                readonly entity: "PainelGerencial";
                readonly title: "Inspecionar painel gerencial";
                readonly description: "Consulta o total a receber no mês, o total recebido e as quantidades de alunos ativos, bloqueados e inadimplentes.";
            }];
            readonly outcome: {
                readonly statement: "A gerência visualiza os indicadores financeiros e a situação atual dos alunos.";
                readonly evidence: ["Painel apresenta total a receber no mês.", "Painel apresenta total recebido e as quantidades de alunos ativos, bloqueados e inadimplentes."];
            };
        };
        readonly businessHash: "sha256:0466b8c50a161dd743dc0813e156f5a87da1253889b1e75c9387b2a272d9c651";
    };
    export type AcompanharIndicadoresDaAcademiaJourneyType = typeof acompanharIndicadoresDaAcademiaJourney;
    export default acompanharIndicadoresDaAcademiaJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/finalize80/fixtures/consultarMisOrdenes.defs" {
    export const consultarMisOrdenesJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "consultarMisOrdenes";
        readonly business: {
            readonly actorRef: "cliente";
            readonly title: "Consultar mis órdenes de servicio";
            readonly goal: "Conocer el estado, el diagnóstico y el valor del presupuesto de las propias órdenes.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarMisOrdenes";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Localizar las órdenes propias.";
                readonly description: "Localizar las órdenes propias.";
            }, {
                readonly stepId: "consultarDetalleDeMiOrden";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Consultar el estado, el diagnóstico y el valor del presupuesto de una orden propia.";
                readonly description: "Consultar el estado, el diagnóstico y el valor del presupuesto de una orden propia.";
            }];
            readonly outcome: {
                readonly statement: "El cliente conoce la información permitida de sus propias órdenes sin acceder a costos internos ni anotaciones técnicas.";
                readonly evidence: ["El cliente visualiza el estado, diagnóstico y valor del presupuesto de su orden.", "La consulta no incluye el costo interno de piezas ni las anotaciones del técnico."];
            };
        };
        readonly businessHash: "sha256:f06acac774dfba3dbbf368b5ebeb3fa48d9c0b147c13556839cd3aec7e3ca283";
    };
    export type ConsultarMisOrdenesJourneyType = typeof consultarMisOrdenesJourney;
    export default consultarMisOrdenesJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/integration70/fixtures/comandaRestaurante5-integration.defs" {
    export const comandaRestaurante5Integration: {
        readonly schemaVersion: "2026-09-10-ns5-integration-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly inbound: [];
        readonly outbound: [];
        readonly plugins: [];
    };
    export type ComandaRestaurante5IntegrationType = typeof comandaRestaurante5Integration;
    export default comandaRestaurante5Integration;
}
declare module "_102035_/l2/agentNewSolution5/steps/integration70/fixtures/ordenServicio5-integration.defs" {
    export const ordenServicio5Integration: {
        readonly schemaVersion: "2026-09-10-ns5-integration-v1";
        readonly moduleName: "ordenServicio5";
        readonly inbound: [];
        readonly outbound: [];
        readonly plugins: [];
    };
    export type OrdenServicio5IntegrationType = typeof ordenServicio5Integration;
    export default ordenServicio5Integration;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/comandaRestaurante5/abrirComandaNaMesa.defs" {
    export const abrirComandaNaMesaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "abrirComandaNaMesa";
        readonly business: {
            readonly actorRef: "garcom";
            readonly title: "Abrir comanda em uma mesa";
            readonly goal: "Iniciar o atendimento de uma mesa com uma comanda vinculada.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarMesa";
                readonly kind: "locate";
                readonly entity: "Mesa";
                readonly title: "Localizar mesa";
                readonly description: "Localiza a mesa que será atendida.";
            }, {
                readonly stepId: "abrirComanda";
                readonly kind: "act";
                readonly entity: "Comanda";
                readonly affects: ["Mesa"];
                readonly title: "Abrir comanda";
                readonly description: "Cria uma comanda aberta para a mesa selecionada.";
            }];
            readonly outcome: {
                readonly statement: "A mesa fica com uma comanda aberta para registrar os pedidos.";
                readonly evidence: ["Comanda identificada como aberta e vinculada à mesa.", "Mesa identificada na comanda aberta."];
            };
        };
        readonly businessHash: "sha256:da6d3ad314adcdbe2648ab84cbb84e40859cb75d3342fd7ed8601f8cfc6b0c33";
    };
    export type AbrirComandaNaMesaJourneyType = typeof abrirComandaNaMesaJourney;
    export default abrirComandaNaMesaJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/comandaRestaurante5/cancelarItemLancadoPorEngano.defs" {
    export const cancelarItemLancadoPorEnganoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cancelarItemLancadoPorEngano";
        readonly business: {
            readonly actorRef: "garcom";
            readonly title: "Cancelar item lançado por engano";
            readonly goal: "Retirar da comanda um item registrado incorretamente.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarComandaParaCorrecao";
                readonly kind: "locate";
                readonly entity: "Comanda";
                readonly title: "Localizar comanda";
                readonly description: "Localiza a comanda aberta que precisa de correção.";
            }, {
                readonly stepId: "conferirItemLancado";
                readonly kind: "inspect";
                readonly entity: "ItemComanda";
                readonly title: "Conferir item lançado";
                readonly description: "Identifica o item que foi lançado por engano.";
            }, {
                readonly stepId: "cancelarItemLancado";
                readonly kind: "act";
                readonly entity: "ItemComanda";
                readonly affects: ["Comanda"];
                readonly title: "Cancelar item lançado";
                readonly description: "Cancela o item incorreto na comanda.";
            }];
            readonly outcome: {
                readonly statement: "O item lançado por engano deixa de ser considerado no valor da comanda.";
                readonly evidence: ["Item com status de cancelado na comanda.", "Total da comanda atualizado sem o item cancelado."];
            };
        };
        readonly businessHash: "sha256:e0e918edb38fcf54da476a4f0c8506be681c4486aea2d6a8ae52cc3e68da91c5";
    };
    export type CancelarItemLancadoPorEnganoJourneyType = typeof cancelarItemLancadoPorEnganoJourney;
    export default cancelarItemLancadoPorEnganoJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/comandaRestaurante5/conferirEfecharConta.defs" {
    export const conferirEfecharContaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "conferirEfecharConta";
        readonly business: {
            readonly actorRef: "caixa";
            readonly title: "Conferir e fechar conta";
            readonly goal: "Conferir a comanda, aplicar desconto pontual quando necessário e receber os pagamentos para encerrar a conta.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarComandaParaFechamento";
                readonly kind: "locate";
                readonly entity: "Comanda";
                readonly title: "Localizar comanda";
                readonly description: "Localiza a comanda apresentada para pagamento.";
            }, {
                readonly stepId: "conferirComanda";
                readonly kind: "inspect";
                readonly entity: "Comanda";
                readonly title: "Conferir comanda";
                readonly description: "Confere os itens, cancelamentos e o valor total da comanda.";
            }, {
                readonly stepId: "aplicarDescontoPontual";
                readonly kind: "act";
                readonly entity: "Desconto";
                readonly affects: ["Comanda"];
                readonly title: "Aplicar desconto pontual";
                readonly description: "Registra um desconto pontual quando ele for concedido.";
            }, {
                readonly stepId: "registrarPagamentosDivididos";
                readonly kind: "act";
                readonly entity: "Pagamento";
                readonly affects: ["Comanda"];
                readonly title: "Registrar pagamentos";
                readonly description: "Registra um ou mais pagamentos, inclusive valores divididos entre as pessoas da mesa.";
            }, {
                readonly stepId: "fecharComanda";
                readonly kind: "act";
                readonly entity: "Comanda";
                readonly title: "Fechar comanda";
                readonly description: "Encerra a conta após o recebimento integral do valor devido.";
            }];
            readonly outcome: {
                readonly statement: "A conta é fechada com os pagamentos recebidos e eventuais descontos registrados.";
                readonly evidence: ["Comanda identificada como fechada.", "Desconto pontual, quando aplicado, fica registrado na comanda.", "Pagamentos registrados totalizam o valor final da conta."];
            };
        };
        readonly businessHash: "sha256:3b416594f01c4f89fce9a6030d28fb2c7b97ef5af6f433989f69bc87f1e3f6e3";
    };
    export type ConferirEfecharContaJourneyType = typeof conferirEfecharContaJourney;
    export default conferirEfecharContaJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/comandaRestaurante5/index.defs" {
    export const comandaRestaurante5JourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly journeys: [{
            readonly journeyId: "abrirComandaNaMesa";
            readonly actorRef: "garcom";
            readonly title: "Abrir comanda em uma mesa";
        }, {
            readonly journeyId: "lancarItemNaComanda";
            readonly actorRef: "garcom";
            readonly title: "Lançar item pedido na comanda";
        }, {
            readonly journeyId: "cancelarItemLancadoPorEngano";
            readonly actorRef: "garcom";
            readonly title: "Cancelar item lançado por engano";
        }, {
            readonly journeyId: "conferirEfecharConta";
            readonly actorRef: "caixa";
            readonly title: "Conferir e fechar conta";
        }];
        readonly systemDecisions: [];
    };
    export type ComandaRestaurante5JourneyIndexType = typeof comandaRestaurante5JourneyIndex;
    export default comandaRestaurante5JourneyIndex;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/comandaRestaurante5/lancarItemNaComanda.defs" {
    export const lancarItemNaComandaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "lancarItemNaComanda";
        readonly business: {
            readonly actorRef: "garcom";
            readonly title: "Lançar item pedido na comanda";
            readonly goal: "Registrar na comanda um item solicitado pela mesa.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarComandaAberta";
                readonly kind: "locate";
                readonly entity: "Comanda";
                readonly title: "Localizar comanda aberta";
                readonly description: "Localiza a comanda da mesa, usando a comanda já em atendimento quando disponível.";
            }, {
                readonly stepId: "consultarItemDoCardapio";
                readonly kind: "inspect";
                readonly entity: "ItemCardapio";
                readonly title: "Consultar item do cardápio";
                readonly description: "Confere o item solicitado no cardápio.";
            }, {
                readonly stepId: "registrarItemPedido";
                readonly kind: "act";
                readonly entity: "ItemComanda";
                readonly affects: ["Comanda", "ItemCardapio"];
                readonly title: "Registrar item pedido";
                readonly description: "Inclui na comanda o item pedido e sua quantidade.";
            }];
            readonly outcome: {
                readonly statement: "O item pedido passa a compor a comanda aberta da mesa.";
                readonly evidence: ["Item lançado aparece na comanda.", "Quantidade e valor do item lançado ficam registrados."];
            };
        };
        readonly businessHash: "sha256:f29068e0387174dab9086d0d668a49883fd65919cbdc928d0db6ce5c8fcb618f";
    };
    export type LancarItemNaComandaJourneyType = typeof lancarItemNaComandaJourney;
    export default lancarItemNaComandaJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/ordenServicio5/analizarYpresupuestarOrden.defs" {
    export const analizarYpresupuestarOrdenJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "analizarYpresupuestarOrden";
        readonly business: {
            readonly actorRef: "tecnico";
            readonly title: "Analizar un aparato y preparar el presupuesto";
            readonly goal: "Registrar el diagnóstico, las piezas necesarias con su costo interno y el presupuesto que verá el cliente.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarOrdenPendiente";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Localizar la orden pendiente de análisis.";
                readonly description: "Localizar la orden recibida que requiere análisis técnico.";
            }, {
                readonly stepId: "inspeccionarAparatoYrecepcion";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Revisar el aparato y los datos de recepción.";
                readonly description: "Revisar el aparato, el defecto informado y las fotos asociados a la orden.";
            }, {
                readonly stepId: "registrarDiagnosticoYpresupuesto";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly affects: ["Diagnostico", "PiezaNecesaria", "Presupuesto"];
                readonly title: "Registrar el diagnóstico, las piezas necesarias y el presupuesto.";
                readonly description: "Registrar el diagnóstico, las piezas necesarias con costo interno y el valor del presupuesto para el cliente.";
            }];
            readonly outcome: {
                readonly statement: "La orden queda diagnosticada y el presupuesto queda disponible para la respuesta del cliente.";
                readonly evidence: ["La orden contiene un diagnóstico registrado.", "Las piezas necesarias incluyen su costo interno.", "La orden contiene un valor de presupuesto para el cliente."];
            };
        };
        readonly businessHash: "sha256:bbaf50642752b85499c176ebfd1d78e97082f3aea0e59b98a5bc04f6ca9f6461";
    };
    export type AnalizarYpresupuestarOrdenJourneyType = typeof analizarYpresupuestarOrdenJourney;
    export default analizarYpresupuestarOrdenJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/ordenServicio5/entregarAparatoYfinalizarOrden.defs" {
    export const entregarAparatoYfinalizarOrdenJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "entregarAparatoYfinalizarOrden";
        readonly business: {
            readonly actorRef: "recepcionista";
            readonly title: "Entregar un aparato y finalizar la orden";
            readonly goal: "Entregar al cliente un aparato cuya orden está lista o quedó rechazada y finalizar la gestión correspondiente.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarOrdenParaEntrega";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Localizar la orden disponible para entrega.";
                readonly description: "Localizar la orden lista para entrega o cerrada como rechazada cuyo aparato está disponible para retiro.";
            }, {
                readonly stepId: "verificarOrdenYaparato";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Verificar la orden y el aparato a entregar.";
                readonly description: "Revisar la identificación del cliente, el estado de la orden y el aparato disponible.";
            }, {
                readonly stepId: "registrarEntregaYfinalizacion";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly affects: ["EntregaAparato", "Aparato"];
                readonly title: "Registrar la entrega y finalizar la orden.";
                readonly description: "Registrar la entrega del aparato al cliente y finalizar la orden correspondiente.";
            }];
            readonly outcome: {
                readonly statement: "El aparato queda entregado al cliente y la orden queda finalizada.";
                readonly evidence: ["Existe un registro de entrega del aparato.", "La orden muestra estado finalizada."];
            };
        };
        readonly businessHash: "sha256:d6ae6dd00e1b4f6f53d4771440c4f86279079ff2d6d4f51fe525ce0cf40df226";
    };
    export type EntregarAparatoYfinalizarOrdenJourneyType = typeof entregarAparatoYfinalizarOrdenJourney;
    export default entregarAparatoYfinalizarOrdenJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/ordenServicio5/index.defs" {
    export const ordenServicio5JourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "ordenServicio5";
        readonly journeys: [{
            readonly journeyId: "registrarRecepcionAparato";
            readonly actorRef: "recepcionista";
            readonly title: "Registrar la recepción de un aparato";
        }, {
            readonly journeyId: "analizarYpresupuestarOrden";
            readonly actorRef: "tecnico";
            readonly title: "Analizar un aparato y preparar el presupuesto";
        }, {
            readonly journeyId: "responderPresupuesto";
            readonly actorRef: "cliente";
            readonly title: "Responder un presupuesto";
        }, {
            readonly journeyId: "repararYmarcarOrdenLista";
            readonly actorRef: "tecnico";
            readonly title: "Reparar un aparato y marcar la orden como lista";
        }, {
            readonly journeyId: "entregarAparatoYfinalizarOrden";
            readonly actorRef: "recepcionista";
            readonly title: "Entregar un aparato y finalizar la orden";
        }];
        readonly systemDecisions: [];
    };
    export type OrdenServicio5JourneyIndexType = typeof ordenServicio5JourneyIndex;
    export default ordenServicio5JourneyIndex;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/ordenServicio5/registrarRecepcionAparato.defs" {
    export const registrarRecepcionAparatoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarRecepcionAparato";
        readonly business: {
            readonly actorRef: "recepcionista";
            readonly title: "Registrar la recepción de un aparato";
            readonly goal: "Abrir una orden de servicio con la información aportada por el cliente y el aparato recibido.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "capturarDatosRecepcion";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly affects: ["Cliente", "Aparato", "DefectoInformado", "FotoOrden"];
                readonly title: "Registrar los datos del cliente, del aparato, el defecto informado y las fotos.";
                readonly description: "Registrar los datos del cliente, del aparato, el defecto informado y las fotos.";
            }];
            readonly outcome: {
                readonly statement: "La orden de servicio queda abierta con el aparato y la información de recepción registrados.";
                readonly evidence: ["Existe una orden de servicio con los datos del cliente, del aparato, el defecto informado y las fotos.", "La orden queda disponible para el análisis técnico."];
            };
        };
        readonly businessHash: "sha256:66c30f0884980a5fb666929ddb57e61dacc0c97d690906794aabb1c009455fc9";
    };
    export type RegistrarRecepcionAparatoJourneyType = typeof registrarRecepcionAparatoJourney;
    export default registrarRecepcionAparatoJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/ordenServicio5/repararYmarcarOrdenLista.defs" {
    export const repararYmarcarOrdenListaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "repararYmarcarOrdenLista";
        readonly business: {
            readonly actorRef: "tecnico";
            readonly title: "Reparar un aparato y marcar la orden como lista";
            readonly goal: "Realizar la reparación autorizada, documentar el trabajo realizado y dejar la orden lista para entrega.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarOrdenAprobada";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Localizar la orden aprobada para reparación.";
                readonly description: "Localizar la orden cuyo presupuesto fue aprobado por el cliente.";
            }, {
                readonly stepId: "revisarDiagnosticoYpiezas";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Revisar el diagnóstico y las piezas necesarias.";
                readonly description: "Consultar el diagnóstico y las piezas registradas antes de realizar la reparación.";
            }, {
                readonly stepId: "registrarReparacionRealizada";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly affects: ["Reparacion"];
                readonly title: "Registrar la reparación realizada.";
                readonly description: "Registrar las tareas efectuadas durante la reparación del aparato.";
            }, {
                readonly stepId: "marcarOrdenLista";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly title: "Marcar la orden como lista para entrega.";
                readonly description: "Actualizar la orden para indicar que el aparato está listo para ser entregado.";
            }, {
                readonly stepId: "derivarParaEntrega";
                readonly kind: "handoff";
                readonly entity: "OrdenServicio";
                readonly title: "Derivar la orden lista para entrega.";
                readonly description: "Poner la orden reparada a disposición del recepcionista para entregar el aparato.";
                readonly handoffTo: "recepcionista";
            }];
            readonly outcome: {
                readonly statement: "La reparación queda registrada y la orden queda lista para entrega.";
                readonly evidence: ["La orden contiene el registro de la reparación realizada.", "La orden muestra estado lista para entrega."];
            };
        };
        readonly businessHash: "sha256:9bad719a8e75390134eafef6e5f2d804bdcdabcbf412b8acf66557181ac4d542";
    };
    export type RepararYmarcarOrdenListaJourneyType = typeof repararYmarcarOrdenListaJourney;
    export default repararYmarcarOrdenListaJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/journeys20/fixtures/ordenServicio5/responderPresupuesto.defs" {
    export const responderPresupuestoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "responderPresupuesto";
        readonly business: {
            readonly actorRef: "cliente";
            readonly title: "Responder un presupuesto";
            readonly goal: "Aprobar o rechazar desde el portal el presupuesto de una orden propia.";
            readonly entry: {
                readonly mode: "fromNotification";
            };
            readonly steps: [{
                readonly stepId: "localizarOrdenPresupuestada";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Abrir la orden propia con presupuesto.";
                readonly description: "Localizar la orden propia notificada o buscarla entre las órdenes propias.";
            }, {
                readonly stepId: "revisarPresupuestoYdiagnostico";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Revisar el estado, diagnóstico y valor del presupuesto.";
                readonly description: "Consultar el diagnóstico y el valor del presupuesto de la orden propia.";
            }, {
                readonly stepId: "decidirRespuestaPresupuesto";
                readonly kind: "decide";
                readonly entity: "Presupuesto";
                readonly title: "Elegir aprobar o rechazar el presupuesto.";
                readonly description: "Seleccionar la aprobación para autorizar la reparación o el rechazo para cerrar la orden y retirar el aparato.";
            }, {
                readonly stepId: "registrarRespuestaPresupuesto";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly affects: ["Presupuesto", "Aparato"];
                readonly title: "Registrar la respuesta al presupuesto.";
                readonly description: "Registrar la aprobación para dejar la orden disponible para reparación o el rechazo para cerrarla y dejar el aparato disponible para retiro.";
            }];
            readonly outcome: {
                readonly statement: "La respuesta del cliente queda registrada: la orden queda autorizada para reparación o cerrada como rechazada con el aparato disponible para retiro.";
                readonly evidence: ["El presupuesto registra la aprobación o el rechazo del cliente.", "La orden aprobada figura disponible para reparación o la orden rechazada figura cerrada con el aparato disponible para retiro."];
            };
        };
        readonly businessHash: "sha256:1aa4d61d7234c3de19562c798d6e86fa7727dd4251041967c3917c8706988d57";
    };
    export type ResponderPresupuestoJourneyType = typeof responderPresupuestoJourney;
    export default responderPresupuestoJourney;
}
declare module "_102035_/l2/agentNewSolution5/steps/module10/fixtures/comandaRestaurante5-module.defs" {
    export const comandaRestaurante5Module: {
        readonly schemaVersion: "2026-09-10-ns5-module-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly title: "Comanda de restaurante";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "crie o módulo comandaRestaurante para um restaurante de bairro: o garçom abre uma comanda numa mesa e vai lançando os itens do cardápio pedidos, podendo cancelar um item lançado por engano; ao final, o caixa confere a comanda, pode aplicar um desconto pontual e fecha a conta recebendo o pagamento, que pode ser dividido entre as pessoas da mesa.";
        readonly actors: [{
            readonly actorId: "garcom";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Garçom";
            readonly description: "Abre comandas nas mesas e registra ou cancela itens pedidos.";
        }, {
            readonly actorId: "caixa";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Caixa";
            readonly description: "Confere comandas, aplica descontos pontuais e recebe pagamentos para fechar contas.";
        }];
        readonly scope: {
            readonly inScope: ["Registro de comandas por mesa", "Lançamento e cancelamento de itens pedidos", "Conferência, desconto pontual e fechamento de contas", "Registro de pagamento dividido entre pessoas da mesa"];
            readonly outOfScope: ["Gestão do cardápio", "Controle de estoque", "Gestão de reservas e atendimento de mesas", "Gestão financeira além do recebimento da conta"];
        };
    };
    export type ComandaRestaurante5ModuleType = typeof comandaRestaurante5Module;
    export default comandaRestaurante5Module;
}
declare module "_102035_/l2/agentNewSolution5/steps/module10/fixtures/ordenServicio5-module.defs" {
    export const ordenServicio5Module: {
        readonly schemaVersion: "2026-09-10-ns5-module-v1";
        readonly moduleName: "ordenServicio5";
        readonly title: "Órdenes de servicio técnico";
        readonly userLanguage: "es";
        readonly productLanguages: ["es"];
        readonly defaultLanguage: "es";
        readonly sourcePrompt: "crear el módulo ordenServicio, en español, para un servicio técnico de electrónica. el cliente trae un aparato y el recepcionista abre una orden de servicio con los datos del cliente, el aparato, el defecto informado y fotos. el técnico analiza y registra el diagnóstico, las piezas necesarias con costo interno y el valor del presupuesto para el cliente. el cliente recibe el presupuesto y lo aprueba o lo rechaza desde el portal; si lo rechaza, la orden se cierra como rechazada y el aparato queda disponible para retiro. si lo aprueba, el técnico realiza la reparación, registra lo que hizo y la marca como lista; el recepcionista entrega y finaliza. el cliente accede al portal y ve solamente sus propias órdenes, con estado, diagnóstico y valor del presupuesto — nunca el costo interno de las piezas ni las anotaciones del técnico. perfiles: recepcionista, técnico y cliente.";
        readonly actors: [{
            readonly actorId: "recepcionista";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Recepcionista";
            readonly description: "Personal que recibe aparatos y gestiona su entrega al cliente.";
        }, {
            readonly actorId: "tecnico";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Técnico";
            readonly description: "Personal que analiza los aparatos y realiza las reparaciones.";
        }, {
            readonly actorId: "cliente";
            readonly kind: "external";
            readonly origin: "named";
            readonly title: "Cliente";
            readonly description: "Persona que presenta un aparato para servicio y consulta o responde al presupuesto desde el portal.";
        }];
        readonly scope: {
            readonly inScope: ["Gestión de órdenes para servicio técnico de electrónica", "Recepción, diagnóstico, presupuesto, reparación y entrega de aparatos", "Consulta y respuesta del cliente sobre sus propias órdenes"];
            readonly outOfScope: ["Gestión general de inventario o compras", "Contabilidad, facturación y cobros", "Servicios técnicos ajenos a aparatos electrónicos"];
        };
    };
    export type OrdenServicio5ModuleType = typeof ordenServicio5Module;
    export default ordenServicio5Module;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/comandaRestaurante5/Comanda.defs" {
    export const comandaRestaurante5EntityComanda: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly entityId: "Comanda";
        readonly title: "Comanda";
        readonly description: "Registro de atendimento e consumo aberto para uma mesa até o fechamento da conta.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "numero";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da comanda.";
        }, {
            readonly fieldId: "numero";
            readonly title: "Número da comanda";
            readonly type: "integer";
            readonly required: true;
            readonly description: "Número exibido para identificar a comanda no atendimento.";
        }, {
            readonly fieldId: "mesa";
            readonly title: "Mesa";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Mesa selecionada para o atendimento desta comanda.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação";
            readonly type: "string";
            readonly required: true;
            readonly enum: ["aberta", "fechada"];
            readonly description: "Situação atual da comanda durante o atendimento e o fechamento.";
        }];
        readonly details: {
            readonly valorItens: "Soma os valores dos itens da comanda que não foram cancelados.";
            readonly valorDescontos: "Soma os descontos pontuais registrados para a comanda.";
            readonly valorDevido: "Calcula o valor a receber após deduzir os descontos do valor dos itens.";
            readonly valorPago: "Soma os pagamentos registrados para a comanda.";
            readonly saldoDevedor: "Calcula o valor que ainda falta receber para quitar a comanda.";
        };
        readonly lifecycleStates: [{
            readonly state: "aberta";
            readonly reachedBy: "actor";
        }, {
            readonly state: "fechada";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "fecharComanda";
            readonly from: ["aberta"];
            readonly to: "fechada";
            readonly by: ["caixa"];
            readonly description: "O caixa fecha a comanda após conferir o consumo e receber integralmente o valor devido.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type ComandaRestaurante5EntityComandaType = typeof comandaRestaurante5EntityComanda;
    export default comandaRestaurante5EntityComanda;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/comandaRestaurante5/Desconto.defs" {
    export const comandaRestaurante5EntityDesconto: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly entityId: "Desconto";
        readonly title: "Desconto";
        readonly description: "Concessão pontual de desconto aplicada a uma comanda durante a conferência.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "motivo";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do desconto concedido.";
        }, {
            readonly fieldId: "comandaId";
            readonly title: "Comanda";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Comanda à qual o desconto é aplicado, selecionada durante a conferência.";
        }, {
            readonly fieldId: "motivo";
            readonly title: "Motivo";
            readonly type: "text";
            readonly required: true;
            readonly description: "Justificativa para a concessão pontual do desconto.";
        }, {
            readonly fieldId: "valor";
            readonly title: "Valor do desconto";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor monetário abatido do total da comanda.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ComandaRestaurante5EntityDescontoType = typeof comandaRestaurante5EntityDesconto;
    export default comandaRestaurante5EntityDesconto;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/comandaRestaurante5/ItemCardapio.defs" {
    export const comandaRestaurante5EntityItemCardapio: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly entityId: "ItemCardapio";
        readonly title: "Item do cardápio";
        readonly description: "Produto oferecido no cardápio do restaurante que pode ser lançado em uma comanda.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "Product";
        readonly displayField: "name";
        readonly fields: [{
            readonly fieldId: "price";
            readonly title: "Preço";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço de venda do item no cardápio.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "comandaRestaurante5.ItemCardapio";
        };
    };
    export type ComandaRestaurante5EntityItemCardapioType = typeof comandaRestaurante5EntityItemCardapio;
    export default comandaRestaurante5EntityItemCardapio;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/comandaRestaurante5/ItemComanda.defs" {
    export const comandaRestaurante5EntityItemComanda: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly entityId: "ItemComanda";
        readonly title: "Item da comanda";
        readonly description: "Lançamento de um item pedido na comanda, incluindo a possibilidade de cancelamento.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "descricao";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item da comanda.";
        }, {
            readonly fieldId: "descricao";
            readonly title: "Descrição";
            readonly type: "string";
            readonly required: true;
            readonly description: "Descrição do item pedido, registrada conforme o cardápio no momento do lançamento.";
        }, {
            readonly fieldId: "comanda";
            readonly title: "Comanda";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Comanda aberta à qual este lançamento pertence.";
        }, {
            readonly fieldId: "itemCardapio";
            readonly title: "Item do cardápio";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Item do cardápio selecionado para o lançamento.";
        }, {
            readonly fieldId: "quantidade";
            readonly title: "Quantidade";
            readonly type: "integer";
            readonly required: true;
            readonly description: "Quantidade solicitada do item do cardápio.";
        }, {
            readonly fieldId: "precoUnitario";
            readonly title: "Preço unitário";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço unitário do item no momento em que foi lançado.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação";
            readonly type: "string";
            readonly required: true;
            readonly enum: ["lancado", "cancelado"];
            readonly description: "Situação do lançamento na comanda.";
        }];
        readonly details: {
            readonly valorTotal: "Valor total do lançamento, calculado pela quantidade multiplicada pelo preço unitário e desconsiderado quando cancelado.";
        };
        readonly lifecycleStates: [{
            readonly state: "lancado";
            readonly reachedBy: "actor";
        }, {
            readonly state: "cancelado";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "cancelarItem";
            readonly from: ["lancado"];
            readonly to: "cancelado";
            readonly by: ["garcom"];
            readonly description: "O garçom cancela um item lançado por engano enquanto a comanda está aberta.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type ComandaRestaurante5EntityItemComandaType = typeof comandaRestaurante5EntityItemComanda;
    export default comandaRestaurante5EntityItemComanda;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/comandaRestaurante5/Mesa.defs" {
    export const comandaRestaurante5EntityMesa: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly entityId: "Mesa";
        readonly title: "Mesa";
        readonly description: "Mesa do restaurante onde uma comanda é aberta e atendida.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "Location";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "comandaRestaurante5.Mesa";
        };
    };
    export type ComandaRestaurante5EntityMesaType = typeof comandaRestaurante5EntityMesa;
    export default comandaRestaurante5EntityMesa;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/comandaRestaurante5/Pagamento.defs" {
    export const comandaRestaurante5EntityPagamento: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly entityId: "Pagamento";
        readonly title: "Pagamento";
        readonly description: "Recebimento de um valor para quitar total ou parcialmente uma comanda.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "valor";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do pagamento.";
        }, {
            readonly fieldId: "valor";
            readonly title: "Valor";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor recebido neste pagamento.";
        }, {
            readonly fieldId: "comanda";
            readonly title: "Comanda";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Comanda à qual este pagamento é destinado.";
        }, {
            readonly fieldId: "recebidoEm";
            readonly title: "Recebido em";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que o pagamento foi recebido.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ComandaRestaurante5EntityPagamentoType = typeof comandaRestaurante5EntityPagamento;
    export default comandaRestaurante5EntityPagamento;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/comandaRestaurante5/index.defs" {
    export const comandaRestaurante5OntologyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly businessDomain: "Gestão de comandas, itens de cardápio, descontos e pagamentos de restaurante.";
        readonly entities: ["Mesa", "ItemCardapio", "Comanda", "ItemComanda", "Desconto", "Pagamento"];
        readonly relationships: [{
            readonly relationshipId: "comandaMesa";
            readonly fromEntity: "Comanda";
            readonly toEntity: "Mesa";
            readonly type: "manyToOne";
            readonly required: true;
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Comanda";
                readonly from: {
                    readonly entityId: "Comanda";
                    readonly fieldIds: ["mesa"];
                };
                readonly to: {
                    readonly entityId: "Mesa";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "itemComandaComanda";
            readonly fromEntity: "ItemComanda";
            readonly toEntity: "Comanda";
            readonly type: "manyToOne";
            readonly required: true;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ItemComanda";
                readonly from: {
                    readonly entityId: "ItemComanda";
                    readonly fieldIds: ["comanda"];
                };
                readonly to: {
                    readonly entityId: "Comanda";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "itemComandaItemCardapio";
            readonly fromEntity: "ItemComanda";
            readonly toEntity: "ItemCardapio";
            readonly type: "manyToOne";
            readonly required: true;
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ItemComanda";
                readonly from: {
                    readonly entityId: "ItemComanda";
                    readonly fieldIds: ["itemCardapio"];
                };
                readonly to: {
                    readonly entityId: "ItemCardapio";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "descontoComanda";
            readonly fromEntity: "Desconto";
            readonly toEntity: "Comanda";
            readonly type: "manyToOne";
            readonly required: true;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Desconto";
                readonly from: {
                    readonly entityId: "Desconto";
                    readonly fieldIds: ["comandaId"];
                };
                readonly to: {
                    readonly entityId: "Comanda";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "pagamentoComanda";
            readonly fromEntity: "Pagamento";
            readonly toEntity: "Comanda";
            readonly type: "manyToOne";
            readonly required: true;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Pagamento";
                readonly from: {
                    readonly entityId: "Pagamento";
                    readonly fieldIds: ["comanda"];
                };
                readonly to: {
                    readonly entityId: "Comanda";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type ComandaRestaurante5OntologyIndexType = typeof comandaRestaurante5OntologyIndex;
    export default comandaRestaurante5OntologyIndex;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/live/FotoOrdenServicio.defs" {
    export const ordenServicio5EntityFotoOrdenServicio: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "FotoOrdenServicio";
        readonly title: "Foto de la orden de servicio";
        readonly description: "Documento fotográfico tomado o adjuntado durante la recepción del aparato.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "Document";
        readonly displayField: "fileName";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "ordenServicio5.FotoOrdenServicio";
        };
    };
    export type OrdenServicio5EntityFotoOrdenServicioType = typeof ordenServicio5EntityFotoOrdenServicio;
    export default ordenServicio5EntityFotoOrdenServicio;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/live/OrdenServicio.defs" {
    export const ordenServicio5EntityOrdenServicio: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "OrdenServicio";
        readonly title: "Orden de servicio";
        readonly description: "Registro central de la recepción, análisis, presupuesto, reparación y entrega de un aparato.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "orderNumber";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único de la orden de servicio.";
        }, {
            readonly fieldId: "orderNumber";
            readonly title: "Número de orden";
            readonly type: "string";
            readonly required: true;
            readonly description: "Número visible que identifica la orden de servicio.";
        }, {
            readonly fieldId: "cliente";
            readonly title: "Cliente";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Cliente al que corresponde la orden de servicio.";
        }, {
            readonly fieldId: "aparato";
            readonly title: "Aparato";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Aparato recibido para su análisis, reparación y entrega.";
        }, {
            readonly fieldId: "reportedDefect";
            readonly title: "Defecto informado";
            readonly type: "text";
            readonly required: true;
            readonly description: "Descripción del defecto reportado por el cliente al recibir el aparato.";
        }, {
            readonly fieldId: "receivedAt";
            readonly title: "Fecha y hora de recepción";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Fecha y hora en que se recibió el aparato.";
        }, {
            readonly fieldId: "diagnostico";
            readonly title: "Diagnóstico";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Diagnóstico registrado para la orden.";
        }, {
            readonly fieldId: "presupuesto";
            readonly title: "Presupuesto";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Presupuesto preparado para la orden.";
        }, {
            readonly fieldId: "reparacion";
            readonly title: "Reparación";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Reparación realizada sobre el aparato tras la aprobación del presupuesto.";
        }, {
            readonly fieldId: "entregaAparato";
            readonly title: "Entrega del aparato";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Registro de entrega del aparato al cliente.";
        }, {
            readonly fieldId: "status";
            readonly title: "Estado";
            readonly type: "string";
            readonly required: true;
            readonly enum: ["pendingAnalysis", "pendingCustomerApproval", "approved", "rejected", "readyForDelivery", "finalized"];
            readonly description: "Estado actual de la orden de servicio.";
        }];
        readonly lifecycleStates: [{
            readonly state: "pendingAnalysis";
            readonly reachedBy: "actor";
        }, {
            readonly state: "pendingCustomerApproval";
            readonly reachedBy: "actor";
        }, {
            readonly state: "approved";
            readonly reachedBy: "actor";
        }, {
            readonly state: "rejected";
            readonly reachedBy: "actor";
        }, {
            readonly state: "readyForDelivery";
            readonly reachedBy: "actor";
        }, {
            readonly state: "finalized";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "submitQuote";
            readonly from: ["pendingAnalysis"];
            readonly to: "pendingCustomerApproval";
            readonly by: ["tecnico"];
            readonly description: "El técnico registra el diagnóstico y el presupuesto, y lo deja disponible para la respuesta del cliente.";
        }, {
            readonly transitionId: "approveQuote";
            readonly from: ["pendingCustomerApproval"];
            readonly to: "approved";
            readonly by: ["cliente"];
            readonly description: "El cliente aprueba el presupuesto desde el portal.";
        }, {
            readonly transitionId: "rejectQuote";
            readonly from: ["pendingCustomerApproval"];
            readonly to: "rejected";
            readonly by: ["cliente"];
            readonly description: "El cliente rechaza el presupuesto y el aparato queda disponible para retiro.";
        }, {
            readonly transitionId: "completeRepair";
            readonly from: ["approved"];
            readonly to: "readyForDelivery";
            readonly by: ["tecnico"];
            readonly description: "El técnico registra la reparación terminada y deja el aparato listo para entrega.";
        }, {
            readonly transitionId: "deliverRejectedDevice";
            readonly from: ["rejected"];
            readonly to: "finalized";
            readonly by: ["recepcionista"];
            readonly description: "El recepcionista entrega al cliente el aparato cuyo presupuesto fue rechazado y finaliza la orden.";
        }, {
            readonly transitionId: "deliverRepairedDevice";
            readonly from: ["readyForDelivery"];
            readonly to: "finalized";
            readonly by: ["recepcionista"];
            readonly description: "El recepcionista entrega al cliente el aparato reparado y finaliza la orden.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type OrdenServicio5EntityOrdenServicioType = typeof ordenServicio5EntityOrdenServicio;
    export default ordenServicio5EntityOrdenServicio;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/Aparato.defs" {
    export const ordenServicio5EntityAparato: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "Aparato";
        readonly title: "Aparato";
        readonly description: "Equipo electrónico recibido para análisis, reparación y posterior entrega o retiro.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "AssetEquipment";
        readonly displayField: "serialNumber";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "ordenServicio5.Aparato";
        };
    };
    export type OrdenServicio5EntityAparatoType = typeof ordenServicio5EntityAparato;
    export default ordenServicio5EntityAparato;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/Cliente.defs" {
    export const ordenServicio5EntityCliente: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "Cliente";
        readonly title: "Cliente";
        readonly description: "Persona que presenta el aparato, consulta su orden en el portal y responde al presupuesto.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "ordenServicio5.Cliente";
        };
    };
    export type OrdenServicio5EntityClienteType = typeof ordenServicio5EntityCliente;
    export default ordenServicio5EntityCliente;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/DefectoInformado.defs" {
    export const ordenServicio5EntityDefectoInformado: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "DefectoInformado";
        readonly title: "Defecto informado";
        readonly description: "Manifestación o problema del aparato informado por el cliente al momento de la recepción.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "descripcion";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único del defecto informado.";
        }, {
            readonly fieldId: "descripcion";
            readonly title: "Descripción";
            readonly type: "text";
            readonly required: true;
            readonly description: "Descripción del problema o manifestación del aparato informada por el cliente.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type OrdenServicio5EntityDefectoInformadoType = typeof ordenServicio5EntityDefectoInformado;
    export default ordenServicio5EntityDefectoInformado;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/Diagnostico.defs" {
    export const ordenServicio5EntityDiagnostico: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "Diagnostico";
        readonly title: "Diagnóstico";
        readonly description: "Resultado técnico del análisis del aparato y de la causa del defecto reportado.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "descripcion";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único del diagnóstico.";
        }, {
            readonly fieldId: "descripcion";
            readonly title: "Descripción del diagnóstico";
            readonly type: "text";
            readonly required: true;
            readonly description: "Descripción técnica del análisis realizado y de la causa del defecto informado.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type OrdenServicio5EntityDiagnosticoType = typeof ordenServicio5EntityDiagnostico;
    export default ordenServicio5EntityDiagnostico;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/EntregaAparato.defs" {
    export const ordenServicio5EntityEntregaAparato: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "EntregaAparato";
        readonly title: "Entrega de aparato";
        readonly description: "Constancia de la entrega del aparato al cliente al finalizar la gestión.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "fechaEntrega";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único de la constancia de entrega del aparato.";
        }, {
            readonly fieldId: "fechaEntrega";
            readonly title: "Fecha y hora de entrega";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Fecha y hora en que se entrega el aparato al cliente.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type OrdenServicio5EntityEntregaAparatoType = typeof ordenServicio5EntityEntregaAparato;
    export default ordenServicio5EntityEntregaAparato;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/FotoOrden.defs" {
    export const ordenServicio5EntityFotoOrden: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "FotoOrden";
        readonly title: "Foto de la orden";
        readonly description: "Imagen adjunta que documenta el aparato o su condición al recibirlo.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "nombreArchivo";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único de la foto de la orden.";
        }, {
            readonly fieldId: "nombreArchivo";
            readonly title: "Nombre del archivo";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nombre del archivo de imagen adjunto a la orden.";
        }, {
            readonly fieldId: "urlArchivo";
            readonly title: "Ubicación del archivo";
            readonly type: "string";
            readonly required: true;
            readonly description: "Ubicación donde se almacena la imagen adjunta.";
        }, {
            readonly fieldId: "tipoMime";
            readonly title: "Tipo de archivo";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo MIME de la imagen adjunta.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type OrdenServicio5EntityFotoOrdenType = typeof ordenServicio5EntityFotoOrden;
    export default ordenServicio5EntityFotoOrden;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/OrdenServicio.defs" {
    export const ordenServicio5EntityOrdenServicio: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "OrdenServicio";
        readonly title: "Orden de servicio";
        readonly description: "Gestión del servicio técnico de un aparato recibido, desde su recepción hasta su entrega o retiro.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "numeroOrden";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único de la orden de servicio.";
        }, {
            readonly fieldId: "numeroOrden";
            readonly title: "Número de orden";
            readonly type: "string";
            readonly required: true;
            readonly description: "Número visible que identifica la orden de servicio.";
        }, {
            readonly fieldId: "clienteId";
            readonly title: "Cliente";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Cliente seleccionado que presentó el aparato para el servicio.";
        }, {
            readonly fieldId: "aparatoId";
            readonly title: "Aparato";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Aparato seleccionado que fue recibido para el servicio técnico.";
        }, {
            readonly fieldId: "defectoInformadoId";
            readonly title: "Defecto informado";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Registro seleccionado con el defecto informado por el cliente.";
        }, {
            readonly fieldId: "fotoOrdenIds";
            readonly title: "Fotos de la orden";
            readonly type: "json";
            readonly required: false;
            readonly description: "Referencias a las fotos asociadas a la recepción del aparato.";
        }, {
            readonly fieldId: "diagnosticoId";
            readonly title: "Diagnóstico";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Diagnóstico técnico seleccionado para la orden.";
        }, {
            readonly fieldId: "presupuestoId";
            readonly title: "Presupuesto";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Presupuesto seleccionado que se presenta al cliente.";
        }, {
            readonly fieldId: "reparacionId";
            readonly title: "Reparación";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Registro seleccionado de la reparación realizada.";
        }, {
            readonly fieldId: "entregaAparatoId";
            readonly title: "Entrega del aparato";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Registro seleccionado de la entrega del aparato al cliente.";
        }, {
            readonly fieldId: "status";
            readonly title: "Estado";
            readonly type: "string";
            readonly required: true;
            readonly enum: ["received", "quoted", "approved", "rejected", "readyForPickup", "completed"];
            readonly description: "Estado actual de la orden de servicio.";
        }];
        readonly lifecycleStates: [{
            readonly state: "received";
            readonly reachedBy: "actor";
        }, {
            readonly state: "quoted";
            readonly reachedBy: "actor";
        }, {
            readonly state: "approved";
            readonly reachedBy: "actor";
        }, {
            readonly state: "rejected";
            readonly reachedBy: "actor";
        }, {
            readonly state: "readyForPickup";
            readonly reachedBy: "actor";
        }, {
            readonly state: "completed";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "quoteOrder";
            readonly from: ["received"];
            readonly to: "quoted";
            readonly by: ["tecnico"];
            readonly description: "El técnico registra el diagnóstico y el presupuesto para poner la orden a disposición del cliente.";
        }, {
            readonly transitionId: "approveQuote";
            readonly from: ["quoted"];
            readonly to: "approved";
            readonly by: ["cliente"];
            readonly description: "El cliente aprueba el presupuesto y autoriza la reparación.";
        }, {
            readonly transitionId: "rejectQuote";
            readonly from: ["quoted"];
            readonly to: "rejected";
            readonly by: ["cliente"];
            readonly description: "El cliente rechaza el presupuesto, cierra la orden como rechazada y deja el aparato disponible para retiro.";
        }, {
            readonly transitionId: "markReadyForPickup";
            readonly from: ["approved"];
            readonly to: "readyForPickup";
            readonly by: ["tecnico"];
            readonly description: "El técnico registra la reparación y marca el aparato como listo para entregar.";
        }, {
            readonly transitionId: "completeRejectedOrder";
            readonly from: ["rejected"];
            readonly to: "completed";
            readonly by: ["recepcionista"];
            readonly description: "El recepcionista entrega el aparato retirado y finaliza la orden rechazada.";
        }, {
            readonly transitionId: "completeRepairedOrder";
            readonly from: ["readyForPickup"];
            readonly to: "completed";
            readonly by: ["recepcionista"];
            readonly description: "El recepcionista entrega el aparato reparado y finaliza la orden.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type OrdenServicio5EntityOrdenServicioType = typeof ordenServicio5EntityOrdenServicio;
    export default ordenServicio5EntityOrdenServicio;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/PiezaNecesaria.defs" {
    export const ordenServicio5EntityPiezaNecesaria: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "PiezaNecesaria";
        readonly title: "Pieza necesaria";
        readonly description: "Pieza o insumo identificado para la reparación, incluyendo su costo interno.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "nombrePieza";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único de la pieza necesaria.";
        }, {
            readonly fieldId: "nombrePieza";
            readonly title: "Nombre de la pieza";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nombre de la pieza o insumo necesario para la reparación.";
        }, {
            readonly fieldId: "cantidad";
            readonly title: "Cantidad";
            readonly type: "integer";
            readonly required: true;
            readonly description: "Cantidad requerida de esta pieza o insumo.";
        }, {
            readonly fieldId: "costoInterno";
            readonly title: "Costo interno";
            readonly type: "money";
            readonly required: true;
            readonly description: "Costo interno de la pieza o insumo para el servicio técnico.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type OrdenServicio5EntityPiezaNecesariaType = typeof ordenServicio5EntityPiezaNecesaria;
    export default ordenServicio5EntityPiezaNecesaria;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/Presupuesto.defs" {
    export const ordenServicio5EntityPresupuesto: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "Presupuesto";
        readonly title: "Presupuesto";
        readonly description: "Propuesta económica comunicada al cliente para autorizar o rechazar la reparación.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "valorCliente";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único del presupuesto.";
        }, {
            readonly fieldId: "valorCliente";
            readonly title: "Valor del presupuesto";
            readonly type: "money";
            readonly required: true;
            readonly description: "Importe propuesto al cliente por la reparación.";
        }, {
            readonly fieldId: "piezasNecesarias";
            readonly title: "Piezas necesarias";
            readonly type: "json";
            readonly required: false;
            readonly description: "Referencias a las piezas necesarias incluidas en el presupuesto.";
        }, {
            readonly fieldId: "status";
            readonly title: "Estado";
            readonly type: "string";
            readonly required: true;
            readonly enum: ["pendingResponse", "approved", "rejected"];
            readonly description: "Estado de la respuesta del cliente al presupuesto.";
        }];
        readonly lifecycleStates: [{
            readonly state: "pendingResponse";
            readonly reachedBy: "actor";
        }, {
            readonly state: "approved";
            readonly reachedBy: "actor";
        }, {
            readonly state: "rejected";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "aprobarPresupuesto";
            readonly from: ["pendingResponse"];
            readonly to: "approved";
            readonly by: ["cliente"];
            readonly description: "El cliente aprueba el presupuesto desde el portal y autoriza la reparación.";
        }, {
            readonly transitionId: "rechazarPresupuesto";
            readonly from: ["pendingResponse"];
            readonly to: "rejected";
            readonly by: ["cliente"];
            readonly description: "El cliente rechaza el presupuesto desde el portal; la orden queda cerrada como rechazada y el aparato disponible para retiro.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type OrdenServicio5EntityPresupuestoType = typeof ordenServicio5EntityPresupuesto;
    export default ordenServicio5EntityPresupuesto;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/Reparacion.defs" {
    export const ordenServicio5EntityReparacion: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly entityId: "Reparacion";
        readonly title: "Reparación";
        readonly description: "Registro de las tareas técnicas efectivamente realizadas sobre el aparato autorizado.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "detalleTrabajo";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único del registro de reparación.";
        }, {
            readonly fieldId: "detalleTrabajo";
            readonly title: "Detalle del trabajo realizado";
            readonly type: "text";
            readonly required: true;
            readonly description: "Describe las tareas técnicas efectuadas durante la reparación del aparato.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type OrdenServicio5EntityReparacionType = typeof ordenServicio5EntityReparacion;
    export default ordenServicio5EntityReparacion;
}
declare module "_102035_/l2/agentNewSolution5/steps/ontology30/fixtures/ordenServicio5/index.defs" {
    export const ordenServicio5OntologyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-ontology-v1";
        readonly moduleName: "ordenServicio5";
        readonly businessDomain: "Gestión de órdenes de servicio técnico para aparatos electrónicos, desde la recepción hasta la entrega.";
        readonly entities: ["DefectoInformado", "FotoOrden", "Diagnostico", "PiezaNecesaria", "Reparacion", "EntregaAparato", "Presupuesto", "OrdenServicio", "Cliente", "Aparato"];
        readonly relationships: [{
            readonly relationshipId: "ordenTieneCliente";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "Cliente";
            readonly type: "manyToOne";
            readonly required: true;
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["clienteId"];
                };
                readonly to: {
                    readonly entityId: "Cliente";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordenTieneAparato";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "Aparato";
            readonly type: "manyToOne";
            readonly required: true;
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["aparatoId"];
                };
                readonly to: {
                    readonly entityId: "Aparato";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordenRegistraDefectoInformado";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "DefectoInformado";
            readonly type: "oneToOne";
            readonly required: true;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["defectoInformadoId"];
                };
                readonly to: {
                    readonly entityId: "DefectoInformado";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordenIncluyeFotos";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "FotoOrden";
            readonly type: "oneToMany";
            readonly required: false;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldCollection";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["fotoOrdenIds"];
                };
                readonly to: {
                    readonly entityId: "FotoOrden";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordenTieneDiagnostico";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "Diagnostico";
            readonly type: "oneToOne";
            readonly required: false;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["diagnosticoId"];
                };
                readonly to: {
                    readonly entityId: "Diagnostico";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordenTienePresupuesto";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "Presupuesto";
            readonly type: "oneToOne";
            readonly required: false;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["presupuestoId"];
                };
                readonly to: {
                    readonly entityId: "Presupuesto";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "presupuestoIncluyePiezasNecesarias";
            readonly fromEntity: "Presupuesto";
            readonly toEntity: "PiezaNecesaria";
            readonly type: "oneToMany";
            readonly required: false;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldCollection";
                readonly ownerEntity: "Presupuesto";
                readonly from: {
                    readonly entityId: "Presupuesto";
                    readonly fieldIds: ["piezasNecesarias"];
                };
                readonly to: {
                    readonly entityId: "PiezaNecesaria";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordenRegistraReparacion";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "Reparacion";
            readonly type: "oneToOne";
            readonly required: false;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["reparacionId"];
                };
                readonly to: {
                    readonly entityId: "Reparacion";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordenRegistraEntregaAparato";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "EntregaAparato";
            readonly type: "oneToOne";
            readonly required: false;
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["entregaAparatoId"];
                };
                readonly to: {
                    readonly entityId: "EntregaAparato";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type OrdenServicio5OntologyIndexType = typeof ordenServicio5OntologyIndex;
    export default ordenServicio5OntologyIndex;
}
declare module "_102035_/l2/agentNewSolution5/steps/rules40/fixtures/comandaRestaurante5-rules.defs" {
    export const comandaRestaurante5Rules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly rules: [{
            readonly ruleId: "valorTotalDoLancamento";
            readonly description: "O valor total de um item da comanda é a quantidade multiplicada pelo preço unitário e é desconsiderado quando o lançamento está cancelado.";
        }, {
            readonly ruleId: "valorItensDaComanda";
            readonly description: "O valor dos itens da comanda é a soma dos valores dos lançamentos que não foram cancelados.";
        }, {
            readonly ruleId: "valorDescontosDaComanda";
            readonly description: "O valor dos descontos da comanda é a soma dos descontos pontuais registrados para a comanda.";
        }, {
            readonly ruleId: "valorDevidoDaComanda";
            readonly description: "O valor devido da comanda é o valor a receber após deduzir os descontos do valor dos itens.";
        }, {
            readonly ruleId: "valorPagoDaComanda";
            readonly description: "O valor pago da comanda é a soma dos pagamentos registrados para a comanda.";
        }, {
            readonly ruleId: "saldoDevedorDaComanda";
            readonly description: "O saldo devedor da comanda é o valor que ainda falta receber para quitar a comanda, obtido subtraindo o valor pago do valor devido.";
        }, {
            readonly ruleId: "fecharComandaAposQuitacao";
            readonly description: "A comanda só pode ser fechada depois que o caixa conferir o consumo e o valor pago cobrir integralmente o valor devido.";
        }, {
            readonly ruleId: "cancelarItemEmComandaAberta";
            readonly description: "O garçom só pode cancelar um item lançado por engano enquanto a comanda permanece aberta.";
        }];
    };
    export type ComandaRestaurante5RulesType = typeof comandaRestaurante5Rules;
    export default comandaRestaurante5Rules;
}
declare module "_102035_/l2/agentNewSolution5/steps/rules40/fixtures/ordenServicio5-rules.defs" {
    export const ordenServicio5Rules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "ordenServicio5";
        readonly rules: [{
            readonly ruleId: "datosObligatoriosRecepcion";
            readonly description: "Al abrir una orden de servicio deben registrarse los datos del cliente, el aparato, el defecto informado y las fotos.";
        }, {
            readonly ruleId: "diagnosticoPiezasYpresupuestoObligatorios";
            readonly description: "Para presupuestar una orden deben registrarse el diagnóstico, las piezas necesarias con su costo interno y el valor del presupuesto para el cliente.";
        }, {
            readonly ruleId: "rechazoCierraOrdenYhabilitaRetiro";
            readonly description: "Si el cliente rechaza el presupuesto, la orden se cierra como rechazada y el aparato queda disponible para retiro.";
        }, {
            readonly ruleId: "aprobacionHabilitaReparacion";
            readonly description: "Si el cliente aprueba el presupuesto, la orden queda disponible para que el técnico realice la reparación.";
        }, {
            readonly ruleId: "reparacionRegistradaParaMarcarLista";
            readonly description: "El técnico debe registrar las tareas efectuadas en la reparación antes de marcar la orden como lista para entrega.";
        }, {
            readonly ruleId: "entregaDeOrdenListaOrechazada";
            readonly description: "El recepcionista entrega el aparato y finaliza la orden cuando esta está lista para entrega o cuando quedó rechazada con el aparato disponible para retiro.";
        }, {
            readonly ruleId: "visibilidadPortalCliente";
            readonly description: "El cliente ve y responde solamente sus propias órdenes, con estado, diagnóstico y valor del presupuesto, y nunca el costo interno de las piezas ni las anotaciones del técnico.";
        }];
    };
    export type OrdenServicio5RulesType = typeof ordenServicio5Rules;
    export default ordenServicio5Rules;
}
declare module "_102035_/l2/agentNewSolution5/steps/workflows50/fixtures/comandaRestaurante5-workflows.defs" {
    export const comandaRestaurante5Workflows: {
        readonly schemaVersion: "2026-09-10-ns5-workflows-v1";
        readonly moduleName: "comandaRestaurante5";
        readonly processes: [];
    };
    export type ComandaRestaurante5WorkflowsType = typeof comandaRestaurante5Workflows;
    export default comandaRestaurante5Workflows;
}
declare module "_102035_/l2/agentNewSolution5/steps/workflows50/fixtures/ordenServicio5-workflows.defs" {
    export const ordenServicio5Workflows: {
        readonly schemaVersion: "2026-09-10-ns5-workflows-v1";
        readonly moduleName: "ordenServicio5";
        readonly processes: [{
            readonly processId: "gestionarOrdenServicio";
            readonly title: "Gestionar orden de servicio";
            readonly description: "Coordinar la recepción, el presupuesto, la respuesta del cliente, la reparación o el retiro y la finalización de una orden de servicio.";
            readonly tasks: [{
                readonly taskId: "registrarRecepcion";
                readonly kind: "human";
                readonly actorRef: "recepcionista";
                readonly journeyRef: "registrarRecepcionAparato";
                readonly stepRef: "capturarDatosRecepcion";
                readonly next: ["localizarOrdenParaAnalisis"];
                readonly description: "El recepcionista registra la recepción del aparato y deja la orden disponible para análisis técnico.";
            }, {
                readonly taskId: "localizarOrdenParaAnalisis";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "analizarYpresupuestarOrden";
                readonly stepRef: "localizarOrdenPendiente";
                readonly next: ["inspeccionarAparato"];
                readonly description: "El técnico toma una orden recibida que requiere análisis.";
            }, {
                readonly taskId: "inspeccionarAparato";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "analizarYpresupuestarOrden";
                readonly stepRef: "inspeccionarAparatoYrecepcion";
                readonly next: ["registrarPresupuesto"];
                readonly description: "El técnico revisa el aparato y la información registrada en la recepción.";
            }, {
                readonly taskId: "registrarPresupuesto";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "analizarYpresupuestarOrden";
                readonly stepRef: "registrarDiagnosticoYpresupuesto";
                readonly next: ["localizarPresupuestoCliente"];
                readonly description: "El técnico registra el diagnóstico, las piezas y el presupuesto para que el cliente responda.";
            }, {
                readonly taskId: "localizarPresupuestoCliente";
                readonly kind: "human";
                readonly actorRef: "cliente";
                readonly journeyRef: "responderPresupuesto";
                readonly stepRef: "localizarOrdenPresupuestada";
                readonly next: ["revisarPresupuestoCliente"];
                readonly description: "El cliente accede a su orden presupuestada para responder al presupuesto.";
            }, {
                readonly taskId: "revisarPresupuestoCliente";
                readonly kind: "human";
                readonly actorRef: "cliente";
                readonly journeyRef: "responderPresupuesto";
                readonly stepRef: "revisarPresupuestoYdiagnostico";
                readonly next: ["decidirPresupuesto"];
                readonly description: "El cliente consulta el diagnóstico y el valor presupuestado antes de decidir.";
            }, {
                readonly taskId: "decidirPresupuesto";
                readonly kind: "human";
                readonly actorRef: "cliente";
                readonly journeyRef: "responderPresupuesto";
                readonly stepRef: "decidirRespuestaPresupuesto";
                readonly next: ["registrarRespuestaCliente"];
                readonly description: "El cliente decide aprobar o rechazar el presupuesto de su orden.";
            }, {
                readonly taskId: "registrarRespuestaCliente";
                readonly kind: "human";
                readonly actorRef: "cliente";
                readonly journeyRef: "responderPresupuesto";
                readonly stepRef: "registrarRespuestaPresupuesto";
                readonly next: ["localizarOrdenAprobada", "localizarOrdenParaEntrega"];
                readonly description: "El cliente registra su respuesta, habilitando la reparación si aprueba o el retiro si rechaza.";
            }, {
                readonly taskId: "localizarOrdenAprobada";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "repararYmarcarOrdenLista";
                readonly stepRef: "localizarOrdenAprobada";
                readonly next: ["revisarDiagnosticoYPiezas"];
                readonly description: "El técnico toma la orden cuyo presupuesto fue aprobado para realizar la reparación.";
            }, {
                readonly taskId: "revisarDiagnosticoYPiezas";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "repararYmarcarOrdenLista";
                readonly stepRef: "revisarDiagnosticoYpiezas";
                readonly next: ["registrarReparacion"];
                readonly description: "El técnico revisa el diagnóstico y las piezas antes de reparar el aparato.";
            }, {
                readonly taskId: "registrarReparacion";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "repararYmarcarOrdenLista";
                readonly stepRef: "registrarReparacionRealizada";
                readonly next: ["marcarOrdenLista"];
                readonly description: "El técnico documenta las tareas efectuadas durante la reparación.";
            }, {
                readonly taskId: "marcarOrdenLista";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "repararYmarcarOrdenLista";
                readonly stepRef: "marcarOrdenLista";
                readonly next: ["derivarParaEntrega"];
                readonly description: "El técnico marca la orden reparada como lista para entrega.";
            }, {
                readonly taskId: "derivarParaEntrega";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "repararYmarcarOrdenLista";
                readonly stepRef: "derivarParaEntrega";
                readonly next: ["localizarOrdenParaEntrega"];
                readonly description: "El técnico pone la orden reparada a disposición del recepcionista para su entrega.";
            }, {
                readonly taskId: "localizarOrdenParaEntrega";
                readonly kind: "human";
                readonly actorRef: "recepcionista";
                readonly journeyRef: "entregarAparatoYfinalizarOrden";
                readonly stepRef: "localizarOrdenParaEntrega";
                readonly next: ["verificarOrdenParaEntrega"];
                readonly description: "El recepcionista toma la orden rechazada o lista para entrega del aparato.";
            }, {
                readonly taskId: "verificarOrdenParaEntrega";
                readonly kind: "human";
                readonly actorRef: "recepcionista";
                readonly journeyRef: "entregarAparatoYfinalizarOrden";
                readonly stepRef: "verificarOrdenYaparato";
                readonly next: ["registrarEntregaFinal"];
                readonly description: "El recepcionista verifica la orden, la identificación del cliente y el aparato disponible.";
            }, {
                readonly taskId: "registrarEntregaFinal";
                readonly kind: "human";
                readonly actorRef: "recepcionista";
                readonly journeyRef: "entregarAparatoYfinalizarOrden";
                readonly stepRef: "registrarEntregaYfinalizacion";
                readonly next: [];
                readonly description: "El recepcionista registra la entrega del aparato y finaliza la orden.";
            }];
        }];
    };
    export type OrdenServicio5WorkflowsType = typeof ordenServicio5Workflows;
    export default ordenServicio5Workflows;
}
