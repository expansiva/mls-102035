declare module "_102034_/l1/server/layer_1_external/config/storageConfig" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    type StorageConfig = {
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
    };
    export function getStorageConfig(appEnv: AppEnv['appEnv']): StorageConfig;
}
declare module "_102034_/l1/server/layer_1_external/config/env" {
    export interface AppEnv {
        appEnv: 'development' | 'staging' | 'production';
        port: number;
        pgHost: string;
        pgPort: number;
        pgDatabase: string;
        pgUser: string;
        pgPassword: string;
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
        awsRegion: string;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        awsSessionToken?: string;
        writeBehindEnabled: boolean;
        logLevel: string;
        runtimeMode: 'memory' | 'postgres';
    }
    export function readAppEnv(): AppEnv;
}
declare module "_102034_/l1/server/layer_1_external/persistence/contracts" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export type TablePurpose = 'mdm' | 'cadastro' | 'transacao' | 'controle' | 'fila' | 'cache';
    export type StorageProfile = 'postgres' | 'postgresHotBackup' | 'dynamoOnly' | 'dynamoWithPostgresIndex';
    export type TableWriteMode = 'sync' | 'writeBehind';
    export interface TableColumnDefinition {
        name: string;
        postgresType: string;
        nullable?: boolean;
        defaultSql?: string;
        description?: string;
    }
    export type TableIndexColumnDefinition = string | {
        name: string;
        direction?: 'asc' | 'desc';
    };
    export interface TableIndexDefinition {
        name: string;
        columns: TableIndexColumnDefinition[];
        unique?: boolean;
    }
    export interface DynamoTableConfig {
        tableName?: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        partitionKey: string;
        sortKey?: string;
        ttlField?: string;
    }
    export interface TableDefinition {
        moduleId: string;
        repositoryName?: string;
        tableName: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        purpose: TablePurpose;
        description: string;
        backupHot: boolean;
        storageProfile: StorageProfile;
        writeMode: TableWriteMode;
        columns: TableColumnDefinition[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        postgres?: {
            unlogged?: boolean;
        };
        dynamo?: DynamoTableConfig;
        retentionDays?: number;
        version: number;
    }
    export interface ResolvedTableDefinition extends TableDefinition {
        projectId: string;
        repositoryName: string;
        dynamoResolvedTableName: string | null;
    }
    export interface SchemaSnapshot {
        id: string;
        hash: string;
        appliedAt: string;
        tables: Array<{
            projectId: string;
            moduleId: string;
            repositoryName: string;
            tableName: string;
            storageProfile: StorageProfile;
            backupHot: boolean;
            dynamoTableName: string | null;
            version: number;
        }>;
    }
    export function resolveRepositoryName(definition: TableDefinition): string;
    export function resolveDynamoTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string | null;
    export function resolvePostgresTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string;
    export function usesPostgres(definition: TableDefinition): boolean;
    export function usesDynamo(definition: TableDefinition): boolean;
    export function requiresWriteBehind(definition: TableDefinition): boolean;
}
declare module "_102035_/l1/locadora/layer_1_external/persistence" {
    import type { TableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export const tableDefinitions: TableDefinition[];
}
declare module "_102035_/l2/locadora/web/contracts/adminDashboard" {
    export interface LocadoraVeiculoResponse {
        placa: string;
        modelo: string;
        ano: number;
        categoria: string;
        status: 'disponível' | 'locado' | 'manutenção';
        quilometragem: number;
    }
    export interface LocadoraUpdateVeiculoRequest {
        placa: string;
        modelo?: string;
        ano?: number;
        categoria?: string;
        status?: LocadoraVeiculoResponse['status'];
        quilometragem?: number;
        author?: string;
    }
    export interface LocadoraClienteResponse {
        nome: string;
        cpf: string;
        cnh: string;
        telefone: string;
        email: string;
    }
    export interface LocadoraUpdateClienteRequest {
        nome: string;
        cpf?: string;
        cnh?: string;
        telefone?: string;
        email?: string;
        author?: string;
    }
    export interface LocadoraLocacaoResponse {
        dataRetirada: string;
        dataDevolucao: string;
        valorDiario: number;
        seguroOpcional?: boolean;
        formaPagamento: string;
        devolucaoPrevista: string;
        placaVeiculo: string;
        cpf: string;
    }
    export interface LocadoraUpdateLocacaoRequest {
        dataRetirada: string;
        dataDevolucao?: string;
        valorDiario?: number;
        seguroOpcional?: LocadoraLocacaoResponse['seguroOpcional'];
        formaPagamento?: string;
        devolucaoPrevista?: string;
        placaVeiculo?: string;
        cpf?: string;
        author?: string;
    }
}
declare module "_102034_/l1/mdm/defs/ontology" {
    /**
     * MDM — Master Data Model
     * Ontology: conceptual source of truth for all shared entities.
     *
     * Storage strategy: hybrid
     *   - DynamoDB  → single document store, 3 columns: mdmId | version | details
     *   - PostgreSQL → two lean indexes:
     *       MdmEntity      → permanent, qualified, deduplicated records
     *       MdmProspect    → transient records (leads, unverified imports, anonymous captures)
     *
     * Every entity is identified by a universal mdmId.
     * The mdmId is stable from creation through promotion — references never break.
     * Any module may reference an mdmId without knowing its subtype.
     *
     * Default country: US (ISO 3166-1 alpha-2: "US")
     *
     * Naming: PascalCase for entity/type names, camelCase for fields.
     */
    export type MdmSubtype = 'Person' | 'Company' | 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel';
    export type MdmStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmProspectStatus = 'New' | 'InProgress' | 'PendingMerge' | 'Promoted' | 'Expired' | 'Discarded';
    export type DocType = 'SSN' | 'EIN' | 'Passport' | 'DriversLicense' | 'NationalId' | 'CPF' | 'CNPJ' | 'VAT' | 'Other';
    export type RelationshipType = 'Owns' | 'Employs' | 'OffersProduct' | 'OffersService' | 'StocksAt' | 'Teaches' | 'HappensAt' | 'FranchiseOf' | 'BelongsToGroup' | 'PartOfUnit' | 'ManagedBy' | 'ReportsTo' | 'AssignedTo' | 'Attends' | 'SuppliesProduct' | 'PartnersWith' | 'Family' | 'GuardianOf' | 'CustomerOf' | 'SupplierOf' | 'MemberOf' | 'HoldsAccount' | 'SubsidiaryOf' | 'LocatedAt' | 'Signed' | 'HasContact';
    /**
     * Address
     * Global address model based on Google / Apple / USPS international format.
     * Embedded as an array inside Person, Company, and AssetProperty documents.
     * Never stored as a standalone row or MDM entity.
     *
     * line1 + line2 + line3 cover the full range of international address formats:
     *   US:     line1="123 Main St", line2="Apt 4B"
     *   Brazil: line1="Rua das Flores 100", line2="Apto 42", line3="Jardim Paulista"
     *   Japan:  line1="1-2-3 Shinjuku", line2="Shinjuku-ku", line3="Tokyo"
     */
    export const Address: {
        readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
        readonly fields: {
            readonly type: {
                readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
            };
            readonly label: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Short human label for this address.";
                readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
            };
            readonly line1: {
                readonly type: "string";
                readonly description: "Primary address line: street and number, PO Box, or rural route.";
            };
            readonly line2: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Secondary line: apartment, suite, floor, unit, building.";
            };
            readonly line3: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
            };
            readonly city: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly stateOrProvince: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
            };
            readonly postalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                readonly constraints: "Default: US";
            };
            readonly formatted: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
            };
            readonly geolocation: {
                readonly type: "{ lat: number; lng: number } | null";
                readonly required: false;
            };
            readonly isPrimary: {
                readonly type: "boolean";
            };
        };
    };
    export const PrivacyConsent: {
        readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
        readonly fields: {
            readonly consentedAt: {
                readonly type: "timestamp";
            };
            readonly consentVersion: {
                readonly type: "string";
                readonly description: "Version of the privacy policy accepted.";
            };
            readonly channel: {
                readonly type: "string";
                readonly description: "How consent was obtained.";
                readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
            };
            readonly revokedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
            };
        };
    };
    /**
     * ContactSummary
     * Embedded inside every entity detail as part of contacts[].
     * Contains only mdmId + title — zero contact data inline.
     * Full contact data (channel type, value, verified status) lives in the ContactChannel entity document.
     * This ensures traceability without duplicating sensitive data.
     */
    export const ContactSummary: {
        readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
            };
            readonly title: {
                readonly type: "string";
                readonly description: "Human-readable label for this contact in the context of the parent entity.";
                readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
            };
        };
    };
    export const CompactRelationshipRefs: {
        readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
        readonly fields: {
            readonly ownedAssets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly owners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employees: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly partners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly family: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly pets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly guardians: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly customers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly suppliers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly memberships: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly members: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly bankAccounts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly accountHolders: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly subsidiaries: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly parentCompanies: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locations: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locatedEntities: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly documents: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly signedBy: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contacts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contactOwners: {
                readonly type: "string[]";
                readonly required: false;
            };
        };
    };
    /**
     * MdmDocument
     * Three top-level columns only. All entity data lives inside details.
     * DynamoDB is used as a pure document store — no GSIs, no top-level attribute queries.
     * All querying is done via the PostgreSQL indexes (MdmEntity or MdmProspect).
     */
    export const MdmDocument: {
        readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
            };
            readonly version: {
                readonly type: "number";
                readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
            };
            readonly details: {
                readonly type: "object (JSON document)";
                readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
            };
        };
    };
    /**
     * MdmEntity
     * Permanent, qualified, deduplicated MDM records.
     * Contains only the fields needed for filtering, searching, joining, and deduplication.
     * Full entity data is always read from DynamoDB by dynamoPk.
     *
     * Sync strategy:
     *   SYNC  → written to PostgreSQL in the same request as DynamoDB
     *   async → propagated by the background worker after each DynamoDB write
     */
    export const MdmEntity: {
        readonly description: "PostgreSQL index for permanent MDM entities.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly sync: "SYNC";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
                readonly sync: "SYNC";
            };
            readonly name: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmStatus";
                readonly sync: "SYNC";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly sync: "SYNC";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "UNIQUE constraint on (docType, docId) — enforces deduplication for permanent records.";
                readonly constraints: "Formatted without punctuation.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly sync: "async";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly sync: "async";
                readonly required: false;
            };
            readonly searchVector: {
                readonly type: "tsvector";
                readonly sync: "async";
                readonly description: "Full-text search vector generated from name + aliases + docId.";
            };
            readonly mergedInto: {
                readonly type: "string (uuid) | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "When status is Merged, points to the winning mdmId.";
            };
            readonly dynamoPk: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly description: "DynamoDB partition key for direct document reads.";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmEntity";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "mergedInto", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "searchVector", "createdAt", "updatedAt"];
            };
        };
    };
    /**
     * MdmProspect
     * Transient, unverified, or provisional entities: leads, anonymous visitors,
     * unconfirmed signups, bulk imports pending review.
     *
     * Key differences from MdmEntity:
     *   - No UNIQUE constraint on (docType, docId)
     *   - Has ttlExpiresAt for auto-expiry
     *   - Has promotionSource to track origin module
     *   - Status covers the full promotion lifecycle
     *
     * DynamoDB document structure is identical (mdmId, version, details).
     * The separation is PostgreSQL-only.
     *
     * Promotion flow:
     *   1. Module calls mdm.promoteProspect(prospectMdmId)
     *   2. MDM runs dedup: does MdmEntity have matching (docType, docId)?
     *   3a. No match  → insert into MdmEntity, delete from MdmProspect. Same mdmId survives.
     *   3b. Match     → set status PendingMerge. Operator confirms merge.
     *   4. Calling module updates its extension table to point to the final mdmId.
     */
    export const MdmProspect: {
        readonly description: "PostgreSQL index for transient MDM records. Isolated from MdmEntity to preserve query performance and deduplication integrity.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly description: "Same mdmId space as MdmEntity. Stable from creation through promotion.";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
            };
            readonly name: {
                readonly type: "string";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmProspectStatus";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "No UNIQUE constraint. Duplicates allowed — resolved on promotion.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly promotionSource: {
                readonly type: "string";
                readonly description: "Module that created this prospect.";
                readonly constraints: "Examples: crm, marketing-automation, web-capture, bulk-import";
            };
            readonly promotedTo: {
                readonly type: "string (uuid) | null";
                readonly required: false;
                readonly description: "mdmId of the MdmEntity record this prospect was promoted or merged into.";
            };
            readonly ttlExpiresAt: {
                readonly type: "timestamp | null";
                readonly required: false;
                readonly description: "Auto-expiry timestamp. Null means no expiry.";
            };
            readonly dynamoPk: {
                readonly type: "string";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspect";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "ttlExpiresAt", "createdAt", "updatedAt"];
            };
        };
    };
    export const MdmRelationship: {
        readonly description: "Typed, versioned relationship between any two permanent MDM entities. PostgreSQL is the source of truth for relationship rows. DynamoDB details may also contain compact derived references in relationshipRefs for read optimization, and the full rows may be replicated to mdm_relationship_documents for recovery.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — must exist in MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — must exist in MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars. Examples: managing-partner, spouse, account-manager";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
                readonly description: "Rich relationship data as JSONB. See RelationshipCatalog for examples per type.";
            };
            readonly isBidirectional: {
                readonly type: "boolean";
                readonly description: "True for symmetric relationships (Family). False for directional (Employs, Owns).";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
                readonly description: "Null means currently active.";
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    /**
     * MdmProspectRelationship
     * Same schema as MdmRelationship, scoped to MdmProspect records.
     * fromId and toId may reference either MdmProspect or MdmEntity rows.
     * On promotion, relationships that reference a promoted entity are migrated
     * to MdmRelationship by the promotion workflow.
     */
    export const MdmProspectRelationship: {
        readonly description: "Relationship table for prospect entities. Same structure as MdmRelationship. Isolated to preserve query performance on the permanent relationship graph. Compact derived references may also appear in details.relationshipRefs, and full rows may be replicated to mdm_relationship_documents.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
            };
            readonly isBidirectional: {
                readonly type: "boolean";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspectRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    export const PersonDetail: {
        readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
        readonly fields: {
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly gender: {
                readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                readonly required: false;
            };
            readonly nationality: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ISO 3166-1 alpha-2 country of nationality.";
            };
            readonly occupation: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly photoUrl: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly privacyConsent: {
                readonly type: "PrivacyConsent | null";
                readonly required: false;
                readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
    };
    export const CompanyDetail: {
        readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
        readonly fields: {
            readonly companyKind: {
                readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                readonly description: "Organizational classification for legal and internal structures.";
            };
            readonly parentCompanyId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId for organizational trees.";
            };
            readonly externalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ERP/HR/legacy code used by consuming modules.";
            };
            readonly tradeName: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "DBA name. Also stored in aliases for full-text search.";
            };
            readonly legalName: {
                readonly type: "string";
                readonly description: "Official registered name.";
            };
            readonly legalType: {
                readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                readonly required: false;
            };
            readonly foundingDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly taxRegime: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
            };
            readonly industryCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
            };
            readonly website: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
    };
    export const ProductDetail: {
        readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
        readonly fields: {
            readonly sku: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Internal stock keeping unit.";
            };
            readonly productType: {
                readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly unitOfMeasure: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: unit, box, kg, liter, hour.";
            };
            readonly isInventoried: {
                readonly type: "boolean";
                readonly required: false;
                readonly description: "True when stock is tracked by location.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const ServiceDetail: {
        readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
        readonly fields: {
            readonly serviceCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly serviceKind: {
                readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                readonly required: false;
                readonly description: "Use Cohort for a concrete class/offering instance.";
            };
            readonly parentServiceId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
            };
            readonly serviceType: {
                readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                readonly required: false;
            };
            readonly durationMinutes: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly deliveryMode: {
                readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const LocationDetail: {
        readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
        readonly fields: {
            readonly locationType: {
                readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
            };
            readonly locationCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly parentLocationId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId when this place belongs to a larger place.";
            };
            readonly capacity: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const AssetVehicleDetail: {
        readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
        readonly fields: {
            readonly plate: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly vin: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Vehicle Identification Number.";
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly year: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fuelType: {
                readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetPropertyDetail: {
        readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
        readonly fields: {
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Deed number, cadastral reference, or equivalent.";
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly areaSqft: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square feet (primary unit for US).";
            };
            readonly areaM2: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square meters (non-US markets).";
            };
            readonly propertyType: {
                readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                readonly required: false;
            };
            readonly taxParcelId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tax parcel / assessor ID (US) or equivalent.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetEquipmentDetail: {
        readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
        readonly fields: {
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: printer, server, forklift, medical device";
            };
            readonly acquisitionDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetGenericDetail: {
        readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
        readonly fields: {
            readonly assetCategory: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
            };
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly manufacturer: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AnimalDetail: {
        readonly description: "Subtype Animal — pets, livestock, working animals.";
        readonly fields: {
            readonly species: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
            };
            readonly breed: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly sex: {
                readonly type: "'Male' | 'Female' | 'Unknown' | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly microchip: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Breed registry, USDA tag, or official animal ID.";
            };
            readonly isNeutered: {
                readonly type: "boolean | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const BankAccountDetail: {
        readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
        readonly fields: {
            readonly bankRoutingNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ABA routing number (US). Use swift for international.";
            };
            readonly bankName: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountType: {
                readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                readonly required: false;
            };
            readonly swift: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "BIC/SWIFT for international transfers.";
            };
            readonly iban: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKey: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKeyType: {
                readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                readonly required: false;
            };
            readonly isVerified: {
                readonly type: "boolean";
                readonly description: "Verified via micro-deposit, open banking, or manual review.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
    };
    export const DocumentDetail: {
        readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
        readonly fields: {
            readonly originModule: {
                readonly type: "string";
                readonly description: "Module that created this record.";
                readonly constraints: "Examples: legal, maintenance, hr, finance";
            };
            readonly docCategory: {
                readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
            };
            readonly storageBucket: {
                readonly type: "string";
                readonly description: "S3 bucket (or equivalent) where the file resides.";
            };
            readonly storagePath: {
                readonly type: "string";
                readonly description: "Relative path within the bucket. Immutable after creation.";
                readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
            };
            readonly fileName: {
                readonly type: "string";
            };
            readonly mimeType: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fileSizeKb: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly issuedAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly expiresAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly issuer: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Free text issuing authority name. Not an mdmId.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
    };
    export const ContactChannelDetail: {
        readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
        readonly fields: {
            readonly contactType: {
                readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
            };
            readonly value: {
                readonly type: "string";
                readonly description: "Full contact value. Stored unmasked.";
                readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
            };
            readonly isVerified: {
                readonly type: "boolean";
            };
            readonly verifiedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-contact-value-unique-per-type"];
    };
    export const RelationshipCatalog: {
        readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
        readonly entries: readonly [{
            readonly type: "Owns";
            readonly from: "Person | Company";
            readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
        }, {
            readonly type: "Employs";
            readonly from: "Company";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
        }, {
            readonly type: "OffersProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
        }, {
            readonly type: "OffersService";
            readonly from: "Company | Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
        }, {
            readonly type: "StocksAt";
            readonly from: "Product | AssetEquipment";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
        }, {
            readonly type: "Teaches";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
        }, {
            readonly type: "HappensAt";
            readonly from: "Service";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
        }, {
            readonly type: "FranchiseOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
        }, {
            readonly type: "BelongsToGroup";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"subsidiary-brand\" }";
        }, {
            readonly type: "PartOfUnit";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
        }, {
            readonly type: "ManagedBy";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
        }, {
            readonly type: "ReportsTo";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"direct-report\" }";
        }, {
            readonly type: "AssignedTo";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
        }, {
            readonly type: "Attends";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
        }, {
            readonly type: "SuppliesProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
        }, {
            readonly type: "PartnersWith";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
        }, {
            readonly type: "Family";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: true;
            readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
        }, {
            readonly type: "GuardianOf";
            readonly from: "Person";
            readonly to: "Animal";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
        }, {
            readonly type: "CustomerOf";
            readonly from: "Person | Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
        }, {
            readonly type: "SupplierOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
        }, {
            readonly type: "MemberOf";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
        }, {
            readonly type: "HoldsAccount";
            readonly from: "Person | Company";
            readonly to: "BankAccount";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
        }, {
            readonly type: "SubsidiaryOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
        }, {
            readonly type: "LocatedAt";
            readonly from: "Person | Company";
            readonly to: "AssetProperty";
            readonly bidirectional: false;
            readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
        }, {
            readonly type: "Signed";
            readonly from: "Person | Company";
            readonly to: "Document";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
        }, {
            readonly type: "HasContact";
            readonly from: "any";
            readonly to: "ContactChannel";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true }";
        }];
    };
    export const MdmOntology: {
        readonly module: "mdm";
        readonly description: "Master Data Model — shared reference entities for all platform modules";
        readonly defaultCountry: "US";
        readonly storageStrategy: "hybrid";
        readonly storageNotes: readonly ["DynamoDB is the source of truth. Three columns per document: mdmId | version | details.", "details is a structured JSON document object containing all entity fields.", "details may embed compact relationshipRefs arrays for fast reads and restore support.", "Full relationship rows are replicated to DynamoDB table mdm_relationship_documents for backup and PostgreSQL rebuilds.", "No DynamoDB GSIs. All querying goes through PostgreSQL indexes.", "PostgreSQL has two index tables: MdmEntity (permanent) and MdmProspect (transient).", "MdmEntity enforces UNIQUE(docType, docId). MdmProspect does not.", "SYNC fields are written to PostgreSQL in the same request as DynamoDB.", "Async fields are propagated by a background worker reading updatedAt from details.", "Module extensions use a separate table per module (e.g. CrmMdmExt) with mdmId as FK.", "MDM has no knowledge of any consuming module — dependency is always module → MDM.", "On prospect promotion: mdmId is preserved. Merge conflicts require operator confirmation."];
        readonly postgresIndexes: {
            readonly MdmEntity: "Permanent, qualified, deduplicated records. UNIQUE(docType, docId).";
            readonly MdmProspect: "Transient records. No unique constraint on docId. Supports TTL expiry.";
            readonly MdmRelationship: "Relationship graph for permanent entities.";
            readonly MdmProspectRelationship: "Relationship graph for prospect entities. Same schema as MdmRelationship.";
        };
        readonly dynamoDocumentSchema: {
            readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
            readonly fields: {
                readonly mdmId: {
                    readonly type: "string (uuid)";
                    readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
                };
                readonly version: {
                    readonly type: "number";
                    readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
                };
                readonly details: {
                    readonly type: "object (JSON document)";
                    readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
                };
            };
        };
        readonly entitySubtypes: {
            readonly Person: {
                readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly gender: {
                        readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                        readonly required: false;
                    };
                    readonly nationality: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 120 chars";
                    };
                    readonly photoUrl: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly privacyConsent: {
                        readonly type: "PrivacyConsent | null";
                        readonly required: false;
                        readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                        readonly description: "Organizational classification for legal and internal structures.";
                    };
                    readonly parentCompanyId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId for organizational trees.";
                    };
                    readonly externalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ERP/HR/legacy code used by consuming modules.";
                    };
                    readonly tradeName: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "DBA name. Also stored in aliases for full-text search.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly description: "Official registered name.";
                    };
                    readonly legalType: {
                        readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly foundingDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly taxRegime: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
                    };
                    readonly industryCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
                    };
                    readonly website: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly Product: {
                readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly required: false;
                        readonly description: "True when stock is tracked by location.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Service: {
                readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly serviceKind: {
                        readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                        readonly required: false;
                        readonly description: "Use Cohort for a concrete class/offering instance.";
                    };
                    readonly parentServiceId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
                    };
                    readonly serviceType: {
                        readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly durationMinutes: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly deliveryMode: {
                        readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Location: {
                readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
                    };
                    readonly locationCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly parentLocationId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId when this place belongs to a larger place.";
                    };
                    readonly capacity: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly AssetGeneric: {
                readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly manufacturer: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly vin: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly year: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fuelType: {
                        readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Deed number, cadastral reference, or equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly areaSqft: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square feet (primary unit for US).";
                    };
                    readonly areaM2: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square meters (non-US markets).";
                    };
                    readonly propertyType: {
                        readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly taxParcelId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tax parcel / assessor ID (US) or equivalent.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: printer, server, forklift, medical device";
                    };
                    readonly acquisitionDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly Animal: {
                readonly description: "Subtype Animal — pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
                    };
                    readonly breed: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly sex: {
                        readonly type: "'Male' | 'Female' | 'Unknown' | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly microchip: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Breed registry, USDA tag, or official animal ID.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
                readonly fields: {
                    readonly bankRoutingNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ABA routing number (US). Use swift for international.";
                    };
                    readonly bankName: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountType: {
                        readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly swift: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "BIC/SWIFT for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKey: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKeyType: {
                        readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                        readonly required: false;
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly description: "Verified via micro-deposit, open banking, or manual review.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly description: "Module that created this record.";
                        readonly constraints: "Examples: legal, maintenance, hr, finance";
                    };
                    readonly docCategory: {
                        readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly description: "S3 bucket (or equivalent) where the file resides.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly description: "Relative path within the bucket. Immutable after creation.";
                        readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
                    };
                    readonly fileName: {
                        readonly type: "string";
                    };
                    readonly mimeType: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fileSizeKb: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly issuedAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly expiresAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly issuer: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Free text issuing authority name. Not an mdmId.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly ContactChannel: {
                readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly description: "Full contact value. Stored unmasked.";
                        readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
        };
        readonly embeddedTypes: {
            readonly Address: {
                readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
                readonly fields: {
                    readonly type: {
                        readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
                    };
                    readonly label: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Short human label for this address.";
                        readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
                    };
                    readonly line1: {
                        readonly type: "string";
                        readonly description: "Primary address line: street and number, PO Box, or rural route.";
                    };
                    readonly line2: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Secondary line: apartment, suite, floor, unit, building.";
                    };
                    readonly line3: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
                    };
                    readonly city: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly stateOrProvince: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                    };
                    readonly postalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                        readonly constraints: "Default: US";
                    };
                    readonly formatted: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                    };
                    readonly geolocation: {
                        readonly type: "{ lat: number; lng: number } | null";
                        readonly required: false;
                    };
                    readonly isPrimary: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly PrivacyConsent: {
                readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
                readonly fields: {
                    readonly consentedAt: {
                        readonly type: "timestamp";
                    };
                    readonly consentVersion: {
                        readonly type: "string";
                        readonly description: "Version of the privacy policy accepted.";
                    };
                    readonly channel: {
                        readonly type: "string";
                        readonly description: "How consent was obtained.";
                        readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
                    };
                    readonly revokedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                };
            };
            readonly ContactSummary: {
                readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
                readonly fields: {
                    readonly mdmId: {
                        readonly type: "string (uuid)";
                        readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                    };
                    readonly title: {
                        readonly type: "string";
                        readonly description: "Human-readable label for this contact in the context of the parent entity.";
                        readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                    };
                };
            };
            readonly CompactRelationshipRefs: {
                readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
                readonly fields: {
                    readonly ownedAssets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly owners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employees: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly partners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly family: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly pets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly guardians: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly customers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly suppliers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly memberships: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly members: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly bankAccounts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly accountHolders: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly subsidiaries: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly parentCompanies: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locations: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locatedEntities: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly documents: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly signedBy: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contacts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contactOwners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                };
            };
        };
        readonly relationships: {
            readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
            readonly entries: readonly [{
                readonly type: "Owns";
                readonly from: "Person | Company";
                readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
            }, {
                readonly type: "Employs";
                readonly from: "Company";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
            }, {
                readonly type: "OffersProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
            }, {
                readonly type: "OffersService";
                readonly from: "Company | Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
            }, {
                readonly type: "StocksAt";
                readonly from: "Product | AssetEquipment";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
            }, {
                readonly type: "Teaches";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
            }, {
                readonly type: "HappensAt";
                readonly from: "Service";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
            }, {
                readonly type: "FranchiseOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
            }, {
                readonly type: "BelongsToGroup";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"subsidiary-brand\" }";
            }, {
                readonly type: "PartOfUnit";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
            }, {
                readonly type: "ManagedBy";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
            }, {
                readonly type: "ReportsTo";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"direct-report\" }";
            }, {
                readonly type: "AssignedTo";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
            }, {
                readonly type: "Attends";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
            }, {
                readonly type: "SuppliesProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
            }, {
                readonly type: "PartnersWith";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
            }, {
                readonly type: "Family";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: true;
                readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
            }, {
                readonly type: "GuardianOf";
                readonly from: "Person";
                readonly to: "Animal";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
            }, {
                readonly type: "CustomerOf";
                readonly from: "Person | Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
            }, {
                readonly type: "SupplierOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
            }, {
                readonly type: "MemberOf";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
            }, {
                readonly type: "HoldsAccount";
                readonly from: "Person | Company";
                readonly to: "BankAccount";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
            }, {
                readonly type: "SubsidiaryOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
            }, {
                readonly type: "LocatedAt";
                readonly from: "Person | Company";
                readonly to: "AssetProperty";
                readonly bidirectional: false;
                readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
            }, {
                readonly type: "Signed";
                readonly from: "Person | Company";
                readonly to: "Document";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
            }, {
                readonly type: "HasContact";
                readonly from: "any";
                readonly to: "ContactChannel";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true }";
            }];
        };
    };
}
declare module "_102034_/l1/mdm/module" {
    import type { DocType, MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    export type AddressType = 'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other';
    export type RelationshipStatus = 'Active' | 'Inactive' | 'PendingConfirmation';
    export interface AddressValue {
        type: AddressType;
        label?: string | null;
        line1: string;
        line2?: string | null;
        line3?: string | null;
        city?: string | null;
        stateOrProvince?: string | null;
        postalCode?: string | null;
        countryCode: string;
        formatted?: string | null;
        geolocation?: {
            lat: number;
            lng: number;
        } | null;
        isPrimary: boolean;
    }
    export interface PrivacyConsentValue {
        consentedAt: string;
        consentVersion: string;
        channel: string;
        revokedAt?: string | null;
        notes?: string | null;
    }
    export interface ContactSummaryValue {
        mdmId: string;
        title: string;
    }
    export type CompanyKind = 'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg';
    export type ServiceKind = 'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType';
    export type MdmModuleNamespaceValue = Record<string, unknown>;
    export type CompactRelationshipRefKey = 'ownedAssets' | 'owners' | 'employees' | 'employers' | 'offeredProducts' | 'productSuppliers' | 'offeredServices' | 'serviceProviders' | 'stockLocations' | 'stockedItems' | 'taughtServices' | 'instructors' | 'serviceLocations' | 'scheduledServices' | 'franchisees' | 'franchisors' | 'groupParents' | 'groupMembers' | 'unitParents' | 'unitChildren' | 'managedOrganizations' | 'managers' | 'reports' | 'reportManagers' | 'assignments' | 'assignees' | 'attendedServices' | 'attendees' | 'suppliedProducts' | 'productVendors' | 'partners' | 'family' | 'pets' | 'guardians' | 'customers' | 'suppliers' | 'memberships' | 'members' | 'bankAccounts' | 'accountHolders' | 'subsidiaries' | 'parentCompanies' | 'locations' | 'locatedEntities' | 'documents' | 'signedBy' | 'contacts' | 'contactOwners';
    export type CompactRelationshipRefs = Partial<Record<CompactRelationshipRefKey, string[]>>;
    export interface BaseMdmDetailRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        aliases: string[];
        contacts: ContactSummaryValue[];
        relationshipRefs: CompactRelationshipRefs;
        addresses: AddressValue[];
        mergedInto?: string | null;
        createdAt: string;
        updatedAt: string;
        [moduleNamespace: string]: unknown;
    }
    export interface PersonDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Person';
        privacyConsent?: PrivacyConsentValue | null;
        birthDate?: string | null;
        gender?: string | null;
        nationality?: string | null;
        occupation?: string | null;
        photoUrl?: string | null;
        notes?: string | null;
    }
    export interface CompanyDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Company';
        companyKind: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        legalName: string;
        tradeName?: string | null;
        legalType?: string | null;
        foundingDate?: string | null;
        taxRegime?: string | null;
        industryCode?: string | null;
        website?: string | null;
        notes?: string | null;
    }
    export interface ProductDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Product';
        sku?: string | null;
        productType?: string | null;
        category?: string | null;
        brand?: string | null;
        unitOfMeasure?: string | null;
        isInventoried?: boolean;
        notes?: string | null;
    }
    export interface ServiceDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Service';
        serviceCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        serviceType?: string | null;
        durationMinutes?: number | null;
        deliveryMode?: string | null;
        notes?: string | null;
    }
    export interface LocationDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Location';
        locationType: string;
        locationCode?: string | null;
        parentLocationId?: string | null;
        capacity?: number | null;
        propertyAddress?: AddressValue | null;
        notes?: string | null;
    }
    export interface AssetGenericDetailRecord extends BaseMdmDetailRecord {
        subtype: 'AssetGeneric';
        assetCategory?: string | null;
        serialNumber?: string | null;
        manufacturer?: string | null;
        model?: string | null;
        notes?: string | null;
    }
    export interface ContactChannelDetailRecord extends BaseMdmDetailRecord {
        subtype: 'ContactChannel';
        contactType: string;
        value: string;
        isVerified?: boolean;
        verifiedAt?: string | null;
        notes?: string | null;
    }
    export interface DocumentDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Document';
        storageBucket: string;
        storagePath: string;
        originModule: string;
        docCategory: string;
        fileName: string;
        mimeType?: string | null;
        notes?: string | null;
    }
    export interface BankAccountDetailRecord extends BaseMdmDetailRecord {
        subtype: 'BankAccount';
        bankRoutingNumber?: string | null;
        bankName?: string | null;
        accountNumber?: string | null;
        accountType?: string | null;
        swift?: string | null;
        iban?: string | null;
        pixKey?: string | null;
        pixKeyType?: string | null;
        isVerified?: boolean;
        notes?: string | null;
    }
    export interface ProspectLifecycleFields {
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
    }
    export interface GenericMdmDetailRecord extends BaseMdmDetailRecord, ProspectLifecycleFields {
        subtype: 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel' | 'Person' | 'Company';
        legalName?: string;
        companyKind?: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    }
    export type MdmDetailRecord = (PersonDetailRecord & ProspectLifecycleFields) | (CompanyDetailRecord & ProspectLifecycleFields) | (ProductDetailRecord & ProspectLifecycleFields) | (ServiceDetailRecord & ProspectLifecycleFields) | (LocationDetailRecord & ProspectLifecycleFields) | (AssetGenericDetailRecord & ProspectLifecycleFields) | (ContactChannelDetailRecord & ProspectLifecycleFields) | (DocumentDetailRecord & ProspectLifecycleFields) | (BankAccountDetailRecord & ProspectLifecycleFields) | GenericMdmDetailRecord;
    export type CreateableMdmDetailInput = {
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode?: string;
        tags?: string[];
        aliases?: string[];
        contacts?: ContactSummaryValue[];
        relationshipRefs?: CompactRelationshipRefs;
        addresses?: AddressValue[];
        mergedInto?: string | null;
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        legalName?: string;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    };
    export interface MdmDocumentRecord {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }
    export interface MdmEntityIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        searchVector: string;
        mergedInto?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmProspectIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        promotionSource: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipRecord {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        isBidirectional: boolean;
        validFrom: string;
        validTo?: string | null;
        status: RelationshipStatus;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipDocumentRecord extends MdmRelationshipRecord {
        scope: 'entity' | 'prospect';
    }
    export type MdmAuditAction = 'create' | 'update' | 'delete' | 'restore' | 'transitionStatus';
    export type MdmActorType = 'user' | 'agent' | 'system';
    export type MdmAuditDiffType = 'CHANGE' | 'CREATE' | 'REMOVE';
    export interface MdmAuditDiffEntry {
        type: MdmAuditDiffType;
        path: Array<string | number>;
        oldValue?: unknown;
        value?: unknown;
    }
    export interface MdmAuditLogIndexRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: MdmAuditAction;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        createdAt: string;
    }
    export interface MdmAuditLogDocumentRecord extends MdmAuditLogIndexRecord {
        diff: MdmAuditDiffEntry[] | null;
    }
    export interface MdmMonitoringWriteRecord {
        id: string;
        entityType: string;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        success: boolean;
        durationMs: number;
        startedAt: string;
        finishedAt: string;
        actorType: MdmActorType;
        source: 'http' | 'message' | 'test' | 'system';
        errorCode?: string | null;
    }
    export interface MdmErrorLogRecord {
        id: string;
        entityType?: string | null;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        errorCode: string;
        message: string;
        details?: Record<string, unknown> | null;
        stack?: string | null;
        createdAt: string;
    }
    export interface MdmStatusHistoryRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface MdmTagRecord {
        id: string;
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy: string;
        createdByType: MdmActorType;
        createdAt: string;
    }
    export interface MdmCommentRecord {
        id: string;
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        authorId: string;
        authorType: MdmActorType;
        module: string;
        isSystemGenerated: boolean;
        editedAt?: string | null;
        deletedAt?: string | null;
        createdAt: string;
    }
    export interface MdmAttachmentRecord {
        id: string;
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy: string;
        uploadedAt: string;
        deletedAt?: string | null;
        details?: Record<string, unknown> | null;
    }
    export type NumberSequenceScopeType = 'global' | 'company' | 'branch';
    export interface MdmNumberSequenceRecord {
        id: string;
        sequenceKey: string;
        prefix?: string | null;
        currentValue: number;
        increment: number;
        padding?: number | null;
        yearSegment: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        lastIssuedAt: string;
        createdAt: string;
        details?: Record<string, unknown> | null;
    }
    export interface MdmKvRecord {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface MdmOutboxRecord {
        id: string;
        topic: string;
        aggregateType: 'MdmDocument' | 'MdmRelationship' | 'MdmAuditLog' | 'MdmTag' | 'MdmComment' | 'MdmAttachment' | 'MdmNumberSequence' | 'RegistryTable';
        aggregateId: string;
        eventType: 'UpsertDocument' | 'DeleteDocument' | 'UpsertRelationship' | 'DeleteRelationship' | 'UpsertAuditLog' | 'UpsertTag' | 'UpsertComment' | 'UpsertAttachment' | 'UpsertNumberSequence' | 'UpsertRegistryTableRecord' | 'DeleteRegistryTableRecord';
        payload: Record<string, unknown>;
        attemptCount: number;
        processedAt?: string | null;
        lastError?: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface CreateRecordParams<TDetail extends CreateableMdmDetailInput = CreateableMdmDetailInput> {
        detail: TDetail;
    }
    export interface UpdateRecordParams {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface ListRecordsParams {
        subtype?: MdmSubtype;
        status?: string;
        countryCode?: string;
        limit?: number;
        orderBy?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface PromoteProspectParams {
        mdmId: string;
    }
    export interface MergeEntityParams {
        winnerMdmId: string;
        loserMdmId: string;
    }
    export interface CreateRelationshipParams {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface UpdateRelationshipParams {
        id: string;
        patch: Partial<Pick<MdmRelationshipRecord, 'role' | 'metadata' | 'validFrom' | 'validTo' | 'status'>>;
    }
    export interface ListRelationshipsParams {
        entityId?: string;
        scope?: 'entity' | 'prospect' | 'all';
        status?: RelationshipStatus;
        type?: RelationshipType;
    }
    export interface SearchParams {
        query?: string;
        subtype?: MdmSubtype;
        status?: string;
        scope?: 'entity' | 'prospect' | 'all';
        limit?: number;
    }
    export interface AddTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy?: string;
        createdByType?: MdmActorType;
    }
    export interface RemoveTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        module: string;
    }
    export interface FindTagsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface FindTagsByTagParams {
        entityType: string;
        tag: string;
        module?: string;
        namespace?: string | null;
    }
    export interface AddCommentParams {
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        module: string;
        authorId?: string;
        authorType?: MdmActorType;
        isSystemGenerated?: boolean;
    }
    export interface EditCommentParams {
        id: string;
        text: string;
        editorId?: string;
    }
    export interface RemoveCommentParams {
        id: string;
    }
    export interface FindCommentsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface AttachFileParams {
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy?: string;
        details?: Record<string, unknown> | null;
    }
    export interface DetachFileParams {
        id: string;
    }
    export interface FindAttachmentsByEntityParams {
        entityType: string;
        entityId: string;
        category?: string | null;
    }
    export interface NumberSequenceNextParams {
        sequenceKey: string;
        prefix?: string | null;
        increment?: number;
        padding?: number | null;
        yearSegment?: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        details?: Record<string, unknown> | null;
    }
    export interface GetMdmKvParams {
        key: string;
    }
    export interface PutMdmKvParams {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface FindStatusHistoryByEntityParams {
        entityType: string;
        entityId: string;
        limit?: number;
    }
    export interface FindLatestStatusByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface RecordDetailResponse {
        index: MdmEntityIndexRecord | MdmProspectIndexRecord;
        document: MdmDocumentRecord;
        details: MdmDetailRecord;
    }
    export type ModuleIdStrategy = 'uuidv7';
    export type ModuleLocalStore = 'postgres';
    export type ModuleRemoteStore = 'dynamodb';
    export type ModuleWriteMode = 'sync' | 'writeBehind';
    export interface ModulePersistenceConfig {
        idStrategy: ModuleIdStrategy;
        localStore: ModuleLocalStore;
        remoteStore: ModuleRemoteStore;
        writeMode: ModuleWriteMode;
        remoteSourceOfTruth: boolean;
        restoreLocalFromRemote: boolean;
    }
    export interface ModuleConfig {
        moduleId: 'mdm';
        persistence: ModulePersistenceConfig;
    }
    export interface EntityDef<TDetail, TIndex> {
        entityType: string;
        moduleName: string;
        getIndexRuntime(runtime: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime): import("_102034_/l1/server/layer_1_external/data/runtime").ITableRuntime<TIndex>;
        buildIndex(detail: TDetail): TIndex;
        toDocument(detail: TDetail, version: number): MdmDocumentRecord;
        getId(detail: TDetail): string;
        getAuditSnapshot(detail: TDetail, index: TIndex): Record<string, unknown>;
    }
    export const moduleConfig: ModuleConfig;
}
declare module "_102034_/l1/server/layer_1_external/data/postgres/pg" {
    import { Pool, type PoolClient } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function getSharedPgPool(env: AppEnv): Pool;
    export function withPgTransaction<TValue>(pool: Pool, callback: (client: PoolClient) => Promise<TValue>): Promise<TValue>;
    export function queryRows<TRow>(client: Pool | PoolClient, sql: string, params?: unknown[]): Promise<TRow[]>;
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/server/layer_1_external/config/projectConfig" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: Array<{
            id: string;
            label: string;
            href: string;
            description?: string;
        }>;
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        backendRouter?: string;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    export function readProjectsConfig(): ProjectsConfig;
    export function resetProjectsConfigCache(): void;
    export function resolveProjectsPath(relativePath: string): string;
    export function resolveProjectDistPath(relativePath: string): string;
    export function getPublicationTarget(targetName?: string): {
        assetBaseUrl: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
        name: string;
    };
    export function resolvePublicationDistPath(targetName: string, relativePath?: string): string;
    export function resolveActivePublicationDistPath(relativePath?: string): string;
    export function toPublishedAssetUrl(relativePath: string, targetName?: string): string;
    export function resolveProjectModuleImportUrl(relativePath: string): string;
}
declare module "_102034_/l1/server/layer_1_external/persistence/registry" {
    import type { ResolvedTableDefinition, SchemaSnapshot } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function loadResolvedTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function resetResolvedTableDefinitionsCache(): void;
    export function loadResolvedPostgresTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function loadResolvedDynamoTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function buildSchemaSnapshot(env: Pick<AppEnv, 'appEnv'>): Promise<SchemaSnapshot>;
    export function findResolvedTableDefinition(repositoryNameOrTableName: string, env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition>;
}
declare module "_102034_/l1/server/layer_1_external/data/moduleDataRuntime" {
    import type { Pool, PoolClient } from 'pg';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    type PgExecutor = Pool | PoolClient;
    export interface IFindManyInput<TWhere> {
        where?: Partial<TWhere>;
        orderBy?: {
            field: keyof TWhere;
            direction: 'asc' | 'desc';
        };
        limit?: number;
    }
    export interface ITableRepository<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        upsert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRepository<TDocument> {
        get(input: {
            key: Record<string, unknown>;
        }): Promise<TDocument | null>;
        put(input: {
            document: TDocument;
        }): Promise<void>;
        delete(input: {
            key: Record<string, unknown>;
        }): Promise<void>;
        scanAll(): Promise<TDocument[]>;
    }
    export interface IModuleDataRuntime {
        getTable<TRecord extends object>(repositoryNameOrTableName: string): Promise<ITableRepository<TRecord>>;
        listTables(): Promise<ResolvedTableDefinition[]>;
        runInTransaction<TValue>(callback: (runtime: IModuleDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
    export function createMemoryModuleDataRuntime(env: AppEnv): IModuleDataRuntime;
    export function createPostgresModuleDataRuntime(env: AppEnv, executor?: PgExecutor): IModuleDataRuntime;
}
declare module "_102034_/l1/server/layer_1_external/data/runtime" {
    import type { MdmAuditLogIndexRecord, MdmAttachmentRecord, MdmCommentRecord, MdmDocumentRecord, MdmErrorLogRecord, MdmEntityIndexRecord, MdmMonitoringWriteRecord, MdmNumberSequenceRecord, MdmOutboxRecord, MdmProspectIndexRecord, MdmRelationshipRecord, MdmStatusHistoryRecord, MdmTagRecord } from "_102034_/l1/mdm/module";
    import type { IFindManyInput, IModuleDataRuntime } from "_102034_/l1/server/layer_1_external/data/moduleDataRuntime";
    export interface ITableRuntime<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRuntime {
        get(input: {
            mdmId: string;
        }): Promise<MdmDocumentRecord | null>;
        getMany(input: {
            mdmIds: string[];
        }): Promise<MdmDocumentRecord[]>;
        put(input: {
            record: MdmDocumentRecord;
            expectedVersion?: number | null;
        }): Promise<void>;
        delete(input: {
            mdmId: string;
        }): Promise<void>;
    }
    export interface IQueueRuntime {
        publish(input: {
            topic: string;
            payload: unknown;
        }): Promise<void>;
        list(input?: {
            topic?: string;
        }): Promise<Array<{
            topic: string;
            payload: unknown;
        }>>;
    }
    export interface IDataRuntime {
        mode: 'memory' | 'postgres';
        mdmDocument: IDocumentRuntime;
        mdmEntityIndex: ITableRuntime<MdmEntityIndexRecord>;
        mdmProspectIndex: ITableRuntime<MdmProspectIndexRecord>;
        mdmRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmProspectRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmAuditLog: ITableRuntime<MdmAuditLogIndexRecord>;
        mdmComment: ITableRuntime<MdmCommentRecord>;
        mdmAttachment: ITableRuntime<MdmAttachmentRecord>;
        mdmNumberSequence: ITableRuntime<MdmNumberSequenceRecord>;
        mdmMonitoringWrite: ITableRuntime<MdmMonitoringWriteRecord>;
        mdmErrorLog: ITableRuntime<MdmErrorLogRecord>;
        mdmStatusHistory: ITableRuntime<MdmStatusHistoryRecord>;
        mdmTag: ITableRuntime<MdmTagRecord>;
        mdmOutbox: ITableRuntime<MdmOutboxRecord>;
        pgQueue: IQueueRuntime;
        moduleData: IModuleDataRuntime;
        runInTransaction<TValue>(callback: (runtime: IDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
}
declare module "_102034_/l1/server/layer_2_controllers/contracts" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export interface BffRequest {
        routine: string;
        params: unknown;
        meta?: {
            requestId?: string;
            userId?: string;
            authToken?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
        };
    }
    export type ShellMode = 'spa' | 'pwa';
    export type DeviceKind = 'desktop' | 'mobile';
    export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface FrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface FrontendAppLayout {
        regions: {
            desktop: FrontendRegionVisibility;
            mobile: FrontendRegionVisibility;
        };
        asideMode: {
            desktop: FrontendAsideMode;
            mobile: FrontendAsideMode;
        };
    }
    export interface FrontendRegionRendererRegistration {
        entrypoint: string;
        tag: string;
    }
    export type FrontendRouteMatchMode = 'exact' | 'prefix';
    export interface FrontendRouteRegistration {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: FrontendRouteMatchMode;
    }
    export interface FrontendModuleShellPreferences {
        layout?: Partial<FrontendAppLayout>;
    }
    export interface FrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface BffError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface BffResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: BffError | null;
    }
    export interface ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
    export interface IClock {
        nowIso(): string;
    }
    export interface IIdGenerator {
        newId(): string;
    }
    export interface RequestContext {
        data: IDataRuntime;
        log: ILogger;
        clock: IClock;
        idGenerator: IIdGenerator;
        requestMeta?: {
            requestId?: string;
            userId?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
        };
    }
    export interface IRequestEnvelope {
        request: BffRequest;
        ctx: RequestContext;
    }
    export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;
    export interface ModuleBffRegistration {
        projectId: string;
        moduleId: string;
        frontendBasePath: string;
        frontendEntrypoint: string;
        loadRouter: () => Promise<Map<string, BffHandler>>;
    }
    export interface FrontendAppRegistration {
        projectId: string;
        appId: string;
        basePath: string;
        indexHtmlPath: string;
        assetRoots: string[];
        routePatterns: string[];
        shellMode: ShellMode;
        routes: FrontendRouteRegistration[];
        headerRenderer?: FrontendRegionRendererRegistration;
        asideRenderer?: FrontendRegionRendererRegistration;
        layout: FrontendAppLayout;
        device?: DeviceKind;
        pageTitle?: string;
        navigation?: FrontendNavigationItem[];
        moduleLinks?: FrontendNavigationItem[];
    }
    export interface RoutineResolution {
        moduleId: string;
        routineName: string;
        registration: ModuleBffRegistration;
    }
    export class AppError extends Error {
        readonly code: string;
        readonly statusCode: number;
        readonly details?: unknown;
        constructor(code: string, message: string, statusCode?: number, details?: unknown);
    }
    export function ok<TData>(data: TData): BffResponse<TData>;
    export function fail(error: AppError): BffResponse;
}
declare module "_102035_/l1/locadora/layer_2_controllers/mock" {
    export const USE_MOCK = true;
    export function getMockVeiculoRepository(): {
        findMany(): Promise<any[]>;
        findOne({ where }: {
            where: Record<string, any>;
        }): Promise<any>;
        upsert({ record }: {
            record: any;
        }): Promise<void>;
    };
    export function getMockClienteRepository(): {
        findMany(): Promise<any[]>;
        findOne({ where }: {
            where: Record<string, any>;
        }): Promise<any>;
        upsert({ record }: {
            record: any;
        }): Promise<void>;
    };
    export function getMockLocacaoRepository(): {
        findMany(): Promise<any[]>;
        findOne({ where }: {
            where: Record<string, any>;
        }): Promise<any>;
        upsert({ record }: {
            record: any;
        }): Promise<void>;
    };
    export function getMockUsuarioAdminRepository(): {
        findMany(): Promise<any[]>;
        findOne({ where }: {
            where: Record<string, any>;
        }): Promise<any>;
        upsert({ record }: {
            record: any;
        }): Promise<void>;
    };
}
declare module "_102035_/l1/locadora/layer_2_controllers/adminDashboard" {
    import { LocadoraClienteResponse, LocadoraLocacaoResponse, LocadoraVeiculoResponse } from "_102035_/l2/locadora/web/contracts/adminDashboard";
    import { type BffHandler, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function getQuickAccess(ctx: RequestContext, input?: {}): Promise<{}>;
    export function getSummary(ctx: RequestContext, input?: {}): Promise<{
        veiculos: LocadoraVeiculoResponse[];
        clientes: LocadoraClienteResponse[];
        locacoes: LocadoraLocacaoResponse[];
    }>;
    export const adminDashboardGetQuickAccessHandler: BffHandler;
    export const adminDashboardGetSummaryHandler: BffHandler;
}
declare module "_102035_/l2/locadora/web/contracts/clientesCadastro" {
    export interface LocadoraClienteResponse {
        nome: string;
        cpf: string;
        cnh: string;
        telefone: string;
        email: string;
    }
    export interface LocadoraUpdateClienteRequest {
        nome: string;
        cpf?: string;
        cnh?: string;
        telefone?: string;
        email?: string;
        author?: string;
    }
}
declare module "_102035_/l1/locadora/layer_2_controllers/clientesCadastro" {
    import { LocadoraClienteResponse, LocadoraUpdateClienteRequest } from "_102035_/l2/locadora/web/contracts/clientesCadastro";
    import { type BffHandler, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function save(ctx: RequestContext, input: LocadoraUpdateClienteRequest): Promise<LocadoraClienteResponse>;
    export function cancel(ctx: RequestContext, input: LocadoraUpdateClienteRequest): Promise<LocadoraClienteResponse>;
    export function validate(ctx: RequestContext, input: LocadoraUpdateClienteRequest): Promise<LocadoraClienteResponse>;
    export const clientesCadastroSaveHandler: BffHandler;
    export const clientesCadastroCancelHandler: BffHandler;
    export const clientesCadastroValidateHandler: BffHandler;
}
declare module "_102035_/l2/locadora/web/contracts/clientesLista" {
    export interface LocadoraClienteResponse {
        nome: string;
        cpf: string;
        cnh: string;
        telefone: string;
        email: string;
    }
    export interface LocadoraUpdateClienteRequest {
        nome: string;
        cpf?: string;
        cnh?: string;
        telefone?: string;
        email?: string;
        author?: string;
    }
}
declare module "_102035_/l1/locadora/layer_2_controllers/clientesLista" {
    import { LocadoraClienteResponse } from "_102035_/l2/locadora/web/contracts/clientesLista";
    import { type BffHandler, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function listarClientes(ctx: RequestContext, input?: {
        nome?: string;
        cpf?: string;
        cnh?: string;
        telefone?: string;
        email?: string;
        statusValidacao?: string;
        page?: number;
        pageSize?: number;
        sortBy?: string;
        sortDir?: string;
    }): Promise<LocadoraClienteResponse[]>;
    export const clientesListaListarClientesHandler: BffHandler;
}
declare module "_102035_/l2/locadora/web/contracts/locacoesCadastro" {
    export interface LocadoraVeiculoResponse {
        placa: string;
        modelo: string;
        ano: number;
        categoria: string;
        status: 'disponível' | 'locado' | 'manutenção';
        quilometragem: number;
    }
    export interface LocadoraUpdateVeiculoRequest {
        placa: string;
        modelo?: string;
        ano?: number;
        categoria?: string;
        status?: LocadoraVeiculoResponse['status'];
        quilometragem?: number;
        author?: string;
    }
    export interface LocadoraClienteResponse {
        nome: string;
        cpf: string;
        cnh: string;
        telefone: string;
        email: string;
    }
    export interface LocadoraUpdateClienteRequest {
        nome: string;
        cpf?: string;
        cnh?: string;
        telefone?: string;
        email?: string;
        author?: string;
    }
    export interface LocadoraLocacaoResponse {
        dataRetirada: string;
        dataDevolucao: string;
        valorDiario: number;
        seguroOpcional?: boolean;
        formaPagamento: string;
        devolucaoPrevista: string;
        placaVeiculo: string;
        cpf: string;
    }
    export interface LocadoraUpdateLocacaoRequest {
        dataRetirada: string;
        dataDevolucao?: string;
        valorDiario?: number;
        seguroOpcional?: boolean;
        formaPagamento?: string;
        devolucaoPrevista?: string;
        placaVeiculo?: string;
        cpf: string;
        author?: string;
    }
}
declare module "_102035_/l1/locadora/layer_2_controllers/locacoesCadastro" {
    import { LocadoraClienteResponse, LocadoraLocacaoResponse, LocadoraUpdateLocacaoRequest, LocadoraUpdateVeiculoRequest, LocadoraVeiculoResponse } from "_102035_/l2/locadora/web/contracts/locacoesCadastro";
    import { type BffHandler, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createLocacao(ctx: RequestContext, input?: {}): Promise<LocadoraLocacaoResponse[]>;
    export function validateCliente(ctx: RequestContext, input?: {
        clienteId?: string;
    }): Promise<LocadoraClienteResponse[]>;
    export function checkVeiculoAvailability(ctx: RequestContext, input?: {
        placa?: string;
    }): Promise<LocadoraVeiculoResponse[]>;
    export function save(ctx: RequestContext, input?: LocadoraUpdateLocacaoRequest): Promise<LocadoraLocacaoResponse>;
    export function checkVeiculo(ctx: RequestContext, input?: LocadoraUpdateVeiculoRequest): Promise<LocadoraVeiculoResponse>;
    export function cancel(ctx: RequestContext, input?: LocadoraUpdateLocacaoRequest): Promise<LocadoraLocacaoResponse>;
    export const locacoesCadastroCreateLocacaoHandler: BffHandler;
    export const locacoesCadastroValidateClienteHandler: BffHandler;
    export const locacoesCadastroCheckVeiculoAvailabilityHandler: BffHandler;
    export const locacoesCadastroSaveHandler: BffHandler;
    export const locacoesCadastroCheckVeiculoHandler: BffHandler;
    export const locacoesCadastroCancelHandler: BffHandler;
}
declare module "_102035_/l2/locadora/web/contracts/locacoesLista" {
    export interface LocadoraLocacaoResponse {
        dataRetirada: string;
        dataDevolucao: string;
        valorDiario: number;
        seguroOpcional?: boolean;
        formaPagamento: string;
        devolucaoPrevista: string;
        placaVeiculo: string;
        cpf: string;
    }
    export interface LocadoraUpdateLocacaoRequest {
        dataRetirada: LocadoraLocacaoResponse["dataRetirada"];
        dataDevolucao?: LocadoraLocacaoResponse["dataDevolucao"];
        valorDiario?: LocadoraLocacaoResponse["valorDiario"];
        seguroOpcional?: LocadoraLocacaoResponse["seguroOpcional"];
        formaPagamento?: LocadoraLocacaoResponse["formaPagamento"];
        devolucaoPrevista?: LocadoraLocacaoResponse["devolucaoPrevista"];
        placaVeiculo?: LocadoraLocacaoResponse["placaVeiculo"];
        cpf: LocadoraLocacaoResponse["cpf"];
        author?: string;
    }
}
declare module "_102035_/l1/locadora/layer_2_controllers/locacoesLista" {
    import { LocadoraLocacaoResponse } from "_102035_/l2/locadora/web/contracts/locacoesLista";
    import { type BffHandler, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function listLocacoes(ctx: RequestContext, input?: {
        placaVeiculo?: string;
        dataRetiradaInicio?: string;
        dataRetiradaFim?: string;
        devolucaoPrevistaInicio?: string;
        devolucaoPrevistaFim?: string;
        formaPagamento?: string;
    }): Promise<LocadoraLocacaoResponse[]>;
    export const locacoesListaListLocacoesHandler: BffHandler;
}
declare module "_102035_/l2/locadora/web/contracts/veiculosCadastro" {
    export interface LocadoraVeiculoResponse {
        placa: string;
        modelo: string;
        ano: number;
        categoria: string;
        status: 'disponível' | 'locado' | 'manutenção';
        quilometragem: number;
    }
    export interface LocadoraUpdateVeiculoRequest {
        placa: string;
        modelo?: string;
        ano?: number;
        categoria?: string;
        status?: LocadoraVeiculoResponse['status'];
        quilometragem?: number;
        author?: string;
    }
}
declare module "_102035_/l1/locadora/layer_2_controllers/veiculosCadastro" {
    import { LocadoraUpdateVeiculoRequest, LocadoraVeiculoResponse } from "_102035_/l2/locadora/web/contracts/veiculosCadastro";
    import { type BffHandler, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function getStatusVeiculoOptions(ctx: RequestContext, input?: {}): Promise<LocadoraVeiculoResponse[]>;
    export function saveVeiculo(ctx: RequestContext, input: LocadoraUpdateVeiculoRequest): Promise<LocadoraVeiculoResponse>;
    export function loadStatusOptions(ctx: RequestContext, input: LocadoraUpdateVeiculoRequest): Promise<LocadoraVeiculoResponse>;
    export const veiculosCadastroGetStatusVeiculoOptionsHandler: BffHandler;
    export const veiculosCadastroSaveHandler: BffHandler;
    export const veiculosCadastroLoadStatusOptionsHandler: BffHandler;
}
declare module "_102035_/l2/locadora/web/contracts/veiculosLista" {
    export interface LocadoraVeiculoResponse {
        placa: string;
        modelo: string;
        ano: number;
        categoria: string;
        status: 'disponível' | 'locado' | 'manutenção';
        quilometragem: number;
    }
    export interface LocadoraUpdateVeiculoRequest {
        placa: string;
        modelo?: string;
        ano?: number;
        categoria?: string;
        status?: LocadoraVeiculoResponse['status'];
        quilometragem?: number;
        author?: string;
    }
}
declare module "_102035_/l1/locadora/layer_2_controllers/veiculosLista" {
    import { LocadoraVeiculoResponse } from "_102035_/l2/locadora/web/contracts/veiculosLista";
    import { type BffHandler, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function listVeiculos(ctx: RequestContext, input?: {
        status?: string;
    }): Promise<LocadoraVeiculoResponse[]>;
    export const veiculosListaListVeiculosHandler: BffHandler;
}
declare module "_102035_/l1/locadora/layer_2_controllers/router" {
    import type { BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createPizzariaRouter(): Map<string, BffHandler>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102035_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102035_/l2/project" {
    export const projectConfig: {
        modules: {
            name: string;
            path: string;
            auth: string;
        }[];
        layouts: {
            1: {
                name: string;
                skill: string;
            };
        };
        designSystems: {
            1: {
                name: string;
                skill: string;
            };
        };
    };
}
declare module "_102035_/l2/locadora/adminDashboard.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
        visualStyle: string;
    };
    export const definitionPage: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: {
                sectionName: string;
                mode: string;
                organisms: ({
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: any[];
                        params: any[];
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: any[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: any[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                    }[];
                } | {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: {
                            entity: string;
                            entityField: string;
                            priority: string;
                            usage: string;
                            nestedCollection: {
                                stateKeySuffix: string;
                                itemFields: {
                                    entity: string;
                                    entityField: string;
                                    priority: string;
                                    usage: string;
                                }[];
                            };
                        }[];
                        params: any[];
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: any[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                })[];
            }[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue: string;
            }[];
        }[];
    };
    export const contractSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/adminDashboard.defs.ts).definitionPage]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l2/locadora/module.defs.ts)]]\n```\n";
    export const sharedSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/adminDashboard.defs.ts).definitionPage]]\n```\n\n## Contracts\n```JSON\n    [[(_102035_/l2/locadora/web/contracts/adminDashboard.ts)]]\n```\n\n";
    export const desktopLayoutSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/adminDashboard.defs.ts).definitionPage]]\n```\n\n## Base Class\n```JSON\n    [[(_102035_/l2/locadora/web/shared/adminDashboard.ts)]]\n```\n";
    export const materializeIndex: ({
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        specVar: string;
        outputPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102035_/l2/locadora/adminLogin.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
        visualStyle: string;
    };
}
declare module "_102035_/l2/locadora/clientesCadastro.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
        visualStyle: string;
    };
    export const definitionPage: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: {
                sectionName: string;
                mode: string;
                organisms: {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        entityFields: {
                            entity: string;
                            entityField: string;
                            stateKey: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                }[];
            }[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue: string;
            }[];
        }[];
    };
    export const contractSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/clientesCadastro.defs.ts).definitionPage]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l2/locadora/module.defs.ts)]]\n```\n";
    export const sharedSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/clientesCadastro.defs.ts).definitionPage]]\n```\n\n## Contracts\n```JSON\n    [[(_102035_/l2/locadora/web/contracts/clientesCadastro.ts)]]\n```\n\n";
    export const desktopLayoutSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/clientesCadastro.defs.ts).definitionPage]]\n```\n\n## Base Class\n```JSON\n    [[(_102035_/l2/locadora/web/shared/clientesCadastro.ts)]]\n```\n";
    export const materializeIndex: ({
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        specVar: string;
        outputPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102035_/l2/locadora/clientesLista.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
        visualStyle: string;
    };
    export const definitionPage: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: {
                sectionName: string;
                mode: string;
                organisms: ({
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        itemFields: {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        params: {
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                stateKey: string;
                            };
                        }[];
                        editable: boolean;
                        entityFields?: undefined;
                    };
                    tempStates: ({
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue?: undefined;
                    } | {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    })[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                } | {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        entityFields: {
                            entity: string;
                            entityField: string;
                            stateKey: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        stateKey?: undefined;
                        sourceRoutine?: undefined;
                        itemFields?: undefined;
                        params?: undefined;
                        editable?: undefined;
                    };
                    tempStates: ({
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue?: undefined;
                    } | {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    })[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                })[];
            }[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: ({
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue: string;
            } | {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue?: undefined;
            })[];
        }[];
    };
    export const contractSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/clientesLista.defs.ts).definitionPage]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l2/locadora/module.defs.ts)]]\n```\n";
    export const sharedSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/clientesLista.defs.ts).definitionPage]]\n```\n\n## Contracts\n```JSON\n    [[(_102035_/l2/locadora/web/contracts/clientesLista.ts)]]\n```\n\n";
    export const desktopLayoutSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/clientesLista.defs.ts).definitionPage]]\n```\n\n## Base Class\n```JSON\n    [[(_102035_/l2/locadora/web/shared/clientesLista.ts)]]\n```\n";
    export const materializeIndex: ({
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        specVar: string;
        outputPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102029_/l2/contracts/bootstrap" {
    export type AuraShellMode = 'spa' | 'pwa';
    export type AuraDeviceKind = 'desktop' | 'mobile';
    export type AuraAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: AuraDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface AuraRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface AuraLayoutConfig {
        regions: {
            desktop: AuraRegionVisibility;
            mobile: AuraRegionVisibility;
        };
        asideMode: {
            desktop: AuraAsideMode;
            mobile: AuraAsideMode;
        };
    }
    export interface AuraRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export type AuraRouteMatchMode = 'exact' | 'prefix';
    export interface AuraRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: AuraRouteMatchMode;
    }
    export interface AuraModuleFrontendDefinition {
        pageTitle?: string;
        device?: AuraDeviceKind;
        navigation?: AuraNavigationItem[];
        routes: AuraRouteDefinition[];
        headerRenderer?: AuraRegionRendererConfig;
        asideRenderer?: AuraRegionRendererConfig;
    }
    export interface AuraNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface AuraModuleShellPreferences {
        layout?: Partial<AuraLayoutConfig>;
    }
    export interface AuraBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: AuraShellMode;
        device: AuraDeviceKind;
        routes: AuraRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: AuraNavigationItem[];
        moduleLinks?: AuraNavigationItem[];
        layout: AuraLayoutConfig;
    }
    export type AuraInteractionMode = 'blocking' | 'silent';
    export type AuraBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface AuraNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface AuraBlockingErrorState {
        title: string;
        error: AuraNormalizedError;
        canRetry: boolean;
    }
    export interface AuraInteractionState {
        busy: boolean;
        busyPhase: AuraBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: AuraBlockingErrorState;
    }
    global {
        interface Window {
            collabAuraShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
            };
        }
        interface Window {
            collabBoot?: AuraBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabAuraInteractionState?: AuraInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102029_/l2/interactionRuntime" {
    import type { AuraInteractionMode, AuraInteractionState, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: AuraInteractionState) => void;
    interface BlockingActionOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): AuraInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): AuraNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102029_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102029_/l2/shellEvents";
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): any;
    }
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: AuraRouteDefinition[], pathname: string): AuraRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell" {
    import type { AuraBootConfig, AuraDeviceKind, AuraInteractionState, AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: AuraInteractionState;
        resolvedDevice: AuraDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: AuraRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        constructor();
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { AuraInteractionMode, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: AuraNormalizedError | null;
        telemetryReceived?: number;
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102035_/l2/locadora/web/shared/clientesCadastro" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { LocadoraUpdateClienteRequest } from "_102035_/l2/locadora/web/contracts/clientesCadastro";
    const message_en: {
        brand: string;
        pageTitle: string;
        pageSubtitle: string;
        loadingCliente: string;
        couldNotLoad: string;
        reload: string;
        save: string;
        saving: string;
        confirm: string;
        confirming: string;
        couldNotSave: string;
        savedSuccessfully: string;
        couldNotCancel: string;
        cancelledSuccessfully: string;
        couldNotValidate: string;
        validatedSuccessfully: string;
        labelNome: string;
        labelCpf: string;
        labelCnh: string;
        labelTelefone: string;
        labelEmail: string;
        statusReady: string;
    };
    type MessageType = typeof message_en;
    export class LocadoraClientesCadastroBase extends CollabLitElement {
        private readonly _stateKeys;
        nome: string;
        cpf: string;
        cnh: string;
        telefone: string;
        email: string;
        cpfMask: string;
        cnhMask: string;
        formDirty: boolean;
        showValidationHint: boolean;
        activeTab: string;
        save: 'idle' | 'loading' | 'success' | 'error';
        cancel: 'idle' | 'loading' | 'success' | 'error';
        validate: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(_params?: undefined, options?: BffClientOptions): Promise<void>;
        saveCliente(params: LocadoraUpdateClienteRequest, signal?: AbortSignal): Promise<void>;
        handleSaveClienteSubmit(event: SubmitEvent): void;
        cancelCadastro(params?: Record<string, never>, signal?: AbortSignal): Promise<void>;
        handleCancelCadastroClick(): void;
        validateCpfCnh(params: {
            cpf: string;
            cnh: string;
        }, signal?: AbortSignal): Promise<void>;
        handleValidateCpfCnhClick(): void;
    }
}
declare module "_102035_/l2/locadora/web/desktop/page11/clientesCadastro" {
    import { LocadoraClientesCadastroBase } from "_102035_/l2/locadora/web/shared/clientesCadastro";
    export class LocadoraWebDesktopClientesCadastroPage extends LocadoraClientesCadastroBase {
        render(): any;
    }
}
declare module "_102035_/l2/locadora/web/shared/clientesLista" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { LocadoraClienteResponse } from "_102035_/l2/locadora/web/contracts/clientesLista";
    const message_en: {
        brand: string;
        pageTitle: string;
        pageSubtitle: string;
        loadingListarClientes: string;
        couldNotLoad: string;
        itemsAvailable: string;
        reload: string;
        save: string;
        saving: string;
        confirm: string;
        confirming: string;
        nome: string;
        cpf: string;
        cnh: string;
        telefone: string;
        email: string;
        statusValidacao: string;
        page: string;
        pageSize: string;
        sortBy: string;
        sortDir: string;
    };
    type MessageType = typeof message_en;
    export class LocadoraClientesListaBase extends CollabLitElement {
        private readonly _stateKeys;
        cliente: LocadoraClienteResponse[];
        status: string;
        nome: string;
        cpf: string;
        cnh: string;
        telefone: string;
        email: string;
        clienteId: string;
        compact: boolean;
        filterNome: string;
        filterCpf: string;
        filterCnh: string;
        filterTelefone: string;
        filterEmail: string;
        statusValidacao: string;
        page: number;
        pageSize: number;
        by: string;
        dir: string;
        lastPayload: any;
        loadingList: 'idle' | 'loading' | 'success' | 'error';
        loadingSearch: 'idle' | 'loading' | 'success' | 'error';
        error: 'idle' | 'error';
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(_params?: undefined, options?: BffClientOptions): Promise<void>;
        loadListarClientes(params?: {
            nome?: string;
            cpf?: string;
            cnh?: string;
            telefone?: string;
            email?: string;
            statusValidacao?: string;
            page?: number;
            pageSize?: number;
            sortBy?: string;
            sortDir?: string;
        }, options?: BffClientOptions): Promise<void>;
        handleBuscarClick(): void;
        handleLimparFiltrosClick(): void;
    }
}
declare module "_102035_/l2/locadora/web/desktop/page11/clientesLista" {
    import { LocadoraClientesListaBase } from "_102035_/l2/locadora/web/shared/clientesLista";
    export class LocadoraWebDesktopClientesListaPage extends LocadoraClientesListaBase {
        render(): any;
    }
}
declare module "_102035_/l2/locadora/web/shared/veiculosCadastro" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { LocadoraVeiculoResponse } from "_102035_/l2/locadora/web/contracts/veiculosCadastro";
    const message_en: {
        brand: string;
        pageTitle: string;
        pageSubtitle: string;
        loadingStatusOptions: string;
        couldNotLoad: string;
        couldNotSave: string;
        savedSuccessfully: string;
        reload: string;
        save: string;
        saving: string;
        placa: string;
        modelo: string;
        ano: string;
        categoria: string;
        status: string;
        quilometragem: string;
    };
    type MessageType = typeof message_en;
    export class LocadoraVeiculosCadastroBase extends CollabLitElement {
        private readonly _stateKeys;
        placa: string;
        modelo: string;
        ano: number;
        categoria: string;
        statusVeiculo: string;
        quilometragem: number;
        statusVeiculoOptions: {
            values: LocadoraVeiculoResponse['status'][];
        } | undefined;
        formErrors: Record<string, string>;
        formDirty: boolean;
        statusOptions: string[];
        saveVeiculo: 'idle' | 'loading' | 'success' | 'error';
        loadStatusOptions: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(_params?: unknown, options?: BffClientOptions): Promise<void>;
        loadGetStatusVeiculoOptions(_params?: {}, options?: BffClientOptions): Promise<void>;
        saveVeiculoAction(params: LocadoraUpdateVeiculoRequest, signal?: AbortSignal): Promise<void>;
        handleSaveVeiculoSubmit(event: SubmitEvent): void;
    }
    type LocadoraUpdateVeiculoRequest = {
        placa: string;
        modelo?: string;
        ano?: number;
        categoria?: string;
        status?: LocadoraVeiculoResponse['status'];
        quilometragem?: number;
        author?: string;
    };
}
declare module "_102035_/l2/locadora/web/desktop/page11/veiculosCadastro" {
    import { LocadoraVeiculosCadastroBase } from "_102035_/l2/locadora/web/shared/veiculosCadastro";
    export class LocadoraWebDesktopVeiculosCadastroPage extends LocadoraVeiculosCadastroBase {
        render(): any;
    }
}
declare module "_102035_/l2/locadora/web/shared/veiculosLista" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { LocadoraVeiculoResponse } from "_102035_/l2/locadora/web/contracts/veiculosLista";
    const message_en: {
        brand: string;
        pageTitle: string;
        pageSubtitle: string;
        loadingVeiculos: string;
        couldNotLoad: string;
        itemsAvailable: string;
        reload: string;
        filterStatus: string;
        placa: string;
        modelo: string;
        ano: string;
        categoria: string;
        status: string;
        quilometragem: string;
    };
    type MessageType = typeof message_en;
    export class LocadoraVeiculosListaBase extends CollabLitElement {
        private readonly _stateKeys;
        veiculo: LocadoraVeiculoResponse[];
        status: string;
        veiculoStatus: string;
        filterStatus: string;
        sortBy: string;
        loading: 'idle' | 'loading' | 'success' | 'error';
        error: 'idle' | 'error';
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: {
            status?: string;
        }, options?: BffClientOptions): Promise<void>;
        loadListVeiculos(params?: {
            status?: string;
        }, options?: BffClientOptions): Promise<void>;
        handleReloadClick(): void;
    }
}
declare module "_102035_/l2/locadora/web/desktop/page11/veiculosLista" {
    import { LocadoraVeiculosListaBase } from "_102035_/l2/locadora/web/shared/veiculosLista";
    export class LocadoraWebDesktopVeiculosListaPage extends LocadoraVeiculosListaBase {
        render(): any;
    }
}
declare module "_102035_/l2/locadora/web/shared/locacoesLista" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { LocadoraLocacaoResponse } from "_102035_/l2/locadora/web/contracts/locacoesLista";
    const message_en: {
        brand: string;
        pageTitle: string;
        pageSubtitle: string;
        loadingLocacoes: string;
        couldNotLoad: string;
        reload: string;
        filtering: string;
        couldNotFilter: string;
        itemsAvailable: string;
        placaVeiculo: string;
        dataRetiradaInicio: string;
        dataRetiradaFim: string;
        devolucaoPrevistaInicio: string;
        devolucaoPrevistaFim: string;
        formaPagamento: string;
        dataRetirada: string;
        dataDevolucao: string;
        devolucaoPrevista: string;
        valorDiario: string;
        seguroOpcional: string;
        placa: string;
        cpf: string;
    };
    type MessageType = typeof message_en;
    export class LocadoraLocacoesListaBase extends CollabLitElement {
        private readonly _stateKeys;
        locacao: LocadoraLocacaoResponse[];
        status: string;
        placaVeiculo: string;
        dataRetiradaInicio: string;
        dataRetiradaFim: string;
        devolucaoPrevistaInicio: string;
        devolucaoPrevistaFim: string;
        formaPagamento: string;
        selectedLocacaoId: string;
        sortBy: string;
        page: number;
        pageSize: number;
        loadState: 'idle' | 'loading' | 'success' | 'error';
        filteringState: 'idle' | 'loading' | 'success' | 'error';
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(_params?: undefined, options?: BffClientOptions): Promise<void>;
        loadListLocacoes(params?: {
            placaVeiculo?: string;
            dataRetiradaInicio?: string;
            dataRetiradaFim?: string;
            devolucaoPrevistaInicio?: string;
            devolucaoPrevistaFim?: string;
            formaPagamento?: string;
        }, options?: BffClientOptions): Promise<void>;
        filtering(params: {
            placaVeiculo?: string;
            dataRetiradaInicio?: string;
            dataRetiradaFim?: string;
            devolucaoPrevistaInicio?: string;
            devolucaoPrevistaFim?: string;
            formaPagamento?: string;
        }, signal?: AbortSignal): Promise<void>;
        handleFilteringSubmit(event: SubmitEvent): void;
    }
}
declare module "_102035_/l2/locadora/web/desktop/page11/locacoesLista" {
    import { LocadoraLocacoesListaBase } from "_102035_/l2/locadora/web/shared/locacoesLista";
    export class LocadoraWebDesktopLocacoesListaPage extends LocadoraLocacoesListaBase {
        render(): any;
    }
}
declare module "_102035_/l2/locadora/web/shared/locacoesCadastro" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { LocadoraLocacaoResponse, LocadoraClienteResponse, LocadoraVeiculoResponse, LocadoraUpdateLocacaoRequest } from "_102035_/l2/locadora/web/contracts/locacoesCadastro";
    const message_en: {
        brand: string;
        pageTitle: string;
        pageSubtitle: string;
        loadingCreateLocacao: string;
        loadingValidateCliente: string;
        loadingCheckVeiculoAvailability: string;
        couldNotLoad: string;
        couldNotSave: string;
        savedSuccessfully: string;
        reload: string;
        save: string;
        saving: string;
        confirm: string;
        confirming: string;
        labelDataRetirada: string;
        labelDataDevolucao: string;
        labelValorDiario: string;
        labelSeguroOpcional: string;
        labelFormaPagamento: string;
        labelDevolucaoPrevista: string;
        labelPlacaVeiculo: string;
        labelCpf: string;
        labelClienteNome: string;
        labelClienteCpf: string;
        labelClienteCnh: string;
        labelClienteTelefone: string;
        labelClienteEmail: string;
        labelVeiculoPlaca: string;
        labelVeiculoModelo: string;
        labelVeiculoAno: string;
        labelVeiculoCategoria: string;
        labelVeiculoStatus: string;
        labelVeiculoQuilometragem: string;
    };
    type MessageType = typeof message_en;
    export class LocadoraLocacoesCadastroBase extends CollabLitElement {
        private readonly _stateKeys;
        novaLocacao: LocadoraLocacaoResponse | undefined;
        clienteValidacao: LocadoraClienteResponse | undefined;
        veiculoDisponibilidade: LocadoraVeiculoResponse | undefined;
        status: string;
        dataRetirada: string;
        dataDevolucao: string;
        valorDiario: number;
        seguroOpcional: boolean;
        formaPagamento: string;
        devolucaoPrevista: string;
        clienteSelecionado: string;
        veiculoSelecionado: string;
        erroValidacao: string;
        cpfValido: boolean;
        cnhValida: boolean;
        mensagemErro: string;
        disponivel: boolean;
        alertaExibido: boolean;
        mensagemAlerta: string;
        formDirty: boolean;
        confirmacaoAberta: boolean;
        erroGeral: string;
        save: 'idle' | 'loading' | 'success' | 'error';
        validateCliente: 'idle' | 'loading' | 'success' | 'error';
        checkVeiculo: 'idle' | 'loading' | 'success' | 'error';
        cancel: 'idle' | 'confirming' | 'cancelled';
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: {}, options?: BffClientOptions): Promise<void>;
        loadCreateLocacao(params?: {}, options?: BffClientOptions): Promise<void>;
        loadValidateCliente(params?: {
            clienteId?: string;
        }, options?: BffClientOptions): Promise<void>;
        loadCheckVeiculoAvailability(params?: {
            placa?: string;
        }, options?: BffClientOptions): Promise<void>;
        saveLocacao(params: LocadoraUpdateLocacaoRequest, signal?: AbortSignal): Promise<void>;
        handleSaveLocacaoSubmit(event: SubmitEvent): void;
    }
}
declare module "_102035_/l2/locadora/web/desktop/page11/locacoesCadastro" {
    import { LocadoraLocacoesCadastroBase } from "_102035_/l2/locadora/web/shared/locacoesCadastro";
    export class LocadoraWebDesktopLocacoesCadastroPage extends LocadoraLocacoesCadastroBase {
        render(): any;
    }
}
declare module "_102035_/l2/locadora/web/shared/adminDashboard" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    const message_en: {
        brand: string;
        pageTitle: string;
        pageSubtitle: string;
        loadingQuickAccess: string;
        loadingSummary: string;
        couldNotLoad: string;
        reload: string;
        save: string;
        saving: string;
        confirm: string;
        confirming: string;
        itemsAvailable: string;
        fieldHoveredCard: string;
        fieldFilterStatus: string;
    };
    type MessageType = typeof message_en;
    export class LocadoraAdminDashboardBase extends CollabLitElement {
        private readonly _stateKeys;
        quickAccess: any | undefined;
        summary: any | undefined;
        hoveredCard: string;
        filterStatus: string;
        activeSection: string;
        load: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(_params?: undefined, options?: BffClientOptions): Promise<void>;
        loadGetQuickAccess(_params?: Record<string, never>, options?: BffClientOptions): Promise<void>;
        loadGetSummary(_params?: Record<string, never>, options?: BffClientOptions): Promise<void>;
        handleReloadClick(): Promise<void>;
    }
}
declare module "_102035_/l2/locadora/web/desktop/page11/adminDashboard" {
    import { LocadoraAdminDashboardBase } from "_102035_/l2/locadora/web/shared/adminDashboard";
    export class LocadoraWebDesktopAdminDashboardPage extends LocadoraAdminDashboardBase {
        render(): any;
    }
}
declare module "_102035_/l2/locadora/index" { }
declare module "_102035_/l2/locadora/locacoesCadastro.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
        visualStyle: string;
    };
    export const definitionPage: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: {
                sectionName: string;
                mode: string;
                organisms: ({
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        params: any[];
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: any[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                } | {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        params: {
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                stateKey: string;
                            };
                        }[];
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: any[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                    }[];
                })[];
            }[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue: string;
            }[];
        }[];
    };
    export const contractSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/locacoesCadastro.defs.ts).definitionPage]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l2/locadora/module.defs.ts)]]\n```\n";
    export const sharedSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/locacoesCadastro.defs.ts).definitionPage]]\n```\n\n## Contracts\n```JSON\n    [[(_102035_/l2/locadora/web/contracts/locacoesCadastro.ts)]]\n```\n\n";
    export const desktopLayoutSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/locacoesCadastro.defs.ts).definitionPage]]\n```\n\n## Base Class\n```JSON\n    [[(_102035_/l2/locadora/web/shared/locacoesCadastro.ts)]]\n```\n";
    export const materializeIndex: ({
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        specVar: string;
        outputPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102035_/l2/locadora/locacoesLista.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
        visualStyle: string;
    };
    export const definitionPage: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: {
                sectionName: string;
                mode: string;
                organisms: ({
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        itemFields: {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        params: {
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                stateKey: string;
                            };
                        }[];
                        editable: boolean;
                        entityFields?: undefined;
                    };
                    tempStates: ({
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue?: undefined;
                    } | {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    })[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                } | {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        entityFields: {
                            entity: string;
                            entityField: string;
                            stateKey: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        stateKey?: undefined;
                        sourceRoutine?: undefined;
                        itemFields?: undefined;
                        params?: undefined;
                        editable?: undefined;
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                    }[];
                    computedFields: any[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                    }[];
                })[];
            }[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue: string;
            }[];
        }[];
    };
    export const contractSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/locacoesLista.defs.ts).definitionPage]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l2/locadora/module.defs.ts)]]\n```\n";
    export const sharedSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/locacoesLista.defs.ts).definitionPage]]\n```\n\n## Contracts\n```JSON\n    [[(_102035_/l2/locadora/web/contracts/locacoesLista.ts)]]\n```\n\n";
    export const desktopLayoutSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/locacoesLista.defs.ts).definitionPage]]\n```\n\n## Base Class\n```JSON\n    [[(_102035_/l2/locadora/web/shared/locacoesLista.ts)]]\n```\n";
    export const materializeIndex: ({
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        specVar: string;
        outputPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102035_/l2/locadora/module.defs" {
    export const ontology: {
        meta: {
            userLanguage: string;
            moduleName: string;
            userPromptOriginal: string;
            userPromptFinal: string;
        };
        ui: {
            visualStyle: string;
        };
        ontology: {
            entities: {
                veiculo: {
                    description: string;
                    fields: {
                        placa: {
                            type: string;
                            required: boolean;
                        };
                        modelo: {
                            type: string;
                            required: boolean;
                        };
                        ano: {
                            type: string;
                            required: boolean;
                        };
                        categoria: {
                            type: string;
                            required: boolean;
                        };
                        status: {
                            type: string;
                            required: boolean;
                            values: string[];
                        };
                        quilometragem: {
                            type: string;
                            required: boolean;
                        };
                    };
                    rules: string[];
                };
                cliente: {
                    description: string;
                    fields: {
                        nome: {
                            type: string;
                            required: boolean;
                        };
                        cpf: {
                            type: string;
                            required: boolean;
                            constraints: string;
                        };
                        cnh: {
                            type: string;
                            required: boolean;
                            constraints: string;
                        };
                        telefone: {
                            type: string;
                            required: boolean;
                        };
                        email: {
                            type: string;
                            required: boolean;
                        };
                    };
                    rules: string[];
                };
                locacao: {
                    description: string;
                    fields: {
                        dataRetirada: {
                            type: string;
                            required: boolean;
                        };
                        dataDevolucao: {
                            type: string;
                            required: boolean;
                        };
                        valorDiario: {
                            type: string;
                            required: boolean;
                        };
                        seguroOpcional: {
                            type: string;
                            required: boolean;
                        };
                        formaPagamento: {
                            type: string;
                            required: boolean;
                        };
                        devolucaoPrevista: {
                            type: string;
                            required: boolean;
                        };
                        placaVeiculo: {
                            type: string;
                            required: boolean;
                        };
                        cpf: {
                            type: string;
                            required: boolean;
                            constraints: string;
                        };
                    };
                    rules: string[];
                };
                usuarioAdmin: {
                    description: string;
                    fields: {
                        id: {
                            type: string;
                            required: boolean;
                        };
                        usuario: {
                            type: string;
                            required: boolean;
                        };
                        senha: {
                            type: string;
                            required: boolean;
                            constraints: string;
                        };
                    };
                    rules: string[];
                };
            };
        };
        rules: {
            rule_publico_interno: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule_papel_admin_unico: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule_idioma_pt_br: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule_tom_profissional_conciso: {
                kind: string;
                description: string;
                scope: string[];
            };
            rule_frota_campos_obrigatorios: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            rule_cliente_campos_obrigatorios: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            rule_locacao_campos_obrigatorios: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            rule_bloqueio_cliente_cpf_cnh_invalidos: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            rule_cpf_cnh_formato_mascara: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            rule_status_veiculo_valores: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            rule_alerta_veiculo_indisponivel: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
        };
        capabilities: {
            gestaoFrota: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            gestaoClientes: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            gestaoLocacoes: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
        };
    };
}
declare module "_102035_/l2/locadora/module" {
    import type { AuraModuleFrontendDefinition, IPaths, IGenomeConfig } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: Record<string, IGenomeConfig>;
    export const skills: IPaths;
    export const moduleStates: {};
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102035_/l2/locadora/veiculosCadastro.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
        visualStyle: string;
    };
    export const definitionPage: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: {
                sectionName: string;
                mode: string;
                organisms: ({
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        entityFields: {
                            entity: string;
                            entityField: string;
                            stateKey: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        stateKey?: undefined;
                        sourceRoutine?: undefined;
                        fields?: undefined;
                        params?: undefined;
                    };
                    tempStates: ({
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue?: undefined;
                    } | {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    })[];
                    computedFields: any[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                } | {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: {
                            entity: string;
                            entityField: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        params: any[];
                        entityFields?: undefined;
                    };
                    tempStates: any[];
                    computedFields: any[];
                    navigationFields: any[];
                    emits: any[];
                })[];
            }[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue: string;
            }[];
        }[];
    };
    export const contractSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/veiculosCadastro.defs.ts).definitionPage]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l2/locadora/module.defs.ts)]]\n```\n";
    export const sharedSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/veiculosCadastro.defs.ts).definitionPage]]\n```\n\n## Contracts\n```JSON\n    [[(_102035_/l2/locadora/web/contracts/veiculosCadastro.ts)]]\n```\n\n";
    export const desktopLayoutSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/veiculosCadastro.defs.ts).definitionPage]]\n```\n\n## Base Class\n```JSON\n    [[(_102035_/l2/locadora/web/shared/veiculosCadastro.ts)]]\n```\n";
    export const materializeIndex: ({
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        specVar: string;
        outputPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
declare module "_102035_/l2/locadora/veiculosLista.defs" {
    export const definition: {
        screenId: string;
        pageName: string;
        actor: string;
        purpose: string;
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                rulesApplied: string[];
            }[];
        }[];
        status: string;
        visualStyle: string;
    };
    export const definitionPage: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: {
                sectionName: string;
                mode: string;
                organisms: ({
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        entityFields: {
                            entity: string;
                            entityField: string;
                            stateKey: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                        stateKey?: undefined;
                        sourceRoutine?: undefined;
                        itemFields?: undefined;
                        params?: undefined;
                        editable?: undefined;
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                } | {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        itemFields: ({
                            entity: string;
                            entityField: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        } | {
                            entity: string;
                            entityField: string;
                            priority: string;
                            usage: string;
                            priorityReason?: undefined;
                        })[];
                        params: {
                            paramName: string;
                            type: string;
                            source: {
                                from: string;
                                stateKey: string;
                            };
                        }[];
                        editable: boolean;
                        entityFields?: undefined;
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: any[];
                    emits: {
                        event: string;
                        payload: string;
                    }[];
                })[];
            }[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue: string;
            }[];
        }[];
    };
    export const contractSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/veiculosLista.defs.ts).definitionPage]]\n```\n\n## Ontology\n```JSON\n    [[(_102035_/l2/locadora/module.defs.ts)]]\n```\n";
    export const sharedSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/veiculosLista.defs.ts).definitionPage]]\n```\n\n## Contracts\n```JSON\n    [[(_102035_/l2/locadora/web/contracts/veiculosLista.ts)]]\n```\n\n";
    export const desktopLayoutSpec = "\n## Pages spec\n```JSON\n    [[(_102035_/l2/locadora/veiculosLista.defs.ts).definitionPage]]\n```\n\n## Base Class\n```JSON\n    [[(_102035_/l2/locadora/web/shared/veiculosLista.ts)]]\n```\n";
    export const materializeIndex: ({
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: any[];
        specUpdatedAt: string;
    } | {
        id: string;
        specVar: string;
        outputPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
        skillPath?: undefined;
    })[];
}
