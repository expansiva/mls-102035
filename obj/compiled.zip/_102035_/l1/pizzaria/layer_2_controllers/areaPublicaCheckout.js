/// <mls fileReference="_102035_/l1/pizzaria/layer_2_controllers/areaPublicaCheckout.ts" enhancement="_blank" /> 
import { AppError, ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
async function getPedidoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaPedido");
}
async function getItemPedidoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaItemPedido");
}
async function getComboRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaCombo");
}
async function getPoliticaCancelamentoReembolsoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaPoliticaCancelamentoReembolso");
}
async function getPagamentoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaPagamento");
}
export async function getResumoCheckoutPublico(ctx, input = {}) {
    const repo = await getPedidoRepository(ctx);
    const rows = await repo.findMany();
    let filtered = rows;
    if (input.pedidoId !== undefined) {
        filtered = filtered.filter((item) => item.id === input.pedidoId);
    }
    return filtered[0];
}
export async function listarItensPedido(ctx, input = {}) {
    const repo = await getItemPedidoRepository(ctx);
    const rows = await repo.findMany();
    let filtered = rows;
    if (input.pedidoId !== undefined) {
        filtered = filtered.filter((item) => item.pedidoId === input.pedidoId);
    }
    return filtered;
}
export async function listarCombosAtivos(ctx) {
    const repo = await getComboRepository(ctx);
    const rows = await repo.findMany();
    return rows;
}
export async function listarPoliticasCancelamentoAtivas(ctx) {
    const repo = await getPoliticaCancelamentoReembolsoRepository(ctx);
    const rows = await repo.findMany();
    return rows;
}
export async function carregar(ctx, input) {
    const repo = await getPedidoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Pedido not found", 404);
    const merged = {
        ...existing,
        ...(input.tipo !== undefined ? { tipo: input.tipo } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.itens !== undefined ? { itens: input.itens } : {}),
        ...(input.total !== undefined ? { total: input.total } : {}),
        ...(input.origem !== undefined ? { origem: input.origem } : {}),
        ...(input.cliente !== undefined ? { cliente: input.cliente } : {}),
        ...(input.enderecoEntrega !== undefined ? { enderecoEntrega: input.enderecoEntrega } : {}),
        ...(input.zonaEntregaId !== undefined ? { zonaEntregaId: input.zonaEntregaId } : {}),
        ...(input.taxaEntrega !== undefined ? { taxaEntrega: input.taxaEntrega } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function salvarPagamento(ctx, input) {
    const repo = await getPagamentoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Pagamento not found", 404);
    const merged = {
        ...existing,
        ...(input.pedidoId !== undefined ? { pedidoId: input.pedidoId } : {}),
        ...(input.metodo !== undefined ? { metodo: input.metodo } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.valor !== undefined ? { valor: input.valor } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function confirmarPedido(ctx, input) {
    const repo = await getPedidoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Pedido not found", 404);
    const merged = {
        ...existing,
        ...(input.tipo !== undefined ? { tipo: input.tipo } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.itens !== undefined ? { itens: input.itens } : {}),
        ...(input.total !== undefined ? { total: input.total } : {}),
        ...(input.origem !== undefined ? { origem: input.origem } : {}),
        ...(input.cliente !== undefined ? { cliente: input.cliente } : {}),
        ...(input.enderecoEntrega !== undefined ? { enderecoEntrega: input.enderecoEntrega } : {}),
        ...(input.zonaEntregaId !== undefined ? { zonaEntregaId: input.zonaEntregaId } : {}),
        ...(input.taxaEntrega !== undefined ? { taxaEntrega: input.taxaEntrega } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export const areaPublicaCheckoutGetResumoCheckoutPublicoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getResumoCheckoutPublico(ctx, {
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined
    }));
};
export const areaPublicaCheckoutListarItensPedidoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listarItensPedido(ctx, {
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined
    }));
};
export const areaPublicaCheckoutListarCombosAtivosHandler = async ({ request, ctx }) => {
    return ok(await listarCombosAtivos(ctx));
};
export const areaPublicaCheckoutListarPoliticasCancelamentoAtivasHandler = async ({ request, ctx }) => {
    return ok(await listarPoliticasCancelamentoAtivas(ctx));
};
export const areaPublicaCheckoutCarregarHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await carregar(ctx, {
        id: typeof params.id === "string" ? params.id : undefined,
        tipo: typeof params.tipo === "string" ? params.tipo : undefined,
        status: typeof params.status === "string" ? params.status : undefined,
        itens: params.itens !== undefined ? params.itens : undefined,
        total: typeof params.total === "number" ? params.total : undefined,
        origem: typeof params.origem === "string" ? params.origem : undefined,
        cliente: typeof params.cliente === "string" ? params.cliente : undefined,
        enderecoEntrega: typeof params.enderecoEntrega === "string" ? params.enderecoEntrega : undefined,
        zonaEntregaId: typeof params.zonaEntregaId === "string" ? params.zonaEntregaId : undefined,
        taxaEntrega: typeof params.taxaEntrega === "number" ? params.taxaEntrega : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const areaPublicaCheckoutSalvarPagamentoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await salvarPagamento(ctx, {
        id: typeof params.id === "string" ? params.id : undefined,
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined,
        metodo: typeof params.metodo === "string" ? params.metodo : undefined,
        status: typeof params.status === "string" ? params.status : undefined,
        valor: typeof params.valor === "number" ? params.valor : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const areaPublicaCheckoutConfirmarPedidoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await confirmarPedido(ctx, {
        id: typeof params.id === "string" ? params.id : undefined,
        tipo: typeof params.tipo === "string" ? params.tipo : undefined,
        status: typeof params.status === "string" ? params.status : undefined,
        itens: params.itens !== undefined ? params.itens : undefined,
        total: typeof params.total === "number" ? params.total : undefined,
        origem: typeof params.origem === "string" ? params.origem : undefined,
        cliente: typeof params.cliente === "string" ? params.cliente : undefined,
        enderecoEntrega: typeof params.enderecoEntrega === "string" ? params.enderecoEntrega : undefined,
        zonaEntregaId: typeof params.zonaEntregaId === "string" ? params.zonaEntregaId : undefined,
        taxaEntrega: typeof params.taxaEntrega === "number" ? params.taxaEntrega : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
