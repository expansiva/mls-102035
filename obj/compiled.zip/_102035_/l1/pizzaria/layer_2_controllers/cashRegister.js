/// <mls fileReference="_102035_/l1/pizzaria/layer_2_controllers/cashRegister.ts" enhancement="_blank" />
import { AppError, ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
async function getCaixaRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaCaixa");
}
async function getMovimentoCaixaRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaMovimentoCaixa");
}
export async function getCaixaDia(ctx, input) {
    const repo = await getCaixaRepository(ctx);
    let rows = await repo.findMany();
    if (input?.data !== undefined) {
        rows = rows.filter((item) => item.data === input.data);
    }
    return rows;
}
export async function listMovimentosCaixaDia(ctx, input) {
    const repo = await getMovimentoCaixaRepository(ctx);
    let rows = await repo.findMany();
    if (input?.data !== undefined) {
        rows = rows.filter((item) => item.dataHora === input.data);
    }
    return rows;
}
export async function openState(ctx, input) {
    const repo = await getCaixaRepository(ctx);
    const existing = await repo.findOne({ where: { data: input.data } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Caixa not found", 404);
    const merged = {
        ...existing,
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.valorAbertura !== undefined ? { valorAbertura: input.valorAbertura } : {}),
        ...(input.valorFechamento !== undefined ? { valorFechamento: input.valorFechamento } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function sangriaState(ctx, input) {
    const repo = await getMovimentoCaixaRepository(ctx);
    const existing = await repo.findOne({ where: { dataHora: input.dataHora } });
    if (!existing)
        throw new AppError("NOT_FOUND", "MovimentoCaixa not found", 404);
    const merged = {
        ...existing,
        ...(input.tipo !== undefined ? { tipo: input.tipo } : {}),
        ...(input.valor !== undefined ? { valor: input.valor } : {}),
        ...(input.observacao !== undefined ? { observacao: input.observacao } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function closeState(ctx, input) {
    const repo = await getCaixaRepository(ctx);
    const existing = await repo.findOne({ where: { data: input.data } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Caixa not found", 404);
    const merged = {
        ...existing,
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.valorAbertura !== undefined ? { valorAbertura: input.valorAbertura } : {}),
        ...(input.valorFechamento !== undefined ? { valorFechamento: input.valorFechamento } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function loadState(ctx, input) {
    const repo = await getCaixaRepository(ctx);
    const existing = await repo.findOne({ where: { data: input.data } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Caixa not found", 404);
    const merged = {
        ...existing,
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.valorAbertura !== undefined ? { valorAbertura: input.valorAbertura } : {}),
        ...(input.valorFechamento !== undefined ? { valorFechamento: input.valorFechamento } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function refreshState(ctx, input) {
    const repo = await getCaixaRepository(ctx);
    const existing = await repo.findOne({ where: { data: input.data } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Caixa not found", 404);
    const merged = {
        ...existing,
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.valorAbertura !== undefined ? { valorAbertura: input.valorAbertura } : {}),
        ...(input.valorFechamento !== undefined ? { valorFechamento: input.valorFechamento } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export const cashRegisterGetCaixaDiaHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getCaixaDia(ctx, {
        data: typeof params.data === "string" ? params.data : undefined
    }));
};
export const cashRegisterListMovimentosCaixaDiaHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listMovimentosCaixaDia(ctx, {
        data: typeof params.data === "string" ? params.data : undefined
    }));
};
export const cashRegisterOpenStateHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await openState(ctx, {
        data: typeof params.data === "string" ? params.data : undefined,
        status: typeof params.status === "string" ? params.status : undefined,
        valorAbertura: typeof params.valorAbertura === "number" ? params.valorAbertura : undefined,
        valorFechamento: typeof params.valorFechamento === "number" ? params.valorFechamento : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const cashRegisterSangriaStateHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await sangriaState(ctx, {
        dataHora: typeof params.dataHora === "string" ? params.dataHora : undefined,
        tipo: typeof params.tipo === "string" ? params.tipo : undefined,
        valor: typeof params.valor === "number" ? params.valor : undefined,
        observacao: typeof params.observacao === "string" ? params.observacao : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const cashRegisterCloseStateHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await closeState(ctx, {
        data: typeof params.data === "string" ? params.data : undefined,
        status: typeof params.status === "string" ? params.status : undefined,
        valorAbertura: typeof params.valorAbertura === "number" ? params.valorAbertura : undefined,
        valorFechamento: typeof params.valorFechamento === "number" ? params.valorFechamento : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const cashRegisterLoadStateHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await loadState(ctx, {
        data: typeof params.data === "string" ? params.data : undefined,
        status: typeof params.status === "string" ? params.status : undefined,
        valorAbertura: typeof params.valorAbertura === "number" ? params.valorAbertura : undefined,
        valorFechamento: typeof params.valorFechamento === "number" ? params.valorFechamento : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const cashRegisterRefreshStateHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await refreshState(ctx, {
        data: typeof params.data === "string" ? params.data : undefined,
        status: typeof params.status === "string" ? params.status : undefined,
        valorAbertura: typeof params.valorAbertura === "number" ? params.valorAbertura : undefined,
        valorFechamento: typeof params.valorFechamento === "number" ? params.valorFechamento : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
