/// <mls fileReference="_102035_/l1/pizzaria/layer_2_controllers/areaPublicaCardapio.ts" enhancement="_blank" />
import { AppError, ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
async function getProdutoRepository(ctx) {
    return ctx.data.moduleData.getTable('pizzariaProduto');
}
async function getComboRepository(ctx) {
    return ctx.data.moduleData.getTable('pizzariaCombo');
}
async function getPoliticaCancelamentoReembolsoRepository(ctx) {
    return ctx.data.moduleData.getTable('pizzariaPoliticaCancelamentoReembolso');
}
async function getConfiguracaoWhatsAppRepository(ctx) {
    return ctx.data.moduleData.getTable('pizzariaConfiguracaoWhatsApp');
}
async function getPedidoRepository(ctx) {
    return ctx.data.moduleData.getTable('pizzariaPedido');
}
export async function listProdutosPublicos(ctx, input) {
    const repo = await getProdutoRepository(ctx);
    let rows = await repo.findMany();
    if (input?.termo) {
        const termo = input.termo.toLowerCase();
        rows = rows.filter((item) => item.nome.toLowerCase().includes(termo) || (item.descricao ? item.descricao.toLowerCase().includes(termo) : false));
    }
    if (input?.categoria) {
        rows = rows.filter((item) => item.categoria === input.categoria);
    }
    if (input?.somenteDisponiveis !== undefined) {
        rows = rows.filter((item) => item.disponivel === input.somenteDisponiveis);
    }
    return rows;
}
export async function listCombosAtivos(ctx, input) {
    const repo = await getComboRepository(ctx);
    let rows = await repo.findMany();
    if (input?.ativo !== undefined) {
        rows = rows.filter((item) => item.ativo === input.ativo);
    }
    return rows;
}
export async function getPoliticaCancelamentoAtiva(ctx, input) {
    const repo = await getPoliticaCancelamentoReembolsoRepository(ctx);
    let rows = await repo.findMany();
    if (input?.ativo !== undefined) {
        rows = rows.filter((item) => item.ativo === input.ativo);
    }
    return rows[0];
}
export async function getConfiguracaoWhatsAppAtiva(ctx, input) {
    const repo = await getConfiguracaoWhatsAppRepository(ctx);
    let rows = await repo.findMany();
    if (input?.ativo !== undefined) {
        rows = rows.filter((item) => item.ativo === input.ativo);
    }
    return rows[0];
}
export async function loadMenu(ctx, input) {
    const repo = await getProdutoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError('NOT_FOUND', 'Produto not found', 404);
    const merged = {
        ...existing,
        ...(input.nome !== undefined ? { nome: input.nome } : {}),
        ...(input.descricao !== undefined ? { descricao: input.descricao } : {}),
        ...(input.preco !== undefined ? { preco: input.preco } : {}),
        ...(input.categoria !== undefined ? { categoria: input.categoria } : {}),
        ...(input.ativo !== undefined ? { ativo: input.ativo } : {}),
        ...(input.disponivel !== undefined ? { disponivel: input.disponivel } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function createOrder(ctx, input) {
    const repo = await getPedidoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError('NOT_FOUND', 'Pedido not found', 404);
    const merged = {
        ...existing,
        ...(input.tipo !== undefined ? { tipo: input.tipo } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.itens !== undefined ? { itens: input.itens } : {}),
        ...(input.total !== undefined ? { total: input.total } : {}),
        ...(input.origem !== undefined ? { origem: input.origem } : {}),
        ...(input.cliente !== undefined ? { cliente: input.cliente } : {}),
        ...(input.enderecoEntrega !== undefined ? { enderecoEntrega: input.enderecoEntrega } : {}),
        ...(input.zonaEntregaId !== undefined ? { zonaEntregaId: input.zonaEntregaId } : {}),
        ...(input.taxaEntrega !== undefined ? { taxaEntrega: input.taxaEntrega } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export const areaPublicaCardapioListProdutosPublicosHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listProdutosPublicos(ctx, {
        termo: typeof params.termo === 'string' ? params.termo : undefined,
        categoria: typeof params.categoria === 'string' ? params.categoria : undefined,
        somenteDisponiveis: true
    }));
};
export const areaPublicaCardapioListCombosAtivosHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listCombosAtivos(ctx, {
        ativo: true
    }));
};
export const areaPublicaCardapioGetPoliticaCancelamentoAtivaHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getPoliticaCancelamentoAtiva(ctx, {
        ativo: true
    }));
};
export const areaPublicaCardapioGetConfiguracaoWhatsAppAtivaHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getConfiguracaoWhatsAppAtiva(ctx, {
        ativo: true
    }));
};
export const areaPublicaCardapioLoadMenuHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await loadMenu(ctx, {
        id: typeof params.id === 'string' ? params.id : '',
        nome: typeof params.nome === 'string' ? params.nome : undefined,
        descricao: typeof params.descricao === 'string' ? params.descricao : undefined,
        preco: typeof params.preco === 'number' ? params.preco : undefined,
        categoria: typeof params.categoria === 'string' ? params.categoria : undefined,
        ativo: typeof params.ativo === 'boolean' ? params.ativo : undefined,
        disponivel: typeof params.disponivel === 'boolean' ? params.disponivel : undefined,
        author: typeof params.author === 'string' ? params.author : undefined
    }));
};
export const areaPublicaCardapioCreateOrderHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await createOrder(ctx, {
        id: typeof params.id === 'string' ? params.id : '',
        tipo: typeof params.tipo === 'string' ? params.tipo : undefined,
        status: typeof params.status === 'string' ? params.status : undefined,
        itens: params.itens !== undefined ? params.itens : undefined,
        total: typeof params.total === 'number' ? params.total : undefined,
        origem: typeof params.origem === 'string' ? params.origem : undefined,
        cliente: typeof params.cliente === 'string' ? params.cliente : undefined,
        enderecoEntrega: typeof params.enderecoEntrega === 'string' ? params.enderecoEntrega : undefined,
        zonaEntregaId: typeof params.zonaEntregaId === 'string' ? params.zonaEntregaId : undefined,
        taxaEntrega: typeof params.taxaEntrega === 'number' ? params.taxaEntrega : undefined,
        author: typeof params.author === 'string' ? params.author : undefined
    }));
};
