import { areaPublicaAcompanhamentoGetPedidoResumoPublicoHandler, areaPublicaAcompanhamentoListPedidoEtapasPublicoHandler, areaPublicaAcompanhamentoListItensPedidoPublicoHandler, areaPublicaAcompanhamentoGetEntregaPublicaHandler, areaPublicaAcompanhamentoGetConfiguracaoWhatsAppPublicaHandler, } from '/_102035_/l1/pizzaria/layer_2_controllers/areaPublicaAcompanhamento.js';
export function createPizzariaRouter() {
    return new Map([
        ['pizzaria.getPedidoResumoPublico', areaPublicaAcompanhamentoGetPedidoResumoPublicoHandler],
        ['pizzaria.listPedidoEtapasPublico', areaPublicaAcompanhamentoListPedidoEtapasPublicoHandler],
        ['pizzaria.listItensPedidoPublico', areaPublicaAcompanhamentoListItensPedidoPublicoHandler],
        ['pizzaria.getEntregaPublica', areaPublicaAcompanhamentoGetEntregaPublicaHandler],
        ['pizzaria.getConfiguracaoWhatsAppPublica', areaPublicaAcompanhamentoGetConfiguracaoWhatsAppPublicaHandler],
    ]);
}
