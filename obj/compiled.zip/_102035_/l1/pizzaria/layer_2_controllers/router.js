import { cashRegisterGetCaixaDiaHandler, cashRegisterListMovimentosCaixaDiaHandler, } from '/_102035_/l1/pizzaria/layer_2_controllers/cashRegister.js';
export function createPizzariaRouter() {
    return new Map([
        ['pizzaria.getCaixaDia', cashRegisterGetCaixaDiaHandler],
        ['pizzaria.listMovimentosCaixaDia', cashRegisterListMovimentosCaixaDiaHandler],
    ]);
}
