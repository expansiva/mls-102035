import { displayCozinhaGetResumoProducaoCozinhaHandler, displayCozinhaListarPedidosCozinhaHandler, displayCozinhaGetPedidoCozinhaDetalheHandler, } from '/_102035_/l1/pizzaria/layer_2_controller/displayCozinha.js';
export function createPizzariaRouter() {
    return new Map([
        ['pizzaria.getResumoProducaoCozinha', displayCozinhaGetResumoProducaoCozinhaHandler],
        ['pizzaria.listarPedidosCozinha', displayCozinhaListarPedidosCozinhaHandler],
        ['pizzaria.getPedidoCozinhaDetalhe', displayCozinhaGetPedidoCozinhaDetalheHandler],
    ]);
}
