import { displayCozinhaGetResumoProducaoCozinhaHandler, displayCozinhaListarPedidosCozinhaHandler, displayCozinhaGetPedidoCozinhaDetalheHandler, } from '/_102035_/l1/pizzaria/layer_2_controllers/displayCozinha.js';
import { confirmacaoImpressaoComandaGetPedidoResumoImpressaoHandler, } from '/_102035_/l1/pizzaria/layer_2_controllers/confirmacaoImpressaoComanda.js';
import { metasTempoConfiguracaoGetMetasTempoEtapasHandler, metasTempoConfiguracaoListDesviosTempoHandler, } from '/_102035_/l1/pizzaria/layer_2_controllers/metasTempoConfiguracao.js';
export function createPizzariaRouter() {
    return new Map([
        ['pizzaria.getResumoProducaoCozinha', displayCozinhaGetResumoProducaoCozinhaHandler],
        ['pizzaria.listarPedidosCozinha', displayCozinhaListarPedidosCozinhaHandler],
        ['pizzaria.getPedidoCozinhaDetalhe', displayCozinhaGetPedidoCozinhaDetalheHandler],
        ['pizzaria.getPedidoResumoImpressao', confirmacaoImpressaoComandaGetPedidoResumoImpressaoHandler],
        ['pizzaria.getMetasTempoEtapas', metasTempoConfiguracaoGetMetasTempoEtapasHandler],
        ['pizzaria.listDesviosTempo', metasTempoConfiguracaoListDesviosTempoHandler],
    ]);
}
