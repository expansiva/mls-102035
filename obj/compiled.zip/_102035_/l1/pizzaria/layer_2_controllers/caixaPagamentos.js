/// <mls fileReference="_102035_/l1/pizzaria/layer_2_controllers/caixaPagamentos.ts" enhancement="_blank" />
import { AppError, ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
async function getPagamentoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaPagamento");
}
async function getPoliticaCancelamentoReembolsoRepository(ctx) {
    return ctx.data.moduleData.getTable("pizzariaPoliticaCancelamentoReembolso");
}
export async function listPagamentos(ctx, input) {
    const repo = await getPagamentoRepository(ctx);
    let rows = await repo.findMany();
    if (input?.status !== undefined) {
        rows = rows.filter((item) => item.status === input.status);
    }
    if (input?.pedidoId !== undefined) {
        rows = rows.filter((item) => item.pedidoId === input.pedidoId);
    }
    return rows;
}
export async function getPoliticaCancelamentoReembolso(ctx, input) {
    const repo = await getPoliticaCancelamentoReembolsoRepository(ctx);
    let rows = await repo.findMany();
    if (input?.ativo !== undefined) {
        rows = rows.filter((item) => item.ativo === input.ativo);
    }
    return rows[0];
}
export async function loadPagamentos(ctx, input) {
    const repo = await getPagamentoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Pagamento not found", 404);
    const merged = {
        ...existing,
        ...(input.pedidoId !== undefined ? { pedidoId: input.pedidoId } : {}),
        ...(input.metodo !== undefined ? { metodo: input.metodo } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.valor !== undefined ? { valor: input.valor } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function processarReembolso(ctx, input) {
    const repo = await getPagamentoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Pagamento not found", 404);
    const merged = {
        ...existing,
        ...(input.pedidoId !== undefined ? { pedidoId: input.pedidoId } : {}),
        ...(input.metodo !== undefined ? { metodo: input.metodo } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.valor !== undefined ? { valor: input.valor } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export const caixaPagamentosListPagamentosHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listPagamentos(ctx, {
        status: typeof params.status === "string" ? params.status : undefined,
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined
    }));
};
export const caixaPagamentosGetPoliticaCancelamentoReembolsoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getPoliticaCancelamentoReembolso(ctx, {
        ativo: typeof params.ativo === "boolean" ? params.ativo : undefined
    }));
};
export const caixaPagamentosLoadPagamentosHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await loadPagamentos(ctx, {
        id: typeof params.id === "string" ? params.id : "",
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined,
        metodo: typeof params.metodo === "string" ? params.metodo : undefined,
        status: typeof params.status === "string" ? params.status : undefined,
        valor: typeof params.valor === "number" ? params.valor : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const caixaPagamentosProcessarReembolsoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await processarReembolso(ctx, {
        id: typeof params.id === "string" ? params.id : "",
        pedidoId: typeof params.pedidoId === "string" ? params.pedidoId : undefined,
        metodo: typeof params.metodo === "string" ? params.metodo : undefined,
        status: typeof params.status === "string" ? params.status : undefined,
        valor: typeof params.valor === "number" ? params.valor : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
