/// <mls fileReference="_102035_/l1/pizzaria/layer_2_controllers/displayCozinha.ts" enhancement="_blank" />
import { AppError, ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
async function getPedidoRepository(ctx) {
    return ctx.data.moduleData.getTable('pizzariaPedido');
}
async function getProducaoRepository(ctx) {
    return ctx.data.moduleData.getTable('pizzariaProducao');
}
async function getItemPedidoRepository(ctx) {
    return ctx.data.moduleData.getTable('pizzariaItemPedido');
}
export async function getResumoProducaoCozinha(ctx, input) {
    const repo = await getPedidoRepository(ctx);
    let rows = await repo.findMany();
    if (input?.cozinhaId !== undefined) {
        rows = rows.filter((item) => item.cozinhaId === input.cozinhaId);
    }
    return rows[0];
}
export async function listarPedidosCozinha(ctx, input) {
    const repo = await getPedidoRepository(ctx);
    let rows = await repo.findMany();
    const statusFilter = input?.status;
    if (statusFilter !== undefined) {
        rows = rows.filter((item) => statusFilter.includes(item.status));
    }
    if (input?.prioridade !== undefined) {
        rows = rows.filter((item) => item.prioridade === input.prioridade);
    }
    if (input?.cozinhaId !== undefined) {
        rows = rows.filter((item) => item.cozinhaId === input.cozinhaId);
    }
    return rows;
}
export async function getPedidoCozinhaDetalhe(ctx, input) {
    const repo = await getPedidoRepository(ctx);
    let rows = await repo.findMany();
    if (input?.pedidoId !== undefined) {
        rows = rows.filter((item) => item.pedidoId === input.pedidoId);
    }
    return rows[0];
}
export async function load(ctx, input) {
    const repo = await getProducaoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError('NOT_FOUND', 'Producao not found', 404);
    const merged = {
        ...existing,
        ...(input.pedidoId !== undefined ? { pedidoId: input.pedidoId } : {}),
        ...(input.statusProducao !== undefined ? { statusProducao: input.statusProducao } : {}),
        ...(input.inicioEm !== undefined ? { inicioEm: input.inicioEm } : {}),
        ...(input.fimEm !== undefined ? { fimEm: input.fimEm } : {}),
        ...(input.cozinheiroResponsavelId !== undefined ? { cozinheiroResponsavelId: input.cozinheiroResponsavelId } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function updateStatus(ctx, input) {
    const repo = await getProducaoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError('NOT_FOUND', 'Producao not found', 404);
    const merged = {
        ...existing,
        ...(input.pedidoId !== undefined ? { pedidoId: input.pedidoId } : {}),
        ...(input.statusProducao !== undefined ? { statusProducao: input.statusProducao } : {}),
        ...(input.inicioEm !== undefined ? { inicioEm: input.inicioEm } : {}),
        ...(input.fimEm !== undefined ? { fimEm: input.fimEm } : {}),
        ...(input.cozinheiroResponsavelId !== undefined ? { cozinheiroResponsavelId: input.cozinheiroResponsavelId } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function assignCook(ctx, input) {
    const repo = await getProducaoRepository(ctx);
    const existing = await repo.findOne({ where: { id: input.id } });
    if (!existing)
        throw new AppError('NOT_FOUND', 'Producao not found', 404);
    const merged = {
        ...existing,
        ...(input.pedidoId !== undefined ? { pedidoId: input.pedidoId } : {}),
        ...(input.statusProducao !== undefined ? { statusProducao: input.statusProducao } : {}),
        ...(input.inicioEm !== undefined ? { inicioEm: input.inicioEm } : {}),
        ...(input.fimEm !== undefined ? { fimEm: input.fimEm } : {}),
        ...(input.cozinheiroResponsavelId !== undefined ? { cozinheiroResponsavelId: input.cozinheiroResponsavelId } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export const displayCozinhaGetResumoProducaoCozinhaHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getResumoProducaoCozinha(ctx, {
        cozinhaId: typeof params.cozinhaId === 'string' ? params.cozinhaId : undefined
    }));
};
export const displayCozinhaListarPedidosCozinhaHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    const statusParam = params.status;
    const status = Array.isArray(statusParam) ? statusParam.filter((item) => typeof item === 'string') : undefined;
    return ok(await listarPedidosCozinha(ctx, {
        status,
        prioridade: typeof params.prioridade === 'string' ? params.prioridade : undefined,
        cozinhaId: typeof params.cozinhaId === 'string' ? params.cozinhaId : undefined
    }));
};
export const displayCozinhaGetPedidoCozinhaDetalheHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getPedidoCozinhaDetalhe(ctx, {
        pedidoId: typeof params.pedidoId === 'string' ? params.pedidoId : undefined
    }));
};
export const displayCozinhaLoadHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await load(ctx, {
        id: typeof params.id === 'string' ? params.id : '',
        pedidoId: typeof params.pedidoId === 'string' ? params.pedidoId : undefined,
        statusProducao: typeof params.statusProducao === 'string' ? params.statusProducao : undefined,
        inicioEm: params.inicioEm,
        fimEm: params.fimEm,
        cozinheiroResponsavelId: typeof params.cozinheiroResponsavelId === 'string' ? params.cozinheiroResponsavelId : undefined,
        author: typeof params.author === 'string' ? params.author : undefined
    }));
};
export const displayCozinhaUpdateStatusHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await updateStatus(ctx, {
        id: typeof params.id === 'string' ? params.id : '',
        pedidoId: typeof params.pedidoId === 'string' ? params.pedidoId : undefined,
        statusProducao: typeof params.statusProducao === 'string' ? params.statusProducao : undefined,
        inicioEm: params.inicioEm,
        fimEm: params.fimEm,
        cozinheiroResponsavelId: typeof params.cozinheiroResponsavelId === 'string' ? params.cozinheiroResponsavelId : undefined,
        author: typeof params.author === 'string' ? params.author : undefined
    }));
};
export const displayCozinhaAssignCookHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await assignCook(ctx, {
        id: typeof params.id === 'string' ? params.id : '',
        pedidoId: typeof params.pedidoId === 'string' ? params.pedidoId : undefined,
        statusProducao: typeof params.statusProducao === 'string' ? params.statusProducao : undefined,
        inicioEm: params.inicioEm,
        fimEm: params.fimEm,
        cozinheiroResponsavelId: typeof params.cozinheiroResponsavelId === 'string' ? params.cozinheiroResponsavelId : undefined,
        author: typeof params.author === 'string' ? params.author : undefined
    }));
};
