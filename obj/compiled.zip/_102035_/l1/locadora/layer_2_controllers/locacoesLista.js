/// <mls fileReference="_102035_/l1/locadora/layer_2_controllers/locacoesLista.ts" enhancement="_blank" />
import { ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
import { USE_MOCK, getMockLocacaoRepository } from "./mock.js";
async function getLocacaoRepository(ctx) {
    if (USE_MOCK)
        return getMockLocacaoRepository();
    return ctx.data.moduleData.getTable("locadoraLocacao");
}
export async function listLocacoes(ctx, input) {
    const repo = await getLocacaoRepository(ctx);
    const rows = await repo.findMany();
    let result = rows;
    if (input?.placaVeiculo) {
        result = result.filter((item) => item.placaVeiculo.includes(input.placaVeiculo));
    }
    if (input?.dataRetiradaInicio) {
        result = result.filter((item) => item.dataRetirada >= input.dataRetiradaInicio);
    }
    if (input?.dataRetiradaFim) {
        result = result.filter((item) => item.dataRetirada <= input.dataRetiradaFim);
    }
    if (input?.devolucaoPrevistaInicio) {
        result = result.filter((item) => item.devolucaoPrevista >= input.devolucaoPrevistaInicio);
    }
    if (input?.devolucaoPrevistaFim) {
        result = result.filter((item) => item.devolucaoPrevista <= input.devolucaoPrevistaFim);
    }
    if (input?.formaPagamento) {
        result = result.filter((item) => item.formaPagamento.includes(input.formaPagamento));
    }
    return result;
}
export const locacoesListaListLocacoesHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listLocacoes(ctx, {
        placaVeiculo: typeof params.placaVeiculo === "string" ? params.placaVeiculo : undefined,
        dataRetiradaInicio: typeof params.dataRetiradaInicio === "string" ? params.dataRetiradaInicio : undefined,
        dataRetiradaFim: typeof params.dataRetiradaFim === "string" ? params.dataRetiradaFim : undefined,
        devolucaoPrevistaInicio: typeof params.devolucaoPrevistaInicio === "string" ? params.devolucaoPrevistaInicio : undefined,
        devolucaoPrevistaFim: typeof params.devolucaoPrevistaFim === "string" ? params.devolucaoPrevistaFim : undefined,
        formaPagamento: typeof params.formaPagamento === "string" ? params.formaPagamento : undefined
    }));
};
