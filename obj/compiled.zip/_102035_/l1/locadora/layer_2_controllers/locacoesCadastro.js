/// <mls fileReference="_102035_/l1/locadora/layer_2_controllers/locacoesCadastro.ts" enhancement="_blank" />
import { AppError, ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
import { USE_MOCK, getMockClienteRepository, getMockLocacaoRepository, getMockVeiculoRepository } from "_102035_/l1/locadora/layer_2_controllers/mock.js";
async function getLocacaoRepository(ctx) {
    if (USE_MOCK)
        return getMockLocacaoRepository();
    return ctx.data.moduleData.getTable('locadoraLocacao');
}
async function getClienteRepository(ctx) {
    if (USE_MOCK)
        return getMockClienteRepository();
    return ctx.data.moduleData.getTable('locadoraCliente');
}
async function getVeiculoRepository(ctx) {
    if (USE_MOCK)
        return getMockVeiculoRepository();
    return ctx.data.moduleData.getTable('locadoraVeiculo');
}
export async function createLocacao(ctx, input) {
    const repo = await getLocacaoRepository(ctx);
    const rows = await repo.findMany();
    return rows;
}
export async function validateCliente(ctx, input) {
    const repo = await getClienteRepository(ctx);
    const rows = await repo.findMany();
    const filtered = typeof input?.clienteId === 'string'
        ? rows.filter((item) => item.clienteId === input.clienteId)
        : rows;
    return filtered;
}
export async function checkVeiculoAvailability(ctx, input) {
    const repo = await getVeiculoRepository(ctx);
    const rows = await repo.findMany();
    const filtered = typeof input?.placa === 'string'
        ? rows.filter((item) => item.placa === input.placa)
        : rows;
    return filtered;
}
export async function save(ctx, input) {
    if (!input || input.dataRetirada === undefined)
        throw new AppError('VALIDATION_ERROR', 'dataRetirada is required', 400);
    const repo = await getLocacaoRepository(ctx);
    const existing = await repo.findOne({ where: { dataRetirada: input.dataRetirada } });
    if (!existing)
        throw new AppError('NOT_FOUND', 'Locacao not found', 404);
    const merged = {
        ...existing,
        ...(input.dataDevolucao !== undefined ? { dataDevolucao: input.dataDevolucao } : {}),
        ...(input.valorDiario !== undefined ? { valorDiario: input.valorDiario } : {}),
        ...(input.seguroOpcional !== undefined ? { seguroOpcional: input.seguroOpcional } : {}),
        ...(input.formaPagamento !== undefined ? { formaPagamento: input.formaPagamento } : {}),
        ...(input.devolucaoPrevista !== undefined ? { devolucaoPrevista: input.devolucaoPrevista } : {}),
        ...(input.placaVeiculo !== undefined ? { placaVeiculo: input.placaVeiculo } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function checkVeiculo(ctx, input) {
    if (!input || input.placa === undefined)
        throw new AppError('VALIDATION_ERROR', 'placa is required', 400);
    const repo = await getVeiculoRepository(ctx);
    const existing = await repo.findOne({ where: { placa: input.placa } });
    if (!existing)
        throw new AppError('NOT_FOUND', 'Veiculo not found', 404);
    const merged = {
        ...existing,
        ...(input.modelo !== undefined ? { modelo: input.modelo } : {}),
        ...(input.ano !== undefined ? { ano: input.ano } : {}),
        ...(input.categoria !== undefined ? { categoria: input.categoria } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.quilometragem !== undefined ? { quilometragem: input.quilometragem } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function cancel(ctx, input) {
    if (!input || input.dataRetirada === undefined)
        throw new AppError('VALIDATION_ERROR', 'dataRetirada is required', 400);
    const repo = await getLocacaoRepository(ctx);
    const existing = await repo.findOne({ where: { dataRetirada: input.dataRetirada } });
    if (!existing)
        throw new AppError('NOT_FOUND', 'Locacao not found', 404);
    const merged = {
        ...existing,
        ...(input.dataDevolucao !== undefined ? { dataDevolucao: input.dataDevolucao } : {}),
        ...(input.valorDiario !== undefined ? { valorDiario: input.valorDiario } : {}),
        ...(input.seguroOpcional !== undefined ? { seguroOpcional: input.seguroOpcional } : {}),
        ...(input.formaPagamento !== undefined ? { formaPagamento: input.formaPagamento } : {}),
        ...(input.devolucaoPrevista !== undefined ? { devolucaoPrevista: input.devolucaoPrevista } : {}),
        ...(input.placaVeiculo !== undefined ? { placaVeiculo: input.placaVeiculo } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export const locacoesCadastroCreateLocacaoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await createLocacao(ctx, {}));
};
export const locacoesCadastroValidateClienteHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await validateCliente(ctx, {
        clienteId: typeof params.clienteId === 'string' ? params.clienteId : undefined
    }));
};
export const locacoesCadastroCheckVeiculoAvailabilityHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await checkVeiculoAvailability(ctx, {
        placa: typeof params.placa === 'string' ? params.placa : undefined
    }));
};
export const locacoesCadastroSaveHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await save(ctx, {
        dataRetirada: typeof params.dataRetirada === 'string' ? params.dataRetirada : undefined,
        dataDevolucao: typeof params.dataDevolucao === 'string' ? params.dataDevolucao : undefined,
        valorDiario: typeof params.valorDiario === 'number' ? params.valorDiario : undefined,
        seguroOpcional: typeof params.seguroOpcional === 'boolean' ? params.seguroOpcional : undefined,
        formaPagamento: typeof params.formaPagamento === 'string' ? params.formaPagamento : undefined,
        devolucaoPrevista: typeof params.devolucaoPrevista === 'string' ? params.devolucaoPrevista : undefined,
        placaVeiculo: typeof params.placaVeiculo === 'string' ? params.placaVeiculo : undefined,
        author: typeof params.author === 'string' ? params.author : undefined
    }));
};
export const locacoesCadastroCheckVeiculoHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await checkVeiculo(ctx, {
        placa: typeof params.placa === 'string' ? params.placa : undefined,
        modelo: typeof params.modelo === 'string' ? params.modelo : undefined,
        ano: typeof params.ano === 'number' ? params.ano : undefined,
        categoria: typeof params.categoria === 'string' ? params.categoria : undefined,
        status: typeof params.status === 'string' ? params.status : undefined,
        quilometragem: typeof params.quilometragem === 'number' ? params.quilometragem : undefined,
        author: typeof params.author === 'string' ? params.author : undefined
    }));
};
export const locacoesCadastroCancelHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await cancel(ctx, {
        dataRetirada: typeof params.dataRetirada === 'string' ? params.dataRetirada : undefined,
        dataDevolucao: typeof params.dataDevolucao === 'string' ? params.dataDevolucao : undefined,
        valorDiario: typeof params.valorDiario === 'number' ? params.valorDiario : undefined,
        seguroOpcional: typeof params.seguroOpcional === 'boolean' ? params.seguroOpcional : undefined,
        formaPagamento: typeof params.formaPagamento === 'string' ? params.formaPagamento : undefined,
        devolucaoPrevista: typeof params.devolucaoPrevista === 'string' ? params.devolucaoPrevista : undefined,
        placaVeiculo: typeof params.placaVeiculo === 'string' ? params.placaVeiculo : undefined,
        author: typeof params.author === 'string' ? params.author : undefined
    }));
};
