/// <mls fileReference="_102035_/l1/locadora/layer_2_controllers/mock.ts" enhancement="_blank" />
export const USE_MOCK = true;
const mockStore = {
    locadoraVeiculo: [
        { placa: 'AAA1', modelo: 'Fiat Argo', ano: 2025, categoria: 'Hatch ', status: 'disponível', quilometragem: 100000 },
        { placa: 'BBB2', modelo: 'Chevrolet Onix', ano: 2025, categoria: 'Sedan', status: 'disponível', quilometragem: 20000 },
    ],
    locadoraCliente: [
        { nome: 'Alberto', cpf: '99999999999', cnh: '99999999', telefone: '(99)9999-999', email: 'emaila@gmail.com' },
        { nome: 'Raul', cpf: '88888888888', cnh: '88888888', telefone: '(88)8888-888', email: 'emailb@gmail.com' },
    ],
    locadoraLocacao: [
        { dataRetirada: '01/05/2026', dataDevolucao: '03/05/2026', valorDiario: 10, seguroOpcional: true, formaPagamento: 'dinheiro', devolucaoPrevista: '03/05/2026', placaVeiculo: "BBB2", cpf: "99999999999" },
        { dataRetirada: '03/05/2026', dataDevolucao: '08/05/2026', valorDiario: 20, seguroOpcional: false, formaPagamento: 'dinheiro', devolucaoPrevista: '08/05/2026', placaVeiculo: "AAA1", cpf: "88888888888" },
    ],
    locadoraUsuarioAdmin: [
        { id: 'id-001', usuario: 'user1', senha: '123456' },
        { id: 'id-002', usuario: 'user2', senha: '123456' },
    ],
};
export function getMockVeiculoRepository() {
    const store = mockStore.locadoraVeiculo;
    return {
        async findMany() {
            return store;
        },
        async findOne({ where }) {
            return store.find((item) => Object.entries(where).every(([k, v]) => item[k] === v));
        },
        async upsert({ record }) {
            const idx = store.findIndex((item) => item.placa === record.placa);
            if (idx >= 0)
                store[idx] = record;
            else
                store.push(record);
        },
    };
}
export function getMockClienteRepository() {
    const store = mockStore.locadoraCliente;
    return {
        async findMany() {
            return store;
        },
        async findOne({ where }) {
            return store.find((item) => Object.entries(where).every(([k, v]) => item[k] === v));
        },
        async upsert({ record }) {
            const idx = store.findIndex((item) => item.nome === record.nome);
            if (idx >= 0)
                store[idx] = record;
            else
                store.push(record);
        },
    };
}
export function getMockLocacaoRepository() {
    const store = mockStore.locadoraLocacao;
    return {
        async findMany() {
            return store;
        },
        async findOne({ where }) {
            return store.find((item) => Object.entries(where).every(([k, v]) => item[k] === v));
        },
        async upsert({ record }) {
            const idx = store.findIndex((item) => item.dataRetirada === record.dataRetirada);
            if (idx >= 0)
                store[idx] = record;
            else
                store.push(record);
        },
    };
}
export function getMockUsuarioAdminRepository() {
    const store = mockStore.locadoraUsuarioAdmin;
    return {
        async findMany() {
            return store;
        },
        async findOne({ where }) {
            return store.find((item) => Object.entries(where).every(([k, v]) => item[k] === v));
        },
        async upsert({ record }) {
            const idx = store.findIndex((item) => item.id === record.id);
            if (idx >= 0)
                store[idx] = record;
            else
                store.push(record);
        },
    };
}
