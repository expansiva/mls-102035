/// <mls fileReference="_102035_/l1/locadora/layer_2_controllers/adminDashboard.ts" enhancement="_blank" />
import { ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
import { USE_MOCK, getMockVeiculoRepository, getMockClienteRepository, getMockLocacaoRepository } from "./mock.js";
async function getVeiculoRepository(ctx) {
    if (USE_MOCK)
        return getMockVeiculoRepository();
    return ctx.data.moduleData.getTable('locadoraVeiculo');
}
async function getClienteRepository(ctx) {
    if (USE_MOCK)
        return getMockClienteRepository();
    return ctx.data.moduleData.getTable('locadoraCliente');
}
async function getLocacaoRepository(ctx) {
    if (USE_MOCK)
        return getMockLocacaoRepository();
    return ctx.data.moduleData.getTable('locadoraLocacao');
}
export async function getQuickAccess(ctx, input) {
    return {};
}
export async function getSummary(ctx, input) {
    const veiculoRepo = await getVeiculoRepository(ctx);
    const clienteRepo = await getClienteRepository(ctx);
    const locacaoRepo = await getLocacaoRepository(ctx);
    const veiculos = await veiculoRepo.findMany();
    const clientes = await clienteRepo.findMany();
    const locacoes = await locacaoRepo.findMany();
    return { veiculos, clientes, locacoes };
}
export const adminDashboardGetQuickAccessHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getQuickAccess(ctx, {}));
};
export const adminDashboardGetSummaryHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getSummary(ctx, {}));
};
