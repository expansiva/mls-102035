/// <mls fileReference="_102035_/l1/locadora/layer_2_controllers/clientesLista.ts" enhancement="_blank" />
import { ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
import { USE_MOCK, getMockClienteRepository } from "./mock.js";
async function getClienteRepository(ctx) {
    if (USE_MOCK)
        return getMockClienteRepository();
    return ctx.data.moduleData.getTable("locadoraCliente");
}
export async function listarClientes(ctx, input) {
    const repo = await getClienteRepository(ctx);
    let rows = await repo.findMany();
    if (input?.nome !== undefined) {
        rows = rows.filter((item) => item.nome.includes(input.nome));
    }
    if (input?.cpf !== undefined) {
        rows = rows.filter((item) => item.cpf.includes(input.cpf));
    }
    if (input?.cnh !== undefined) {
        rows = rows.filter((item) => item.cnh.includes(input.cnh));
    }
    if (input?.telefone !== undefined) {
        rows = rows.filter((item) => item.telefone.includes(input.telefone));
    }
    if (input?.email !== undefined) {
        rows = rows.filter((item) => item.email.includes(input.email));
    }
    return rows;
}
export const clientesListaListarClientesHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listarClientes(ctx, {
        nome: typeof params.nome === "string" ? params.nome : undefined,
        cpf: typeof params.cpf === "string" ? params.cpf : undefined,
        cnh: typeof params.cnh === "string" ? params.cnh : undefined,
        telefone: typeof params.telefone === "string" ? params.telefone : undefined,
        email: typeof params.email === "string" ? params.email : undefined,
        statusValidacao: typeof params.statusValidacao === "string" ? params.statusValidacao : undefined,
        page: typeof params.page === "number" ? params.page : undefined,
        pageSize: typeof params.pageSize === "number" ? params.pageSize : undefined,
        sortBy: typeof params.sortBy === "string" ? params.sortBy : undefined,
        sortDir: typeof params.sortDir === "string" ? params.sortDir : undefined
    }));
};
