/// <mls fileReference="_102035_/l1/locadora/layer_2_controllers/clientesCadastro.ts" enhancement="_blank" />
import { AppError, ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
import { USE_MOCK, getMockClienteRepository } from "./mock.js";
async function getClienteRepository(ctx) {
    if (USE_MOCK)
        return getMockClienteRepository();
    return ctx.data.moduleData.getTable("locadoraCliente");
}
export async function save(ctx, input) {
    const repo = await getClienteRepository(ctx);
    const existing = await repo.findOne({ where: { nome: input.nome } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Cliente not found", 404);
    const merged = {
        ...existing,
        ...(input.cpf !== undefined ? { cpf: input.cpf } : {}),
        ...(input.cnh !== undefined ? { cnh: input.cnh } : {}),
        ...(input.telefone !== undefined ? { telefone: input.telefone } : {}),
        ...(input.email !== undefined ? { email: input.email } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function cancel(ctx, input) {
    const repo = await getClienteRepository(ctx);
    const existing = await repo.findOne({ where: { nome: input.nome } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Cliente not found", 404);
    const merged = {
        ...existing,
        ...(input.cpf !== undefined ? { cpf: input.cpf } : {}),
        ...(input.cnh !== undefined ? { cnh: input.cnh } : {}),
        ...(input.telefone !== undefined ? { telefone: input.telefone } : {}),
        ...(input.email !== undefined ? { email: input.email } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export async function validate(ctx, input) {
    const repo = await getClienteRepository(ctx);
    const existing = await repo.findOne({ where: { nome: input.nome } });
    if (!existing)
        throw new AppError("NOT_FOUND", "Cliente not found", 404);
    const merged = {
        ...existing,
        ...(input.cpf !== undefined ? { cpf: input.cpf } : {}),
        ...(input.cnh !== undefined ? { cnh: input.cnh } : {}),
        ...(input.telefone !== undefined ? { telefone: input.telefone } : {}),
        ...(input.email !== undefined ? { email: input.email } : {})
    };
    await repo.upsert({ record: merged });
    return merged;
}
export const clientesCadastroSaveHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await save(ctx, {
        nome: typeof params.nome === "string" ? params.nome : '',
        cpf: typeof params.cpf === "string" ? params.cpf : undefined,
        cnh: typeof params.cnh === "string" ? params.cnh : undefined,
        telefone: typeof params.telefone === "string" ? params.telefone : undefined,
        email: typeof params.email === "string" ? params.email : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const clientesCadastroCancelHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await cancel(ctx, {
        nome: typeof params.nome === "string" ? params.nome : '',
        cpf: typeof params.cpf === "string" ? params.cpf : undefined,
        cnh: typeof params.cnh === "string" ? params.cnh : undefined,
        telefone: typeof params.telefone === "string" ? params.telefone : undefined,
        email: typeof params.email === "string" ? params.email : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
export const clientesCadastroValidateHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await validate(ctx, {
        nome: typeof params.nome === "string" ? params.nome : '',
        cpf: typeof params.cpf === "string" ? params.cpf : undefined,
        cnh: typeof params.cnh === "string" ? params.cnh : undefined,
        telefone: typeof params.telefone === "string" ? params.telefone : undefined,
        email: typeof params.email === "string" ? params.email : undefined,
        author: typeof params.author === "string" ? params.author : undefined
    }));
};
