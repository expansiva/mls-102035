/// <mls fileReference="_102035_/l1/locadora/layer_2_controllers/veiculosLista.ts" enhancement="_blank" />
import { ok } from "/_102034_/l1/server/layer_2_controllers/contracts.js";
import { USE_MOCK, getMockVeiculoRepository } from "./mock.js";
async function getVeiculoRepository(ctx) {
    if (USE_MOCK)
        return getMockVeiculoRepository();
    return ctx.data.moduleData.getTable('locadoraVeiculo');
}
export async function listVeiculos(ctx, input) {
    const repo = await getVeiculoRepository(ctx);
    const rows = await repo.findMany();
    if (input?.status !== '') {
        return rows.filter((item) => item.status === input.status);
    }
    return rows;
}
export const veiculosListaListVeiculosHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listVeiculos(ctx, {
        status: typeof params.status === 'string' ? params.status : ''
    }));
};
