/// <mls fileReference="_102035_/l2/agentReviewSolution/steps/validate40/validate40.ts" enhancement="_blank" />
import { candidateCanPublish, unavailableCandidateCoverage, validateV3Candidate, } from '/_102035_/l2/newRelease/helpers/candidateValidation.js';
import { stableStringifyTobe } from '/_102035_/l2/newRelease/tobeDiff.js';
import { validateNs5Overlay, } from '/_102035_/l2/newRelease/tobe.js';
import { NS5_ONTOLOGY_SCHEMA_VERSION, isNs5OntologyV3Version, } from '/_102035_/l2/solution/types.js';
export const VALIDATE40_MAX_ATTEMPTS = 3;
function isRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function validArtifactPath(path) {
    return /^(?:module|rules|workflows|access|integration|workspace-model)\.defs\.ts$|^(?:journeys|ontology)\/index\.defs\.ts$/u.test(path)
        || /^(?:journeys\/[a-z][A-Za-z0-9]*|ontology\/[A-Z][A-Za-z0-9]*|workspaces\/[a-z][A-Za-z0-9]*)\.defs\.ts$/u.test(path);
}
function cloneInventory(value) {
    return JSON.parse(JSON.stringify(value));
}
function sourceOf(path, base, proposal) {
    return stableStringifyTobe(base[path]) === stableStringifyTobe(proposal[path]) ? 'asis' : 'tobe';
}
function artifact(path, base, proposal) {
    const raw = proposal[path];
    return { path, source: sourceOf(path, base, proposal), value: isRecord(raw) ? raw : null };
}
/** JSON boundary adapter. The imported gates, not TypeScript assertions, decide whether artifact values are valid. */
export function validate40Sources(base, proposal) {
    const paths = [...new Set([...Object.keys(base), ...Object.keys(proposal)])].sort();
    for (const path of paths)
        if (!validArtifactPath(path))
            throw new Error(`invalid L4 artifact path: ${path}`);
    const one = (path) => artifact(path, base, proposal);
    const journeys = paths.filter(path => /^journeys\/[a-z][A-Za-z0-9]*\.defs\.ts$/u.test(path) && path !== 'journeys/index.defs.ts')
        .map(path => one(path));
    const entities = paths.filter(path => /^ontology\/[A-Z][A-Za-z0-9]*\.defs\.ts$/u.test(path))
        .map(path => one(path));
    const module = one('module.defs.ts');
    const journeyIndex = one('journeys/index.defs.ts');
    const ontologyIndex = one('ontology/index.defs.ts');
    const rules = one('rules.defs.ts');
    const workflows = one('workflows.defs.ts');
    const access = one('access.defs.ts');
    const integration = one('integration.defs.ts');
    const typed = [module, journeyIndex, ...journeys, ontologyIndex, ...entities, rules, workflows, access, integration];
    const known = new Set(typed.map(item => item.path));
    const extra = paths.filter(path => !known.has(path))
        .map(path => one(path));
    return { module, journeyIndex, journeys, ontologyIndex, entities, rules, workflows, access, integration, all: [...typed, ...extra] };
}
function affectedByPath(path) {
    if (path === 'module.defs.ts')
        return ['module'];
    if (path.startsWith('journeys/'))
        return ['journeys'];
    if (path.startsWith('ontology/'))
        return ['ontologyAssembly', 'ontologyEntities'];
    if (path === 'rules.defs.ts')
        return ['rules'];
    if (path === 'workflows.defs.ts')
        return ['workflows'];
    if (path === 'access.defs.ts')
        return ['access'];
    if (path === 'integration.defs.ts')
        return ['integration'];
    return [];
}
export function validate40AffectedAreas(base, proposal) {
    const areas = new Set();
    const unsupportedPaths = [];
    for (const path of [...new Set([...Object.keys(base), ...Object.keys(proposal)])].sort()) {
        if (stableStringifyTobe(base[path]) === stableStringifyTobe(proposal[path]))
            continue;
        const mapped = affectedByPath(path);
        if (!mapped.length)
            unsupportedPaths.push(path);
        mapped.forEach(area => areas.add(area));
    }
    return { areas: [...areas], unsupportedPaths };
}
function failureValidation(code, message, affected) {
    const coverage = unavailableCandidateCoverage(message);
    for (const area of affected)
        coverage[area] = { status: 'error', reason: message };
    return {
        ok: false, oracle: null, coverage,
        issues: [{ artifact: 'module.defs.ts', path: '$', severity: 'error', code, message, source: 'gate' }],
    };
}
function reasonsFor(validation, affected, unsupportedPaths) {
    const reasons = unsupportedPaths.map(path => `No validate40 coverage for ${path}.`);
    for (const area of affected) {
        const coverage = validation.coverage[area];
        if (coverage.status !== 'checked')
            reasons.push(`${area}: ${coverage.status}${coverage.reason ? ` — ${coverage.reason}` : ''}`);
    }
    for (const issue of validation.issues.filter(item => item.severity === 'error'))
        reasons.push(`${issue.code} ${issue.path}: ${issue.message}`);
    return [...new Set(reasons)];
}
/** Pure core. Validation observes correction state but never consumes a correction attempt. */
export async function validate40Private(input) {
    if (!input.requestKey.trim() || input.state.requestKey !== input.requestKey) {
        throw new Error('validate40 attempt state does not belong to this persisted request');
    }
    if (!Number.isSafeInteger(input.state.correctionAttemptsUsed) || input.state.correctionAttemptsUsed < 0
        || input.state.correctionAttemptsUsed > VALIDATE40_MAX_ATTEMPTS) {
        throw new Error('invalid validate40 correction counter');
    }
    const draft = cloneInventory(input.proposal);
    const affected = validate40AffectedAreas(input.base, input.proposal);
    const rawIndex = input.proposal['ontology/index.defs.ts'];
    const schemaFamily = isRecord(rawIndex) && typeof rawIndex.schemaVersion === 'string'
        ? isNs5OntologyV3Version(rawIndex.schemaVersion) ? 'v3'
            : rawIndex.schemaVersion === NS5_ONTOLOGY_SCHEMA_VERSION ? 'v2' : 'unknown'
        : 'unknown';
    const state = { ...input.state };
    let validation;
    try {
        const sources = validate40Sources(input.base, input.proposal);
        if (schemaFamily === 'v3') {
            validation = validateV3Candidate(sources, input.context.v3 || {});
            if (!input.context.v3?.registryModuleNames) {
                validation = { ...validation, ok: false, coverage: { ...validation.coverage,
                        integration: { status: 'unsupported', reason: 'The caller did not provide the real module registry.' } } };
            }
        }
        else if (schemaFamily === 'v2') {
            validation = await validateNs5Overlay(sources, input.context.v2);
            if (!input.context.v2?.registryModuleNames) {
                validation = { ...validation, ok: false, coverage: { ...validation.coverage,
                        integration: { status: 'unsupported', reason: 'The caller did not provide the real module registry.' } } };
            }
        }
        else {
            validation = failureValidation('REVIEW_VALIDATE40_SCHEMA', 'Ontology schema family is unavailable.', affected.areas);
        }
    }
    catch (error) {
        validation = failureValidation('REVIEW_VALIDATE40_EXCEPTION', error instanceof Error ? error.message : String(error), affected.areas);
    }
    const publishable = affected.unsupportedPaths.length === 0 && candidateCanPublish(validation, affected.areas);
    const affectedUnsupported = affected.unsupportedPaths.length > 0
        || affected.areas.some(area => validation.coverage[area].status === 'unsupported');
    const operationalFailure = validation.issues.some(issue => issue.code === 'REVIEW_VALIDATE40_EXCEPTION' || issue.code === 'NR_GATE_EXCEPTION');
    const correctableInvalid = !publishable && !affectedUnsupported && !operationalFailure
        && (affected.areas.some(area => validation.coverage[area].status === 'error')
            || validation.issues.some(issue => issue.severity === 'error'));
    const attemptLimit = correctableInvalid && state.correctionAttemptsUsed >= VALIDATE40_MAX_ATTEMPTS;
    const mayCorrect = correctableInvalid && !attemptLimit;
    const reasons = reasonsFor(validation, affected.areas, affected.unsupportedPaths);
    if (attemptLimit)
        reasons.unshift(`Correction attempt limit (${VALIDATE40_MAX_ATTEMPTS}) reached for this request.`);
    return {
        status: publishable ? 'publishable' : attemptLimit ? 'attempt-limit' : 'draft', publishable, mayCorrect, schemaFamily,
        affectedAreas: affected.areas, unsupportedPaths: affected.unsupportedPaths,
        state, draft, validation, reasons,
    };
}
