/// <mls fileReference="_102035_/l2/ensaio/diskBridge.ts" enhancement="_blank" />
/**
 * Bridge between the disk of a project (what `collabmsg` agents read and write) and the in-memory stor of the rehearsal
 * (where the revision libraries of the New Release screen run in node). Not a second harness: the libraries are the ones
 * `nodejsCenario.ts` already runs; this only moves files across.
 */
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
const MLS_BASE = path.resolve(new URL('../../../', import.meta.url).pathname);
const keyOf = (file) => `${file.project}|${file.level}|${file.folder}|${file.shortName}|${file.extension}`;
/** `shortName` and `extension` the way the Studio splits a file name. */
export function splitName(name) {
    for (const extension of ['.defs.ts', '.test.ts', '.ts', '.json', '.txt', '.md']) {
        if (name.endsWith(extension))
            return { shortName: name.slice(0, -extension.length), extension };
    }
    throw new Error(`Unknown extension: ${name}`);
}
/** Puts a stor on the current `mls` and loads into it every file under `<root>` of the project (level 4 by default). */
export function installDiskStor(project, roots, level = 4) {
    const host = globalThis.mls;
    const files = {};
    const loaded = new Set();
    const add = (lvl, folder, shortName, extension, content) => {
        const file = {
            project, level: lvl, folder, shortName, extension, status: 'unchanged', versionRef: '1', content,
            getContent() { return Promise.resolve(this.content); },
            getValueInfo() { return Promise.resolve({ content: this.content }); },
        };
        files[keyOf(file)] = file;
        return file;
    };
    const walk = (dir, folder, lvl) => {
        for (const entry of readdirSync(dir, { withFileTypes: true })) {
            if (entry.name === '.DS_Store')
                continue;
            if (entry.isDirectory()) {
                walk(path.join(dir, entry.name), `${folder}/${entry.name}`, lvl);
                continue;
            }
            const { shortName, extension } = splitName(entry.name);
            add(lvl, folder, shortName, extension, readFileSync(path.join(dir, entry.name), 'utf8'));
            loaded.add(keyOf({ project, level: lvl, folder, shortName, extension }));
        }
    };
    for (const root of roots) {
        const dir = path.join(MLS_BASE, `mls-${project}`, `l${level}`, root);
        if (existsSync(dir))
            walk(dir, root, level);
    }
    Object.assign(host.stor, {
        files, getKeyToFile: keyOf,
        addOrUpdateFile: async (params) => files[keyOf(params)] ?? add(params.level, params.folder, params.shortName, params.extension, ''),
        localStor: {
            setContent: async (file, info) => { file.content = info.content; if (file.status === 'unchanged')
                file.status = 'changed'; },
            deleteFile: async (file) => { file.status = 'deleted'; },
            listFolder: (p, lvl, folder) => Object.values(files).filter(f => f.project === p && f.level === lvl && (f.folder === folder || f.folder.startsWith(`${folder}/`))),
        },
    });
    return { files, loaded };
}
/** Writes to the disk every file of the stor that is new or changed, and removes none. Returns the paths written. */
export function writeStorToDisk(files, project, level, onlyUnder) {
    const written = [];
    for (const file of Object.values(files)) {
        if (file.status === 'deleted' || file.project !== project || file.level !== level)
            continue;
        if (!onlyUnder.some(prefix => file.folder === prefix || file.folder.startsWith(`${prefix}/`)))
            continue;
        const target = path.join(MLS_BASE, `mls-${project}`, `l${level}`, file.folder, `${file.shortName}${file.extension}`);
        if (existsSync(target) && readFileSync(target, 'utf8') === file.content)
            continue;
        mkdirSync(path.dirname(target), { recursive: true });
        writeFileSync(target, file.content);
        written.push(path.relative(MLS_BASE, target));
    }
    return written;
}
