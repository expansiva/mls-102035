/// <mls fileReference="_102035_/l2/newRelease/helpers/agentCommandRunner.ts" enhancement="_blank" />
import { environment } from '/_102036_/l2/environmentContract.js';
import { msgGetTaskUpdate } from '/_102036_/l2/shared/api.js';
import { getThreadByName } from '/_102036_/l2/collabMessagesIndexedDB.js';
import { createThread, getTemporaryContext, getUserId } from '/_102025_/l2/collabMessagesHelper.js';
/** Canonical result/clarification payloads, including nested agent interactions. */
export function taskResultTexts(task) {
    const output = [];
    function visit(steps) {
        for (const step of steps) {
            if (step.type === 'result')
                output.push(step.result);
            if (step.type === 'clarification')
                output.push(step.json || step.stepTitle || '');
            visit(step.nextSteps || []);
            visit(step.interaction?.payload || []);
        }
    }
    visit(task.iaCompressed?.nextSteps || []);
    return [...new Set(output)];
}
/** Decode producer outcomes; indexes, proposals and successful intermediate gates stay out of the main flow. */
export function summarizeNewReleaseRequest(results, status) {
    let question = '';
    let refusal = '';
    let written = null;
    for (const result of results) {
        let value;
        try {
            value = JSON.parse(result);
        }
        catch {
            if (status === 'paused')
                question = result;
            else if (result.trim())
                refusal = result;
            continue;
        }
        if (!value || typeof value !== 'object' || Array.isArray(value))
            continue;
        const outcome = value;
        if (typeof outcome.question === 'string')
            question = outcome.question;
        if (outcome.triage?.valid === false) {
            if (typeof outcome.triage.clarification === 'string')
                question = outcome.triage.clarification;
            if (typeof outcome.triage.reason === 'string')
                refusal = outcome.triage.reason;
        }
        if (outcome.written === false)
            refusal = typeof outcome.reason === 'string' ? outcome.reason : '';
        if (outcome.written === true)
            written = Array.isArray(outcome.files) ? outcome.files.length : 0;
    }
    if (question)
        return { key: 'request.question', values: { question }, retry: true };
    if (refusal)
        return { key: 'request.refused', values: { reason: refusal }, retry: true };
    if (status === 'failed')
        return { key: 'request.failed', values: {}, retry: true };
    if (written !== null)
        return { key: 'request.success', values: { count: written }, retry: false };
    return { key: 'request.noResult', values: {}, retry: true };
}
export async function runNewReleaseRequest(moduleName, request, progress, dependencies = {}) {
    if (!request.trim())
        throw new Error('new-release.request_empty');
    const payload = { moduleName, request };
    return runNewReleaseCommand('agentNewReleasePrompt', JSON.stringify(payload), progress, dependencies);
}
export async function runNewReleaseCommand(agent, payload, progress, dependencies = {}) {
    const user = (dependencies.userId ?? getUserId)();
    if (!user)
        throw new Error('implementation.user_unavailable');
    const threadName = '_102035_/l2/newRelease/requests';
    const resolved = await (dependencies.thread ?? (async () => await getThreadByName(threadName) ?? await createThread(threadName, [], 'company')))();
    if (!resolved?.threadId)
        throw new Error('implementation.thread_unavailable');
    const prompt = '@@' + agent + ' ' + payload;
    const context = (dependencies.context ?? getTemporaryContext)(resolved.threadId, user, prompt);
    await (dependencies.execute ?? ((agent, ctx) => environment.agents.executeAgent(agent, ctx)))(agent, context);
    if (!context.task?.PK)
        throw new Error('implementation.task_unavailable');
    let task = context.task;
    const identity = task.PK;
    const id = identity.replace(/^task(?:\/#?|#)/u, '');
    const messageId = task.messageid_created || `${context.message.threadId}/${context.message.orderAt || context.message.createAt}`;
    for (;;) {
        if (task.PK !== identity)
            throw new Error('implementation.task_mismatch');
        progress(task);
        if (['done', 'failed', 'paused'].includes(task.status))
            return { task, results: taskResultTexts(task) };
        await (dependencies.wait ?? (() => new Promise(resolve => setTimeout(resolve, 1500))))();
        task = await (dependencies.task ?? (async (userId, taskId, messageId) => {
            const read = await msgGetTaskUpdate({ userId, taskId, messageId });
            if (!read.success || !read.response?.task)
                throw new Error(read.error || 'implementation.task_unavailable');
            return read.response.task;
        }))(user, id, messageId);
    }
}
