/// <mls fileReference="_102035_/l2/newRelease/helpers/candidateDraftStore.ts" enhancement="_blank" />
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _IndexedDbCandidateDraftStore_instances, _IndexedDbCandidateDraftStore_factory, _IndexedDbCandidateDraftStore_databaseName, _IndexedDbCandidateDraftStore_databasePromise, _IndexedDbCandidateDraftStore_database, _IndexedDbCandidateDraftStore_request, _IndexedDbCandidateDraftStore_write;
import { CandidateRepositoryError, } from './candidateRepository.js';
const DATABASE_VERSION = 1;
const STORE_NAME = 'drafts';
export const STUDIO_CANDIDATE_DATABASE = 'collab-new-release-candidates-v1';
function clone(value) {
    return structuredClone(value);
}
function unavailable() {
    return new CandidateRepositoryError(503, 'candidate.draft_store_unavailable');
}
/** Durable, private Studio draft storage. `create` is atomic across tabs in the same browser. */
export class IndexedDbCandidateDraftStore {
    constructor(factory = globalThis.indexedDB, databaseName = STUDIO_CANDIDATE_DATABASE) {
        _IndexedDbCandidateDraftStore_instances.add(this);
        _IndexedDbCandidateDraftStore_factory.set(this, void 0);
        _IndexedDbCandidateDraftStore_databaseName.set(this, void 0);
        _IndexedDbCandidateDraftStore_databasePromise.set(this, null);
        __classPrivateFieldSet(this, _IndexedDbCandidateDraftStore_factory, factory, "f");
        __classPrivateFieldSet(this, _IndexedDbCandidateDraftStore_databaseName, databaseName, "f");
    }
    async read(key) {
        const row = await __classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_instances, "m", _IndexedDbCandidateDraftStore_request).call(this, 'readonly', store => store.get(key));
        return row ? clone(row.draft) : null;
    }
    async list(prefix) {
        const rows = await __classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_instances, "m", _IndexedDbCandidateDraftStore_request).call(this, 'readonly', store => store.getAll());
        return rows
            .filter(row => row.key.startsWith(`${prefix}/`))
            .sort((left, right) => left.key.localeCompare(right.key))
            .map(row => ({ key: row.key, draft: clone(row.draft) }));
    }
    async create(key, draft) {
        const database = await __classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_instances, "m", _IndexedDbCandidateDraftStore_database).call(this);
        return new Promise((resolve, reject) => {
            const transaction = database.transaction(STORE_NAME, 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            let selected = null;
            const get = store.get(key);
            get.onsuccess = () => {
                const existing = get.result;
                if (existing) {
                    selected = clone(existing.draft);
                    return;
                }
                selected = clone(draft);
                const add = store.add({ key, draft: clone(draft) });
                add.onerror = () => transaction.abort();
            };
            get.onerror = () => transaction.abort();
            transaction.oncomplete = () => selected ? resolve(clone(selected)) : reject(unavailable());
            transaction.onerror = () => reject(unavailable());
            transaction.onabort = () => reject(unavailable());
        });
    }
    async write(key, draft) {
        await __classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_instances, "m", _IndexedDbCandidateDraftStore_write).call(this, store => store.put({ key, draft: clone(draft) }));
    }
    async remove(key) {
        await __classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_instances, "m", _IndexedDbCandidateDraftStore_write).call(this, store => store.delete(key));
    }
}
_IndexedDbCandidateDraftStore_factory = new WeakMap(), _IndexedDbCandidateDraftStore_databaseName = new WeakMap(), _IndexedDbCandidateDraftStore_databasePromise = new WeakMap(), _IndexedDbCandidateDraftStore_instances = new WeakSet(), _IndexedDbCandidateDraftStore_database = async function _IndexedDbCandidateDraftStore_database() {
    if (!__classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_factory, "f"))
        throw unavailable();
    if (!__classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_databasePromise, "f")) {
        __classPrivateFieldSet(this, _IndexedDbCandidateDraftStore_databasePromise, new Promise((resolve, reject) => {
            const request = __classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_factory, "f").open(__classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_databaseName, "f"), DATABASE_VERSION);
            request.onupgradeneeded = () => {
                if (!request.result.objectStoreNames.contains(STORE_NAME)) {
                    request.result.createObjectStore(STORE_NAME, { keyPath: 'key' });
                }
            };
            request.onsuccess = () => {
                request.result.onversionchange = () => request.result.close();
                resolve(request.result);
            };
            request.onerror = () => reject(unavailable());
            request.onblocked = () => reject(unavailable());
        }), "f");
    }
    try {
        return await __classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_databasePromise, "f");
    }
    catch (error) {
        __classPrivateFieldSet(this, _IndexedDbCandidateDraftStore_databasePromise, null, "f");
        throw error;
    }
}, _IndexedDbCandidateDraftStore_request = async function _IndexedDbCandidateDraftStore_request(mode, operation) {
    const database = await __classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_instances, "m", _IndexedDbCandidateDraftStore_database).call(this);
    return new Promise((resolve, reject) => {
        const transaction = database.transaction(STORE_NAME, mode);
        const request = operation(transaction.objectStore(STORE_NAME));
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(unavailable());
        transaction.onerror = () => reject(unavailable());
        transaction.onabort = () => reject(unavailable());
    });
}, _IndexedDbCandidateDraftStore_write = async function _IndexedDbCandidateDraftStore_write(operation) {
    const database = await __classPrivateFieldGet(this, _IndexedDbCandidateDraftStore_instances, "m", _IndexedDbCandidateDraftStore_database).call(this);
    await new Promise((resolve, reject) => {
        const transaction = database.transaction(STORE_NAME, 'readwrite');
        const request = operation(transaction.objectStore(STORE_NAME));
        request.onerror = () => transaction.abort();
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(unavailable());
        transaction.onabort = () => reject(unavailable());
    });
};
