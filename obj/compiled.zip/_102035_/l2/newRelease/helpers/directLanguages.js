/// <mls fileReference="_102035_/l2/newRelease/helpers/directLanguages.ts" enhancement="_blank" />
import { findLanguageByCode } from '/_102027_/l2/collabLanguages.js';
import { readDefsJson, readJson, writeJson } from '/_102035_/l2/solution/fs.js';
import { tobeArtifactFileInfo } from '/_102035_/l2/solution/candidate/tobePaths.js';
import { saveDirectLanguageMetadata } from '/_102035_/l2/newRelease/tobe.js';
import { runNewReleaseCommand } from '/_102035_/l2/newRelease/helpers/agentCommandRunner.js';
export function languageCommands(projectId, moduleName, before, after) {
    return [['agentAddLanguage', after.filter(code => !before.includes(code))],
        ['agentRemoveLanguage', before.filter(code => !after.includes(code))]]
        .filter(([, codes]) => codes.length > 0).map(([agent, codes]) => {
        const payload = [{ projectId, moduleName,
                languages: codes.map(code => ({ code, name: findLanguageByCode(code)?.name || code })) }];
        return { agent, payload: JSON.stringify(payload) };
    });
}
export async function hasPendingLanguages(project, moduleName) {
    const record = await readJson({ project, level: 4, folder: `${moduleName}/pipeline/newRelease`, shortName: 'languages', extension: '.json' });
    return !!record?.pending.length;
}
export async function applyDirectLanguages(project, moduleName, value, expected, progress, execute = runNewReleaseCommand) {
    const published = await readDefsJson(tobeArtifactFileInfo(project, moduleName, 'module.defs.ts', 'asis'));
    if (!published)
        throw new Error('general.languagesInvalid');
    const info = { project, level: 4, folder: `${moduleName}/pipeline/newRelease`, shortName: 'languages', extension: '.json' };
    const previous = await readJson(info);
    const target = JSON.stringify([value.productLanguages, value.defaultLanguage]);
    if (!previous?.pending.length && JSON.stringify([published.productLanguages, published.defaultLanguage]) === target)
        return expected.revisionId;
    if (previous?.pending.length && previous.target !== target)
        throw new Error('general.languagesPending');
    const pending = previous?.pending.length ? previous.pending : languageCommands(project, moduleName, published.productLanguages, value.productLanguages);
    progress('general.languagesSaving');
    const revisionId = await saveDirectLanguageMetadata(project, moduleName, { productLanguages: [...value.productLanguages], defaultLanguage: value.defaultLanguage }, expected);
    await writeJson(info, { target, pending });
    while (pending.length) {
        const command = pending[0];
        progress('general.languagesRunning');
        const outcome = await execute(command.agent, command.payload, () => progress('general.languagesRunning'));
        const refusal = outcome.results.find(result => /^(?:refused|failed):/u.test(result.trim()));
        if (outcome.task.status !== 'done' || refusal)
            throw new Error(refusal || outcome.results.join('\n') || outcome.task.last_update_log || 'general.languagesFailed');
        pending.shift();
        await writeJson(info, { target, pending });
    }
    progress('general.languagesDone');
    return revisionId;
}
