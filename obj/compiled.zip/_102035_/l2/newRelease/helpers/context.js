/// <mls fileReference="_102035_/l2/newRelease/helpers/context.ts" enhancement="_blank" />
export function historicalReleaseId(version) {
    if (!version.startsWith('release:'))
        return null;
    const id = version.slice('release:'.length);
    if (!/^[a-zA-Z0-9-]+$/u.test(id))
        throw new Error('Invalid release identifier.');
    return id;
}
export const NEW_RELEASE_CONTEXT_EVENT = 'new-release-context-change';
export const NEW_RELEASE_TOBE_UPDATED_EVENT = 'nr-tobe-updated';
export function announceNewReleaseContext(context) {
    window.dispatchEvent(new CustomEvent(NEW_RELEASE_CONTEXT_EVENT, { detail: context }));
}
