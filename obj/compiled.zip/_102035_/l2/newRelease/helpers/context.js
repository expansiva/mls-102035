/// <mls fileReference="_102035_/l2/newRelease/helpers/context.ts" enhancement="_blank" />
export const NEW_RELEASE_CONTEXT_EVENT = 'new-release-context-change';
export const NEW_RELEASE_TOBE_UPDATED_EVENT = 'nr-tobe-updated';
export function announceNewReleaseContext(context) {
    window.dispatchEvent(new CustomEvent(NEW_RELEASE_CONTEXT_EVENT, { detail: context }));
}
