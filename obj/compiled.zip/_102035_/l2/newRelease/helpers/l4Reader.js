/// <mls fileReference="_102035_/l2/newRelease/helpers/l4Reader.ts" enhancement="_blank" />
import { finalizeReportFileForProject, moduleFileForProject, pipelineJsonFileForProject, readDefsJson, readJson, readPipelineForProject, } from '/_102035_/l2/solution/fs.js';
import { readActiveL4Change, readL4Release } from '/_102035_/l2/newRelease/helpers/moduleRevision.js';
import { readNs5Overlay, } from '/_102035_/l2/newRelease/tobe.js';
function liveFiles(files) {
    return Object.values(files).filter((file) => !!file && file.status !== 'deleted');
}
export function listReadableProjectsFromFiles(files) {
    const projects = new Set();
    for (const file of liveFiles(files)) {
        if (file.level !== 4 || file.shortName !== 'module' || file.extension !== '.defs.ts')
            continue;
        if (!file.folder || file.folder.includes('/'))
            continue;
        if (typeof file.project === 'number' && file.project > 0)
            projects.add(file.project);
    }
    return [...projects].sort((a, b) => a - b);
}
export function listNs5ModulesFromFiles(files, project) {
    const modules = new Set();
    for (const file of liveFiles(files)) {
        if (file.project !== project || file.level !== 4 || file.shortName !== 'module' || file.extension !== '.defs.ts')
            continue;
        if (!file.folder || file.folder.includes('/') || file.folder === 'organization')
            continue;
        modules.add(file.folder);
    }
    return [...modules].sort((a, b) => a.localeCompare(b));
}
export function listReadableProjects() {
    return listReadableProjectsFromFiles(mls.stor.files);
}
export function listNs5Modules(project) {
    return listNs5ModulesFromFiles(mls.stor.files, project);
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
export function runtimeConfigHasModules(value, project) {
    if (!isRecord(value) || !isRecord(value.projects))
        return false;
    const projectConfig = value.projects[String(project)];
    return isRecord(projectConfig) && Array.isArray(projectConfig.modules) && projectConfig.modules.length > 0;
}
async function readRuntimeConfig(project) {
    const file = liveFiles(mls.stor.files).find(candidate => candidate.project === project
        && candidate.level === 5
        && !candidate.folder
        && candidate.shortName === 'config'
        && candidate.extension === '.json');
    if (!file?.getContent)
        return null;
    try {
        const content = await file.getContent();
        if (typeof content !== 'string' || !content.trim())
            return null;
        return JSON.parse(content);
    }
    catch {
        return null;
    }
}
/** Projects with an L4 module and a materialized runtime config containing modules. */
export async function listEligibleProjects() {
    const candidates = listReadableProjects();
    const accepted = await Promise.all(candidates.map(async (project) => runtimeConfigHasModules(await readRuntimeConfig(project), project) ? project : null));
    return accepted.filter((project) => project !== null);
}
function filePath(file) {
    return `l${file.level}/${file.folder ? `${file.folder}/` : ''}${file.shortName}${file.extension}`;
}
async function optionalRead(file, reader, errors) {
    try {
        return await reader();
    }
    catch (error) {
        errors.push({ path: filePath(file), message: error instanceof Error ? error.message : String(error) });
        return null;
    }
}
function filesForPipeline(project, moduleName) {
    const folder = `${moduleName}/pipeline`;
    return liveFiles(mls.stor.files)
        .filter(file => file.project === project
        && file.level === 4
        && file.folder === folder
        && file.extension === '.json'
        && /^run\d+_newsolution5$/.test(String(file.shortName || '')))
        .map(file => ({
        project,
        level: 4,
        folder,
        shortName: String(file.shortName),
        extension: '.json',
    }));
}
async function readLatestRun(project, moduleName, errors) {
    const runs = await Promise.all(filesForPipeline(project, moduleName).map(file => optionalRead(file, () => readJson(file), errors)));
    return runs
        .filter((run) => !!run)
        .sort((a, b) => String(b.savedAt || '').localeCompare(String(a.savedAt || '')))[0] ?? null;
}
async function readTobeChanges(project, moduleName, errors) {
    const file = {
        project,
        level: 4,
        folder: `${moduleName}/tobe/plan`,
        shortName: 'tobe',
        extension: '.json',
    };
    const manifest = await optionalRead(file, () => readJson(file), errors);
    return Array.isArray(manifest?.changes) ? manifest.changes.length : 0;
}
/** Read a complete NS5 module, substituting each prepared artifact independently in `tobe` mode. */
export async function readNs5Module(project, moduleName, version = 'asis') {
    const errors = [];
    const pipelineInfo = pipelineJsonFileForProject(project, moduleName, 'pipeline');
    const reportInfo = finalizeReportFileForProject(project, moduleName);
    const [pipeline, persistedReport, run] = await Promise.all([
        optionalRead(pipelineInfo, () => readPipelineForProject(project, moduleName), errors),
        optionalRead(reportInfo, () => readJson(reportInfo), errors),
        readLatestRun(project, moduleName, errors),
    ]);
    const overlay = await readNs5Overlay(project, moduleName, version, {
        pipeline: version.startsWith('release:') ? null : pipeline,
        registryModuleNames: listNs5Modules(project),
    });
    errors.push(...overlay.errors);
    const finalizeReport = version.startsWith('release:') ? null : version === 'tobe' && overlay.validation.oracle
        ? overlay.validation.oracle
        : persistedReport;
    const active = version.startsWith('release:') ? null : await readActiveL4Change(project, moduleName);
    const baseProvenance = active ? (await readL4Release(project, moduleName, active.baseId))?.provenance ?? null : null;
    const resultCurrent = !!active?.activeRevisionId && active.resultRevisionId === active.activeRevisionId;
    return {
        module: overlay.sources.module.value,
        pipeline: version.startsWith('release:') ? null : pipeline,
        finalizeReport,
        run: version.startsWith('release:') ? null : run,
        tobeChanges: overlay.manifest?.changes.length ?? 0,
        artifacts: overlay.sources,
        manifest: overlay.manifest,
        changeId: overlay.changeId,
        revisionId: overlay.revisionId,
        baseProvenance,
        resultCurrent,
        stalePaths: overlay.stalePaths,
        diffs: overlay.diffs,
        validation: overlay.validation,
        errors,
    };
}
export async function listNs5ModuleSummaries(project) {
    const summaries = await Promise.all(listNs5Modules(project).map(async (name) => {
        const errors = [];
        const moduleInfo = moduleFileForProject(project, name);
        const pipelineInfo = pipelineJsonFileForProject(project, name, 'pipeline');
        const [module, pipeline, tobeChanges] = await Promise.all([
            optionalRead(moduleInfo, () => readDefsJson(moduleInfo), errors),
            optionalRead(pipelineInfo, () => readPipelineForProject(project, name), errors),
            readTobeChanges(project, name, errors),
        ]);
        return {
            name,
            title: module?.title || name,
            status: pipeline?.status || 'unknown',
            failedStep: failedStepOf(pipeline),
            tobeChanges,
            module,
        };
    }));
    return summaries.sort((a, b) => a.title.localeCompare(b.title));
}
export function failedStepOf(pipeline) {
    if (!pipeline)
        return null;
    const entry = Object.entries(pipeline.steps).find(([, step]) => step?.status === 'failed');
    return entry?.[0] ?? null;
}
