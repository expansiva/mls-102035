/// <mls fileReference="_102035_/l2/newRelease/helpers/visibleDiffs.ts" enhancement="_blank" />
import { tabForArtifactPath } from '/_102035_/l2/newRelease/editContract.js';
export function visibleDiffs(diffs, tab) {
    return diffs
        .filter(diff => tab === 'review' || tabForArtifactPath(diff.path) === tab)
        .map(diff => ({ ...diff, entries: diff.entries.filter(entry => entry.jsonPath !== '$.businessHash') }))
        .filter(diff => diff.entries.length > 0);
}
