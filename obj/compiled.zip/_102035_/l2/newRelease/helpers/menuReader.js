/// <mls fileReference="_102035_/l2/newRelease/helpers/menuReader.ts" enhancement="_blank" />
import { normalizeModuleName, readJson } from '/_102035_/l2/solution/fs.js';
export function menuFileForProject(project, moduleName, root) {
    return {
        project,
        level: 4,
        folder: `${root || normalizeModuleName(moduleName)}/pool/l2/web`,
        shortName: 'menu',
        extension: '.json',
    };
}
function menuPath(file) {
    return `l${file.level}/${file.folder}/${file.shortName}${file.extension}`;
}
/** Tolerant read of `l4/<module>/pool/l2/web/menu.json` for the selected project. Never throws. */
export async function readModuleMenu(project, moduleName, root) {
    const file = menuFileForProject(project, moduleName, root);
    const path = menuPath(file);
    if (!project || !moduleName)
        return { status: 'missing', path };
    const stored = mls.stor.files[mls.stor.getKeyToFile(file)];
    if (!stored || stored.status === 'deleted')
        return { status: 'missing', path };
    try {
        const value = await readJson(file);
        if (value === null)
            return { status: 'invalid', path };
        return { status: 'ok', path, value };
    }
    catch {
        return { status: 'invalid', path };
    }
}
