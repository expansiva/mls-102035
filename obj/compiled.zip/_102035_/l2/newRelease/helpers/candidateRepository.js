/// <mls fileReference="_102035_/l2/newRelease/helpers/candidateRepository.ts" enhancement="_blank" />
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _CandidateRepository_instances, _CandidateRepository_scope, _CandidateRepository_options, _CandidateRepository_hasRead, _CandidateRepository_state, _CandidateRepository_publishFixed, _CandidateRepository_wireFromDraft, _CandidateRepository_acceptCommitted, _CandidateRepository_block, _CandidateRepository_createRequestId, _CandidateRepository_requireReady, _CandidateRepository_normalizeReadResult, _CandidateRepository_requireCommitted, _CandidateRepository_requireConflictPointer, _CandidateRepository_loadDrafts, _CandidateRepository_safeLoadDrafts, _CandidateRepository_validateStored, _CandidateRepository_upsert, _CandidateRepository_settle, _CandidateRepository_unavailable;
import { candidatePublish, candidateRead, CandidateGatewayError, verifyCandidateSnapshot, } from './candidateGateway.js';
const DRAFT_SCHEMA = '2026-09-21-candidate-draft-v2';
const TOKEN = /^[A-Za-z0-9_-]{1,100}$/u;
const MODULE = /^[a-z][A-Za-z0-9]{0,59}$/u;
const HASH = /^[a-f0-9]{64}$/u;
export class CandidateRepositoryError extends Error {
    constructor(statusCode, code, reasons = []) {
        super(code);
        this.statusCode = statusCode;
        this.code = code;
        this.reasons = reasons;
        this.name = 'CandidateRepositoryError';
    }
}
/** Control-flow marker emitted only after the blocked draft is durably stored. */
class CandidateBlockedError extends CandidateRepositoryError {
}
function clone(value) {
    return structuredClone(value);
}
function deepFreeze(value) {
    if (value !== null && typeof value === 'object' && !Object.isFrozen(value)) {
        Object.freeze(value);
        for (const child of Object.values(value))
            deepFreeze(child);
    }
    return value;
}
function frozenClone(value) {
    return deepFreeze(clone(value));
}
function requireScope(scope) {
    if (!Number.isSafeInteger(scope.project) || scope.project <= 0 || !MODULE.test(scope.moduleName)) {
        throw new CandidateRepositoryError(400, 'candidate.invalid_scope');
    }
}
function requireToken(value) {
    if (!TOKEN.test(value))
        throw new CandidateRepositoryError(400, 'candidate.invalid_identifier');
}
function requireHash(value) {
    if (!HASH.test(value))
        throw new CandidateRepositoryError(400, 'candidate.invalid_snapshot_hash');
}
function errorCode(error) {
    if (error instanceof CandidateRepositoryError || error instanceof CandidateGatewayError)
        return error.code;
    return 'candidate.storage_unavailable';
}
function sameScope(left, right) {
    return left.project === right.project && left.moduleName === right.moduleName;
}
function identityOf(input) {
    return { changeId: input.changeId, revisionId: input.revisionId, snapshotHash: input.snapshot.hash };
}
function sameIdentity(left, right) {
    return left.changeId === right.changeId
        && left.revisionId === right.revisionId
        && left.snapshotHash === right.snapshotHash;
}
function samePermit(left, right) {
    if (!left || !right)
        return !left && !right;
    return left.resultId === right.resultId && left.resultHash === right.resultHash
        && left.inputRevisionId === right.inputRevisionId
        && left.inputSnapshotHash === right.inputSnapshotHash
        && left.inputRevisionNumber === right.inputRevisionNumber
        && left.outputSnapshotHash === right.outputSnapshotHash;
}
function matchesPointer(draft, pointer) {
    return draft.changeId === pointer.changeId
        && draft.revisionId === pointer.revisionId
        && draft.snapshotHash === pointer.snapshotHash;
}
export function candidateDraftPrefix(scope) {
    requireScope(scope);
    return `candidate-drafts/${scope.project}/${scope.moduleName}`;
}
export function candidateDraftKey(scope, identity) {
    requireScope(scope);
    requireToken(identity.changeId);
    requireToken(identity.revisionId);
    requireHash(identity.snapshotHash);
    return `${candidateDraftPrefix(scope)}/${identity.changeId}/${identity.revisionId}/${identity.snapshotHash}`;
}
function defaultRequestId() {
    return `request-${crypto.randomUUID()}`;
}
const defaultTransport = {
    read: candidateRead,
    publish: candidatePublish,
};
/**
 * Isolated candidate state machine. It never reads or writes the shared tobe/plan tree.
 * A draft is immutable by identity and remains private until an exact CAS commit wins.
 */
export class CandidateRepository {
    constructor(scope, options) {
        _CandidateRepository_instances.add(this);
        _CandidateRepository_scope.set(this, void 0);
        _CandidateRepository_options.set(this, void 0);
        _CandidateRepository_hasRead.set(this, false);
        _CandidateRepository_state.set(this, {
            phase: 'idle', authoritative: null, draft: null, drafts: [],
            migrationRequired: false, conflict: null, errorCode: null,
        });
        const fixedScope = frozenClone(scope);
        requireScope(fixedScope);
        __classPrivateFieldSet(this, _CandidateRepository_scope, fixedScope, "f");
        __classPrivateFieldSet(this, _CandidateRepository_options, options, "f");
    }
    get state() {
        return clone(__classPrivateFieldGet(this, _CandidateRepository_state, "f"));
    }
    async read() {
        let drafts = [];
        try {
            drafts = await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_loadDrafts).call(this);
            const authoritative = await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_normalizeReadResult).call(this, await (__classPrivateFieldGet(this, _CandidateRepository_options, "f").transport ?? defaultTransport).read(clone(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"))));
            if (authoritative.pointer) {
                for (const draft of drafts.filter(item => matchesPointer(item, authoritative.pointer))) {
                    await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.remove(candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), identityOf(draft)));
                }
                drafts = drafts.filter(item => !matchesPointer(item, authoritative.pointer));
            }
            const migrationRequired = authoritative.pointer === null
                ? await __classPrivateFieldGet(this, _CandidateRepository_options, "f").sealedLegacyExists(clone(__classPrivateFieldGet(this, _CandidateRepository_scope, "f")))
                : false;
            __classPrivateFieldSet(this, _CandidateRepository_hasRead, true, "f");
            __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_settle).call(this, authoritative, drafts, migrationRequired);
            return this.state;
        }
        catch (error) {
            __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_unavailable).call(this, error, drafts);
            throw error;
        }
    }
    async publishWithPermit(input) {
        const fixed = frozenClone(input);
        __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_requireReady).call(this);
        if (__classPrivateFieldGet(this, _CandidateRepository_state, "f").migrationRequired) {
            throw new CandidateRepositoryError(409, 'candidate.migration_required');
        }
        if (!fixed.permit) {
            throw new CandidateRepositoryError(409, 'candidate.result_permit_required');
        }
        return __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_publishFixed).call(this, fixed, false);
    }
    /** Finds an already-submitted private attempt by immutable output identity; no pointer read first. */
    async replaySubmitted(input) {
        const fixed = frozenClone(input);
        requireToken(fixed.changeId);
        requireToken(fixed.revisionId);
        const snapshot = deepFreeze(await verifyCandidateSnapshot(fixed.snapshot));
        const identity = identityOf({ ...fixed, expectedRevisionId: null, snapshot });
        const drafts = await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_loadDrafts).call(this);
        const draft = drafts.find(item => sameIdentity(item, identity));
        if (!draft || draft.status !== 'submitted' || draft.expectedRevisionId === null || !draft.permit)
            return null;
        return this.replayWithPermit({
            expectedRevisionId: draft.expectedRevisionId,
            changeId: fixed.changeId,
            revisionId: fixed.revisionId,
            snapshot,
            permit: clone(draft.permit),
        });
    }
    /** Replays only a durable attempt that already passed checks and reached transport. No read first. */
    async replayWithPermit(input) {
        const fixed = frozenClone(input);
        requireToken(fixed.changeId);
        requireToken(fixed.revisionId);
        requireToken(fixed.expectedRevisionId);
        const snapshot = deepFreeze(await verifyCandidateSnapshot(fixed.snapshot));
        const identity = identityOf({ ...fixed, snapshot });
        const key = candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), identity);
        let drafts = await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_loadDrafts).call(this);
        const draft = drafts.find(item => sameIdentity(item, identity));
        if (!draft || draft.status !== 'submitted')
            return null;
        if (draft.expectedRevisionId !== fixed.expectedRevisionId
            || !samePermit(draft.permit, fixed.permit)) {
            throw new CandidateRepositoryError(409, 'candidate.draft_identity_conflict');
        }
        const wire = __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_wireFromDraft).call(this, draft);
        try {
            __classPrivateFieldSet(this, _CandidateRepository_state, {
                ...__classPrivateFieldGet(this, _CandidateRepository_state, "f"), phase: 'publishing', draft: clone(draft), drafts: clone(drafts),
                conflict: null, errorCode: null,
            }, "f");
            const result = await (__classPrivateFieldGet(this, _CandidateRepository_options, "f").transport ?? defaultTransport).publish(clone(wire));
            if (result.status === 'conflict') {
                __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_requireConflictPointer).call(this, result.pointer);
                const conflict = deepFreeze({ ...draft, status: 'conflict' });
                await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.write(key, clone(conflict));
                await this.read();
                return clone(result);
            }
            await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_acceptCommitted).call(this, result, identity, key);
            return clone(result);
        }
        catch (error) {
            __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_unavailable).call(this, error, await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_safeLoadDrafts).call(this, drafts));
            throw error;
        }
    }
    /** Explicitly imports a sealed legacy snapshot through the same empty-pointer CAS. */
    async migrate(input) {
        const fixed = frozenClone(input);
        __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_requireReady).call(this);
        if (!__classPrivateFieldGet(this, _CandidateRepository_state, "f").migrationRequired || __classPrivateFieldGet(this, _CandidateRepository_state, "f").authoritative?.pointer !== null
            || fixed.expectedRevisionId !== null) {
            throw new CandidateRepositoryError(409, 'candidate.migration_not_required');
        }
        return __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_publishFixed).call(this, fixed, false);
    }
    /**
     * Explicitly supersedes one preserved blocked/conflicting draft. The previous draft is
     * deleted only after the replacement commits; failed replacement attempts preserve both.
     */
    async reconcile(previous, replacement) {
        const fixedPrevious = frozenClone(previous);
        const fixedReplacement = frozenClone(replacement);
        __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_requireReady).call(this);
        const drafts = await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_loadDrafts).call(this);
        const old = drafts.find(item => sameIdentity(item, fixedPrevious));
        if (!old || (old.status !== 'blocked' && old.status !== 'conflict')) {
            throw new CandidateRepositoryError(409, 'candidate.draft_not_reconcilable');
        }
        if (sameIdentity(fixedPrevious, identityOf(fixedReplacement))) {
            throw new CandidateRepositoryError(409, 'candidate.replacement_must_differ');
        }
        const expected = __classPrivateFieldGet(this, _CandidateRepository_state, "f").authoritative?.pointer?.revisionId ?? null;
        if (fixedReplacement.expectedRevisionId !== expected) {
            throw new CandidateRepositoryError(409, 'candidate.stale_reconciliation');
        }
        const result = await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_publishFixed).call(this, fixedReplacement, true);
        if (result.status === 'committed') {
            try {
                await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.remove(candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), fixedPrevious));
                __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_settle).call(this, __classPrivateFieldGet(this, _CandidateRepository_state, "f").authoritative, await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_loadDrafts).call(this), false);
            }
            catch (error) {
                __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_unavailable).call(this, error, await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_safeLoadDrafts).call(this));
                throw error;
            }
        }
        return result;
    }
    /** Explicit local abandonment; it never mutates the authoritative candidate. */
    async discardDraft(identity) {
        const fixed = frozenClone(identity);
        __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_requireReady).call(this);
        const key = candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), fixed);
        const stored = await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.read(key);
        if (!stored)
            throw new CandidateRepositoryError(404, 'candidate.draft_not_found');
        await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_validateStored).call(this, stored, key);
        await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.remove(key);
        __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_settle).call(this, __classPrivateFieldGet(this, _CandidateRepository_state, "f").authoritative, await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_loadDrafts).call(this), __classPrivateFieldGet(this, _CandidateRepository_state, "f").migrationRequired);
    }
}
_CandidateRepository_scope = new WeakMap(), _CandidateRepository_options = new WeakMap(), _CandidateRepository_hasRead = new WeakMap(), _CandidateRepository_state = new WeakMap(), _CandidateRepository_instances = new WeakSet(), _CandidateRepository_publishFixed = async function _CandidateRepository_publishFixed(fixed, allowDifferent) {
    requireToken(fixed.changeId);
    requireToken(fixed.revisionId);
    if (fixed.expectedRevisionId !== null) {
        requireToken(fixed.expectedRevisionId);
        if (!fixed.permit)
            throw new CandidateRepositoryError(409, 'candidate.result_permit_required');
    }
    else if (fixed.permit) {
        throw new CandidateRepositoryError(400, 'candidate.unexpected_result_permit');
    }
    const snapshot = deepFreeze(await verifyCandidateSnapshot(fixed.snapshot));
    const identity = identityOf({ ...fixed, snapshot });
    const key = candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), identity);
    let drafts = await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_loadDrafts).call(this);
    const exact = drafts.find(item => sameIdentity(item, identity));
    const currentRevision = __classPrivateFieldGet(this, _CandidateRepository_state, "f").authoritative?.pointer?.revisionId ?? null;
    if (!allowDifferent && !exact && drafts.some(item => item.status === 'blocked'
        || item.status === 'conflict' || item.expectedRevisionId !== currentRevision)) {
        throw new CandidateRepositoryError(409, 'candidate.explicit_draft_resolution_required');
    }
    if (exact && (exact.expectedRevisionId !== fixed.expectedRevisionId
        || !samePermit(exact.permit, fixed.permit))) {
        throw new CandidateRepositoryError(409, 'candidate.draft_identity_conflict');
    }
    const proposedRequestId = exact?.requestId ?? __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_createRequestId).call(this);
    const proposed = deepFreeze({
        schemaVersion: DRAFT_SCHEMA, ...clone(__classPrivateFieldGet(this, _CandidateRepository_scope, "f")), expectedRevisionId: fixed.expectedRevisionId,
        requestId: proposedRequestId, changeId: fixed.changeId, revisionId: fixed.revisionId,
        snapshotHash: snapshot.hash, snapshot, ...(fixed.permit ? { permit: clone(fixed.permit) } : {}),
        status: exact?.status ?? 'pending',
    });
    let persisted;
    try {
        persisted = exact ?? await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_validateStored).call(this, await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.create(key, clone(proposed)), key);
    }
    catch (error) {
        __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_unavailable).call(this, error, await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_safeLoadDrafts).call(this, drafts));
        throw error;
    }
    if (persisted.expectedRevisionId !== fixed.expectedRevisionId
        || !samePermit(persisted.permit, fixed.permit)) {
        throw new CandidateRepositoryError(409, 'candidate.draft_identity_conflict');
    }
    const requestId = persisted.requestId;
    const wire = deepFreeze({
        ...clone(__classPrivateFieldGet(this, _CandidateRepository_scope, "f")), expectedRevisionId: fixed.expectedRevisionId,
        requestId, changeId: fixed.changeId, revisionId: fixed.revisionId, snapshot,
        ...(fixed.permit ? { permit: clone(fixed.permit) } : {}),
    });
    let draft = deepFreeze({ ...persisted, status: 'pending' });
    try {
        await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.write(key, clone(draft));
        drafts = __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_upsert).call(this, drafts, draft);
        __classPrivateFieldSet(this, _CandidateRepository_state, {
            ...__classPrivateFieldGet(this, _CandidateRepository_state, "f"), phase: 'publishing', draft: clone(draft), drafts: clone(drafts),
            conflict: null, errorCode: null,
        }, "f");
        const inventory = await __classPrivateFieldGet(this, _CandidateRepository_options, "f").inventory(frozenClone(wire));
        if (!inventory.ok)
            return await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_block).call(this, key, draft, drafts, 'candidate.invalid_inventory', inventory.reasons);
        const validation = await __classPrivateFieldGet(this, _CandidateRepository_options, "f").validate(frozenClone(wire));
        if (!validation.ok)
            return await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_block).call(this, key, draft, drafts, 'candidate.validation_failed', validation.reasons);
        draft = deepFreeze({ ...draft, status: 'submitted' });
        await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.write(key, clone(draft));
        drafts = __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_upsert).call(this, drafts, draft);
        const result = await (__classPrivateFieldGet(this, _CandidateRepository_options, "f").transport ?? defaultTransport).publish(clone(wire));
        if (result.status === 'conflict') {
            __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_requireConflictPointer).call(this, result.pointer);
            draft = deepFreeze({ ...draft, status: 'conflict' });
            await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.write(key, clone(draft));
            drafts = __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_upsert).call(this, drafts, draft);
            __classPrivateFieldSet(this, _CandidateRepository_state, {
                ...__classPrivateFieldGet(this, _CandidateRepository_state, "f"), phase: 'conflict', draft: clone(draft), drafts: clone(drafts),
                conflict: clone(result.pointer), errorCode: 'candidate.conflict',
            }, "f");
            return clone(result);
        }
        await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_acceptCommitted).call(this, result, identity, key);
        return clone(result);
    }
    catch (error) {
        if (error instanceof CandidateBlockedError)
            throw error;
        __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_unavailable).call(this, error, await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_safeLoadDrafts).call(this, drafts));
        throw error;
    }
}, _CandidateRepository_wireFromDraft = function _CandidateRepository_wireFromDraft(draft) {
    return deepFreeze({
        ...clone(__classPrivateFieldGet(this, _CandidateRepository_scope, "f")), expectedRevisionId: draft.expectedRevisionId,
        requestId: draft.requestId, changeId: draft.changeId, revisionId: draft.revisionId,
        snapshot: clone(draft.snapshot), ...(draft.permit ? { permit: clone(draft.permit) } : {}),
    });
}, _CandidateRepository_acceptCommitted = async function _CandidateRepository_acceptCommitted(result, identity, key) {
    __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_requireCommitted).call(this, result.pointer, identity);
    const authoritative = await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_normalizeReadResult).call(this, await (__classPrivateFieldGet(this, _CandidateRepository_options, "f").transport ?? defaultTransport).read(clone(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"))));
    if (!authoritative.pointer
        || authoritative.pointer.revisionNumber < result.pointer.revisionNumber) {
        throw new CandidateRepositoryError(502, 'candidate.invalid_response');
    }
    await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.remove(key);
    const remaining = (await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_loadDrafts).call(this)).filter(item => !sameIdentity(item, identity));
    __classPrivateFieldSet(this, _CandidateRepository_hasRead, true, "f");
    __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_settle).call(this, authoritative, remaining, false);
}, _CandidateRepository_block = async function _CandidateRepository_block(key, draft, drafts, code, reasons) {
    const blocked = deepFreeze({ ...draft, status: 'blocked' });
    await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.write(key, clone(blocked));
    const updated = __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_upsert).call(this, drafts, blocked);
    __classPrivateFieldSet(this, _CandidateRepository_state, {
        ...__classPrivateFieldGet(this, _CandidateRepository_state, "f"), phase: 'blocked', draft: clone(blocked), drafts: clone(updated),
        conflict: null, errorCode: code,
    }, "f");
    throw new CandidateBlockedError(422, code, clone(reasons ?? []));
}, _CandidateRepository_createRequestId = function _CandidateRepository_createRequestId() {
    const requestId = (__classPrivateFieldGet(this, _CandidateRepository_options, "f").createRequestId ?? defaultRequestId)();
    requireToken(requestId);
    return requestId;
}, _CandidateRepository_requireReady = function _CandidateRepository_requireReady() {
    if (!__classPrivateFieldGet(this, _CandidateRepository_hasRead, "f") || !__classPrivateFieldGet(this, _CandidateRepository_state, "f").authoritative) {
        throw new CandidateRepositoryError(409, 'candidate.authoritative_read_required');
    }
}, _CandidateRepository_normalizeReadResult = async function _CandidateRepository_normalizeReadResult(result) {
    if (result.status !== 'read' || (result.pointer === null) !== (result.snapshot === null)) {
        throw new CandidateRepositoryError(502, 'candidate.invalid_response');
    }
    if (!result.pointer)
        return { status: 'read', pointer: null, snapshot: null };
    __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_requireConflictPointer).call(this, result.pointer);
    const snapshot = await verifyCandidateSnapshot(result.snapshot);
    if (result.pointer.snapshotHash !== snapshot.hash) {
        throw new CandidateRepositoryError(502, 'candidate.invalid_response');
    }
    return { ...clone(result), pointer: clone(result.pointer), snapshot };
}, _CandidateRepository_requireCommitted = function _CandidateRepository_requireCommitted(pointer, identity) {
    __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_requireConflictPointer).call(this, pointer);
    if (!pointer || !sameIdentity({
        changeId: pointer.changeId, revisionId: pointer.revisionId, snapshotHash: pointer.snapshotHash,
    }, identity))
        throw new CandidateRepositoryError(502, 'candidate.invalid_response');
}, _CandidateRepository_requireConflictPointer = function _CandidateRepository_requireConflictPointer(pointer) {
    if (pointer === null)
        return;
    if (!TOKEN.test(pointer.changeId) || !TOKEN.test(pointer.revisionId) || !HASH.test(pointer.snapshotHash)
        || !Number.isSafeInteger(pointer.revisionNumber) || pointer.revisionNumber < 1) {
        throw new CandidateRepositoryError(502, 'candidate.invalid_response');
    }
}, _CandidateRepository_loadDrafts = async function _CandidateRepository_loadDrafts() {
    const raw = await __classPrivateFieldGet(this, _CandidateRepository_options, "f").store.list(candidateDraftPrefix(__classPrivateFieldGet(this, _CandidateRepository_scope, "f")));
    if (!Array.isArray(raw))
        throw new CandidateRepositoryError(503, 'candidate.draft_store_invalid');
    const drafts = [];
    const identities = new Set();
    for (const item of raw) {
        if (!item || typeof item.key !== 'string' || !item.draft) {
            throw new CandidateRepositoryError(503, 'candidate.invalid_draft');
        }
        const identity = identityOf(item.draft);
        const key = candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), identity);
        if (item.key !== key)
            throw new CandidateRepositoryError(503, 'candidate.invalid_draft');
        const draft = await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_validateStored).call(this, item.draft, key);
        if (identities.has(key))
            throw new CandidateRepositoryError(503, 'candidate.duplicate_draft');
        identities.add(key);
        drafts.push(draft);
    }
    return drafts.sort((left, right) => candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), identityOf(left))
        .localeCompare(candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), identityOf(right))));
}, _CandidateRepository_safeLoadDrafts = async function _CandidateRepository_safeLoadDrafts(fallback = []) {
    try {
        return await __classPrivateFieldGet(this, _CandidateRepository_instances, "m", _CandidateRepository_loadDrafts).call(this);
    }
    catch {
        return clone(fallback);
    }
}, _CandidateRepository_validateStored = async function _CandidateRepository_validateStored(value, expectedKey) {
    if (!value || value.schemaVersion !== DRAFT_SCHEMA || !sameScope(value, __classPrivateFieldGet(this, _CandidateRepository_scope, "f"))
        || (value.status !== 'pending' && value.status !== 'submitted'
            && value.status !== 'blocked' && value.status !== 'conflict')) {
        throw new CandidateRepositoryError(503, 'candidate.invalid_draft');
    }
    requireToken(value.requestId);
    requireToken(value.changeId);
    requireToken(value.revisionId);
    requireHash(value.snapshotHash);
    if (value.expectedRevisionId !== null)
        requireToken(value.expectedRevisionId);
    if (value.expectedRevisionId === null && value.permit) {
        throw new CandidateRepositoryError(503, 'candidate.invalid_draft');
    }
    if (value.expectedRevisionId !== null) {
        if (!value.permit || value.permit.inputRevisionId !== value.expectedRevisionId
            || !TOKEN.test(value.permit.resultId) || !HASH.test(value.permit.resultHash)
            || !TOKEN.test(value.permit.inputRevisionId) || !HASH.test(value.permit.inputSnapshotHash)
            || !Number.isSafeInteger(value.permit.inputRevisionNumber) || value.permit.inputRevisionNumber < 1
            || !HASH.test(value.permit.outputSnapshotHash) || value.permit.outputSnapshotHash !== value.snapshotHash) {
            throw new CandidateRepositoryError(503, 'candidate.invalid_draft');
        }
    }
    const snapshot = await verifyCandidateSnapshot(value.snapshot);
    if (snapshot.hash !== value.snapshotHash
        || candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), identityOf(value)) !== expectedKey) {
        throw new CandidateRepositoryError(503, 'candidate.invalid_draft');
    }
    return deepFreeze({ ...clone(value), snapshot });
}, _CandidateRepository_upsert = function _CandidateRepository_upsert(drafts, draft) {
    return [...drafts.filter(item => !sameIdentity(item, draft)), clone(draft)]
        .sort((left, right) => candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), identityOf(left))
        .localeCompare(candidateDraftKey(__classPrivateFieldGet(this, _CandidateRepository_scope, "f"), identityOf(right))));
}, _CandidateRepository_settle = function _CandidateRepository_settle(authoritative, drafts, migrationRequired) {
    const currentRevision = authoritative.pointer?.revisionId ?? null;
    const conflict = drafts.find(item => item.status === 'conflict' || item.expectedRevisionId !== currentRevision);
    const blocked = drafts.find(item => item.status === 'blocked');
    const selected = conflict ?? blocked ?? drafts[0] ?? null;
    __classPrivateFieldSet(this, _CandidateRepository_state, {
        phase: conflict ? 'conflict' : blocked ? 'blocked' : drafts.length ? 'draft' : 'ready',
        authoritative: clone(authoritative), draft: clone(selected), drafts: clone(drafts),
        migrationRequired, conflict: conflict ? clone(authoritative.pointer) : null,
        errorCode: conflict ? 'candidate.conflict' : blocked ? 'candidate.validation_blocked' : null,
    }, "f");
}, _CandidateRepository_unavailable = function _CandidateRepository_unavailable(error, drafts) {
    __classPrivateFieldSet(this, _CandidateRepository_state, {
        ...__classPrivateFieldGet(this, _CandidateRepository_state, "f"), phase: 'unavailable', draft: clone(drafts[0] ?? __classPrivateFieldGet(this, _CandidateRepository_state, "f").draft),
        drafts: clone(drafts), migrationRequired: false, conflict: null, errorCode: errorCode(error),
    }, "f");
};
