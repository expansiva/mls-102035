/// <mls fileReference="_102035_/l2/newRelease/helpers/backendReader.ts" enhancement="_blank" />
import { normalizeModuleName, readJson } from '/_102035_/l2/solution/fs.js';
export function reviewArtifactFile(project, moduleName, name, root) {
    return {
        project,
        level: 4,
        folder: `${root || normalizeModuleName(moduleName)}/pool/l2/web`,
        shortName: name,
        extension: '.json',
    };
}
export async function readReviewArtifact(project, moduleName, name, root) {
    const file = reviewArtifactFile(project, moduleName, name, root);
    const path = `l4/${file.folder}/${file.shortName}${file.extension}`;
    if (!project || !moduleName)
        return { status: 'missing', path };
    const stored = mls.stor.files[mls.stor.getKeyToFile(file)];
    if (!stored || stored.status === 'deleted')
        return { status: 'missing', path };
    try {
        const value = await readJson(file);
        return value === null ? { status: 'invalid', path } : { status: 'ok', path, value };
    }
    catch {
        return { status: 'invalid', path };
    }
}
