/// <mls fileReference="_102035_/l2/newRelease/helpers/studioCandidateAdapter.ts" enhancement="_blank" />
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _StudioCandidateAdapter_instances, _StudioCandidateAdapter_scope, _StudioCandidateAdapter_legacy, _StudioCandidateAdapter_checks, _StudioCandidateAdapter_repository, _StudioCandidateAdapter_checkExactLegacy, _StudioCandidateAdapter_checkPermit, _StudioCandidateAdapter_readLegacy;
import { buildCandidateSnapshot, } from './candidateGateway.js';
import { IndexedDbCandidateDraftStore } from './candidateDraftStore.js';
import { CandidateRepository, CandidateRepositoryError, } from './candidateRepository.js';
import { L4SealedCandidateError, readActiveSealedL4Candidate, withModuleWriter, } from './moduleRevision.js';
const CHECK_REQUIRED = 'candidate.finalize50_check_required';
const ordinal = (left, right) => left < right ? -1 : left > right ? 1 : 0;
function deepFreeze(value) {
    if (value && typeof value === 'object' && !Object.isFrozen(value)) {
        Object.freeze(value);
        for (const child of Object.values(value))
            deepFreeze(child);
    }
    return value;
}
function frozenClone(value) {
    return deepFreeze(structuredClone(value));
}
const productionLegacyReader = {
    read: scope => readActiveSealedL4Candidate(scope.project, scope.moduleName),
    withStableCandidate: (scope, work) => withModuleWriter(scope.project, scope.moduleName, work),
};
function sameSnapshotInput(input, sealed, snapshotHash) {
    return input.changeId === sealed.manifest.changeId
        && input.revisionId === sealed.manifest.revisionId
        && input.snapshot.baseId === sealed.manifest.baseId
        && input.snapshot.requestRevision === sealed.manifest.requestRevision
        && input.snapshot.hash === snapshotHash;
}
/**
 * Production Studio boundary for authoritative candidate reads and explicit legacy migration.
 * Ordinary edit publication is intentionally not exposed until finalize50 provides a checked permit.
 */
export class StudioCandidateAdapter {
    constructor(scope, options = {}) {
        _StudioCandidateAdapter_instances.add(this);
        _StudioCandidateAdapter_scope.set(this, void 0);
        _StudioCandidateAdapter_legacy.set(this, void 0);
        _StudioCandidateAdapter_checks.set(this, void 0);
        _StudioCandidateAdapter_repository.set(this, void 0);
        __classPrivateFieldSet(this, _StudioCandidateAdapter_scope, frozenClone(scope), "f");
        __classPrivateFieldSet(this, _StudioCandidateAdapter_legacy, options.legacy ?? productionLegacyReader, "f");
        __classPrivateFieldSet(this, _StudioCandidateAdapter_checks, options.checks ?? null, "f");
        const store = options.store ?? new IndexedDbCandidateDraftStore(options.indexedDb);
        __classPrivateFieldSet(this, _StudioCandidateAdapter_repository, new CandidateRepository(__classPrivateFieldGet(this, _StudioCandidateAdapter_scope, "f"), {
            store,
            ...(options.transport ? { transport: options.transport } : {}),
            ...(options.createRequestId ? { createRequestId: options.createRequestId } : {}),
            sealedLegacyExists: async () => (await __classPrivateFieldGet(this, _StudioCandidateAdapter_instances, "m", _StudioCandidateAdapter_readLegacy).call(this)) !== null,
            inventory: input => input.permit
                ? __classPrivateFieldGet(this, _StudioCandidateAdapter_instances, "m", _StudioCandidateAdapter_checkPermit).call(this, input)
                : __classPrivateFieldGet(this, _StudioCandidateAdapter_instances, "m", _StudioCandidateAdapter_checkExactLegacy).call(this, 'inventory', input),
            validate: input => input.permit
                ? __classPrivateFieldGet(this, _StudioCandidateAdapter_instances, "m", _StudioCandidateAdapter_checkPermit).call(this, input)
                : __classPrivateFieldGet(this, _StudioCandidateAdapter_instances, "m", _StudioCandidateAdapter_checkExactLegacy).call(this, 'validate', input),
        }), "f");
    }
    get state() {
        return __classPrivateFieldGet(this, _StudioCandidateAdapter_repository, "f").state;
    }
    /** Same-origin authenticated read. Failure never falls back to the mutable legacy mirror. */
    read() {
        return __classPrivateFieldGet(this, _StudioCandidateAdapter_repository, "f").read();
    }
    /** Retries an already-submitted durable draft before any authoritative pointer gate. */
    replaySubmitted(input) {
        return __classPrivateFieldGet(this, _StudioCandidateAdapter_repository, "f").replaySubmitted(frozenClone(input));
    }
    /** Publishes only through a fresh, authoritative and still-current completed-result permit. */
    async publishWithPermit(input) {
        const fixed = frozenClone(input);
        const wire = {
            expectedRevisionId: fixed.permit.inputRevisionId,
            changeId: fixed.changeId,
            revisionId: fixed.revisionId,
            snapshot: fixed.snapshot,
            permit: fixed.permit,
        };
        const replayed = await __classPrivateFieldGet(this, _StudioCandidateAdapter_repository, "f").replayWithPermit(wire);
        if (replayed)
            return replayed;
        await __classPrivateFieldGet(this, _StudioCandidateAdapter_repository, "f").read();
        const checked = await __classPrivateFieldGet(this, _StudioCandidateAdapter_instances, "m", _StudioCandidateAdapter_checkPermit).call(this, wire);
        if (!checked.ok) {
            throw new CandidateRepositoryError(409, checked.reasons?.[0] ?? 'candidate.result_permit_mismatch');
        }
        return __classPrivateFieldGet(this, _StudioCandidateAdapter_repository, "f").publishWithPermit(wire);
    }
    /**
     * Explicit, non-destructive import of the active sealed legacy revision. It never deletes or
     * rewrites the legacy revision/tobe tree. Without both injected checks it blocks before POST.
     */
    migrateLegacy() {
        return __classPrivateFieldGet(this, _StudioCandidateAdapter_legacy, "f").withStableCandidate(structuredClone(__classPrivateFieldGet(this, _StudioCandidateAdapter_scope, "f")), async () => {
            await __classPrivateFieldGet(this, _StudioCandidateAdapter_repository, "f").read();
            const sealed = await __classPrivateFieldGet(this, _StudioCandidateAdapter_instances, "m", _StudioCandidateAdapter_readLegacy).call(this);
            if (!sealed)
                throw new CandidateRepositoryError(409, 'candidate.sealed_legacy_required');
            const snapshot = await buildCandidateSnapshot({
                baseId: sealed.manifest.baseId,
                requestRevision: sealed.manifest.requestRevision,
                request: sealed.request,
                sources: sealed.sources,
            });
            return __classPrivateFieldGet(this, _StudioCandidateAdapter_repository, "f").migrate({
                expectedRevisionId: null,
                changeId: sealed.manifest.changeId,
                revisionId: sealed.manifest.revisionId,
                snapshot,
            });
        });
    }
}
_StudioCandidateAdapter_scope = new WeakMap(), _StudioCandidateAdapter_legacy = new WeakMap(), _StudioCandidateAdapter_checks = new WeakMap(), _StudioCandidateAdapter_repository = new WeakMap(), _StudioCandidateAdapter_instances = new WeakSet(), _StudioCandidateAdapter_checkExactLegacy = async function _StudioCandidateAdapter_checkExactLegacy(kind, input) {
    const sealed = await __classPrivateFieldGet(this, _StudioCandidateAdapter_instances, "m", _StudioCandidateAdapter_readLegacy).call(this);
    if (!sealed)
        return { ok: false, reasons: ['candidate.sealed_legacy_required'] };
    const snapshot = await buildCandidateSnapshot({
        baseId: sealed.manifest.baseId,
        requestRevision: sealed.manifest.requestRevision,
        request: sealed.request,
        sources: sealed.sources,
    });
    if (!sameSnapshotInput(input, sealed, snapshot.hash)) {
        return { ok: false, reasons: ['candidate.legacy_snapshot_changed'] };
    }
    if (!__classPrivateFieldGet(this, _StudioCandidateAdapter_checks, "f"))
        return { ok: false, reasons: [CHECK_REQUIRED] };
    return __classPrivateFieldGet(this, _StudioCandidateAdapter_checks, "f")[kind](structuredClone(input));
}, _StudioCandidateAdapter_checkPermit = async function _StudioCandidateAdapter_checkPermit(input) {
    const permit = input.permit;
    const authoritative = __classPrivateFieldGet(this, _StudioCandidateAdapter_repository, "f").state.authoritative;
    const pointer = authoritative?.pointer;
    const inputSnapshot = authoritative?.snapshot;
    const result = authoritative && 'result' in authoritative ? authoritative.result : undefined;
    if (!permit || !pointer || !inputSnapshot || !result || result.manifest.status !== 'completed'
        || input.expectedRevisionId !== permit.inputRevisionId
        || pointer.revisionId !== permit.inputRevisionId
        || pointer.snapshotHash !== permit.inputSnapshotHash
        || pointer.revisionNumber !== permit.inputRevisionNumber
        || pointer.resultRevisionId !== permit.inputRevisionId
        || pointer.resultSnapshotHash !== permit.inputSnapshotHash
        || pointer.resultRevisionNumber !== permit.inputRevisionNumber
        || pointer.resultId !== permit.resultId || pointer.resultHash !== permit.resultHash
        || result.resultId !== permit.resultId || result.resultHash !== permit.resultHash
        || result.manifest.outputSnapshotHash !== permit.outputSnapshotHash
        || input.snapshot.hash !== permit.outputSnapshotHash) {
        return { ok: false, reasons: ['candidate.result_permit_mismatch'] };
    }
    const files = input.snapshot.files.map(({ path, sha256 }) => ({ path, sha256 }))
        .sort((left, right) => ordinal(left.path, right.path));
    const artifacts = result.manifest.artifacts.map(({ path, sha256 }) => ({ path, sha256 }))
        .sort((left, right) => ordinal(left.path, right.path));
    const inputPaths = inputSnapshot.files.map(({ path }) => path).sort(ordinal);
    const outputPaths = files.map(({ path }) => path).sort(ordinal);
    return JSON.stringify(inputPaths) === JSON.stringify(outputPaths)
        && JSON.stringify(files) === JSON.stringify(artifacts)
        ? { ok: true }
        : { ok: false, reasons: ['candidate.result_permit_artifacts_mismatch'] };
}, _StudioCandidateAdapter_readLegacy = async function _StudioCandidateAdapter_readLegacy() {
    try {
        return await __classPrivateFieldGet(this, _StudioCandidateAdapter_legacy, "f").read(structuredClone(__classPrivateFieldGet(this, _StudioCandidateAdapter_scope, "f")));
    }
    catch (error) {
        if (error instanceof L4SealedCandidateError) {
            throw new CandidateRepositoryError(409, error.code);
        }
        throw error;
    }
};
export function createStudioCandidateAdapter(scope, options = {}) {
    return new StudioCandidateAdapter(scope, options);
}
