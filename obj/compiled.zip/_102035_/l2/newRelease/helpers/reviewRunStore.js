/// <mls fileReference="_102035_/l2/newRelease/helpers/reviewRunStore.ts" enhancement="_blank" />
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _IndexedDbReviewRunStore_instances, _IndexedDbReviewRunStore_factory, _IndexedDbReviewRunStore_databaseName, _IndexedDbReviewRunStore_databasePromise, _IndexedDbReviewRunStore_database, _IndexedDbReviewRunStore_request;
import { assertBoundReviewResult, assertReviewRunUpdate, reviewRunBindingEquals, reviewRunKey, verifyReviewRunDraft, verifyReviewRunRecord, } from './reviewRun.js';
export class ReviewRunStoreError extends Error {
    constructor(code) {
        super(code);
        this.code = code;
        this.name = 'ReviewRunStoreError';
    }
}
export const STUDIO_REVIEW_RUN_DATABASE = 'collab-new-release-review-runs-v3';
const STORE_NAME = 'runs';
const DATABASE_VERSION = 1;
function clone(value) { return structuredClone(value); }
function unavailable() { return new ReviewRunStoreError('review-run.store_unavailable'); }
function deepFreeze(value) {
    if (value && typeof value === 'object' && !Object.isFrozen(value)) {
        Object.freeze(value);
        for (const item of Object.values(value))
            deepFreeze(item);
    }
    return value;
}
function migrateStoredRun(value) {
    if (!value || typeof value !== 'object')
        throw new Error('review-run.invalid_record');
    const raw = clone(value);
    if (raw.schemaVersion === '2026-09-21-review-run-v4') {
        return raw;
    }
    if (raw.schemaVersion !== '2026-09-21-review-run-v3')
        throw new Error('review-run.invalid_record');
    const legacy = raw;
    const terminal = legacy.state === 'ready' || legacy.state === 'stale'
        ? 'ready'
        : legacy.state === 'failed' || legacy.state === 'disputed' ? legacy.state : 'running';
    const run = {
        schemaVersion: '2026-09-21-review-run-v4',
        binding: legacy.binding,
        request: legacy.request,
        runId: legacy.runId,
        requestId: legacy.requestId,
        status: legacy.state === 'draft' ? 'planning' : terminal,
        phase: legacy.state === 'draft' || legacy.state === 'submitting' || legacy.state === 'reviewing'
            ? 'reviewing'
            : legacy.state === 'ready' || legacy.state === 'stale' ? 'finalizing' : 'planning',
        superseded: legacy.archivePending || legacy.state === 'stale',
        storeRevision: legacy.storeRevision,
        attemptsUsed: legacy.attemptsUsed,
        taskId: legacy.taskId,
        threadId: legacy.threadId,
        output: legacy.output,
        errorCode: legacy.state === 'stale' || legacy.archivePending ? null : legacy.errorCode,
        createdAt: legacy.createdAt,
        updatedAt: legacy.updatedAt,
    };
    return run;
}
async function normalizeStoredRun(value) {
    const run = migrateStoredRun(value);
    await verifyReviewRunRecord(run);
    return run;
}
export class IndexedDbReviewRunStore {
    constructor(factory = globalThis.indexedDB, databaseName = STUDIO_REVIEW_RUN_DATABASE) {
        _IndexedDbReviewRunStore_instances.add(this);
        _IndexedDbReviewRunStore_factory.set(this, void 0);
        _IndexedDbReviewRunStore_databaseName.set(this, void 0);
        _IndexedDbReviewRunStore_databasePromise.set(this, null);
        __classPrivateFieldSet(this, _IndexedDbReviewRunStore_factory, factory, "f");
        __classPrivateFieldSet(this, _IndexedDbReviewRunStore_databaseName, databaseName, "f");
    }
    async read(binding) {
        const key = reviewRunKey(binding);
        const row = await __classPrivateFieldGet(this, _IndexedDbReviewRunStore_instances, "m", _IndexedDbReviewRunStore_request).call(this, 'readonly', store => store.get(key));
        if (!row)
            return null;
        return clone(await normalizeStoredRun(row.run));
    }
    async create(run) {
        // No caller mutation can race hashing or the IndexedDB transaction.
        const fixed = deepFreeze(clone(run));
        await verifyReviewRunDraft(fixed);
        const key = reviewRunKey(fixed.binding);
        const database = await __classPrivateFieldGet(this, _IndexedDbReviewRunStore_instances, "m", _IndexedDbReviewRunStore_database).call(this);
        const selected = await new Promise((resolve, reject) => {
            const transaction = database.transaction(STORE_NAME, 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            let value = null;
            let failure = null;
            let settled = false;
            const finishReject = (error) => { if (!settled) {
                settled = true;
                reject(error);
            } };
            const finishResolve = (result) => { if (!settled) {
                settled = true;
                resolve(clone(result));
            } };
            const abort = (error) => {
                failure = failure ?? error;
                try {
                    transaction.abort();
                }
                catch {
                    finishReject(failure);
                }
            };
            const get = store.get(key);
            get.onsuccess = () => {
                const existing = get.result;
                if (existing) {
                    if (!reviewRunBindingEquals(existing.run.binding, fixed.binding)) {
                        abort(new ReviewRunStoreError('review-run.revision_already_bound'));
                        return;
                    }
                    try {
                        value = clone(migrateStoredRun(existing.run));
                    }
                    catch (error) {
                        abort(error);
                    }
                    return;
                }
                value = clone(fixed);
                const add = store.add({ key, run: clone(fixed) });
                add.onerror = () => abort(unavailable());
            };
            get.onerror = () => abort(unavailable());
            transaction.oncomplete = () => value ? finishResolve(value) : finishReject(failure ?? unavailable());
            transaction.onerror = () => finishReject(failure ?? unavailable());
            transaction.onabort = () => finishReject(failure ?? unavailable());
        });
        await verifyReviewRunRecord(selected);
        return selected;
    }
    async compareAndSwap(expectedStoreRevision, next) {
        const fixed = deepFreeze(clone(next));
        await verifyReviewRunRecord(fixed);
        const key = reviewRunKey(fixed.binding);
        const database = await __classPrivateFieldGet(this, _IndexedDbReviewRunStore_instances, "m", _IndexedDbReviewRunStore_database).call(this);
        const result = await new Promise((resolve, reject) => {
            const transaction = database.transaction(STORE_NAME, 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            let value = null;
            let failure = null;
            let settled = false;
            const finishReject = (error) => { if (!settled) {
                settled = true;
                reject(error);
            } };
            const finishResolve = (current) => {
                if (!settled) {
                    settled = true;
                    resolve({ committed: current.committed, current: clone(current.current) });
                }
            };
            const abort = (error) => {
                failure = failure ?? error;
                try {
                    transaction.abort();
                }
                catch {
                    finishReject(failure);
                }
            };
            const get = store.get(key);
            get.onsuccess = () => {
                const existing = get.result;
                if (!existing) {
                    abort(new ReviewRunStoreError('review-run.not_found'));
                    return;
                }
                let current;
                try {
                    current = migrateStoredRun(existing.run);
                }
                catch (error) {
                    abort(error);
                    return;
                }
                if (current.storeRevision !== expectedStoreRevision) {
                    value = { committed: false, current: clone(current) };
                    return;
                }
                try {
                    assertReviewRunUpdate(current, fixed);
                }
                catch (error) {
                    abort(error);
                    return;
                }
                value = { committed: true, current: clone(fixed) };
                const put = store.put({ key, run: clone(fixed) });
                put.onerror = () => abort(unavailable());
            };
            get.onerror = () => abort(unavailable());
            transaction.oncomplete = () => value ? finishResolve(value) : finishReject(failure ?? unavailable());
            transaction.onerror = () => finishReject(failure ?? unavailable());
            transaction.onabort = () => finishReject(failure ?? unavailable());
        });
        await verifyReviewRunRecord(result.current);
        return result;
    }
}
_IndexedDbReviewRunStore_factory = new WeakMap(), _IndexedDbReviewRunStore_databaseName = new WeakMap(), _IndexedDbReviewRunStore_databasePromise = new WeakMap(), _IndexedDbReviewRunStore_instances = new WeakSet(), _IndexedDbReviewRunStore_database = async function _IndexedDbReviewRunStore_database() {
    if (!__classPrivateFieldGet(this, _IndexedDbReviewRunStore_factory, "f"))
        throw unavailable();
    if (!__classPrivateFieldGet(this, _IndexedDbReviewRunStore_databasePromise, "f")) {
        __classPrivateFieldSet(this, _IndexedDbReviewRunStore_databasePromise, new Promise((resolve, reject) => {
            const request = __classPrivateFieldGet(this, _IndexedDbReviewRunStore_factory, "f").open(__classPrivateFieldGet(this, _IndexedDbReviewRunStore_databaseName, "f"), DATABASE_VERSION);
            request.onupgradeneeded = () => {
                if (!request.result.objectStoreNames.contains(STORE_NAME))
                    request.result.createObjectStore(STORE_NAME, { keyPath: 'key' });
            };
            request.onsuccess = () => {
                request.result.onversionchange = () => request.result.close();
                resolve(request.result);
            };
            request.onerror = () => reject(unavailable());
            request.onblocked = () => reject(unavailable());
        }), "f");
    }
    try {
        return await __classPrivateFieldGet(this, _IndexedDbReviewRunStore_databasePromise, "f");
    }
    catch (error) {
        __classPrivateFieldSet(this, _IndexedDbReviewRunStore_databasePromise, null, "f");
        throw error;
    }
}, _IndexedDbReviewRunStore_request = async function _IndexedDbReviewRunStore_request(mode, operation) {
    const database = await __classPrivateFieldGet(this, _IndexedDbReviewRunStore_instances, "m", _IndexedDbReviewRunStore_database).call(this);
    return new Promise((resolve, reject) => {
        const transaction = database.transaction(STORE_NAME, mode);
        let settled = false;
        const finishReject = () => { if (!settled) {
            settled = true;
            reject(unavailable());
        } };
        const request = operation(transaction.objectStore(STORE_NAME));
        request.onsuccess = () => { if (!settled) {
            settled = true;
            resolve(request.result);
        } };
        request.onerror = finishReject;
        transaction.onerror = finishReject;
        transaction.onabort = finishReject;
    });
};
export async function readBoundReviewResult(store, expected) {
    const run = await store.read(expected);
    if (!run)
        throw new ReviewRunStoreError('review-run.not_found');
    const { runId: _runId, outputSnapshotHash: _hash, ...binding } = expected;
    if (!reviewRunBindingEquals(run.binding, binding))
        throw new ReviewRunStoreError('review-run.result_binding_mismatch');
    return assertBoundReviewResult(run, expected);
}
