/// <mls fileReference="_102035_/l2/newRelease/helpers/reviewRunMessageTransport.ts" enhancement="_blank" />
const CENTRAL_MESSAGES_ENDPOINT = 'https://msg.collab.codes/msg';
function isLoopback(hostname) {
    const normalized = hostname.toLowerCase().replace(/^\[|\]$/gu, '');
    return normalized === 'localhost' || normalized.endsWith('.localhost')
        || normalized === '::1' || normalized === '0.0.0.0' || /^127(?:\.\d{1,3}){3}$/u.test(normalized);
}
/** Local Studio owns the authenticated cauth cookie, so its same-origin /msg proxy is authoritative. */
export function resolveReviewMessageRoute(runtime) {
    if (isLoopback(runtime.hostname) && runtime.configuredUrl === CENTRAL_MESSAGES_ENDPOINT) {
        return {
            url: new URL('/msg', runtime.origin).toString(),
            credentials: 'same-origin',
            useConfiguredPost: false,
        };
    }
    return {
        url: runtime.configuredUrl,
        credentials: runtime.configuredCredentials,
        useConfiguredPost: true,
    };
}
export async function postReviewMessage(args, runtime, dependencies) {
    const route = resolveReviewMessageRoute(runtime);
    if (route.useConfiguredPost)
        return dependencies.configuredPost(args);
    const response = await dependencies.fetchImpl(route.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(args),
        credentials: route.credentials,
    });
    if (response.status !== 200)
        throw await dependencies.errorFromResponse(response, args);
    const data = await response.json();
    if (!data)
        throw new Error('No data on cbePost');
    return data;
}
