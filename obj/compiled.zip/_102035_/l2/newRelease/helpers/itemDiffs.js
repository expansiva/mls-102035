/// <mls fileReference="_102035_/l2/newRelease/helpers/itemDiffs.ts" enhancement="_blank" />
/** Match a JSON member boundary, so `taskId=one` never marks `taskId=oneMore`. */
export function hasItemDiff(diffs, path, selectors) {
    const scopes = typeof selectors === 'string' ? [selectors] : selectors;
    return diffs.some(diff => diff.path === path && diff.entries.some(entry => {
        const jsonPath = entry.jsonPath;
        if (jsonPath === '$.businessHash')
            return false;
        if (!scopes)
            return true;
        if (jsonPath === '$')
            return true;
        return scopes.some(scope => jsonPath === scope || jsonPath.startsWith(`${scope}.`) || jsonPath.startsWith(`${scope}[`));
    }));
}
export function idScope(array, key, id) {
    return `$.${array}[${key}=${encodeURIComponent(id)}]`;
}
export function ontologyFieldScope(fieldPath, v3) {
    if (!v3)
        return idScope('fields', 'fieldId', fieldPath);
    return `$.record.fields.${fieldPath.split('.').join('.fields.')}`;
}
export function ruleScopes(id) {
    return [`$.rules.${id}`, idScope('rules', 'ruleId', id)];
}
/** Resolve the diff's data index to a stable pluginId; a full record takes precedence. */
export function hasPluginDiff(diffs, plugins, pluginId) {
    if (!pluginId)
        return false;
    const matchRecord = (value) => !!value && typeof value === 'object' && !Array.isArray(value)
        && value.pluginId === pluginId;
    return diffs.some(diff => diff.path === 'integration.defs.ts' && diff.entries.some(entry => {
        if (entry.jsonPath === '$') {
            const before = entry.before?.plugins || [];
            const after = entry.after?.plugins || [];
            return [...before, ...after].some(matchRecord);
        }
        const match = /^\$\.plugins\[(\d+)\](?:\.|\[|$)/u.exec(entry.jsonPath);
        if (!match)
            return false;
        if (entry.jsonPath === `$.plugins[${match[1]}]`)
            return matchRecord(entry.before) || matchRecord(entry.after);
        if (entry.jsonPath === `$.plugins[${match[1]}].pluginId`)
            return entry.before === pluginId || entry.after === pluginId;
        return plugins[Number(match[1])]?.pluginId === pluginId;
    }));
}
