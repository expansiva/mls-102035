/// <mls fileReference="_102035_/l2/newRelease/helpers/reviewStart.ts" enhancement="_blank" />
import { buildCandidateSnapshot, candidatePublish, candidateRead, } from '/_102035_/l2/solution/candidate/candidateGateway.js';
import { readActiveSealedL4Candidate } from '/_102035_/l2/solution/candidate/moduleRevision.js';
import { sameReviewStartSnapshot } from '../widgets/review/reviewModel.js';
export async function prepareReviewStartInput(context, dependencies = {}) {
    const { project, moduleName, changeId, revisionId, request, userId, loaded } = structuredClone(context);
    if (!changeId || !revisionId || !userId || !request.trim())
        throw new Error('review-run.invalid_request');
    const sealed = await (dependencies.readActive ?? readActiveSealedL4Candidate)(project, moduleName);
    if (!sealed || sealed.request !== request || !sealed.manifest.requestHash
        || sealed.manifest.changeId !== changeId || sealed.manifest.revisionId !== revisionId
        || !sameReviewStartSnapshot(loaded, sealed)) {
        throw new Error('review-run.revision_mismatch');
    }
    const snapshot = await (dependencies.buildSnapshot ?? buildCandidateSnapshot)({
        baseId: sealed.manifest.baseId,
        requestRevision: sealed.manifest.requestRevision,
        request: sealed.request,
        sources: sealed.sources,
    });
    const candidate = await (dependencies.readCandidate ?? candidateRead)({ project, moduleName });
    const pointer = candidate.pointer;
    let supersededRevisionId;
    let publishedPointer = null;
    if (!pointer || pointer.changeId !== changeId || pointer.revisionId !== revisionId
        || pointer.snapshotHash !== snapshot.hash) {
        const published = await (dependencies.publishCandidate ?? candidatePublish)({
            project,
            moduleName,
            expectedRevisionId: pointer?.revisionId ?? null,
            requestId: `review-start-${revisionId}`,
            changeId,
            revisionId,
            snapshot,
            ...(pointer ? { supersede: { changeId: pointer.changeId, revisionId: pointer.revisionId } } : {}),
        });
        if (published.status === 'conflict')
            throw new Error('review-run.hub_publish_conflict');
        if (published.status !== 'committed' || published.pointer?.changeId !== changeId
            || published.pointer.revisionId !== revisionId
            || published.pointer.snapshotHash !== snapshot.hash) {
            throw new Error('review-run.hub_publish_conflict');
        }
        if (pointer) {
            const prior = published.pointer.supersedes;
            if (!prior || prior.changeId !== pointer.changeId || prior.revisionId !== pointer.revisionId
                || prior.revisionNumber !== pointer.revisionNumber)
                throw new Error('review-run.hub_publish_conflict');
            supersededRevisionId = prior.revisionId;
        }
        publishedPointer = published.pointer;
    }
    const activePointer = pointer && pointer.changeId === changeId && pointer.revisionId === revisionId
        && pointer.snapshotHash === snapshot.hash
        ? pointer
        : publishedPointer;
    if (!activePointer || !Number.isSafeInteger(activePointer.revisionNumber) || activePointer.revisionNumber < 1
        || sealed.request.length > 65536) {
        throw new Error('review-run.invalid_request');
    }
    return {
        userId,
        ...(supersededRevisionId ? { supersededRevisionId } : {}),
        input: {
            userId,
            project,
            moduleName,
            changeId,
            inputRevisionId: revisionId,
            inputRevisionNumber: activePointer.revisionNumber,
            inputSnapshotHash: `sha256:${snapshot.hash}`,
            baseId: sealed.manifest.baseId,
            requestRevision: sealed.manifest.requestRevision,
            requestHash: sealed.manifest.requestHash,
            request: sealed.request,
        },
    };
}
/** Exact handler seam: start is unreachable when authoritative preparation refuses the click. */
export async function executePreparedReviewStart(prepare, start) {
    const prepared = await prepare();
    return { prepared, run: await start(prepared.input) };
}
