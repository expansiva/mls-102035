/// <mls fileReference="_102035_/l2/newRelease/helpers/reviewStart.ts" enhancement="_blank" />
import { buildCandidateSnapshot } from './candidateGateway.js';
import { readActiveSealedL4Candidate } from './moduleRevision.js';
import { sameReviewStartSnapshot } from '../widgets/reviewModel.js';
export async function prepareReviewStartInput(context, dependencies = {}) {
    const { project, moduleName, changeId, revisionId, request, userId, loaded } = structuredClone(context);
    if (!changeId || !revisionId || !userId || !request.trim())
        throw new Error('review-run.invalid_request');
    const sealed = await (dependencies.readActive ?? readActiveSealedL4Candidate)(project, moduleName);
    if (!sealed || sealed.request !== request || !sealed.manifest.requestHash
        || sealed.manifest.changeId !== changeId || sealed.manifest.revisionId !== revisionId
        || !sameReviewStartSnapshot(loaded, sealed)) {
        throw new Error('review-run.revision_mismatch');
    }
    const snapshot = await (dependencies.buildSnapshot ?? buildCandidateSnapshot)({
        baseId: sealed.manifest.baseId,
        requestRevision: sealed.manifest.requestRevision,
        request: sealed.request,
        sources: sealed.sources,
    });
    return {
        userId,
        input: {
            userId,
            project,
            moduleName,
            changeId,
            inputRevisionId: revisionId,
            inputSnapshotHash: `sha256:${snapshot.hash}`,
            baseId: sealed.manifest.baseId,
            requestRevision: sealed.manifest.requestRevision,
            requestHash: sealed.manifest.requestHash,
        },
    };
}
/** Exact handler seam: start is unreachable when authoritative preparation refuses the click. */
export async function executePreparedReviewStart(prepare, start) {
    const prepared = await prepare();
    return { prepared, run: await start(prepared.input) };
}
