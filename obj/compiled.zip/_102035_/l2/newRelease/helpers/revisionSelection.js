/// <mls fileReference="_102035_/l2/newRelease/helpers/revisionSelection.ts" enhancement="_blank" />
import { readJson, readSourceText, writeSourceText } from '/_102035_/l2/solution/fs.js';
import { historicalReleaseId } from '/_102035_/l2/newRelease/helpers/context.js';
import { deactivateL4Change, editL4Candidate, originalL4FileInfo, prepareL4Change, readActiveL4Change, readL4Release, sealL4Revision, } from '/_102035_/l2/newRelease/helpers/moduleRevision.js';
import { normalizeTobeArtifactPath, tobeArtifactFileInfo } from '/_102035_/l2/newRelease/tobe.js';
export class ChangeRequestDrafts {
    constructor() {
        this.drafts = new Map();
    }
    static key(project, moduleName, changeId) {
        return `${project}/${moduleName}/${changeId ?? 'new'}`;
    }
    remember(key, text, saved) {
        if (key && text !== saved)
            this.drafts.set(key, { text, saved });
    }
    restore(key, persisted) {
        const draft = this.drafts.get(key);
        if (!draft)
            return null;
        if (draft.saved !== persisted) {
            this.drafts.delete(key);
            return null;
        }
        return draft.text;
    }
    forget(key) {
        if (key)
            this.drafts.delete(key);
    }
    move(from, to) {
        if (from === to)
            return;
        const draft = this.drafts.get(from);
        if (!draft)
            return;
        if (!this.drafts.has(to))
            this.drafts.set(to, draft);
        this.drafts.delete(from);
    }
}
export function revisionsForKnob(releases) {
    return ['asis', 'tobe', ...releases.map(release => release.version)];
}
export function selectedRevisionIndex(versions, selected) {
    const index = versions.indexOf(selected);
    return index < 0 ? 1 : index + 1;
}
export function contextStillCurrent(expected, current) {
    return expected.project === current.project && expected.moduleName === current.moduleName && expected.version === current.version;
}
export async function listReleaseChoices(project, moduleName) {
    const catalog = await readJson({ project, level: 4, folder: `${moduleName}/pipeline/releases`, shortName: 'index', extension: '.json' });
    const valid = await Promise.all((catalog?.releases ?? []).map(async (entry) => {
        const release = await readL4Release(project, moduleName, entry.baseId);
        return release ? { version: `release:${release.baseId}`, baseId: release.baseId, createdAt: release.createdAt, provenance: release.provenance } : null;
    }));
    return valid.filter((release) => release !== null)
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt) || a.baseId.localeCompare(b.baseId));
}
export async function readChangeRequest(project, moduleName) {
    const change = await readActiveL4Change(project, moduleName);
    if (!change)
        return null;
    const stored = change.requestRevision ? await readJson({
        project, level: 4, folder: `${moduleName}/pipeline/changes/${change.changeId}/requests`,
        shortName: `request-${change.requestRevision}`, extension: '.json',
    }) : null;
    if (change.requestRevision && typeof stored?.request !== 'string')
        throw new Error('Change request is incomplete.');
    return {
        changeId: change.changeId,
        revisionId: change.activeRevisionId,
        text: stored?.request ?? '',
        resultCurrent: change.resultRevisionId !== null && change.resultRevisionId === change.activeRevisionId,
    };
}
export async function saveChangeRequest(project, moduleName, text, expectedChangeId, expectedRevisionId) {
    const legacy = await readJson({ project, level: 4, folder: `${moduleName}/tobe/plan`, shortName: 'tobe', extension: '.json' });
    const prepared = await prepareL4Change(project, moduleName, legacy);
    if ((prepared.created && expectedChangeId !== null) || (!prepared.created && prepared.change.changeId !== expectedChangeId)) {
        throw new Error('L4 change conflict: reload before saving.');
    }
    if (prepared.change.activeRevisionId !== expectedRevisionId)
        throw new Error('L4 revision conflict: reload before saving.');
    const revision = await sealL4Revision(project, moduleName, expectedRevisionId, text);
    return { changeId: prepared.change.changeId, revisionId: revision.revisionId };
}
/** Reuse a verified local snapshot as a new candidate relative to the current base, never as publication. */
export async function reuseHistoricalRelease(project, moduleName, version) {
    const baseId = historicalReleaseId(version);
    if (!baseId)
        throw new Error('Select a historical release.');
    const historical = await readL4Release(project, moduleName, baseId);
    if (!historical)
        throw new Error('Historical release is incomplete.');
    if (await readActiveL4Change(project, moduleName))
        throw new Error('Discard the active candidate before reusing a historical release.');
    const prepared = await prepareL4Change(project, moduleName);
    const currentPaths = Object.keys(prepared.release.files).sort();
    if (JSON.stringify(Object.keys(historical.files).sort()) !== JSON.stringify(currentPaths)) {
        if (prepared.created)
            await deactivateL4Change(project, moduleName);
        throw new Error('Historical inventory differs from the current base; reconcile before reuse.');
    }
    const { revision } = await editL4Candidate(project, moduleName, null, prepared.change.changeId, async () => {
        for (const rawPath of currentPaths) {
            const path = normalizeTobeArtifactPath(rawPath);
            await writeSourceText(tobeArtifactFileInfo(project, moduleName, path, 'tobe'), await readSourceText(originalL4FileInfo(project, moduleName, baseId, path)));
        }
    });
    return revision.revisionId;
}
