/// <mls fileReference="_102035_/l2/newRelease/helpers/reviewRunWorker.ts" enhancement="_blank" />
export const REVIEW_RUN_MAX_ATTEMPTS = 4;
export function reviewRunLinkKey(identity) {
    return `collab-new-release-review-link-v1/${identity.project}/${identity.moduleName}/${identity.changeId}/${identity.inputRevisionId}`;
}
export function reviewRunStableLinkKey(identity) {
    return `collab-new-release-review-link-v1/${identity.project}/${identity.moduleName}/${identity.changeId}`;
}
export function saveReviewRunLink(identity, storage = globalThis.localStorage, lookup = identity) {
    const serialized = JSON.stringify(identity);
    storage.setItem(reviewRunLinkKey(lookup), serialized);
    storage.setItem(reviewRunStableLinkKey(lookup), serialized);
}
export function readReviewRunLink(identity, storage = globalThis.localStorage) {
    try {
        const raw = storage.getItem(reviewRunLinkKey(identity))
            ?? storage.getItem(reviewRunStableLinkKey(identity));
        return raw ? JSON.parse(raw) : null;
    }
    catch {
        return null;
    }
}
export function outputRevisionIdForRun(run) {
    const manifest = run.candidateResult?.manifest;
    const match = /^result-([a-f0-9]{32})$/u.exec(String(manifest?.runId || ''));
    return match ? `review-${match[1]}` : null;
}
export function reviewRunMatchesRevision(run, revisionId) {
    return revisionId === run.binding.inputRevisionId || revisionId === outputRevisionIdForRun(run);
}
export function publishedCandidateMatchesRunRevision(run, revisionId, candidate) {
    const value = candidate;
    const pointer = value?.pointer;
    const result = value?.result;
    const manifest = result?.manifest;
    const match = /^result-([a-f0-9]{32})$/u.exec(String(manifest?.runId || ''));
    return value?.status === 'read' && !!pointer && !!result && !!manifest && !!match
        && pointer.changeId === run.binding.changeId
        && pointer.revisionId === revisionId
        && pointer.resultId === result.resultId
        && pointer.resultHash === result.resultHash
        && revisionId === `review-${match[1]}`
        && result.resultRevisionId === run.binding.inputRevisionId
        && result.resultSnapshotHash === run.binding.inputSnapshotHash.replace(/^sha256:/u, '')
        && result.resultRevisionNumber === run.binding.inputRevisionNumber
        && manifest.status === 'completed'
        && typeof manifest.taskId === 'string' && manifest.taskId.length > 0;
}
export function claimInputForRun(run, userId, workerId, canonicalSnapshotHash, candidate = {}) {
    return {
        userId,
        project: run.binding.project,
        moduleName: run.binding.moduleName,
        changeId: run.binding.changeId,
        inputRevisionId: run.binding.inputRevisionId,
        inputSnapshotHash: run.binding.inputSnapshotHash,
        baseId: run.binding.baseId,
        requestRevision: run.binding.requestRevision,
        requestHash: run.binding.requestHash,
        runId: run.runId,
        workerId,
        canonicalSnapshotHash,
        ...(candidate.snapshotHash ? { candidateSnapshotHash: candidate.snapshotHash } : {}),
        ...(candidate.pipelineComplete ? { pipelineStatus: 'complete' } : {}),
        ...(candidate.pipelineSnapshotHash ? { pipelineSnapshotHash: candidate.pipelineSnapshotHash } : {}),
    };
}
export { driveReviewRunWorker } from './reviewRunWorkerCore.js';
