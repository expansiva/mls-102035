/// <mls fileReference="_102035_/l2/newRelease/editContract.ts" enhancement="_blank" />
export const NEW_RELEASE_CHANGED_EVENT = 'nr-changed';
export function announceNewReleaseChange(target, detail) {
    target.dispatchEvent(new CustomEvent(NEW_RELEASE_CHANGED_EVENT, {
        bubbles: true,
        composed: true,
        detail,
    }));
}
export function tabForArtifactPath(path) {
    if (path === 'module.defs.ts')
        return 'general';
    if (path.startsWith('journeys/'))
        return 'journeys';
    if (path.startsWith('ontology/'))
        return 'ontology';
    if (path === 'access.defs.ts')
        return 'access';
    if (path === 'rules.defs.ts')
        return 'rules';
    if (path === 'workflows.defs.ts')
        return 'workflows';
    return 'integration';
}
