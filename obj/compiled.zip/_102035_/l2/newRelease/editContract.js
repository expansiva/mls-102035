/// <mls fileReference="_102035_/l2/newRelease/editContract.ts" enhancement="_blank" />
export const NEW_RELEASE_CHANGED_EVENT = 'nr-changed';
export function announceNewReleaseChange(target, detail) {
    return new Promise((resolve, reject) => {
        const complete = (error) => error ? reject(error) : resolve();
        const accepted = !target.dispatchEvent(new CustomEvent(NEW_RELEASE_CHANGED_EVENT, {
            bubbles: true, composed: true, cancelable: true, detail: { ...detail, complete },
        }));
        if (!accepted)
            reject(new Error('new-release.save.unhandled'));
    });
}
export function tabForArtifactPath(path) {
    if (path === 'module.defs.ts')
        return 'general';
    if (path.startsWith('journeys/'))
        return 'journeys';
    if (path.startsWith('ontology/'))
        return 'ontology';
    if (path === 'access.defs.ts')
        return 'access';
    if (path === 'rules.defs.ts')
        return 'rules';
    if (path === 'workflows.defs.ts')
        return 'workflows';
    return 'integration';
}
/** Ask the common container before discarding a tab's draft. */
export function canDiscardNewReleaseDraft(target) {
    return target.dispatchEvent(new CustomEvent('nr-before-discard', { bubbles: true, cancelable: true }));
}
export function requestNewReleasePresentation(target, mode) {
    target.dispatchEvent(new CustomEvent('nr-presentation-request', { bubbles: true, composed: true, detail: { mode } }));
}
export const NEW_RELEASE_GENERAL_INDICATORS_EDIT_ID = 'general:indicators';
export function requestNewReleaseEdit(target, id) {
    target.dispatchEvent(new CustomEvent('nr-request-edit', { bubbles: true, composed: true, detail: { id } }));
}
