/// <mls fileReference="_102035_/l2/newRelease/tobe.ts" enhancement="_blank" />
import { assertNewReleaseEditable } from '/_102035_/l2/newRelease/helpers/revisionSelection.js';
import { implementationCommands, readL4Implementation } from '/_102035_/l2/solution/candidate/moduleImplementation.js';
import { getSessionUser } from '/_102033_/l2/shared/sessionUser.js';
import { fileExists, pipelineJsonFileForProject, readDefsJson, readJson, writeDefs, writeJson, } from '/_102035_/l2/solution/fs.js';
import { sha256Tobe, tobeDiff } from '/_102035_/l2/solution/candidate/tobeDiff.js';
import { validateNs5Overlay } from '/_102035_/l2/solution/candidate/overlayValidation.js';
import { assertProject, isNs5OntologyV3, normalizeTobeArtifactPath, ns5OntologyEntityIds, NS5_TOBE_MANIFEST_SCHEMA_VERSION, pathParts, tobeArtifactFileInfo, } from '/_102035_/l2/solution/candidate/tobePaths.js';
import { historicalReleaseId, NEW_RELEASE_TOBE_UPDATED_EVENT } from '/_102035_/l2/newRelease/helpers/context.js';
import { clearChangeOrigins, recordManualChangeOrigin } from '/_102035_/l2/newRelease/helpers/changeOrigins.js';
import { captureConfirmedL4Release, deactivateL4Change, editL4Candidate, originalL4FileInfo, prepareL4Change, readActiveL4Change, readL4Release, readSealedL4Candidate, revertL4CandidatePath, withModuleWriter } from '/_102035_/l2/solution/candidate/moduleRevision.js';
export { NEW_RELEASE_TOBE_UPDATED_EVENT } from '/_102035_/l2/newRelease/helpers/context.js';
export function tobeManifestFileInfo(project, moduleName) {
    assertProject(project);
    return { project, level: 4, folder: `${moduleName}/tobe/plan`, shortName: 'tobe', extension: '.json' };
}
function changeNow(now) {
    return now || new Date().toISOString();
}
export function recordTobeSave(current, path, jsonPath, baseHash, author, now) {
    const at = changeNow(now);
    const createdAt = current?.createdAt || at;
    return {
        schemaVersion: NS5_TOBE_MANIFEST_SCHEMA_VERSION,
        createdAt,
        updatedAt: at,
        author: author || current?.author || 'anonymous',
        base: { ...(current?.base || {}), [path]: current?.base?.[path] || baseHash },
        changes: [...(current?.changes || []), { path, jsonPath: jsonPath || '$', at }],
    };
}
export function recordTobeDiscard(current, path, now) {
    const base = { ...current.base };
    delete base[path];
    const changes = current.changes.filter(change => change.path !== path);
    if (!Object.keys(base).length && !changes.length)
        return null;
    return { ...current, base, changes, updatedAt: changeNow(now) };
}
async function readManifest(project, moduleName) {
    return readJson(tobeManifestFileInfo(project, moduleName));
}
function artifactWriteSpec(moduleName, path) {
    const shortName = pathParts(path).shortName;
    if (path === 'module.defs.ts')
        return { exportName: `${moduleName}Module`, typeName: 'Ns5ModuleArtifact' };
    if (path === 'journeys/index.defs.ts')
        return { exportName: `${moduleName}JourneyIndex`, typeName: 'Ns5JourneyIndexArtifact' };
    if (path.startsWith('journeys/'))
        return { exportName: `${shortName}Journey`, typeName: 'Ns5JourneyArtifact' };
    if (path === 'ontology/index.defs.ts')
        return { exportName: `${moduleName}OntologyIndex`, typeName: 'Ns5OntologyIndexArtifact' };
    if (path.startsWith('ontology/'))
        return { exportName: `${moduleName}Entity${shortName}`, typeName: 'Ns5OntologyEntityArtifact' };
    if (path === 'rules.defs.ts')
        return { exportName: `${moduleName}Rules`, typeName: 'Ns5RulesArtifact' };
    if (path === 'workflows.defs.ts')
        return { exportName: `${moduleName}Workflows`, typeName: 'Ns5WorkflowsArtifact' };
    if (path === 'access.defs.ts')
        return { exportName: `${moduleName}Access`, typeName: 'Ns5AccessArtifact' };
    if (path === 'integration.defs.ts')
        return { exportName: `${moduleName}Integration`, typeName: 'Ns5IntegrationArtifact' };
    if (path === 'workspace-model.defs.ts')
        return { exportName: `${moduleName}WorkspaceModel`, typeName: 'unknown' };
    if (path.startsWith('workspaces/'))
        return { exportName: `${shortName}Workspace`, typeName: 'unknown' };
    throw new Error(`Unsupported tobe artifact path: ${path}`);
}
async function manifestAuthor() {
    const user = await getSessionUser();
    return user.email || user.name || 'anonymous';
}
function announceTobeUpdated(project, moduleName, version) {
    if (typeof window === 'undefined')
        return;
    window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project, moduleName, version } }));
}
export class NewReleaseSaveValidationError extends Error {
    constructor(reason, issues) {
        super(`new-release.save.${reason}`);
        this.reason = reason;
        this.issues = issues;
        this.name = 'NewReleaseSaveValidationError';
    }
}
export async function saveTobeArtifact(project, moduleName, pathValue, value, options) {
    await assertNewReleaseEditable(project, moduleName);
    const path = normalizeTobeArtifactPath(pathValue);
    const active = await readActiveL4Change(project, moduleName);
    const reading = active ? 'tobe' : 'asis';
    const currentOverlay = await readNs5Overlay(project, moduleName, reading);
    const currentArtifact = currentOverlay.sources.all.find(artifact => artifact.path === path);
    if (!currentArtifact)
        throw new NewReleaseSaveValidationError('missing', []);
    const proposedOverlay = await readNs5Overlay(project, moduleName, reading, undefined, { path, value });
    const validation = proposedOverlay.validation;
    const unsupported = Object.entries(validation.coverage)
        .filter(([, area]) => area.status === 'unsupported')
        .map(([area, coverage]) => ({ area, reason: coverage.reason ?? '' }));
    if (unsupported.length) {
        console.error('[newRelease] candidate validation unavailable', JSON.stringify({
            project, moduleName, path, unsupported,
            previousOntologyCoverage: currentOverlay.validation.coverage.ontologyEntities,
        }));
        throw new NewReleaseSaveValidationError('unavailable', validation.issues);
    }
    const identity = (issue) => `${issue.artifact}:${issue.path}:${issue.code}:${issue.message}`;
    const previousErrors = new Set(currentOverlay.validation.issues.filter(issue => issue.severity === 'error').map(identity));
    const newErrors = validation.issues.filter(issue => issue.severity === 'error' && !previousErrors.has(identity(issue)));
    if (newErrors.length)
        throw new NewReleaseSaveValidationError('invalid', newErrors);
    const oldManifest = await readManifest(project, moduleName);
    const prepared = await prepareL4Change(project, moduleName, oldManifest);
    if (options.expectedChangeId !== undefined && options.expectedChangeId !== prepared.change.changeId && !(options.expectedChangeId === null && prepared.created)) {
        throw new Error('L4 change conflict: reload before saving.');
    }
    const expected = options.expectedRevisionId;
    const { value: manifest, revision } = await editL4Candidate(project, moduleName, expected, prepared.change.changeId, async () => {
        const original = await readDefsJson(originalL4FileInfo(project, moduleName, prepared.release.baseId, path));
        if (original === null)
            throw new Error(`Cannot prepare ${path}: captured artifact was not found.`);
        const current = await readManifest(project, moduleName);
        const baseHash = current?.base?.[path] || await sha256Tobe(original);
        const spec = artifactWriteSpec(moduleName, path);
        await writeDefs(tobeArtifactFileInfo(project, moduleName, path, 'tobe'), spec.exportName, value, spec.typeName);
        const next = recordTobeSave(current, path, options.jsonPath || '$', baseHash, options.author || await manifestAuthor(), options.now);
        await writeJson(tobeManifestFileInfo(project, moduleName), next);
        await recordManualChangeOrigin(project, moduleName, path, currentArtifact.value, value, options.now ? new Date(options.now) : undefined);
        return next;
    });
    manifest.changeId = revision.changeId;
    manifest.revisionId = revision.revisionId;
    manifest.baseId = revision.baseId;
    announceTobeUpdated(project, moduleName);
    return manifest;
}
function listedPlanFiles(project, moduleName) {
    return listedTobeFolder(project, `${moduleName}/tobe/plan`);
}
function listedCandidateFiles(project, moduleName) {
    return listedTobeFolder(project, `${moduleName}/tobe/candidate`);
}
function listedTobeFolder(project, folder) {
    const files = mls.stor.files;
    const keys = new Set();
    for (const [key, file] of Object.entries(files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted')
            continue;
        if (file.folder === folder || file.folder?.startsWith(`${folder}/`))
            keys.add(key);
    }
    return [...keys].map(key => files[key]).filter((file) => !!file && file.status !== 'deleted');
}
function relativePlanPath(file, moduleName) {
    const root = `${moduleName}/tobe/plan`;
    const suffix = String(file.folder || '').slice(root.length).replace(/^\//u, '');
    return `${suffix ? `${suffix}/` : ''}${file.shortName}${file.extension}`;
}
async function deleteInventory(files) {
    if (!files.length)
        return;
    const { deleteFile } = await import('/_102027_/l2/libStor.js');
    for (const file of files)
        await deleteFile(file);
}
export async function discardTobe(project, moduleName, pathValue, announce = true) {
    assertProject(project);
    const path = pathValue ? normalizeTobeArtifactPath(pathValue) : null;
    const deleted = [];
    let manifest = null;
    if (path) {
        const updateManifest = async () => {
            await clearChangeOrigins(project, moduleName, path);
            const current = await readManifest(project, moduleName);
            if (!current)
                return;
            manifest = recordTobeDiscard(current, path);
            if (manifest)
                await writeJson(tobeManifestFileInfo(project, moduleName), manifest);
            else {
                const manifestFile = listedPlanFiles(project, moduleName)
                    .find(file => relativePlanPath(file, moduleName) === 'tobe.json');
                if (manifestFile) {
                    await deleteInventory([manifestFile]);
                    deleted.push(`l4/${manifestFile.folder}/${manifestFile.shortName}${manifestFile.extension}`);
                }
            }
        };
        const active = await readActiveL4Change(project, moduleName);
        if (active) {
            await revertL4CandidatePath(project, moduleName, path, active.activeRevisionId, updateManifest);
        }
        else {
            const inventory = listedPlanFiles(project, moduleName);
            const target = inventory.filter(file => relativePlanPath(file, moduleName) === path);
            deleted.push(...target.map(file => `l4/${file.folder}/${file.shortName}${file.extension}`));
            await deleteInventory(target);
            await updateManifest();
        }
    }
    else {
        await deactivateL4Change(project, moduleName, async () => {
            const inventory = [...listedPlanFiles(project, moduleName), ...listedCandidateFiles(project, moduleName), ...listedTobeFolder(project, `${moduleName}/tobe/operations`)];
            deleted.push(...inventory.map(file => `l4/${file.folder}/${file.shortName}${file.extension}`));
            await deleteInventory(inventory);
        });
    }
    const remaining = listedPlanFiles(project, moduleName)
        .map(file => relativePlanPath(file, moduleName));
    const forbidden = path ? (manifest ? [] : ['tobe.json']) : remaining;
    if (forbidden.some(item => remaining.includes(item))) {
        throw new Error(`Discard inventory mismatch: ${forbidden.filter(item => remaining.includes(item)).join(', ')}`);
    }
    if (announce)
        announceTobeUpdated(project, moduleName);
    return { deleted: [...new Set(deleted)].sort(), manifest };
}
async function readArtifact(project, moduleName, path, version, errors, baseId) {
    const planned = tobeArtifactFileInfo(project, moduleName, path, 'tobe');
    const original = baseId ? originalL4FileInfo(project, moduleName, baseId, path) : tobeArtifactFileInfo(project, moduleName, path, 'asis');
    const hasPlanned = version === 'tobe' && fileExists(planned);
    const info = hasPlanned ? planned : original;
    try {
        const value = await readDefsJson(info);
        const originalValue = hasPlanned ? await readDefsJson(original) : value;
        const published = path === 'module.defs.ts' ? await readDefsJson(tobeArtifactFileInfo(project, moduleName, path, 'asis')) : null;
        const source = hasPlanned && value !== null && await sha256Tobe(value) !== await sha256Tobe(moduleLanguageBaseline(originalValue, value, published)) ? 'tobe' : 'asis';
        if (hasPlanned && value === null)
            errors.push({ path, message: 'Prepared artifact is unreadable; captured data was not substituted.' });
        return { path, source, value };
    }
    catch (error) {
        errors.push({ path, message: error instanceof Error ? error.message : String(error) });
        return { path, source: hasPlanned ? 'tobe' : 'asis', value: null };
    }
}
function idsFromFiles(project, moduleName, kind, reading) {
    const folder = reading === 'tobe' ? `${moduleName}/tobe/plan/${kind}` : `${moduleName}/${kind}`;
    const names = new Set();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.status === 'deleted' || file.project !== project || file.level !== 4)
            continue;
        if (String(file.folder || '') !== folder || file.extension !== '.defs.ts' || file.shortName === 'index')
            continue;
        names.add(String(file.shortName || ''));
    }
    return [...names].filter(Boolean).sort();
}
async function staleManifestPaths(project, moduleName, manifest) {
    if (!manifest)
        return [];
    const stale = [];
    for (const [rawPath, expected] of Object.entries(manifest.base)) {
        const path = normalizeTobeArtifactPath(rawPath);
        const asis = await readDefsJson(tobeArtifactFileInfo(project, moduleName, path, 'asis'));
        if (!expected || asis === null || await sha256Tobe(asis) !== expected)
            stale.push(path);
    }
    return stale.sort();
}
/** Match only language metadata already applied directly to the published module. */
export function moduleLanguageBaseline(base, candidate, published) {
    if (!base || !candidate || !published || typeof base !== 'object' || typeof candidate !== 'object')
        return base;
    const next = candidate;
    return JSON.stringify(next.productLanguages) === JSON.stringify(published.productLanguages) && next.defaultLanguage === published.defaultLanguage
        ? { ...base, productLanguages: published.productLanguages, defaultLanguage: published.defaultLanguage } : base;
}
export async function saveDirectLanguageMetadata(project, moduleName, languages, expected) {
    await assertNewReleaseEditable(project, moduleName);
    if (!languages.productLanguages.length || new Set(languages.productLanguages).size !== languages.productLanguages.length
        || !languages.productLanguages.includes(languages.defaultLanguage))
        throw new Error('general.languagesInvalid');
    const write = async () => {
        await assertNewReleaseEditable(project, moduleName);
        const publishedInfo = tobeArtifactFileInfo(project, moduleName, 'module.defs.ts', 'asis');
        const published = await readDefsJson(publishedInfo);
        if (!published)
            throw new Error('general.languagesInvalid');
        const plannedInfo = tobeArtifactFileInfo(project, moduleName, 'module.defs.ts', 'tobe');
        const planned = fileExists(plannedInfo) ? await readDefsJson(plannedInfo) : null;
        if (fileExists(plannedInfo) && !planned)
            throw new Error('general.languagesInvalid');
        const manifest = await readManifest(project, moduleName);
        if (manifest?.base['module.defs.ts'] && manifest.base['module.defs.ts'] !== await sha256Tobe(published))
            throw new Error('general.languagesConflict');
        const next = { ...published, ...languages };
        if (planned)
            await writeDefs(plannedInfo, `${moduleName}Module`, { ...planned, ...languages }, 'Ns5ModuleArtifact');
        await writeDefs(publishedInfo, `${moduleName}Module`, next, 'Ns5ModuleArtifact');
        if (manifest?.base['module.defs.ts']) {
            manifest.base['module.defs.ts'] = await sha256Tobe(next);
            await writeJson(tobeManifestFileInfo(project, moduleName), manifest);
        }
    };
    if (expected.changeId) {
        const result = await editL4Candidate(project, moduleName, expected.revisionId, expected.changeId, write);
        return result.revision.revisionId;
    }
    return withModuleWriter(project, moduleName, async () => {
        if (await readActiveL4Change(project, moduleName))
            throw new Error('general.languagesConflict');
        await write();
        return null;
    });
}
async function overlayDiffs(project, moduleName, sources, baseId, baseline, compareAll = false) {
    const result = [];
    for (const artifact of sources.all) {
        if ((!compareAll && artifact.source !== 'tobe') || artifact.value === null)
            continue;
        const asis = await readDefsJson(baseId ? originalL4FileInfo(project, moduleName, baseId, artifact.path) : tobeArtifactFileInfo(project, moduleName, artifact.path, 'asis'));
        const published = !compareAll && artifact.path === 'module.defs.ts' ? await readDefsJson(tobeArtifactFileInfo(project, moduleName, artifact.path, 'asis')) : null;
        const entries = tobeDiff(asis === null ? undefined : compareAll ? asis : moduleLanguageBaseline(asis, artifact.value, published), artifact.value);
        if (entries.length)
            result.push({ path: artifact.path, entries });
    }
    if (baseline) {
        const present = new Set(sources.all.filter(artifact => artifact.value !== null).map(artifact => artifact.path));
        for (const artifact of baseline.all) {
            if (artifact.value === null || present.has(artifact.path))
                continue;
            const entries = tobeDiff(artifact.value, undefined);
            if (entries.length)
                result.push({ path: artifact.path, entries });
        }
    }
    return result.sort((left, right) => left.path < right.path ? -1 : left.path > right.path ? 1 : 0);
}
async function readOverlaySourceBundle(project, moduleName, reading, baseId, proposed) {
    const errors = [];
    const module = await readArtifact(project, moduleName, 'module.defs.ts', reading, errors, baseId);
    const journeyIndex = await readArtifact(project, moduleName, 'journeys/index.defs.ts', reading, errors, baseId);
    const journeyIds = journeyIndex.value?.journeys.map(item => item.journeyId) || idsFromFiles(project, moduleName, 'journeys', reading);
    const journeys = await Promise.all(journeyIds.map(id => readArtifact(project, moduleName, `journeys/${id}.defs.ts`, reading, errors, baseId)));
    const ontologyIndex = await readArtifact(project, moduleName, 'ontology/index.defs.ts', reading, errors, baseId);
    const entityIds = ns5OntologyEntityIds(ontologyIndex.value);
    const resolvedEntityIds = entityIds.length ? entityIds : idsFromFiles(project, moduleName, 'ontology', reading);
    const entities = await Promise.all(resolvedEntityIds.map(id => readArtifact(project, moduleName, `ontology/${id}.defs.ts`, reading, errors, baseId)));
    const [rules, workflows, access, integration] = await Promise.all([
        readArtifact(project, moduleName, 'rules.defs.ts', reading, errors, baseId),
        readArtifact(project, moduleName, 'workflows.defs.ts', reading, errors, baseId),
        readArtifact(project, moduleName, 'access.defs.ts', reading, errors, baseId),
        readArtifact(project, moduleName, 'integration.defs.ts', reading, errors, baseId),
    ]);
    if (proposed) {
        const candidates = [module, journeyIndex, ...journeys, ontologyIndex, ...entities, rules, workflows, access, integration];
        const artifact = candidates.find(item => item.path === proposed.path);
        if (artifact) {
            artifact.value = structuredClone(proposed.value);
            artifact.source = 'tobe';
        }
    }
    const all = [module, journeyIndex, ...journeys, ontologyIndex, ...entities, rules, workflows, access, integration];
    const sources = { module, journeyIndex, journeys, ontologyIndex, entities, rules, workflows, access, integration, all };
    return { sources, errors };
}
export async function readNs5Overlay(project, moduleName, version = 'asis', context, proposed) {
    const historicalId = historicalReleaseId(version);
    const historicalRelease = historicalId ? await readL4Release(project, moduleName, historicalId) : null;
    if (historicalId && !historicalRelease)
        throw new Error('Historical release is incomplete.');
    let active = version === 'tobe' ? await readActiveL4Change(project, moduleName) : null;
    if (version === 'tobe' && !active)
        active = (await prepareL4Change(project, moduleName, await readManifest(project, moduleName))).change;
    const baseId = historicalId ?? active?.baseId;
    const reading = version === 'tobe' ? 'tobe' : 'asis';
    const loaded = await readOverlaySourceBundle(project, moduleName, reading, baseId, proposed);
    const { sources, errors } = loaded;
    let baseline;
    const comparisonBaseId = historicalRelease?.confirmedRound?.sourceBaseId ?? (version === 'tobe' ? baseId : undefined);
    if (comparisonBaseId) {
        const base = await readOverlaySourceBundle(project, moduleName, 'asis', comparisonBaseId);
        if (base.errors.length === 0 && base.sources.all.every(artifact => artifact.value !== null))
            baseline = base.sources;
        else if (historicalRelease?.confirmedRound)
            errors.push({ path: `pipeline/releases/${comparisonBaseId}`, message: 'Snapshot baseline is incomplete.' });
    }
    const ontologyPlan = !historicalId && isNs5OntologyV3(sources.ontologyIndex.value)
        ? await readJson(pipelineJsonFileForProject(project, moduleName, 'ontology30-plan-draft'))
        : null;
    const storedManifest = version === 'tobe' ? await readManifest(project, moduleName) : null;
    const manifest = storedManifest && active ? { ...storedManifest, changeId: active.changeId, revisionId: active.activeRevisionId ?? undefined, baseId: active.baseId } : storedManifest;
    let sealedRevision = null;
    if (version === 'tobe' && active?.activeRevisionId) {
        const path = `l4/${moduleName}/pipeline/changes/${active.changeId}/revisions/${active.activeRevisionId}`;
        try {
            sealedRevision = await readSealedL4Candidate(project, moduleName, active.changeId, active.activeRevisionId);
            if (!sealedRevision)
                errors.push({ path, message: 'The sealed revision failed its integrity check.' });
        }
        catch (error) {
            errors.push({ path, message: error instanceof Error ? error.message : String(error) });
        }
    }
    const [stalePaths, diffs] = await Promise.all([
        staleManifestPaths(project, moduleName, manifest),
        overlayDiffs(project, moduleName, sources, comparisonBaseId ?? baseId, baseline, !!historicalRelease?.confirmedRound && !!baseline),
    ]);
    return { sources, manifest, sealedRevision, changeId: active?.changeId ?? null, revisionId: active?.activeRevisionId ?? null,
        confirmedRound: historicalRelease?.confirmedRound, stalePaths, diffs,
        validation: await validateNs5Overlay(sources, { ...context, ontologyPlan }, baseline), errors };
}
/** Retire only the successfully applied revision, keeping its immutable history. */
export async function completeTobeImplementation(project, moduleName, changeId, revisionId, confirmedBy = '') {
    await deactivateL4Change(project, moduleName, async () => {
        const active = await readActiveL4Change(project, moduleName);
        if (active?.changeId !== changeId || active.activeRevisionId !== revisionId || active.promotedRevisionId !== revisionId) {
            throw new Error('l4.implementation_conflict');
        }
        const record = await readL4Implementation(project, moduleName);
        if (!record || record.revisionId !== revisionId || !implementationCommands(record, project, moduleName).every((_, index) => record.phases.some(phase => phase.name === `runAgents:${index}` && phase.status === 'done')))
            throw new Error('implementation.not_complete');
        const confirmedAt = new Date().toISOString();
        await captureConfirmedL4Release(project, moduleName, changeId, revisionId, active.baseId, confirmedAt, confirmedBy);
        await deleteInventory([...listedPlanFiles(project, moduleName), ...listedCandidateFiles(project, moduleName), ...listedTobeFolder(project, `${moduleName}/tobe/operations`)]);
        await writeJson({ project, level: 4, folder: `${moduleName}/pipeline/changes/${changeId}`, shortName: 'confirmation', extension: '.json' }, { changeId, revisionId, confirmedAt, confirmedBy });
    });
    announceTobeUpdated(project, moduleName, 'asis');
}
