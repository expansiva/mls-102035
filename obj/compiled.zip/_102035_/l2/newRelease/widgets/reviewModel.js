/// <mls fileReference="_102035_/l2/newRelease/widgets/reviewModel.ts" enhancement="_blank" />
export const MENU_SCHEMA_VERSION = '2026-09-20-p2-menu-v2.2';
export const REVIEW_ALL_ACTORS = 'all';
export const MENU_NODE_KINDS = ['hub', 'page', 'group'];
export const MENU_ORGANISM_KINDS = [
    'list', 'detail', 'form', 'summary', 'highlights', 'timeline', 'actions', 'inbox', 'alerts',
];
export const MENU_ACTIONS = ['new', 'change', 'keep', 'remove'];
function sortedEntries(record) {
    return Object.entries(record).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0);
}
/** Full fence between the snapshot rendered by preflight and the authoritative click reread. */
export function sameReviewStartSnapshot(loaded, fresh) {
    if (!loaded || !fresh)
        return false;
    const left = loaded.manifest;
    const right = fresh.manifest;
    if (loaded.request !== fresh.request
        || left.project !== right.project || left.moduleName !== right.moduleName
        || left.changeId !== right.changeId || left.revisionId !== right.revisionId
        || left.baseId !== right.baseId || left.requestRevision !== right.requestRevision
        || left.requestHash !== right.requestHash
        || JSON.stringify(sortedEntries(left.files)) !== JSON.stringify(sortedEntries(right.files)))
        return false;
    const normalize = (sources) => [...sources]
        .sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0)
        .map(item => [item.path, item.source]);
    return JSON.stringify(normalize(loaded.sources)) === JSON.stringify(normalize(fresh.sources));
}
/** Synchronous presentation gate; the click repeats the authoritative sealed read before start. */
export function canStartReviewRun(input) {
    const sealed = input.sealedRevision;
    const manifest = sealed?.manifest;
    return !input.hasRun
        && !!input.userId
        && !!input.request.trim()
        && input.request === input.request.trim()
        && sealed?.request === input.request
        && !!sealed.sources.length
        && manifest?.project === input.project
        && manifest.moduleName === input.moduleName
        && manifest.changeId === input.changeId
        && manifest.revisionId === input.revisionId
        && /^[A-Za-z0-9][A-Za-z0-9-]{0,127}$/u.test(manifest.baseId)
        && Number.isSafeInteger(manifest.requestRevision) && manifest.requestRevision > 0
        && /^sha256:[a-f0-9]{64}$/u.test(manifest.requestHash || '');
}
export function buildReviewActionPresentation(input) {
    let kind = 'unavailable';
    if (!input.loading && input.current && input.version === 'tobe') {
        if (input.retry && input.retryAvailable)
            kind = 'retry';
        else if (!input.retry && input.viewKind === 'pending')
            kind = 'calculate';
        else if (input.viewKind === 'ready' && input.resultCurrent
            && input.backendKind === 'ready' && input.effortKind !== 'invalid')
            kind = 'continue';
    }
    const labelKey = input.busy
        ? 'review.actionBusy'
        : kind === 'retry' ? 'review.retry'
            : kind === 'calculate' ? 'review.calculate'
                : kind === 'continue' ? 'review.continue'
                    : 'review.actionUnavailable';
    const expectsCurrentResult = input.viewKind === 'ready' && input.resultCurrent;
    const descriptionKey = input.loading || !input.current
        ? 'review.actionLoading'
        : input.retry && !input.retryAvailable ? 'review.actionRetryExhausted'
            : kind === 'retry' ? 'review.actionRetryBody'
                : kind === 'calculate' ? 'review.actionCalculateBody'
                    : kind === 'continue' ? 'review.actionContinueBody'
                        : expectsCurrentResult && input.backendKind === 'missing' ? 'review.actionBackendMissing'
                            : expectsCurrentResult && input.backendKind === 'invalid' ? 'review.actionBackendInvalid'
                                : expectsCurrentResult && input.backendKind === 'stale' ? 'review.actionBackendStale'
                                    : expectsCurrentResult && input.effortKind === 'invalid' ? 'review.actionEffortInvalid'
                                        : 'review.actionUnavailableBody';
    return {
        kind,
        labelKey,
        descriptionKey,
        availabilityKey: input.busy ? 'review.actionBusy' : input.connected ? '' : 'review.actionReadinessBlocked',
        disabled: input.busy || !input.connected || kind === 'unavailable',
        busy: input.busy,
        error: input.error,
    };
}
export function buildReviewActionPlacements(action) {
    return [
        { placement: 'top', action, announceError: true },
        { placement: 'bottom', action, announceError: false },
    ];
}
export function beginReviewPrimaryAction(action) {
    return action.disabled || action.busy ? { accepted: false, busy: action.busy } : { accepted: true, busy: true };
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function asNonEmpty(value) {
    return typeof value === 'string' && value.trim() ? value : null;
}
function parseAction(value) {
    return typeof value === 'string' && MENU_ACTIONS.includes(value) ? value : null;
}
function parseOrganism(value) {
    if (!isRecord(value))
        return null;
    const kind = value.kind;
    const text = asNonEmpty(value.text);
    if (typeof kind !== 'string' || !MENU_ORGANISM_KINDS.includes(kind) || !text)
        return null;
    return { kind: kind, text };
}
function parseNode(value) {
    if (!isRecord(value))
        return null;
    const id = asNonEmpty(value.id);
    const label = asNonEmpty(value.label);
    const action = parseAction(value.action);
    if (!id || !label || !action)
        return null;
    if (value.kind === 'page') {
        if (!Array.isArray(value.organisms))
            return null;
        const organisms = [];
        for (const item of value.organisms) {
            const organism = parseOrganism(item);
            if (!organism)
                return null;
            organisms.push(organism);
        }
        return { id, kind: 'page', label, action, organisms };
    }
    if (value.kind !== 'hub' && value.kind !== 'group')
        return null;
    if (!Array.isArray(value.children))
        return null;
    const children = [];
    for (const item of value.children) {
        const child = parseNode(item);
        if (!child)
            return null;
        children.push(child);
    }
    const text = asNonEmpty(value.text);
    if (!text)
        return null;
    if (value.kind === 'hub') {
        const context = asNonEmpty(value.context);
        if (!context)
            return null;
        return { id, kind: 'hub', label, action, context, text, children };
    }
    return { id, kind: 'group', label, action, text, children };
}
function parseAuthorities(value) {
    if (!isRecord(value))
        return null;
    const authorities = {};
    for (const [key, ids] of Object.entries(value)) {
        if (!key || !Array.isArray(ids) || ids.some(id => typeof id !== 'string' || !id))
            return null;
        authorities[key] = ids;
    }
    return authorities;
}
function parseForest(value) {
    if (!Array.isArray(value))
        return null;
    const nodes = [];
    for (const item of value) {
        const node = parseNode(item);
        if (!node)
            return null;
        nodes.push(node);
    }
    return nodes;
}
export function parseReviewMenu(raw) {
    if (!isRecord(raw))
        return { ok: false, errorCode: 'review.error.invalid' };
    if (raw.schemaVersion !== MENU_SCHEMA_VERSION)
        return { ok: false, errorCode: 'review.error.schema' };
    const moduleName = asNonEmpty(raw.moduleName);
    const device = asNonEmpty(raw.device);
    const tree = parseForest(raw.tree);
    const authorities = parseAuthorities(raw.authorities);
    if (!moduleName || !device || !tree || !authorities || !isRecord(raw.meta)) {
        return { ok: false, errorCode: 'review.error.invalid' };
    }
    const removed = raw.meta.removed === undefined ? [] : parseForest(raw.meta.removed);
    if (!removed)
        return { ok: false, errorCode: 'review.error.invalid' };
    return { ok: true, menu: { schemaVersion: MENU_SCHEMA_VERSION, moduleName, device, tree, authorities, removed } };
}
export function actorIdFromKey(key) {
    return key.startsWith('actor:') ? key.slice('actor:'.length) : key;
}
export function resolveSelectedActor(actors, selected) {
    if (selected === REVIEW_ALL_ACTORS)
        return REVIEW_ALL_ACTORS;
    if (actors.some(actor => actor.key === selected))
        return selected;
    return actors[0]?.key || REVIEW_ALL_ACTORS;
}
function toTree(nodes) {
    return nodes.map(node => ({
        id: node.id,
        kind: node.kind,
        label: node.label,
        action: node.action,
        children: node.kind === 'page' ? [] : toTree(node.children),
    }));
}
function walk(nodes, visit, ancestors = []) {
    for (const node of nodes) {
        visit(node, ancestors);
        if (node.kind !== 'page')
            walk(node.children, visit, [...ancestors, node]);
    }
}
function addDescendants(node, visible) {
    if (node.kind === 'page')
        return;
    for (const child of node.children) {
        visible.add(child.id);
        addDescendants(child, visible);
    }
}
function filterVisible(nodes, visible) {
    const out = [];
    for (const node of nodes) {
        if (!visible.has(node.id)) {
            if (node.kind !== 'page')
                out.push(...filterVisible(node.children, visible));
            continue;
        }
        if (node.kind === 'page') {
            out.push(node);
            continue;
        }
        out.push({ ...node, children: filterVisible(node.children, visible) });
    }
    return out;
}
export function menuTreeForActor(menu, actorKey) {
    if (actorKey === REVIEW_ALL_ACTORS)
        return menu.tree;
    const explicit = menu.authorities[actorKey] || [];
    const visible = new Set(explicit);
    walk(menu.tree, node => {
        if (visible.has(node.id))
            addDescendants(node, visible);
    });
    const filtered = filterVisible(menu.tree, visible);
    const order = new Map(explicit.map((id, index) => [id, index]));
    return [...filtered].sort((left, right) => (order.get(left.id) ?? Number.POSITIVE_INFINITY) - (order.get(right.id) ?? Number.POSITIVE_INFINITY));
}
function indexNodes(nodes) {
    const found = new Map();
    walk(nodes, node => {
        if (!found.has(node.id))
            found.set(node.id, node);
    });
    return found;
}
function containsId(nodes, id) {
    return nodes.some(node => node.id === id || containsId(node.children, id));
}
export function toggleReviewSelection(selectedId, selectedScope, id, scope) {
    return selectedId === id && selectedScope === scope
        ? { selectedId: '', selectedScope: scope }
        : { selectedId: id, selectedScope: scope };
}
export function reviewExpansionKey(scope, id) {
    return `${scope}:${id}`;
}
function ancestorIds(nodes, id) {
    const found = [];
    const walk = (list, trail) => {
        for (const node of list) {
            if (node.id === id) {
                found.push(...trail);
                return true;
            }
            if (node.children.length && walk(node.children, [...trail, node.id]))
                return true;
        }
        return false;
    };
    walk(nodes, []);
    return found;
}
export function openReviewExpansionKeys(expandedKeys, view) {
    const keys = new Set(expandedKeys);
    const forest = view.selectedScope === 'removed' ? view.removed : view.tree;
    for (const id of ancestorIds(forest, view.selectedId))
        keys.add(reviewExpansionKey(view.selectedScope, id));
    return keys;
}
export function toggleReviewExpansion(expandedKeys, view, id, scope) {
    const key = reviewExpansionKey(scope, id);
    const wasOpen = openReviewExpansionKeys(expandedKeys, view).has(key);
    const forest = scope === 'removed' ? view.removed : view.tree;
    const closesSelectedAncestor = wasOpen && view.selectedScope === scope && ancestorIds(forest, view.selectedId).includes(id);
    return {
        expandedKeys: wasOpen ? expandedKeys.filter(item => item !== key) : [...expandedKeys, key],
        selectedId: closesSelectedAncestor ? '' : view.selectedId,
    };
}
function detailOf(node, scope) {
    return {
        id: node.id,
        kind: node.kind,
        label: node.label,
        action: node.action,
        scope,
        text: node.kind === 'page' ? '' : node.text,
        context: node.kind === 'hub' ? node.context : '',
        organisms: node.kind === 'page' ? node.organisms : [],
    };
}
const EMPTY_VIEW = {
    actors: [],
    selectedActor: REVIEW_ALL_ACTORS,
    selectedId: '',
    selectedScope: 'future',
    tree: [],
    removed: [],
    selected: null,
};
export function buildReviewView(input) {
    if (input.pendingCount > 0) {
        return {
            ...EMPTY_VIEW,
            kind: 'pending',
            errorCode: '',
            showContinue: false,
            showCalculate: true,
        };
    }
    if (input.readStatus === 'missing') {
        return {
            ...EMPTY_VIEW,
            kind: 'empty',
            errorCode: 'review.emptyBody',
            showContinue: false,
            showCalculate: false,
        };
    }
    if (input.readStatus === 'invalid') {
        return {
            ...EMPTY_VIEW,
            kind: 'invalid',
            errorCode: 'review.error.invalid',
            showContinue: false,
            showCalculate: false,
        };
    }
    const parsed = parseReviewMenu(input.raw);
    if (!parsed.ok) {
        return {
            ...EMPTY_VIEW,
            kind: 'invalid',
            errorCode: parsed.errorCode,
            showContinue: false,
            showCalculate: false,
        };
    }
    const actors = Object.keys(parsed.menu.authorities).map(key => ({ key, actorId: actorIdFromKey(key) }));
    const selectedActor = resolveSelectedActor(actors, input.selectedActor);
    const future = menuTreeForActor(parsed.menu, selectedActor);
    const tree = toTree(future);
    const removed = selectedActor === REVIEW_ALL_ACTORS ? toTree(parsed.menu.removed) : [];
    const futureIndex = indexNodes(future);
    const removedIndex = selectedActor === REVIEW_ALL_ACTORS ? indexNodes(parsed.menu.removed) : new Map();
    let selectedScope = input.selectedScope;
    let selectedId = input.selectedId;
    if (selectedScope === 'removed' && !containsId(removed, selectedId)) {
        selectedScope = 'future';
        selectedId = '';
    }
    if (selectedScope === 'future' && !containsId(tree, selectedId))
        selectedId = '';
    const selectedNode = selectedScope === 'removed' ? removedIndex.get(selectedId) : futureIndex.get(selectedId);
    return {
        kind: 'ready',
        errorCode: '',
        actors,
        selectedActor,
        selectedId,
        selectedScope,
        tree,
        removed,
        selected: selectedNode ? detailOf(selectedNode, selectedScope) : null,
        showContinue: true,
        showCalculate: false,
    };
}
