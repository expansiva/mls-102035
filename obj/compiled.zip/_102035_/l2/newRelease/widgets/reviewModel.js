/// <mls fileReference="_102035_/l2/newRelease/widgets/reviewModel.ts" enhancement="_blank" />
export const MENU_SCHEMA_VERSION = '2026-09-20-p2-menu-v2.2';
export const REVIEW_ALL_ACTORS = 'all';
export const MENU_NODE_KINDS = ['hub', 'page', 'group'];
export const MENU_ORGANISM_KINDS = [
    'list', 'detail', 'form', 'summary', 'highlights', 'timeline', 'actions', 'inbox', 'alerts',
];
export const MENU_ACTIONS = ['new', 'change', 'keep', 'remove'];
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function asNonEmpty(value) {
    return typeof value === 'string' && value.trim() ? value : null;
}
function parseAction(value) {
    return typeof value === 'string' && MENU_ACTIONS.includes(value) ? value : null;
}
function parseOrganism(value) {
    if (!isRecord(value))
        return null;
    const kind = value.kind;
    const text = asNonEmpty(value.text);
    if (typeof kind !== 'string' || !MENU_ORGANISM_KINDS.includes(kind) || !text)
        return null;
    return { kind: kind, text };
}
function parseNode(value) {
    if (!isRecord(value))
        return null;
    const id = asNonEmpty(value.id);
    const label = asNonEmpty(value.label);
    const action = parseAction(value.action);
    if (!id || !label || !action)
        return null;
    if (value.kind === 'page') {
        if (!Array.isArray(value.organisms))
            return null;
        const organisms = [];
        for (const item of value.organisms) {
            const organism = parseOrganism(item);
            if (!organism)
                return null;
            organisms.push(organism);
        }
        return { id, kind: 'page', label, action, organisms };
    }
    if (value.kind !== 'hub' && value.kind !== 'group')
        return null;
    if (!Array.isArray(value.children))
        return null;
    const children = [];
    for (const item of value.children) {
        const child = parseNode(item);
        if (!child)
            return null;
        children.push(child);
    }
    const text = asNonEmpty(value.text);
    if (!text)
        return null;
    if (value.kind === 'hub') {
        const context = asNonEmpty(value.context);
        if (!context)
            return null;
        return { id, kind: 'hub', label, action, context, text, children };
    }
    return { id, kind: 'group', label, action, text, children };
}
function parseAuthorities(value) {
    if (!isRecord(value))
        return null;
    const authorities = {};
    for (const [key, ids] of Object.entries(value)) {
        if (!key || !Array.isArray(ids) || ids.some(id => typeof id !== 'string' || !id))
            return null;
        authorities[key] = ids;
    }
    return authorities;
}
function parseForest(value) {
    if (!Array.isArray(value))
        return null;
    const nodes = [];
    for (const item of value) {
        const node = parseNode(item);
        if (!node)
            return null;
        nodes.push(node);
    }
    return nodes;
}
export function parseReviewMenu(raw) {
    if (!isRecord(raw))
        return { ok: false, errorCode: 'review.error.invalid' };
    if (raw.schemaVersion !== MENU_SCHEMA_VERSION)
        return { ok: false, errorCode: 'review.error.schema' };
    const moduleName = asNonEmpty(raw.moduleName);
    const device = asNonEmpty(raw.device);
    const tree = parseForest(raw.tree);
    const authorities = parseAuthorities(raw.authorities);
    if (!moduleName || !device || !tree || !authorities || !isRecord(raw.meta)) {
        return { ok: false, errorCode: 'review.error.invalid' };
    }
    const removed = raw.meta.removed === undefined ? [] : parseForest(raw.meta.removed);
    if (!removed)
        return { ok: false, errorCode: 'review.error.invalid' };
    return { ok: true, menu: { schemaVersion: MENU_SCHEMA_VERSION, moduleName, device, tree, authorities, removed } };
}
export function actorIdFromKey(key) {
    return key.startsWith('actor:') ? key.slice('actor:'.length) : key;
}
export function resolveSelectedActor(actors, selected) {
    if (selected === REVIEW_ALL_ACTORS)
        return REVIEW_ALL_ACTORS;
    if (actors.some(actor => actor.key === selected))
        return selected;
    return actors[0]?.key || REVIEW_ALL_ACTORS;
}
function toTree(nodes) {
    return nodes.map(node => ({
        id: node.id,
        kind: node.kind,
        label: node.label,
        action: node.action,
        children: node.kind === 'page' ? [] : toTree(node.children),
    }));
}
function walk(nodes, visit, ancestors = []) {
    for (const node of nodes) {
        visit(node, ancestors);
        if (node.kind !== 'page')
            walk(node.children, visit, [...ancestors, node]);
    }
}
function addDescendants(node, visible) {
    if (node.kind === 'page')
        return;
    for (const child of node.children) {
        visible.add(child.id);
        addDescendants(child, visible);
    }
}
function filterVisible(nodes, visible) {
    const out = [];
    for (const node of nodes) {
        if (!visible.has(node.id)) {
            if (node.kind !== 'page')
                out.push(...filterVisible(node.children, visible));
            continue;
        }
        if (node.kind === 'page') {
            out.push(node);
            continue;
        }
        out.push({ ...node, children: filterVisible(node.children, visible) });
    }
    return out;
}
export function menuTreeForActor(menu, actorKey) {
    if (actorKey === REVIEW_ALL_ACTORS)
        return menu.tree;
    const explicit = menu.authorities[actorKey] || [];
    const visible = new Set(explicit);
    walk(menu.tree, node => {
        if (visible.has(node.id))
            addDescendants(node, visible);
    });
    const filtered = filterVisible(menu.tree, visible);
    const order = new Map(explicit.map((id, index) => [id, index]));
    return [...filtered].sort((left, right) => (order.get(left.id) ?? Number.POSITIVE_INFINITY) - (order.get(right.id) ?? Number.POSITIVE_INFINITY));
}
function indexNodes(nodes) {
    const found = new Map();
    walk(nodes, node => {
        if (!found.has(node.id))
            found.set(node.id, node);
    });
    return found;
}
function firstId(nodes) {
    return nodes[0]?.id || '';
}
function containsId(nodes, id) {
    return nodes.some(node => node.id === id || containsId(node.children, id));
}
function detailOf(node, scope) {
    return {
        id: node.id,
        kind: node.kind,
        label: node.label,
        action: node.action,
        scope,
        text: node.kind === 'page' ? '' : node.text,
        context: node.kind === 'hub' ? node.context : '',
        organisms: node.kind === 'page' ? node.organisms : [],
    };
}
const EMPTY_VIEW = {
    actors: [],
    selectedActor: REVIEW_ALL_ACTORS,
    selectedId: '',
    selectedScope: 'future',
    tree: [],
    removed: [],
    selected: null,
};
export function buildReviewView(input) {
    if (input.pendingCount > 0) {
        return {
            ...EMPTY_VIEW,
            kind: 'pending',
            errorCode: '',
            showContinue: false,
            showCalculate: true,
        };
    }
    if (input.readStatus === 'missing') {
        return {
            ...EMPTY_VIEW,
            kind: 'empty',
            errorCode: 'review.emptyBody',
            showContinue: false,
            showCalculate: false,
        };
    }
    if (input.readStatus === 'invalid') {
        return {
            ...EMPTY_VIEW,
            kind: 'invalid',
            errorCode: 'review.error.invalid',
            showContinue: false,
            showCalculate: false,
        };
    }
    const parsed = parseReviewMenu(input.raw);
    if (!parsed.ok) {
        return {
            ...EMPTY_VIEW,
            kind: 'invalid',
            errorCode: parsed.errorCode,
            showContinue: false,
            showCalculate: false,
        };
    }
    const actors = Object.keys(parsed.menu.authorities).map(key => ({ key, actorId: actorIdFromKey(key) }));
    const selectedActor = resolveSelectedActor(actors, input.selectedActor);
    const future = menuTreeForActor(parsed.menu, selectedActor);
    const tree = toTree(future);
    const removed = selectedActor === REVIEW_ALL_ACTORS ? toTree(parsed.menu.removed) : [];
    const futureIndex = indexNodes(future);
    const removedIndex = selectedActor === REVIEW_ALL_ACTORS ? indexNodes(parsed.menu.removed) : new Map();
    let selectedScope = input.selectedScope;
    let selectedId = input.selectedId;
    if (selectedScope === 'removed' && !containsId(removed, selectedId)) {
        selectedScope = 'future';
        selectedId = '';
    }
    if (selectedScope === 'future' && !containsId(tree, selectedId))
        selectedId = firstId(tree);
    if (!selectedId && removed.length) {
        selectedScope = 'removed';
        selectedId = firstId(removed);
    }
    const selectedNode = selectedScope === 'removed' ? removedIndex.get(selectedId) : futureIndex.get(selectedId);
    return {
        kind: 'ready',
        errorCode: '',
        actors,
        selectedActor,
        selectedId,
        selectedScope,
        tree,
        removed,
        selected: selectedNode ? detailOf(selectedNode, selectedScope) : null,
        showContinue: true,
        showCalculate: false,
    };
}
