/// <mls fileReference="_102035_/l2/newRelease/widgets/access.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { hasItemDiff, idScope } from '/_102035_/l2/newRelease/helpers/itemDiffs.js';
import { changedDot } from '/_102035_/l2/newRelease/helpers/changedDot.js';
import { announceNewReleaseChange, canDiscardNewReleaseDraft, requestNewReleaseEdit, } from '/_102035_/l2/newRelease/editContract.js';
import { patchAccessActor, patchAccessGrant, accessMatrixRows, accessTextNodes, accessIsPerson, accessFieldLabel, accessFieldRefs, accessGrantsForActor, accessJourneyCount, accessOracleIssues, reachablePersonAnchors, } from '/_102035_/l2/newRelease/widgets/accessModel.js';
const SCOPE_MODES = ['own', 'assigned', 'related', 'public', 'organization', 'custom'];
const DISCLOSURE_MODES = ['fullRecord', 'fieldsOnly', 'summaryOnly', 'aggregateOnly'];
const PERSON_SCOPE_MODES = ['own', 'assigned', 'related'];
const LIMITED_DISCLOSURE_MODES = ['fieldsOnly', 'summaryOnly'];
const ACTOR_ORIGINS = ['named', 'inferred'];
const ACTOR_KINDS = ['internal', 'external', 'system'];
let NewReleaseAccess102035 = class NewReleaseAccess102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--access-102035 {
  display: block;
  color: #e5e7eb;
  --surface-bg: #131923;
  --surface-alt-bg: #10151e;
  --text-default: #e5e7eb;
  --text-muted: #9aa7ba;
  --border-default: #344155;
}
new-release--widgets--access-102035 * {
  box-sizing: border-box;
}
new-release--widgets--access-102035 button,
new-release--widgets--access-102035 input,
new-release--widgets--access-102035 select,
new-release--widgets--access-102035 textarea {
  font: inherit;
  color: inherit;
}
new-release--widgets--access-102035 button {
  cursor: pointer;
}
new-release--widgets--access-102035 code {
  color: #9aa7ba;
  font: 0.75rem ui-monospace, monospace;
  overflow-wrap: anywhere;
}
new-release--widgets--access-102035 input,
new-release--widgets--access-102035 select,
new-release--widgets--access-102035 textarea {
  width: 100%;
  padding: 0.6rem 0.75rem;
  border: 1px solid #344155;
  border-radius: 0.5rem;
  background: #10151e;
}
new-release--widgets--access-102035 textarea {
  min-height: 6rem;
  resize: vertical;
}
new-release--widgets--access-102035 select[multiple] {
  min-height: 8rem;
}
new-release--widgets--access-102035 button:focus-visible,
new-release--widgets--access-102035 input:focus-visible,
new-release--widgets--access-102035 textarea:focus-visible,
new-release--widgets--access-102035 select:focus-visible,
new-release--widgets--access-102035 summary:focus-visible {
  outline: 2px solid #71b7fa;
  outline-offset: 3px;
}
new-release--widgets--access-102035 .nr-access__matrix {
  padding: 1.25rem;
}
new-release--widgets--access-102035 .nr-access__matrix > header {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  margin-bottom: 1.25rem;
}
new-release--widgets--access-102035 .nr-access__matrix > header span {
  font-size: 1.1rem;
  font-weight: 650;
}
new-release--widgets--access-102035 .nr-access__matrix p,
new-release--widgets--access-102035 .nr-access__matrix small {
  color: #9aa7ba;
  font-size: 0.8rem;
  line-height: 1.5;
}
new-release--widgets--access-102035 .nr-access__matrix-scroll {
  overflow: auto;
  border: 1px solid #2c3748;
  border-radius: 0.75rem;
}
new-release--widgets--access-102035 table {
  width: 100%;
  border-collapse: collapse;
  background: #131923;
}
new-release--widgets--access-102035 th,
new-release--widgets--access-102035 td {
  padding: 0.85rem;
  border-bottom: 1px solid #283345;
  text-align: center;
}
new-release--widgets--access-102035 thead th {
  background: #182130;
  font-weight: 500;
}
new-release--widgets--access-102035 th:first-child {
  min-width: 15rem;
  text-align: left;
}
new-release--widgets--access-102035 tbody th {
  font-weight: 400;
}
new-release--widgets--access-102035 tbody th button {
  display: grid;
  gap: 0.35rem;
  border: 0;
  padding: 0;
  background: none;
  text-align: left;
}
new-release--widgets--access-102035 tbody th strong {
  font-size: 0.9rem;
  font-weight: 550;
  white-space: normal;
  overflow-wrap: anywhere;
}
new-release--widgets--access-102035 tbody tr:last-child th,
new-release--widgets--access-102035 tbody tr:last-child td {
  border-bottom: 0;
}
new-release--widgets--access-102035 thead th:not(:first-child),
new-release--widgets--access-102035 td {
  min-width: 5rem;
}
new-release--widgets--access-102035 .nr-access__role-number {
  border: 0;
  background: none;
  color: #c4ccdc;
  min-width: 44px;
  min-height: 44px;
}
new-release--widgets--access-102035 .nr-access__role-popover {
  position: fixed;
  inset: auto;
  margin: 0;
  width: 240px;
  max-width: calc(100vw - 16px);
  padding: 0.75rem;
  border: 1px solid #344155;
  border-radius: 0.5rem;
  background: #182130;
  color: #e5e7eb;
  overflow-wrap: anywhere;
  box-shadow: 0 8px 24px #0008;
}
new-release--widgets--access-102035 .nr-access__role-edit {
  display: block;
  border: 0;
  background: none;
  color: #94c7fa;
  font-size: 0.8rem;
  padding: 0.5rem 0;
  min-height: 44px;
}
new-release--widgets--access-102035 td > .nr-access__indicator {
  display: inline-grid;
  place-items: center;
  width: 44px;
  height: 44px;
  padding: 0;
  border: 0;
  background: none;
}
new-release--widgets--access-102035 .nr-access__indicator > span {
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  border: 1px solid #4bd69a;
  border-radius: 0.3rem;
  background: #1e694a;
  color: #b6f5d6;
}
new-release--widgets--access-102035 .nr-access__absent {
  color: #647187;
}
new-release--widgets--access-102035 .nr-access__workspace {
  display: grid;
  padding: 1.5rem;
  max-width: 66rem;
  margin: auto;
}
new-release--widgets--access-102035 .nr-access__actor,
new-release--widgets--access-102035 .nr-access__grant-detail {
  display: grid;
  gap: 1rem;
  min-width: 0;
  padding: 1.5rem;
  border: 1px solid #2c3748;
  border-radius: 0.8rem;
  background: #131923;
}
new-release--widgets--access-102035 article > header {
  display: flex;
  align-items: start;
  gap: 0.75rem;
  justify-content: space-between;
}
new-release--widgets--access-102035 article > header code {
  display: block;
  margin: 0.5rem 0;
}
new-release--widgets--access-102035 label {
  display: grid;
  align-content: start;
  gap: 0.5rem;
  font-size: 0.85rem;
}
new-release--widgets--access-102035 label > span,
new-release--widgets--access-102035 dt {
  color: #b1bfd1;
}
new-release--widgets--access-102035 label small {
  color: #9aa7ba;
}
new-release--widgets--access-102035 .nr-access__edit-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1rem;
}
new-release--widgets--access-102035 .is-wide {
  grid-column: 1 / -1;
}
new-release--widgets--access-102035 .nr-access__title-input {
  font-size: 1.1rem;
  font-weight: 600;
}
new-release--widgets--access-102035 dl {
  display: flex;
  gap: 2rem;
}
new-release--widgets--access-102035 dd {
  margin: 0.5rem 0;
}
new-release--widgets--access-102035 .nr-access__edit-footer {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.5rem;
  border-top: 1px solid #2c3748;
  background: #10151e;
  font-size: 0.85rem;
}
new-release--widgets--access-102035 .nr-access__edit-footer > div {
  display: flex;
  gap: 0.75rem;
}
new-release--widgets--access-102035 .nr-access__edit-footer button {
  padding: 0.6rem 1rem;
  border: 1px solid #344155;
  border-radius: 0.5rem;
  background: #1c2839;
}
new-release--widgets--access-102035 .nr-access__edit-footer button.is-primary {
  background: #2469af;
}
new-release--widgets--access-102035 button:disabled {
  opacity: 0.45;
  cursor: default;
}
new-release--widgets--access-102035 .nr-access__issues {
  padding: 1rem 1.5rem;
  color: #ffd89c;
  background: #30271c;
}
new-release--widgets--access-102035 .nr-access__issues header {
  display: flex;
  gap: 1rem;
}
new-release--widgets--access-102035 .nr-access__issues article {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  align-items: center;
}
new-release--widgets--access-102035 .nr-access__issues code {
  color: inherit;
}
new-release--widgets--access-102035 .nr-access__empty {
  padding: 2rem;
}
@media (max-width: 700px) {
  new-release--widgets--access-102035 .nr-access__workspace,
  new-release--widgets--access-102035 .nr-access__matrix {
    padding: 0.75rem;
  }
  new-release--widgets--access-102035 .nr-access__actor,
  new-release--widgets--access-102035 .nr-access__grant-detail {
    padding: 1rem;
  }
  new-release--widgets--access-102035 .nr-access__edit-grid {
    grid-template-columns: 1fr;
  }
  new-release--widgets--access-102035 .is-wide {
    grid-column: auto;
  }
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.detailKind = '';
        this.editSnapshot = '';
        this.selectedActorId = '';
        this.selectedGrantId = '';
        this.accessDraft = null;
        this.suppliedIssues = [];
        this.gateIssues = [];
        this.editMessage = '';
    }
    createRenderRoot() { return this; }
    updated(changed) {
        if (changed.has('data') || changed.has('mode') || changed.has('detailKind') || changed.has('accessDraft') || changed.has('t')) {
            this.publishPresentation();
        }
    }
    publishPresentation() {
        const access = this.currentAccess();
        const presentation = {
            nodes: access ? accessTextNodes(access, this.t('access.unassigned')).map(node => ({ ...node,
                changed: node.id.startsWith('actor:') && this.changedActor(node.id.slice(6)),
                children: node.children.map(child => ({ ...child, changed: this.changedGrant(child.id.slice(6)) })),
            })) : [],
            detail: !!this.detailKind,
            select: id => {
                if (id.startsWith('actor:'))
                    this.selectActor(id.slice(6));
                if (id.startsWith('grant:'))
                    this.selectGrant(id.slice(6));
            },
            back: () => { if (canDiscardNewReleaseDraft(this))
                this.cancelEdit(); },
        };
        this.dispatchEvent(new CustomEvent('nr-view-state', { bubbles: true, composed: true, detail: presentation }));
    }
    changedActor(id) { return hasItemDiff(this.data?.diffs || [], 'access.defs.ts', idScope('actors', 'actorId', id)); }
    changedGrant(id) { return hasItemDiff(this.data?.diffs || [], 'access.defs.ts', idScope('grants', 'grantId', id)); }
    getDraft() {
        const access = this.currentAccess();
        return access ? structuredClone(access) : null;
    }
    setIssues(issues) {
        this.suppliedIssues = accessOracleIssues(issues);
    }
    currentAccess() {
        return this.mode === 'edit' && this.accessDraft
            ? this.accessDraft
            : this.data?.artifacts.access.value || null;
    }
    entities() {
        return this.data?.artifacts.entities.map(item => item.value)
            .filter((item) => !!item) || [];
    }
    index() {
        return this.data?.artifacts.ontologyIndex.value || null;
    }
    journeys() {
        return this.data?.artifacts.journeys.map(item => item.value)
            .filter((item) => !!item) || [];
    }
    actor() {
        return this.currentAccess()?.actors.find(actor => actor.actorId === this.selectedActorId) || null;
    }
    grant() {
        return this.currentAccess()?.grants.find(grant => grant.grantId === this.selectedGrantId) || null;
    }
    entityTitle(entityId) {
        return this.entities().find(entity => entity.entityId === entityId)?.title || entityId;
    }
    selectActor(actorId) {
        if (!canDiscardNewReleaseDraft(this))
            return;
        if (this.version === 'asis') {
            requestNewReleaseEdit(this, `actor:${actorId}`);
            return;
        }
        this.cancelEdit();
        this.selectedActorId = actorId;
        this.detailKind = 'actor';
        this.beginEdit();
    }
    selectGrant(grantId) {
        if (!canDiscardNewReleaseDraft(this))
            return;
        if (this.version === 'asis') {
            requestNewReleaseEdit(this, `grant:${grantId}`);
            return;
        }
        this.cancelEdit();
        const grant = this.currentAccess()?.grants.find(item => item.grantId === grantId);
        if (!grant)
            return;
        this.selectedActorId = grant.actorRef;
        this.selectedGrantId = grantId;
        this.detailKind = 'grant';
        this.beginEdit();
    }
    beginEdit() {
        const access = this.currentAccess();
        if (!access || this.version.startsWith('release:'))
            return;
        this.accessDraft = structuredClone(access);
        this.editSnapshot = JSON.stringify(access);
        this.mode = 'edit';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    cancelEdit() {
        this.detailKind = '';
        this.accessDraft = null;
        this.mode = 'view';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
        const access = this.currentAccess();
        const grants = access ? accessGrantsForActor(access, this.selectedActorId) : [];
        if (!grants.some(grant => grant.grantId === this.selectedGrantId))
            this.selectedGrantId = grants[0]?.grantId || '';
    }
    updateAccess(next) {
        this.accessDraft = next;
        this.dirty = JSON.stringify(next) !== this.editSnapshot;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateActor(patch) {
        if (!this.accessDraft)
            return;
        this.updateAccess(patchAccessActor(this.accessDraft, this.selectedActorId, patch));
    }
    updateGrant(patch) {
        if (!this.accessDraft)
            return;
        this.updateAccess(patchAccessGrant(this.accessDraft, this.selectedGrantId, patch));
    }
    updateScope(patch) {
        const grant = this.grant();
        if (!grant)
            return;
        const dataScope = { ...grant.dataScope, ...patch };
        if (patch.mode && !PERSON_SCOPE_MODES.includes(patch.mode))
            delete dataScope.anchorEntity;
        if (patch.mode && PERSON_SCOPE_MODES.includes(patch.mode)) {
            const anchors = reachablePersonAnchors(grant.entityRefs, this.entities(), this.index());
            if (!anchors.some(anchor => anchor.entityId === dataScope.anchorEntity))
                dataScope.anchorEntity = anchors[0]?.entityId;
        }
        this.updateGrant({ dataScope });
    }
    updateDisclosure(patch) {
        const grant = this.grant();
        if (!grant)
            return;
        const disclosure = { ...grant.disclosure, ...patch };
        if (patch.mode && !LIMITED_DISCLOSURE_MODES.includes(patch.mode)) {
            delete disclosure.allowedFields;
            delete disclosure.deniedFields;
        }
        this.updateGrant({ disclosure });
    }
    multiValues(event) {
        return [...event.currentTarget.selectedOptions].map(option => option.value);
    }
    updateEntities(entityRefs) {
        // References elsewhere in the grant are preserved for candidate validation to assess.
        this.updateGrant({ entityRefs });
    }
    async saveEdit() {
        if (!this.accessDraft || !this.dirty)
            return;
        try {
            await announceNewReleaseChange(this, { path: 'access.defs.ts', jsonPath: '$', value: structuredClone(this.accessDraft) });
            this.cancelEdit();
        }
        catch (error) {
            this.editMessage = this.t('access.gateUnavailable', { message: error instanceof Error ? error.message : String(error) });
        }
    }
    renderMatrix(access) {
        return html `<section class="nr-access__matrix"><header><div><span>${this.t('access.matrix')}</span><p>${this.t('access.matrixDescription')}</p></div><small>${this.t('access.matrixHint')}</small></header>
      <div class="nr-access__matrix-scroll"><table><thead><tr><th scope="col">${this.t('access.grants')}</th>${access.actors.map((actor, index) => html `<th scope="col"><button type="button" class="nr-access__role-number" popovertarget=${`nr-access-role-${index}`} aria-label=${actor.title} @pointerenter=${(event) => { if (event.pointerType === 'mouse')
            event.currentTarget.nextElementSibling?.showPopover(); }}>#${index + 1}${changedDot(this.changedActor(actor.actorId), this.t)}</button><div id=${`nr-access-role-${index}`} class="nr-access__role-popover" popover data-nr-hint @beforetoggle=${(event) => {
            const popup = event.currentTarget;
            const rect = popup.previousElementSibling.getBoundingClientRect();
            popup.style.left = `${Math.max(8, Math.min(rect.left, window.innerWidth - 248))}px`;
            popup.style.top = `${rect.bottom + 6}px`;
        }}><span>${actor.title}</span><button type="button" class="nr-access__role-edit" aria-label=${this.t('access.editActor', { actor: actor.title })} @click=${() => this.selectActor(actor.actorId)}>${this.t('access.edit')}</button></div></th>`)}</tr></thead>
      <tbody>${accessMatrixRows(access).map(({ grant, cells }) => html `<tr><th scope="row"><button type="button" @click=${() => this.selectGrant(grant.grantId)}><strong>${grant.title}</strong>${changedDot(this.changedGrant(grant.grantId), this.t)}<code>${grant.grantId}</code></button></th>${cells.map((checked, index) => html `<td>${checked ? html `<button type="button" class="nr-access__indicator" aria-label=${this.t('access.matrixCell', { actor: access.actors[index].title, grant: grant.title })} @click=${() => this.selectGrant(grant.grantId)}><span aria-hidden="true">✓</span></button>` : html `<span class="nr-access__absent" aria-label=${this.t('access.none')}>—</span>`}</td>`)}</tr>`)}</tbody></table></div></section>`;
    }
    renderActor(access, actor) {
        const people = this.entities().filter(accessIsPerson);
        const peopleIds = [...new Set([...(actor.personEntity ? [actor.personEntity] : []), ...people.map(entity => entity.entityId)])];
        return html `<article class="nr-access__actor"><header><span>${this.t('access.selectedActor')}</span><code>${actor.actorId}</code></header>
      <label><span>${this.t('access.actorTitle')}</span><input .value=${actor.title} @input=${(event) => this.updateActor({ title: event.currentTarget.value })}></label>
      <label><span>${this.t('access.actorDescription')}</span><textarea .value=${actor.description} @input=${(event) => this.updateActor({ description: event.currentTarget.value })}></textarea></label>
      <label><span>${this.t('access.kind')}</span><select .value=${actor.kind} @change=${(event) => this.updateActor({ kind: event.currentTarget.value })}>${ACTOR_KINDS.map(kind => html `<option value=${kind} ?selected=${actor.kind === kind}>${this.t(`access.kind.${kind}`)}</option>`)}</select></label>
      <label><span>${this.t('access.origin')}</span><select .value=${actor.origin} @change=${(event) => this.updateActor({ origin: event.currentTarget.value })}>${ACTOR_ORIGINS.map(origin => html `<option value=${origin} ?selected=${actor.origin === origin}>${this.t(`access.origin.${origin}`)}</option>`)}</select></label>
      <label><span>${this.t('access.personEntity')}</span><select .value=${actor.personEntity || ''} @change=${(event) => this.updateActor({ personEntity: event.currentTarget.value })}><option value="" ?selected=${!actor.personEntity}>${this.t('access.noPersonEntity')}</option>${peopleIds.map(id => html `<option value=${id} ?selected=${actor.personEntity === id}>${this.entityTitle(id)}</option>`)}</select></label>
      <dl><div><dt>${this.t('access.journeys')}</dt><dd>${accessJourneyCount(this.journeys(), actor.actorId)}</dd></div><div><dt>${this.t('access.grants')}</dt><dd>${accessGrantsForActor(access, actor.actorId).length}</dd></div></dl></article>`;
    }
    renderGrantEdit(grant) {
        const anchors = reachablePersonAnchors(grant.entityRefs, this.entities(), this.index());
        const fields = [...new Set([...accessFieldRefs(grant, this.entities()), ...(grant.disclosure.allowedFields || []), ...(grant.disclosure.deniedFields || [])])];
        const entityIds = [...new Set([...grant.entityRefs, ...this.entities().map(entity => entity.entityId)])];
        const anchorIds = [...new Set([...(grant.dataScope.anchorEntity ? [grant.dataScope.anchorEntity] : []), ...anchors.map(anchor => anchor.entityId)])];
        const fieldOption = (ref) => `${accessFieldLabel(ref, this.entities())} — ${ref}`;
        return html `<article class="nr-access__grant-detail is-editing"><header><div><span>${this.t('access.editing')}</span><input aria-label=${this.t('access.grantTitle')} class="nr-access__title-input" .value=${grant.title} @input=${(event) => this.updateGrant({ title: event.currentTarget.value })}><code>${grant.grantId}</code></div></header><label class="is-wide"><span>${this.t('access.grantDescription')}</span><textarea .value=${grant.description} @input=${(event) => this.updateGrant({ description: event.currentTarget.value })}></textarea></label><div class="nr-access__edit-grid"><label><span>${this.t('access.actor')}</span><select .value=${grant.actorRef} @change=${(event) => this.updateGrant({ actorRef: event.currentTarget.value })}>${[...new Set([grant.actorRef, ...(this.currentAccess()?.actors.map(actor => actor.actorId) || [])])].map(id => html `<option value=${id} ?selected=${grant.actorRef === id}>${this.currentAccess()?.actors.find(actor => actor.actorId === id)?.title || id}</option>`)}</select></label><label><span>${this.t('access.entities')}</span><select multiple @change=${(event) => this.updateEntities(this.multiValues(event))}>${entityIds.map(id => html `<option value=${id} ?selected=${grant.entityRefs.includes(id)}>${this.entityTitle(id)}</option>`)}</select></label><label><span>${this.t('access.scope')}</span><select .value=${grant.dataScope.mode} @change=${(event) => this.updateScope({ mode: event.currentTarget.value })}>${SCOPE_MODES.map(mode => html `<option value=${mode} ?selected=${grant.dataScope.mode === mode} ?disabled=${this.currentAccess()?.actors.find(actor => actor.actorId === grant.actorRef)?.kind === 'external' && mode !== 'own'}>${this.t(`access.scope.${mode}`)}</option>`)}</select></label>${PERSON_SCOPE_MODES.includes(grant.dataScope.mode) ? html `<label><span>${this.t('access.anchor')}</span><select .value=${grant.dataScope.anchorEntity || ''} @change=${(event) => this.updateScope({ anchorEntity: event.currentTarget.value || undefined })}><option value="" ?selected=${!grant.dataScope.anchorEntity}>${this.t('access.chooseAnchor')}</option>${anchorIds.map(id => html `<option value=${id} ?selected=${grant.dataScope.anchorEntity === id}>${this.entityTitle(id)}</option>`)}</select><small>${anchors.length ? this.t('access.anchorReachable') : this.t('access.anchorUnavailable')}</small></label>` : nothing}<label class="is-wide"><span>${this.t('access.scopeDescription')}</span><textarea .value=${grant.dataScope.description} @input=${(event) => this.updateScope({ description: event.currentTarget.value })}></textarea></label><label><span>${this.t('access.disclosure')}</span><select .value=${grant.disclosure.mode} @change=${(event) => this.updateDisclosure({ mode: event.currentTarget.value })}>${DISCLOSURE_MODES.map(mode => html `<option value=${mode} ?selected=${grant.disclosure.mode === mode}>${this.t(`access.disclosure.${mode}`)}</option>`)}</select></label><label class="is-wide"><span>${this.t('access.disclosureDescription')}</span><textarea .value=${grant.disclosure.description} @input=${(event) => this.updateDisclosure({ description: event.currentTarget.value })}></textarea></label>${LIMITED_DISCLOSURE_MODES.includes(grant.disclosure.mode) ? html `<label><span>${this.t('access.allowedFields')}</span><select multiple @change=${(event) => this.updateDisclosure({ allowedFields: this.multiValues(event) })}>${fields.map(ref => html `<option value=${ref} ?selected=${grant.disclosure.allowedFields?.includes(ref)}>${fieldOption(ref)}</option>`)}</select></label><label><span>${this.t('access.deniedFields')}</span><select multiple @change=${(event) => this.updateDisclosure({ deniedFields: this.multiValues(event) })}>${fields.map(ref => html `<option value=${ref} ?selected=${grant.disclosure.deniedFields?.includes(ref)}>${fieldOption(ref)}</option>`)}</select></label>` : nothing}</div></article>`;
    }
    issues() {
        const source = [...(this.data?.validation.issues || []), ...this.suppliedIssues];
        const mapped = accessOracleIssues(source).map(issue => ({ severity: issue.severity, code: issue.code, message: issue.message }));
        return [...new Map([...mapped, ...this.gateIssues].map(issue => [`${issue.code}:${issue.message}`, issue])).values()];
    }
    renderIssues() {
        const issues = this.issues();
        if (!issues.length && !this.editMessage)
            return nothing;
        return html `<section class="nr-access__issues" role="alert"><header><strong>${this.t('access.issues')}</strong><span>${this.t('access.issueCount', { count: issues.length })}</span></header>${this.editMessage ? html `<p>${this.editMessage}</p>` : nothing}<div>${issues.map(issue => html `<article class=${`is-${issue.severity}`}><code>${issue.code}</code><p>${issue.message}</p></article>`)}</div></section>`;
    }
    render() {
        const access = this.currentAccess();
        if (!access)
            return html `<section class="nr-access__empty"><h2>${this.t('access.emptyTitle')}</h2><p>${this.t('access.emptyBody')}</p></section>`;
        const actor = this.actor();
        const grant = this.grant();
        return html `<section class="nr-access">${this.renderIssues()}${this.detailKind ? html `<div class="nr-access__workspace">${this.detailKind === 'actor' && actor ? this.renderActor(access, actor) : this.detailKind === 'grant' && grant ? this.renderGrantEdit(grant) : nothing}</div>` : this.renderMatrix(access)}${this.mode === 'edit' ? html `<footer class="nr-access__edit-footer"><span>${this.dirty ? this.t('access.unsaved') : this.t('access.noChanges')}</span><div><button type="button" @click=${() => { if (canDiscardNewReleaseDraft(this))
            this.cancelEdit(); }}>${this.t('access.cancel')}</button><button class="is-primary" type="button" ?disabled=${!this.dirty} @click=${() => void this.saveEdit()}>${this.t('access.save')}</button></div></footer>` : nothing}</section>`;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseAccess102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseAccess102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseAccess102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseAccess102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseAccess102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseAccess102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseAccess102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "detailKind", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "selectedActorId", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "selectedGrantId", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "accessDraft", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "suppliedIssues", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "gateIssues", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "editMessage", void 0);
NewReleaseAccess102035 = __decorate([
    customElement('new-release--widgets--access-102035')
], NewReleaseAccess102035);
export { NewReleaseAccess102035 };
