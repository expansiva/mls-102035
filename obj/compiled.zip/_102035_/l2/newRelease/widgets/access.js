/// <mls fileReference="_102035_/l2/newRelease/widgets/access.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { announceNewReleaseChange, } from '/_102035_/l2/newRelease/editContract.js';
import { accessAnchorPaths, accessFieldLabel, accessFieldRefs, accessGrantsForActor, accessJourneyCount, accessOracleIssues, bestAccessGrant, newAccessGrant, reachablePersonAnchors, } from '/_102035_/l2/newRelease/widgets/accessModel.js';
const SCOPE_MODES = ['own', 'assigned', 'related', 'public', 'organization', 'custom'];
const DISCLOSURE_MODES = ['fullRecord', 'fieldsOnly', 'summaryOnly', 'aggregateOnly'];
const PERSON_SCOPE_MODES = ['own', 'assigned', 'related'];
const LIMITED_DISCLOSURE_MODES = ['fieldsOnly', 'summaryOnly'];
const ACTOR_KINDS = ['internal', 'external', 'system'];
let NewReleaseAccess102035 = class NewReleaseAccess102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--access-102035 {
  display: block;
}
new-release--widgets--access-102035 * {
  box-sizing: border-box;
}
new-release--widgets--access-102035 h2,
new-release--widgets--access-102035 h3,
new-release--widgets--access-102035 p,
new-release--widgets--access-102035 dl,
new-release--widgets--access-102035 dd {
  margin: 0;
}
new-release--widgets--access-102035 button,
new-release--widgets--access-102035 input,
new-release--widgets--access-102035 select,
new-release--widgets--access-102035 textarea {
  font: inherit;
}
new-release--widgets--access-102035 button {
  cursor: pointer;
}
new-release--widgets--access-102035 code {
  font-family: var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--access-102035 input,
new-release--widgets--access-102035 select,
new-release--widgets--access-102035 textarea {
  width: 100%;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--access-102035 input,
new-release--widgets--access-102035 select {
  min-height: 2.25rem;
  padding: 0.42rem 0.58rem;
}
new-release--widgets--access-102035 textarea {
  min-height: 4.5rem;
  padding: 0.55rem 0.62rem;
  resize: vertical;
  line-height: 1.45;
}
new-release--widgets--access-102035 select[multiple] {
  min-height: 8rem;
}
new-release--widgets--access-102035 input:focus,
new-release--widgets--access-102035 select:focus,
new-release--widgets--access-102035 textarea:focus,
new-release--widgets--access-102035 button:focus-visible {
  border-color: var(--focus-border, #1273d4);
  outline: 2px solid color-mix(in srgb, var(--focus-border, #1273d4) 22%, transparent);
  outline-offset: 1px;
}
new-release--widgets--access-102035 .nr-access {
  display: grid;
  min-width: 0;
  color: var(--text-default, #2f3a48);
}
new-release--widgets--access-102035 .nr-access__hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.2rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: linear-gradient(135deg, var(--surface-bg, #fff), color-mix(in srgb, var(--selected-bg, #e3f1ff) 46%, var(--surface-bg, #fff)));
}
new-release--widgets--access-102035 .nr-access__hero > div > span,
new-release--widgets--access-102035 .nr-access__matrix > header span,
new-release--widgets--access-102035 .nr-access__actor > header span,
new-release--widgets--access-102035 .nr-access__grant-detail > header span,
new-release--widgets--access-102035 .nr-access__boundary > section > span {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 800;
  letter-spacing: 0.11em;
  text-transform: uppercase;
}
new-release--widgets--access-102035 .nr-access__hero h2 {
  margin-top: 0.28rem;
  color: var(--text-strong, #111827);
  font-size: 1.5rem;
  letter-spacing: -0.03em;
}
new-release--widgets--access-102035 .nr-access__hero p {
  max-width: 47rem;
  margin-top: 0.42rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--access-102035 .nr-access__hero dl {
  display: flex;
  overflow: hidden;
  border: 1px solid color-mix(in srgb, var(--selected-border, #1273d4) 24%, var(--border-subtle, #e4e9f0));
  border-radius: 0.82rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--access-102035 .nr-access__hero dl div {
  display: grid;
  min-width: 5rem;
  place-items: center;
  padding: 0.55rem 0.75rem;
}
new-release--widgets--access-102035 .nr-access__hero dl div + div {
  border-left: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--access-102035 .nr-access__hero dt {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--access-102035 .nr-access__hero dd {
  order: -1;
  color: var(--text-strong, #111827);
  font-size: 1.2rem;
  font-weight: 800;
  letter-spacing: -0.04em;
}
new-release--widgets--access-102035 .nr-access__matrix {
  min-width: 0;
  padding: 0.9rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--access-102035 .nr-access__matrix > header {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 1rem;
  margin-bottom: 0.55rem;
}
new-release--widgets--access-102035 .nr-access__matrix > header p,
new-release--widgets--access-102035 .nr-access__matrix > header small {
  margin-top: 0.2rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
}
new-release--widgets--access-102035 .nr-access__matrix-scroll {
  overflow-x: auto;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.72rem;
  background: var(--surface-bg, #fff);
  box-shadow: 0 0.2rem 0.8rem color-mix(in srgb, var(--text-strong, #111827) 5%, transparent);
}
new-release--widgets--access-102035 .nr-access__matrix table {
  width: 100%;
  min-width: 45rem;
  border-collapse: collapse;
}
new-release--widgets--access-102035 .nr-access__matrix th {
  padding: 0.5rem 0.55rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
  letter-spacing: 0.045em;
  text-align: center;
  text-transform: uppercase;
}
new-release--widgets--access-102035 .nr-access__matrix th:first-child {
  position: sticky;
  left: 0;
  z-index: 2;
  min-width: 11rem;
  text-align: left;
}
new-release--widgets--access-102035 .nr-access__matrix td,
new-release--widgets--access-102035 .nr-access__matrix tbody th {
  padding: 0.28rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  border-right: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--access-102035 .nr-access__matrix tbody tr:first-child td,
new-release--widgets--access-102035 .nr-access__matrix tbody tr:first-child th {
  border-top: 0;
}
new-release--widgets--access-102035 .nr-access__matrix tbody tr.is-selected {
  background: color-mix(in srgb, var(--selected-bg, #e3f1ff) 44%, transparent);
}
new-release--widgets--access-102035 .nr-access__matrix tbody th {
  position: sticky;
  left: 0;
  z-index: 1;
  background: var(--surface-bg, #fff);
}
new-release--widgets--access-102035 .nr-access__matrix tbody tr.is-selected th {
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--access-102035 .nr-access__matrix tbody th button {
  display: grid;
  width: 100%;
  gap: 0.1rem;
  padding: 0.3rem 0.38rem;
  border: 0;
  background: transparent;
  color: var(--text-default, #2f3a48);
  text-align: left;
}
new-release--widgets--access-102035 .nr-access__matrix tbody th strong {
  color: var(--text-strong, #111827);
  font-size: 0.68rem;
}
new-release--widgets--access-102035 .nr-access__matrix tbody th code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.54rem;
  text-transform: none;
}
new-release--widgets--access-102035 .nr-access__matrix td > button {
  display: flex;
  width: 100%;
  min-width: 7.2rem;
  min-height: 2.3rem;
  align-items: center;
  justify-content: space-between;
  gap: 0.35rem;
  padding: 0.38rem 0.48rem;
  border: 1px solid transparent;
  border-radius: 0.52rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
}
new-release--widgets--access-102035 .nr-access__matrix td > button:hover {
  border-color: var(--selected-border, #1273d4);
  transform: translateY(-1px);
}
new-release--widgets--access-102035 .nr-access__matrix td > button span {
  overflow: hidden;
  font-size: 0.61rem;
  font-weight: 800;
  letter-spacing: 0;
  text-overflow: ellipsis;
  text-transform: none;
  white-space: nowrap;
}
new-release--widgets--access-102035 .nr-access__matrix td > button i {
  display: grid;
  width: 1.35rem;
  height: 1.35rem;
  flex: 0 0 auto;
  place-items: center;
  border-radius: 0.35rem;
  background: color-mix(in srgb, var(--surface-bg, #fff) 70%, transparent);
}
new-release--widgets--access-102035 .nr-access__matrix svg {
  width: 0.9rem;
  height: 0.9rem;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 1.7;
}
new-release--widgets--access-102035 .nr-access__matrix .scope-public {
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--access-102035 .nr-access__matrix .scope-custom {
  background: var(--status-warning-bg, #fff1c2);
  color: var(--status-warning-text, #7a4b00);
}
new-release--widgets--access-102035 .nr-access__matrix td > button.is-empty {
  justify-content: center;
  border-style: dashed;
  border-color: var(--border-default, #cfd8e3);
  background: transparent;
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--access-102035 .nr-access__matrix .is-empty small {
  font-size: 0.57rem;
}
new-release--widgets--access-102035 .nr-access__issues {
  margin: 0.85rem 1.25rem 0;
  overflow: hidden;
  border: 1px solid color-mix(in srgb, var(--status-warning-text, #7a4b00) 28%, var(--border-subtle, #e4e9f0));
  border-radius: 0.72rem;
  background: var(--status-warning-bg, #fff1c2);
}
new-release--widgets--access-102035 .nr-access__issues > header {
  display: flex;
  justify-content: space-between;
  padding: 0.55rem 0.7rem;
  border-bottom: 1px solid color-mix(in srgb, var(--status-warning-text, #7a4b00) 18%, transparent);
}
new-release--widgets--access-102035 .nr-access__issues > header strong,
new-release--widgets--access-102035 .nr-access__issues > header span {
  font-size: 0.65rem;
}
new-release--widgets--access-102035 .nr-access__issues > p {
  padding: 0.5rem 0.7rem;
  font-size: 0.67rem;
}
new-release--widgets--access-102035 .nr-access__issues > div {
  display: grid;
  gap: 0.35rem;
  padding: 0.55rem 0.7rem;
}
new-release--widgets--access-102035 .nr-access__issues article {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 0.5rem;
  align-items: start;
}
new-release--widgets--access-102035 .nr-access__issues article code {
  padding: 0.1rem 0.28rem;
  border-radius: 0.28rem;
  background: var(--surface-bg, #fff);
  font-size: 0.54rem;
  font-weight: 700;
}
new-release--widgets--access-102035 .nr-access__issues article p {
  font-size: 0.65rem;
  line-height: 1.4;
}
new-release--widgets--access-102035 .nr-access__issues article.is-error {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--access-102035 .nr-access__workspace {
  display: grid;
  grid-template-columns: minmax(14rem, 0.78fr) minmax(0, 2.2fr);
  gap: 1rem;
  align-items: start;
  padding: 1rem 1.25rem 1.5rem;
}
new-release--widgets--access-102035 .nr-access__actor,
new-release--widgets--access-102035 .nr-access__grant-detail,
new-release--widgets--access-102035 .nr-access__grant-empty {
  min-width: 0;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.85rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--access-102035 .nr-access__actor {
  overflow: hidden;
}
new-release--widgets--access-102035 .nr-access__actor > header {
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
  padding: 0.65rem 0.75rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--access-102035 .nr-access__actor > header code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
}
new-release--widgets--access-102035 .nr-access__actor-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.55rem;
  padding: 0.75rem 0.8rem 0.35rem;
}
new-release--widgets--access-102035 .nr-access__actor-title h2 {
  color: var(--text-strong, #111827);
  font-size: 1.05rem;
}
new-release--widgets--access-102035 .nr-access__actor-title > span {
  flex: 0 0 auto;
  padding: 0.24rem 0.46rem;
  border-radius: 999px;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.56rem;
  font-weight: 800;
}
new-release--widgets--access-102035 .nr-access__actor-title .kind-external {
  background: var(--status-warning-bg, #fff1c2);
  color: var(--status-warning-text, #7a4b00);
}
new-release--widgets--access-102035 .nr-access__actor-title .kind-system {
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--access-102035 .nr-access__actor > p {
  padding: 0 0.8rem 0.7rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
  line-height: 1.5;
}
new-release--widgets--access-102035 .nr-access__actor > label,
new-release--widgets--access-102035 .nr-access__grant-detail > label {
  display: grid;
  gap: 0.25rem;
  margin: 0.45rem 0.8rem;
}
new-release--widgets--access-102035 .nr-access__actor label > span,
new-release--widgets--access-102035 .nr-access__grant-detail label > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
  font-weight: 750;
}
new-release--widgets--access-102035 .nr-access__actor dl {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  margin: 0.2rem 0.8rem 0.8rem;
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.55rem;
}
new-release--widgets--access-102035 .nr-access__actor dl div {
  display: grid;
  gap: 0.1rem;
  padding: 0.45rem;
  text-align: center;
}
new-release--widgets--access-102035 .nr-access__actor dl div + div {
  border-left: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--access-102035 .nr-access__actor dt {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.52rem;
  text-transform: uppercase;
}
new-release--widgets--access-102035 .nr-access__actor dd {
  color: var(--text-strong, #111827);
  font-size: 0.68rem;
  font-weight: 800;
}
new-release--widgets--access-102035 .nr-access__grant-list {
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--access-102035 .nr-access__grant-list > header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.55rem 0.65rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--access-102035 .nr-access__grant-list > header strong {
  font-size: 0.64rem;
}
new-release--widgets--access-102035 .nr-access__grant-list > header button {
  border: 0;
  background: transparent;
  color: var(--link-text, #0f62b8);
  font-size: 0.61rem;
  font-weight: 750;
}
new-release--widgets--access-102035 .nr-access__grant-list > button {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  padding: 0.62rem 0.68rem;
  border: 0;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  text-align: left;
}
new-release--widgets--access-102035 .nr-access__grant-list > button.is-active {
  border-left: 0.2rem solid var(--selected-border, #1273d4);
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--access-102035 .nr-access__grant-list > button span {
  display: grid;
  min-width: 0;
  gap: 0.12rem;
}
new-release--widgets--access-102035 .nr-access__grant-list > button strong {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.67rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--access-102035 .nr-access__grant-list > button code {
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.53rem;
  text-overflow: ellipsis;
}
new-release--widgets--access-102035 .nr-access__grant-list > button i {
  flex: 0 0 auto;
  color: var(--link-text, #0f62b8);
  font-size: 0.55rem;
  font-style: normal;
  font-weight: 700;
}
new-release--widgets--access-102035 .nr-access__no-grants {
  padding: 0.7rem !important;
  text-align: center;
}
new-release--widgets--access-102035 .nr-access__grant-detail {
  display: grid;
  gap: 0.8rem;
  padding: 0.85rem 0.9rem 1rem;
}
new-release--widgets--access-102035 .nr-access__grant-detail > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1rem;
}
new-release--widgets--access-102035 .nr-access__grant-detail > header h2 {
  margin-top: 0.2rem;
  color: var(--text-strong, #111827);
  font-size: 1.25rem;
  letter-spacing: -0.025em;
}
new-release--widgets--access-102035 .nr-access__grant-detail > header code {
  display: block;
  margin-top: 0.2rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
}
new-release--widgets--access-102035 .nr-button {
  min-height: 2.2rem;
  padding: 0.4rem 0.72rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--access-102035 .nr-button.is-danger {
  border-color: color-mix(in srgb, var(--status-error-text, #ab2328) 26%, var(--border-default, #cfd8e3));
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--access-102035 .nr-access__lead {
  color: var(--text-default, #2f3a48);
  font-size: 0.76rem;
  line-height: 1.55;
}
new-release--widgets--access-102035 .nr-access__entities {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.35rem;
}
new-release--widgets--access-102035 .nr-access__entities strong {
  margin-right: 0.2rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
  text-transform: uppercase;
}
new-release--widgets--access-102035 .nr-access__entities button {
  padding: 0.26rem 0.48rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--link-text, #0f62b8);
  font-size: 0.59rem;
}
new-release--widgets--access-102035 .nr-access__boundary {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.7rem;
}
new-release--widgets--access-102035 .nr-access__boundary > section {
  min-width: 0;
  padding: 0.75rem 0.8rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.72rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--access-102035 .nr-access__boundary h3 {
  margin-top: 0.2rem;
  color: var(--text-strong, #111827);
  font-size: 0.85rem;
}
new-release--widgets--access-102035 .nr-access__boundary section > p {
  margin-top: 0.32rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
  line-height: 1.5;
}
new-release--widgets--access-102035 .nr-access__anchor {
  display: grid;
  gap: 0.35rem;
  margin-top: 0.65rem;
  padding-top: 0.55rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--access-102035 .nr-access__anchor > strong {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
  text-transform: uppercase;
}
new-release--widgets--access-102035 .nr-access__anchor > code {
  color: var(--text-strong, #111827);
  font-size: 0.63rem;
}
new-release--widgets--access-102035 .nr-access__anchor p {
  display: grid;
  gap: 0.12rem;
  padding: 0.4rem;
  border-radius: 0.48rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--access-102035 .nr-access__anchor p span {
  color: var(--text-default, #2f3a48);
  font-size: 0.61rem;
  font-weight: 700;
}
new-release--widgets--access-102035 .nr-access__anchor p small {
  color: var(--text-muted, #5d6b7e);
  font: 0.52rem var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--access-102035 .nr-access__field-groups {
  display: grid;
  gap: 0.5rem;
  margin-top: 0.65rem;
}
new-release--widgets--access-102035 .nr-access__field-groups > div {
  display: flex;
  flex-wrap: wrap;
  gap: 0.28rem;
  align-items: center;
}
new-release--widgets--access-102035 .nr-access__field-groups strong {
  flex: 0 0 100%;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
  text-transform: uppercase;
}
new-release--widgets--access-102035 .nr-access__field-chip {
  display: grid;
  gap: 0.05rem;
  padding: 0.28rem 0.48rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.48rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--access-102035 .nr-access__field-chip strong {
  color: var(--text-strong, #111827);
  font-size: 0.59rem;
  text-transform: none;
}
new-release--widgets--access-102035 .nr-access__field-chip code {
  color: var(--link-text, #0f62b8);
  font-size: 0.53rem;
}
new-release--widgets--access-102035 .nr-access__field-groups .is-denied .nr-access__field-chip {
  background: var(--status-error-bg, #fde8e9);
}
new-release--widgets--access-102035 .nr-access__field-groups .is-denied .nr-access__field-chip code {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--access-102035 .nr-access__title-input {
  min-width: min(28rem, 48vw);
  margin-top: 0.2rem;
  color: var(--text-strong, #111827);
  font-size: 1.05rem;
  font-weight: 750;
}
new-release--widgets--access-102035 .nr-access__edit-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.65rem;
}
new-release--widgets--access-102035 .nr-access__edit-grid label {
  display: grid;
  align-content: start;
  gap: 0.25rem;
}
new-release--widgets--access-102035 .nr-access__edit-grid label.is-wide {
  grid-column: 1 / -1;
}
new-release--widgets--access-102035 .nr-access__edit-grid label > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
  font-weight: 750;
}
new-release--widgets--access-102035 .nr-access__edit-grid label > small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
  line-height: 1.35;
}
new-release--widgets--access-102035 .nr-access__grant-empty {
  display: grid;
  min-height: 16rem;
  place-items: center;
  align-content: center;
  gap: 0.45rem;
  padding: 2rem;
  text-align: center;
}
new-release--widgets--access-102035 .nr-access__grant-empty > span {
  display: grid;
  width: 2.4rem;
  height: 2.4rem;
  place-items: center;
  border-radius: 0.72rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 1.4rem;
}
new-release--widgets--access-102035 .nr-access__grant-empty h2 {
  color: var(--text-strong, #111827);
  font-size: 1rem;
}
new-release--widgets--access-102035 .nr-access__grant-empty p {
  max-width: 25rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
}
new-release--widgets--access-102035 .nr-access__grant-empty button {
  margin-top: 0.35rem;
  padding: 0.45rem 0.75rem;
  border: 0;
  border-radius: 0.55rem;
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--access-102035 .nr-access__edit-footer {
  position: sticky;
  z-index: 5;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.72rem 1.25rem;
  border-top: 1px solid var(--border-default, #cfd8e3);
  background: color-mix(in srgb, var(--surface-bg, #fff) 94%, transparent);
  box-shadow: 0 -0.5rem 1.4rem color-mix(in srgb, var(--text-strong, #111827) 8%, transparent);
  backdrop-filter: blur(10px);
}
new-release--widgets--access-102035 .nr-access__edit-footer > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--access-102035 .nr-access__edit-footer > div {
  display: flex;
  gap: 0.5rem;
}
new-release--widgets--access-102035 .nr-access__edit-footer button {
  min-height: 2.15rem;
  padding: 0.42rem 0.72rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.7rem;
  font-weight: 750;
}
new-release--widgets--access-102035 .nr-access__edit-footer button.is-primary {
  border-color: var(--action-primary-bg, #126fc2);
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
}
new-release--widgets--access-102035 .nr-access__edit-footer button:disabled {
  cursor: not-allowed;
  opacity: 0.48;
}
new-release--widgets--access-102035 .nr-access__empty {
  padding: 3rem 1.25rem;
  text-align: center;
}
new-release--widgets--access-102035 .nr-access__empty h2 {
  color: var(--text-strong, #111827);
}
new-release--widgets--access-102035 .nr-access__empty p {
  margin-top: 0.4rem;
  color: var(--text-muted, #5d6b7e);
}
@media (max-width: 820px) {
  new-release--widgets--access-102035 .nr-access__hero,
  new-release--widgets--access-102035 .nr-access__matrix > header,
  new-release--widgets--access-102035 .nr-access__edit-footer {
    align-items: stretch;
    flex-direction: column;
  }
  new-release--widgets--access-102035 .nr-access__hero dl {
    align-self: flex-start;
  }
  new-release--widgets--access-102035 .nr-access__workspace,
  new-release--widgets--access-102035 .nr-access__boundary,
  new-release--widgets--access-102035 .nr-access__edit-grid {
    grid-template-columns: 1fr;
  }
  new-release--widgets--access-102035 .nr-access__edit-grid label.is-wide {
    grid-column: auto;
  }
  new-release--widgets--access-102035 .nr-access__title-input {
    min-width: 0;
  }
  new-release--widgets--access-102035 .nr-access__edit-footer > div {
    justify-content: flex-end;
  }
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.selectedActorId = '';
        this.selectedGrantId = '';
        this.accessDraft = null;
        this.suppliedIssues = [];
        this.gateIssues = [];
        this.editMessage = '';
    }
    createRenderRoot() { return this; }
    updated(changed) {
        if (!changed.has('data') || this.mode === 'edit')
            return;
        const access = this.currentAccess();
        if (!access)
            return;
        if (!access.actors.some(actor => actor.actorId === this.selectedActorId)) {
            this.selectedActorId = access.actors[0]?.actorId || '';
        }
        const grants = accessGrantsForActor(access, this.selectedActorId);
        if (!grants.some(grant => grant.grantId === this.selectedGrantId)) {
            this.selectedGrantId = grants[0]?.grantId || '';
        }
    }
    getDraft() {
        const access = this.currentAccess();
        return access ? structuredClone(access) : null;
    }
    setIssues(issues) {
        this.suppliedIssues = accessOracleIssues(issues);
    }
    currentAccess() {
        return this.mode === 'edit' && this.accessDraft
            ? this.accessDraft
            : this.data?.artifacts.access.value || null;
    }
    entities() {
        return this.data?.artifacts.entities.map(item => item.value)
            .filter((item) => item?.schemaVersion === '2026-09-11-ns5-ontology-v2') || [];
    }
    index() {
        const value = this.data?.artifacts.ontologyIndex.value;
        return value?.schemaVersion === '2026-09-11-ns5-ontology-v2' ? value : null;
    }
    journeys() {
        return this.data?.artifacts.journeys.map(item => item.value)
            .filter((item) => !!item) || [];
    }
    actor() {
        return this.currentAccess()?.actors.find(actor => actor.actorId === this.selectedActorId) || null;
    }
    grant() {
        return this.currentAccess()?.grants.find(grant => grant.grantId === this.selectedGrantId) || null;
    }
    entityTitle(entityId) {
        return this.entities().find(entity => entity.entityId === entityId)?.title || entityId;
    }
    selectActor(actorId) {
        this.selectedActorId = actorId;
        this.selectedGrantId = accessGrantsForActor(this.currentAccess(), actorId)[0]?.grantId || '';
    }
    selectGrant(grantId) {
        const grant = this.currentAccess()?.grants.find(item => item.grantId === grantId);
        if (!grant)
            return;
        this.selectedActorId = grant.actorRef;
        this.selectedGrantId = grantId;
    }
    beginEdit() {
        const access = this.currentAccess();
        if (!access)
            return;
        this.accessDraft = structuredClone(access);
        this.mode = 'edit';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    cancelEdit() {
        this.accessDraft = null;
        this.mode = 'view';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
        const access = this.currentAccess();
        const grants = access ? accessGrantsForActor(access, this.selectedActorId) : [];
        if (!grants.some(grant => grant.grantId === this.selectedGrantId))
            this.selectedGrantId = grants[0]?.grantId || '';
    }
    updateAccess(next) {
        this.accessDraft = next;
        this.dirty = true;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateActor(patch) {
        if (!this.accessDraft)
            return;
        this.updateAccess({
            ...this.accessDraft,
            actors: this.accessDraft.actors.map(actor => actor.actorId === this.selectedActorId ? { ...actor, ...patch } : actor),
        });
    }
    updateGrant(patch) {
        if (!this.accessDraft)
            return;
        this.updateAccess({
            ...this.accessDraft,
            grants: this.accessDraft.grants.map(grant => grant.grantId === this.selectedGrantId ? { ...grant, ...patch } : grant),
        });
    }
    updateScope(patch) {
        const grant = this.grant();
        if (!grant)
            return;
        const dataScope = { ...grant.dataScope, ...patch };
        if (patch.mode && !PERSON_SCOPE_MODES.includes(patch.mode))
            delete dataScope.anchorEntity;
        if (patch.mode && PERSON_SCOPE_MODES.includes(patch.mode)) {
            const anchors = reachablePersonAnchors(grant.entityRefs, this.entities(), this.index());
            if (!anchors.some(anchor => anchor.entityId === dataScope.anchorEntity))
                dataScope.anchorEntity = anchors[0]?.entityId;
        }
        this.updateGrant({ dataScope });
    }
    updateDisclosure(patch) {
        const grant = this.grant();
        if (!grant)
            return;
        const disclosure = { ...grant.disclosure, ...patch };
        if (patch.mode && !LIMITED_DISCLOSURE_MODES.includes(patch.mode)) {
            delete disclosure.allowedFields;
            delete disclosure.deniedFields;
        }
        this.updateGrant({ disclosure });
    }
    multiValues(event) {
        return [...event.currentTarget.selectedOptions].map(option => option.value);
    }
    updateEntities(entityRefs) {
        const grant = this.grant();
        if (!grant)
            return;
        const validFieldPrefixes = new Set(entityRefs.map(entityId => `${entityId}.`));
        const disclosure = {
            ...grant.disclosure,
            ...(grant.disclosure.allowedFields
                ? { allowedFields: grant.disclosure.allowedFields.filter(ref => [...validFieldPrefixes].some(prefix => ref.startsWith(prefix))) }
                : {}),
            ...(grant.disclosure.deniedFields
                ? { deniedFields: grant.disclosure.deniedFields.filter(ref => [...validFieldPrefixes].some(prefix => ref.startsWith(prefix))) }
                : {}),
        };
        const anchors = reachablePersonAnchors(entityRefs, this.entities(), this.index());
        const dataScope = { ...grant.dataScope };
        if (dataScope.anchorEntity && !anchors.some(anchor => anchor.entityId === dataScope.anchorEntity))
            delete dataScope.anchorEntity;
        if (PERSON_SCOPE_MODES.includes(dataScope.mode) && !dataScope.anchorEntity)
            dataScope.anchorEntity = anchors[0]?.entityId;
        this.updateGrant({ entityRefs, dataScope, disclosure });
    }
    addGrant(entityId = '') {
        const access = this.currentAccess();
        const actor = this.actor();
        if (!access || !actor)
            return;
        if (this.mode !== 'edit')
            this.beginEdit();
        const draft = this.accessDraft;
        const grant = newAccessGrant(draft, actor, entityId || this.entities()[0]?.entityId || '', {
            title: this.t('access.newGrantTitle'),
            description: this.t('access.newGrantDescription'),
            scopeDescription: this.t('access.newScopeDescription'),
            disclosureDescription: this.t('access.newDisclosureDescription'),
        });
        this.selectedGrantId = grant.grantId;
        this.updateAccess({ ...draft, grants: [...draft.grants, grant] });
    }
    removeGrant() {
        if (!this.accessDraft || !this.selectedGrantId)
            return;
        const grants = this.accessDraft.grants.filter(grant => grant.grantId !== this.selectedGrantId);
        const next = { ...this.accessDraft, grants };
        this.selectedGrantId = accessGrantsForActor(next, this.selectedActorId)[0]?.grantId || '';
        this.updateAccess(next);
    }
    clickMatrix(actor, entityId, grant) {
        if (grant) {
            this.selectGrant(grant.grantId);
            return;
        }
        this.selectedActorId = actor.actorId;
        this.addGrant(entityId);
    }
    async saveEdit() {
        if (!this.accessDraft || !this.dirty)
            return;
        try {
            const gate = await import('/_102035_/l2/agentNewSolution5/steps/access60/gate.js');
            const result = gate.validateNs5Access(this.accessDraft.grants, {
                moduleName: this.moduleName,
                actors: this.accessDraft.actors,
                entities: this.entities(),
                relationships: this.index()?.relationships || [],
                journeys: this.journeys(),
            });
            this.gateIssues = result.issues.map(issue => ({ severity: issue.severity, code: issue.code, message: issue.message }));
            if (!result.ok) {
                this.editMessage = this.t('access.gateBlocked');
                return;
            }
            announceNewReleaseChange(this, { path: 'access.defs.ts', jsonPath: '$', value: structuredClone(this.accessDraft) });
            this.cancelEdit();
        }
        catch (error) {
            this.editMessage = this.t('access.gateUnavailable', { message: error instanceof Error ? error.message : String(error) });
        }
    }
    disclosureIcon(mode) {
        if (mode === 'fullRecord')
            return svg `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16v12H4z"/><path d="M8 10h8M8 14h8"/></svg>`;
        if (mode === 'aggregateOnly')
            return svg `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 18V9M12 18V5M19 18v-6"/></svg>`;
        return svg `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 6h14M5 12h9M5 18h6"/><path d="m17 15 2 2 3-4"/></svg>`;
    }
    renderMatrix(access) {
        const entities = this.entities();
        return html `<section class="nr-access__matrix"><header><div><span>${this.t('access.matrix')}</span><p>${this.t('access.matrixDescription')}</p></div><small>${this.t('access.matrixHint')}</small></header><div class="nr-access__matrix-scroll"><table><thead><tr><th>${this.t('access.actor')}</th>${entities.map(entity => html `<th title=${entity.entityId}>${entity.title}</th>`)}</tr></thead><tbody>${access.actors.map(actor => html `<tr class=${actor.actorId === this.selectedActorId ? 'is-selected' : ''}><th><button type="button" @click=${() => this.selectActor(actor.actorId)}><strong>${actor.title}</strong><code>${actor.actorId}</code></button></th>${entities.map(entity => {
            const grant = bestAccessGrant(access.grants, actor.actorId, entity.entityId);
            const accessLabel = grant
                ? `${this.t(`access.scope.${grant.dataScope.mode}`)} · ${this.t(`access.disclosure.${grant.disclosure.mode}`)}`
                : this.t('access.none');
            return html `<td><button type="button" class=${grant ? `has-grant scope-${grant.dataScope.mode}` : 'is-empty'} title=${grant ? `${grant.title} · ${accessLabel}` : this.t('access.matrixCreate')} aria-label=${this.t('access.matrixCell', { actor: actor.title, entity: entity.title, access: accessLabel })} @click=${() => this.clickMatrix(actor, entity.entityId, grant)}>${grant ? html `<span>${this.t(`access.scope.${grant.dataScope.mode}`)}</span><i title=${this.t(`access.disclosure.${grant.disclosure.mode}`)}>${this.disclosureIcon(grant.disclosure.mode)}</i>` : html `<span aria-hidden="true">+</span><small>${this.t('access.none')}</small>`}</button></td>`;
        })}</tr>`)}</tbody></table></div></section>`;
    }
    renderActor(access, actor) {
        const grants = accessGrantsForActor(access, actor.actorId);
        const journeyCount = accessJourneyCount(this.journeys(), actor.actorId);
        return html `<aside class="nr-access__actor"><header><span>${this.t('access.selectedActor')}</span><code>${actor.actorId}</code></header><div class="nr-access__actor-title">${this.mode === 'edit' ? html `<input .value=${actor.title} @input=${(event) => this.updateActor({ title: event.currentTarget.value })}>` : html `<h2>${actor.title}</h2>`}<span class=${`kind-${actor.kind}`}>${this.t(`access.kind.${actor.kind}`)}</span></div>${this.mode === 'edit' ? html `<label><span>${this.t('access.kind')}</span><select .value=${actor.kind} @change=${(event) => this.updateActor({ kind: event.currentTarget.value })}>${ACTOR_KINDS.map(kind => html `<option value=${kind} ?selected=${actor.kind === kind}>${this.t(`access.kind.${kind}`)}</option>`)}</select></label><label><span>${this.t('access.actorDescription')}</span><textarea .value=${actor.description} @input=${(event) => this.updateActor({ description: event.currentTarget.value })}></textarea></label>` : html `<p>${actor.description}</p>`}<dl><div><dt>${this.t('access.origin')}</dt><dd>${this.t(`access.origin.${actor.origin}`)}</dd></div><div><dt>${this.t('access.journeys')}</dt><dd>${journeyCount}</dd></div><div><dt>${this.t('access.grants')}</dt><dd>${grants.length}</dd></div></dl><section class="nr-access__grant-list"><header><strong>${this.t('access.actorGrants')}</strong><button type="button" @click=${() => this.addGrant()}>+ ${this.t('access.addGrant')}</button></header>${grants.length ? grants.map(grant => html `<button type="button" class=${grant.grantId === this.selectedGrantId ? 'is-active' : ''} @click=${() => this.selectGrant(grant.grantId)}><span><strong>${grant.title}</strong><code>${grant.grantId}</code></span><i>${this.t(`access.scope.${grant.dataScope.mode}`)}</i></button>`) : html `<p class="nr-access__no-grants">${this.t('access.noGrants')}</p>`}</section></aside>`;
    }
    renderGrantView(grant) {
        const paths = accessAnchorPaths(grant, this.index());
        const allowed = grant.disclosure.allowedFields || [];
        const denied = grant.disclosure.deniedFields || [];
        const fieldChip = (ref) => html `<span class="nr-access__field-chip"><strong>${accessFieldLabel(ref, this.entities())}</strong><code>${ref}</code></span>`;
        return html `<article class="nr-access__grant-detail"><header><div><span>${this.t('access.selectedGrant')}</span><h2>${grant.title}</h2><code>${grant.grantId}</code></div><button class="nr-button" type="button" @click=${() => this.beginEdit()}>${this.t('access.edit')}</button></header><p class="nr-access__lead">${grant.description}</p><div class="nr-access__entities"><strong>${this.t('access.entities')}</strong>${grant.entityRefs.map(entityId => html `<button type="button" @click=${() => this.dispatchEvent(new CustomEvent('nr-navigate', { bubbles: true, composed: true, detail: { tab: 'ontology', entityId } }))}>${this.entityTitle(entityId)}</button>`)}</div><div class="nr-access__boundary"><section><span>${this.t('access.scope')}</span><h3>${this.t(`access.scope.${grant.dataScope.mode}`)}</h3><p>${grant.dataScope.description}</p>${grant.dataScope.anchorEntity ? html `<div class="nr-access__anchor"><strong>${this.t('access.anchor')}</strong><code>${grant.dataScope.anchorEntity}</code>${paths.map(path => html `<p><span>${path.entities.join(' → ')}</span><small>${path.relationships.length ? path.relationships.join(' · ') : this.t('access.sameEntity')}</small></p>`)}</div>` : nothing}</section><section><span>${this.t('access.disclosure')}</span><h3>${this.t(`access.disclosure.${grant.disclosure.mode}`)}</h3><p>${grant.disclosure.description}</p>${allowed.length || denied.length ? html `<div class="nr-access__field-groups">${allowed.length ? html `<div><strong>${this.t('access.allowedFields')}</strong>${allowed.map(fieldChip)}</div>` : nothing}${denied.length ? html `<div class="is-denied"><strong>${this.t('access.deniedFields')}</strong>${denied.map(fieldChip)}</div>` : nothing}</div>` : nothing}</section></div></article>`;
    }
    renderGrantEdit(grant) {
        const anchors = reachablePersonAnchors(grant.entityRefs, this.entities(), this.index());
        const fields = accessFieldRefs(grant, this.entities());
        const fieldOption = (ref) => `${accessFieldLabel(ref, this.entities())} — ${ref}`;
        return html `<article class="nr-access__grant-detail is-editing"><header><div><span>${this.t('access.editing')}</span><input class="nr-access__title-input" .value=${grant.title} @input=${(event) => this.updateGrant({ title: event.currentTarget.value })}><code>${grant.grantId}</code></div><button class="nr-button is-danger" type="button" @click=${() => this.removeGrant()}>${this.t('access.removeGrant')}</button></header><label class="is-wide"><span>${this.t('access.grantDescription')}</span><textarea .value=${grant.description} @input=${(event) => this.updateGrant({ description: event.currentTarget.value })}></textarea></label><div class="nr-access__edit-grid"><label><span>${this.t('access.entities')}</span><select multiple @change=${(event) => this.updateEntities(this.multiValues(event))}>${this.entities().map(entity => html `<option value=${entity.entityId} ?selected=${grant.entityRefs.includes(entity.entityId)}>${entity.title}</option>`)}</select></label><label><span>${this.t('access.scope')}</span><select .value=${grant.dataScope.mode} @change=${(event) => this.updateScope({ mode: event.currentTarget.value })}>${SCOPE_MODES.map(mode => html `<option value=${mode} ?selected=${grant.dataScope.mode === mode} ?disabled=${this.actor()?.kind === 'external' && mode !== 'own'}>${this.t(`access.scope.${mode}`)}</option>`)}</select></label>${PERSON_SCOPE_MODES.includes(grant.dataScope.mode) ? html `<label><span>${this.t('access.anchor')}</span><select .value=${grant.dataScope.anchorEntity || ''} @change=${(event) => this.updateScope({ anchorEntity: event.currentTarget.value || undefined })}><option value="" ?selected=${!grant.dataScope.anchorEntity}>${this.t('access.chooseAnchor')}</option>${anchors.map(anchor => html `<option value=${anchor.entityId} ?selected=${grant.dataScope.anchorEntity === anchor.entityId}>${anchor.title}</option>`)}</select><small>${anchors.length ? this.t('access.anchorReachable') : this.t('access.anchorUnavailable')}</small></label>` : nothing}<label class="is-wide"><span>${this.t('access.scopeDescription')}</span><textarea .value=${grant.dataScope.description} @input=${(event) => this.updateScope({ description: event.currentTarget.value })}></textarea></label><label><span>${this.t('access.disclosure')}</span><select .value=${grant.disclosure.mode} @change=${(event) => this.updateDisclosure({ mode: event.currentTarget.value })}>${DISCLOSURE_MODES.map(mode => html `<option value=${mode} ?selected=${grant.disclosure.mode === mode}>${this.t(`access.disclosure.${mode}`)}</option>`)}</select></label><label class="is-wide"><span>${this.t('access.disclosureDescription')}</span><textarea .value=${grant.disclosure.description} @input=${(event) => this.updateDisclosure({ description: event.currentTarget.value })}></textarea></label>${LIMITED_DISCLOSURE_MODES.includes(grant.disclosure.mode) ? html `<label><span>${this.t('access.allowedFields')}</span><select multiple @change=${(event) => this.updateDisclosure({ allowedFields: this.multiValues(event) })}>${fields.map(ref => html `<option value=${ref} ?selected=${grant.disclosure.allowedFields?.includes(ref)}>${fieldOption(ref)}</option>`)}</select></label><label><span>${this.t('access.deniedFields')}</span><select multiple @change=${(event) => this.updateDisclosure({ deniedFields: this.multiValues(event) })}>${fields.map(ref => html `<option value=${ref} ?selected=${grant.disclosure.deniedFields?.includes(ref)}>${fieldOption(ref)}</option>`)}</select></label>` : nothing}</div></article>`;
    }
    issues() {
        const source = [...(this.data?.validation.issues || []), ...this.suppliedIssues];
        const mapped = accessOracleIssues(source).map(issue => ({ severity: issue.severity, code: issue.code, message: issue.message }));
        return [...new Map([...mapped, ...this.gateIssues].map(issue => [`${issue.code}:${issue.message}`, issue])).values()];
    }
    renderIssues() {
        const issues = this.issues();
        if (!issues.length && !this.editMessage)
            return nothing;
        return html `<section class="nr-access__issues" role="alert"><header><strong>${this.t('access.issues')}</strong><span>${this.t('access.issueCount', { count: issues.length })}</span></header>${this.editMessage ? html `<p>${this.editMessage}</p>` : nothing}<div>${issues.map(issue => html `<article class=${`is-${issue.severity}`}><code>${issue.code}</code><p>${issue.message}</p></article>`)}</div></section>`;
    }
    render() {
        const access = this.currentAccess();
        const actor = this.actor();
        if (!access || !actor)
            return html `<section class="nr-access__empty"><h2>${this.t('access.emptyTitle')}</h2><p>${this.t('access.emptyBody')}</p></section>`;
        const grant = this.grant();
        return html `<section class="nr-access"><header class="nr-access__hero"><div><span>${this.t('access.eyebrow')}</span><h2>${this.t('access.title')}</h2><p>${this.t('access.description')}</p></div><dl><div><dt>${this.t('access.actors')}</dt><dd>${access.actors.length}</dd></div><div><dt>${this.t('access.grants')}</dt><dd>${access.grants.length}</dd></div><div><dt>${this.t('access.entities')}</dt><dd>${this.entities().length}</dd></div></dl></header>${this.renderMatrix(access)}${this.renderIssues()}<div class="nr-access__workspace">${this.renderActor(access, actor)}${grant ? (this.mode === 'edit' ? this.renderGrantEdit(grant) : this.renderGrantView(grant)) : html `<section class="nr-access__grant-empty"><span aria-hidden="true">+</span><h2>${this.t('access.noGrantTitle')}</h2><p>${this.t('access.noGrantBody')}</p><button type="button" @click=${() => this.addGrant()}>${this.t('access.addGrant')}</button></section>`}</div>${this.mode === 'edit' ? html `<footer class="nr-access__edit-footer"><span>${this.dirty ? this.t('access.unsaved') : this.t('access.noChanges')}</span><div><button type="button" @click=${() => this.cancelEdit()}>${this.t('access.cancel')}</button><button class="is-primary" type="button" ?disabled=${!this.dirty} @click=${() => void this.saveEdit()}>${this.t('access.save')}</button></div></footer>` : nothing}</section>`;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseAccess102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseAccess102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseAccess102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseAccess102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseAccess102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseAccess102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseAccess102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "selectedActorId", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "selectedGrantId", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "accessDraft", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "suppliedIssues", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "gateIssues", void 0);
__decorate([
    state()
], NewReleaseAccess102035.prototype, "editMessage", void 0);
NewReleaseAccess102035 = __decorate([
    customElement('new-release--widgets--access-102035')
], NewReleaseAccess102035);
export { NewReleaseAccess102035 };
