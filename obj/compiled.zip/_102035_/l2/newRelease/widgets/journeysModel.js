/// <mls fileReference="_102035_/l2/newRelease/widgets/journeysModel.ts" enhancement="_blank" />
export const JOURNEY_ENTRY_MODES = [
    'coldStart', 'contextOrLookup', 'fromNotification',
];
export const JOURNEY_STEP_KINDS = [
    'locate', 'inspect', 'act', 'decide', 'handoff',
];
export function orderedJourneys(index, journeys) {
    if (!index)
        return [...journeys];
    const byId = new Map(journeys.map(journey => [journey.journeyId, journey]));
    return index.journeys.map(item => byId.get(item.journeyId)).filter((item) => !!item);
}
export function syncJourneyIndex(index, journey) {
    return {
        ...index,
        journeys: index.journeys.map(item => item.journeyId === journey.journeyId
            ? { journeyId: item.journeyId, actorRef: journey.business.actorRef, title: journey.business.title }
            : item),
    };
}
export function moveJourney(index, journeyId, targetJourneyId) {
    if (journeyId === targetJourneyId)
        return index;
    const journeys = [...index.journeys];
    const from = journeys.findIndex(item => item.journeyId === journeyId);
    const to = journeys.findIndex(item => item.journeyId === targetJourneyId);
    if (from < 0 || to < 0)
        return index;
    const [moved] = journeys.splice(from, 1);
    journeys.splice(to, 0, moved);
    return { ...index, journeys };
}
export function moveJourneyStep(journey, stepId, targetStepId) {
    if (stepId === targetStepId)
        return journey;
    const steps = [...journey.business.steps];
    const from = steps.findIndex(item => item.stepId === stepId);
    const to = steps.findIndex(item => item.stepId === targetStepId);
    if (from < 0 || to < 0)
        return journey;
    const [moved] = steps.splice(from, 1);
    steps.splice(to, 0, moved);
    return { ...journey, business: { ...journey.business, steps } };
}
export function nextJourneyStepId(journey) {
    const ids = new Set(journey.business.steps.map(step => step.stepId));
    let position = journey.business.steps.length + 1;
    while (ids.has(`step${position}`))
        position += 1;
    return `step${position}`;
}
export function journeyTransitions(entities, entityId, actorRef) {
    const entity = entities.find(item => item.entityId === entityId);
    return (entity?.transitions || []).map(transition => ({
        entityId,
        transitionId: transition.transitionId,
        from: transition.from,
        to: transition.to,
        description: transition.description,
        eligible: Array.isArray(transition.by) && transition.by.includes(actorRef),
    }));
}
export function journeyIssues(issues, journeyId) {
    const artifact = `journeys/${journeyId}.defs.ts`;
    return issues.filter(issue => issue.artifact === artifact
        || issue.path.startsWith(`journeys.${journeyId}`)
        || ((issue.code.startsWith('I2') || issue.code.startsWith('I8')) && issue.message.includes(journeyId)));
}
export function journeyPath(journeyId) {
    return `journeys/${journeyId}.defs.ts`;
}
