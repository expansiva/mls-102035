/// <mls fileReference="_102035_/l2/newRelease/widgets/changeEffortModel.ts" enhancement="_blank" />
import { validateChangeEffort } from '/_102035_/l2/solution/gates/changeEffort/gate.js';
export function buildChangeEffortView(read) {
    const empty = { status: '', items: [], merged: null, untouched: null };
    if (read.status === 'missing')
        return { ...empty, kind: 'missing', errorCode: '' };
    const result = read.status === 'ok' ? validateChangeEffort(read.value) : null;
    if (!result?.ok)
        return { ...empty, kind: 'invalid', errorCode: 'review.effort.invalid' };
    const file = result.file;
    return {
        kind: 'ready', errorCode: '', status: file.status,
        items: file.request.items.map(item => ({
            item: { kind: item.kind, op: item.op, entity: item.entity, id: item.changeId },
            answers: file.perItem.filter(row => row.item === item.changeId).flatMap(row => row.answers),
        })),
        merged: file.merged,
        untouched: file.untouched,
    };
}
