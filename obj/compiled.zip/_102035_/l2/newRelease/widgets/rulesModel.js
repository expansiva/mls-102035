/// <mls fileReference="_102035_/l2/newRelease/widgets/rulesModel.ts" enhancement="_blank" />
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
function textMentionsRule(text, ruleId) {
    const escaped = ruleId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`(^|[^A-Za-z0-9])${escaped}([^A-Za-z0-9]|$)`, 'i').test(text);
}
export function collectRuleCitations(rules, entities, journeys) {
    const knownRules = new Set(rules.map(rule => rule.ruleId));
    const citations = [];
    const transitions = new Map();
    for (const entity of entities) {
        for (const transition of entity.transitions) {
            const ruleRefs = (transition.ruleRefs || []).filter(ruleId => knownRules.has(ruleId));
            transitions.set(`${entity.entityId}:${transition.transitionId}`, { entityId: entity.entityId, ruleRefs });
            for (const ruleId of ruleRefs) {
                citations.push({
                    ruleId,
                    kind: 'transition',
                    entityId: entity.entityId,
                    transitionId: transition.transitionId,
                    label: `${entity.entityId}.${transition.transitionId}`,
                });
            }
        }
        for (const [detailName, detail] of Object.entries(entity.details || {})) {
            for (const rule of rules) {
                if (!textMentionsRule(`${detailName} ${detail.description}`, rule.ruleId))
                    continue;
                citations.push({
                    ruleId: rule.ruleId,
                    kind: 'detail',
                    entityId: entity.entityId,
                    detailName,
                    label: `${entity.entityId}.details.${detailName}`,
                });
            }
        }
    }
    for (const journey of journeys) {
        for (const step of journey.business.steps) {
            if (!step.transitionRef)
                continue;
            const transition = transitions.get(`${step.entity}:${step.transitionRef}`);
            if (!transition)
                continue;
            for (const ruleId of transition.ruleRefs) {
                citations.push({
                    ruleId,
                    kind: 'journey',
                    entityId: transition.entityId,
                    journeyId: journey.journeyId,
                    stepId: step.stepId,
                    transitionId: step.transitionRef,
                    label: `${journey.journeyId}.${step.stepId}`,
                });
            }
        }
    }
    return citations;
}
export function citationsForRule(citations, ruleId) {
    return citations.filter(citation => citation.ruleId === ruleId);
}
export function ruleEntityIds(citations, ruleId) {
    return [...new Set(citationsForRule(citations, ruleId).map(citation => citation.entityId))].sort();
}
export function filterRules(rules, citations, query) {
    const normalized = query.trim().toLocaleLowerCase();
    if (!normalized)
        return [...rules];
    return rules.filter(rule => {
        const related = citationsForRule(citations, rule.ruleId).map(citation => `${citation.label} ${citation.entityId}`).join(' ');
        return `${rule.ruleId} ${rule.description} ${related}`.toLocaleLowerCase().includes(normalized);
    });
}
export function groupRulesByEntity(rules, citations) {
    const groups = new Map();
    const orphan = [];
    for (const rule of rules) {
        const entityIds = ruleEntityIds(citations, rule.ruleId);
        if (!entityIds.length) {
            orphan.push(rule);
            continue;
        }
        for (const entityId of entityIds)
            groups.set(entityId, [...(groups.get(entityId) || []), rule]);
    }
    return [
        ...[...groups.entries()].sort(([left], [right]) => left.localeCompare(right)).map(([entityId, groupedRules]) => ({ entityId, rules: groupedRules })),
        ...(orphan.length ? [{ entityId: null, rules: orphan }] : []),
    ];
}
export function isValidNewRuleId(artifact, ruleId) {
    return MEMBER_ID.test(ruleId) && !artifact.rules.some(rule => rule.ruleId === ruleId);
}
export function rulesOracleIssues(issues) {
    return issues.filter(issue => issue.artifact === 'rules.defs.ts'
        || issue.code === 'I4'
        || issue.code === 'NS5_FINALIZE_I4');
}
