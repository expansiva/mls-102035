var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102035_/l2/newRelease/widgets/rules.ts" enhancement="_102027_/l2/enhancementLit" />
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { ns5RuleRecord } from '/_102035_/l2/solution/rulesView.js';
import { hasItemDiff, ruleScopes } from '/_102035_/l2/newRelease/helpers/itemDiffs.js';
import { changedDot } from '/_102035_/l2/newRelease/helpers/changedDot.js';
import { announceNewReleaseChange, canDiscardNewReleaseDraft, requestNewReleaseEdit } from '/_102035_/l2/newRelease/editContract.js';
import { patchRuleText, humanizeRuleKey, ontologyRuleCitations, rulePresentationGroups, ruleEntityIds, citationsForRule, rulesOracleIssues } from '/_102035_/l2/newRelease/widgets/rulesModel.js';
let NewReleaseRules102035 = class NewReleaseRules102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--rules-102035 {
  display: block;
  color: #e2e8f0;
}
new-release--widgets--rules-102035 * {
  box-sizing: border-box;
}
new-release--widgets--rules-102035 button,
new-release--widgets--rules-102035 input,
new-release--widgets--rules-102035 textarea {
  font: inherit;
  color: inherit;
}
new-release--widgets--rules-102035 button {
  cursor: pointer;
  border: 1px solid #334155;
  border-radius: 8px;
  background: #172334;
  padding: 0.65rem;
}
new-release--widgets--rules-102035 button:disabled {
  opacity: 0.5;
  cursor: default;
}
new-release--widgets--rules-102035 button:focus-visible,
new-release--widgets--rules-102035 input:focus-visible,
new-release--widgets--rules-102035 textarea:focus-visible {
  outline: 2px solid #60a5fa;
  outline-offset: 2px;
}
new-release--widgets--rules-102035 .nr-rules {
  padding: 1rem;
}
new-release--widgets--rules-102035 .nr-rules__panels {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 19rem), 1fr));
  gap: 1rem;
  align-items: start;
}
new-release--widgets--rules-102035 .nr-rules__group,
new-release--widgets--rules-102035 .nr-rules__detail {
  border: 1px solid #334155;
  border-radius: 12px;
  background: #101a29;
  overflow: hidden;
}
new-release--widgets--rules-102035 h2 {
  font-size: 1rem;
  margin: 0;
  padding: 1rem;
}
new-release--widgets--rules-102035 .nr-rules__group > div {
  max-height: 30rem;
  overflow-y: auto;
}
new-release--widgets--rules-102035 .nr-rules__group button {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  width: 100%;
  height: 3rem;
  border-width: 1px 0 0;
  border-radius: 0;
  background: transparent;
  text-align: left;
  white-space: normal;
  overflow-wrap: anywhere;
  font-size: 0.85rem;
  line-height: 1.2;
}
new-release--widgets--rules-102035 .nr-rules__name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--rules-102035 .nr-rules__count {
  flex: 0 0 auto;
}
new-release--widgets--rules-102035 .nr-rules__group button:hover {
  background: #203149;
}
new-release--widgets--rules-102035 .nr-rules__detail {
  display: grid;
  gap: 1rem;
  padding: 1rem;
}
new-release--widgets--rules-102035 .nr-rules__detail header,
new-release--widgets--rules-102035 footer {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex-wrap: wrap;
}
new-release--widgets--rules-102035 .nr-rules__detail h2 {
  padding: 0;
  flex: 1;
}
new-release--widgets--rules-102035 label {
  display: grid;
  gap: 0.5rem;
}
new-release--widgets--rules-102035 input,
new-release--widgets--rules-102035 textarea {
  width: 100%;
  border: 1px solid #334155;
  border-radius: 6px;
  background: #0b1220;
  padding: 0.75rem;
}
new-release--widgets--rules-102035 textarea {
  min-height: 10rem;
  resize: vertical;
}
new-release--widgets--rules-102035 p {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
new-release--widgets--rules-102035 footer span {
  flex: 1;
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.selected = '';
        this.draft = null;
        this.saving = false;
        this.message = '';
        this.issues = [];
        this.snapshot = '';
    }
    createRenderRoot() { return this; }
    artifact() { return this.draft || this.data?.artifacts.rules.value || null; }
    entities() { return (this.data?.artifacts.entities || []).flatMap(item => item.value ? [item.value] : []); }
    rules() { const artifact = this.artifact(); return artifact ? Object.entries(ns5RuleRecord(artifact)).map(([ruleId, description]) => ({ ruleId, description })) : []; }
    citations() { return ontologyRuleCitations(this.rules(), this.entities()); }
    groups() { return rulePresentationGroups(this.rules(), this.citations(), this.entities(), this.t('rules.orphanGroup')); }
    getDraft() { return this.artifact() ? structuredClone(this.artifact()) : null; }
    setIssues(issues) { this.issues = rulesOracleIssues(issues); }
    updated(changed) {
        if (changed.has('data') || changed.has('version') || changed.has('moduleName') || changed.has('project'))
            this.reset();
        if (changed.has('data') || changed.has('selected') || changed.has('mode') || changed.has('t') || changed.has('draft'))
            this.present();
    }
    present() {
        const citations = this.citations();
        const presentation = {
            detail: !!this.selected,
            nodes: this.groups().map(group => ({ id: `group:${group.entityId || ''}`, label: `${group.title} (${group.rules.length})`, value: '', children: group.rules.map(rule => ({ id: `rule:${rule.ruleId}`, label: humanizeRuleKey(rule.ruleId), suffix: this.ruleSuffix(rule.ruleId, citations), changed: this.changedRule(rule.ruleId), value: rule.description, children: [] })) })),
            select: id => { if (id.startsWith('rule:'))
                this.select(id.slice(5)); }, back: () => this.back(),
        };
        this.dispatchEvent(new CustomEvent('nr-view-state', { bubbles: true, composed: true, detail: presentation }));
    }
    ruleSuffix(id, citations = this.citations()) { const count = ruleEntityIds(citations, id).length; return count > 1 ? `(${count})` : ''; }
    changedRule(id) { return hasItemDiff(this.data?.diffs || [], 'rules.defs.ts', ruleScopes(id)); }
    select(id) {
        if (this.saving || !canDiscardNewReleaseDraft(this))
            return;
        if (this.version === 'asis') {
            requestNewReleaseEdit(this, `rule:${id}`);
            return;
        }
        this.reset();
        this.selected = id;
        if (!this.version.startsWith('release:'))
            this.edit();
    }
    reset() { this.draft = null; this.snapshot = ''; this.mode = 'view'; this.dirty = false; this.message = ''; this.issues = []; }
    back() { if (this.saving || !canDiscardNewReleaseDraft(this))
        return; this.reset(); this.selected = ''; this.present(); }
    edit() { if (this.version.startsWith('release:'))
        return; this.draft = this.getDraft(); this.snapshot = JSON.stringify(this.draft); this.mode = 'edit'; }
    updateText(text) {
        if (!this.draft)
            return;
        this.draft = patchRuleText(this.draft, this.selected, text);
        this.dirty = JSON.stringify(this.draft) !== this.snapshot;
        this.message = '';
    }
    async save() {
        if (!this.draft || !this.dirty || this.saving || this.version.startsWith('release:'))
            return;
        this.saving = true;
        try {
            await announceNewReleaseChange(this, { path: 'rules.defs.ts', jsonPath: '$', value: structuredClone(this.draft) });
            this.reset();
        }
        catch (error) {
            this.message = this.t('rules.gateUnavailable', { message: error instanceof Error ? error.message : String(error) });
        }
        finally {
            this.saving = false;
        }
    }
    render() {
        const rule = this.rules().find(rule => rule.ruleId === this.selected);
        const citations = this.citations();
        return html `<section class="nr-rules" aria-label=${this.t('rules.title')}>
      ${rule ? html `<article class="nr-rules__detail"><header><h2>${humanizeRuleKey(rule.ruleId)}</h2>${this.mode === 'view' && !this.version.startsWith('release:') ? html `<button type="button" @click=${this.edit}>${this.t('rules.edit')}</button>` : nothing}</header>
        <label>${this.t('rules.key')}<input readonly .value=${rule.ruleId}></label>
        <label>${this.t('rules.businessStatement')}${this.mode === 'edit' ? html `<textarea ?disabled=${this.saving} .value=${rule.description} @input=${(event) => this.updateText(event.currentTarget.value)}></textarea>` : html `<p>${rule.description}</p>`}</label>
        <section><h3>${this.t('rules.usedIn')}</h3>${citationsForRule(citations, rule.ruleId).map(citation => html `<p>${this.entities().find(entity => entity.entityId === citation.entityId)?.title || citation.entityId}${citation.transitionId ? html ` — ${citation.label} <code>(${citation.transitionId})</code>` : nothing}</p>`)}${!citationsForRule(citations, rule.ruleId).length ? html `<p>${this.t('rules.orphanGroup')}</p>` : nothing}</section>
        ${this.mode === 'edit' ? html `<footer><span>${this.t(this.dirty ? 'rules.unsaved' : 'rules.noChanges')}</span><button type="button" ?disabled=${this.saving} @click=${() => { if (canDiscardNewReleaseDraft(this))
            this.reset(); }}>${this.t('rules.cancel')}</button><button class="is-primary" type="button" ?disabled=${!this.dirty || this.saving} @click=${this.save}>${this.t('rules.save')}</button></footer>` : nothing}
      </article>` : html `<div class="nr-rules__panels">${this.groups().map(group => html `<section class="nr-rules__group"><h2>${group.title} (${group.rules.length})</h2><div>${group.rules.map(rule => html `<button type="button" @click=${() => this.select(rule.ruleId)}><span class="nr-rules__name">${humanizeRuleKey(rule.ruleId)}</span>${changedDot(this.changedRule(rule.ruleId), this.t)}<span class="nr-rules__count">${this.ruleSuffix(rule.ruleId, citations)}</span></button>`)}</div></section>`)}</div>`}
      ${this.message || this.issues.length ? html `<div role="alert">${this.message}${this.issues.map(issue => html `<p>${issue.message}</p>`)}</div>` : nothing}
    </section>`;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseRules102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseRules102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseRules102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseRules102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseRules102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseRules102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseRules102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "selected", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "draft", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "saving", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "message", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "issues", void 0);
NewReleaseRules102035 = __decorate([
    customElement('new-release--widgets--rules-102035')
], NewReleaseRules102035);
export { NewReleaseRules102035 };
