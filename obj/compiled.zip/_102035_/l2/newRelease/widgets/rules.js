/// <mls fileReference="_102035_/l2/newRelease/widgets/rules.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { ns5RuleRecord } from '/_102035_/l2/solution/rulesView.js';
import { announceNewReleaseChange, } from '/_102035_/l2/newRelease/editContract.js';
import { citationsForRule, collectRuleCitations, filterRules, groupRulesByEntity, isValidNewRuleId, ruleEntityIds, rulesOracleIssues, } from '/_102035_/l2/newRelease/widgets/rulesModel.js';
let NewReleaseRules102035 = class NewReleaseRules102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--rules-102035 {
  display: block;
}
new-release--widgets--rules-102035 * {
  box-sizing: border-box;
}
new-release--widgets--rules-102035 h2,
new-release--widgets--rules-102035 p,
new-release--widgets--rules-102035 dl,
new-release--widgets--rules-102035 dd {
  margin: 0;
}
new-release--widgets--rules-102035 button,
new-release--widgets--rules-102035 input,
new-release--widgets--rules-102035 textarea {
  font: inherit;
}
new-release--widgets--rules-102035 button {
  cursor: pointer;
}
new-release--widgets--rules-102035 code {
  font-family: var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--rules-102035 input,
new-release--widgets--rules-102035 textarea {
  width: 100%;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--rules-102035 input {
  min-height: 2.25rem;
  padding: 0.42rem 0.58rem;
}
new-release--widgets--rules-102035 textarea {
  min-height: 8rem;
  padding: 0.65rem 0.7rem;
  resize: vertical;
  line-height: 1.55;
}
new-release--widgets--rules-102035 input:focus,
new-release--widgets--rules-102035 textarea:focus,
new-release--widgets--rules-102035 button:focus-visible {
  border-color: var(--focus-border, #1273d4);
  outline: 2px solid color-mix(in srgb, var(--focus-border, #1273d4) 22%, transparent);
  outline-offset: 1px;
}
new-release--widgets--rules-102035 .nr-rules {
  display: grid;
  min-width: 0;
  color: var(--text-default, #2f3a48);
}
new-release--widgets--rules-102035 .nr-rules__hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.2rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: linear-gradient(135deg, var(--surface-bg, #fff), color-mix(in srgb, var(--selected-bg, #e3f1ff) 46%, var(--surface-bg, #fff)));
}
new-release--widgets--rules-102035 .nr-rules__hero > div > span,
new-release--widgets--rules-102035 .nr-rules__detail > header > div > span,
new-release--widgets--rules-102035 .nr-rules__statement strong,
new-release--widgets--rules-102035 .nr-rules__citations > header span {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 800;
  letter-spacing: 0.11em;
  text-transform: uppercase;
}
new-release--widgets--rules-102035 .nr-rules__hero h2 {
  margin-top: 0.28rem;
  color: var(--text-strong, #111827);
  font-size: 1.5rem;
  letter-spacing: -0.03em;
}
new-release--widgets--rules-102035 .nr-rules__hero p {
  max-width: 46rem;
  margin-top: 0.42rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--rules-102035 .nr-rules__hero dl {
  display: flex;
  overflow: hidden;
  border: 1px solid color-mix(in srgb, var(--selected-border, #1273d4) 24%, var(--border-subtle, #e4e9f0));
  border-radius: 0.82rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--rules-102035 .nr-rules__hero dl div {
  display: grid;
  min-width: 5rem;
  place-items: center;
  padding: 0.55rem 0.75rem;
}
new-release--widgets--rules-102035 .nr-rules__hero dl div + div {
  border-left: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--rules-102035 .nr-rules__hero dt {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.54rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--rules-102035 .nr-rules__hero dd {
  order: -1;
  color: var(--text-strong, #111827);
  font-size: 1.2rem;
  font-weight: 800;
  letter-spacing: -0.04em;
}
new-release--widgets--rules-102035 .nr-rules__workspace {
  display: grid;
  grid-template-columns: minmax(16rem, 0.92fr) minmax(0, 2fr);
  gap: 1rem;
  align-items: start;
  padding: 1rem 1.25rem 1.5rem;
}
new-release--widgets--rules-102035 .nr-rules__catalog,
new-release--widgets--rules-102035 .nr-rules__detail,
new-release--widgets--rules-102035 .nr-rules__empty-detail {
  min-width: 0;
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.85rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--rules-102035 .nr-rules__search {
  display: grid;
  gap: 0.25rem;
  padding: 0.7rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--rules-102035 .nr-rules__search span,
new-release--widgets--rules-102035 .nr-rules__catalog form label span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
  font-weight: 750;
}
new-release--widgets--rules-102035 .nr-rules__groups {
  display: grid;
  max-height: 34rem;
  overflow-y: auto;
}
new-release--widgets--rules-102035 .nr-rules__groups > section > header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  padding: 0.45rem 0.65rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
  font-weight: 800;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}
new-release--widgets--rules-102035 .nr-rules__groups > section:first-child > header {
  border-top: 0;
}
new-release--widgets--rules-102035 .nr-rules__groups section > button {
  display: grid;
  width: 100%;
  grid-template-columns: 1.65rem minmax(0, 1fr) auto;
  gap: 0.5rem;
  align-items: center;
  padding: 0.62rem 0.68rem;
  border: 0;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  text-align: left;
}
new-release--widgets--rules-102035 .nr-rules__groups section > button:hover {
  background: color-mix(in srgb, var(--selected-bg, #e3f1ff) 42%, transparent);
}
new-release--widgets--rules-102035 .nr-rules__groups section > button.is-active {
  border-left: 0.2rem solid var(--selected-border, #1273d4);
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--rules-102035 .nr-rules__groups button > i {
  display: grid;
  width: 1.65rem;
  height: 1.65rem;
  place-items: center;
  border-radius: 0.48rem;
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--rules-102035 .nr-rules__groups button > i.is-orphan {
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--rules-102035 .nr-rules__groups svg,
new-release--widgets--rules-102035 .nr-rules__orphan svg {
  width: 1rem;
  height: 1rem;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 1.7;
}
new-release--widgets--rules-102035 .nr-rules__groups button > span {
  display: grid;
  min-width: 0;
  gap: 0.18rem;
}
new-release--widgets--rules-102035 .nr-rules__groups button strong {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font: 700 0.62rem var(--font-family-mono, ui-monospace, monospace);
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--rules-102035 .nr-rules__groups button small {
  display: -webkit-box;
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
  line-height: 1.35;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}
new-release--widgets--rules-102035 .nr-rules__groups button b {
  display: grid;
  min-width: 1.45rem;
  height: 1.45rem;
  place-items: center;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
}
new-release--widgets--rules-102035 .nr-rules__catalog > form {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 0.5rem;
  align-items: end;
  padding: 0.7rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--rules-102035 .nr-rules__catalog > form label {
  display: grid;
  gap: 0.25rem;
}
new-release--widgets--rules-102035 .nr-rules__catalog > form button {
  min-height: 2.25rem;
  padding: 0.42rem 0.65rem;
  border: 0;
  border-radius: 0.55rem;
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
  font-size: 0.65rem;
  font-weight: 750;
}
new-release--widgets--rules-102035 .nr-rules__no-results {
  padding: 1.2rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
  text-align: center;
}
new-release--widgets--rules-102035 .nr-rules__detail {
  display: grid;
  gap: 0.85rem;
  padding: 0.9rem;
}
new-release--widgets--rules-102035 .nr-rules__detail > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1rem;
}
new-release--widgets--rules-102035 .nr-rules__detail > header h2 {
  max-width: 100%;
  margin-top: 0.25rem;
  overflow-wrap: anywhere;
  color: var(--text-strong, #111827);
  font: 750 1.08rem var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--rules-102035 .nr-rules__detail > header > div > div {
  display: flex;
  flex-wrap: wrap;
  gap: 0.3rem;
  margin-top: 0.45rem;
}
new-release--widgets--rules-102035 .nr-rules__detail > header > div > div button,
new-release--widgets--rules-102035 .nr-rules__detail > header small {
  padding: 0.2rem 0.42rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--link-text, #0f62b8);
  font-size: 0.55rem;
}
new-release--widgets--rules-102035 .nr-button {
  min-height: 2.2rem;
  flex: 0 0 auto;
  padding: 0.4rem 0.72rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--rules-102035 .nr-rules__editing {
  flex: 0 0 auto;
  padding: 0.35rem 0.58rem;
  border-radius: 999px;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.61rem;
  font-weight: 750;
}
new-release--widgets--rules-102035 .nr-rules__statement {
  display: grid;
  grid-template-columns: 2.35rem minmax(0, 1fr);
  gap: 0.7rem;
  padding: 0.8rem;
  border: 1px solid color-mix(in srgb, var(--selected-border, #1273d4) 28%, var(--border-subtle, #e4e9f0));
  border-radius: 0.75rem;
  background: linear-gradient(135deg, var(--selected-bg, #e3f1ff), var(--surface-bg, #fff));
}
new-release--widgets--rules-102035 .nr-rules__statement > span {
  display: grid;
  width: 2.35rem;
  height: 2.35rem;
  place-items: center;
  border-radius: 0.65rem;
  background: var(--selected-text, #0d5296);
  color: var(--selected-bg, #e3f1ff);
  font: 800 1.2rem Georgia, serif;
}
new-release--widgets--rules-102035 .nr-rules__statement > div {
  display: grid;
  min-width: 0;
  gap: 0.35rem;
}
new-release--widgets--rules-102035 .nr-rules__statement p {
  color: var(--text-strong, #111827);
  font-size: 0.82rem;
  line-height: 1.62;
}
new-release--widgets--rules-102035 .nr-rules__citations {
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.75rem;
}
new-release--widgets--rules-102035 .nr-rules__citations > header {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.65rem 0.75rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--rules-102035 .nr-rules__citations > header p {
  margin-top: 0.18rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
}
new-release--widgets--rules-102035 .nr-rules__citations > header > strong {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
}
new-release--widgets--rules-102035 .nr-rules__citations > div:not(.nr-rules__orphan) {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.5rem;
  padding: 0.65rem;
}
new-release--widgets--rules-102035 .nr-rules__citations > div > button {
  display: grid;
  grid-template-columns: 1.75rem minmax(0, 1fr);
  gap: 0.5rem;
  align-items: center;
  padding: 0.55rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.62rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  text-align: left;
}
new-release--widgets--rules-102035 .nr-rules__citations > div > button:hover {
  border-color: var(--selected-border, #1273d4);
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--rules-102035 .nr-rules__citations button > i {
  display: grid;
  width: 1.75rem;
  height: 1.75rem;
  place-items: center;
  border-radius: 0.5rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-style: normal;
  font-weight: 800;
}
new-release--widgets--rules-102035 .nr-rules__citations button > span {
  display: grid;
  min-width: 0;
  gap: 0.08rem;
}
new-release--widgets--rules-102035 .nr-rules__citations button strong {
  color: var(--link-text, #0f62b8);
  font-size: 0.52rem;
  letter-spacing: 0.05em;
  text-transform: uppercase;
}
new-release--widgets--rules-102035 .nr-rules__citations button b {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.65rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--rules-102035 .nr-rules__citations button code {
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.53rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--rules-102035 .nr-rules__orphan {
  display: grid;
  grid-template-columns: 2rem 1fr;
  gap: 0.65rem;
  align-items: center;
  padding: 0.8rem;
}
new-release--widgets--rules-102035 .nr-rules__orphan > i {
  display: grid;
  width: 2rem;
  height: 2rem;
  place-items: center;
  border-radius: 0.58rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--rules-102035 .nr-rules__orphan strong {
  color: var(--text-strong, #111827);
  font-size: 0.68rem;
}
new-release--widgets--rules-102035 .nr-rules__orphan p {
  margin-top: 0.18rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.63rem;
  line-height: 1.45;
}
new-release--widgets--rules-102035 .nr-rules__remove {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.7rem 0.75rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.68rem;
}
new-release--widgets--rules-102035 .nr-rules__remove strong {
  color: var(--text-strong, #111827);
  font-size: 0.66rem;
}
new-release--widgets--rules-102035 .nr-rules__remove p {
  margin-top: 0.16rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
}
new-release--widgets--rules-102035 .nr-rules__remove button {
  min-height: 2rem;
  flex: 0 0 auto;
  padding: 0.38rem 0.62rem;
  border: 1px solid color-mix(in srgb, var(--status-error-text, #ab2328) 28%, var(--border-default, #cfd8e3));
  border-radius: 0.52rem;
  background: var(--surface-bg, #fff);
  color: var(--status-error-text, #ab2328);
  font-size: 0.63rem;
  font-weight: 750;
}
new-release--widgets--rules-102035 .nr-rules__remove button:disabled {
  cursor: not-allowed;
  opacity: 0.45;
}
new-release--widgets--rules-102035 .nr-rules__issues {
  display: grid;
  gap: 0.4rem;
  padding: 0.68rem 0.75rem;
  border: 1px solid color-mix(in srgb, var(--status-warning-text, #7a4b00) 28%, var(--border-subtle, #e4e9f0));
  border-radius: 0.68rem;
  background: var(--status-warning-bg, #fff1c2);
}
new-release--widgets--rules-102035 .nr-rules__issues > strong,
new-release--widgets--rules-102035 .nr-rules__issues > p {
  font-size: 0.66rem;
}
new-release--widgets--rules-102035 .nr-rules__issues > div {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 0.45rem;
  align-items: start;
}
new-release--widgets--rules-102035 .nr-rules__issues code {
  padding: 0.1rem 0.28rem;
  border-radius: 0.28rem;
  background: var(--surface-bg, #fff);
  font-size: 0.54rem;
  font-weight: 700;
}
new-release--widgets--rules-102035 .nr-rules__issues p {
  font-size: 0.63rem;
  line-height: 1.4;
}
new-release--widgets--rules-102035 .nr-rules__issues .is-error {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--rules-102035 .nr-rules__empty-detail {
  display: grid;
  min-height: 18rem;
  place-items: center;
  align-content: center;
  gap: 0.4rem;
  padding: 2rem;
  text-align: center;
}
new-release--widgets--rules-102035 .nr-rules__empty-detail h2 {
  color: var(--text-strong, #111827);
  font-size: 1rem;
}
new-release--widgets--rules-102035 .nr-rules__empty-detail p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--rules-102035 .nr-rules__edit-footer {
  position: sticky;
  z-index: 5;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.72rem 1.25rem;
  border-top: 1px solid var(--border-default, #cfd8e3);
  background: color-mix(in srgb, var(--surface-bg, #fff) 94%, transparent);
  box-shadow: 0 -0.5rem 1.4rem color-mix(in srgb, var(--text-strong, #111827) 8%, transparent);
  backdrop-filter: blur(10px);
}
new-release--widgets--rules-102035 .nr-rules__edit-footer > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--rules-102035 .nr-rules__edit-footer > div {
  display: flex;
  gap: 0.5rem;
}
new-release--widgets--rules-102035 .nr-rules__edit-footer button {
  min-height: 2.15rem;
  padding: 0.42rem 0.72rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.7rem;
  font-weight: 750;
}
new-release--widgets--rules-102035 .nr-rules__edit-footer button.is-primary {
  border-color: var(--action-primary-bg, #126fc2);
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
}
new-release--widgets--rules-102035 .nr-rules__edit-footer button:disabled {
  cursor: not-allowed;
  opacity: 0.48;
}
new-release--widgets--rules-102035 .nr-rules__empty {
  padding: 3rem 1.25rem;
  text-align: center;
}
new-release--widgets--rules-102035 .nr-rules__empty h2 {
  color: var(--text-strong, #111827);
}
new-release--widgets--rules-102035 .nr-rules__empty p {
  margin-top: 0.4rem;
  color: var(--text-muted, #5d6b7e);
}
@media (max-width: 1180px) {
  new-release--widgets--rules-102035 .nr-rules__workspace {
    grid-template-columns: 1fr;
  }
  new-release--widgets--rules-102035 .nr-rules__groups {
    max-height: 22rem;
  }
}
@media (max-width: 720px) {
  new-release--widgets--rules-102035 .nr-rules__hero,
  new-release--widgets--rules-102035 .nr-rules__detail > header,
  new-release--widgets--rules-102035 .nr-rules__citations > header,
  new-release--widgets--rules-102035 .nr-rules__remove,
  new-release--widgets--rules-102035 .nr-rules__edit-footer {
    align-items: stretch;
    flex-direction: column;
  }
  new-release--widgets--rules-102035 .nr-rules__hero dl {
    align-self: flex-start;
  }
  new-release--widgets--rules-102035 .nr-rules__catalog > form,
  new-release--widgets--rules-102035 .nr-rules__citations > div:not(.nr-rules__orphan) {
    grid-template-columns: 1fr;
  }
  new-release--widgets--rules-102035 .nr-rules__edit-footer > div {
    justify-content: flex-end;
  }
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.selectedRuleId = '';
        this.query = '';
        this.rulesDraft = null;
        this.newRuleId = '';
        this.suppliedIssues = [];
        this.gateIssues = [];
        this.editMessage = '';
    }
    createRenderRoot() { return this; }
    updated(changed) {
        if (!changed.has('data') || this.mode === 'edit')
            return;
        const rules = this.currentRules()?.rules || [];
        if (!rules.some(rule => rule.ruleId === this.selectedRuleId))
            this.selectedRuleId = rules[0]?.ruleId || '';
    }
    getDraft() {
        const rules = this.currentRules();
        return rules ? structuredClone(rules) : null;
    }
    setIssues(issues) {
        this.suppliedIssues = rulesOracleIssues(issues);
    }
    currentRules() {
        return this.mode === 'edit' && this.rulesDraft
            ? this.rulesDraft
            : this.data?.artifacts.rules.value || null;
    }
    entities() {
        return this.data?.artifacts.entities.map(item => item.value)
            .filter((item) => !!item) || [];
    }
    journeys() {
        return this.data?.artifacts.journeys.map(item => item.value)
            .filter((item) => !!item) || [];
    }
    citations() {
        return collectRuleCitations(this.currentRules()?.rules || [], this.entities(), this.journeys());
    }
    rule() {
        return this.currentRules()?.rules.find(rule => rule.ruleId === this.selectedRuleId) || null;
    }
    entityTitle(entityId) {
        return this.entities().find(entity => entity.entityId === entityId)?.title || entityId;
    }
    journeyTitle(journeyId) {
        return this.journeys().find(journey => journey.journeyId === journeyId)?.business.title || journeyId;
    }
    beginEdit() {
        const artifact = this.currentRules();
        if (!artifact)
            return;
        this.rulesDraft = structuredClone(artifact);
        this.mode = 'edit';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    cancelEdit() {
        this.rulesDraft = null;
        this.mode = 'view';
        this.dirty = false;
        this.newRuleId = '';
        this.gateIssues = [];
        this.editMessage = '';
        const rules = this.currentRules()?.rules || [];
        if (!rules.some(rule => rule.ruleId === this.selectedRuleId))
            this.selectedRuleId = rules[0]?.ruleId || '';
    }
    updateRules(next) {
        this.rulesDraft = next;
        this.dirty = true;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateDescription(description) {
        if (!this.rulesDraft)
            return;
        this.updateRules({
            ...this.rulesDraft,
            rules: this.rulesDraft.rules.map(rule => rule.ruleId === this.selectedRuleId ? { ...rule, description } : rule),
        });
    }
    addRule() {
        const current = this.currentRules();
        const ruleId = this.newRuleId.trim();
        if (!current || !isValidNewRuleId(current, ruleId)) {
            this.editMessage = this.t('rules.newIdInvalid');
            return;
        }
        if (this.mode !== 'edit')
            this.beginEdit();
        const draft = this.rulesDraft;
        const rule = { ruleId, description: this.t('rules.newDescription') };
        this.query = '';
        this.newRuleId = '';
        this.selectedRuleId = ruleId;
        this.updateRules({ ...draft, rules: [...draft.rules, rule] });
    }
    removeRule() {
        if (!this.rulesDraft || citationsForRule(this.citations(), this.selectedRuleId).length)
            return;
        const rules = this.rulesDraft.rules.filter(rule => rule.ruleId !== this.selectedRuleId);
        this.selectedRuleId = rules[0]?.ruleId || '';
        this.updateRules({ ...this.rulesDraft, rules });
    }
    navigate(citation) {
        const detail = citation.kind === 'journey'
            ? { tab: 'journeys', journeyId: citation.journeyId }
            : { tab: 'ontology', entityId: citation.entityId };
        this.dispatchEvent(new CustomEvent('nr-navigate', { bubbles: true, composed: true, detail }));
    }
    async saveEdit() {
        if (!this.rulesDraft || !this.dirty)
            return;
        try {
            const gate = await import('/_102035_/l2/agentNewSolution5/steps/rules40/gate.js');
            const result = gate.validateNs5Rules(ns5RuleRecord(this.rulesDraft), { moduleName: this.moduleName });
            this.gateIssues = result.issues.map(issue => ({ severity: issue.severity, code: issue.code, message: issue.message }));
            if (!result.ok) {
                this.editMessage = this.t('rules.gateBlocked');
                return;
            }
            announceNewReleaseChange(this, { path: 'rules.defs.ts', jsonPath: '$', value: structuredClone(this.rulesDraft) });
            this.cancelEdit();
        }
        catch (error) {
            this.editMessage = this.t('rules.gateUnavailable', { message: error instanceof Error ? error.message : String(error) });
        }
    }
    ruleIcon(orphan) {
        return orphan
            ? svg `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 3.5 19h17Z"/><path d="M12 9v4m0 3h.01"/></svg>`
            : svg `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="m8 12 2.2 2.2L16 8.5"/></svg>`;
    }
    renderRuleList(artifact, citations) {
        const filtered = filterRules(artifact.rules, citations, this.query);
        const groups = groupRulesByEntity(filtered, citations);
        return html `<aside class="nr-rules__catalog"><label class="nr-rules__search"><span>${this.t('rules.search')}</span><input type="search" .value=${this.query} placeholder=${this.t('rules.searchPlaceholder')} @input=${(event) => { this.query = event.currentTarget.value; }}></label><div class="nr-rules__groups">${groups.map(group => html `<section><header><span>${group.entityId ? this.entityTitle(group.entityId) : this.t('rules.orphanGroup')}</span><small>${group.rules.length}</small></header>${group.rules.map(rule => {
            const count = citationsForRule(citations, rule.ruleId).length;
            return html `<button type="button" class=${rule.ruleId === this.selectedRuleId ? 'is-active' : ''} @click=${() => { this.selectedRuleId = rule.ruleId; }}><i class=${count ? '' : 'is-orphan'}>${this.ruleIcon(!count)}</i><span><strong>${rule.ruleId}</strong><small>${rule.description}</small></span><b title=${this.t('rules.citationCount', { count })}>${count}</b></button>`;
        })}</section>`)}</div>${!filtered.length ? html `<p class="nr-rules__no-results">${this.t('rules.noResults')}</p>` : nothing}<form @submit=${(event) => { event.preventDefault(); this.addRule(); }}><label><span>${this.t('rules.newRuleId')}</span><input .value=${this.newRuleId} placeholder=${this.t('rules.newRulePlaceholder')} @input=${(event) => { this.newRuleId = event.currentTarget.value; this.editMessage = ''; }}></label><button type="submit">+ ${this.t('rules.addRule')}</button></form></aside>`;
    }
    renderCitation(citation) {
        const title = citation.kind === 'journey' && citation.journeyId
            ? this.journeyTitle(citation.journeyId)
            : this.entityTitle(citation.entityId);
        return html `<button type="button" class=${`kind-${citation.kind}`} @click=${() => this.navigate(citation)}><i>${citation.kind === 'transition' ? '↗' : citation.kind === 'journey' ? '→' : 'ƒ'}</i><span><strong>${this.t(`rules.citation.${citation.kind}`)}</strong><b>${title}</b><code>${citation.label}</code></span></button>`;
    }
    renderIssues() {
        const source = [...(this.data?.validation.issues || []), ...this.suppliedIssues];
        const oracle = rulesOracleIssues(source).map(issue => ({ severity: issue.severity, code: issue.code, message: issue.message }));
        const issues = [...new Map([...oracle, ...this.gateIssues].map(issue => [`${issue.code}:${issue.message}`, issue])).values()];
        if (!issues.length && !this.editMessage)
            return nothing;
        return html `<section class="nr-rules__issues" role="alert"><strong>${this.t('rules.issues')}</strong>${this.editMessage ? html `<p>${this.editMessage}</p>` : nothing}${issues.map(issue => html `<div class=${`is-${issue.severity}`}><code>${issue.code}</code><p>${issue.message}</p></div>`)}</section>`;
    }
    renderDetail(rule, citations) {
        const ruleCitations = citationsForRule(citations, rule.ruleId);
        const entities = ruleEntityIds(citations, rule.ruleId);
        const removable = !ruleCitations.length;
        return html `<main class="nr-rules__detail"><header><div><span>${this.t('rules.selected')}</span><h2>${rule.ruleId}</h2>${entities.length ? html `<div>${entities.map(entityId => html `<button type="button" @click=${() => this.navigate({ ruleId: rule.ruleId, kind: 'transition', entityId, label: entityId })}>${this.entityTitle(entityId)}</button>`)}</div>` : html `<small>${this.t('rules.orphan')}</small>`}</div>${this.mode === 'view' ? html `<button class="nr-button" type="button" @click=${() => this.beginEdit()}>${this.t('rules.edit')}</button>` : html `<span class="nr-rules__editing">${this.t('rules.editing')}</span>`}</header><section class="nr-rules__statement"><span aria-hidden="true">§</span><div><strong>${this.t('rules.businessStatement')}</strong>${this.mode === 'edit' ? html `<textarea .value=${rule.description} @input=${(event) => this.updateDescription(event.currentTarget.value)}></textarea>` : html `<p>${rule.description}</p>`}</div></section>${this.renderIssues()}<section class="nr-rules__citations"><header><div><span>${this.t('rules.citedBy')}</span><p>${this.t('rules.citedByDescription')}</p></div><strong>${this.t('rules.citationCount', { count: ruleCitations.length })}</strong></header>${ruleCitations.length ? html `<div>${ruleCitations.map(citation => this.renderCitation(citation))}</div>` : html `<div class="nr-rules__orphan"><i>${this.ruleIcon(true)}</i><div><strong>${this.t('rules.orphanTitle')}</strong><p>${this.t('rules.orphanDescription')}</p></div></div>`}</section>${this.mode === 'edit' ? html `<section class="nr-rules__remove"><div><strong>${removable ? this.t('rules.removeAvailable') : this.t('rules.removeBlocked')}</strong><p>${removable ? this.t('rules.removeAvailableDescription') : this.t('rules.removeBlockedDescription')}</p></div><button type="button" ?disabled=${!removable} @click=${() => this.removeRule()}>${this.t('rules.remove')}</button></section>` : nothing}</main>`;
    }
    render() {
        const artifact = this.currentRules();
        if (!artifact)
            return html `<section class="nr-rules__empty"><h2>${this.t('rules.emptyTitle')}</h2><p>${this.t('rules.emptyBody')}</p></section>`;
        const citations = this.citations();
        const orphanCount = artifact.rules.filter(rule => !citationsForRule(citations, rule.ruleId).length).length;
        const rule = this.rule();
        return html `<section class="nr-rules"><header class="nr-rules__hero"><div><span>${this.t('rules.eyebrow')}</span><h2>${this.t('rules.title')}</h2><p>${this.t('rules.description')}</p></div><dl><div><dt>${this.t('rules.plural')}</dt><dd>${artifact.rules.length}</dd></div><div><dt>${this.t('rules.citations')}</dt><dd>${citations.length}</dd></div><div><dt>${this.t('rules.orphans')}</dt><dd>${orphanCount}</dd></div></dl></header><div class="nr-rules__workspace">${this.renderRuleList(artifact, citations)}${rule ? this.renderDetail(rule, citations) : html `<section class="nr-rules__empty-detail"><h2>${this.t('rules.noSelection')}</h2><p>${this.t('rules.noSelectionDescription')}</p></section>`}</div>${this.mode === 'edit' ? html `<footer class="nr-rules__edit-footer"><span>${this.dirty ? this.t('rules.unsaved') : this.t('rules.noChanges')}</span><div><button type="button" @click=${() => this.cancelEdit()}>${this.t('rules.cancel')}</button><button class="is-primary" type="button" ?disabled=${!this.dirty} @click=${() => void this.saveEdit()}>${this.t('rules.save')}</button></div></footer>` : nothing}</section>`;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseRules102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseRules102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseRules102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseRules102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseRules102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseRules102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseRules102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "selectedRuleId", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "query", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "rulesDraft", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "newRuleId", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "suppliedIssues", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "gateIssues", void 0);
__decorate([
    state()
], NewReleaseRules102035.prototype, "editMessage", void 0);
NewReleaseRules102035 = __decorate([
    customElement('new-release--widgets--rules-102035')
], NewReleaseRules102035);
export { NewReleaseRules102035 };
