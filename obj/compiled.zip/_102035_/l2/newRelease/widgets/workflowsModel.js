/// <mls fileReference="_102035_/l2/newRelease/widgets/workflowsModel.ts" enhancement="_blank" />
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function strings(value) {
    return Array.isArray(value) ? value.filter((item) => typeof item === 'string') : [];
}
function triggerOf(value) {
    const item = record(value);
    if (!['scheduled', 'event', 'manual'].includes(String(item.kind || '')))
        return null;
    return {
        kind: item.kind,
        ...(typeof item.schedule === 'string' ? { schedule: item.schedule } : {}),
        ...(typeof item.event === 'string' ? { event: item.event } : {}),
        ...(typeof item.actorRef === 'string' ? { actorRef: item.actorRef } : {}),
    };
}
function taskOf(value) {
    const item = record(value);
    const kind = ['human', 'mechanical', 'llm', 'wait', 'system'].includes(String(item.kind || ''))
        ? String(item.kind)
        : 'wait';
    return {
        taskId: String(item.taskId || ''),
        kind,
        ...(typeof item.actorRef === 'string' ? { actorRef: item.actorRef } : {}),
        ...(typeof item.journeyRef === 'string' ? { journeyRef: item.journeyRef } : {}),
        ...(typeof item.entityRef === 'string' ? { entityRef: item.entityRef } : {}),
        ...(typeof item.effect === 'string' ? { effect: item.effect } : {}),
        ...(typeof item.transitionRef === 'string' ? { transitionRef: item.transitionRef } : {}),
        next: strings(item.next),
        description: String(item.description || ''),
    };
}
export function workflowSchemaKind(value) {
    const version = String(record(value).schemaVersion || '');
    if (version.includes('workflows-v2'))
        return 'v2';
    if (version.includes('workflows-v1'))
        return 'v1';
    return 'unknown';
}
export function normalizeWorkflows(value) {
    const root = record(value);
    const processes = Array.isArray(root.processes) ? root.processes.map(process => {
        const item = record(process);
        return {
            processId: String(item.processId || ''),
            title: String(item.title || item.processId || ''),
            description: String(item.description || ''),
            trigger: triggerOf(item.trigger),
            tasks: Array.isArray(item.tasks) ? item.tasks.map(taskOf) : [],
        };
    }) : [];
    const journeyDecisions = Array.isArray(root.journeyDecisions) ? root.journeyDecisions.map(decision => {
        const item = record(decision);
        return {
            journeyId: String(item.journeyId || ''),
            inProcess: item.inProcess === true,
            ...(typeof item.processId === 'string' ? { processId: item.processId } : {}),
        };
    }) : [];
    return {
        schema: workflowSchemaKind(value),
        schemaVersion: String(root.schemaVersion || ''),
        moduleName: String(root.moduleName || ''),
        processes,
        journeyDecisions,
        raw: value,
    };
}
export function workflowTaskCount(processes) {
    return processes.reduce((total, process) => total + process.tasks.length, 0);
}
export function workflowStartTaskIds(process) {
    const referenced = new Set(process.tasks.flatMap(task => task.next));
    return process.tasks.map(task => task.taskId).filter(taskId => !referenced.has(taskId));
}
export function workflowNextLabels(process, task) {
    const titleById = new Map(process.tasks.map(item => [item.taskId, item.description || item.taskId]));
    return task.next.map(id => titleById.get(id) || id);
}
export function workflowOracleIssues(issues) {
    return issues.filter(issue => issue.artifact === 'workflows.defs.ts'
        || issue.code === 'I6'
        || issue.code.includes('FINALIZE_I6'));
}
export function nextMemberId(prefix, existing) {
    const ids = new Set(existing);
    let number = 1;
    while (ids.has(`${prefix}${number}`))
        number += 1;
    return `${prefix}${number}`;
}
export function workflowsArtifactFromView(view) {
    if (view.schema !== 'v2')
        return null;
    return view.raw;
}
