/// <mls fileReference="_102035_/l2/newRelease/widgets/ontology.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { chart } from '/_102033_/l2/shared/chartRuntimeLocal.js';
import { resolveModuleEntity, resolvePlatformEntity, } from '/_102034_/l2/mdm/resolveMdmEntity.js';
import { announceNewReleaseChange, } from '/_102035_/l2/newRelease/editContract.js';
import { readDefsJson } from '/_102035_/l2/solution/fs.js';
import { ONTOLOGY_DETAIL_NAME, ONTOLOGY_ENUM_VALUE, ONTOLOGY_FIELD_TYPES, buildOntologyGraph, ontologyCardinality, ontologyEntityIssues, ontologyEntityPath, ontologyFieldCounts, ontologyResolvableFields, removeOntologyState, updateOntologyField, updateOntologyRelationship, } from '/_102035_/l2/newRelease/widgets/ontologyModel.js';
import { buildOntologyV3Graph, isOntologyV3Entity, isOntologyV3Index, ontologyNodeLeafCount, ontologyPlatformFile, ontologyV3DerivedFields, ontologyV3FieldCount, } from '/_102035_/l2/newRelease/widgets/ontologyV3Model.js';
let NewReleaseOntology102035 = class NewReleaseOntology102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--ontology-102035 {
  display: block;
}
new-release--widgets--ontology-102035 * {
  box-sizing: border-box;
}
new-release--widgets--ontology-102035 h2,
new-release--widgets--ontology-102035 h3,
new-release--widgets--ontology-102035 h4,
new-release--widgets--ontology-102035 p,
new-release--widgets--ontology-102035 dl,
new-release--widgets--ontology-102035 dd {
  margin: 0;
}
new-release--widgets--ontology-102035 button,
new-release--widgets--ontology-102035 input,
new-release--widgets--ontology-102035 select,
new-release--widgets--ontology-102035 textarea {
  font: inherit;
}
new-release--widgets--ontology-102035 button {
  cursor: pointer;
}
new-release--widgets--ontology-102035 code {
  font-family: var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--ontology-102035 .nr-ontology {
  display: grid;
  min-width: 0;
  color: var(--text-default, #2f3a48);
}
new-release--widgets--ontology-102035 .nr-ontology__hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.2rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-bg, #fff);
}
new-release--widgets--ontology-102035 .nr-ontology__hero > div:first-child > span,
new-release--widgets--ontology-102035 .nr-ontology__section > header h3,
new-release--widgets--ontology-102035 .nr-ontology__summary > span,
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.66rem;
  font-weight: 800;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
new-release--widgets--ontology-102035 .nr-ontology__hero > div:first-child > span {
  color: var(--link-text, #0f62b8);
}
new-release--widgets--ontology-102035 .nr-ontology__hero h2 {
  margin-top: 0.3rem;
  color: var(--text-strong, #111827);
  font-size: 1.45rem;
  letter-spacing: -0.025em;
}
new-release--widgets--ontology-102035 .nr-ontology__hero p {
  max-width: 48rem;
  margin-top: 0.4rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--ontology-102035 .nr-ontology__actions {
  display: flex;
  align-items: center;
  gap: 0.65rem;
}
new-release--widgets--ontology-102035 .nr-ontology__actions > span {
  padding: 0.36rem 0.62rem;
  border-radius: 999px;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-ontology__toggle {
  display: flex;
  padding: 0.18rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.65rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-ontology__toggle button {
  min-height: 1.9rem;
  padding: 0.34rem 0.65rem;
  border: 0;
  border-radius: 0.45rem;
  background: transparent;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-ontology__toggle button.is-active {
  background: var(--surface-bg, #fff);
  color: var(--text-strong, #111827);
  box-shadow: 0 0.08rem 0.28rem color-mix(in srgb, var(--text-strong, #111827) 13%, transparent);
}
new-release--widgets--ontology-102035 .nr-button {
  min-height: 2.25rem;
  padding: 0.42rem 0.75rem;
  border-radius: 0.58rem;
  font-size: 0.72rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-button--secondary {
  border: 1px solid var(--border-default, #cfd8e3);
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--ontology-102035 .nr-ontology__summary {
  display: flex;
  gap: 1px;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--border-subtle, #e4e9f0);
}
new-release--widgets--ontology-102035 .nr-ontology__summary > span {
  display: flex;
  flex: 1;
  align-items: baseline;
  gap: 0.42rem;
  padding: 0.62rem 1rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-ontology__summary strong {
  color: var(--text-strong, #111827);
  font-size: 1rem;
  letter-spacing: -0.03em;
}
new-release--widgets--ontology-102035 .nr-ontology__workbench {
  display: grid;
  grid-template-columns: minmax(12.5rem, 15rem) minmax(0, 1fr);
  min-height: 40rem;
}
new-release--widgets--ontology-102035 .nr-ontology__workbench > aside {
  display: grid;
  align-content: start;
  gap: 0.38rem;
  padding: 0.85rem;
  border-right: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-ontology__workbench > aside button {
  display: grid;
  min-width: 0;
  gap: 0.22rem;
  padding: 0.65rem 0.7rem;
  border: 1px solid transparent;
  border-radius: 0.68rem;
  background: transparent;
  color: var(--text-default, #2f3a48);
  text-align: left;
}
new-release--widgets--ontology-102035 .nr-ontology__workbench > aside button:hover {
  background: var(--surface-bg, #fff);
}
new-release--widgets--ontology-102035 .nr-ontology__workbench > aside button.is-active {
  border-color: var(--selected-border, #1273d4);
  background: var(--selected-bg, #e3f1ff);
  box-shadow: inset 0.19rem 0 var(--selected-border, #1273d4);
}
new-release--widgets--ontology-102035 .nr-ontology__workbench > aside strong {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.77rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--ontology-102035 .nr-ontology__workbench > aside code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
}
new-release--widgets--ontology-102035 .nr-ontology__workbench > aside button > span {
  display: flex;
  flex-wrap: wrap;
  gap: 0.22rem;
  margin-top: 0.18rem;
}
new-release--widgets--ontology-102035 .nr-ontology__workbench > aside i {
  padding: 0.13rem 0.3rem;
  border-radius: 0.28rem;
  background: color-mix(in srgb, var(--selected-border, #1273d4) 10%, var(--surface-bg, #fff));
  color: var(--text-muted, #5d6b7e);
  font-size: 0.54rem;
  font-style: normal;
}
new-release--widgets--ontology-102035 .nr-ontology__workbench > main {
  display: grid;
  align-content: start;
  min-width: 0;
  gap: 0.9rem;
  padding: 1rem 1.1rem 1.35rem;
  background: var(--page-bg, #f8fafc);
}
new-release--widgets--ontology-102035 .nr-ontology__identity,
new-release--widgets--ontology-102035 .nr-ontology__section,
new-release--widgets--ontology-102035 .nr-ontology__issues {
  min-width: 0;
  padding: 0.95rem 1rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.85rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--ontology-102035 .nr-ontology__identity {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 0.75rem 1rem;
}
new-release--widgets--ontology-102035 .nr-ontology__identity > div:first-child > span {
  display: block;
  margin-bottom: 0.25rem;
  color: var(--link-text, #0f62b8);
  font-size: 0.63rem;
  font-weight: 800;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
new-release--widgets--ontology-102035 .nr-ontology__identity h2 {
  color: var(--text-strong, #111827);
  font-size: 1.3rem;
}
new-release--widgets--ontology-102035 .nr-ontology__identity code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.67rem;
}
new-release--widgets--ontology-102035 .nr-ontology__identity > p {
  grid-column: 1 / -1;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.8rem;
  line-height: 1.55;
}
new-release--widgets--ontology-102035 .nr-ontology__field-breakdown {
  display: inline-flex;
  grid-column: 1 / -1;
  width: fit-content;
  padding: 0.25rem 0.48rem;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
  font-weight: 700;
}
new-release--widgets--ontology-102035 .nr-ontology__badges {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 0.28rem;
}
new-release--widgets--ontology-102035 .nr-ontology__badges span,
new-release--widgets--ontology-102035 .nr-chip {
  padding: 0.22rem 0.42rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.38rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
  font-weight: 700;
}
new-release--widgets--ontology-102035 .nr-chip.is-required {
  border-color: color-mix(in srgb, var(--status-info-text, #0b5497) 30%, transparent);
  background: var(--status-info-bg, #e1effd);
  color: var(--status-info-text, #0b5497);
}
new-release--widgets--ontology-102035 .nr-chip.is-unique {
  border-color: color-mix(in srgb, var(--status-success-text, #25640e) 30%, transparent);
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--ontology-102035 .nr-chip.is-platform {
  border-color: color-mix(in srgb, var(--chart-series-4, #7b61a8) 40%, var(--border-subtle, #e4e9f0));
  background: color-mix(in srgb, var(--chart-series-4, #7b61a8) 13%, var(--surface-bg, #fff));
  color: var(--chart-series-4, #7b61a8);
}
new-release--widgets--ontology-102035 .nr-ontology__identity dl {
  display: grid;
  grid-column: 1 / -1;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 0.55rem;
  padding-top: 0.7rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--ontology-102035 .nr-ontology__identity dl div {
  min-width: 0;
}
new-release--widgets--ontology-102035 .nr-ontology__identity dt {
  margin-bottom: 0.17rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
  font-weight: 700;
  text-transform: uppercase;
}
new-release--widgets--ontology-102035 .nr-ontology__identity dd {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.72rem;
  text-overflow: ellipsis;
}
new-release--widgets--ontology-102035 .nr-ontology__description-edit {
  grid-column: 1 / -1;
}
new-release--widgets--ontology-102035 .nr-ontology__section > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1rem;
  margin-bottom: 0.7rem;
}
new-release--widgets--ontology-102035 .nr-ontology__section > header h3 {
  color: var(--text-strong, #111827);
}
new-release--widgets--ontology-102035 .nr-ontology__section > header p {
  max-width: 48rem;
  margin-top: 0.22rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-ontology__section > header > span {
  flex: none;
  padding: 0.2rem 0.42rem;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
}
new-release--widgets--ontology-102035 .nr-ontology input,
new-release--widgets--ontology-102035 .nr-ontology select,
new-release--widgets--ontology-102035 .nr-ontology textarea {
  width: 100%;
  min-height: 2rem;
  padding: 0.36rem 0.5rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.48rem;
  outline: none;
  background: var(--input-bg, var(--surface-bg, #fff));
  color: var(--input-text, var(--text-default, #2f3a48));
  font-size: 0.7rem;
}
new-release--widgets--ontology-102035 .nr-ontology textarea {
  min-height: 3.7rem;
  resize: vertical;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-ontology select[multiple] {
  min-height: 5rem;
}
new-release--widgets--ontology-102035 .nr-ontology input:focus,
new-release--widgets--ontology-102035 .nr-ontology select:focus,
new-release--widgets--ontology-102035 .nr-ontology textarea:focus,
new-release--widgets--ontology-102035 .nr-ontology button:focus-visible {
  border-color: var(--focus-ring, #1273d4);
  box-shadow: 0 0 0 0.18rem color-mix(in srgb, var(--focus-ring, #1273d4) 18%, transparent);
  outline: none;
}
new-release--widgets--ontology-102035 .nr-ontology input.is-invalid {
  border-color: var(--status-error-text, #ab2328);
}
new-release--widgets--ontology-102035 .nr-ontology label > span {
  display: block;
  margin-bottom: 0.2rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
  font-weight: 700;
}
new-release--widgets--ontology-102035 .nr-ontology__fields {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.62rem;
}
new-release--widgets--ontology-102035 .nr-field {
  display: grid;
  align-content: start;
  min-width: 0;
  gap: 0.45rem;
  padding: 0.72rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.68rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-field > header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
}
new-release--widgets--ontology-102035 .nr-field > header > div {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 0.22rem;
}
new-release--widgets--ontology-102035 .nr-field > header code {
  color: var(--link-text, #0f62b8);
  font-size: 0.68rem;
  font-weight: 700;
}
new-release--widgets--ontology-102035 .nr-field h4 {
  color: var(--text-strong, #111827);
  font-size: 0.8rem;
}
new-release--widgets--ontology-102035 .nr-field > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-field.is-platform {
  border-color: color-mix(in srgb, var(--chart-series-4, #7b61a8) 38%, var(--border-subtle, #e4e9f0));
  background: color-mix(in srgb, var(--chart-series-4, #7b61a8) 7%, var(--surface-alt-bg, #f5f7fa));
  box-shadow: inset 0.18rem 0 var(--chart-series-4, #7b61a8);
}
new-release--widgets--ontology-102035 .nr-field__edit-grid {
  display: grid;
  grid-template-columns: minmax(0, 1.35fr) minmax(7rem, 0.65fr);
  gap: 0.5rem;
}
new-release--widgets--ontology-102035 .nr-field__description {
  grid-column: 1 / -1;
}
new-release--widgets--ontology-102035 .nr-check {
  display: flex;
  align-items: center;
  gap: 0.38rem;
}
new-release--widgets--ontology-102035 .nr-check input {
  flex: none;
  width: 1rem;
  min-height: 1rem;
  accent-color: var(--selected-border, #1273d4);
}
new-release--widgets--ontology-102035 .nr-check span {
  margin: 0;
}
new-release--widgets--ontology-102035 .nr-ontology__constraints {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 0.35rem;
  padding-top: 0.4rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--ontology-102035 .nr-field__constraints-view {
  display: flex;
  flex-wrap: wrap;
  gap: 0.3rem;
}
new-release--widgets--ontology-102035 .nr-field__constraints-view div {
  display: flex;
  gap: 0.22rem;
  padding: 0.18rem 0.35rem;
  border-radius: 0.3rem;
  background: var(--surface-bg, #fff);
  font-size: 0.61rem;
}
new-release--widgets--ontology-102035 .nr-field__constraints-view dt {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--ontology-102035 .nr-field__constraints-view dd {
  color: var(--text-strong, #111827);
  font-weight: 700;
}
new-release--widgets--ontology-102035 .nr-field__enum {
  display: grid;
  gap: 0.32rem;
  padding-top: 0.4rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--ontology-102035 .nr-field__enum > strong {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
}
new-release--widgets--ontology-102035 .nr-field__enum > div {
  display: grid;
  grid-template-columns: minmax(0, 0.7fr) minmax(0, 1.3fr) auto;
  gap: 0.3rem;
}
new-release--widgets--ontology-102035 .nr-field__enum button,
new-release--widgets--ontology-102035 .nr-ontology__key-list button,
new-release--widgets--ontology-102035 .nr-lifecycle__rail button {
  width: 2rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.42rem;
  background: var(--surface-bg, #fff);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--ontology-102035 .nr-text-button {
  justify-self: start;
  padding: 0.28rem 0;
  border: 0;
  background: transparent;
  color: var(--link-text, #0f62b8);
  font-size: 0.65rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-field__enum-view {
  display: flex;
  flex-wrap: wrap;
  gap: 0.3rem;
}
new-release--widgets--ontology-102035 .nr-field__enum-view span {
  display: grid;
  gap: 0.06rem;
  padding: 0.3rem 0.42rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.4rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--ontology-102035 .nr-field__enum-view strong {
  color: var(--text-strong, #111827);
  font-size: 0.62rem;
}
new-release--widgets--ontology-102035 .nr-field__enum-view code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.55rem;
}
new-release--widgets--ontology-102035 .nr-ontology__base-fields {
  border-left: 0.25rem solid var(--chart-series-4, #7b61a8);
}
new-release--widgets--ontology-102035 .nr-ontology__readonly-note {
  padding: 0.52rem 0.62rem;
  border: 1px solid color-mix(in srgb, var(--chart-series-4, #7b61a8) 32%, var(--border-subtle, #e4e9f0));
  border-radius: 0.55rem;
  background: color-mix(in srgb, var(--chart-series-4, #7b61a8) 8%, var(--surface-bg, #fff));
  color: var(--text-muted, #5d6b7e);
  font-size: 0.66rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-ontology__two-columns {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.9rem;
}
new-release--widgets--ontology-102035 .nr-ontology__key-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.38rem;
}
new-release--widgets--ontology-102035 .nr-ontology__key-list > span {
  display: flex;
  align-items: center;
  gap: 0.22rem;
  padding: 0.25rem 0.3rem 0.25rem 0.42rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.45rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-ontology__key-list code + code::before {
  content: '+';
  margin-right: 0.22rem;
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--ontology-102035 .nr-ontology__key-list code {
  color: var(--text-strong, #111827);
  font-size: 0.61rem;
}
new-release--widgets--ontology-102035 .nr-ontology__key-list button {
  width: 1.5rem;
  min-height: 1.5rem;
}
new-release--widgets--ontology-102035 .nr-ontology__detail-list {
  display: grid;
  gap: 0.38rem;
}
new-release--widgets--ontology-102035 .nr-ontology__detail-list article {
  display: grid;
  grid-template-columns: minmax(6rem, 0.45fr) minmax(5rem, 0.35fr) minmax(0, 1.2fr) auto;
  align-items: start;
  gap: 0.35rem;
  padding: 0.46rem;
  border-radius: 0.52rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-ontology__detail-list article > code {
  padding-top: 0.38rem;
  color: var(--link-text, #0f62b8);
  font-size: 0.65rem;
}
new-release--widgets--ontology-102035 .nr-ontology__detail-list article > span {
  padding-top: 0.38rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
}
new-release--widgets--ontology-102035 .nr-ontology__detail-list article > p {
  grid-column: span 2;
  padding-top: 0.3rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
  line-height: 1.4;
}
new-release--widgets--ontology-102035 .nr-ontology__detail-list button,
new-release--widgets--ontology-102035 .nr-transition__grid > button {
  min-height: 2rem;
  padding: 0.3rem 0.48rem;
  border: 1px solid color-mix(in srgb, var(--status-error-text, #ab2328) 35%, transparent);
  border-radius: 0.45rem;
  background: transparent;
  color: var(--status-error-text, #ab2328);
  font-size: 0.62rem;
}
new-release--widgets--ontology-102035 .nr-ontology__empty-inline {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
  font-style: italic;
}
new-release--widgets--ontology-102035 .nr-ontology__adder {
  display: flex;
  align-items: stretch;
  gap: 0.4rem;
  margin-top: 0.62rem;
  padding-top: 0.62rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--ontology-102035 .nr-ontology__adder input,
new-release--widgets--ontology-102035 .nr-ontology__adder select {
  max-width: 14rem;
}
new-release--widgets--ontology-102035 .nr-ontology__adder select[multiple] {
  min-width: 14rem;
}
new-release--widgets--ontology-102035 .nr-ontology__adder button {
  align-self: flex-start;
  min-height: 2rem;
  padding: 0.34rem 0.58rem;
  border: 1px solid var(--selected-border, #1273d4);
  border-radius: 0.48rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.65rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-lifecycle__rail {
  display: flex;
  align-items: stretch;
  gap: 0.72rem;
  overflow-x: auto;
  padding: 0.3rem 0.1rem 0.7rem;
}
new-release--widgets--ontology-102035 .nr-lifecycle__rail > span {
  position: relative;
  display: grid;
  flex: 0 0 8.7rem;
  align-content: center;
  gap: 0.14rem;
  min-height: 3.8rem;
  padding: 0.45rem 0.55rem;
  border: 1px solid var(--selected-border, #1273d4);
  border-radius: 0.58rem;
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--ontology-102035 .nr-lifecycle__rail > span:not(:last-child)::after {
  content: '→';
  position: absolute;
  right: -0.58rem;
  top: 1.2rem;
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--ontology-102035 .nr-lifecycle__rail strong {
  color: var(--selected-text, #0d5296);
  font-size: 0.68rem;
}
new-release--widgets--ontology-102035 .nr-lifecycle__rail small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
}
new-release--widgets--ontology-102035 .nr-lifecycle__rail select {
  margin-top: 0.18rem;
}
new-release--widgets--ontology-102035 .nr-lifecycle__rail button {
  position: absolute;
  top: 0.18rem;
  right: 0.18rem;
  width: 1.25rem;
  min-height: 1.25rem;
  border: 0;
  background: transparent;
}
new-release--widgets--ontology-102035 .nr-lifecycle__transitions {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.48rem;
  margin-top: 0.6rem;
}
new-release--widgets--ontology-102035 .nr-lifecycle__transitions > article {
  display: grid;
  gap: 0.36rem;
  padding: 0.62rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.6rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-lifecycle__transitions article > header {
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
}
new-release--widgets--ontology-102035 .nr-lifecycle__transitions article > header code {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 700;
}
new-release--widgets--ontology-102035 .nr-lifecycle__transitions article > header span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
}
new-release--widgets--ontology-102035 .nr-lifecycle__transitions article > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-lifecycle__transitions article > footer {
  display: flex;
  flex-wrap: wrap;
  gap: 0.45rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
}
new-release--widgets--ontology-102035 .nr-lifecycle__transitions article > footer code {
  margin-left: 0.22rem;
}
new-release--widgets--ontology-102035 .nr-transition__grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.38rem;
}
new-release--widgets--ontology-102035 .nr-transition__description {
  grid-column: 1 / -1;
}
new-release--widgets--ontology-102035 .nr-transition__grid > button {
  justify-self: start;
}
new-release--widgets--ontology-102035 .nr-ontology__relationships {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.48rem;
}
new-release--widgets--ontology-102035 .nr-ontology__relationships > article {
  display: grid;
  gap: 0.3rem;
  min-width: 0;
  padding: 0.62rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.6rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-ontology__relationships article > header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
}
new-release--widgets--ontology-102035 .nr-ontology__relationships article > header strong {
  display: flex;
  min-width: 0;
  align-items: center;
  gap: 0.3rem;
  color: var(--text-strong, #111827);
  font-size: 0.68rem;
}
new-release--widgets--ontology-102035 .nr-ontology__relationships article > header i {
  color: var(--link-text, #0f62b8);
  font-style: normal;
}
new-release--widgets--ontology-102035 .nr-ontology__relationships article > header span,
new-release--widgets--ontology-102035 .nr-ontology__relationships article > span {
  padding: 0.16rem 0.32rem;
  border-radius: 0.3rem;
  background: var(--surface-bg, #fff);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
}
new-release--widgets--ontology-102035 .nr-ontology__relationships article > span.is-required {
  color: var(--status-info-text, #0b5497);
}
new-release--widgets--ontology-102035 .nr-ontology__relationships article > code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
}
new-release--widgets--ontology-102035 .nr-ontology__relationships article > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-relationship__edit {
  display: grid;
  grid-template-columns: minmax(7rem, 0.5fr) minmax(7rem, 0.5fr);
  gap: 0.4rem;
}
new-release--widgets--ontology-102035 .nr-relationship__edit > label:last-child {
  grid-column: 1 / -1;
}
new-release--widgets--ontology-102035 .nr-ontology__issues {
  border-left: 0.25rem solid var(--status-warning-text, #7a5000);
  background: var(--status-warning-bg, #fff1cc);
}
new-release--widgets--ontology-102035 .nr-ontology__issues > strong {
  color: var(--status-warning-text, #7a5000);
  font-size: 0.72rem;
}
new-release--widgets--ontology-102035 .nr-ontology__issues p {
  display: flex;
  gap: 0.4rem;
  margin-top: 0.35rem;
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
  line-height: 1.4;
}
new-release--widgets--ontology-102035 .nr-ontology__issues p > span {
  flex: none;
  font-weight: 800;
}
new-release--widgets--ontology-102035 .nr-ontology__issues p.error > span {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 15.5rem;
  min-height: 42rem;
  background: var(--page-bg, #f8fafc);
}
new-release--widgets--ontology-102035 .nr-ontology__graph {
  min-width: 0;
  min-height: 42rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside {
  display: grid;
  align-content: start;
  gap: 0.45rem;
  padding: 1rem;
  border-left: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside h2 {
  color: var(--text-strong, #111827);
  font-size: 1rem;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside code {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
  line-height: 1.5;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside dl {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0.3rem;
  margin-top: 0.35rem;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside dl div {
  padding: 0.45rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.48rem;
  background: var(--surface-bg, #fff);
  text-align: center;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside dt {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.52rem;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside dd {
  margin-top: 0.16rem;
  color: var(--text-strong, #111827);
  font-size: 0.88rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside button {
  margin-top: 0.35rem;
  padding: 0.42rem 0.62rem;
  border: 1px solid var(--selected-border, #1273d4);
  border-radius: 0.5rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-legend {
  display: flex;
  align-items: center;
  gap: 0.3rem;
  padding-top: 0.45rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--ontology-102035 .nr-ontology__graph-legend > span {
  width: 0.65rem;
  height: 0.65rem;
  border-radius: 0.18rem;
  background: var(--chart-series-4, #7b61a8);
}
new-release--widgets--ontology-102035 .nr-ontology__graph-legend strong {
  color: var(--text-strong, #111827);
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative {
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-bg, #fff);
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative > summary {
  padding: 0.75rem 1rem;
  color: var(--link-text, #0f62b8);
  cursor: pointer;
  font-size: 0.7rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative > div {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1rem;
  padding: 0 1rem 1rem;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative h3 {
  margin: 0 0 0.45rem;
  color: var(--text-strong, #111827);
  font-size: 0.72rem;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative ul {
  display: grid;
  gap: 0.3rem;
  margin: 0;
  padding: 0;
  list-style: none;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative li {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  min-width: 0;
  color: var(--text-default, #2f3a48);
  font-size: 0.65rem;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative li > button {
  display: grid;
  width: 100%;
  gap: 0.12rem;
  padding: 0.4rem 0.5rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.45rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-default, #2f3a48);
  text-align: left;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative li > button code,
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative li > code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative li > span {
  flex: none;
  color: var(--link-text, #0f62b8);
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-ontology__graph-alternative li > strong {
  min-width: 0;
  overflow-wrap: anywhere;
}
new-release--widgets--ontology-102035 .nr-ontology__edit-footer {
  position: sticky;
  z-index: 4;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.7rem 1rem;
  border-top: 1px solid var(--border-default, #cfd8e3);
  background: color-mix(in srgb, var(--surface-bg, #fff) 94%, transparent);
  box-shadow: 0 -0.45rem 1.3rem color-mix(in srgb, var(--text-strong, #111827) 8%, transparent);
  backdrop-filter: blur(0.5rem);
}
new-release--widgets--ontology-102035 .nr-ontology__edit-footer > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.67rem;
}
new-release--widgets--ontology-102035 .nr-ontology__edit-footer > div {
  display: flex;
  gap: 0.45rem;
}
new-release--widgets--ontology-102035 .nr-ontology__edit-footer button {
  min-height: 2.1rem;
  padding: 0.38rem 0.68rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.5rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-ontology__edit-footer button.is-primary {
  border-color: var(--button-primary-bg, #126ac2);
  background: var(--button-primary-bg, #126ac2);
  color: var(--button-primary-text, #fff);
}
new-release--widgets--ontology-102035 .nr-ontology__edit-footer button:disabled {
  cursor: not-allowed;
  opacity: 0.45;
}
new-release--widgets--ontology-102035 .nr-ontology__empty {
  display: grid;
  place-items: center;
  gap: 0.4rem;
  min-height: 22rem;
  padding: 2rem;
  text-align: center;
}
new-release--widgets--ontology-102035 .nr-ontology__empty h2 {
  color: var(--text-strong, #111827);
  font-size: 1.1rem;
}
new-release--widgets--ontology-102035 .nr-ontology__empty p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.75rem;
}
new-release--widgets--ontology-102035 .nr-v3 .nr-ontology__actions {
  display: grid;
  grid-template-columns: auto auto;
  justify-items: end;
}
new-release--widgets--ontology-102035 .nr-v3__edit-note {
  grid-column: 1 / -1;
  max-width: none;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
  line-height: 1.35;
  text-align: right;
}
new-release--widgets--ontology-102035 .nr-v3 .nr-button:disabled {
  cursor: not-allowed;
  opacity: 0.48;
}
new-release--widgets--ontology-102035 .nr-v3__entity-accordion {
  display: grid;
  gap: 0.7rem;
  padding: 1rem 1.1rem 1.35rem;
  background: var(--page-bg, #f8fafc);
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel {
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.9rem;
  background: var(--surface-bg, #fff);
  box-shadow: 0 0.18rem 0.65rem color-mix(in srgb, var(--text-strong, #111827) 5%, transparent);
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel.is-platform {
  border-style: dashed;
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel[open] {
  border-color: color-mix(in srgb, var(--selected-border, #1273d4) 62%, var(--border-subtle, #e4e9f0));
  box-shadow: 0 0.45rem 1.35rem color-mix(in srgb, var(--selected-border, #1273d4) 13%, transparent);
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel > summary {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.85rem 1rem 0.85rem 2.65rem;
  scroll-margin-top: 1rem;
  cursor: pointer;
  list-style: none;
  background: var(--surface-bg, #fff);
  transition: background 0.2s ease;
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel > summary::-webkit-details-marker {
  display: none;
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel > summary::before {
  position: absolute;
  top: 0.78rem;
  left: 1rem;
  content: '▸';
  color: var(--link-text, #0f62b8);
  font-size: 1.22rem;
  font-weight: 900;
  line-height: 1;
  transition: transform 0.24s ease;
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel[open] > summary {
  background: color-mix(in srgb, var(--selected-bg, #e3f1ff) 68%, var(--surface-bg, #fff));
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel[open] > summary::before {
  transform: rotate(90deg);
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel > summary > span:first-of-type {
  display: grid;
  gap: 0.08rem;
  min-width: 0;
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel > summary strong {
  color: var(--text-strong, #111827);
  font-size: 0.84rem;
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel > summary code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
}
new-release--widgets--ontology-102035 .nr-v3__entity-meta {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 0.3rem;
}
new-release--widgets--ontology-102035 .nr-v3__entity-meta i {
  padding: 0.2rem 0.42rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
  font-style: normal;
  font-weight: 700;
}
new-release--widgets--ontology-102035 .nr-v3__entity-reveal {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition: grid-template-rows 0.8s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.8s ease;
}
new-release--widgets--ontology-102035 .nr-v3__entity-reveal > div {
  min-height: 0;
  overflow: hidden;
}
new-release--widgets--ontology-102035 .nr-v3__entity-panel[open] > .nr-v3__entity-reveal {
  grid-template-rows: 1fr;
  opacity: 1;
}
new-release--widgets--ontology-102035 .nr-v3__entity-content {
  display: grid;
  gap: 1rem;
  padding: 1rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--page-bg, #f8fafc);
}
new-release--widgets--ontology-102035 .nr-v3__identity dl {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
new-release--widgets--ontology-102035 .nr-v3__section {
  overflow: hidden;
}
new-release--widgets--ontology-102035 details.nr-v3__collapsible-section {
  padding: 0;
}
new-release--widgets--ontology-102035 .nr-v3__section-summary {
  position: relative;
  padding: 0.95rem 1rem 0.95rem 2.45rem;
  cursor: pointer;
  list-style: none;
}
new-release--widgets--ontology-102035 .nr-v3__section-summary::-webkit-details-marker {
  display: none;
}
new-release--widgets--ontology-102035 .nr-v3__section-summary > div {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1rem;
}
new-release--widgets--ontology-102035 .nr-v3__section-summary h3 {
  color: var(--text-strong, #111827);
  font-size: 0.78rem;
}
new-release--widgets--ontology-102035 .nr-v3__section-summary p {
  max-width: 48rem;
  margin-top: 0.22rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-v3__section-summary > div > span {
  flex: none;
  padding: 0.2rem 0.42rem;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
}
new-release--widgets--ontology-102035 .nr-v3__section-body {
  padding: 0 1rem 0.95rem;
}
new-release--widgets--ontology-102035 .nr-v3__record {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(10.5rem, 1fr));
  gap: 0.55rem;
}
new-release--widgets--ontology-102035 .nr-v3__record > article {
  display: grid;
  align-content: start;
  gap: 0.45rem;
  min-height: 7.6rem;
  padding: 0.7rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.68rem;
  background: var(--surface-alt-bg, #f5f7fa);
  box-shadow: inset 0 0.18rem var(--chart-series-1, #1677c8);
}
new-release--widgets--ontology-102035 .nr-v3__record > article.is-details {
  box-shadow: inset 0 0.18rem var(--chart-series-4, #7b61a8);
}
new-release--widgets--ontology-102035 .nr-v3__record article > header {
  display: grid;
  gap: 0.12rem;
}
new-release--widgets--ontology-102035 .nr-v3__record article > header strong {
  color: var(--text-strong, #111827);
  font-size: 0.75rem;
}
new-release--widgets--ontology-102035 .nr-v3__record article > header code {
  color: var(--link-text, #0f62b8);
  font-size: 0.6rem;
}
new-release--widgets--ontology-102035 .nr-v3__record article > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-v3__chips {
  display: flex;
  flex-wrap: wrap;
  gap: 0.24rem;
}
new-release--widgets--ontology-102035 .nr-chip.is-module {
  border-color: color-mix(in srgb, var(--chart-series-2, #008f77) 35%, transparent);
  color: var(--chart-series-2, #008f77);
}
new-release--widgets--ontology-102035 .nr-chip.is-derived {
  border-color: color-mix(in srgb, var(--chart-series-5, #a55c00) 35%, transparent);
  color: var(--chart-series-5, #a55c00);
}
new-release--widgets--ontology-102035 .nr-chip.is-indexed {
  border-color: color-mix(in srgb, var(--selected-border, #1273d4) 35%, transparent);
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
}
new-release--widgets--ontology-102035 .nr-chip.is-tightened {
  border-color: color-mix(in srgb, var(--status-warning-text, #7a5000) 35%, transparent);
  background: var(--status-warning-bg, #fff1cc);
  color: var(--status-warning-text, #7a5000);
}
new-release--widgets--ontology-102035 .nr-chip.is-ready {
  border-color: color-mix(in srgb, var(--status-success-text, #25640e) 35%, transparent);
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--ontology-102035 .nr-chip.is-partial {
  border-color: color-mix(in srgb, var(--status-warning-text, #7a5000) 35%, transparent);
  background: var(--status-warning-bg, #fff1cc);
  color: var(--status-warning-text, #7a5000);
}
new-release--widgets--ontology-102035 .nr-chip.is-missing {
  border-color: color-mix(in srgb, var(--status-error-text, #ab2328) 35%, transparent);
  background: var(--status-error-bg, #fde7e8);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--ontology-102035 .nr-v3__tree {
  display: grid;
  gap: 0.48rem;
}
new-release--widgets--ontology-102035 .nr-v3__tree-node {
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.66rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-v3__tree-node > summary,
new-release--widgets--ontology-102035 .nr-v3__tree-node > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.6rem;
  padding: 0.62rem 0.7rem;
}
new-release--widgets--ontology-102035 .nr-v3__tree-node > summary {
  position: relative;
  padding-left: 2.2rem;
  cursor: pointer;
  list-style: none;
}
new-release--widgets--ontology-102035 .nr-v3__tree-node > summary::-webkit-details-marker {
  display: none;
}
new-release--widgets--ontology-102035 .nr-v3__tree-node > summary::before,
new-release--widgets--ontology-102035 .nr-v3__section-summary::before {
  position: absolute;
  top: 0.57rem;
  left: 0.7rem;
  content: '▸';
  color: var(--link-text, #0f62b8);
  font-size: 1.15rem;
  font-weight: 900;
  line-height: 1;
  transition: transform 0.16s ease;
}
new-release--widgets--ontology-102035 .nr-v3__section-summary::before {
  top: 0.87rem;
  left: 1rem;
}
new-release--widgets--ontology-102035 .nr-v3__tree-node[open] > summary::before,
new-release--widgets--ontology-102035 .nr-v3__collapsible-section[open] > .nr-v3__section-summary::before {
  transform: rotate(90deg);
}
new-release--widgets--ontology-102035 .nr-v3__tree-node > summary > span:first-child,
new-release--widgets--ontology-102035 .nr-v3__tree-node > header > span:first-child {
  display: grid;
  gap: 0.1rem;
  min-width: 7rem;
}
new-release--widgets--ontology-102035 .nr-v3__tree-node strong {
  color: var(--text-strong, #111827);
  font-size: 0.7rem;
}
new-release--widgets--ontology-102035 .nr-v3__tree-node code {
  color: var(--link-text, #0f62b8);
  font-size: 0.58rem;
}
new-release--widgets--ontology-102035 .nr-v3__branch-count {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
  font-weight: 700;
}
new-release--widgets--ontology-102035 .nr-v3__node-body {
  display: grid;
  gap: 0.45rem;
  padding: 0 0.7rem 0.7rem;
}
new-release--widgets--ontology-102035 .nr-v3__node-body > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-v3__children {
  display: grid;
  gap: 0.42rem;
  padding: 0.55rem 0 0 0.68rem;
  border-left: 0.16rem solid color-mix(in srgb, var(--chart-series-4, #7b61a8) 38%, transparent);
}
new-release--widgets--ontology-102035 .nr-v3__children .nr-v3__tree-node {
  background: var(--surface-bg, #fff);
}
new-release--widgets--ontology-102035 .nr-v3__warning {
  padding: 0.42rem 0.52rem;
  border-radius: 0.45rem;
  background: var(--status-warning-bg, #fff1cc);
  color: var(--status-warning-text, #7a5000) !important;
  font-weight: 700;
}
new-release--widgets--ontology-102035 .nr-v3__empty-branch {
  padding: 0.45rem;
  border: 1px dashed var(--border-default, #cfd8e3);
  border-radius: 0.45rem;
  background: var(--surface-bg, #fff);
  font-style: italic;
}
new-release--widgets--ontology-102035 .nr-v3__values {
  display: flex;
  flex-wrap: wrap;
  gap: 0.3rem;
}
new-release--widgets--ontology-102035 .nr-v3__values > span {
  display: grid;
  gap: 0.05rem;
  padding: 0.28rem 0.38rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.4rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--ontology-102035 .nr-v3__values strong {
  font-size: 0.61rem;
}
new-release--widgets--ontology-102035 .nr-v3__values code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.53rem;
}
new-release--widgets--ontology-102035 .nr-v3__relationships {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.5rem;
}
new-release--widgets--ontology-102035 .nr-v3__relationships > article {
  display: grid;
  align-content: start;
  gap: 0.45rem;
  padding: 0.68rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.65rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-v3__relationships > article.has-conflict {
  border-color: var(--status-warning-text, #7a5000);
}
new-release--widgets--ontology-102035 .nr-v3__relationships article > header {
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
}
new-release--widgets--ontology-102035 .nr-v3__relationships article > header > div {
  display: grid;
  gap: 0.1rem;
}
new-release--widgets--ontology-102035 .nr-v3__relationships article > header strong {
  color: var(--text-strong, #111827);
  font-size: 0.72rem;
}
new-release--widgets--ontology-102035 .nr-v3__relationships article > header code {
  color: var(--link-text, #0f62b8);
  font-size: 0.56rem;
}
new-release--widgets--ontology-102035 .nr-v3__relationships article > header > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-v3__relationships article > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-v3__relationships dl {
  display: grid;
  gap: 0.34rem;
}
new-release--widgets--ontology-102035 .nr-v3__relationships dl > div {
  display: grid;
  grid-template-columns: 4rem minmax(0, 1fr);
  gap: 0.35rem;
}
new-release--widgets--ontology-102035 .nr-v3__relationships dt {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--ontology-102035 .nr-v3__relationships dd {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  color: var(--text-default, #2f3a48);
  font-size: 0.62rem;
}
new-release--widgets--ontology-102035 .nr-v3__relationships dd button {
  padding: 0;
  border: 0;
  background: transparent;
  color: var(--link-text, #0f62b8);
  font-size: 0.62rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-v3__relationships footer {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
}
new-release--widgets--ontology-102035 .nr-v3__path {
  padding: 0.38rem;
  border-radius: 0.4rem;
  background: var(--surface-bg, #fff);
  overflow-wrap: anywhere;
}
new-release--widgets--ontology-102035 .nr-v3__split {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.75rem;
}
new-release--widgets--ontology-102035 .nr-v3__split > section {
  min-width: 0;
}
new-release--widgets--ontology-102035 .nr-v3__split h4 {
  margin-bottom: 0.42rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
new-release--widgets--ontology-102035 .nr-v3__catalog {
  display: grid;
  gap: 0.4rem;
}
new-release--widgets--ontology-102035 .nr-v3__catalog article {
  display: grid;
  gap: 0.3rem;
  padding: 0.58rem 0.62rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.55rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-v3__catalog article.is-unresolved {
  border-color: var(--status-warning-text, #7a5000);
}
new-release--widgets--ontology-102035 .nr-v3__catalog article > header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.35rem;
}
new-release--widgets--ontology-102035 .nr-v3__catalog article code {
  overflow-wrap: anywhere;
  color: var(--link-text, #0f62b8);
  font-size: 0.59rem;
  font-weight: 750;
}
new-release--widgets--ontology-102035 .nr-v3__catalog article p {
  color: var(--text-default, #2f3a48);
  font-size: 0.65rem;
  line-height: 1.45;
}
new-release--widgets--ontology-102035 .nr-v3__catalog article small {
  padding-top: 0.3rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
  line-height: 1.4;
}
new-release--widgets--ontology-102035 .nr-v3__unique {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.4rem;
  margin-bottom: 0.65rem;
}
new-release--widgets--ontology-102035 .nr-v3__unique > strong {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
  text-transform: uppercase;
}
new-release--widgets--ontology-102035 .nr-v3__unique > span {
  display: flex;
  gap: 0.25rem;
  padding: 0.3rem 0.42rem;
  border-radius: 0.42rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--ontology-102035 .nr-v3__unique code + code::before {
  content: '+';
  margin-right: 0.25rem;
  color: var(--text-muted, #5d6b7e);
}
@media (max-width: 960px) {
  new-release--widgets--ontology-102035 .nr-ontology__fields,
  new-release--widgets--ontology-102035 .nr-ontology__two-columns,
  new-release--widgets--ontology-102035 .nr-lifecycle__transitions,
  new-release--widgets--ontology-102035 .nr-ontology__relationships,
  new-release--widgets--ontology-102035 .nr-v3__relationships,
  new-release--widgets--ontology-102035 .nr-v3__split {
    grid-template-columns: 1fr;
  }
  new-release--widgets--ontology-102035 .nr-ontology__identity dl {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 760px) {
  new-release--widgets--ontology-102035 .nr-ontology__hero,
  new-release--widgets--ontology-102035 .nr-ontology__workbench,
  new-release--widgets--ontology-102035 .nr-ontology__graph-layout {
    grid-template-columns: 1fr;
  }
  new-release--widgets--ontology-102035 .nr-ontology__hero {
    display: grid;
  }
  new-release--widgets--ontology-102035 .nr-ontology__actions {
    flex-wrap: wrap;
  }
  new-release--widgets--ontology-102035 .nr-v3__edit-note {
    max-width: none;
    text-align: left;
  }
  new-release--widgets--ontology-102035 .nr-ontology__workbench {
    display: grid;
  }
  new-release--widgets--ontology-102035 .nr-ontology__workbench > aside {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    border-right: 0;
    border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  }
  new-release--widgets--ontology-102035 .nr-v3__entity-panel > summary {
    align-items: flex-start;
  }
  new-release--widgets--ontology-102035 .nr-v3__entity-meta {
    max-width: 55%;
  }
  new-release--widgets--ontology-102035 .nr-ontology__graph-layout > aside {
    border-top: 1px solid var(--border-subtle, #e4e9f0);
    border-left: 0;
  }
  new-release--widgets--ontology-102035 .nr-ontology__graph,
  new-release--widgets--ontology-102035 .nr-ontology__graph-layout {
    min-height: 32rem;
  }
  new-release--widgets--ontology-102035 .nr-ontology__summary {
    overflow-x: auto;
  }
  new-release--widgets--ontology-102035 .nr-ontology__summary > span {
    min-width: 8rem;
  }
  new-release--widgets--ontology-102035 .nr-field__edit-grid,
  new-release--widgets--ontology-102035 .nr-transition__grid,
  new-release--widgets--ontology-102035 .nr-relationship__edit {
    grid-template-columns: 1fr;
  }
  new-release--widgets--ontology-102035 .nr-field__description,
  new-release--widgets--ontology-102035 .nr-transition__description,
  new-release--widgets--ontology-102035 .nr-relationship__edit > label:last-child {
    grid-column: auto;
  }
  new-release--widgets--ontology-102035 .nr-ontology__graph-alternative > div {
    grid-template-columns: 1fr;
  }
}
@media (prefers-reduced-motion: reduce) {
  new-release--widgets--ontology-102035 .nr-v3__entity-panel,
  new-release--widgets--ontology-102035 .nr-v3__entity-panel > summary,
  new-release--widgets--ontology-102035 .nr-v3__entity-panel > summary::before,
  new-release--widgets--ontology-102035 .nr-v3__entity-reveal {
    transition: none;
  }
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.view = 'text';
        this.selectedEntityId = '';
        this.entityDraft = null;
        this.indexDraft = null;
        this.issues = [];
        this.gateIssues = [];
        this.editMessage = '';
        this.newUniqueFields = [];
        this.newDetailName = '';
        this.newDetailType = 'string';
        this.newStateName = '';
        this.newStateReachedBy = 'actor';
        this.newTransitionId = '';
        this.v3Views = [];
        this.v3PlatformView = null;
        this.v3Loading = false;
        this.v3Error = '';
        this.entityDirty = false;
        this.indexDirty = false;
        this.graphCacheSignature = '';
        this.v3GraphCacheSignature = '';
        this.v3PlatformOntology = null;
        this.v3LoadToken = 0;
        this.v3ScrollToken = 0;
    }
    createRenderRoot() { return this; }
    updated(changed) {
        if (changed.has('data')) {
            if (this.v3Index()) {
                void this.loadV3();
                return;
            }
            const entities = this.entities();
            if (!entities.some(entity => entity.entityId === this.selectedEntityId)) {
                this.selectedEntityId = entities[0]?.entityId || '';
            }
        }
    }
    getDraft() {
        const entity = this.currentEntity();
        return entity ? structuredClone(entity) : null;
    }
    setIssues(issues) {
        this.issues = issues.filter(issue => String(issue.artifact).startsWith('ontology/'));
    }
    entities() {
        return this.data?.artifacts.entities
            .map(artifact => artifact.value)
            .filter((entity) => !!entity && !isOntologyV3Entity(entity)) || [];
    }
    v3Index() {
        const value = this.data?.artifacts.ontologyIndex.value;
        return isOntologyV3Index(value) ? value : null;
    }
    v3Entities() {
        return this.data?.artifacts.entities
            .map(artifact => artifact.value)
            .filter(isOntologyV3Entity) || [];
    }
    async loadV3() {
        const index = this.v3Index();
        const rules = this.data?.artifacts.rules.value;
        if (!index || !rules)
            return;
        const token = ++this.v3LoadToken;
        this.v3Loading = true;
        this.v3Error = '';
        try {
            const platformFile = ontologyPlatformFile(index.platformOntology);
            await mls.stor.server.loadProjectInfoIfNeeded(platformFile.project);
            const mdm = await readDefsJson(platformFile);
            if (!mdm)
                throw new Error(this.t('ontology.v3.platformMissing'));
            const views = this.v3Entities().map(entity => resolveModuleEntity(entity, index, mdm, rules));
            if (token !== this.v3LoadToken)
                return;
            this.v3PlatformOntology = mdm;
            this.v3Views = views;
            this.v3PlatformView = null;
            if (!views.some(view => view.entityId === this.selectedEntityId))
                this.selectedEntityId = views[0]?.entityId || '';
        }
        catch (error) {
            if (token === this.v3LoadToken)
                this.v3Error = error instanceof Error ? error.message : String(error);
        }
        finally {
            if (token === this.v3LoadToken)
                this.v3Loading = false;
        }
    }
    v3SelectedView() {
        if (this.v3PlatformView?.entityId === this.selectedEntityId)
            return this.v3PlatformView;
        return this.v3Views.find(view => view.entityId === this.selectedEntityId) || this.v3Views[0] || null;
    }
    selectV3Entity(entityId) {
        const moduleView = this.v3Views.find(view => view.entityId === entityId);
        if (moduleView) {
            this.v3PlatformView = null;
            this.selectedEntityId = entityId;
            return;
        }
        const index = this.v3Index();
        if (!index || !this.v3PlatformOntology || !(entityId in this.v3PlatformOntology.subtypes))
            return;
        this.v3PlatformView = resolvePlatformEntity(this.v3PlatformOntology, entityId, index.moduleNamespace.key);
        this.selectedEntityId = entityId;
    }
    async selectV3EntityAndScroll(entityId, summary) {
        const token = ++this.v3ScrollToken;
        const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        this.selectV3Entity(entityId);
        await this.updateComplete;
        if (!reduceMotion)
            await new Promise(resolve => window.setTimeout(resolve, 800));
        if (token !== this.v3ScrollToken || !summary.isConnected)
            return;
        summary.scrollIntoView({
            behavior: reduceMotion ? 'auto' : 'smooth',
            block: 'start',
            inline: 'nearest',
        });
    }
    currentIndex() {
        if (this.mode === 'edit' && this.indexDraft)
            return this.indexDraft;
        const value = this.data?.artifacts.ontologyIndex.value;
        return value && !isOntologyV3Index(value) ? value : null;
    }
    currentEntity() {
        if (this.mode === 'edit' && this.entityDraft?.entityId === this.selectedEntityId)
            return this.entityDraft;
        return this.entities().find(entity => entity.entityId === this.selectedEntityId) || null;
    }
    currentEntities() {
        return this.entities().map(entity => this.mode === 'edit' && this.entityDraft?.entityId === entity.entityId ? this.entityDraft : entity);
    }
    selectEntity(entityId) {
        if (entityId === this.selectedEntityId)
            return;
        this.cancelEdit();
        this.selectedEntityId = entityId;
    }
    beginEdit() {
        const entity = this.currentEntity();
        const index = this.currentIndex();
        if (!entity || !index)
            return;
        this.entityDraft = structuredClone(entity);
        this.indexDraft = structuredClone(index);
        this.mode = 'edit';
        this.dirty = false;
        this.entityDirty = false;
        this.indexDirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    cancelEdit() {
        this.entityDraft = null;
        this.indexDraft = null;
        this.mode = 'view';
        this.dirty = false;
        this.entityDirty = false;
        this.indexDirty = false;
        this.gateIssues = [];
        this.editMessage = '';
        this.newUniqueFields = [];
        this.newDetailName = '';
        this.newStateName = '';
        this.newTransitionId = '';
    }
    updateEntity(next) {
        this.entityDraft = next;
        this.entityDirty = true;
        this.dirty = true;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateIndex(next) {
        this.indexDraft = next;
        this.indexDirty = true;
        this.dirty = true;
        this.gateIssues = [];
        this.editMessage = '';
    }
    async saveEdit() {
        if (!this.entityDraft || !this.indexDraft || !this.dirty)
            return;
        try {
            const gate = await import('/_102035_/l2/agentNewSolution5/steps/ontology30/gate.js');
            const allEntities = this.currentEntities();
            const plan = {
                moduleName: this.moduleName,
                businessDomain: this.indexDraft.businessDomain,
                entities: allEntities.map(entity => ({
                    entityId: entity.entityId,
                    title: entity.title,
                    description: entity.description,
                    kind: entity.kind,
                    party: entity.party,
                    ...(entity.mdmSubtype ? { mdmSubtype: entity.mdmSubtype } : {}),
                    displayField: entity.displayField,
                    ...(entity.mutability ? { mutability: entity.mutability } : {}),
                    ...(entity.writer ? { writer: entity.writer } : {}),
                    storage: entity.storage,
                })),
                relationships: this.indexDraft.relationships.map(relationship => ({
                    relationshipId: relationship.relationshipId,
                    fromEntity: relationship.fromEntity,
                    toEntity: relationship.toEntity,
                    type: relationship.type,
                    required: relationship.required,
                    description: relationship.description,
                    persistence: relationship.persistence,
                })),
            };
            const detail = {
                entityId: this.entityDraft.entityId,
                fields: this.entityDraft.fields,
                ...(this.entityDraft.uniqueKeys ? { uniqueKeys: this.entityDraft.uniqueKeys } : {}),
                ...(this.entityDraft.details ? { details: this.entityDraft.details } : {}),
                lifecycleStates: this.entityDraft.lifecycleStates,
                transitions: this.entityDraft.transitions,
            };
            const result = gate.validateNs5OntologyEntity(plan, detail, {
                moduleName: this.moduleName,
                actors: this.data?.artifacts.access.value?.actors || this.data?.pipeline?.steps.module10?.actors || [],
                journeys: this.data?.artifacts.journeys
                    .map(artifact => artifact.value)
                    .filter((journey) => !!journey),
                writerPlan: plan,
            });
            this.gateIssues = result.issues.map(issue => ({ severity: issue.severity, message: issue.message }));
            if (!result.ok) {
                this.editMessage = this.t('ontology.gateBlocked');
                return;
            }
        }
        catch (error) {
            this.editMessage = this.t('ontology.gateUnavailable', { message: error instanceof Error ? error.message : String(error) });
            return;
        }
        if (this.entityDirty) {
            announceNewReleaseChange(this, {
                path: ontologyEntityPath(this.entityDraft.entityId),
                jsonPath: '$',
                value: structuredClone(this.entityDraft),
            });
        }
        if (this.indexDirty) {
            announceNewReleaseChange(this, {
                path: 'ontology/index.defs.ts',
                jsonPath: '$',
                value: structuredClone(this.indexDraft),
            });
        }
        this.cancelEdit();
    }
    setField(fieldId, patch) {
        if (!this.entityDraft)
            return;
        this.updateEntity(updateOntologyField(this.entityDraft, fieldId, patch));
    }
    setConstraint(field, key, value) {
        const constraints = { ...(field.constraints || {}) };
        if (value === '')
            delete constraints[key];
        else
            constraints[key] = Number(value);
        this.setField(field.fieldId, { constraints });
    }
    setEnum(field, index, key, value) {
        const values = [...(field.enum || [])];
        values[index] = { ...values[index], [key]: value };
        this.setField(field.fieldId, { enum: values });
    }
    addEnum(field) {
        const values = [...(field.enum || [])];
        let index = values.length + 1;
        while (values.some(value => value.value === `option${index}`))
            index += 1;
        values.push({ value: `option${index}`, title: this.t('ontology.enumNewTitle') });
        this.setField(field.fieldId, { enum: values });
    }
    removeEnum(field, index) {
        const values = (field.enum || []).filter((_, itemIndex) => itemIndex !== index);
        this.setField(field.fieldId, { enum: values.length ? values : undefined });
    }
    addUniqueKey() {
        if (!this.entityDraft || !this.newUniqueFields.length)
            return;
        const key = [...this.newUniqueFields];
        const duplicate = (this.entityDraft.uniqueKeys || []).some(current => current.join('|') === key.join('|'));
        if (duplicate) {
            this.editMessage = this.t('ontology.uniqueDuplicate');
            return;
        }
        this.updateEntity({ ...this.entityDraft, uniqueKeys: [...(this.entityDraft.uniqueKeys || []), key] });
        this.newUniqueFields = [];
    }
    removeUniqueKey(index) {
        if (!this.entityDraft)
            return;
        const uniqueKeys = (this.entityDraft.uniqueKeys || []).filter((_, itemIndex) => itemIndex !== index);
        const next = { ...this.entityDraft, uniqueKeys };
        if (!uniqueKeys.length)
            delete next.uniqueKeys;
        this.updateEntity(next);
    }
    addDetail() {
        if (!this.entityDraft)
            return;
        const name = this.newDetailName.trim();
        if (!ONTOLOGY_DETAIL_NAME.test(name) || this.entityDraft.details?.[name]) {
            this.editMessage = this.t('ontology.memberInvalid');
            return;
        }
        this.updateEntity({
            ...this.entityDraft,
            details: {
                ...(this.entityDraft.details || {}),
                [name]: { type: this.newDetailType, description: this.t('ontology.detailNewDescription') },
            },
        });
        this.newDetailName = '';
    }
    updateDetail(name, patch) {
        if (!this.entityDraft?.details?.[name])
            return;
        this.updateEntity({
            ...this.entityDraft,
            details: { ...this.entityDraft.details, [name]: { ...this.entityDraft.details[name], ...patch } },
        });
    }
    removeDetail(name) {
        if (!this.entityDraft?.details)
            return;
        const details = { ...this.entityDraft.details };
        delete details[name];
        const next = { ...this.entityDraft, details };
        if (!Object.keys(details).length)
            delete next.details;
        this.updateEntity(next);
    }
    addState() {
        if (!this.entityDraft)
            return;
        const state = this.newStateName.trim();
        if (!ONTOLOGY_ENUM_VALUE.test(state) || this.entityDraft.lifecycleStates.some(item => item.state === state)) {
            this.editMessage = this.t('ontology.memberInvalid');
            return;
        }
        this.updateEntity({
            ...this.entityDraft,
            lifecycleStates: [...this.entityDraft.lifecycleStates, { state, reachedBy: this.newStateReachedBy }],
        });
        this.newStateName = '';
    }
    removeState(state) {
        if (this.entityDraft)
            this.updateEntity(removeOntologyState(this.entityDraft, state));
    }
    addTransition() {
        if (!this.entityDraft)
            return;
        const transitionId = this.newTransitionId.trim();
        const states = this.entityDraft.lifecycleStates.map(item => item.state);
        if (!ONTOLOGY_ENUM_VALUE.test(transitionId) || !states.length || this.entityDraft.transitions.some(item => item.transitionId === transitionId)) {
            this.editMessage = this.t('ontology.memberInvalid');
            return;
        }
        this.updateEntity({
            ...this.entityDraft,
            transitions: [...this.entityDraft.transitions, {
                    transitionId,
                    from: [states[0]],
                    to: states[Math.min(1, states.length - 1)],
                    by: 'system',
                    description: this.t('ontology.transitionNewDescription'),
                }],
        });
        this.newTransitionId = '';
    }
    updateTransition(index, patch) {
        if (!this.entityDraft)
            return;
        this.updateEntity({
            ...this.entityDraft,
            transitions: this.entityDraft.transitions.map((transition, itemIndex) => itemIndex === index ? { ...transition, ...patch } : transition),
        });
    }
    relationship(relationshipId, patch) {
        if (this.indexDraft)
            this.updateIndex(updateOntologyRelationship(this.indexDraft, relationshipId, patch));
    }
    multiValues(event) {
        return [...event.currentTarget.selectedOptions].map(option => option.value);
    }
    transitionBy(event) {
        const values = this.multiValues(event);
        if (values.includes('system'))
            return 'system';
        if (values.includes('time'))
            return 'time';
        return values;
    }
    fieldConstraints(field) {
        const numeric = field.type === 'number' || field.type === 'integer' || field.type === 'money';
        const precision = field.type === 'number' || field.type === 'money';
        const length = field.type === 'string' || field.type === 'text';
        if (!numeric && !length)
            return nothing;
        return html `<div class="nr-ontology__constraints">
      ${numeric ? html `
        <label><span>${this.t('ontology.constraint.min')}</span><input type="number" .value=${String(field.constraints?.min ?? '')} @input=${(event) => this.setConstraint(field, 'min', event.currentTarget.value)}></label>
        <label><span>${this.t('ontology.constraint.max')}</span><input type="number" .value=${String(field.constraints?.max ?? '')} @input=${(event) => this.setConstraint(field, 'max', event.currentTarget.value)}></label>
      ` : nothing}
      ${precision ? html `<label><span>${this.t('ontology.constraint.precision')}</span><input type="number" min="0" .value=${String(field.constraints?.precision ?? '')} @input=${(event) => this.setConstraint(field, 'precision', event.currentTarget.value)}></label>` : nothing}
      ${length ? html `<label><span>${this.t('ontology.constraint.maxLength')}</span><input type="number" min="1" .value=${String(field.constraints?.maxLength ?? '')} @input=${(event) => this.setConstraint(field, 'maxLength', event.currentTarget.value)}></label>` : nothing}
    </div>`;
    }
    renderFields(entity) {
        return html `
      <section class="nr-ontology__section">
        <header><div><h3>${this.t('ontology.namespaceFields')}</h3><p>${this.t('ontology.fieldsDescription')}</p></div><span>${this.t('ontology.count', { count: entity.fields.length })}</span></header>
        <div class="nr-ontology__fields">
          ${entity.fields.map(field => html `
            <article class="nr-field">
              <header><code>${field.fieldId}</code><div><span class="nr-chip">${field.type}</span><span class=${field.required ? 'nr-chip is-required' : 'nr-chip'}>${field.required ? this.t('ontology.required') : this.t('ontology.optional')}</span>${field.unique ? html `<span class="nr-chip is-unique">${this.t('ontology.unique')}</span>` : nothing}</div></header>
              ${this.mode === 'edit' ? html `
                <div class="nr-field__edit-grid">
                  <label><span>${this.t('ontology.title')}</span><input .value=${field.title} @input=${(event) => this.setField(field.fieldId, { title: event.currentTarget.value })}></label>
                  <label><span>${this.t('ontology.type')}</span><select .value=${field.type} @change=${(event) => this.setField(field.fieldId, { type: event.currentTarget.value })}>${ONTOLOGY_FIELD_TYPES.map(type => html `<option value=${type} ?selected=${field.type === type}>${type}</option>`)}</select></label>
                  <label class="nr-field__description"><span>${this.t('ontology.description')}</span><textarea .value=${field.description} @input=${(event) => this.setField(field.fieldId, { description: event.currentTarget.value })}></textarea></label>
                  <label class="nr-check"><input type="checkbox" .checked=${field.required} @change=${(event) => this.setField(field.fieldId, { required: event.currentTarget.checked })}><span>${this.t('ontology.required')}</span></label>
                  <label class="nr-check"><input type="checkbox" .checked=${!!field.unique} @change=${(event) => this.setField(field.fieldId, { unique: event.currentTarget.checked })}><span>${this.t('ontology.unique')}</span></label>
                </div>
                ${this.fieldConstraints(field)}
                ${field.type === 'string' ? html `
                  <div class="nr-field__enum">
                    <strong>${this.t('ontology.enum')}</strong>
                    ${(field.enum || []).map((option, index) => html `<div><input aria-label=${this.t('ontology.enumValue')} class=${ONTOLOGY_ENUM_VALUE.test(option.value) ? '' : 'is-invalid'} .value=${option.value} @input=${(event) => this.setEnum(field, index, 'value', event.currentTarget.value)}><input aria-label=${this.t('ontology.enumTitle')} .value=${option.title} @input=${(event) => this.setEnum(field, index, 'title', event.currentTarget.value)}><button type="button" @click=${() => this.removeEnum(field, index)} aria-label=${this.t('ontology.removeEnum')}>${this.t('ontology.removeSymbol')}</button></div>`)}
                    <button class="nr-text-button" type="button" @click=${() => this.addEnum(field)}>${this.t('ontology.addEnum')}</button>
                  </div>
                ` : nothing}
              ` : html `
                <h4>${field.title}</h4><p>${field.description}</p>
                ${field.constraints && Object.keys(field.constraints).length ? html `<dl class="nr-field__constraints-view">${Object.entries(field.constraints).map(([key, value]) => html `<div><dt>${this.t(`ontology.constraint.${key}`)}</dt><dd>${value}</dd></div>`)}</dl>` : nothing}
                ${field.enum?.length ? html `<div class="nr-field__enum-view">${field.enum.map(option => html `<span><strong>${option.title}</strong><code>${option.value}</code></span>`)}</div>` : nothing}
              `}
            </article>
          `)}
        </div>
      </section>
    `;
    }
    renderBaseFields(entity) {
        if (entity.kind !== 'mdm')
            return nothing;
        const fields = entity.fieldsBase || [];
        return html `
      <section class="nr-ontology__section nr-ontology__base-fields">
        <header><div><h3>${this.t('ontology.baseFields')}</h3><p>${this.t('ontology.baseFieldsDescription', { subtype: entity.mdmSubtype || '' })}</p></div><span>${this.t('ontology.count', { count: fields.length })}</span></header>
        ${this.mode === 'edit' ? html `<p class="nr-ontology__readonly-note">${this.t('ontology.baseFieldsReadOnly')}</p>` : nothing}
        ${fields.length ? html `<div class="nr-ontology__fields">${fields.map(field => html `
          <article class="nr-field is-platform">
            <header><code>${field.fieldId}</code><div><span class="nr-chip is-platform">${this.t('ontology.baseFieldOrigin')}</span><span class="nr-chip">${field.type}</span><span class=${field.required ? 'nr-chip is-required' : 'nr-chip'}>${field.required ? this.t('ontology.required') : this.t('ontology.optional')}</span></div></header>
            <h4>${field.title}</h4><p>${field.description}</p>
            ${field.constraints && Object.keys(field.constraints).length ? html `<dl class="nr-field__constraints-view">${Object.entries(field.constraints).map(([key, value]) => html `<div><dt>${this.t(`ontology.constraint.${key}`)}</dt><dd>${value}</dd></div>`)}</dl>` : nothing}
            ${field.enum?.length ? html `<div class="nr-field__enum-view">${field.enum.map(option => html `<span><strong>${option.title}</strong><code>${option.value}</code></span>`)}</div>` : nothing}
          </article>
        `)}</div>` : html `<p class="nr-ontology__empty-inline">${this.t('ontology.baseFieldsEmptyLegacy')}</p>`}
      </section>
    `;
    }
    renderUniqueAndDetails(entity) {
        return html `
      <div class="nr-ontology__two-columns">
        <section class="nr-ontology__section">
          <header><div><h3>${this.t('ontology.uniqueKeys')}</h3><p>${this.t('ontology.uniqueKeysDescription')}</p></div></header>
          <div class="nr-ontology__key-list">${(entity.uniqueKeys || []).map((key, index) => html `<span>${key.map(field => html `<code>${field}</code>`)}${this.mode === 'edit' ? html `<button type="button" aria-label=${this.t('ontology.removeUnique')} @click=${() => this.removeUniqueKey(index)}>${this.t('ontology.removeSymbol')}</button>` : nothing}</span>`)}</div>
          ${!(entity.uniqueKeys || []).length ? html `<p class="nr-ontology__empty-inline">${this.t('ontology.uniqueEmpty')}</p>` : nothing}
          ${this.mode === 'edit' ? html `<div class="nr-ontology__adder"><select multiple @change=${(event) => { this.newUniqueFields = this.multiValues(event); }}>${entity.fields.map(field => html `<option value=${field.fieldId}>${field.title}</option>`)}</select><button type="button" @click=${this.addUniqueKey}>${this.t('ontology.addUnique')}</button></div>` : nothing}
        </section>
        <section class="nr-ontology__section">
          <header><div><h3>${this.t('ontology.details')}</h3><p>${this.t('ontology.detailsDescription')}</p></div></header>
          <div class="nr-ontology__detail-list">${Object.entries(entity.details || {}).map(([name, detail]) => html `<article><code>${name}</code>${this.mode === 'edit' ? html `<select .value=${detail.type} @change=${(event) => this.updateDetail(name, { type: event.currentTarget.value })}>${ONTOLOGY_FIELD_TYPES.map(type => html `<option value=${type} ?selected=${detail.type === type}>${type}</option>`)}</select><textarea .value=${detail.description} @input=${(event) => this.updateDetail(name, { description: event.currentTarget.value })}></textarea><button type="button" @click=${() => this.removeDetail(name)}>${this.t('ontology.remove')}</button>` : html `<span>${detail.type}</span><p>${detail.description}</p>`}</article>`)}</div>
          ${!Object.keys(entity.details || {}).length ? html `<p class="nr-ontology__empty-inline">${this.t('ontology.detailsEmpty')}</p>` : nothing}
          ${this.mode === 'edit' ? html `<div class="nr-ontology__adder nr-ontology__adder--detail"><input placeholder=${this.t('ontology.detailName')} .value=${this.newDetailName} @input=${(event) => { this.newDetailName = event.currentTarget.value; }}><select .value=${this.newDetailType} @change=${(event) => { this.newDetailType = event.currentTarget.value; }}>${ONTOLOGY_FIELD_TYPES.map(type => html `<option value=${type}>${type}</option>`)}</select><button type="button" @click=${this.addDetail}>${this.t('ontology.addDetail')}</button></div>` : nothing}
        </section>
      </div>
    `;
    }
    renderLifecycle(entity) {
        const states = entity.lifecycleStates.map(item => item.state);
        const actors = this.data?.artifacts.access.value?.actors || this.data?.pipeline?.steps.module10?.actors || [];
        const rules = this.data?.artifacts.rules.value?.rules || [];
        return html `
      <section class="nr-ontology__section nr-ontology__lifecycle">
        <header><div><h3>${this.t('ontology.lifecycle')}</h3><p>${this.t('ontology.lifecycleDescription')}</p></div></header>
        ${states.length ? html `<div class="nr-lifecycle__rail">${entity.lifecycleStates.map((item, index) => html `<span><strong>${item.state}</strong><small>${this.t(`ontology.reachedBy.${item.reachedBy}`)}</small>${this.mode === 'edit' ? html `<select .value=${item.reachedBy} @change=${(event) => this.updateEntity({ ...entity, lifecycleStates: entity.lifecycleStates.map((state, stateIndex) => stateIndex === index ? { ...state, reachedBy: event.currentTarget.value } : state) })}><option value="actor" ?selected=${item.reachedBy === 'actor'}>${this.t('ontology.reachedBy.actor')}</option><option value="command" ?selected=${item.reachedBy === 'command'}>${this.t('ontology.reachedBy.command')}</option><option value="time" ?selected=${item.reachedBy === 'time'}>${this.t('ontology.reachedBy.time')}</option></select><button type="button" @click=${() => this.removeState(item.state)} aria-label=${this.t('ontology.removeState')}>${this.t('ontology.removeSymbol')}</button>` : nothing}</span>`)}</div>` : html `<p class="nr-ontology__empty-inline">${this.t('ontology.lifecycleEmpty')}</p>`}
        ${this.mode === 'edit' ? html `<div class="nr-ontology__adder"><input placeholder=${this.t('ontology.stateName')} .value=${this.newStateName} @input=${(event) => { this.newStateName = event.currentTarget.value; }}><select .value=${this.newStateReachedBy} @change=${(event) => { this.newStateReachedBy = event.currentTarget.value; }}><option value="actor">${this.t('ontology.reachedBy.actor')}</option><option value="command">${this.t('ontology.reachedBy.command')}</option><option value="time">${this.t('ontology.reachedBy.time')}</option></select><button type="button" @click=${this.addState}>${this.t('ontology.addState')}</button></div>` : nothing}
        <div class="nr-lifecycle__transitions">${entity.transitions.map((transition, index) => html `
          <article><header><code>${transition.transitionId}</code><span>${transition.from.join(', ')} → ${transition.to}</span></header>
          ${this.mode === 'edit' ? html `
            <div class="nr-transition__grid">
              <label><span>${this.t('ontology.from')}</span><select multiple @change=${(event) => this.updateTransition(index, { from: this.multiValues(event) })}>${states.map(state => html `<option value=${state} ?selected=${transition.from.includes(state)}>${state}</option>`)}</select></label>
              <label><span>${this.t('ontology.to')}</span><select .value=${transition.to} @change=${(event) => this.updateTransition(index, { to: event.currentTarget.value })}>${states.map(state => html `<option value=${state} ?selected=${transition.to === state}>${state}</option>`)}</select></label>
              <label><span>${this.t('ontology.by')}</span><select multiple @change=${(event) => this.updateTransition(index, { by: this.transitionBy(event) })}><option value="system" ?selected=${transition.by === 'system'}>${this.t('ontology.by.system')}</option><option value="time" ?selected=${transition.by === 'time'}>${this.t('ontology.by.time')}</option>${actors.map(actor => html `<option value=${actor.actorId} ?selected=${Array.isArray(transition.by) && transition.by.includes(actor.actorId)}>${actor.title}</option>`)}</select></label>
              <label><span>${this.t('ontology.ruleRefs')}</span><select multiple @change=${(event) => { const ruleRefs = this.multiValues(event); this.updateTransition(index, { ruleRefs: ruleRefs.length ? ruleRefs : undefined }); }}>${rules.map(rule => html `<option value=${rule.ruleId} ?selected=${transition.ruleRefs?.includes(rule.ruleId) || false}>${rule.ruleId}</option>`)}</select></label>
              <label class="nr-transition__description"><span>${this.t('ontology.description')}</span><textarea .value=${transition.description} @input=${(event) => this.updateTransition(index, { description: event.currentTarget.value })}></textarea></label>
              <button type="button" @click=${() => this.updateEntity({ ...entity, transitions: entity.transitions.filter((_, itemIndex) => itemIndex !== index) })}>${this.t('ontology.remove')}</button>
            </div>
          ` : html `<p>${transition.description}</p><footer><span>${this.t('ontology.by')}: <strong>${Array.isArray(transition.by) ? transition.by.join(', ') : this.t(`ontology.by.${transition.by}`)}</strong></span>${transition.ruleRefs?.length ? html `<span>${this.t('ontology.ruleRefs')}: ${transition.ruleRefs.map(rule => html `<code>${rule}</code>`)}</span>` : nothing}</footer>`}
          </article>`)}
        </div>
        ${this.mode === 'edit' && states.length ? html `<div class="nr-ontology__adder"><input placeholder=${this.t('ontology.transitionName')} .value=${this.newTransitionId} @input=${(event) => { this.newTransitionId = event.currentTarget.value; }}><button type="button" @click=${this.addTransition}>${this.t('ontology.addTransition')}</button></div>` : nothing}
      </section>
    `;
    }
    renderRelationships(entity) {
        const relationships = (this.currentIndex()?.relationships || []).filter(item => item.fromEntity === entity.entityId || item.toEntity === entity.entityId);
        return html `
      <section class="nr-ontology__section">
        <header><div><h3>${this.t('ontology.relationships')}</h3><p>${this.t('ontology.relationshipsDescription')}</p></div><span>${this.t('ontology.count', { count: relationships.length })}</span></header>
        <div class="nr-ontology__relationships">${relationships.map(relationship => html `
          <article><header><strong>${relationship.fromEntity}<i>→</i>${relationship.toEntity}</strong><span>${ontologyCardinality(relationship.type)}</span></header>
            <code>${relationship.relationshipId} · ${relationship.persistence.mode}</code>
            ${this.mode === 'edit' ? html `<div class="nr-relationship__edit"><label><span>${this.t('ontology.relationshipType')}</span><select .value=${relationship.type} @change=${(event) => this.relationship(relationship.relationshipId, { type: event.currentTarget.value })}><option value="oneToOne" ?selected=${relationship.type === 'oneToOne'}>${this.t('ontology.cardinality.oneToOne')}</option><option value="oneToMany" ?selected=${relationship.type === 'oneToMany'}>${this.t('ontology.cardinality.oneToMany')}</option><option value="manyToOne" ?selected=${relationship.type === 'manyToOne'}>${this.t('ontology.cardinality.manyToOne')}</option><option value="manyToMany" ?selected=${relationship.type === 'manyToMany'}>${this.t('ontology.cardinality.manyToMany')}</option></select></label><label class="nr-check"><input type="checkbox" .checked=${relationship.required} @change=${(event) => this.relationship(relationship.relationshipId, { required: event.currentTarget.checked })}><span>${this.t('ontology.required')}</span></label><label><span>${this.t('ontology.description')}</span><textarea .value=${relationship.description} @input=${(event) => this.relationship(relationship.relationshipId, { description: event.currentTarget.value })}></textarea></label></div>` : html `<p>${relationship.description}</p><span class=${relationship.required ? 'is-required' : ''}>${relationship.required ? this.t('ontology.required') : this.t('ontology.optional')}</span>`}
          </article>`)}
        </div>
        ${!relationships.length ? html `<p class="nr-ontology__empty-inline">${this.t('ontology.relationshipsEmpty')}</p>` : nothing}
      </section>
    `;
    }
    renderIssues(entity) {
        const source = this.issues.length ? this.issues : this.data?.validation.issues || [];
        const issues = [...ontologyEntityIssues(source, entity.entityId), ...this.gateIssues.map(issue => ({ ...issue, code: '', path: '', artifact: ontologyEntityPath(entity.entityId), source: 'gate' }))];
        if (!issues.length && !this.editMessage)
            return nothing;
        return html `<section class="nr-ontology__issues" role="alert"><strong>${this.t('ontology.issues')}</strong>${this.editMessage ? html `<p>${this.editMessage}</p>` : nothing}${issues.map(issue => html `<p class=${issue.severity}><span>${this.t(`ontology.issue.${issue.severity}`)}</span>${issue.message}</p>`)}</section>`;
    }
    renderText(entity) {
        const counts = ontologyFieldCounts(entity);
        return html `
      <div class="nr-ontology__workbench">
        <aside>${this.currentEntities().map(item => html `<button type="button" class=${item.entityId === entity.entityId ? 'is-active' : ''} @click=${() => this.selectEntity(item.entityId)}><strong>${item.title}</strong><code>${item.entityId}</code><span><i>${this.t(`ontology.kind.${item.kind}`)}</i><i>${this.t(`ontology.party.${item.party}`)}</i>${item.mdmSubtype ? html `<i>${item.mdmSubtype}</i>` : nothing}${item.writer ? html `<i>${this.t(`ontology.writer.${item.writer}`)}</i>` : nothing}</span></button>`)}</aside>
        <main>
          <section class="nr-ontology__identity">
            <div><span>${this.t('ontology.entity')}</span>${this.mode === 'edit' ? html `<input .value=${entity.title} @input=${(event) => this.updateEntity({ ...entity, title: event.currentTarget.value })}>` : html `<h2>${entity.title}</h2>`}<code>${entity.entityId}</code></div>
            <div class="nr-ontology__badges"><span>${this.t(`ontology.kind.${entity.kind}`)}</span><span>${this.t(`ontology.party.${entity.party}`)}</span>${entity.mdmSubtype ? html `<span>${entity.mdmSubtype}</span>` : nothing}<span>${entity.writer ? this.t(`ontology.writer.${entity.writer}`) : entity.mutability ? entity.mutability : this.t('ontology.writer.journey')}</span></div>
            ${this.mode === 'edit' ? html `<label class="nr-ontology__description-edit"><span>${this.t('ontology.description')}</span><textarea .value=${entity.description} @input=${(event) => this.updateEntity({ ...entity, description: event.currentTarget.value })}></textarea></label>` : html `<p>${entity.description}</p>`}
            <dl><div><dt>${this.t('ontology.storage')}</dt><dd>${entity.storage.target} · ${entity.storage.scope}</dd></div><div><dt>${this.t('ontology.idField')}</dt><dd><code>${entity.storage.idField}</code></dd></div><div><dt>${this.t('ontology.displayField')}</dt><dd>${this.mode === 'edit' ? html `<select .value=${entity.displayField} @change=${(event) => this.updateEntity({ ...entity, displayField: event.currentTarget.value })}>${ontologyResolvableFields(entity).map(field => html `<option value=${field.fieldId} ?selected=${entity.displayField === field.fieldId}>${field.title}</option>`)}</select>` : html `<code>${entity.displayField}</code>`}</dd></div><div><dt>${this.t('ontology.writer')}</dt><dd>${this.mode === 'edit' ? html `<select .value=${entity.writer || 'journey'} @change=${(event) => { const writer = event.currentTarget.value; const next = { ...entity, writer }; if (writer === 'journey')
            delete next.writer; this.updateEntity(next); }}><option value="journey" ?selected=${!entity.writer || entity.writer === 'journey'}>${this.t('ontology.writer.journey')}</option><option value="crud" ?selected=${entity.writer === 'crud'}>${this.t('ontology.writer.crud')}</option><option value="inbound" ?selected=${entity.writer === 'inbound'}>${this.t('ontology.writer.inbound')}</option></select>` : this.t(`ontology.writer.${entity.writer || 'journey'}`)}</dd></div></dl>
            <p class="nr-ontology__field-breakdown">${this.t('ontology.fieldCountBreakdown', { namespace: counts.namespace, base: counts.base })}</p>
          </section>
          ${this.renderIssues(entity)}
          ${this.renderFields(entity)}
          ${this.renderBaseFields(entity)}
          ${this.renderUniqueAndDetails(entity)}
          ${this.renderLifecycle(entity)}
          ${this.renderRelationships(entity)}
        </main>
      </div>
    `;
    }
    graphOption() {
        const style = getComputedStyle(this);
        const colors = Array.from({ length: 6 }, (_, index) => style.getPropertyValue(`--chart-series-${index + 1}`).trim() || style.getPropertyValue(`--ds-chart-series-${index + 1}`).trim());
        const text = style.getPropertyValue('--text-default').trim() || '#2f3a48';
        const muted = style.getPropertyValue('--text-muted').trim() || '#5d6b7e';
        const surface = style.getPropertyValue('--surface-bg').trim() || '#fff';
        const index = this.currentIndex();
        const entities = this.currentEntities();
        const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches || false;
        const signature = JSON.stringify({ index, entities, colors, text, muted, surface, reduceMotion, language: this.t('ontology.title') });
        if (signature === this.graphCacheSignature && this.graphCache)
            return this.graphCache;
        const graph = buildOntologyGraph(index, entities, colors);
        const nodeLabel = (node) => {
            const fields = node.namespaceFields.map(field => `{${field === node.displayField ? 'fieldDisplay' : 'field'}|${field}}`);
            const base = node.baseFields.map(field => `{${field === node.displayField ? 'platformDisplay' : 'platform'}|${field}}`);
            return [`{title|${node.title}}`, `{id|${node.id}}`, ...fields, ...base].join('\n');
        };
        this.graphCacheSignature = signature;
        this.graphCache = {
            animation: !reduceMotion,
            animationDurationUpdate: reduceMotion ? 0 : 450,
            aria: { enabled: true, decal: { show: true }, description: this.t('ontology.graphAria') },
            color: colors,
            tooltip: {
                trigger: 'item',
                formatter: (params) => params.dataType === 'edge'
                    ? `${params.data?.name || ''} ${params.value || ''}`
                    : `<strong>${params.data?.title || params.data?.name || ''}</strong><br>${params.data?.value || ''}`,
            },
            legend: [{ data: graph.categories.map(category => ({ name: this.t(`ontology.kind.${category.name}`), icon: 'circle' })), textStyle: { color: muted } }],
            toolbox: {
                right: 12,
                feature: {
                    restore: { title: this.t('ontology.graphReset') },
                    saveAsImage: { title: this.t('ontology.graphPng'), name: `${this.moduleName}-ontology`, pixelRatio: 2 },
                },
            },
            series: [{
                    type: 'graph',
                    layout: 'force',
                    roam: true,
                    draggable: true,
                    data: graph.nodes.map(node => ({ ...node, category: node.category, label: { formatter: nodeLabel(node) } })),
                    links: graph.links.map(link => ({ ...link, label: { formatter: link.value } })),
                    categories: graph.categories.map(category => ({ ...category, name: this.t(`ontology.kind.${category.name}`) })),
                    force: { repulsion: 310, edgeLength: [105, 180], gravity: .08 },
                    edgeSymbol: ['none', 'arrow'],
                    edgeSymbolSize: 9,
                    label: {
                        show: true,
                        color: text,
                        rich: {
                            title: { fontSize: 12, fontWeight: 700, lineHeight: 18 },
                            id: { fontSize: 10, color: muted, lineHeight: 14 },
                            field: { fontSize: 9, color: muted, lineHeight: 14, padding: [0, 3] },
                            platform: { fontSize: 9, color: colors[3] || muted, lineHeight: 14, padding: [0, 3], backgroundColor: surface, borderRadius: 2 },
                            fieldDisplay: { fontSize: 9, fontWeight: 700, color: text, lineHeight: 15, padding: [1, 4], borderColor: colors[0] || text, borderWidth: 1, borderRadius: 3 },
                            platformDisplay: { fontSize: 9, fontWeight: 700, color: colors[3] || text, lineHeight: 15, padding: [1, 4], backgroundColor: surface, borderColor: colors[3] || text, borderWidth: 1, borderRadius: 3 },
                        },
                    },
                    edgeLabel: { show: true, color: muted, fontSize: 10, backgroundColor: surface, padding: [2, 4], borderRadius: 3 },
                    lineStyle: { curveness: .12 },
                    emphasis: { focus: 'adjacency', lineStyle: { width: 3 } },
                }],
        };
        return this.graphCache;
    }
    renderGraph(entity) {
        const relationships = this.currentIndex()?.relationships || [];
        const related = relationships.filter(item => item.fromEntity === entity.entityId || item.toEntity === entity.entityId).length;
        const counts = ontologyFieldCounts(entity);
        const titleOf = (entityId) => this.currentEntities().find(item => item.entityId === entityId)?.title || entityId;
        return html `<section class="nr-ontology__graph-view"><div class="nr-ontology__graph-layout"><div class="nr-ontology__graph" role="img" aria-label=${this.t('ontology.graphAria')} ${chart(this.graphOption(), { click: (params) => { const node = params; if (node.dataType === 'node' && node.data?.id)
                this.selectEntity(node.data.id); } })}></div><aside><span>${this.t('ontology.selected')}</span><h2>${entity.title}</h2><code>${entity.entityId}</code><p>${entity.description}</p><dl><div title=${this.t('ontology.fieldCountBreakdown', { namespace: counts.namespace, base: counts.base })}><dt>${this.t('ontology.fields')}</dt><dd>${counts.total}</dd></div><div><dt>${this.t('ontology.relationships')}</dt><dd>${related}</dd></div><div><dt>${this.t('ontology.lifecycle')}</dt><dd>${entity.lifecycleStates.length}</dd></div></dl><p class="nr-ontology__graph-legend"><span></span>${this.t('ontology.baseFieldOrigin')} · <strong>${this.t('ontology.displayField')}</strong></p><button type="button" @click=${() => { this.view = 'text'; }}>${this.t('ontology.openDetails')}</button></aside></div><details class="nr-ontology__graph-alternative"><summary>${this.t('ontology.graphAlternative')}</summary><div><section><h3>${this.t('ontology.entities')}</h3><ul>${this.currentEntities().map(item => html `<li><button type="button" @click=${() => this.selectEntity(item.entityId)}><strong>${item.title}</strong><code>${item.entityId}</code></button></li>`)}</ul></section><section><h3>${this.t('ontology.relationships')}</h3>${relationships.length ? html `<ul>${relationships.map(item => html `<li><strong>${titleOf(item.fromEntity)}</strong><span>${ontologyCardinality(item.type)}</span><strong>${titleOf(item.toEntity)}</strong><code>${item.relationshipId}</code></li>`)}</ul>` : html `<p>${this.t('ontology.relationshipsEmpty')}</p>`}</section></div></details></section>`;
    }
    v3NodeType(node) {
        if (node.to?.length)
            return `${node.type} → ${node.to.join(', ')}`;
        if (node.of)
            return `${node.type} · ${node.of}`;
        return node.type;
    }
    renderV3NodeChips(node) {
        return html `
      <span class="nr-chip">${this.v3NodeType(node)}</span>
      <span class=${node.required ? 'nr-chip is-required' : 'nr-chip'}>${node.required ? this.t('ontology.required') : this.t('ontology.optional')}</span>
      ${node.origin ? html `<span class="nr-chip is-${node.origin}">${this.t(`ontology.v3.origin.${node.origin}`)}</span>` : nothing}
      ${node.indexed ? html `<span class="nr-chip is-indexed">${this.t('ontology.v3.indexedColumn')}</span>` : nothing}
      ${node.tightened ? html `<span class="nr-chip is-tightened">${this.t('ontology.v3.tightened')}</span>` : nothing}
      ${node.derived ? html `<span class="nr-chip is-derived">${this.t('ontology.v3.derived')}</span>` : nothing}
    `;
    }
    renderV3Node(node, depth = 0) {
        const innerFieldCount = node.children ? ontologyNodeLeafCount(node.children) : 0;
        const body = html `
      ${node.description ? html `<p>${node.description}</p>` : nothing}
      ${node.conflict ? html `<p class="nr-v3__warning" role="alert">${this.t('ontology.v3.conflict')}</p>` : nothing}
      ${node.values?.length ? html `<div class="nr-v3__values">${node.values.map(value => html `<span><strong>${value.title}</strong><code>${value.value}</code></span>`)}</div>` : nothing}
      ${node.children?.length ? html `<div class="nr-v3__children">${node.children.map(child => this.renderV3Node(child, depth + 1))}</div>` : nothing}
      ${node.children && !node.children.length ? html `<p class="nr-v3__empty-branch">${node.description || this.t('ontology.v3.emptyBranch')}</p>` : nothing}
    `;
        if (node.children)
            return html `
      <details class="nr-v3__tree-node is-branch">
        <summary><span><strong>${node.title}</strong><code>${node.id}</code><small class="nr-v3__branch-count">${this.t('ontology.v3.innerFields', { count: innerFieldCount })}</small></span><span class="nr-v3__chips">${this.renderV3NodeChips(node)}</span></summary>
        <div class="nr-v3__node-body">${body}</div>
      </details>
    `;
        return html `
      <article class="nr-v3__tree-node is-leaf">
        <header><span><strong>${node.title}</strong><code>${node.id}</code></span><span class="nr-v3__chips">${this.renderV3NodeChips(node)}</span></header>
        <div class="nr-v3__node-body">${body}</div>
      </article>
    `;
    }
    renderV3Relationships(relationships) {
        return html `<details class="nr-ontology__section nr-v3__section nr-v3__collapsible-section">
      <summary class="nr-v3__section-summary"><div><div><h3>${this.t('ontology.relationships')}</h3><p>${this.t('ontology.v3.relationshipsDescription')}</p></div><span>${this.t('ontology.count', { count: relationships.length })}</span></div></summary>
      <div class="nr-v3__section-body"><div class="nr-v3__relationships">${relationships.map(relationship => html `
        <article class=${relationship.conflict ? 'has-conflict' : ''}>
          <header><div><strong>${relationship.title}</strong><code>${relationship.relationshipId || relationship.name}</code></div><span>${relationship.cardinality || '—'}</span></header>
          ${relationship.description ? html `<p>${relationship.description}</p>` : nothing}
          <dl><div><dt>${this.t('ontology.v3.target')}</dt><dd>${relationship.to.map(target => html `<button type="button" @click=${() => this.selectV3Entity(target)}>${target}</button>`)}</dd></div><div><dt>${this.t('ontology.v3.via')}</dt><dd><code>${relationship.via}</code></dd></div>${relationship.roles?.length ? html `<div><dt>${this.t('ontology.v3.roles')}</dt><dd>${relationship.roles.join(', ')}</dd></div>` : nothing}</dl>
          <footer><span class="nr-chip">${this.t(`ontology.v3.mode.${relationship.mode}`)}</span>${relationship.required !== undefined ? html `<span class="nr-chip is-required">${relationship.required === true ? this.t('ontology.required') : relationship.required === false ? this.t('ontology.optional') : relationship.required}</span>` : nothing}${relationship.derived ? html `<span class="nr-chip is-derived">${this.t('ontology.v3.derived')}</span>` : nothing}</footer>
          ${relationship.path ? html `<p class="nr-v3__path"><code>${relationship.path}</code></p>` : nothing}
          ${relationship.conflict ? html `<p class="nr-v3__warning" role="alert">${relationship.conflict}</p>` : nothing}
        </article>
      `)}</div></div>
    </details>`;
    }
    renderV3Capabilities(capabilities) {
        const group = (origin) => capabilities.filter(item => item.origin === origin);
        return html `<details class="nr-ontology__section nr-v3__section nr-v3__collapsible-section">
      <summary class="nr-v3__section-summary"><div><div><h3>${this.t('ontology.v3.capabilities')}</h3><p>${this.t('ontology.v3.capabilitiesDescription')}</p></div><span>${this.t('ontology.count', { count: capabilities.length })}</span></div></summary>
      <div class="nr-v3__section-body"><div class="nr-v3__split">${['platform', 'module'].map(origin => html `<section><h4>${this.t(`ontology.v3.group.${origin}`)}</h4><div class="nr-v3__catalog">${group(origin).map(capability => html `
        <article class=${capability.unresolved ? 'is-unresolved' : ''}><header><code>${capability.id}</code>${capability.platform ? html `<span class="nr-chip is-${capability.platform}">${this.t(`ontology.v3.status.${capability.platform}`)}</span>` : nothing}</header>
          <p>${capability.moduleSentence || capability.sentence || this.t('ontology.v3.unresolved')}</p>
          ${capability.moduleSentence ? html `<small>${capability.sentence}</small>` : nothing}
        </article>`)}${!group(origin).length ? html `<p class="nr-ontology__empty-inline">${this.t('ontology.v3.none')}</p>` : nothing}</div></section>`)}</div></div>
    </details>`;
    }
    renderV3Rules(rules) {
        const group = (origin) => rules.filter(item => item.origin === origin);
        return html `<details class="nr-ontology__section nr-v3__section nr-v3__collapsible-section">
      <summary class="nr-v3__section-summary"><div><div><h3>${this.t('ontology.rules')}</h3><p>${this.t('ontology.v3.rulesDescription')}</p></div><span>${this.t('ontology.count', { count: rules.length })}</span></div></summary>
      <div class="nr-v3__section-body"><div class="nr-v3__split">${['platform', 'module'].map(origin => html `<section><h4>${this.t(`ontology.v3.group.${origin}`)}</h4><div class="nr-v3__catalog">${group(origin).map(rule => html `<article class=${rule.unresolved ? 'is-unresolved' : ''}><header><code>${rule.id}</code>${rule.platform ? html `<span class="nr-chip is-${rule.platform}">${this.t(`ontology.v3.status.${rule.platform}`)}</span>` : nothing}</header><p>${rule.text || this.t('ontology.v3.unresolved')}</p></article>`)}${!group(origin).length ? html `<p class="nr-ontology__empty-inline">${this.t('ontology.v3.none')}</p>` : nothing}</div></section>`)}</div></div>
    </details>`;
    }
    /**
     * ns5_47: what nobody writes. The tree already paints a derived leaf; this says WHY it is derived —
     * the condition in the user language and the paths it reads.
     */
    renderV3Derived(entity) {
        if (!entity)
            return nothing;
        const derived = ontologyV3DerivedFields(entity);
        if (!derived.length)
            return nothing;
        return html `<section class="nr-ontology__section nr-v3__section"><header><div><h3>${this.t('ontology.v3.derived')}</h3><p>${this.t('ontology.v3.derivedDescription')}</p></div><span>${this.t('ontology.v3.derivedCount', { count: derived.length })}</span></header><div class="nr-v3__record">${derived.map(field => html `<article><header><strong>${field.title}</strong><code>${field.path}</code></header>${field.description ? html `<p>${field.description}</p>` : nothing}</article>`)}</div></section>`;
    }
    renderV3Lifecycle(entity) {
        if (!entity)
            return nothing;
        const states = entity.lifecycleStates || [];
        const transitions = entity.transitions || [];
        const uniqueKeys = entity.uniqueKeys || [];
        if (!states.length && !transitions.length && !uniqueKeys.length)
            return nothing;
        return html `<details class="nr-ontology__section nr-v3__section nr-v3__collapsible-section">
      <summary class="nr-v3__section-summary"><div><div><h3>${this.t('ontology.v3.lifecycleAndKeys')}</h3><p>${this.t('ontology.v3.lifecycleDescription')}</p></div><span>${this.t('ontology.v3.lifecycleCount', { states: states.length, transitions: transitions.length })}</span></div></summary>
      <div class="nr-v3__section-body">
        ${uniqueKeys.length ? html `<div class="nr-v3__unique"><strong>${this.t('ontology.uniqueKeys')}</strong>${uniqueKeys.map(key => html `<span>${key.map(field => html `<code>${field}</code>`)}</span>`)}</div>` : nothing}
        ${states.length ? html `<div class="nr-lifecycle__rail">${states.map(state => html `<span><strong>${state.state}</strong><small>${this.t(`ontology.reachedBy.${state.reachedBy}`)}</small></span>`)}</div>` : nothing}
        ${transitions.length ? html `<div class="nr-lifecycle__transitions">${transitions.map(transition => html `<article><header><code>${transition.transitionId}</code><span>${transition.from.join(', ')} → ${transition.to}</span></header><p>${transition.description}</p><footer><span>${this.t('ontology.by')}: <strong>${Array.isArray(transition.by) ? transition.by.join(', ') : transition.by}</strong></span>${transition.ruleRefs?.length ? html `<span>${this.t('ontology.ruleRefs')}: ${transition.ruleRefs.map(rule => html `<code>${rule}</code>`)}</span>` : nothing}</footer></article>`)}</div>` : nothing}
      </div>
    </details>`;
    }
    v3GraphOption(index) {
        const style = getComputedStyle(this);
        const colors = Array.from({ length: 6 }, (_, item) => style.getPropertyValue(`--chart-series-${item + 1}`).trim() || style.getPropertyValue(`--ds-chart-series-${item + 1}`).trim());
        const text = style.getPropertyValue('--text-default').trim() || '#2f3a48';
        const muted = style.getPropertyValue('--text-muted').trim() || '#5d6b7e';
        const surface = style.getPropertyValue('--surface-bg').trim() || '#fff';
        const graph = buildOntologyV3Graph(index, this.v3Views, colors);
        const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches || false;
        const signature = JSON.stringify({ index, graph, colors, text, muted, surface, reduceMotion });
        if (signature === this.v3GraphCacheSignature && this.v3GraphCache)
            return this.v3GraphCache;
        this.v3GraphCacheSignature = signature;
        this.v3GraphCache = {
            animation: !reduceMotion,
            aria: { enabled: true, decal: { show: true }, description: this.t('ontology.v3.graphAria') },
            tooltip: { trigger: 'item' },
            legend: [{ data: graph.categories.map(category => ({ name: this.t(`ontology.kind.${category.name}`), icon: 'circle' })), textStyle: { color: muted } }],
            toolbox: { right: 12, feature: { restore: { title: this.t('ontology.graphReset') }, saveAsImage: { title: this.t('ontology.graphPng'), name: `${this.moduleName}-ontology-v3`, pixelRatio: 2 } } },
            series: [{
                    type: 'graph', layout: 'force', roam: true, draggable: true,
                    data: graph.nodes.map(node => ({ ...node, label: { formatter: [`{title|${node.title}}`, `{id|${node.id}}`, ...node.detailBranches.map(branch => `{branch|details.${branch}}`)].join('\n') } })),
                    links: graph.links.map(link => ({ ...link, label: { formatter: link.value } })),
                    categories: graph.categories.map(category => ({ ...category, name: this.t(`ontology.kind.${category.name}`) })),
                    force: { repulsion: 360, edgeLength: [120, 210], gravity: .07 }, edgeSymbol: ['none', 'arrow'], edgeSymbolSize: 9,
                    label: { show: true, color: text, rich: { title: { fontSize: 12, fontWeight: 700, lineHeight: 18 }, id: { fontSize: 10, color: muted, lineHeight: 14 }, branch: { fontSize: 9, color: muted, lineHeight: 13, backgroundColor: surface, padding: [0, 3], borderRadius: 2 } } },
                    edgeLabel: { show: true, color: muted, fontSize: 9, backgroundColor: surface, padding: [2, 4], borderRadius: 3 }, lineStyle: { curveness: .1 }, emphasis: { focus: 'adjacency' },
                }],
        };
        return this.v3GraphCache;
    }
    renderV3Graph(index, selected) {
        const graph = buildOntologyV3Graph(index, this.v3Views, []);
        return html `<section class="nr-ontology__graph-view"><div class="nr-ontology__graph-layout"><div class="nr-ontology__graph" role="img" aria-label=${this.t('ontology.v3.graphAria')} ${chart(this.v3GraphOption(index), { click: (params) => { const node = params; if (node.dataType === 'node' && node.data?.id)
                this.selectV3Entity(node.data.id); } })}></div><aside><span>${this.t('ontology.selected')}</span><h2>${selected.title}</h2><code>${selected.entityId}</code><p>${selected.description}</p><dl><div><dt>${this.t('ontology.fields')}</dt><dd>${ontologyV3FieldCount(selected)}</dd></div><div><dt>${this.t('ontology.relationships')}</dt><dd>${selected.relationships.length}</dd></div><div><dt>${this.t('ontology.v3.branches')}</dt><dd>${selected.details.length}</dd></div></dl><button type="button" @click=${() => { this.view = 'text'; }}>${this.t('ontology.openDetails')}</button></aside></div><details class="nr-ontology__graph-alternative"><summary>${this.t('ontology.graphAlternative')}</summary><div><section><h3>${this.t('ontology.entities')}</h3><ul>${graph.nodes.map(node => html `<li><button type="button" @click=${() => this.selectV3Entity(node.id)}><strong>${node.title}</strong><code>${node.ghost ? this.t('ontology.v3.platformGhost') : node.id}</code></button></li>`)}</ul></section><section><h3>${this.t('ontology.relationships')}</h3><ul>${index.relationships.map(link => html `<li><strong>${link.from}</strong><span>${link.mode}</span><strong>${link.to}</strong><code>${link.catalogType || link.through || link.field || link.relationshipId}</code></li>`)}</ul></section></div></details></section>`;
    }
    renderV3EntityContent(index, entity) {
        const raw = this.v3Entities().find(item => item.entityId === entity.entityId);
        return html `<div class="nr-v3__entity-content">
      <section class="nr-ontology__identity nr-v3__identity"><div><span>${this.t('ontology.entity')}</span><h2>${entity.title}</h2><code>${entity.entityId}</code></div><div class="nr-ontology__badges"><span>${this.t(`ontology.kind.${entity.kind}`)}</span>${entity.subtype ? html `<span>${entity.subtype}</span>` : nothing}<span>${this.t('ontology.v3.readOnly')}</span></div><p>${entity.description}</p><dl><div><dt>${this.t('ontology.displayField')}</dt><dd><code>${entity.displayField}</code></dd></div><div><dt>${this.t('ontology.v3.namespace')}</dt><dd><code>${index.moduleNamespace.key}</code></dd></div><div><dt>${this.t('ontology.v3.schema')}</dt><dd><code>${this.t('ontology.v3.contractName')}</code></dd></div></dl></section>
      <section class="nr-ontology__section nr-v3__section"><header><div><h3>${this.t('ontology.v3.record')}</h3><p>${this.t('ontology.v3.recordDescription')}</p></div><span>${this.t('ontology.count', { count: entity.columns.length + 1 })}</span></header><div class="nr-v3__record">${entity.columns.map(column => html `<article><header><strong>${column.title || column.id}</strong><code>${column.id}</code></header><div class="nr-v3__chips">${this.renderV3NodeChips(column)}</div>${column.description ? html `<p>${column.description}</p>` : nothing}</article>`)}<article class="is-details"><header><strong>${this.t('ontology.v3.details')}</strong><code>${this.t('ontology.v3.details')}</code></header><div class="nr-v3__chips"><span class="nr-chip">${this.t('ontology.v3.object')}</span><span class="nr-chip is-required">${this.t('ontology.required')}</span></div><p>${this.t('ontology.v3.detailsSummary', { count: entity.details.length })}</p></article></div></section>
      <section class="nr-ontology__section nr-v3__section"><header><div><h3>${this.t('ontology.v3.details')}</h3><p>${this.t('ontology.v3.treeDescription')}</p></div><span title=${this.t('ontology.v3.leafCountHelp')} >${this.t('ontology.v3.leafCount', { count: ontologyNodeLeafCount(entity.details) })}</span></header><div class="nr-v3__tree">${entity.details.map(node => this.renderV3Node(node))}</div></section>
      ${this.renderV3Relationships(entity.relationships)}
      ${this.renderV3Capabilities(entity.capabilities)}
      ${this.renderV3Rules(entity.rules)}
      ${this.renderV3Derived(raw)}
      ${this.renderV3Lifecycle(raw)}
    </div>`;
    }
    renderV3EntityPanel(index, entity, selected) {
        const isOpen = entity.entityId === selected.entityId;
        const className = entity.kind === 'platform' ? 'nr-v3__entity-panel is-platform' : 'nr-v3__entity-panel';
        return html `<details class=${className} ?open=${isOpen}>
      <summary @click=${(event) => {
            event.preventDefault();
            void this.selectV3EntityAndScroll(entity.entityId, event.currentTarget);
        }}>
        <span><strong>${entity.title}</strong><code>${entity.entityId}</code></span>
        <span class="nr-v3__entity-meta"><i>${this.t(`ontology.kind.${entity.kind}`)}</i>${entity.subtype ? html `<i>${entity.subtype}</i>` : nothing}<i>${ontologyV3FieldCount(entity)} ${this.t('ontology.fields')}</i></span>
      </summary>
      <div class="nr-v3__entity-reveal"><div>${this.renderV3EntityContent(index, entity)}</div></div>
    </details>`;
    }
    renderV3Text(index, selected) {
        const entities = selected.kind === 'platform' ? [...this.v3Views, selected] : this.v3Views;
        return html `<div class="nr-v3__entity-accordion">${entities.map(entity => this.renderV3EntityPanel(index, entity, selected))}</div>`;
    }
    renderV3(index) {
        if (this.v3Loading && !this.v3Views.length)
            return html `<section class="nr-ontology__empty"><h2>${this.t('ontology.v3.loading')}</h2></section>`;
        if (this.v3Error)
            return html `<section class="nr-ontology__empty"><h2>${this.t('ontology.v3.error')}</h2><p>${this.v3Error}</p></section>`;
        const selected = this.v3SelectedView();
        if (!selected)
            return html `<section class="nr-ontology__empty"><h2>${this.t('ontology.emptyTitle')}</h2><p>${this.t('ontology.emptyBody')}</p></section>`;
        const fields = this.v3Views.reduce((count, view) => count + ontologyV3FieldCount(view), 0);
        return html `<section class="nr-ontology nr-v3"><header class="nr-ontology__hero"><div><span>${this.t('ontology.v3.eyebrow')}</span><h2>${this.t('ontology.title')}</h2><p>${index.businessDomain}</p></div><div class="nr-ontology__actions"><div class="nr-ontology__toggle" role="group" aria-label=${this.t('ontology.view')}><button type="button" class=${this.view === 'text' ? 'is-active' : ''} @click=${() => { this.view = 'text'; }}>${this.t('ontology.view.text')}</button><button type="button" class=${this.view === 'graph' ? 'is-active' : ''} @click=${() => { this.view = 'graph'; }}>${this.t('ontology.view.graph')}</button></div><span class="nr-v3__edit-note">${this.t('ontology.v3.editNote')}</span><button class="nr-button nr-button--secondary" type="button" disabled title=${this.t('ontology.v3.editNote')}>${this.t('ontology.edit')}</button></div></header><div class="nr-ontology__summary"><span><strong>${this.v3Views.length}</strong>${this.t('ontology.entities')}</span><span><strong>${index.relationships.length}</strong>${this.t('ontology.relationships')}</span><span title=${this.t('ontology.v3.fieldCountHelp')}><strong>${fields}</strong>${this.t('ontology.fields')}</span></div>${this.view === 'graph' ? this.renderV3Graph(index, selected) : this.renderV3Text(index, selected)}</section>`;
    }
    render() {
        const v3Index = this.v3Index();
        if (v3Index)
            return this.renderV3(v3Index);
        const entity = this.currentEntity();
        const index = this.currentIndex();
        if (!entity || !index)
            return html `<section class="nr-ontology__empty"><h2>${this.t('ontology.emptyTitle')}</h2><p>${this.t('ontology.emptyBody')}</p></section>`;
        const counts = this.currentEntities().reduce((result, item) => {
            const current = ontologyFieldCounts(item);
            return { namespace: result.namespace + current.namespace, base: result.base + current.base, total: result.total + current.total };
        }, { namespace: 0, base: 0, total: 0 });
        return html `
      <section class="nr-ontology">
        <header class="nr-ontology__hero"><div><span>${this.t('ontology.eyebrow')}</span><h2>${this.t('ontology.title')}</h2><p>${index.businessDomain}</p></div><div class="nr-ontology__actions"><div class="nr-ontology__toggle" role="group" aria-label=${this.t('ontology.view')}><button type="button" class=${this.view === 'text' ? 'is-active' : ''} @click=${() => { this.view = 'text'; }}>${this.t('ontology.view.text')}</button><button type="button" class=${this.view === 'graph' ? 'is-active' : ''} @click=${() => { this.view = 'graph'; }}>${this.t('ontology.view.graph')}</button></div>${this.mode === 'view' ? html `<button class="nr-button nr-button--secondary" type="button" @click=${() => { this.view = 'text'; this.beginEdit(); }}>${this.t('ontology.edit')}</button>` : html `<span>${this.t('ontology.editing')}</span>`}</div></header>
        <div class="nr-ontology__summary"><span><strong>${this.currentEntities().length}</strong>${this.t('ontology.entities')}</span><span><strong>${index.relationships.length}</strong>${this.t('ontology.relationships')}</span><span title=${this.t('ontology.fieldCountBreakdown', { namespace: counts.namespace, base: counts.base })}><strong>${counts.total}</strong>${this.t('ontology.fields')}</span></div>
        ${this.view === 'graph' ? this.renderGraph(entity) : this.renderText(entity)}
        ${this.mode === 'edit' ? html `<footer class="nr-ontology__edit-footer"><span>${this.dirty ? this.t('ontology.unsaved') : this.t('ontology.noChanges')}</span><div><button type="button" @click=${this.cancelEdit}>${this.t('ontology.cancel')}</button><button class="is-primary" type="button" ?disabled=${!this.dirty} @click=${() => void this.saveEdit()}>${this.t('ontology.save')}</button></div></footer>` : nothing}
      </section>
    `;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseOntology102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseOntology102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseOntology102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseOntology102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseOntology102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseOntology102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseOntology102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "view", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "selectedEntityId", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "entityDraft", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "indexDraft", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "issues", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "gateIssues", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "editMessage", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "newUniqueFields", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "newDetailName", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "newDetailType", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "newStateName", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "newStateReachedBy", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "newTransitionId", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "v3Views", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "v3PlatformView", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "v3Loading", void 0);
__decorate([
    state()
], NewReleaseOntology102035.prototype, "v3Error", void 0);
NewReleaseOntology102035 = __decorate([
    customElement('new-release--widgets--ontology-102035')
], NewReleaseOntology102035);
export { NewReleaseOntology102035 };
