/// <mls fileReference="_102035_/l2/newRelease/widgets/journeys.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { announceNewReleaseChange, canDiscardNewReleaseDraft, requestNewReleaseEdit, } from '/_102035_/l2/newRelease/editContract.js';
import { validNewJourneyStepId, journeyStepGroups, JOURNEY_STEP_KINDS, journeyIssues, journeyPath, journeyTransitions, moveJourney, moveJourneyStep, orderedJourneys, syncJourneyIndex, } from '/_102035_/l2/newRelease/widgets/journeysModel.js';
import { renderNewReleaseIcon } from '/_102035_/l2/newRelease/widgets/iconPicker.js';
import { hasItemDiff, idScope } from '/_102035_/l2/newRelease/helpers/itemDiffs.js';
import { changedDot } from '/_102035_/l2/newRelease/helpers/changedDot.js';
import { JOURNEY_ICON_DEFAULTS, withNewReleaseIcon } from '/_102035_/l2/newRelease/widgets/iconModel.js';
let NewReleaseJourneys102035 = class NewReleaseJourneys102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--journeys-102035 {
  display: block;
}
new-release--widgets--journeys-102035 * {
  box-sizing: border-box;
}
new-release--widgets--journeys-102035 h2,
new-release--widgets--journeys-102035 h3,
new-release--widgets--journeys-102035 p {
  margin: 0;
}
new-release--widgets--journeys-102035 button,
new-release--widgets--journeys-102035 input,
new-release--widgets--journeys-102035 select,
new-release--widgets--journeys-102035 textarea {
  font: inherit;
}
new-release--widgets--journeys-102035 button {
  cursor: pointer;
}
new-release--widgets--journeys-102035 code {
  font-family: var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--journeys-102035 input,
new-release--widgets--journeys-102035 select,
new-release--widgets--journeys-102035 textarea {
  width: 100%;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--journeys-102035 input,
new-release--widgets--journeys-102035 select {
  min-height: 2.25rem;
  padding: 0.42rem 0.58rem;
}
new-release--widgets--journeys-102035 textarea {
  min-height: 4rem;
  padding: 0.55rem 0.62rem;
  resize: vertical;
  line-height: 1.45;
}
new-release--widgets--journeys-102035 select[multiple] {
  min-height: 5rem;
}
new-release--widgets--journeys-102035 input:focus,
new-release--widgets--journeys-102035 select:focus,
new-release--widgets--journeys-102035 textarea:focus {
  border-color: var(--focus-border, #1273d4);
  outline: 2px solid color-mix(in srgb, var(--focus-border, #1273d4) 20%, transparent);
}
new-release--widgets--journeys-102035 .nr-journeys {
  display: grid;
  min-width: 0;
  color: var(--text-default, #2f3a48);
}
new-release--widgets--journeys-102035 .nr-journeys__hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.2rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: linear-gradient(135deg, var(--surface-bg, #fff), color-mix(in srgb, var(--selected-bg, #e3f1ff) 48%, var(--surface-bg, #fff)));
}
new-release--widgets--journeys-102035 .nr-journeys__hero > div:first-child > span,
new-release--widgets--journeys-102035 .nr-journeys__detail > header span,
new-release--widgets--journeys-102035 .nr-journeys__intent label > span,
new-release--widgets--journeys-102035 .nr-journeys__path > header span,
new-release--widgets--journeys-102035 .nr-journeys__outcome small {
  color: var(--link-text, #0f62b8);
  font-size: 0.65rem;
  font-weight: 800;
  letter-spacing: 0.11em;
  text-transform: uppercase;
}
new-release--widgets--journeys-102035 .nr-journeys__hero h2 {
  margin-top: 0.28rem;
  color: var(--text-strong, #111827);
  font-size: 1.5rem;
  letter-spacing: -0.03em;
}
new-release--widgets--journeys-102035 .nr-journeys__hero p {
  max-width: 46rem;
  margin-top: 0.42rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--journeys-102035 .nr-journeys__hero > div:last-child {
  display: grid;
  min-width: 6rem;
  place-items: center;
  padding: 0.65rem 0.9rem;
  border: 1px solid color-mix(in srgb, var(--selected-border, #1273d4) 25%, var(--border-subtle, #e4e9f0));
  border-radius: 0.85rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--journeys-102035 .nr-journeys__hero > div:last-child strong {
  color: var(--text-strong, #111827);
  font-size: 1.35rem;
  letter-spacing: -0.04em;
}
new-release--widgets--journeys-102035 .nr-journeys__hero > div:last-child span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--journeys-102035 .nr-journeys__filters {
  display: flex;
  align-items: flex-end;
  gap: 0.8rem;
  padding: 0.75rem 1.25rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--journeys-102035 .nr-journeys__filters label {
  display: grid;
  min-width: 13rem;
  gap: 0.25rem;
}
new-release--widgets--journeys-102035 .nr-journeys__filters label span,
new-release--widgets--journeys-102035 .nr-journeys__filters > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
  font-weight: 750;
}
new-release--widgets--journeys-102035 .nr-journeys__filters > span {
  margin-bottom: 0.65rem;
}
new-release--widgets--journeys-102035 .nr-journeys__toggle {
  display: flex;
  margin-left: auto;
  padding: 0.17rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.6rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--journeys-102035 .nr-journeys__toggle button {
  min-height: 1.8rem;
  padding: 0.3rem 0.62rem;
  border: 0;
  border-radius: 0.42rem;
  background: transparent;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.67rem;
  font-weight: 750;
}
new-release--widgets--journeys-102035 .nr-journeys__toggle button.is-active {
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
}
new-release--widgets--journeys-102035 .nr-journeys__cards {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(min(100%, 14rem), 1fr));
  gap: 0.65rem;
  padding: 0.85rem 1.25rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--journeys-102035 .nr-journeys__cards > button {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  min-width: 0;
  gap: 0.65rem;
  padding: 0.72rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.72rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  text-align: left;
}
new-release--widgets--journeys-102035 .nr-journeys__cards > button:hover {
  border-color: var(--border-default, #cfd8e3);
  transform: translateY(-1px);
}
new-release--widgets--journeys-102035 .nr-journeys__cards > button.is-active {
  border-color: var(--selected-border, #1273d4);
  background: var(--selected-bg, #e3f1ff);
  box-shadow: inset 0 -0.18rem var(--selected-border, #1273d4);
}
new-release--widgets--journeys-102035 .nr-journeys__cards > button > span {
  color: var(--text-muted, #5d6b7e);
  font: 700 0.62rem var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--journeys-102035 .nr-journeys__cards > button > div {
  min-width: 0;
}
new-release--widgets--journeys-102035 .nr-journeys__cards strong,
new-release--widgets--journeys-102035 .nr-journeys__cards small {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--journeys-102035 .nr-journeys__cards strong {
  color: var(--text-strong, #111827);
  font-size: 0.76rem;
}
new-release--widgets--journeys-102035 .nr-journeys__cards small {
  margin-top: 0.18rem;
  color: var(--link-text, #0f62b8);
  font-size: 0.62rem;
  font-weight: 700;
}
new-release--widgets--journeys-102035 .nr-journeys__cards p {
  display: -webkit-box;
  margin-top: 0.36rem;
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
  line-height: 1.4;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}
new-release--widgets--journeys-102035 .nr-journeys__cards i {
  display: grid;
  width: 1.55rem;
  height: 1.55rem;
  place-items: center;
  border-radius: 50%;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--link-text, #0f62b8);
  font-style: normal;
}
new-release--widgets--journeys-102035 .nr-journeys__table-wrap {
  overflow-x: auto;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--journeys-102035 table {
  width: 100%;
  border-collapse: collapse;
  background: var(--surface-bg, #fff);
  font-size: 0.7rem;
}
new-release--widgets--journeys-102035 th {
  padding: 0.55rem 0.72rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
  letter-spacing: 0.07em;
  text-align: left;
  text-transform: uppercase;
}
new-release--widgets--journeys-102035 td {
  padding: 0.58rem 0.72rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  vertical-align: middle;
}
new-release--widgets--journeys-102035 tbody tr {
  cursor: pointer;
}
new-release--widgets--journeys-102035 tbody tr:hover,
new-release--widgets--journeys-102035 tbody tr.is-active {
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--journeys-102035 td strong,
new-release--widgets--journeys-102035 td small {
  display: block;
}
new-release--widgets--journeys-102035 td strong {
  color: var(--text-strong, #111827);
  font-size: 0.72rem;
}
new-release--widgets--journeys-102035 td small {
  max-width: 34rem;
  margin-top: 0.12rem;
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--journeys-102035 .nr-journeys__detail {
  display: grid;
  gap: 1rem;
  padding: 1.15rem 1.25rem 1.5rem;
}
new-release--widgets--journeys-102035 .nr-journeys__detail > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1rem;
}
new-release--widgets--journeys-102035 .nr-journeys__detail > header h2 {
  margin-top: 0.25rem;
  color: var(--text-strong, #111827);
  font-size: 1.35rem;
  letter-spacing: -0.025em;
}
new-release--widgets--journeys-102035 .nr-journeys__detail > header code {
  display: block;
  margin-top: 0.28rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
}
new-release--widgets--journeys-102035 .nr-journeys__title-input {
  min-width: min(32rem, 60vw);
  margin-top: 0.28rem;
  color: var(--text-strong, #111827);
  font-size: 1.15rem;
  font-weight: 750;
}
new-release--widgets--journeys-102035 .nr-button {
  min-height: 2.25rem;
  padding: 0.42rem 0.78rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.58rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.72rem;
  font-weight: 750;
}
new-release--widgets--journeys-102035 .nr-journeys__editing {
  padding: 0.38rem 0.65rem;
  border-radius: 999px;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296) !important;
  letter-spacing: 0 !important;
  text-transform: none !important;
}
new-release--widgets--journeys-102035 .nr-journeys__intent {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.7rem;
}
new-release--widgets--journeys-102035 .nr-journeys__intent label {
  display: grid;
  gap: 0.35rem;
  padding: 0.75rem 0.82rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.75rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--journeys-102035 .nr-journeys__intent label.is-wide {
  grid-column: 1 / -1;
}
new-release--widgets--journeys-102035 .nr-journeys__intent strong {
  color: var(--text-strong, #111827);
  font-size: 0.8rem;
}
new-release--widgets--journeys-102035 .nr-journeys__intent p {
  color: var(--text-default, #2f3a48);
  font-size: 0.79rem;
  line-height: 1.55;
}
new-release--widgets--journeys-102035 .nr-journeys__path,
new-release--widgets--journeys-102035 .nr-journeys__outcome {
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.85rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--journeys-102035 .nr-journeys__path > header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.72rem 0.85rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--journeys-102035 .nr-journeys__path > header p {
  margin-top: 0.15rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.66rem;
}
new-release--widgets--journeys-102035 .nr-journeys__path > header strong {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline {
  margin: 0;
  padding: 0.85rem 0.9rem 0.2rem;
  list-style: none;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline > li {
  display: grid;
  grid-template-columns: 2rem minmax(0, 1fr);
  gap: 0.55rem;
}
new-release--widgets--journeys-102035 .nr-step__rail {
  display: grid;
  grid-template-rows: 1.8rem 1fr;
  justify-items: center;
}
new-release--widgets--journeys-102035 .nr-step__rail > span {
  display: grid;
  width: 1.8rem;
  height: 1.8rem;
  place-items: center;
  border: 1px solid color-mix(in srgb, var(--selected-border, #1273d4) 32%, var(--border-subtle, #e4e9f0));
  border-radius: 0.55rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
}
new-release--widgets--journeys-102035 .nr-step__rail svg {
  width: 1rem;
  height: 1rem;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 1.8;
}
new-release--widgets--journeys-102035 .nr-step__rail i {
  width: 1px;
  min-height: 1.2rem;
  background: var(--border-default, #cfd8e3);
}
new-release--widgets--journeys-102035 .nr-journeys__timeline > li:last-child .nr-step__rail i {
  background: linear-gradient(var(--border-default, #cfd8e3), transparent);
}
new-release--widgets--journeys-102035 .nr-journeys__timeline article {
  min-width: 0;
  margin-bottom: 0.7rem;
  padding: 0.68rem 0.75rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.7rem;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline article > header {
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline article > header small {
  color: var(--text-muted, #5d6b7e);
  font: 700 0.58rem var(--font-family-mono, ui-monospace, monospace);
  text-transform: uppercase;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline h3 {
  margin-top: 0.14rem;
  color: var(--text-strong, #111827);
  font-size: 0.8rem;
}
new-release--widgets--journeys-102035 .nr-step__actions {
  display: flex;
  flex: none;
  gap: 0.25rem;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline article > header button {
  width: 1.65rem;
  height: 1.65rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.4rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--journeys-102035 .nr-journeys__timeline article > header button.is-remove {
  border-color: transparent;
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--journeys-102035 .nr-journeys__timeline article > header button:disabled {
  cursor: not-allowed;
  opacity: 0.38;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline article > p {
  margin-top: 0.38rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.72rem;
  line-height: 1.5;
}
new-release--widgets--journeys-102035 .nr-step__meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem;
  margin-top: 0.55rem;
}
new-release--widgets--journeys-102035 .nr-step__meta > * {
  min-height: 1.55rem;
  padding: 0.25rem 0.48rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
  font-weight: 700;
}
new-release--widgets--journeys-102035 .nr-step__meta button {
  color: var(--link-text, #0f62b8);
  text-decoration: underline;
  text-underline-offset: 0.12rem;
}
new-release--widgets--journeys-102035 .nr-step__meta .is-effect {
  border-color: color-mix(in srgb, var(--status-success-text, #25640e) 25%, transparent);
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--journeys-102035 .nr-step__meta .is-handoff {
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
}
new-release--widgets--journeys-102035 .nr-step__edit {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.55rem;
  margin-top: 0.6rem;
}
new-release--widgets--journeys-102035 .nr-step__edit label {
  display: grid;
  gap: 0.24rem;
}
new-release--widgets--journeys-102035 .nr-step__edit label > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
  font-weight: 750;
}
new-release--widgets--journeys-102035 .nr-step__edit .is-wide {
  grid-column: 1 / -1;
}
new-release--widgets--journeys-102035 .nr-step__exits {
  display: grid;
  gap: 0.3rem;
  margin-top: 0.55rem;
  padding: 0.55rem;
  border-left: 0.18rem solid var(--selected-border, #1273d4);
  border-radius: 0.25rem 0.55rem 0.55rem 0.25rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--journeys-102035 .nr-step__exits > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
  font-weight: 800;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
new-release--widgets--journeys-102035 .nr-step__exits > div {
  display: grid;
  grid-template-columns: auto auto auto 1fr;
  align-items: center;
  gap: 0.38rem;
  font-size: 0.62rem;
}
new-release--widgets--journeys-102035 .nr-step__exits > div.is-disabled {
  opacity: 0.52;
}
new-release--widgets--journeys-102035 .nr-step__exits small {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--journeys-102035 .nr-journeys__add {
  margin: 0 0.9rem 0.9rem;
  padding: 0.55rem;
  border: 1px dashed var(--selected-border, #1273d4);
  border-radius: 0.6rem;
  background: transparent;
  color: var(--link-text, #0f62b8);
  font-size: 0.7rem;
  font-weight: 750;
}
new-release--widgets--journeys-102035 .nr-journeys__outcome {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) minmax(0, 1fr);
  overflow: hidden;
}
new-release--widgets--journeys-102035 .nr-journeys__outcome > header {
  display: grid;
  grid-template-columns: 2rem 1fr;
  gap: 0.65rem;
  padding: 0.9rem;
  background: linear-gradient(135deg, var(--status-success-bg, #e2f5db), var(--surface-bg, #fff));
}
new-release--widgets--journeys-102035 .nr-journeys__outcome > header > span {
  display: grid;
  width: 2rem;
  height: 2rem;
  place-items: center;
  border-radius: 50%;
  background: var(--status-success-text, #25640e);
  color: var(--status-success-bg, #e2f5db);
  font-weight: 900;
}
new-release--widgets--journeys-102035 .nr-journeys__outcome h3 {
  margin-top: 0.3rem;
  color: var(--text-strong, #111827);
  font-size: 0.84rem;
  line-height: 1.5;
}
new-release--widgets--journeys-102035 .nr-journeys__outcome > div {
  padding: 0.85rem 0.9rem;
  border-left: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--journeys-102035 .nr-journeys__outcome > div > strong {
  display: block;
  margin-bottom: 0.45rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
new-release--widgets--journeys-102035 .nr-journeys__outcome > div > p {
  display: flex;
  gap: 0.4rem;
  margin-top: 0.3rem;
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
  line-height: 1.45;
}
new-release--widgets--journeys-102035 .nr-journeys__outcome > div > p i {
  color: var(--status-success-text, #25640e);
  font-style: normal;
  font-weight: 900;
}
new-release--widgets--journeys-102035 .nr-journeys__outcome > div > label {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 0.35rem;
  margin-top: 0.35rem;
}
new-release--widgets--journeys-102035 .nr-journeys__outcome > div > label button {
  width: 2.25rem;
  border: 0;
  border-radius: 0.45rem;
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--journeys-102035 .nr-journeys__add-evidence {
  margin-top: 0.5rem;
  border: 0;
  background: transparent;
  color: var(--link-text, #0f62b8);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--journeys-102035 .nr-journeys__issues {
  display: grid;
  gap: 0.4rem;
  padding: 0.7rem 0.8rem;
  border: 1px solid color-mix(in srgb, var(--status-warning-text, #7a4b00) 30%, var(--border-subtle, #e4e9f0));
  border-radius: 0.7rem;
  background: var(--status-warning-bg, #fff1c2);
}
new-release--widgets--journeys-102035 .nr-journeys__issues > strong {
  color: var(--text-strong, #111827);
  font-size: 0.7rem;
}
new-release--widgets--journeys-102035 .nr-journeys__issues > p {
  font-size: 0.68rem;
}
new-release--widgets--journeys-102035 .nr-journeys__issues > div {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 0.45rem;
  align-items: start;
}
new-release--widgets--journeys-102035 .nr-journeys__issues > div span {
  padding: 0.12rem 0.32rem;
  border-radius: 0.3rem;
  background: var(--surface-bg, #fff);
  font: 700 0.56rem var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--journeys-102035 .nr-journeys__issues > div p {
  font-size: 0.66rem;
  line-height: 1.4;
}
new-release--widgets--journeys-102035 .nr-journeys__issues > div.is-error {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--journeys-102035 .nr-journeys__edit-footer {
  position: sticky;
  z-index: 5;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.72rem 1.25rem;
  border-top: 1px solid var(--border-default, #cfd8e3);
  background: color-mix(in srgb, var(--surface-bg, #fff) 94%, transparent);
  box-shadow: 0 -0.5rem 1.4rem color-mix(in srgb, var(--text-strong, #111827) 8%, transparent);
  backdrop-filter: blur(10px);
}
new-release--widgets--journeys-102035 .nr-journeys__edit-footer > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--journeys-102035 .nr-journeys__edit-footer > div {
  display: flex;
  gap: 0.5rem;
}
new-release--widgets--journeys-102035 .nr-journeys__edit-footer button {
  min-height: 2.15rem;
  padding: 0.42rem 0.72rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.7rem;
  font-weight: 750;
}
new-release--widgets--journeys-102035 .nr-journeys__edit-footer button.is-primary {
  border-color: var(--action-primary-bg, #126fc2);
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
}
new-release--widgets--journeys-102035 .nr-journeys__edit-footer button:disabled {
  cursor: not-allowed;
  opacity: 0.48;
}
new-release--widgets--journeys-102035 .nr-journeys__empty {
  padding: 3rem 1.25rem;
  text-align: center;
}
new-release--widgets--journeys-102035 .nr-journeys__empty h2 {
  color: var(--text-strong, #111827);
}
new-release--widgets--journeys-102035 .nr-journeys__empty p {
  margin-top: 0.4rem;
  color: var(--text-muted, #5d6b7e);
}
@media (max-width: 720px) {
  new-release--widgets--journeys-102035 .nr-journeys__hero,
  new-release--widgets--journeys-102035 .nr-journeys__filters,
  new-release--widgets--journeys-102035 .nr-journeys__detail > header,
  new-release--widgets--journeys-102035 .nr-journeys__edit-footer {
    align-items: stretch;
    flex-direction: column;
  }
  new-release--widgets--journeys-102035 .nr-journeys__filters label {
    min-width: 0;
  }
  new-release--widgets--journeys-102035 .nr-journeys__toggle {
    margin-left: 0;
    align-self: flex-start;
  }
  new-release--widgets--journeys-102035 .nr-journeys__intent,
  new-release--widgets--journeys-102035 .nr-journeys__outcome {
    grid-template-columns: 1fr;
  }
  new-release--widgets--journeys-102035 .nr-journeys__outcome > div {
    border-top: 1px solid var(--border-subtle, #e4e9f0);
    border-left: 0;
  }
  new-release--widgets--journeys-102035 .nr-step__edit {
    grid-template-columns: 1fr;
  }
  new-release--widgets--journeys-102035 .nr-step__edit .is-wide {
    grid-column: auto;
  }
  new-release--widgets--journeys-102035 .nr-journeys__title-input {
    min-width: 0;
  }
  new-release--widgets--journeys-102035 .nr-journeys__edit-footer > div {
    justify-content: flex-end;
  }
}
new-release--widgets--journeys-102035 .nr-journeys__group > h3 {
  padding: 0.8rem 1rem 0;
  color: var(--text-muted);
  font-size: 0.8rem;
}
new-release--widgets--journeys-102035 .nr-step__open {
  width: 100%;
  padding: 0.35rem;
  border: 0;
  background: transparent;
  color: inherit;
  text-align: left;
  cursor: pointer;
}
new-release--widgets--journeys-102035 .nr-step__open:focus-visible {
  outline: 2px solid var(--selected-border);
}
new-release--widgets--journeys-102035 .nr-journeys__detail > label {
  display: grid;
  gap: 0.4rem;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline article {
  transition: opacity 0.2s, transform 0.2s;
}
new-release--widgets--journeys-102035 .nr-journeys__cards > button {
  animation: nr-journey-open 0.18s ease-out;
}
@keyframes nr-journey-open {
  from {
    opacity: 0.5;
    transform: translateY(-0.4rem);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
@media (prefers-reduced-motion: reduce) {
  new-release--widgets--journeys-102035 .nr-journeys__cards > button {
    animation: none;
  }
}
new-release--widgets--journeys-102035 .nr-journeys {
  background: radial-gradient(#1d56864d 0.8px, transparent 0.8px) 0 0 / 18px 18px, #081421;
  padding: 1rem;
  color: #eaf2ff;
}
new-release--widgets--journeys-102035 .nr-journeys__group {
  width: 100%;
  min-width: 0;
  margin: 1rem 0;
  padding: 0.4rem 1rem 1rem;
  border: 1px solid #235285;
  border-radius: 0.8rem;
  background: linear-gradient(#0d2035b8, #0a1a2bcc);
}
new-release--widgets--journeys-102035 .nr-journeys__group > h3 {
  color: #eaf2ff;
  font-size: 1rem;
  font-weight: 500;
}
new-release--widgets--journeys-102035 .nr-journeys__cards {
  border: 0;
  padding: 1rem 0;
  background: transparent;
}
new-release--widgets--journeys-102035 .nr-journeys__cards > button {
  min-height: 74px;
  border-color: #33557d;
  background: linear-gradient(#1a3453, #14283f);
}
new-release--widgets--journeys-102035 .nr-journeys__cards strong {
  color: #eaf2ff;
  font-size: 0.9rem;
  white-space: normal;
}
new-release--widgets--journeys-102035 .nr-journeys__detail {
  background: transparent;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2.5rem;
  padding: 1.5rem;
  overflow: auto;
  animation: nr-journey-steps 0.65s ease-in-out;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline > li {
  display: flex;
  position: relative;
  flex-direction: column;
  align-items: center;
  gap: 2rem;
  min-width: 240px;
}
new-release--widgets--journeys-102035 .nr-journeys__timeline > li + li:before {
  content: "↓";
  position: absolute;
  top: -2.2rem;
  left: 50%;
  color: #739acf;
  font-size: 1.5rem;
}
new-release--widgets--journeys-102035 .nr-step__open {
  display: flex;
  align-items: center;
  gap: 0.9rem;
  width: 260px;
  min-height: 74px;
  padding: 1rem;
  border: 1px solid #33557d;
  border-radius: 0.7rem;
  background: linear-gradient(#1a3453, #14283f);
  color: #eaf2ff;
  text-align: left;
}
new-release--widgets--journeys-102035 .nr-step__open:hover {
  border-color: #399cff;
  box-shadow: 0 0 20px #2499ff33;
}
new-release--widgets--journeys-102035 .nr-step__open > span {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  color: #82bfff;
}
new-release--widgets--journeys-102035 .nr-step__open svg {
  width: 24px;
  height: 24px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
}
new-release--widgets--journeys-102035 .nr-step__open.is-decision {
  border-color: #a087e8;
  border-radius: 1.8rem 0.7rem;
}
new-release--widgets--journeys-102035 .nr-journeys__branches {
  display: flex;
  position: relative;
  gap: 1.5rem;
  margin: 0;
  padding: 0;
  list-style: none;
}
new-release--widgets--journeys-102035 .nr-journeys__branches:before {
  content: "";
  position: absolute;
  top: -1rem;
  left: 130px;
  right: 130px;
  border-top: 1px solid #739acf;
}
new-release--widgets--journeys-102035 .nr-journeys__branches > li {
  position: relative;
}
new-release--widgets--journeys-102035 .nr-journeys__branches > li:before {
  content: "↓";
  position: absolute;
  top: -1.65rem;
  left: 50%;
  height: 1.5rem;
  color: #739acf;
}
@keyframes nr-journey-steps {
  from {
    opacity: 0;
    transform: translateY(-2rem);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
@media (prefers-reduced-motion: reduce) {
  new-release--widgets--journeys-102035 .nr-journeys__timeline {
    animation: none;
  }
}
new-release--widgets--journeys-102035 .nr-journeys__detail {
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  border-radius: 0.8rem;
}
new-release--widgets--journeys-102035 .nr-journeys__detail > .nr-button {
  justify-self: start;
}
new-release--widgets--journeys-102035 .nr-journeys__outcome > header {
  display: block;
}
new-release--widgets--journeys-102035 .nr-journeys__actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}
new-release--widgets--journeys-102035 .nr-journeys__cards > button:focus-visible,
new-release--widgets--journeys-102035 .nr-step__open:focus-visible {
  outline: 2px solid var(--focus-border, #1273d4);
  outline-offset: 3px;
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.selectedJourneyId = '';
        this.opened = false;
        this.journeyDetails = false;
        this.selectedStepId = '';
        this.newStepId = '';
        this.creatingStep = false;
        this.view = 'cards';
        this.journeyDraft = null;
        this.indexDraft = null;
        this.suppliedIssues = [];
        this.gateIssues = [];
        this.editMessage = '';
        this.journeyDirty = false;
        this.indexDirty = false;
        this.draggedJourneyId = '';
        this.draggedStepId = '';
    }
    createRenderRoot() { return this; }
    updated(changed) {
        if (changed.has('data') && !this.journeys().some(j => j.journeyId === this.selectedJourneyId)) {
            this.selectedJourneyId = '';
            this.opened = false;
            this.journeyDetails = false;
            this.selectedStepId = '';
        }
        if (['data', 'opened', 'journeyDetails', 'selectedJourneyId', 'mode', 'selectedStepId', 'creatingStep', 'journeyDraft', 't'].some(key => changed.has(key))) {
            const presentation = {
                filters: this.actors().map(actor => ({ id: actor.actorId, label: actor.title, rootIds: this.journeys().filter(journey => journey.business.actorRef === actor.actorId).map(journey => journey.journeyId) })),
                nodes: this.journeys().map(journey => ({ id: journey.journeyId, label: journey.business.title, value: journey.journeyId, changed: this.changedJourney(journey.journeyId),
                    children: journey.business.steps.map(step => ({ id: `${journey.journeyId}/${step.stepId}`, label: step.title, value: step.stepId, changed: this.changedStep(journey.journeyId, step.stepId), children: [] })) })),
                detail: this.journeyDetails || this.mode === 'edit' || !!this.selectedStepId || this.creatingStep,
                canBack: this.opened,
                select: id => {
                    if (id.startsWith('edit:')) {
                        if (this.selectJourney(id.slice(5)))
                            this.openJourneyEdit();
                        return;
                    }
                    if (id.startsWith('add:')) {
                        if (this.selectJourney(id.slice(4)))
                            this.openNewStep();
                        return;
                    }
                    const [journeyId, stepId] = id.split('/');
                    if (stepId)
                        this.openStep(journeyId, stepId);
                    else
                        this.selectJourney(journeyId);
                },
                back: () => {
                    if (!canDiscardNewReleaseDraft(this))
                        return;
                    const nested = this.journeyDetails || !!this.selectedStepId || this.creatingStep || this.mode === 'edit';
                    this.cancelEdit();
                    this.selectedStepId = '';
                    this.journeyDetails = false;
                    if (!nested)
                        this.opened = false;
                },
            };
            this.dispatchEvent(new CustomEvent('nr-view-state', { bubbles: true, composed: true, detail: presentation }));
        }
    }
    getDraft() {
        const journey = this.currentJourney();
        return journey ? structuredClone(journey) : null;
    }
    setIssues(issues) {
        this.suppliedIssues = issues.filter(issue => String(issue.artifact).startsWith('journeys/'));
    }
    actors() {
        return this.data?.artifacts.access.value?.actors
            || this.data?.pipeline?.steps.module10?.actors
            || [];
    }
    entities() {
        return this.data?.artifacts.entities.map(item => item.value)
            .filter((item) => !!item) || [];
    }
    sourceJourneys() {
        return this.data?.artifacts.journeys.map(item => item.value)
            .filter((item) => !!item) || [];
    }
    currentIndex() {
        return this.mode === 'edit' && this.indexDraft
            ? this.indexDraft
            : this.data?.artifacts.journeyIndex.value || null;
    }
    journeys() {
        const values = this.sourceJourneys().map(item => this.mode === 'edit' && this.journeyDraft?.journeyId === item.journeyId
            ? this.journeyDraft
            : item);
        return orderedJourneys(this.currentIndex(), values);
    }
    currentJourney() {
        return this.journeys().find(item => item.journeyId === this.selectedJourneyId) || null;
    }
    changedJourney(id) { return hasItemDiff(this.data?.diffs || [], `journeys/${id}.defs.ts`); }
    changedStep(journeyId, stepId) {
        return hasItemDiff(this.data?.diffs || [], `journeys/${journeyId}.defs.ts`, idScope('business.steps', 'stepId', stepId));
    }
    actorTitle(actorId) {
        return this.actors().find(actor => actor.actorId === actorId)?.title || actorId;
    }
    entityTitle(entityId) {
        return this.entities().find(entity => entity.entityId === entityId)?.title || entityId;
    }
    selectJourney(journeyId) {
        if (!canDiscardNewReleaseDraft(this))
            return false;
        this.cancelEdit();
        this.selectedJourneyId = journeyId;
        this.selectedStepId = '';
        this.journeyDetails = false;
        this.opened = true;
        return true;
    }
    openStep(journeyId, stepId) {
        if (this.version === 'asis') {
            if (canDiscardNewReleaseDraft(this))
                requestNewReleaseEdit(this, `${journeyId}/${stepId}`);
            return;
        }
        if (!this.selectJourney(journeyId))
            return;
        this.selectedStepId = stepId;
        if (!this.version.startsWith('release:'))
            this.beginEdit();
    }
    openJourneyEdit() {
        if (this.version === 'asis') {
            requestNewReleaseEdit(this, `edit:${this.selectedJourneyId}`);
            return;
        }
        this.beginEdit();
    }
    openNewStep() {
        if (this.version.startsWith('release:'))
            return;
        if (this.version === 'asis') {
            requestNewReleaseEdit(this, `add:${this.selectedJourneyId}`);
            return;
        }
        this.beginEdit();
        this.creatingStep = true;
        this.newStepId = '';
    }
    beginEdit() {
        const journey = this.currentJourney();
        const index = this.currentIndex();
        if (!journey || !index || this.version.startsWith('release:'))
            return;
        this.journeyDraft = structuredClone(journey);
        this.indexDraft = structuredClone(index);
        this.mode = 'edit';
        this.dirty = false;
        this.journeyDirty = false;
        this.indexDirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    cancelEdit() {
        this.journeyDraft = null;
        this.indexDraft = null;
        this.mode = 'view';
        this.dirty = false;
        this.journeyDirty = false;
        this.indexDirty = false;
        this.gateIssues = [];
        this.editMessage = '';
        this.draggedJourneyId = '';
        this.draggedStepId = '';
        this.creatingStep = false;
    }
    updateJourney(next) {
        this.journeyDraft = next;
        this.journeyDirty = JSON.stringify(next) !== JSON.stringify(this.sourceJourneys().find(item => item.journeyId === next.journeyId));
        this.gateIssues = [];
        this.editMessage = '';
        if (this.indexDraft) {
            this.indexDraft = syncJourneyIndex(this.indexDraft, next);
            this.indexDirty = JSON.stringify(this.indexDraft) !== JSON.stringify(this.data?.artifacts.journeyIndex.value);
        }
        this.dirty = this.journeyDirty || this.indexDirty;
    }
    updateBusiness(patch) {
        if (!this.journeyDraft)
            return;
        this.updateJourney({ ...this.journeyDraft, business: { ...this.journeyDraft.business, ...patch } });
    }
    updateStep(stepId, patch) {
        if (!this.journeyDraft)
            return;
        const steps = this.journeyDraft.business.steps.map(step => {
            if (step.stepId !== stepId)
                return step;
            const next = { ...step, ...patch };
            if (patch.kind) {
                if (next.kind !== 'act') {
                    delete next.effect;
                    delete next.transitionRef;
                    delete next.affects;
                }
                else if (!next.effect)
                    next.effect = 'update';
                if (next.kind !== 'handoff')
                    delete next.handoffTo;
                else if (!next.handoffTo)
                    next.handoffTo = this.actors()[0]?.actorId || '';
            }
            if (patch.entity && next.transitionRef) {
                const valid = journeyTransitions(this.entities(), next.entity, this.journeyDraft.business.actorRef)
                    .some(option => option.transitionId === next.transitionRef && option.eligible);
                if (!valid)
                    delete next.transitionRef;
            }
            if (patch.effect && next.effect !== 'transition')
                delete next.transitionRef;
            return next;
        });
        this.updateBusiness({ steps });
    }
    multiValues(event) {
        return [...event.currentTarget.selectedOptions].map(option => option.value);
    }
    addStep() {
        if (!this.journeyDraft)
            return;
        const id = this.newStepId.trim();
        if (!validNewJourneyStepId(this.journeyDraft, id)) {
            this.editMessage = this.t('journeys.invalidStepId');
            return;
        }
        const entity = this.entities()[0]?.entityId || '';
        const steps = [...this.journeyDraft.business.steps, {
                stepId: id, kind: 'locate', entity,
                title: this.t('journeys.newStepTitle'), description: this.t('journeys.newStepDescription'),
            }];
        this.updateBusiness({ steps });
        this.selectedStepId = id;
        this.creatingStep = false;
    }
    removeStep(stepId) {
        if (!globalThis.confirm(this.t('journeys.confirmRemoveStep')))
            return;
        if (this.journeyDraft)
            this.updateBusiness({ steps: this.journeyDraft.business.steps.filter(step => step.stepId !== stepId) });
        this.selectedStepId = '';
    }
    moveStep(stepId, targetStepId) {
        if (this.journeyDraft)
            this.updateJourney(moveJourneyStep(this.journeyDraft, stepId, targetStepId));
    }
    moveStepBy(stepId, offset) {
        if (!this.journeyDraft)
            return;
        const position = this.journeyDraft.business.steps.findIndex(step => step.stepId === stepId);
        const target = this.journeyDraft.business.steps[position + offset];
        if (target)
            this.moveStep(stepId, target.stepId);
    }
    addEvidence() {
        if (!this.journeyDraft)
            return;
        const evidence = [...this.journeyDraft.business.outcome.evidence, this.t('journeys.newEvidence')];
        this.updateBusiness({ outcome: { ...this.journeyDraft.business.outcome, evidence } });
    }
    updateEvidence(index, value) {
        if (!this.journeyDraft)
            return;
        const evidence = this.journeyDraft.business.outcome.evidence.map((item, position) => position === index ? value : item);
        this.updateBusiness({ outcome: { ...this.journeyDraft.business.outcome, evidence } });
    }
    removeEvidence(index) {
        if (!this.journeyDraft)
            return;
        const evidence = this.journeyDraft.business.outcome.evidence.filter((_, position) => position !== index);
        this.updateBusiness({ outcome: { ...this.journeyDraft.business.outcome, evidence } });
    }
    reorderJourney(journeyId, targetJourneyId) {
        if (!this.indexDraft)
            return;
        this.indexDraft = moveJourney(this.indexDraft, journeyId, targetJourneyId);
        this.indexDirty = true;
        this.dirty = true;
    }
    async saveEdit() {
        if (!this.journeyDraft || !this.indexDraft || !this.dirty)
            return;
        try {
            const [gate, contracts] = await Promise.all([
                import('/_102035_/l2/solution/gates/journeys20/gate.js'),
                import('/_102035_/l2/solution/gates/journeys20/contracts.js'),
            ]);
            const journeys = this.journeys();
            const result = gate.validateNs5Journeys(journeys.map(journey => ({ journeyId: journey.journeyId, business: journey.business })), { actors: this.actors(), moduleName: this.moduleName });
            this.gateIssues = result.issues.map(issue => ({ severity: issue.severity, message: issue.message }));
            if (!result.ok) {
                this.editMessage = this.t('journeys.gateBlocked');
                return;
            }
            const hashed = await contracts.hashNs5Journey({
                journeyId: this.journeyDraft.journeyId,
                business: structuredClone(this.journeyDraft.business),
            });
            const index = syncJourneyIndex(this.indexDraft, hashed);
            if (this.journeyDirty)
                await announceNewReleaseChange(this, { path: journeyPath(hashed.journeyId), jsonPath: '$', value: hashed });
            if (this.indexDirty)
                await announceNewReleaseChange(this, { path: 'journeys/index.defs.ts', jsonPath: '$', value: index });
            this.cancelEdit();
        }
        catch (error) {
            this.editMessage = this.t('journeys.gateUnavailable', { message: error instanceof Error ? error.message : String(error) });
        }
    }
    openEntity(entityId) {
        this.dispatchEvent(new CustomEvent('nr-navigate', { bubbles: true, composed: true, detail: { tab: 'ontology', entityId } }));
    }
    renderJourneyList() {
        const journeys = this.opened ? this.journeys().filter(j => j.journeyId === this.selectedJourneyId) : this.journeys();
        const actors = [...new Set(journeys.map(j => j.business.actorRef))];
        return html `${actors.map(actor => html `<section class="nr-journeys__group"><h3>${this.actorTitle(actor)}</h3><div class="nr-journeys__cards">${journeys.filter(j => j.business.actorRef === actor).map(journey => html `<button type="button" class=${this.opened ? 'is-active' : ''} @click=${() => { if (this.opened)
            this.journeyDetails = true;
        else
            this.selectJourney(journey.journeyId); }}><span>${renderNewReleaseIcon(journey.business.icon, 'route')}</span><div><strong>${journey.business.title}</strong>${changedDot(this.changedJourney(journey.journeyId), this.t)}</div></button>`)}</div></section>`)}`;
    }
    renderTransitions(step, journey) {
        const options = journeyTransitions(this.entities(), step.entity, journey.business.actorRef);
        if (!options.length)
            return nothing;
        return html `<div class="nr-step__exits"><span>${this.t('journeys.decisionExits')}</span>${options.map(option => html `<div class=${option.eligible ? '' : 'is-disabled'}><code>${option.from.join(' · ')}</code><b>→</b><code>${option.to}</code><small>${option.description}</small></div>`)}</div>`;
    }
    renderStepEdit(step) {
        const transitions = journeyTransitions(this.entities(), step.entity, this.journeyDraft?.business.actorRef || '');
        return html `<div class="nr-step__edit"><label><span>${this.t('journeys.stepId')}</span><input readonly .value=${step.stepId}></label>
      <new-release--widgets--icon-picker-102035 .value=${step.icon || ''} .fallback=${JOURNEY_ICON_DEFAULTS[step.kind]} .t=${this.t} @nr-icon-selected=${(event) => {
            if (!this.journeyDraft)
                return;
            this.updateBusiness({ steps: this.journeyDraft.business.steps.map(item => item.stepId === step.stepId ? withNewReleaseIcon(item, event.detail) : item) });
        }}></new-release--widgets--icon-picker-102035>
      <label><span>${this.t('journeys.decisionRef')}</span><select .value=${step.decisionRef || ''} @change=${(event) => this.updateStep(step.stepId, { decisionRef: event.currentTarget.value || undefined })}><option value="" ?selected=${!step.decisionRef}>${this.t('journeys.noDecisionRef')}</option>${(this.journeyDraft?.business.steps || []).filter(item => item.kind === 'decide' && item.stepId !== step.stepId).map(item => html `<option value=${item.stepId} ?selected=${step.decisionRef === item.stepId}>${item.title}</option>`)}</select></label>
      <label><span>${this.t('journeys.stepTitle')}</span><input .value=${step.title} @input=${(event) => this.updateStep(step.stepId, { title: event.currentTarget.value })}></label>
      <label><span>${this.t('journeys.kind')}</span><select .value=${step.kind} @change=${(event) => this.updateStep(step.stepId, { kind: event.currentTarget.value })}>${JOURNEY_STEP_KINDS.map(kind => html `<option value=${kind} ?selected=${step.kind === kind}>${this.t(`journeys.kind.${kind}`)}</option>`)}</select></label>
      <label><span>${this.t('journeys.entity')}</span><select .value=${step.entity} @change=${(event) => this.updateStep(step.stepId, { entity: event.currentTarget.value })}>${this.entities().map(entity => html `<option value=${entity.entityId} ?selected=${step.entity === entity.entityId}>${entity.title}</option>`)}</select></label>
      <label class="is-wide"><span>${this.t('journeys.stepDescription')}</span><textarea .value=${step.description} @input=${(event) => this.updateStep(step.stepId, { description: event.currentTarget.value })}></textarea></label>
      ${step.kind === 'act' ? html `<label><span>${this.t('journeys.effect')}</span><select .value=${step.effect || 'update'} @change=${(event) => this.updateStep(step.stepId, { effect: event.currentTarget.value })}><option value="create" ?selected=${step.effect === 'create'}>${this.t('journeys.effect.create')}</option><option value="update" ?selected=${!step.effect || step.effect === 'update'}>${this.t('journeys.effect.update')}</option><option value="transition" ?selected=${step.effect === 'transition'}>${this.t('journeys.effect.transition')}</option></select></label>
      <label><span>${this.t('journeys.affects')}</span><select multiple @change=${(event) => this.updateStep(step.stepId, { affects: this.multiValues(event) })}>${this.entities().filter(entity => entity.entityId !== step.entity).map(entity => html `<option value=${entity.entityId} ?selected=${step.affects?.includes(entity.entityId)}>${entity.title}</option>`)}</select></label>
      ${step.effect === 'transition' ? html `<label class="is-wide"><span>${this.t('journeys.transition')}</span><select .value=${step.transitionRef || ''} @change=${(event) => this.updateStep(step.stepId, { transitionRef: event.currentTarget.value })}><option value="" ?selected=${!step.transitionRef}>${this.t('journeys.chooseTransition')}</option>${transitions.map(option => html `<option value=${option.transitionId} ?selected=${step.transitionRef === option.transitionId} ?disabled=${!option.eligible}>${option.transitionId} · ${option.from.join(', ')} → ${option.to}${option.eligible ? '' : ` · ${this.t('journeys.notAllowed')}`}</option>`)}</select></label>` : nothing}` : nothing}
      ${step.kind === 'handoff' ? html `<label><span>${this.t('journeys.handoffTo')}</span><select .value=${step.handoffTo || ''} @change=${(event) => this.updateStep(step.stepId, { handoffTo: event.currentTarget.value })}>${this.actors().map(actor => html `<option value=${actor.actorId} ?selected=${step.handoffTo === actor.actorId}>${actor.title}</option>`)}</select></label>` : nothing}
    </div>`;
    }
    renderStepCard(step, journeyId) {
        return html `<button class=${`nr-step__open ${step.kind === 'decide' ? 'is-decision' : ''}`} type="button" @click=${() => this.openStep(journeyId, step.stepId)}><span>${renderNewReleaseIcon(step.icon, JOURNEY_ICON_DEFAULTS[step.kind])}</span><strong>${step.title}</strong>${changedDot(this.changedStep(journeyId, step.stepId), this.t)}</button>`;
    }
    renderTimeline(journey) {
        return html `<ol class="nr-journeys__timeline" aria-label=${this.t('journeys.path')}>${journeyStepGroups(journey).map(({ step, branches }) => {
            return html `<li>${this.renderStepCard(step, journey.journeyId)}${branches.length ? html `<ol class="nr-journeys__branches">${branches.map(branch => html `<li>${this.renderStepCard(branch, journey.journeyId)}</li>`)}</ol>` : nothing}</li>`;
        })}</ol>`;
    }
    renderIssues(journey) {
        const source = [...(this.data?.validation.issues || []), ...this.suppliedIssues];
        const issues = [...new Map(journeyIssues(source, journey.journeyId).map(issue => [`${issue.code}:${issue.message}`, issue])).values()];
        const all = [...issues.map(issue => ({ severity: issue.severity, message: issue.message, code: issue.code })), ...this.gateIssues.map(issue => ({ ...issue, code: 'gate' }))];
        if (!all.length && !this.editMessage)
            return nothing;
        return html `<section class="nr-journeys__issues" role="alert"><strong>${this.t('journeys.issues')}</strong>${this.editMessage ? html `<p>${this.editMessage}</p>` : nothing}${all.map(issue => html `<div class=${`is-${issue.severity}`}><span>${issue.code}</span><p>${issue.message}</p></div>`)}</section>`;
    }
    renderDetail(journey) {
        const step = journey.business.steps.find(item => item.stepId === this.selectedStepId);
        return html `<main class="nr-journeys__detail">
      ${this.renderIssues(journey)}
      ${this.creatingStep ? html `<label>${this.t('journeys.stepId')}<input .value=${this.newStepId} @input=${(e) => { this.newStepId = e.currentTarget.value; }}></label><button class="nr-button" @click=${() => this.addStep()}>${this.t('journeys.addStep')}</button>`
            : step ? html `<h2>${step.title}</h2>${this.mode === 'edit' ? this.renderStepEdit(step) : html `<code>${step.stepId}</code><p>${step.description}</p><p>${this.entityTitle(step.entity)} · ${this.t(`journeys.kind.${step.kind}`)}</p>${!this.version.startsWith('release:') ? html `<button class="nr-button" @click=${this.openJourneyEdit}>${this.t('journeys.edit')}</button>` : nothing}`}${this.mode === 'edit' ? html `<button class="nr-button" @click=${() => this.removeStep(step.stepId)}>${this.t('journeys.removeStep')}</button>` : nothing}`
                : this.mode === 'edit' ? html `<new-release--widgets--icon-picker-102035 .value=${journey.business.icon || ''} fallback="route" .t=${this.t} @nr-icon-selected=${(event) => { if (this.journeyDraft)
                    this.updateJourney({ ...this.journeyDraft, business: withNewReleaseIcon(this.journeyDraft.business, event.detail) }); }}></new-release--widgets--icon-picker-102035><label>${this.t('journeys.journey')}<input .value=${journey.business.title} @input=${(e) => this.updateBusiness({ title: e.currentTarget.value })}></label><label>${this.t('journeys.goal')}<textarea .value=${journey.business.goal} @input=${(e) => this.updateBusiness({ goal: e.currentTarget.value })}></textarea></label><code>${journey.journeyId}</code>`
                    : html `<header><h2>${journey.business.title}</h2></header><label><span>${this.t('journeys.goal')}</span><p>${journey.business.goal}</p></label><section class="nr-journeys__outcome"><header><div><small>${this.t('journeys.outcome')}</small><h3>${journey.business.outcome.statement}</h3></div></header><div><strong>${this.t('journeys.evidence')}</strong>${journey.business.outcome.evidence.map(e => html `<p>${e}</p>`)}</div></section>${!this.version.startsWith('release:') ? html `<div class="nr-journeys__actions"><button class="nr-button" @click=${this.openJourneyEdit}>${this.t('journeys.edit')}</button><button class="nr-button" @click=${this.openNewStep}>${this.t('journeys.addStep')}</button></div>` : nothing}`}
    </main>`;
    }
    render() {
        const journey = this.currentJourney();
        return html `<section class="nr-journeys">${this.journeyDetails || this.selectedStepId || this.creatingStep || this.mode === 'edit' ? (journey ? this.renderDetail(journey) : nothing) : html `${this.renderJourneyList()}${this.opened && journey ? this.renderTimeline(journey) : nothing}`}${this.mode === 'edit' ? html `<footer class="nr-journeys__edit-footer"><span>${this.dirty ? this.t('journeys.unsaved') : this.t('journeys.noChanges')}</span><div><button @click=${() => { if (canDiscardNewReleaseDraft(this))
            this.cancelEdit(); }}>${this.t('journeys.cancel')}</button><button class="is-primary" ?disabled=${!this.dirty} @click=${() => void this.saveEdit()}>${this.t('journeys.save')}</button></div></footer>` : nothing}</section>`;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseJourneys102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseJourneys102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseJourneys102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseJourneys102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseJourneys102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseJourneys102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseJourneys102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "selectedJourneyId", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "opened", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "journeyDetails", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "selectedStepId", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "newStepId", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "creatingStep", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "view", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "journeyDraft", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "indexDraft", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "suppliedIssues", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "gateIssues", void 0);
__decorate([
    state()
], NewReleaseJourneys102035.prototype, "editMessage", void 0);
NewReleaseJourneys102035 = __decorate([
    customElement('new-release--widgets--journeys-102035')
], NewReleaseJourneys102035);
export { NewReleaseJourneys102035 };
