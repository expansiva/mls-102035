var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102035_/l2/newRelease/widgets/review/review.ts" enhancement="_102027_/l2/enhancementLit" />
import { discardModuleInStudio } from '/_102020_/l2/aura/helpers/draftModuleDiscard.js';
import { completeTobeImplementation } from '/_102035_/l2/newRelease/tobe.js';
import { effortMatchesCurrent } from '/_102035_/l2/newRelease/helpers/effortFreshness.js';
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { NEW_RELEASE_IMPLEMENTATION_STATE_EVENT, NEW_RELEASE_TOBE_UPDATED_EVENT } from '/_102035_/l2/newRelease/helpers/context.js';
import { readModuleMenu } from '/_102035_/l2/newRelease/helpers/menuReader.js';
import { readReviewArtifact, reviewArtifactFile } from '/_102035_/l2/newRelease/helpers/backendReader.js';
import { readReviewPoolBoxes } from '/_102035_/l2/newRelease/helpers/poolBoxes.js';
import { IndexedDbReviewRunStore } from '/_102035_/l2/newRelease/helpers/reviewRunStore.js';
import { readCandidateWorkerGate } from '/_102035_/l2/newRelease/helpers/candidateWorkerGate.js';
import { buildCandidateSnapshot, candidateRead } from '/_102035_/l2/solution/candidate/candidateGateway.js';
import { adoptL4ReviewResult, originalL4FileInfo, promoteL4Revision, readSealedL4Candidate, prepareL4Change, sealL4Revision, readActiveL4Change, withModuleWriter } from '/_102035_/l2/solution/candidate/moduleRevision.js';
import { executePreparedReviewStart, prepareReviewStartInput } from '/_102035_/l2/newRelease/helpers/reviewStart.js';
import { readJson, readSourceText, writeJson } from '/_102035_/l2/solution/fs.js';
import { sealModuleLayers, sealModuleApplication, compactModuleApplication, restoreModuleApplication, restoreModuleFromSeals, diffModuleLayers } from '/_102035_/l2/solution/candidate/moduleLayers.js';
import { readLatestCompletedL4Implementation, implementationCommands, acceptL4Implementation, readL4Implementation, recordL4ImplementationPhase, readInitialImplementationPlan } from '/_102035_/l2/solution/candidate/moduleImplementation.js';
import { createImplementationRunner } from '/_102035_/l2/newRelease/helpers/implementationRunner.js';
import { environment } from '/_102036_/l2/environmentContract.js';
import { msgGetMessage, msgGetMessagesAfter, msgGetTaskUpdate } from '/_102036_/l2/shared/api.js';
import { resolveModuleThread } from '/_102035_/l2/newRelease/helpers/moduleThread.js';
import { serializeReviewInvocation } from '/_102035_/l2/agentReviewSolution/helpers/invocation.js';
import { taskResultTexts } from '/_102035_/l2/newRelease/helpers/agentCommandRunner.js';
import { listConfirmedRounds } from '/_102035_/l2/newRelease/helpers/roundHistory.js';
import { getUserId, getTemporaryContext } from '/_102025_/l2/collabMessagesHelper.js';
import { dispatchThreadOpen } from '/_102025_/l2/collabMessagesEvents.js';
import { addOrUpdateTask, getTask } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { getAllMessagesByThreadId } from '/_102036_/l2/collabMessagesIndexedDB.js';
import '/_102025_/l2/collabMessagesTask.js';
import { claimInputForRun, publishedCandidateMatchesRunRevision, REVIEW_RUN_MAX_ATTEMPTS, reviewRunMatchesRevision, } from '/_102035_/l2/newRelease/helpers/reviewRunWorker.js';
import { createReviewStudioHost, createReviewWorkerTransport, driveReviewRunWorker, observeReviewRun, outputRevisionIdForRun, readReviewRunLink, saveReviewRunLink, startReviewRun, } from '/_102035_/l2/newRelease/helpers/reviewRunStudioWorker.js';
import { reviewImplementationVisible, moduleHasGeneratedSources, reviewReleaseState, actorIdFromKey, beginReviewPrimaryAction, buildReviewActionPresentation, buildReviewView, canStartReviewRun, canAcceptImplementation, implementationProgress, openReviewExpansionKeys, REVIEW_ALL_ACTORS, reviewExpansionKey, reviewResultVisible, toggleReviewExpansion, toggleReviewSelection, } from '/_102035_/l2/newRelease/widgets/review/reviewModel.js';
import { buildChangeEffortView } from '/_102035_/l2/newRelease/widgets/review/changeEffortModel.js';
import { MENU_ACTIONS } from '/_102035_/l2/solution/poolPlan.js';
import { backendTone, buildBackendReview, parseEffortSummary } from '/_102035_/l2/newRelease/widgets/review/backendReviewModel.js';
const POLL_INTERVAL_MS = 1500;
export function observeImplementationTask(previous, taskId, lastUpdated, status, startedAt, now) {
    const timestamp = Number.isFinite(lastUpdated) && lastUpdated > 0 ? lastUpdated : 0;
    const same = previous?.taskId === taskId;
    const changed = same && timestamp !== previous.lastUpdated;
    const advanced = same && timestamp > previous.lastUpdated;
    const started = Date.parse(startedAt);
    const unchangedSince = timestamp || (same ? previous.unchangedSince
        : Number.isFinite(started) && started > 0 ? started : now);
    const paused = status === 'in progress' && ((same && previous.paused && !advanced)
        || now - unchangedSince >= 10 * 60 * 1000);
    return { taskId, lastUpdated: timestamp, unchangedSince,
        interval: same && !changed ? Math.min(previous.interval * 2, 30000) : POLL_INTERVAL_MS,
        paused };
}
const EMPTY_MENU = { status: 'missing', path: '' };
const EMPTY_ARTIFACT = { status: 'missing', path: '' };
function applicationCheckpointInfo(project, moduleName) {
    return { project, level: 4, folder: `${moduleName}/pipeline/application`, shortName: 'undo', extension: '.json' };
}
function hasApplicationCheckpoint(project, moduleName) {
    const info = applicationCheckpointInfo(project, moduleName);
    return Object.values(mls.stor.files).some(file => !!file && file.project === project && file.level === info.level
        && file.folder === info.folder && file.shortName === info.shortName && file.extension === info.extension && file.status !== 'deleted');
}
async function applicationCancelRequested(project, moduleName, changeId, revisionId) {
    const seal = await readJson(applicationCheckpointInfo(project, moduleName));
    return !!seal && seal.changeId === changeId && seal.revisionId === revisionId && seal.cancelRequested === true;
}
async function requestApplicationCancel(project, moduleName, changeId, revisionId) {
    await withModuleWriter(project, moduleName, async () => {
        const info = applicationCheckpointInfo(project, moduleName);
        const seal = await readJson(info);
        if (!seal || seal.changeId !== changeId || seal.revisionId !== revisionId)
            throw new Error('module-application.invalid_seal');
        if (!seal.cancelRequested)
            await writeJson(info, { ...seal, cancelRequested: true });
    });
}
export async function reviewInitialCandidate(sealed, userId, dependencies = {}) {
    const { project, moduleName, changeId, revisionId, baseId } = sealed.manifest;
    const prepared = await (dependencies.prepare ?? prepareReviewStartInput)({ project, moduleName, changeId, revisionId, request: sealed.request, userId, loaded: sealed });
    const invocation = { project, moduleName, baseId, request: sealed.request,
        originalL4Path: `l4/${moduleName}/pipeline/releases/${baseId}/l4`, temporaryL4Path: `l4/${moduleName}/tobe/plan`, expectedRevisionId: revisionId };
    const thread = await (dependencies.thread?.() ?? (dependencies.moduleThread ?? resolveModuleThread)(project, moduleName));
    if (!thread?.threadId)
        throw new Error('implementation.thread_unavailable');
    const ctx = (dependencies.context ?? getTemporaryContext)(thread.threadId, userId, '@@agentReviewSolution ' + serializeReviewInvocation(invocation));
    await (dependencies.execute ?? ((agent, context) => environment.agents.executeAgent(agent, context)))('agentReviewSolution', ctx);
    if (!ctx.task?.PK)
        throw new Error('implementation.task_unavailable');
    let task = ctx.task;
    const taskId = task.PK.replace(/^task(?:\/#?|#)/u, '');
    const messageId = task.messageid_created || `${ctx.message.threadId}/${ctx.message.orderAt || ctx.message.createAt}`;
    while (!['done', 'failed', 'paused'].includes(task.status)) {
        await (dependencies.wait ?? (() => new Promise(resolve => window.setTimeout(resolve, POLL_INTERVAL_MS))))();
        if (dependencies.task)
            task = await dependencies.task(userId, taskId, messageId);
        else {
            const update = await msgGetTaskUpdate({ userId, taskId, messageId });
            if (!update.success || !update.response?.task)
                throw new Error(update.error || 'implementation.task_unavailable');
            task = update.response.task;
        }
        if (task.PK.replace(/^task(?:\/#?|#)/u, '') !== taskId)
            throw new Error('implementation.task_mismatch');
    }
    const message = dependencies.message ? await dependencies.message(userId, thread.threadId, messageId)
        : (await msgGetMessage({ userId, threadId: thread.threadId, messageId })).response?.message;
    const reports = [...taskResultTexts(task), ...(message?.taskResults ?? [])].join('\n');
    const refusal = reports.split('\n').map(line => line.trim()).find(line => /^(?:refused|failed):/u.test(line));
    if (refusal || task.status !== 'done')
        throw new Error(refusal || task.last_update_log || 'review.implementation.error.run');
    const candidate = await (dependencies.candidate ?? candidateRead)({ project, moduleName });
    const pointer = candidate.pointer;
    const result = pointer && candidate.result;
    if (!pointer || pointer.changeId !== changeId || !result
        || result.resultRevisionId !== revisionId || result.resultSnapshotHash !== prepared.input.inputSnapshotHash.replace(/^sha256:/u, '')
        || result.manifest.status !== 'completed')
        throw new Error('l4.implementation_conflict');
    const gateRun = {
        runId: taskId, status: 'reviewing', attempt: 1,
        binding: { ...prepared.input, runId: taskId, inputRevisionNumber: result.resultRevisionNumber,
            originalL4Path: invocation.originalL4Path, temporaryL4Path: invocation.temporaryL4Path },
        candidateResult: { ...result }, executions: [], plannerArtifacts: [], errorCode: null, createdAt: '', updatedAt: '',
    };
    const outputRevisionId = outputRevisionIdForRun(gateRun);
    const inputPointer = pointer.revisionId === revisionId && pointer.snapshotHash === result.resultSnapshotHash
        && pointer.revisionNumber === result.resultRevisionNumber;
    const publishedPointer = outputRevisionId && publishedCandidateMatchesRunRevision(gateRun, outputRevisionId, candidate)
        && pointer.snapshotHash === result.manifest.outputSnapshotHash && pointer.source?.revisionId === revisionId
        && pointer.source.snapshotHash === result.resultSnapshotHash && pointer.source.revisionNumber === result.resultRevisionNumber;
    if (!inputPointer && !publishedPointer)
        throw new Error('l4.implementation_conflict');
    const gate = await (dependencies.gate ?? readCandidateWorkerGate)(gateRun);
    if (!outputRevisionId || !gate.pipelineComplete)
        throw new Error('l4.implementation_not_ready');
    const output = await (dependencies.readSealed ?? readSealedL4Candidate)(project, moduleName, changeId, outputRevisionId);
    if (!output)
        throw new Error('l4.implementation_not_ready');
    const snapshot = await buildCandidateSnapshot({ baseId, requestRevision: output.manifest.requestRevision, request: output.request, sources: output.sources });
    if (result.manifest.outputSnapshotHash !== snapshot.hash)
        throw new Error('l4.implementation_conflict');
    await (dependencies.adopt ?? adoptL4ReviewResult)(project, moduleName, { inputRevisionId: revisionId, outputRevisionId });
    const active = await (dependencies.active ?? readActiveL4Change)(project, moduleName);
    if (active?.activeRevisionId !== outputRevisionId || active.resultRevisionId !== outputRevisionId)
        throw new Error('l4.implementation_conflict');
    return output;
}
/** Exact Apply handler seam, including the neutral revision when no change is active. */
export async function applyInitialReview(input, dependencies = {}) {
    const current = () => { if (dependencies.current && !dependencies.current())
        throw new Error('l4.implementation_conflict'); };
    current();
    const { project, moduleName, acceptedBy } = input;
    if (!acceptedBy)
        throw new Error('implementation.user_unavailable');
    const plan = await (dependencies.plan ?? readInitialImplementationPlan)(project, moduleName);
    current();
    const prepared = await (dependencies.prepare ?? prepareL4Change)(project, moduleName);
    if ((input.changeId ? prepared.change.changeId !== input.changeId : !prepared.created)
        || prepared.change.activeRevisionId !== input.revisionId)
        throw new Error('l4.implementation_conflict');
    current();
    const revision = await (dependencies.seal ?? sealL4Revision)(project, moduleName, input.revisionId);
    let sealed = await (dependencies.readSealed ?? readSealedL4Candidate)(project, moduleName, prepared.change.changeId, revision.revisionId);
    if (!sealed)
        throw new Error('l4.implementation_not_ready');
    current();
    if (sealed.manifest.changedPaths.length)
        sealed = await (dependencies.review ?? reviewInitialCandidate)(sealed, acceptedBy);
    current();
    const { changeId, revisionId, baseId } = sealed.manifest;
    await (dependencies.sealApplication ?? sealModuleApplication)(project, moduleName, changeId, revisionId);
    try {
        await (dependencies.sealLayers ?? sealModuleLayers)(project, moduleName, baseId);
        current();
        await (dependencies.promote ?? promoteL4Revision)(project, moduleName, changeId, revisionId);
        current();
        return await (dependencies.accept ?? acceptL4Implementation)(project, moduleName, { kind: 'initial', revisionId, acceptedBy, plan });
    }
    catch (error) {
        await (dependencies.restoreApplication ?? restoreModuleApplication)(project, moduleName, changeId, revisionId);
        throw error;
    }
}
let NewReleaseReview102035 = class NewReleaseReview102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--review-102035 {
  color-scheme: dark;
  --page-bg: #0d1117;
  --surface-bg: #161b22;
  --surface-alt-bg: #1c2330;
  --text-strong: #f0f4fc;
  --text-default: #d0d8e8;
  --text-muted: #92a0b8;
  --border-subtle: #303b50;
  --border-default: #46546d;
  --link-text: #8fb9ff;
  --selected-bg: #223854;
  --selected-text: #bdd6ff;
  --selected-border: #6198e8;
  --focus-ring: #83b4ff;
  background: var(--page-bg);
  color: var(--text-default);
  font-family: var(--font-family, system-ui, sans-serif);
  line-height: 1.5;
  overflow-wrap: anywhere;
  display: block;
}
new-release--widgets--review-102035 button,
new-release--widgets--review-102035 input,
new-release--widgets--review-102035 select,
new-release--widgets--review-102035 textarea {
  font: inherit;
}
new-release--widgets--review-102035 button:focus-visible,
new-release--widgets--review-102035 summary:focus-visible {
  outline: 2px solid var(--focus-ring);
  outline-offset: 3px;
}
new-release--widgets--review-102035 * {
  box-sizing: border-box;
}
new-release--widgets--review-102035 h2,
new-release--widgets--review-102035 h3,
new-release--widgets--review-102035 p,
new-release--widgets--review-102035 ul,
new-release--widgets--review-102035 li {
  margin: 0;
}
new-release--widgets--review-102035 button,
new-release--widgets--review-102035 select {
  font: inherit;
}
new-release--widgets--review-102035 button {
  cursor: pointer;
}
new-release--widgets--review-102035 code {
  font-family: var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--review-102035 select {
  min-height: 2.25rem;
  width: 100%;
  padding: 0.42rem 0.58rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--review-102035 select:focus {
  border-color: var(--focus-border, #1273d4);
  outline: 2px solid color-mix(in srgb, var(--focus-border, #1273d4) 20%, transparent);
}
new-release--widgets--review-102035 .nr-review {
  display: grid;
  min-width: 0;
  color: var(--text-default, #2f3a48);
  container-type: inline-size;
}
new-release--widgets--review-102035 .nr-review__panel {
  margin: 0.85rem 1.25rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.7rem;
  overflow: hidden;
}
new-release--widgets--review-102035 .nr-review__text-detail {
  margin: 0.5rem 0.9rem;
  padding: 0.35rem 0.25rem;
  border: 0;
  border-radius: 0;
  background: transparent;
  font-size: 12px;
}
new-release--widgets--review-102035 .nr-review__text-detail > summary {
  display: list-item;
  padding: 0.25rem 0;
  cursor: pointer;
  font-size: 12px;
  font-weight: 400;
}
new-release--widgets--review-102035 .nr-review__text-detail > summary span {
  margin-left: 0.6rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 12px;
}
new-release--widgets--review-102035 .nr-review__text-detail > p,
new-release--widgets--review-102035 .nr-review__text-detail > section,
new-release--widgets--review-102035 .nr-review__text-detail > details {
  margin: 0.55rem 0.35rem;
}
new-release--widgets--review-102035 .nr-review__detail-copy {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin: 0.4rem 0.35rem 0.7rem;
}
new-release--widgets--review-102035 .nr-review__detail-copy button {
  padding: 0.25rem 0.55rem;
  border: 1px solid var(--border-default);
  border-radius: 0.35rem;
  background: var(--surface-bg);
  color: var(--text-default);
  font-size: 12px;
}
new-release--widgets--review-102035 .nr-review__effort-panel > .nr-index__diff {
  margin: 0.6rem 0.85rem;
}
new-release--widgets--review-102035 .nr-review__panel > h3 {
  margin: 0.85rem;
  font-size: 0.95rem;
}
new-release--widgets--review-102035 .nr-review__panel-note {
  margin: 0.85rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__effort-panel > .nr-review__primary-action,
new-release--widgets--review-102035 .nr-review__apply > .nr-review__primary-action {
  padding: 0.85rem;
}
new-release--widgets--review-102035 .nr-review__progress {
  display: grid;
  gap: 0.45rem;
  padding: 0.8rem 1rem;
  color: var(--text-default);
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__progress progress,
new-release--widgets--review-102035 .nr-review__implementation progress {
  width: 100%;
  height: 0.55rem;
  accent-color: var(--selected-border);
}
new-release--widgets--review-102035 .nr-review__hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.2rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: linear-gradient(135deg, var(--surface-bg, #fff), color-mix(in srgb, var(--selected-bg, #e3f1ff) 46%, var(--surface-bg, #fff)));
}
new-release--widgets--review-102035 .nr-review__hero span,
new-release--widgets--review-102035 .nr-review__detail > header span,
new-release--widgets--review-102035 .nr-review__detail section > span,
new-release--widgets--review-102035 .nr-review__pool summary,
new-release--widgets--review-102035 .nr-review__pool h3,
new-release--widgets--review-102035 .nr-review__toolbar label span,
new-release--widgets--review-102035 .nr-review__removed > summary {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 800;
  letter-spacing: 0.11em;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__hero h2 {
  margin-top: 0.28rem;
  color: var(--text-strong, #111827);
  font-size: 1.5rem;
  letter-spacing: -0.03em;
}
new-release--widgets--review-102035 .nr-review__hero p {
  max-width: 46rem;
  margin-top: 0.42rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--review-102035 .nr-review__primary-action {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(11rem, 15rem);
  align-items: center;
  gap: 0.8rem 1.25rem;
  padding: 1rem 1.25rem;
  background: color-mix(in srgb, var(--selected-bg, #e3f1ff) 38%, var(--surface-bg, #fff));
}
new-release--widgets--review-102035 .nr-review__primary-action.is-top {
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--review-102035 .nr-review__primary-action.is-bottom {
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--review-102035 .nr-review__primary-action.has-undo {
  grid-template-columns: minmax(0, 1fr) minmax(20rem, 27rem);
}
new-release--widgets--review-102035 .nr-review__primary-action > div {
  display: grid;
  min-width: 0;
  gap: 0.22rem;
}
new-release--widgets--review-102035 .nr-review__primary-action > .nr-review__action-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}
new-release--widgets--review-102035 .nr-review__action-buttons > button {
  flex: 1 1 10rem;
  width: auto;
}
new-release--widgets--review-102035 .nr-review__primary-action > div > span {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 800;
  letter-spacing: 0.11em;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__primary-action p {
  color: var(--text-default, #2f3a48);
  font-size: 0.78rem;
  line-height: 1.5;
}
new-release--widgets--review-102035 .nr-review__primary-action small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.67rem;
}
new-release--widgets--review-102035 .nr-review__primary-action .nr-review__action-error {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--review-102035 .nr-review__primary-action button {
  min-height: 2.75rem;
  width: 100%;
  padding: 0.65rem 1rem;
  border: 1px solid var(--button-primary-bg, #1273d4);
  border-radius: 0.7rem;
  background: var(--button-primary-bg, #1273d4);
  color: var(--button-primary-text, #fff);
  font: inherit;
  font-size: 0.82rem;
  font-weight: 800;
}
new-release--widgets--review-102035 .nr-review__primary-action button:disabled {
  border-color: var(--button-primary-bg-disabled, #b9d6f2);
  background: var(--button-primary-bg-disabled, #b9d6f2);
  color: var(--button-primary-text-disabled, #657689);
  cursor: not-allowed;
}
new-release--widgets--review-102035 .nr-review__primary-action .nr-review__undo-action {
  border-color: var(--border-strong, #71849c);
  background: var(--surface-bg, #fff);
  color: var(--text-strong, #111827);
}
new-release--widgets--review-102035 .nr-review__undo-feedback {
  margin: 0.5rem 0.85rem;
  color: var(--text-default, #2f3a48);
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__run {
  display: grid;
  gap: 0.55rem;
  padding: 0.85rem 1.25rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__run > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.6rem 1rem;
}
new-release--widgets--review-102035 .nr-review__run > header span {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 800;
  letter-spacing: 0.11em;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__run > header h3 {
  margin-top: 0.15rem;
  color: var(--text-strong, #111827);
  font-size: 0.95rem;
}
new-release--widgets--review-102035 .nr-review__run > header strong {
  color: var(--text-default, #2f3a48);
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__run > p {
  color: var(--status-error-text, #ab2328);
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__run dl {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem 1rem;
  margin: 0;
}
new-release--widgets--review-102035 .nr-review__run dl div {
  min-width: min(100%, 12rem);
}
new-release--widgets--review-102035 .nr-review__run dt {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__run dd {
  margin: 0.08rem 0 0;
  overflow-wrap: anywhere;
  font-size: 0.66rem;
}
new-release--widgets--review-102035 .nr-review__copy-actions {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.5rem;
}
new-release--widgets--review-102035 .nr-review__copy-actions button {
  min-height: 2.25rem;
  padding: 0.42rem 0.7rem;
  border: 1px solid var(--link-text, #8fb9ff);
  border-radius: 0.5rem;
  background: transparent;
  color: var(--link-text, #8fb9ff);
  font-size: 0.75rem;
}
new-release--widgets--review-102035 .nr-review__copy-actions span {
  color: var(--text-muted, #92a0b8);
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__run.is-ready > header strong {
  color: var(--status-success-text, #25640e);
}
new-release--widgets--review-102035 .nr-review__run.is-failed > header strong,
new-release--widgets--review-102035 .nr-review__run.is-disputed > header strong {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--review-102035 .nr-review__implementation {
  min-width: 0;
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__implementation progress {
  display: block;
}
new-release--widgets--review-102035 .nr-review__task-card {
  display: flex;
  align-items: center;
  box-sizing: border-box;
  width: min(100%, 220px);
  height: 40px;
  margin: 0.45rem 0;
}
new-release--widgets--review-102035 .nr-review__task-card .card {
  box-sizing: border-box;
  min-width: 0;
  padding: 0 0.6rem;
}
new-release--widgets--review-102035 .nr-review__task-card .card-header {
  min-width: 0;
}
new-release--widgets--review-102035 .nr-review__task-card .card-title {
  min-width: 0;
  flex: 1 1 auto;
}
new-release--widgets--review-102035 .nr-review__task-card .card-price,
new-release--widgets--review-102035 .nr-review__task-card .task-icon {
  flex: none;
}
new-release--widgets--review-102035 .nr-review__task-loading {
  display: flex;
  align-items: center;
  box-sizing: border-box;
  width: min(100%, 220px);
  height: 40px;
  padding: 0 0.7rem;
  border-radius: 0.6rem;
  background: #fff;
  color: #334155;
  margin: 0.45rem 0;
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__review-task,
new-release--widgets--review-102035 .nr-review__effort-panel > .nr-review__task-loading {
  margin: 0.6rem 0.85rem 0.85rem;
}
new-release--widgets--review-102035 .nr-review__task-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 0.65rem 1rem;
  padding: 0.85rem;
}
new-release--widgets--review-102035 .nr-review__task-slot {
  min-width: 0;
}
new-release--widgets--review-102035 .nr-review__task-slot > span {
  display: block;
  color: var(--text-muted);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__implementation-details {
  margin: 0.5rem 0.9rem;
  padding: 0.35rem 0.25rem;
  border: 0;
  border-radius: 0;
}
new-release--widgets--review-102035 .nr-review__implementation-details > summary {
  cursor: pointer;
}
new-release--widgets--review-102035 .nr-review__history > details {
  padding: 0.85rem;
}
new-release--widgets--review-102035 .nr-review__round {
  margin: 0.7rem 0;
  padding: 0.65rem;
  border: 1px solid var(--border-subtle);
  border-radius: 0.5rem;
}
new-release--widgets--review-102035 .nr-review__round pre {
  overflow: auto;
  white-space: pre-wrap;
}
new-release--widgets--review-102035 .nr-review__phase-report pre {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
new-release--widgets--review-102035 .nr-review__implementation ol {
  display: grid;
  gap: 0.7rem;
  margin: 0;
  padding-left: 1.2rem;
}
new-release--widgets--review-102035 .nr-review__implementation li {
  min-width: 0;
  overflow-wrap: anywhere;
}
new-release--widgets--review-102035 .nr-review__phase-heading {
  display: flex;
  flex-wrap: wrap;
  gap: 0.3rem 0.75rem;
  align-items: baseline;
}
new-release--widgets--review-102035 .nr-review__phase-heading small {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review__implementation .is-concluido > .nr-review__phase-heading > span {
  color: var(--status-success-text, #25640e);
}
new-release--widgets--review-102035 .nr-review__implementation .is-falhou > .nr-review__phase-heading > span,
new-release--widgets--review-102035 .nr-review__implementation-error {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--review-102035 .nr-review__implementation summary {
  padding: 0.4rem 0;
  cursor: pointer;
}
new-release--widgets--review-102035 .nr-review__implementation ul {
  padding-left: 1.2rem;
}
new-release--widgets--review-102035 .nr-review__implementation code {
  overflow-wrap: anywhere;
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__implementation .nr-review__implementation-note {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review__implementation-level {
  padding: 0.25rem 0.7rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.5rem;
}
new-release--widgets--review-102035 .nr-review__implementation button {
  justify-self: start;
  margin-top: 0.35rem;
  padding: 0.5rem 0.8rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.5rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--review-102035 .nr-review__implementation button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
new-release--widgets--review-102035 .nr-review__loading,
new-release--widgets--review-102035 .nr-review__empty,
new-release--widgets--review-102035 .nr-review__pending {
  display: grid;
  gap: 0.45rem;
  padding: 1.4rem 1.25rem;
}
new-release--widgets--review-102035 .nr-review__empty h3,
new-release--widgets--review-102035 .nr-review__pending h3 {
  color: var(--text-strong, #111827);
  font-size: 1.05rem;
}
new-release--widgets--review-102035 .nr-review__empty p,
new-release--widgets--review-102035 .nr-review__pending p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.78rem;
  line-height: 1.5;
}
new-release--widgets--review-102035 .nr-review__toolbar {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.8rem 1.1rem;
  padding: 0.75rem 1.25rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__toolbar label {
  display: grid;
  min-width: min(16rem, 100%);
  gap: 0.25rem;
}
new-release--widgets--review-102035 .nr-review__legend {
  display: flex;
  flex-wrap: wrap;
  gap: 0.55rem 0.85rem;
  padding: 0;
  list-style: none;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
  font-weight: 700;
}
new-release--widgets--review-102035 .nr-review__legend .is-new,
new-release--widgets--review-102035 .nr-review__legend .is-change {
  color: var(--text-strong, #111827);
  font-weight: 800;
}
new-release--widgets--review-102035 .nr-review__legend .is-keep {
  color: var(--text-muted, #5d6b7e);
  font-weight: 500;
}
new-release--widgets--review-102035 .nr-review__legend .is-remove {
  color: var(--text-muted, #5d6b7e);
  text-decoration: line-through;
}
new-release--widgets--review-102035 .nr-review__split {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  align-items: start;
  min-width: 0;
}
new-release--widgets--review-102035 .nr-review__split.has-detail {
  grid-template-columns: minmax(12rem, 18rem) minmax(0, 1fr);
}
new-release--widgets--review-102035 .nr-review__menu {
  min-width: 0;
  padding: 0.45rem 0.45rem 0.9rem 0.35rem;
  border-right: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-bg, #fff);
}
new-release--widgets--review-102035 .nr-review__menu ul {
  padding: 0;
  list-style: none;
}
new-release--widgets--review-102035 .nr-review__menu ul ul {
  padding-left: 0.75rem;
}
new-release--widgets--review-102035 .nr-review__row {
  display: flex;
  align-items: center;
  gap: 0.05rem;
}
new-release--widgets--review-102035 .nr-review__toggle {
  flex: none;
  width: 1.15rem;
  height: 1.55rem;
  padding: 0;
  border: 0;
  background: transparent;
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review__toggle::before {
  content: '';
  display: block;
  width: 0;
  height: 0;
  margin: 0 auto;
  border-style: solid;
  border-width: 0.28rem 0 0.28rem 0.4rem;
  border-color: transparent transparent transparent currentColor;
  transform-origin: 35% 50%;
  transition: transform 0.12s ease;
}
new-release--widgets--review-102035 .nr-review__toggle.is-open::before {
  transform: rotate(90deg);
}
new-release--widgets--review-102035 .nr-review__toggle.is-leaf {
  visibility: hidden;
}
new-release--widgets--review-102035 .nr-review__link {
  flex: 1;
  min-width: 0;
  margin: 0.04rem 0;
  padding: 0.32rem 0.42rem;
  overflow: hidden;
  border: 1px solid transparent;
  border-radius: 0.42rem;
  background: transparent;
  color: inherit;
  font-size: 0.78rem;
  line-height: 1.3;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--review-102035 .nr-review__link:hover {
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__link.is-active {
  border-color: var(--selected-border, #1273d4);
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--review-102035 .nr-review__link.is-new,
new-release--widgets--review-102035 .nr-review__link.is-change,
new-release--widgets--review-102035 .nr-review__detail h3.is-new,
new-release--widgets--review-102035 .nr-review__detail h3.is-change {
  color: var(--text-strong, #111827);
  font-weight: 800;
}
new-release--widgets--review-102035 .nr-review__link.is-keep,
new-release--widgets--review-102035 .nr-review__detail h3.is-keep {
  color: var(--text-muted, #5d6b7e);
  font-weight: 500;
}
new-release--widgets--review-102035 .nr-review__link.is-remove,
new-release--widgets--review-102035 .nr-review__detail h3.is-remove,
new-release--widgets--review-102035 .nr-review .is-remove {
  color: var(--text-muted, #5d6b7e);
  text-decoration: line-through;
}
new-release--widgets--review-102035 .nr-review__removed {
  margin: 0.55rem 0.2rem 0;
}
new-release--widgets--review-102035 .nr-review__removed > summary {
  padding: 0.28rem 0.2rem;
  cursor: pointer;
}
new-release--widgets--review-102035 .nr-review__badge {
  display: inline-block;
  padding: 0.12rem 0.38rem;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
  font-weight: 750;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__badge.is-new {
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--review-102035 .nr-review__badge.is-change {
  background: var(--status-info-bg, #eaf3fc);
  color: var(--status-info-text, #0b5497);
}
new-release--widgets--review-102035 .nr-review__badge.is-remove {
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--review-102035 .nr-review__detail {
  min-width: 0;
  padding: 0.7rem 1.1rem 1.1rem;
}
new-release--widgets--review-102035 .nr-review__detail {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  justify-content: flex-start;
  gap: 0.38rem;
}
new-release--widgets--review-102035 .nr-review__detail > header h3 {
  margin-top: 0.12rem;
  font-size: 1.15rem;
  letter-spacing: -0.02em;
}
new-release--widgets--review-102035 .nr-review__detail > header small {
  display: inline-block;
  margin-top: 0.28rem;
}
new-release--widgets--review-102035 .nr-review__detail > p,
new-release--widgets--review-102035 .nr-review__detail article p {
  color: var(--text-default, #2f3a48);
  font-size: 0.8rem;
  line-height: 1.5;
}
new-release--widgets--review-102035 .nr-review__detail > p span {
  display: block;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__detail section {
  display: grid;
  gap: 0.45rem;
}
new-release--widgets--review-102035 .nr-review__detail section article {
  padding: 0.65rem 0.72rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.65rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--review-102035 .nr-review__detail section article strong {
  color: var(--text-strong, #111827);
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__pending {
  align-items: center;
  justify-items: start;
}
new-release--widgets--review-102035 .nr-review__change-effort {
  min-width: 0;
  padding: 1rem 1.25rem;
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__change-effort header {
  display: grid;
  gap: 0.4rem;
  margin-bottom: 0.8rem;
}
new-release--widgets--review-102035 .nr-review__effort-item {
  margin-top: 0.6rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.65rem;
}
new-release--widgets--review-102035 .nr-review__effort-item summary {
  padding: 0.75rem;
  cursor: pointer;
  overflow-wrap: anywhere;
}
new-release--widgets--review-102035 .nr-review__effort-item summary code {
  display: block;
  margin-top: 0.25rem;
}
new-release--widgets--review-102035 .nr-review__effort-item > div {
  display: grid;
  gap: 0.75rem;
  padding: 0 0.75rem 0.75rem;
}
new-release--widgets--review-102035 .nr-review__effort-master {
  min-width: 0;
  padding: 0.75rem;
  background: var(--surface-alt-bg, #f5f7fa);
  border-radius: 0.5rem;
}
new-release--widgets--review-102035 .nr-review__effort-master h4 {
  margin: 0 0 0.4rem;
}
new-release--widgets--review-102035 .nr-review__effort-master section {
  margin-top: 0.8rem;
}
new-release--widgets--review-102035 .nr-review__effort-master ul {
  padding-left: 1.2rem;
}
new-release--widgets--review-102035 .nr-review__effort-master li {
  margin-top: 0.4rem;
}
new-release--widgets--review-102035 .nr-review__change-effort code {
  display: block;
  overflow-wrap: anywhere;
  font-size: 0.7rem;
}
new-release--widgets--review-102035 .nr-review__effort-master p {
  overflow-wrap: anywhere;
  white-space: pre-wrap;
}
new-release--widgets--review-102035 .nr-review__effort-abend {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--review-102035 .nr-review__backend {
  min-width: 0;
  padding: 1rem 1.25rem 1.2rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--review-102035 .nr-review__backend > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.45rem 1rem;
}
new-release--widgets--review-102035 .nr-review__backend > header span {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 800;
  letter-spacing: 0.11em;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__backend > header h3 {
  margin-top: 0.2rem;
  color: var(--text-strong, #111827);
  font-size: 1.12rem;
}
new-release--widgets--review-102035 .nr-review__backend > header p {
  margin-top: 0.25rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__backend > header > strong {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__backend-message {
  margin-top: 0.7rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__backend-legend {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem 0.7rem;
  margin: 0.85rem 0;
  padding: 0;
  list-style: none;
  font-size: 0.65rem;
}
new-release--widgets--review-102035 .nr-review__backend-legend .is-new,
new-release--widgets--review-102035 .nr-review__backend-legend .is-change {
  color: var(--text-strong, #111827);
  font-weight: 800;
}
new-release--widgets--review-102035 .nr-review__backend-legend .is-keep,
new-release--widgets--review-102035 .nr-review__backend-legend .is-unknown {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review__backend-legend .is-remove {
  color: var(--status-error-text, #ab2328);
  text-decoration: line-through;
}
new-release--widgets--review-102035 .nr-review__backend-groups {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 21rem), 1fr));
  align-items: start;
  gap: 0.7rem;
  min-width: 0;
}
new-release--widgets--review-102035 .nr-review__backend-group {
  min-width: 0;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.65rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--review-102035 .nr-review__backend-group summary {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.45rem;
  padding: 0.65rem 0.75rem;
  cursor: pointer;
}
new-release--widgets--review-102035 .nr-review__backend-group summary span {
  display: grid;
  min-width: 0;
  gap: 0.1rem;
}
new-release--widgets--review-102035 .nr-review__backend-group summary strong {
  overflow-wrap: anywhere;
  color: var(--text-strong, #111827);
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__backend-group summary code {
  overflow-wrap: anywhere;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
}
new-release--widgets--review-102035 .nr-review__backend-group summary small {
  flex: none;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
}
new-release--widgets--review-102035 .nr-review__backend-group > div {
  display: grid;
  gap: 0.45rem;
  padding: 0 0.65rem 0.7rem;
}
new-release--widgets--review-102035 .nr-review__backend-item {
  min-width: 0;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.5rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__backend-item summary {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.35rem;
  padding: 0.6rem 0.65rem;
  cursor: pointer;
}
new-release--widgets--review-102035 .nr-review__backend-item summary div {
  display: grid;
  min-width: 0;
  gap: 0.1rem;
}
new-release--widgets--review-102035 .nr-review__backend-item summary div span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
}
new-release--widgets--review-102035 .nr-review__backend-item summary strong {
  overflow-wrap: anywhere;
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__backend-item.is-new strong,
new-release--widgets--review-102035 .nr-review__backend-item.is-change strong {
  color: var(--text-strong, #111827);
  font-weight: 800;
}
new-release--widgets--review-102035 .nr-review__backend-item.is-keep strong {
  color: var(--text-muted, #5d6b7e);
  font-weight: 500;
}
new-release--widgets--review-102035 .nr-review__backend-item.is-remove strong {
  color: var(--text-muted, #5d6b7e);
  text-decoration: line-through;
}
new-release--widgets--review-102035 .nr-review__backend-item-detail {
  min-width: 0;
  padding: 0 0.65rem 0.6rem;
}
new-release--widgets--review-102035 .nr-review__backend-item-detail > code,
new-release--widgets--review-102035 .nr-review__backend-item p code {
  overflow-wrap: anywhere;
  font-size: 0.62rem;
}
new-release--widgets--review-102035 .nr-review__backend-item p {
  margin-top: 0.35rem;
  overflow-wrap: anywhere;
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__backend-item p span {
  color: var(--text-muted, #5d6b7e);
  font-weight: 700;
}
new-release--widgets--review-102035 .nr-review__backend-item .nr-review__backend-limitation {
  color: var(--status-warning-text, #775700);
}
new-release--widgets--review-102035 .nr-review__backend-empty {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__effort {
  margin-top: 0.9rem;
  padding: 0.7rem 0.8rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.65rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__effort header {
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__effort header span {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review__effort p {
  margin-top: 0.25rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__effort > div {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 13rem), 1fr));
  gap: 0.45rem;
  margin-top: 0.55rem;
}
new-release--widgets--review-102035 .nr-review__effort > div > div {
  display: grid;
  gap: 0.12rem;
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__effort > div span {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review__test-support {
  margin-top: 0.85rem;
}
new-release--widgets--review-102035 .nr-review__test-support .nr-review__backend-group {
  margin-top: 0.45rem;
}
new-release--widgets--review-102035 .nr-review__test-gap {
  display: block;
  margin-top: 0.15rem;
  color: var(--status-warning-text, #775700);
  font-size: 0.64rem;
  font-weight: 700;
}
new-release--widgets--review-102035 .nr-review :where(button, select, summary):focus-visible {
  outline: 0.15rem solid var(--focus-ring, #1273d4);
  outline-offset: 0.12rem;
}
new-release--widgets--review-102035 .nr-review__pool {
  margin: 0 1.25rem 1.2rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.8rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__pool summary {
  padding: 0.7rem 0.9rem;
  cursor: pointer;
  color: var(--text-muted, #5d6b7e);
  letter-spacing: 0.08em;
}
new-release--widgets--review-102035 .nr-review__pool > p {
  padding: 0 0.9rem 0.5rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
}
new-release--widgets--review-102035 .nr-review__pool section {
  padding: 0.15rem 0.9rem 0.8rem;
}
new-release--widgets--review-102035 .nr-review__pool h3 {
  margin-bottom: 0.4rem;
}
new-release--widgets--review-102035 .nr-review__pool article {
  display: grid;
  gap: 0.12rem;
  margin-top: 0.35rem;
  padding: 0.55rem 0.65rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__pool article code {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
}
new-release--widgets--review-102035 .nr-review__pool article span {
  color: var(--text-default, #2f3a48);
}
new-release--widgets--review-102035 .nr-review__pool .is-unreadable span {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--review-102035 .nr-review__pool section > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
@container (max-width: 519px) {
  new-release--widgets--review-102035 .nr-review__primary-action {
    grid-template-columns: minmax(0, 1fr);
    padding-inline: 0.85rem;
  }
  new-release--widgets--review-102035 .nr-review__primary-action.has-undo {
    grid-template-columns: minmax(0, 1fr);
  }
  new-release--widgets--review-102035 .nr-review__split.has-detail {
    grid-template-columns: 1fr;
  }
  new-release--widgets--review-102035 .nr-review__menu {
    border-right: 0;
    border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  }
  new-release--widgets--review-102035 .nr-review__backend {
    padding-inline: 0.85rem;
  }
  new-release--widgets--review-102035 .nr-review__backend-groups {
    grid-template-columns: minmax(0, 1fr);
  }
  new-release--widgets--review-102035 .nr-review__run {
    padding-inline: 0.85rem;
  }
  new-release--widgets--review-102035 .nr-review__run > header {
    display: grid;
  }
}
@media (max-width: 780px) {
  new-release--widgets--review-102035 .nr-review__hero,
  new-release--widgets--review-102035 .nr-review__toolbar {
    padding-inline: 0.85rem;
  }
  new-release--widgets--review-102035 .nr-review__primary-action {
    grid-template-columns: minmax(0, 1fr);
    padding-inline: 0.85rem;
  }
  new-release--widgets--review-102035 .nr-review__primary-action.has-undo {
    grid-template-columns: minmax(0, 1fr);
  }
  new-release--widgets--review-102035 .nr-review__split.has-detail {
    grid-template-columns: 1fr;
  }
  new-release--widgets--review-102035 .nr-review__menu {
    border-right: 0;
    border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  }
  new-release--widgets--review-102035 .nr-review__pool {
    margin-inline: 0.85rem;
  }
}
@media (prefers-reduced-motion: reduce) {
  new-release--widgets--review-102035 .nr-review *,
  new-release--widgets--review-102035 .nr-review *::before,
  new-release--widgets--review-102035 .nr-review *::after {
    scroll-behavior: auto !important;
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
new-release--widgets--review-102035 pre {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  max-width: 100%;
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.request = '';
        this.changesContent = nothing;
        this.identityError = '';
        this.menuRead = EMPTY_MENU;
        this.pool = [];
        this.backendRead = EMPTY_ARTIFACT;
        this.effortRead = EMPTY_ARTIFACT;
        this.changeEffortRead = EMPTY_ARTIFACT;
        this.loading = false;
        this.hasRelease = false;
        this.effortCurrent = false;
        this.effortRefreshPending = false;
        this.initialPlan = null;
        this.selectedActor = '';
        this.selectedId = '';
        this.selectedScope = 'future';
        this.expandedKeys = [];
        this.actionBusy = false;
        this.actionError = '';
        this.supersededRevisionId = '';
        this.initialErrorDetail = '';
        this.reviewRun = null;
        this.reviewRunLoadError = '';
        this.channelRun = null;
        this.reviewTask = null;
        this.reviewTaskSettled = false;
        this.reviewCopyFeedback = '';
        this.reviewCopyRunId = '';
        this.implementationBusy = false;
        this.implementation = null;
        this.implementationTasks = {};
        this.implementationTaskSettled = {};
        this.implementationPolling = null;
        this.implementationCheckBusy = false;
        this.implementationCheckFeedback = '';
        this.implementationCopyFeedback = '';
        this.detailCopyKey = '';
        this.detailCopyFeedback = '';
        this.implementationTaskChanges = {};
        this.implementationHashes = { changeEffort: '' };
        this.confirmedRounds = [];
        this.confirmedTasks = {};
        this.confirmationBusy = false;
        this.publishFeedback = '';
        this.implementationDiff = null;
        this.implementationDiffError = false;
        this.implementationRestored = false;
        this.applicationCheckpoint = false;
        this.implementationCancelBusy = false;
        this.implementationUndoFeedback = '';
        this.implementationCancelRequested = false;
        this.implementationFlight = null;
        this.loadToken = 0;
        this.adoptedRuns = new Set();
        this.reviewRunStore = new IndexedDbReviewRunStore();
        this.workerTransport = createReviewWorkerTransport();
        this.workerHost = createReviewStudioHost();
        this.implementationTaskWrite = Promise.resolve();
        this.implementationRunner = createImplementationRunner({ onTask: (project, moduleName, phaseName, task) => {
                if (project !== this.project || moduleName !== this.moduleName)
                    return;
                const phase = this.implementation?.phases.find(phase => phase.name === phaseName);
                this.implementationPolling = observeImplementationTask(this.implementationPolling, task.PK.replace(/^task(?:\/#?|#)/u, ''), task.last_updated, task.status, phase?.startedAt ?? '', Date.now());
                void this.rememberImplementationTask(phaseName, task, this.loadToken);
            }, onPhase: (project, moduleName, phase) => {
                this.rememberImplementationPhase(project, moduleName, phase);
            } });
        this.initialApply = applyInitialReview;
        this.discardModule = discardModuleInStudio;
        this.discardBusy = false;
        this.discardError = '';
        this.loadedFor = null;
        this.runReviewPrimaryAction = async () => {
            const action = this.actionPresentation(this.view(), this.isCurrentLoad());
            const start = beginReviewPrimaryAction(action);
            if (!start.accepted)
                return;
            if (action.kind === 'continue') {
                if (this.isInitialGeneration()) {
                    await this.acceptInitialImplementation();
                    return;
                }
                await this.acceptImplementation();
                return;
            }
            if (!['calculate', 'retry'].includes(action.kind))
                return;
            const clicked = { project: this.project, moduleName: this.moduleName,
                changeId: this.data?.changeId, revisionId: this.data?.revisionId };
            const previousRun = this.channelRun;
            this.actionBusy = start.busy;
            this.actionError = '';
            this.supersededRevisionId = '';
            this.effortRefreshPending = true;
            this.effortCurrent = false;
            this.effortRead = EMPTY_ARTIFACT;
            this.backendRead = EMPTY_ARTIFACT;
            this.changeEffortRead = EMPTY_ARTIFACT;
            this.implementationHashes = { changeEffort: '' };
            this.channelRun = null;
            this.reviewTask = null;
            try {
                const retry = previousRun?.status === 'failed' || previousRun?.status === 'disputed';
                const userId = getUserId();
                if (!userId)
                    throw new Error('review-worker.user_unavailable');
                let started;
                if (retry && previousRun) {
                    const input = this.retryStartInput(previousRun, userId);
                    started = {
                        prepared: { input, userId },
                        run: await startReviewRun({ ...input, retry: true }),
                    };
                }
                else {
                    started = await executePreparedReviewStart(async () => {
                        const prepared = await this.prepareStartInput();
                        if (this.project === clicked.project && this.moduleName === clicked.moduleName
                            && this.data?.changeId === clicked.changeId && this.data?.revisionId === clicked.revisionId) {
                            this.supersededRevisionId = prepared.supersededRevisionId ?? '';
                        }
                        return prepared;
                    }, startReviewRun);
                }
                const { prepared, run } = started;
                const identity = { ...prepared.input, runId: run.runId };
                saveReviewRunLink(identity);
                this.channelRun = run;
                await this.driveWorker(run, prepared.userId);
            }
            catch (error) {
                this.actionError = this.reviewRunErrorKey(error instanceof Error ? error.message : String(error));
            }
            finally {
                this.actionBusy = false;
            }
        };
    }
    createRenderRoot() { return this; }
    disconnectedCallback() {
        ++this.loadToken;
        this.stopImplementationTimer();
        if (this.workerTimer)
            window.clearTimeout(this.workerTimer);
        super.disconnectedCallback();
    }
    updated(changed) {
        const previousData = changed.get('data');
        if (changed.has('project') || changed.has('moduleName'))
            this.implementationUndoFeedback = '';
        if (changed.has('project') || changed.has('moduleName')
            || (changed.has('data') && (previousData?.changeId !== this.data?.changeId
                || previousData?.revisionId !== this.data?.revisionId)))
            this.supersededRevisionId = '';
        if (changed.has('project') || changed.has('moduleName') || changed.has('version') || changed.has('data') || changed.has('request')) {
            this.reviewCopyFeedback = '';
            this.reviewCopyRunId = '';
            this.detailCopyKey = '';
            this.detailCopyFeedback = '';
            this.selectedActor = '';
            this.selectedId = '';
            this.selectedScope = 'future';
            this.expandedKeys = [];
            this.actionBusy = false;
            this.actionError = '';
            this.reviewRun = null;
            this.reviewRunLoadError = '';
            this.channelRun = null;
            this.reviewTask = null;
            this.reviewTaskSettled = false;
            if (this.workerTimer)
                window.clearTimeout(this.workerTimer);
            void this.load();
        }
    }
    pendingCount() {
        return this.version === 'tobe' && this.data?.changeId && !this.data.resultCurrent ? 1 : 0;
    }
    actorTitle(key) {
        const actorId = actorIdFromKey(key);
        return this.data?.artifacts.access.value?.actors.find(actor => actor.actorId === actorId)?.title || actorId;
    }
    view() {
        return buildReviewView({
            pendingCount: this.pendingCount(),
            readStatus: this.menuRead.status,
            raw: this.menuRead.value,
            selectedActor: this.selectedActor,
            selectedId: this.selectedId,
            selectedScope: this.selectedScope,
        });
    }
    isCurrentLoad() {
        const loaded = this.loadedFor;
        return !!loaded && loaded.project === this.project && loaded.moduleName === this.moduleName
            && loaded.version === this.version && loaded.data === this.data;
    }
    async load() {
        const token = ++this.loadToken;
        this.discardError = '';
        this.changeEffortRead = EMPTY_ARTIFACT;
        this.effortCurrent = false;
        this.effortRefreshPending = false;
        this.implementationPolling = null;
        this.implementationCheckBusy = false;
        this.implementationCheckFeedback = '';
        this.implementationTasks = {};
        this.implementationTaskSettled = {};
        this.implementationTaskChanges = {};
        this.confirmedTasks = {};
        this.confirmedRounds = [];
        this.publishFeedback = '';
        this.initialPlan = null;
        this.stopImplementationTimer();
        this.implementationDiff = null;
        this.implementationDiffError = false;
        this.implementationRestored = false;
        this.applicationCheckpoint = hasApplicationCheckpoint(this.project, this.moduleName);
        const context = { project: this.project, moduleName: this.moduleName, version: this.version, data: this.data };
        this.loadedFor = null;
        this.implementation = null;
        this.implementationHashes = { changeEffort: '' };
        if (!this.project || !this.moduleName) {
            this.menuRead = EMPTY_MENU;
            this.backendRead = EMPTY_ARTIFACT;
            this.effortRead = EMPTY_ARTIFACT;
            this.pool = [];
            this.reviewRun = null;
            this.reviewRunLoadError = '';
            this.loadedFor = context;
            this.loading = false;
            return;
        }
        this.loading = true;
        const hasRelease = moduleHasGeneratedSources(context.project, context.moduleName, Object.values(mls.stor.files).filter(file => !!file));
        const snapshot = context.data?.confirmedRound;
        const snapshotRoot = snapshot
            ? `${context.moduleName}/pipeline/changes/${snapshot.changeId}/revisions/${snapshot.revisionId}/l4` : undefined;
        const runRead = context.version === 'tobe' && context.data?.changeId && context.data.revisionId
            ? this.reviewRunStore.read({
                project: context.project,
                moduleName: context.moduleName,
                changeId: context.data.changeId,
                inputRevisionId: context.data.revisionId,
            }).then(run => ({ run, errorCode: '' }), () => ({ run: null, errorCode: 'review.run.storeError' }))
            : Promise.resolve({ run: null, errorCode: '' });
        const [menuRead, backendRead, effortRead, changeEffortRead, pool, persistedRun, implementation, confirmedRounds] = await Promise.all([
            readModuleMenu(context.project, context.moduleName, { generated: hasRelease }),
            readReviewArtifact(context.project, context.moduleName, 'backend', snapshotRoot),
            readReviewArtifact(context.project, context.moduleName, 'effort', snapshotRoot),
            readReviewArtifact(context.project, context.moduleName, 'changeEffort', snapshotRoot),
            readReviewPoolBoxes(context.project, context.moduleName),
            runRead,
            (context.data?.changeId ? readL4Implementation(context.project, context.moduleName) : readLatestCompletedL4Implementation(context.project, context.moduleName)).then(value => ({ value, error: false }), () => ({ value: null, error: true })),
            listConfirmedRounds(context.project, context.moduleName),
        ]);
        if (token !== this.loadToken)
            return;
        this.hasRelease = hasRelease;
        if (!this.hasRelease && (context.version === 'asis' || context.version === 'tobe')) {
            try {
                this.initialPlan = await readInitialImplementationPlan(context.project, context.moduleName);
            }
            catch (error) {
                console.error('[newRelease] initial planning unavailable', error);
            }
            if (token !== this.loadToken)
                return;
        }
        const candidateImplementation = implementation.value ?? (!context.data?.resultCurrent && !context.data?.diffs.some(diff => diff.entries.length)
            ? await readLatestCompletedL4Implementation(context.project, context.moduleName) : null);
        if (token !== this.loadToken)
            return;
        this.implementation = reviewImplementationVisible(candidateImplementation, context.data) ? candidateImplementation : null;
        if (this.applicationCheckpoint && this.implementation
            && implementationCommands(this.implementation, context.project, context.moduleName).every((_, index) => this.implementation.phases.some(phase => phase.name === `runAgents:${index}` && phase.status === 'done'))) {
            try {
                await compactModuleApplication(context.project, context.moduleName, this.implementation.changeId, this.implementation.revisionId);
            }
            catch (error) {
                console.error('[newRelease] application checkpoint compaction failed', error);
            }
        }
        this.confirmedRounds = confirmedRounds;
        void this.hydrateConfirmedTasks(confirmedRounds, token);
        let cancelReadError = '';
        let cancelRequested = false;
        if (this.applicationCheckpoint && this.implementation) {
            try {
                cancelRequested = await applicationCancelRequested(context.project, context.moduleName, this.implementation.changeId, this.implementation.revisionId);
            }
            catch (error) {
                cancelRequested = true;
                cancelReadError = error instanceof Error ? error.message : String(error);
            }
        }
        if (token !== this.loadToken)
            return;
        this.implementationCancelRequested = cancelRequested;
        if (cancelReadError)
            this.implementationUndoFeedback = this.t('review.implementation.undoError', { reason: cancelReadError });
        if (implementation.error)
            this.actionError = 'review.implementation.error.load';
        this.menuRead = menuRead;
        this.backendRead = backendRead;
        this.effortRead = effortRead;
        this.changeEffortRead = changeEffortRead;
        this.pool = pool;
        this.reviewRun = persistedRun.run;
        this.reviewRunLoadError = persistedRun.errorCode;
        await this.loadChannelRun(context, token);
        if (token !== this.loadToken)
            return;
        await this.loadReviewTask(token);
        if (token !== this.loadToken)
            return;
        if (!this.effortRefreshPending && !this.effortCurrent && context.version === 'tobe' && context.data?.resultCurrent && context.data.changeId && context.data.revisionId) {
            const root = `${context.moduleName}/pipeline/changes/${context.data.changeId}/revisions/${context.data.revisionId}/l4`;
            const effort = await this.readCandidateChangeEffort(context.project, context.moduleName, root);
            const fresh = effort.read.status === 'ok' && await effortMatchesCurrent(context.project, context.moduleName, effort.read.value);
            if (token !== this.loadToken)
                return;
            this.changeEffortRead = effort.read;
            this.effortCurrent = fresh;
            this.implementationHashes = { changeEffort: fresh ? effort.hash : '' };
        }
        if (!this.isConnected || context.project !== this.project || context.moduleName !== this.moduleName
            || context.version !== this.version || context.data !== this.data)
            return;
        this.loadedFor = context;
        this.loading = false;
        if (this.implementation)
            void this.hydrateImplementationTasks(this.implementation, token);
        if (this.implementationCancelRequested) {
            this.announceImplementationState(true);
            if (!cancelReadError && !this.implementationCancelBusy)
                void this.undoLastApplication(true);
        }
        else if (this.implementationPending()) {
            this.announceImplementationState(true);
            void this.advanceImplementation(token);
        }
        else if (this.implementationComplete())
            void this.loadImplementationDiff(token);
        else if (this.implementation?.phases.some(phase => phase.status === 'failed'))
            this.announceImplementationState(false);
    }
    announceImplementationState(active, project = this.project, moduleName = this.moduleName) {
        window.dispatchEvent(new CustomEvent(NEW_RELEASE_IMPLEMENTATION_STATE_EVENT, { detail: { project, moduleName, active } }));
    }
    async hydrateImplementationTasks(record, token) {
        const userId = getUserId();
        if (!userId)
            return;
        await Promise.all(record.phases.filter(phase => phase.taskId && phase.messageId).map(async (phase) => {
            try {
                const result = await msgGetTaskUpdate({ userId, taskId: phase.taskId, messageId: phase.messageId });
                const task = result.success ? result.response?.task : null;
                if (!task || task.PK.replace(/^task(?:\/#?|#)/u, '') !== phase.taskId
                    || token !== this.loadToken || this.implementation !== record || this.implementationTasks[phase.name])
                    return;
                await this.rememberImplementationTask(phase.name, task, token);
            }
            catch (error) {
                console.error('[newRelease] implementation task snapshot unavailable', error);
            }
            finally {
                if (token === this.loadToken && this.implementation === record) {
                    this.implementationTaskSettled = { ...this.implementationTaskSettled, [phase.name]: true };
                }
            }
        }));
    }
    async hydrateConfirmedTasks(rounds, token) {
        const phases = rounds.flatMap(round => round.record.phases).filter(phase => phase.taskId);
        await Promise.all(phases.map(async (phase) => {
            try {
                let task = await getTask(phase.taskId);
                if (!task && phase.messageId && getUserId()) {
                    const result = await msgGetTaskUpdate({ userId: getUserId(), taskId: phase.taskId, messageId: phase.messageId });
                    task = result.success ? result.response?.task ?? null : null;
                    if (task)
                        await addOrUpdateTask(task);
                }
                if (task?.PK.replace(/^task(?:\/#?|#)/u, '') === phase.taskId && token === this.loadToken) {
                    this.confirmedTasks = { ...this.confirmedTasks, [phase.taskId]: task };
                }
            }
            catch (error) {
                console.error('[newRelease] confirmed task snapshot unavailable', error);
            }
        }));
    }
    rememberImplementationTask(phaseName, task, token, storeTask = addOrUpdateTask) {
        const project = this.project;
        const moduleName = this.moduleName;
        const write = this.implementationTaskWrite.then(async () => {
            try {
                // The card also reads IndexedDB on mount. Store this snapshot first so that read cannot replace it with an older one.
                await storeTask(task);
            }
            catch {
                return; // Keep the details fallback when the card cannot be mounted reliably.
            }
            if (token !== this.loadToken || project !== this.project || moduleName !== this.moduleName)
                return;
            this.implementationTaskChanges[phaseName] = (this.implementationTaskChanges[phaseName] || 0) + 1;
            this.implementationTasks = { ...this.implementationTasks, [phaseName]: task };
        });
        this.implementationTaskWrite = write.catch(() => undefined);
        return write;
    }
    rememberImplementationPhase(project, moduleName, phase) {
        if (project !== this.project || moduleName !== this.moduleName || !this.implementation
            || this.implementation.changeId !== this.data?.changeId || this.implementation.revisionId !== this.data?.revisionId)
            return;
        const phases = this.implementation.phases.filter(item => item.name !== phase.name);
        this.implementation = { ...this.implementation, phases: [...phases, phase] };
    }
    async checkImplementationTask() {
        if (this.implementationCheckBusy || !this.implementationPolling?.taskId)
            return;
        const token = this.loadToken;
        const before = this.implementationPolling;
        const phaseStatus = this.implementation?.phases.find(phase => phase.taskId === before.taskId)?.status;
        this.implementationCheckBusy = true;
        this.implementationCheckFeedback = this.t('review.implementation.checking');
        try {
            await this.advanceImplementation(token);
            if (token !== this.loadToken)
                return;
            if (this.actionError)
                throw new Error(this.actionError);
            const after = this.implementationPolling;
            const updatedPhaseStatus = this.implementation?.phases.find(phase => phase.taskId === before.taskId)?.status;
            this.implementationCheckFeedback = this.t('review.implementation.checked', {
                time: new Date().toLocaleTimeString(),
                status: this.t(after?.taskId === before.taskId && after?.lastUpdated === before.lastUpdated
                    && after?.paused === before.paused && updatedPhaseStatus === phaseStatus
                    ? 'review.implementation.noUpdate' : 'review.implementation.updated'),
            });
        }
        catch (error) {
            console.error('[newRelease] task check failed', error);
            if (token === this.loadToken)
                this.implementationCheckFeedback = this.t('review.implementation.checkError');
        }
        finally {
            if (token === this.loadToken)
                this.implementationCheckBusy = false;
        }
    }
    selectActor(actor) {
        this.selectedActor = actor;
        this.selectedId = '';
        this.selectedScope = 'future';
        this.expandedKeys = [];
    }
    selectNode(id, scope) {
        const selected = toggleReviewSelection(this.selectedId, this.selectedScope, id, scope);
        this.selectedId = selected.selectedId;
        this.selectedScope = selected.selectedScope;
    }
    toggleExpand(id, scope) {
        const next = toggleReviewExpansion(this.expandedKeys, this.view(), id, scope);
        this.selectedId = next.selectedId;
        this.expandedKeys = next.expandedKeys;
    }
    actionClass(action) {
        return `is-${action}`;
    }
    nodeAria(node) {
        return this.t('review.nodeAria', {
            label: node.label,
            kind: this.t(`review.kind.${node.kind}`),
            action: this.t(`review.action.${node.action}`),
        });
    }
    renderMenuList(nodes, scope, view, openKeys) {
        return html `
      <ul>
        ${nodes.map(node => {
            const selected = view.selectedId === node.id && view.selectedScope === scope;
            const expandable = node.children.length > 0;
            const expanded = expandable && openKeys.has(reviewExpansionKey(scope, node.id));
            return html `
            <li>
              <div class="nr-review__row">
                ${expandable ? html `
                  <button
                    type="button"
                    class=${`nr-review__toggle${expanded ? ' is-open' : ''}`}
                    aria-expanded=${expanded ? 'true' : 'false'}
                    aria-label=${this.nodeAria(node)}
                    @click=${() => this.toggleExpand(node.id, scope)}
                  ></button>
                ` : html `<span class="nr-review__toggle is-leaf" aria-hidden="true"></span>`}
                <button
                  type="button"
                  class=${`nr-review__link ${this.actionClass(node.action)}${selected ? ' is-active' : ''}`}
                  aria-label=${this.nodeAria(node)}
                  aria-pressed=${selected ? 'true' : 'false'}
                  @click=${() => this.selectNode(node.id, scope)}
                >${node.label}</button>
              </div>
              ${expanded ? this.renderMenuList(node.children, scope, view, openKeys) : nothing}
            </li>
          `;
        })}
      </ul>
    `;
    }
    renderDetail(detail) {
        if (!detail)
            return nothing;
        const struck = detail.scope === 'removed' || detail.action === 'remove';
        return html `
      <article class="nr-review__detail" aria-live="polite">
        <header>
          <span>${this.t(`review.kind.${detail.kind}`)}</span>
          <h3 class=${this.actionClass(detail.action)}>${detail.label}</h3>
          <small class=${`nr-review__badge ${this.actionClass(detail.action)}`}>${this.t(`review.action.${detail.action}`)}</small>
        </header>
        ${detail.context ? html `<p><span>${this.t('review.context')}</span><strong>${detail.context}</strong></p>` : nothing}
        ${detail.text ? html `<p class=${struck ? 'is-remove' : ''}>${detail.text}</p>` : nothing}
        ${detail.href ? html `<p><span>${this.t('review.page')}</span><strong>${detail.href}</strong></p>` : nothing}
        ${detail.description ? html `<p class=${struck ? 'is-remove' : ''}>${detail.description}</p>` : nothing}
        ${detail.actors.length ? html `<p><span>${this.t('review.actors')}</span><strong>${detail.actors.map(actor => this.actorTitle(`actor:${actor}`)).join(', ')}</strong></p>` : nothing}
        ${detail.landing ? html `<p><span>${this.t('review.landing')}</span></p>` : nothing}
        ${detail.organisms.length ? html `
          <section>
            <span>${this.t('review.organisms')}</span>
            ${detail.organisms.map(organism => html `
              <article>
                <strong>${this.t(`review.organism.${organism.kind}`)}</strong>
                <p class=${struck ? 'is-remove' : ''}>${organism.text}</p>
              </article>
            `)}
          </section>
        ` : nothing}
      </article>
    `;
    }
    renderMenu(view) {
        if (view.kind === 'pending') {
            return html `
        <section class="nr-review__pending">
          <h3>${this.t('review.pendingTitle')}</h3>
          <p>${this.t('review.pendingBody')}</p>
        </section>
      `;
        }
        if (view.kind === 'empty') {
            return html `
        <section class="nr-review__empty">
          <h3>${this.t('review.emptyTitle')}</h3>
          <p>${this.t(view.errorCode || 'review.emptyBody')}</p>
        </section>
      `;
        }
        if (view.kind === 'invalid') {
            return html `
        <section class="nr-review__empty">
          <h3>${this.t('review.invalidTitle')}</h3>
          <p>${this.t(view.errorCode || 'review.error.invalid')}</p>
        </section>
      `;
        }
        const openKeys = openReviewExpansionKeys(this.expandedKeys, view);
        return html `
      <div class="nr-review__toolbar">
        <label>
          <span>${this.t('review.actor')}</span>
          <select .value=${view.selectedActor} @change=${(event) => this.selectActor(event.currentTarget.value)}>
            <option value=${REVIEW_ALL_ACTORS} ?selected=${view.selectedActor === REVIEW_ALL_ACTORS}>${this.t('review.allActors')}</option>
            ${view.actors.map(actor => html `<option value=${actor.key} ?selected=${view.selectedActor === actor.key}>${this.actorTitle(actor.key)}</option>`)}
          </select>
        </label>
        <ul class="nr-review__legend">
          ${MENU_ACTIONS.map(action => html `<li class=${this.actionClass(action)}>${this.t(`review.action.${action}`)}</li>`)}
        </ul>
      </div>
      <div class=${`nr-review__split${view.selected ? ' has-detail' : ''}`}>
        <nav class="nr-review__menu" aria-label=${this.t('review.futureTree')}>
          ${this.renderMenuList(view.tree, 'future', view, openKeys)}
          ${view.removed.length ? html `
            <details class="nr-review__removed" ?open=${view.selectedScope === 'removed'}>
              <summary>${this.t('review.removedTree')}</summary>
              ${this.renderMenuList(view.removed, 'removed', view, openKeys)}
            </details>
          ` : nothing}
        </nav>
        ${this.renderDetail(view.selected)}
      </div>
    `;
    }
    async prepareStartInput() {
        if (this.version !== 'tobe')
            throw new Error('review-run.invalid_request');
        return prepareReviewStartInput({
            project: this.project,
            moduleName: this.moduleName,
            changeId: this.data?.changeId ?? null,
            revisionId: this.data?.revisionId ?? null,
            request: this.request,
            userId: getUserId(),
            loaded: this.data?.sealedRevision ?? null,
        });
    }
    workerId() {
        const key = 'collab-new-release-review-worker-id-v1';
        const existing = localStorage.getItem(key);
        if (existing)
            return existing;
        const created = `studio-${crypto.randomUUID()}`;
        localStorage.setItem(key, created);
        return created;
    }
    async loadChannelRun(context, token) {
        if (context.version !== 'tobe' || !context.data?.changeId || !context.data.revisionId)
            return;
        const link = readReviewRunLink({
            project: context.project,
            moduleName: context.moduleName,
            changeId: context.data.changeId,
            inputRevisionId: context.data.revisionId,
        });
        if (!link)
            return;
        try {
            const run = await observeReviewRun(link);
            if (token !== this.loadToken)
                return;
            let revisionMatches = reviewRunMatchesRevision(run, context.data.revisionId);
            if (!revisionMatches && run.candidateResult === null) {
                const published = await candidateRead({ project: run.binding.project, moduleName: run.binding.moduleName });
                if (token !== this.loadToken)
                    return;
                revisionMatches = publishedCandidateMatchesRunRevision(run, context.data.revisionId, published);
            }
            if (!revisionMatches)
                return;
            this.channelRun = run;
            if (!['ready', 'failed', 'disputed'].includes(run.status)) {
                this.effortRefreshPending = true;
                this.effortRead = EMPTY_ARTIFACT;
                this.backendRead = EMPTY_ARTIFACT;
                this.changeEffortRead = EMPTY_ARTIFACT;
                this.effortCurrent = false;
                await this.driveWorker(run, link.userId, token);
            }
            else if (run.status === 'ready') {
                await this.loadCandidateArtifacts(run, link.userId, token);
            }
        }
        catch (error) {
            if (token !== this.loadToken)
                return;
            this.reviewRunLoadError = this.reviewRunErrorKey(error instanceof Error ? error.message : String(error));
        }
    }
    async driveWorker(run, userId, token = this.loadToken) {
        const candidate = await readCandidateWorkerGate(run);
        if (token !== this.loadToken)
            return;
        const canonicalHash = await this.readCanonicalSnapshotHash(run);
        if (token !== this.loadToken)
            return;
        let publishedExecution;
        if (['queued', 'reviewing'].includes(run.status) && run.candidateResult === null) {
            const published = await candidateRead({ project: run.binding.project, moduleName: run.binding.moduleName });
            if (token !== this.loadToken)
                return;
            if (published.status === 'read' && published.pointer && published.result
                && publishedCandidateMatchesRunRevision(run, published.pointer.revisionId, published)) {
                const { manifest } = published.result;
                publishedExecution = { taskId: manifest.taskId, resultRunId: manifest.runId };
            }
        }
        const result = await driveReviewRunWorker(this.workerTransport, this.workerHost, claimInputForRun(run, userId, this.workerId(), canonicalHash, candidate), publishedExecution);
        const current = result.state === 'reported'
            ? result.run
            : await observeReviewRun(this.identityForRun(run, userId));
        if (token !== this.loadToken)
            return;
        this.channelRun = current;
        await this.loadReviewTask(token);
        this.saveOutputAlias(current, userId);
        if (current.status === 'ready') {
            await this.loadCandidateArtifacts(current, userId, token);
            return;
        }
        if (current.status === 'failed' || current.status === 'disputed')
            return;
        if (this.workerTimer)
            window.clearTimeout(this.workerTimer);
        this.workerTimer = window.setTimeout(() => {
            this.workerTimer = undefined;
            if (token !== this.loadToken)
                return;
            void this.driveWorker(current, userId, token).catch(error => {
                if (token !== this.loadToken)
                    return;
                this.actionError = this.reviewRunErrorKey(error instanceof Error ? error.message : String(error));
            });
        }, POLL_INTERVAL_MS);
    }
    async readCanonicalSnapshotHash(run) {
        const sealed = await readSealedL4Candidate(run.binding.project, run.binding.moduleName, run.binding.changeId, run.binding.inputRevisionId);
        if (!sealed)
            throw new Error('review-run.canonical_snapshot_unavailable');
        const sources = await Promise.all(sealed.sources.map(async (item) => ({
            path: item.path,
            source: await readSourceText(originalL4FileInfo(run.binding.project, run.binding.moduleName, run.binding.baseId, item.path)),
        })));
        const snapshot = await buildCandidateSnapshot({
            baseId: run.binding.baseId,
            requestRevision: run.binding.requestRevision,
            request: sealed.request,
            sources,
        });
        return `sha256:${snapshot.hash}`;
    }
    async loadCandidateArtifacts(run, userId, token = this.loadToken) {
        const revisionId = outputRevisionIdForRun(run);
        if (!revisionId)
            throw new Error('review-run.candidate_binding_mismatch');
        const root = `${run.binding.moduleName}/pipeline/changes/${run.binding.changeId}/revisions/${revisionId}/l4`;
        const [menu, backend, effort, changeEffort] = await Promise.all([
            readModuleMenu(run.binding.project, run.binding.moduleName, { generated: this.hasRelease, root }),
            readReviewArtifact(run.binding.project, run.binding.moduleName, 'backend', root),
            readReviewArtifact(run.binding.project, run.binding.moduleName, 'effort', root),
            this.readCandidateChangeEffort(run.binding.project, run.binding.moduleName, root),
        ]);
        if (token !== this.loadToken)
            return;
        const fresh = changeEffort.read.status === 'ok' && await effortMatchesCurrent(run.binding.project, run.binding.moduleName, changeEffort.read.value);
        if (token !== this.loadToken)
            return;
        this.effortCurrent = fresh;
        this.effortRefreshPending = !fresh;
        this.implementationHashes = { changeEffort: fresh ? changeEffort.hash : '' };
        this.menuRead = menu;
        this.backendRead = backend;
        this.effortRead = effort;
        this.changeEffortRead = changeEffort.read;
        this.pool = [];
        this.saveOutputAlias(run, userId);
        if (run.status !== 'ready' || this.adoptedRuns.has(run.runId)
            || (this.data?.revisionId === revisionId && this.data.resultCurrent))
            return;
        const gate = await readCandidateWorkerGate(run);
        if (token !== this.loadToken || !gate.pipelineComplete || this.adoptedRuns.has(run.runId))
            return;
        this.adoptedRuns.add(run.runId);
        try {
            await adoptL4ReviewResult(run.binding.project, run.binding.moduleName, {
                inputRevisionId: run.binding.inputRevisionId,
                outputRevisionId: revisionId,
            });
        }
        catch (error) {
            if (error instanceof Error && error.message === 'l4.result_stale')
                return;
            this.adoptedRuns.delete(run.runId);
            throw error;
        }
        window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, {
            detail: { project: run.binding.project, moduleName: run.binding.moduleName },
        }));
    }
    async readCandidateChangeEffort(project, moduleName, root) {
        const effortInfo = reviewArtifactFile(project, moduleName, 'changeEffort', root);
        const effortPath = `l4/${effortInfo.folder}/${effortInfo.shortName}${effortInfo.extension}`;
        const readEffort = async () => {
            const stored = mls.stor.files[mls.stor.getKeyToFile(effortInfo)];
            if (!stored || stored.status === 'deleted')
                return { read: { status: 'missing', path: effortPath }, hash: '' };
            let source;
            try {
                source = await readSourceText(effortInfo);
            }
            catch (cause) {
                console.error('[newRelease] effort artifact could not be read', { effortPath, cause });
                return { read: { status: 'invalid', path: effortPath }, hash: '' };
            }
            let value;
            try {
                value = JSON.parse(source);
            }
            catch (cause) {
                console.error('[newRelease] effort artifact could not be read', { effortPath, cause });
                return { read: { status: 'invalid', path: effortPath }, hash: '' };
            }
            if (value === null)
                return { read: { status: 'invalid', path: effortPath }, hash: '' };
            const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(source));
            return { read: { status: 'ok', path: effortPath, value },
                hash: `sha256:${[...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('')}` };
        };
        return readEffort();
    }
    saveOutputAlias(run, userId) {
        const revisionId = outputRevisionIdForRun(run);
        if (!revisionId)
            return;
        saveReviewRunLink(this.identityForRun(run, userId), undefined, {
            project: run.binding.project,
            moduleName: run.binding.moduleName,
            changeId: run.binding.changeId,
            inputRevisionId: revisionId,
        });
    }
    identityForRun(run, userId) {
        return {
            userId,
            project: run.binding.project,
            moduleName: run.binding.moduleName,
            changeId: run.binding.changeId,
            inputRevisionId: run.binding.inputRevisionId,
            inputSnapshotHash: run.binding.inputSnapshotHash,
            baseId: run.binding.baseId,
            requestRevision: run.binding.requestRevision,
            requestHash: run.binding.requestHash,
            runId: run.runId,
        };
    }
    isInitialGeneration() {
        return !this.hasRelease && !(this.data?.resultCurrent && this.changeEffortRead.status !== 'missing');
    }
    async acceptInitialImplementation() {
        if (this.actionBusy || !this.initialPlan || !this.isInitialGeneration() || !this.isCurrentLoad()
            || (this.version !== 'asis' && this.version !== 'tobe'))
            return;
        const { project, moduleName, version, data } = this;
        const token = this.loadToken;
        const current = () => this.isConnected && token === this.loadToken && this.project === project
            && this.moduleName === moduleName && this.version === version && this.data === data;
        this.actionBusy = true;
        this.actionError = '';
        this.initialErrorDetail = '';
        window.dispatchEvent(new CustomEvent(NEW_RELEASE_IMPLEMENTATION_STATE_EVENT, { detail: { project, moduleName, active: true } }));
        let accepted = false;
        try {
            const record = await this.initialApply({ project, moduleName, acceptedBy: getUserId() ?? '',
                changeId: data?.changeId ?? null, revisionId: data?.revisionId ?? null }, { current });
            if (!current())
                return;
            this.implementation = record;
            accepted = true;
            this.initialPlan = null;
            // The context owner reloads the accepted revision in tobe; load() resumes its persisted phases.
            window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project, moduleName, version: 'tobe' } }));
        }
        catch (error) {
            if (current())
                this.actionError = error instanceof Error && error.message === 'l4.implementation_conflict'
                    ? 'review.implementation.error.conflict' : 'review.implementation.error.run';
            if (current())
                this.initialErrorDetail = error instanceof Error ? error.message : String(error);
            console.error('[newRelease] initial implementation failed', error);
        }
        finally {
            if (current())
                this.actionBusy = false;
            if (!accepted)
                window.dispatchEvent(new CustomEvent(NEW_RELEASE_IMPLEMENTATION_STATE_EVENT, { detail: { project, moduleName, active: false } }));
        }
    }
    canImplement() {
        return this.effortCurrent && canAcceptImplementation({ project: this.project, moduleName: this.moduleName, data: this.data,
            runStatus: this.channelRun?.status ?? this.reviewRun?.status ?? (this.data?.resultCurrent ? 'ready' : null),
            changeEffort: this.changeEffortRead,
            hashes: this.implementationHashes, implementation: this.implementation });
    }
    async acceptImplementation() {
        const data = this.data;
        const acceptedBy = getUserId();
        const baseId = data?.sealedRevision?.manifest.baseId;
        if (this.actionBusy || !this.canImplement() || !data?.changeId || !data.revisionId || !baseId || !acceptedBy)
            return;
        const { project, moduleName } = this;
        const token = this.loadToken;
        const current = () => this.implementationContextCurrent(token);
        const { changeId, revisionId } = data;
        const hashes = { ...this.implementationHashes };
        this.actionBusy = true;
        this.actionError = '';
        this.announceImplementationState(true, project, moduleName);
        this.querySelectorAll('.nr-review__primary-action button').forEach(button => {
            button.disabled = true;
            button.setAttribute('aria-disabled', 'true');
        });
        let accepted = false;
        let phase = 'seal';
        let applicationSealed = false;
        try {
            if (!await effortMatchesCurrent(project, moduleName, this.changeEffortRead.value)) {
                this.effortCurrent = false;
                this.actionError = 'review.implementation.error.conflict';
                return;
            }
            await sealModuleApplication(project, moduleName, changeId, revisionId);
            applicationSealed = true;
            if (current())
                this.applicationCheckpoint = true;
            await sealModuleLayers(project, moduleName, baseId);
            phase = 'promote';
            await promoteL4Revision(project, moduleName, changeId, revisionId);
            phase = 'accept';
            const implementation = await acceptL4Implementation(project, moduleName, { revisionId, acceptedBy, hashes });
            accepted = true;
            if (current())
                this.implementation = implementation;
        }
        catch (error) {
            if (applicationSealed) {
                try {
                    await restoreModuleApplication(project, moduleName, changeId, revisionId);
                    if (current())
                        this.applicationCheckpoint = false;
                }
                catch (restoreError) {
                    console.error('[newRelease] application rollback failed', restoreError);
                    phase = 'restore';
                }
            }
            if (current()) {
                this.actionError = phase === 'accept' && error instanceof Error
                    ? error.message === 'l4.implementation_conflict' ? 'review.implementation.error.conflict'
                        : error.message === 'l4.implementation_regenerate_unsupported' ? 'review.implementation.error.regenerateUnsupported'
                            : error.message === 'l4.implementation_blocked' ? 'review.implementation.error.blocked'
                                : `review.implementation.error.${phase}`
                    : `review.implementation.error.${phase}`;
            }
        }
        finally {
            if (current())
                this.actionBusy = false;
            if (!accepted)
                this.announceImplementationState(false, project, moduleName);
        }
        // Execution failures must never roll back a successfully accepted revision.
        if (accepted && current()) {
            await this.advanceImplementation(token);
            if (current() && !this.implementationCancelRequested && this.implementationComplete())
                await this.loadImplementationDiff(token);
        }
    }
    stopImplementationTimer() {
        if (this.implementationTimer !== undefined)
            window.clearTimeout(this.implementationTimer);
        this.implementationTimer = undefined;
    }
    async waitForRunningImplementation(project, moduleName) {
        const deadline = Date.now() + 10 * 60 * 1000;
        while (Date.now() < deadline) {
            const record = await readL4Implementation(project, moduleName);
            if (!record) {
                if (this.implementationComplete())
                    return;
                throw new Error('implementation.not_accepted');
            }
            const phase = record.phases.find(item => item.status === 'running');
            if (!phase)
                return;
            const userId = getUserId();
            if (!userId)
                throw new Error('implementation.user_unavailable');
            let taskId = phase.taskId;
            if (!taskId) {
                const message = await msgGetMessage({ userId, threadId: phase.threadId, messageId: phase.messageId });
                taskId = message.response?.message?.taskId?.replace(/^task(?:\/#?|#)/u, '') || '';
            }
            if (taskId) {
                const update = await msgGetTaskUpdate({ userId, taskId, messageId: phase.messageId });
                if (!update.success || !update.response?.task)
                    throw new Error(update.error || 'implementation.task_unavailable');
                const task = update.response.task;
                if (task.PK.replace(/^task(?:\/#?|#)/u, '') !== taskId)
                    throw new Error('implementation.task_mismatch');
                if (['done', 'failed', 'paused'].includes(task.status)) {
                    await recordL4ImplementationPhase(project, moduleName, { ...phase, taskId,
                        status: task.status === 'done' ? 'done' : 'failed', endedAt: new Date().toISOString(),
                        ...(task.status !== 'done' ? { error: task.last_update_log || 'review.implementation.error.run' } : {}) });
                    continue;
                }
            }
            await new Promise(resolve => window.setTimeout(resolve, POLL_INTERVAL_MS));
        }
        throw new Error('implementation.task_not_terminal');
    }
    async undoLastApplication(resume = false) {
        const record = this.implementation;
        if (!record || !this.applicationCheckpoint || this.implementationCancelBusy || this.actionBusy && !this.implementationPending())
            return;
        const running = this.implementationPending();
        if (!resume && !window.confirm(this.t(running ? 'review.implementation.cancelConfirm' : 'review.implementation.undoConfirm')))
            return;
        const { project, moduleName } = this;
        const token = this.loadToken;
        this.implementationCancelRequested = true;
        this.implementationCancelBusy = true;
        this.implementationUndoFeedback = '';
        this.stopImplementationTimer();
        try {
            await requestApplicationCancel(project, moduleName, record.changeId, record.revisionId);
            if (this.implementationFlight)
                await this.implementationFlight;
            if (running)
                await this.waitForRunningImplementation(project, moduleName);
            await restoreModuleApplication(project, moduleName, record.changeId, record.revisionId);
            this.applicationCheckpoint = false;
            this.implementation = null;
            this.implementationDiff = null;
            this.implementationUndoFeedback = this.t('review.implementation.undone');
            this.announceImplementationState(false, project, moduleName);
            window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project, moduleName, version: 'tobe' } }));
        }
        catch (error) {
            console.error('[newRelease] last application undo failed', error);
            if (token === this.loadToken)
                this.implementationUndoFeedback = this.t('review.implementation.undoError', { reason: this.t(error instanceof Error ? error.message : String(error)) });
        }
        finally {
            if (token === this.loadToken)
                this.implementationCancelBusy = false;
        }
    }
    implementationContextCurrent(token) {
        return this.isConnected && token === this.loadToken && this.isCurrentLoad() && this.version === 'tobe';
    }
    implementationPending() {
        const record = this.implementation;
        return !!record && record.changeId === this.data?.changeId && record.revisionId === this.data?.revisionId && this.version === 'tobe' && !record.phases.some(phase => phase.status === 'failed')
            && implementationCommands(record, this.project, this.moduleName).some((_, index) => !record.phases.some(phase => phase.name === `runAgents:${index}` && phase.status === 'done'));
    }
    async advanceImplementation(token = this.loadToken, retry) {
        if (this.implementationFlight)
            await this.implementationFlight;
        if (!this.implementationContextCurrent(token) || this.implementationFlight || this.discardBusy || this.implementationCancelRequested)
            return;
        const flight = this.runImplementation(token, retry);
        this.implementationFlight = flight;
        try {
            await flight;
        }
        finally {
            if (this.implementationFlight === flight)
                this.implementationFlight = null;
        }
    }
    async runImplementation(token, retry) {
        if (!this.implementationContextCurrent(token) || this.implementationBusy || this.discardBusy || this.implementationCancelRequested)
            return;
        if (retry) {
            const phase = this.implementation?.phases.find(phase => phase.name === retry);
            if (phase?.status !== 'failed' || phase.attempt >= 2)
                return;
        }
        else if (!this.implementationPending())
            return;
        this.stopImplementationTimer();
        const { project, moduleName } = this;
        this.implementationBusy = true;
        this.actionError = '';
        try {
            const record = retry
                ? await this.implementationRunner.retryPhase(project, moduleName, retry)
                : await this.implementationRunner.runNext(project, moduleName);
            if (!this.implementationContextCurrent(token))
                return;
            this.implementation = record.changeId === this.data?.changeId ? record : null;
            if (this.applicationCheckpoint && this.implementationComplete()) {
                await compactModuleApplication(project, moduleName, record.changeId, record.revisionId);
            }
            if (!this.implementationCancelRequested && this.implementationComplete())
                await this.loadImplementationDiff(token);
            if (!this.implementationCancelRequested && record.phases.some(phase => phase.status === 'failed'))
                this.announceImplementationState(false, project, moduleName);
            if (!this.implementationContextCurrent(token))
                return;
            // A synchronous completion can leave the next phase absent, with none running.
            if (!this.implementationCancelRequested && this.implementationPending() && !this.implementationPolling?.paused) {
                this.implementationTimer = window.setTimeout(() => {
                    this.implementationTimer = undefined;
                    if (this.implementationContextCurrent(token))
                        void this.advanceImplementation(token);
                }, this.implementationPolling?.interval ?? POLL_INTERVAL_MS);
            }
        }
        catch (error) {
            if (this.implementationContextCurrent(token))
                this.actionError = error instanceof Error ? error.message : 'review.implementation.error.run';
        }
        finally {
            this.implementationBusy = false;
        }
    }
    hasImplementation() {
        return this.version === 'tobe' && this.isCurrentLoad() && !!this.implementation
            && reviewImplementationVisible(this.implementation, this.data);
    }
    implementationComplete() {
        return this.hasImplementation() && implementationProgress(this.implementation, this.implementation?.changeId ?? null, this.project, this.moduleName)
            .every(phase => phase.status === 'concluido');
    }
    async finalizeImplementation(token) {
        if (!this.implementationContextCurrent(token) || this.confirmationBusy || this.implementationCancelRequested || !this.implementationComplete() || !this.data?.changeId)
            return;
        const record = this.implementation;
        if (record.changeId !== this.data.changeId || record.revisionId !== this.data.revisionId)
            return;
        this.confirmationBusy = true;
        this.actionError = '';
        try {
            await completeTobeImplementation(this.project, this.moduleName, record.changeId, record.revisionId, getUserId() || '');
            if (this.implementationContextCurrent(token))
                this.announceImplementationState(false);
        }
        catch (error) {
            if (this.implementationContextCurrent(token))
                this.actionError = error instanceof Error ? error.message : 'review.implementation.error.run';
        }
        finally {
            if (token === this.loadToken)
                this.confirmationBusy = false;
        }
    }
    async loadImplementationDiff(token) {
        const baseId = this.data?.sealedRevision?.manifest.baseId;
        if (!this.implementationContextCurrent(token))
            return;
        if (!baseId) {
            this.implementationDiffError = true;
            return;
        }
        try {
            const diff = await diffModuleLayers(this.project, this.moduleName, baseId);
            if (this.implementationContextCurrent(token)) {
                this.implementationDiff = diff;
                this.implementationDiffError = false;
            }
        }
        catch {
            if (this.implementationContextCurrent(token))
                this.implementationDiffError = true;
        }
    }
    async refuseImplementation() {
        const baseId = this.data?.sealedRevision?.manifest.baseId;
        if (!this.implementationComplete() || this.implementationBusy || this.implementationRestored || !baseId)
            return;
        if (!window.confirm(this.t('review.implementation.refuseConfirm')))
            return;
        const token = this.loadToken;
        const { project, moduleName } = this;
        this.implementationBusy = true;
        this.actionError = '';
        try {
            await restoreModuleFromSeals(project, moduleName, baseId);
            if (!this.implementationContextCurrent(token))
                return;
            this.implementationRestored = true;
            await this.loadImplementationDiff(token);
        }
        catch {
            if (this.implementationContextCurrent(token))
                this.actionError = 'review.implementation.error.refuse';
        }
        finally {
            this.implementationBusy = false;
        }
    }
    async discardFailedModule() {
        if (this.discardBusy || this.implementationBusy || this.actionBusy || !this.isCurrentLoad()
            || !this.implementation?.phases.some(phase => phase.status === 'failed'))
            return;
        if (!window.confirm(this.t('review.implementation.discardConfirm')))
            return;
        const { project, moduleName, version, data } = this;
        const token = this.loadToken;
        const current = () => token === this.loadToken && project === this.project && moduleName === this.moduleName
            && version === this.version && data === this.data;
        this.discardBusy = true;
        this.discardError = '';
        try {
            await this.discardModule(project, moduleName);
            window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, {
                detail: { project, moduleName, version: 'asis' },
            }));
        }
        catch (error) {
            console.error('[newRelease] module discard failed', error);
            if (current()) {
                const reason = error instanceof Error ? error.message : String(error);
                const translated = this.t(reason);
                this.discardError = this.t('review.implementation.discardError', { reason: translated });
            }
        }
        finally {
            this.discardBusy = false;
        }
    }
    /** Localize only the closing receipt; keep the stored agent report untouched. */
    implementationReport(report) {
        return report.replace(/(^|\r?\n)menu\.json (removed|kept: ([^\r\n]*))(?=(?:\r?\n)*$)/u, (_line, separator, status, reason) => {
            if (status === 'removed')
                return separator + this.t('review.implementation.menu.removed');
            const reasons = {
                absent: 'absent',
                'finalize70 not approved': 'notApproved',
                'l1 incomplete': 'incomplete',
                'delete left the file': 'deleteFailed',
            };
            const known = reason !== undefined && Object.hasOwn(reasons, reason) ? reasons[reason] : null;
            return separator + (known ? this.t(`review.implementation.menu.${known}`)
                : this.t('review.implementation.menu.technicalError', { reason: reason ?? '' }));
        });
    }
    async copyImplementationReport(report) {
        try {
            await navigator.clipboard.writeText(report);
            this.implementationCopyFeedback = this.t('common.copied');
        }
        catch (error) {
            console.error('[newRelease] report copy failed', error);
            this.implementationCopyFeedback = this.t('common.copyFailed');
        }
    }
    async copyDetail(key, value) {
        this.detailCopyKey = key;
        try {
            await navigator.clipboard.writeText(typeof value === 'string' ? value : JSON.stringify(value, null, 2));
            this.detailCopyFeedback = this.t('common.copied');
        }
        catch {
            this.detailCopyFeedback = this.t('common.copyFailed');
        }
    }
    renderDetailCopy(key, value) {
        return html `<div class="nr-review__detail-copy"><button type="button" @click=${() => void this.copyDetail(key, value)}>${this.t('common.copy')}</button>
      ${this.detailCopyKey === key ? html `<span role="status">${this.detailCopyFeedback}</span>` : nothing}</div>`;
    }
    renderImplementation(placement) {
        if (!this.hasImplementation())
            return nothing;
        const complete = this.implementationComplete();
        const phases = implementationProgress(this.implementation, this.implementation?.changeId ?? null, this.project, this.moduleName);
        const commands = implementationCommands(this.implementation, this.project, this.moduleName);
        const materialize = this.implementation.merged.materialize;
        return html `
      <section class=${`nr-review__run nr-review__implementation is-${placement}`} aria-live=${placement === 'top' ? 'polite' : 'off'}>
        ${this.implementationPolling?.paused ? html `<p>${this.t('review.implementation.pollingPaused', { taskId: this.implementationPolling.taskId })}
          <button type="button" ?disabled=${this.implementationCheckBusy} @click=${() => this.checkImplementationTask()}>${this.t('review.implementation.checkNow')}</button>
        </p>` : nothing}
        ${this.implementationCheckFeedback ? html `<p role="status">${this.implementationCheckFeedback}</p>` : nothing}
        <details class="nr-review__implementation-details nr-review__text-detail"><summary>${this.t('review.implementation.details')}</summary>
        ${this.renderDetailCopy('implementation', { plan: this.implementation?.merged, phases: this.implementation?.phases })}
        <p class="nr-review__implementation-note">${this.t(complete ? 'review.implementation.completedBody' : 'review.implementation.changesPendingBody')}</p>
        ${materialize.length ? html `<section class="nr-review__implementation-materialize">
          <h4>${this.t('review.implementation.materialize')}</h4>
          <ul>${materialize.map(unit => html `<li><code>${unit.path}</code></li>`)}</ul>
        </section>` : nothing}
        ${phases.length ? html `
        <ol>
          ${phases.map(phase => html `
            <li class=${`is-${phase.status}`}>
              <div class="nr-review__phase-heading">
                <strong>${implementationCommands(this.implementation, this.project, this.moduleName)[Number(phase.name.split(':')[1])]?.agent}</strong>
                <span>${this.t(`review.implementation.status.${phase.status}`)}</span>
                ${phase.attempt ? html `<small>${this.t('review.implementation.attempt', { attempt: phase.attempt })}</small>` : nothing}
              </div>
              ${this.implementation?.phases.find(item => item.name === phase.name)?.report ? html `<details class="nr-review__phase-report">
                <summary>${this.t('review.implementation.reportDetails')}</summary>
                <button type="button" @click=${() => void this.copyImplementationReport(this.implementation.phases.find(item => item.name === phase.name).report)}>${this.t('common.copy')}</button>
                ${this.implementationCopyFeedback ? html `<span role="status">${this.implementationCopyFeedback}</span>` : nothing}
                <pre>${this.implementationReport(this.implementation.phases.find(item => item.name === phase.name).report)}</pre>
              </details>` : nothing}
              ${phase.error ? html `<p class="nr-review__implementation-error">${this.tStoredReviewError(phase.error)}</p>` : nothing}
              ${phase.previousAttempts?.length ? html `<details>
                <summary>${this.t('review.implementation.previousAttempts')}</summary>
                ${phase.previousAttempts.map(previous => html `<p>${this.t('review.implementation.attempt', { attempt: previous.attempt })}: ${previous.error || this.t('review.implementation.status.falhou')}</p>`)}
              </details>` : nothing}
              ${phase.changedDefs?.length ? html `<details>
                <summary>${this.t('review.implementation.changedDefs', { count: phase.changedDefs.length })}</summary>
                <ul>${phase.changedDefs.map(file => html `<li><code>${file.path}</code> <span>${this.t(`review.implementation.file.${file.status}`)}</span></li>`)}</ul>
              </details>` : nothing}
              ${phase.podeTentarDeNovo ? html `
                <button type="button" class="nr-review__implementation-retry" ?disabled=${this.implementationBusy || this.discardBusy}
                  @click=${() => void this.advanceImplementation(this.loadToken, phase.name)}>${this.t('review.implementation.retry')}</button>
              ` : nothing}
            </li>
          `)}
        </ol>` : nothing}
        ${this.implementation?.phases.some(phase => phase.status === 'failed') ? html `
          <button type="button" ?disabled=${this.discardBusy || this.implementationBusy || this.actionBusy}
            @click=${() => this.discardFailedModule()}>${this.t('review.implementation.discardModule')}</button>
          ${this.discardError ? html `<p role=${placement === 'top' ? 'alert' : nothing}>${this.discardError}</p>` : nothing}
        ` : nothing}
        ${this.actionError ? html `<p role=${placement === 'top' ? 'alert' : nothing}>${this.tStoredReviewError(this.actionError)}</p>` : nothing}
        ${complete ? html `
          ${this.implementationDiffError ? html `<p>${this.t('review.implementation.error.diff')}</p>` : this.implementationDiff === null ? html `<p>${this.t('state.loading')}</p>` : html `
            ${[2, 1].map(level => html `<details class="nr-review__implementation-level">
              <summary>${this.t('review.implementation.level', { level })}</summary>
              <ul>${this.implementationDiff.filter(file => file.level === level).map(file => html `
                <li><code>${file.path}</code> <span>${this.t(`review.implementation.file.${file.status}`)}</span></li>
              `)}</ul>
              ${!this.implementationDiff.some(file => file.level === level) ? html `<p>${this.t('review.implementation.noChanges')}</p>` : nothing}
            </details>`)}
          `}
        ${this.implementationRestored ? html `<p>${this.t('review.implementation.restored')}</p>` : html `
            <button type="button" class="nr-review__implementation-refuse" ?disabled=${this.implementationBusy || !this.data?.sealedRevision?.manifest.baseId}
              @click=${() => void this.refuseImplementation()}>${this.t('review.implementation.refuse')}</button>
          `}
        ` : nothing}
        </details>
        <div class="nr-review__task-grid">${commands.map((command, index) => html `<div class="nr-review__task-slot">
          <span>${command.agent}</span>${this.renderImplementationTask(`runAgents:${index}`)}
        </div>`)}</div>
      </section>
    `;
    }
    renderImplementationTask(phaseName) {
        const phase = this.implementation?.phases.find(item => item.name === phaseName);
        if (!phase?.taskId)
            return html `<div class="nr-review__task-loading" role="status">${this.t(phase?.status === 'running'
                ? 'review.implementation.starting' : 'review.implementation.waiting')}</div>`;
        const task = this.implementationTasks[phaseName];
        if (!task || task.PK.replace(/^task(?:\/#?|#)/u, '') !== phase.taskId) {
            return this.implementationTaskSettled[phaseName] ? html `<button type="button" class="nr-review__task-loading"
        @click=${() => { if (phase.threadId)
                dispatchThreadOpen(phase.threadId, phase.taskId); }}
      >${this.t('review.implementation.taskDetails', { id: phase.taskId })}</button>`
                : html `<div class="nr-review__task-loading" role="status">${this.t('review.implementation.taskLoading')}</div>`;
        }
        const messageOrderAt = phase.messageId.split('/').pop() || '';
        const context = {
            message: {
                threadId: phase.threadId,
                orderAt: messageOrderAt,
                createAt: messageOrderAt.slice(0, 14),
                senderId: getUserId() || '',
                content: phase.command,
                taskId: phase.taskId,
                taskStatus: task.status,
            },
            task,
            isTest: false,
        };
        const lastChanged = `${phase.taskId}:${this.implementationTaskChanges[phaseName] || 0}`;
        return html `<collab-messages-task-102025 class="nr-review__task-card"
      taskid=${phase.taskId} threadId=${phase.threadId} messageid=${phase.messageId}
      userId=${getUserId() || ''} .context=${context} lastChanged=${lastChanged}
      @taskclick=${() => { if (phase.threadId)
            dispatchThreadOpen(phase.threadId, phase.taskId); }}
    ></collab-messages-task-102025>`;
    }
    renderPlannedImplementation(view) {
        const commands = !this.hasRelease && this.initialPlan
            ? implementationCommands({
                initial: { plan: this.initialPlan, replan: !this.initialPlan.fresh || !!this.data?.diffs.some(diff => diff.entries.length), promotedAt: '' },
                merged: { create: [], regenerateDefs: [], remove: [], materialize: [], runAgents: [], abend: [] },
            }, this.project, this.moduleName)
            : view.kind === 'ready' && this.effortCurrent ? implementationCommands({ merged: view.merged }, this.project, this.moduleName) : [];
        if (!commands.length)
            return nothing;
        return html `<div class="nr-review__planned-implementation">
      <details class="nr-review__implementation-details"><summary>${this.t('review.implementation.details')}</summary>
        <p>${this.t('review.implementation.waitingBody')}</p>
      </details>
      <div class="nr-review__task-grid">${commands.map(command => html `<div class="nr-review__task-slot">
        <span>${command.agent}</span><div class="nr-review__task-loading">${this.t('review.implementation.waiting')}</div>
      </div>`)}</div>
    </div>`;
    }
    renderConfirmedTask(phase) {
        if (!phase.taskId)
            return nothing;
        const task = this.confirmedTasks[phase.taskId];
        if (!task)
            return html `<button type="button" class="nr-review__task-loading"
      @click=${() => { if (phase.threadId)
                dispatchThreadOpen(phase.threadId, phase.taskId); }}
    >${this.t('review.implementation.taskDetails', { id: phase.taskId })}</button>`;
        const orderAt = phase.messageId.split('/').pop() || '';
        const context = { message: { threadId: phase.threadId, orderAt, createAt: orderAt.slice(0, 14),
                senderId: getUserId() || '', content: phase.command, taskId: phase.taskId, taskStatus: task.status }, task, isTest: false };
        return html `<collab-messages-task-102025 class="nr-review__task-card" taskid=${phase.taskId}
      threadId=${phase.threadId} messageid=${phase.messageId} userId=${getUserId() || ''}
      .context=${context} lastChanged=${`${phase.taskId}:${task.last_updated}`}
      @taskclick=${() => { if (phase.threadId)
            dispatchThreadOpen(phase.threadId, phase.taskId); }}
    ></collab-messages-task-102025>`;
    }
    renderConfirmedRounds() {
        if (!this.confirmedRounds.length)
            return nothing;
        return html `<section class="nr-review__panel nr-review__history">
      <details><summary>${this.t('review.rounds.title', { count: this.confirmedRounds.length })}</summary>
        ${this.confirmedRounds.map(round => html `<details class="nr-review__round">
          <summary>${this.t('review.rounds.item', { date: new Date(round.confirmedAt).toLocaleString(), id: round.record.changeId.slice(-8) })}</summary>
          <p>${this.t('review.rounds.confirmedBy', { user: round.confirmedBy || '—' })}</p>
          <div class="nr-review__task-grid">${implementationCommands(round.record, this.project, this.moduleName).map((command, index) => {
            const phase = round.record.phases.find(item => item.name === `runAgents:${index}`);
            return html `<div class="nr-review__task-slot"><span>${command.agent}</span>${phase ? this.renderConfirmedTask(phase) : nothing}</div>`;
        })}</div>
          <details><summary>${this.t('review.implementation.details')}</summary>
            <dl><div><dt>${this.t('review.rounds.changeId')}</dt><dd><code>${round.record.changeId}</code></dd></div>
              <div><dt>${this.t('review.rounds.revisionId')}</dt><dd><code>${round.record.revisionId}</code></dd></div></dl>
            ${['create', 'regenerateDefs', 'materialize', 'remove'].map(operation => html `<section>
              <h4>${this.t(`review.effort.operation.${operation}`)}</h4>
              ${round.record.merged[operation].length ? html `<ul>${round.record.merged[operation].map(unit => html `<li>${unit.kind}: ${unit.id} <code>${unit.path}</code></li>`)}</ul>`
            : html `<p>${this.t('review.effort.none')}</p>`}
            </section>`)}
            ${round.record.phases.map(phase => html `<section><strong>${phase.agent}</strong>
              <p>${this.t(`review.implementation.status.${phase.status === 'done' ? 'concluido' : phase.status === 'failed' ? 'falhou' : 'executando'}`)}</p>
              ${phase.changedDefs?.length ? html `<details><summary>${this.t('review.implementation.changedDefs', { count: phase.changedDefs.length })}</summary>
                <ul>${phase.changedDefs.map(file => html `<li><code>${file.path}</code> ${this.t(`review.implementation.file.${file.status}`)}</li>`)}</ul>
              </details>` : nothing}
              ${phase.report ? html `<pre>${this.implementationReport(phase.report)}</pre>` : nothing}
            </section>`)}
          </details>
        </details>`)}
      </details>
    </section>`;
    }
    retryStartInput(run, userId) {
        const identity = this.identityForRun(run, userId);
        const { runId: _runId, ...input } = identity;
        const request = run.binding.request;
        if (!Number.isSafeInteger(run.binding.inputRevisionNumber) || run.binding.inputRevisionNumber < 1
            || typeof request !== 'string' || request.length < 1 || request.length > 65536) {
            throw new Error('review-run.invalid_request');
        }
        return { ...input, inputRevisionNumber: run.binding.inputRevisionNumber, request };
    }
    actionPresentation(view, current) {
        if (this.isInitialGeneration() && (this.version === 'asis' || this.version === 'tobe')) {
            return { kind: 'continue', labelKey: this.actionBusy ? 'review.actionBusy' : 'review.implementation.accept',
                descriptionKey: 'review.panels.fullGenerationBody', availabilityKey: getUserId() ? '' : 'request.userUnavailable',
                disabled: !current || this.loading || this.actionBusy || !this.initialPlan || !!this.implementation || !getUserId()
                    || this.data?.pipeline?.status !== 'complete' || this.data?.validation.ok !== true,
                busy: this.actionBusy, error: this.actionError ? [this.tStoredReviewError(this.actionError), this.initialErrorDetail].filter(Boolean).join(': ') : '' };
        }
        const backend = buildBackendReview(this.backendRead, view.kind === 'pending', this.moduleName);
        const effort = parseEffortSummary(this.effortRead, this.moduleName);
        const active = !!this.channelRun && !['ready', 'failed', 'disputed'].includes(this.channelRun.status);
        const retry = this.channelRun?.status === 'failed' || this.channelRun?.status === 'disputed';
        const action = buildReviewActionPresentation({
            viewKind: retry ? 'pending' : view.kind,
            version: this.version,
            loading: this.loading,
            current,
            resultCurrent: retry ? false : this.data?.resultCurrent === true,
            backendKind: backend.kind,
            effortKind: effort.kind,
            busy: this.actionBusy,
            connected: retry ? !active && !!getUserId() : canStartReviewRun({
                project: this.project,
                moduleName: this.moduleName,
                changeId: this.data?.changeId ?? null,
                revisionId: this.data?.revisionId ?? null,
                request: this.request,
                userId: getUserId(),
                hasRun: !!this.channelRun,
                sealedRevision: this.data?.sealedRevision ?? null,
            }),
            retry,
            retryAvailable: !retry || this.channelRun.attempt < REVIEW_RUN_MAX_ATTEMPTS,
            error: this.actionError ? this.tStoredReviewError(this.actionError) : '',
        });
        const accepted = this.implementation?.changeId === this.data?.changeId
            && this.implementation?.revisionId === this.data?.revisionId && !!this.implementation;
        const changeEffort = buildChangeEffortView(this.changeEffortRead);
        if (this.version === 'tobe' && current && changeEffort.kind !== 'missing'
            && this.data?.resultCurrent && this.effortCurrent) {
            const reason = changeEffort.kind !== 'ready' ? 'review.effort.invalid'
                : changeEffort.status === 'blocked' ? 'review.effort.status.blocked'
                    : 'review.implementation.body';
            return { ...action, kind: 'continue',
                labelKey: this.actionBusy ? 'review.actionBusy' : accepted ? 'review.implementation.accepted' : 'review.implementation.accept',
                descriptionKey: accepted ? this.implementationComplete() ? 'review.implementation.completedBody' : 'review.implementation.runningBody' : reason,
                availabilityKey: '', disabled: this.actionBusy || this.loading || accepted || !getUserId() || !this.canImplement(),
            };
        }
        if (this.version === 'tobe' && current && accepted) {
            return { ...action, kind: 'continue',
                labelKey: this.actionBusy ? 'review.actionBusy' : accepted ? 'review.implementation.accepted' : 'review.implementation.accept',
                descriptionKey: accepted ? this.implementationComplete() ? 'review.implementation.completedBody' : 'review.implementation.runningBody' : 'review.implementation.body',
                availabilityKey: '',
                disabled: this.actionBusy || this.loading || accepted || !getUserId() || !this.canImplement(),
            };
        }
        if (this.version === 'tobe' && current && !this.effortCurrent && !active && !retry)
            return {
                ...action, kind: 'calculate', labelKey: this.actionBusy ? 'review.actionBusy' : 'review.calculate',
                descriptionKey: 'review.actionCalculateBody', availabilityKey: getUserId() ? '' : 'request.userUnavailable',
                disabled: this.actionBusy || this.loading || !getUserId() || !this.data?.sealedRevision,
            };
        return action;
    }
    reviewRunErrorKey(code) {
        if (code && /(?:^| \| reason: )review\.not_publishable:(invalid|unsupported):([A-Z][A-Z0-9_]*(?:,[A-Z][A-Z0-9_]*){0,4})?$/u.test(code))
            return 'review.run.error.notPublishable';
        if (code?.startsWith('review-worker.agent_paused'))
            return 'review.run.error.agentPaused';
        if (code === 'review.run.error.agentPaused')
            return code;
        if (code === 'review-run.planner_result_contract_pending')
            return 'review.run.error.resultPending';
        if (code === 'review-run.channel_failed' || code === 'review-run.channel_ended_without_terminal') {
            return 'review.run.error.channel';
        }
        if (code === 'review-run.invalid_terminal_result')
            return 'review.run.error.invalidResult';
        if (code === 'review-run.hub_publish_conflict')
            return 'review.run.error.hubConflict';
        if (code === 'candidate.supersede_mismatch')
            return 'review.run.error.supersedeMismatch';
        if (code === 'review-run.hub_revision_differs')
            return 'review.run.error.hubRevisionDiffers';
        return code ? 'review.run.error.generic' : '';
    }
    tReviewRunError(code) {
        const key = this.reviewRunErrorKey(code);
        if (key === 'review.run.error.notPublishable') {
            const [, status = '', codes = ''] = code.match(/(?:^| \| reason: )review\.not_publishable:(invalid|unsupported):([A-Z][A-Z0-9_]*(?:,[A-Z][A-Z0-9_]*){0,4})?$/u);
            return this.t(key, { status, codes });
        }
        if (key !== 'review.run.error.agentPaused')
            return this.t(key);
        const prefix = 'review-worker.agent_paused';
        const motivo = code?.startsWith(prefix) ? code.slice(prefix.length).replace(/^:/, '') : '';
        return this.t(key, { motivo });
    }
    renderGenericFailureDetail(run) {
        if (run.status !== 'failed' || this.reviewRunErrorKey(run.errorCode) !== 'review.run.error.generic')
            return nothing;
        const taskId = run.executions[0]?.taskId;
        if (!run.errorCode && !taskId)
            return nothing;
        return html `
      <div>
        ${run.errorCode ? html `<p><span>${this.t('review.run.error.generic.code')}</span> <code style="overflow-wrap:anywhere;white-space:pre-wrap">${run.errorCode}</code></p>` : nothing}
        ${taskId ? html `<p><span>${this.t('review.run.error.generic.task')}</span> <code>${taskId}</code></p>` : nothing}
      </div>
    `;
    }
    tStoredReviewError(stored) {
        if (stored.startsWith('review-worker.agent_paused') || stored === 'review.run.error.agentPaused') {
            return this.tReviewRunError(stored);
        }
        return this.t(stored);
    }
    reviewRunCopyText(run) {
        const execution = 'executions' in run ? run.executions.at(-1) : undefined;
        const saved = 'taskId' in run ? run : undefined;
        const output = 'output' in run ? run.output : undefined;
        return `${this.t('review.run.title')}\n${JSON.stringify({
            project: this.project,
            moduleName: this.moduleName,
            status: run.status,
            errorCode: run.errorCode,
            runId: run.runId,
            taskId: execution?.taskId ?? saved?.taskId ?? null,
            threadId: execution?.threadId ?? saved?.threadId ?? null,
            attempt: 'attempt' in run ? run.attempt : run.attemptsUsed,
            provider: execution?.provider ?? null,
            model: execution?.model ?? null,
            changeId: run.binding.changeId,
            inputRevisionId: run.binding.inputRevisionId,
            requestRevision: run.binding.requestRevision,
            resultRunId: execution?.resultRunId ?? null,
            resultId: output?.result.resultId ?? null,
            resultTaskId: output?.result.manifest.taskId ?? null,
            traceHash: output?.result.manifest.traceHash ?? null,
        }, null, 2)}`;
    }
    async copyReviewRun(run) {
        this.reviewCopyRunId = run.runId;
        try {
            await navigator.clipboard.writeText(this.reviewRunCopyText(run));
            this.reviewCopyFeedback = this.t('common.copied');
        }
        catch {
            this.reviewCopyFeedback = this.t('common.copyFailed');
        }
    }
    renderReviewRunCopy(run) {
        return html `<div class="nr-review__copy-actions">
      <button type="button" @click=${() => void this.copyReviewRun(run)}>${this.t('common.copy')}</button>
      ${this.reviewCopyRunId === run.runId && this.reviewCopyFeedback ? html `<span role="status">${this.reviewCopyFeedback}</span>` : nothing}
    </div>`;
    }
    renderReviewRun() {
        if (this.version !== 'tobe')
            return nothing;
        if (this.reviewRunLoadError) {
            return html `<section class="nr-review__run"><p role="alert">${this.tStoredReviewError(this.reviewRunLoadError)}</p></section>`;
        }
        const channel = this.channelRun;
        if (channel) {
            const execution = channel.executions[channel.executions.length - 1];
            const terminal = channel.status === 'ready' || channel.status === 'failed' || channel.status === 'disputed';
            const stateKey = terminal ? `review.run.status.${channel.status}` : `review.run.phase.${channel.status}`;
            return html `
        <section class=${`nr-review__run is-${channel.status}`} aria-live="polite">
          <header><div><span>${this.t('review.run.eyebrow')}</span><h3>${this.t('review.run.title')}</h3></div><strong>${this.t(stateKey)}</strong></header>
          ${channel.errorCode ? html `<p role="alert">${this.tReviewRunError(channel.errorCode)}</p>` : nothing}
          ${this.renderGenericFailureDetail(channel)}
          <dl>
            <div><dt>${this.t('review.run.runId')}</dt><dd><code>${channel.runId}</code></dd></div>
            ${execution?.taskId ? html `<div><dt>${this.t('review.run.taskId')}</dt><dd><code>${execution.taskId}</code></dd></div>` : nothing}
            ${execution?.threadId ? html `<div><dt>${this.t('review.run.threadId')}</dt><dd><code>${execution.threadId}</code></dd></div>` : nothing}
            ${execution?.provider ? html `<div><dt>${this.t('review.run.provider')}</dt><dd><code>${execution.provider}</code></dd></div>` : nothing}
            ${execution?.model ? html `<div><dt>${this.t('review.run.model')}</dt><dd><code>${execution.model}</code></dd></div>` : nothing}
          </dl>
          ${this.renderReviewRunCopy(channel)}
        </section>
      `;
        }
        const run = this.reviewRun;
        if (!run)
            return nothing;
        const terminal = run.status === 'ready' || run.status === 'failed' || run.status === 'disputed';
        const stateKey = terminal ? `review.run.status.${run.status}` : `review.run.phase.${run.phase}`;
        const errorKey = this.reviewRunErrorKey(run.errorCode);
        return html `
      <section class=${`nr-review__run is-${run.status}`} aria-live="polite">
        <header>
          <div><span>${this.t('review.run.eyebrow')}</span><h3>${this.t('review.run.title')}</h3></div>
          <strong>${this.t(stateKey)}</strong>
        </header>
        ${run.superseded ? html `<p>${this.t('review.run.superseded')}</p>` : nothing}
        ${errorKey ? html `<p role="alert">${this.tReviewRunError(run.errorCode)}</p>` : nothing}
        <dl>
          <div><dt>${this.t('review.run.runId')}</dt><dd><code>${run.runId}</code></dd></div>
          ${run.taskId ? html `<div><dt>${this.t('review.run.taskId')}</dt><dd><code>${run.taskId}</code></dd></div>` : nothing}
          ${run.threadId ? html `<div><dt>${this.t('review.run.threadId')}</dt><dd><code>${run.threadId}</code></dd></div>` : nothing}
          ${run.output ? html `
            <div><dt>${this.t('review.run.resultId')}</dt><dd><code>${run.output.result.resultId}</code></dd></div>
            <div><dt>${this.t('review.run.manifestTaskId')}</dt><dd><code>${run.output.result.manifest.taskId}</code></dd></div>
            <div><dt>${this.t('review.run.trace')}</dt><dd><code>${run.output.result.manifest.traceHash}</code></dd></div>
          ` : nothing}
        </dl>
        ${this.renderReviewRunCopy(run)}
      </section>
    `;
    }
    async loadReviewTask(token) {
        const taskId = this.channelRun?.executions.at(-1)?.taskId ?? this.reviewRun?.taskId;
        const threadId = this.channelRun?.executions.at(-1)?.threadId ?? this.reviewRun?.threadId;
        if (!taskId) {
            this.reviewTask = null;
            this.reviewTaskSettled = false;
            return;
        }
        this.reviewTaskSettled = false;
        try {
            let task = await getTask(taskId);
            if (!task && threadId && getUserId()) {
                const cached = await getAllMessagesByThreadId(threadId);
                const cachedMessage = cached.find(item => item.taskId?.replace(/^task(?:\/#?|#)/u, '') === taskId);
                let messageId = cachedMessage ? `${threadId}/${cachedMessage.orderAt || cachedMessage.createAt}` : '';
                if (!messageId) {
                    const response = await msgGetMessagesAfter({ userId: getUserId(), threadId, lastOrderAt: '' });
                    const remoteMessage = response.success ? response.response?.data?.find(item => item.taskId?.replace(/^task(?:\/#?|#)/u, '') === taskId) : undefined;
                    if (remoteMessage)
                        messageId = `${threadId}/${remoteMessage.orderAt || remoteMessage.createAt}`;
                }
                if (messageId) {
                    const response = await msgGetTaskUpdate({ userId: getUserId(), taskId, messageId });
                    task = response.success ? response.response?.task ?? null : null;
                    if (task)
                        await addOrUpdateTask(task);
                }
            }
            if (token === this.loadToken)
                this.reviewTask = task?.PK.replace(/^task(?:\/#?|#)/u, '') === taskId ? task : null;
        }
        catch (error) {
            console.error('[newRelease] review task snapshot unavailable', error);
            if (token === this.loadToken)
                this.reviewTask = null;
        }
        finally {
            if (token === this.loadToken)
                this.reviewTaskSettled = true;
        }
    }
    renderReviewTask() {
        const execution = this.channelRun?.executions.at(-1);
        const taskId = execution?.taskId ?? this.reviewRun?.taskId;
        const threadId = execution?.threadId ?? this.reviewRun?.threadId;
        if (!taskId || !threadId)
            return nothing;
        const task = this.reviewTask;
        if (!task || task.PK.replace(/^task(?:\/#?|#)/u, '') !== taskId) {
            return this.reviewTaskSettled ? html `<button type="button" class="nr-review__task-loading"
        @click=${() => dispatchThreadOpen(threadId, taskId)}>${this.t('review.implementation.taskDetails', { id: taskId })}</button>`
                : html `<div class="nr-review__task-loading" role="status">${this.t('review.implementation.taskLoading')}</div>`;
        }
        const messageId = task.messageid_created || '';
        const orderAt = messageId.split('/').pop() || '';
        const context = { message: { threadId, orderAt, createAt: orderAt.slice(0, 14), senderId: getUserId() || '', content: '', taskId, taskStatus: task.status }, task, isTest: false };
        return html `<div class="nr-review__review-task"><collab-messages-task-102025 class="nr-review__task-card"
      taskid=${taskId} threadId=${threadId} messageid=${messageId} userId=${getUserId() || ''}
      .context=${context} lastChanged=${`${taskId}:${task.last_updated}`}
      @taskclick=${() => dispatchThreadOpen(threadId, taskId)}
    ></collab-messages-task-102025></div>`;
    }
    renderPrimaryAction(block, includeUndo = false) {
        const { placement } = block;
        const action = this.identityError ? { ...block.action, disabled: true,
            availabilityKey: this.identityError === 'pending' ? 'request.identityPending' : 'request.identityUnavailable' } : block.action;
        const showUndo = includeUndo && this.applicationCheckpoint && this.hasImplementation();
        const running = this.implementationPending();
        return html `
      <section class=${`nr-review__primary-action is-${placement}${showUndo ? ' has-undo' : ''}`} aria-busy=${action.busy ? 'true' : 'false'}>
        <div>
          <p>${this.t(action.descriptionKey)}</p>
          ${action.availabilityKey ? html `<small>${this.t(action.availabilityKey, { reason: this.identityError })}</small>` : nothing}
          ${action.error ? html `<p class="nr-review__action-error" role=${block.announceError ? 'alert' : nothing}>${action.error}</p>` : nothing}
        </div>
        <div class="nr-review__action-buttons">
          ${showUndo ? html `<button type="button" class="nr-review__undo-action"
            ?disabled=${this.implementationCancelBusy || this.loading}
            aria-disabled=${this.implementationCancelBusy || this.loading ? 'true' : 'false'}
            @click=${() => void this.undoLastApplication()}>${this.t(this.implementationCancelBusy
            ? 'review.implementation.undoWaiting' : running ? 'review.implementation.cancel' : 'review.implementation.undo')}</button>` : nothing}
          <button
            type="button"
            ?disabled=${action.disabled}
            aria-disabled=${action.disabled ? 'true' : 'false'}
            @click=${this.runReviewPrimaryAction}
          >${this.t(action.labelKey)}</button>
        </div>
      </section>
    `;
    }
    tableTitle(entity) {
        const value = this.data?.artifacts.entities.find(item => item.value?.entityId === entity)?.value;
        return value?.title || entity;
    }
    renderBackendItem(item, knownTables) {
        const status = this.t(`review.backend.status.${item.tone}`);
        const tableNames = item.tableRefs.join(', ');
        const unresolved = item.tableRefs.filter(ref => !knownTables.has(ref));
        return html `
      <details class=${`nr-review__backend-item is-${item.tone}`}>
        <summary>
          <div><span>${this.t(`review.backend.kind.${item.kind}`)}</span><strong>${item.kind === 'table' ? this.tableTitle(item.entity) : item.label}</strong></div>
          <small class=${`nr-review__badge is-${item.tone}`} aria-label=${status}>${status}${item.tone === 'unknown' && item.status ? ` · ${item.status}` : ''}</small>
        </summary>
        <div class="nr-review__backend-item-detail">
          ${item.kind === 'table' || item.kind === 'change' ? html `<code>${item.kind === 'table' ? item.detail : item.label}</code>` : nothing}
          ${item.detail && item.kind !== 'table' ? html `<p><span>${this.t(item.kind === 'usecase' ? 'review.backend.operation'
            : item.kind === 'endpoint' ? 'review.backend.usecases'
                : 'review.backend.detail')}</span> ${item.detail}</p>` : nothing}
          ${item.reason ? html `<p><span>${this.t('review.backend.reason')}</span> ${item.reason}</p>` : nothing}
          ${item.source ? html `<p><span>${this.t('review.backend.source')}</span> <code>${item.source}</code></p>` : nothing}
          ${item.usecaseRefs.length ? html `<p><span>${this.t('review.backend.usecases')}</span> ${item.usecaseRefs.join(', ')}</p>` : nothing}
          ${item.tableRefs.length ? html `<p><span>${this.t('review.backend.tables')}</span> ${tableNames}</p>` : nothing}
          ${!item.tableRefs.length ? html `<p class="nr-review__backend-limitation">${this.t(`review.backend.noTable.${item.noTable}`)}</p>` : nothing}
          ${unresolved.length ? html `<p class="nr-review__backend-limitation">${this.t('review.backend.unresolvedRefs', { refs: unresolved.join(', ') })}</p>` : nothing}
        </div>
      </details>
    `;
    }
    renderBackendGroup(title, technical, items, knownTables) {
        return html `
      <details class="nr-review__backend-group">
        <summary><span><strong>${title}</strong>${technical ? html `<code>${technical}</code>` : nothing}</span><small>${this.t('review.backend.itemCount', { count: items.length })}</small></summary>
        <div>${items.length ? items.map(item => this.renderBackendItem(item, knownTables)) : html `<p class="nr-review__backend-empty">${this.t('review.backend.noItems')}</p>`}</div>
      </details>
    `;
    }
    renderEffort(changeEffort) {
        const summary = parseEffortSummary(this.effortRead, this.moduleName);
        if (summary.kind === 'missing' && changeEffort.kind === 'ready')
            return nothing;
        return html `
      <section class="nr-review__effort" aria-label=${this.t('review.backend.effortTitle')}>
        <header><strong>${this.t('review.backend.effortTitle')}</strong><span>${this.t(summary.kind === 'counts' ? 'review.backend.partial' : summary.kind === 'invalid' ? 'review.backend.effortInvalid' : 'review.backend.notCalculated')}</span></header>
        ${summary.kind === 'counts' ? html `
          <p>${this.t('review.backend.effortCoverage')}</p>
          <div>${summary.counts.map(category => html `
            <div><strong>${this.t(`review.backend.count.${category.category}`)}</strong>
              <span>${category.statuses.map(value => {
            const tone = backendTone(value.status);
            return `${this.t(`review.backend.status.${tone}`)}${tone === 'unknown' ? ` (${value.status})` : ''}: ${value.count}`;
        }).join(' · ')}</span>
            </div>
          `)}</div>
        ` : nothing}
      </section>
    `;
    }
    renderChangeEffortUnits(label, units) {
        return html `<section><h4>${this.t(label)}</h4>
      ${units.length ? html `<ul>${units.map(unit => html `<li><strong>${unit.kind}: ${unit.id}</strong><code>${unit.path}</code></li>`)}</ul>`
            : html `<p>${this.t('review.effort.none')}</p>`}
    </section>`;
    }
    renderChangeEffort(view) {
        if (view.kind === 'missing')
            return nothing;
        return html `<section class="nr-review__change-effort" aria-label=${this.t('review.effort.title')}>
      <header><h3>${this.t('review.effort.title')}</h3>
        ${view.kind === 'invalid' ? html `<p class="nr-review__effort-abend" role="alert">${this.t('review.effort.invalid')}</p>` : html `
          <p class=${view.status === 'blocked' ? 'nr-review__effort-abend' : ''}>${this.t(`review.effort.status.${view.status}`)}</p>
          <p>${this.t('review.effort.untouched', { count: view.untouched.count })}</p><p>${this.t('review.effort.costUnavailable')}</p>
        `}
      </header>
      ${view.items.map(({ item, answers }) => html `<details class="nr-review__effort-item">
        <summary><strong>${item.kind} · ${item.op} · ${item.entity}</strong><code>${item.id}</code></summary>
        <div>${answers.map(answer => html `<article class="nr-review__effort-master">
          <h4>${this.t('review.effort.master', { project: answer.master.project, kind: answer.master.kind, device: answer.master.device })}</h4><p>${this.t('review.effort.contract')}: ${answer.contract}</p>
          ${answer.abend ? html `<p class="nr-review__effort-abend"><strong>${this.t('review.effort.abend')}</strong> ${answer.abend.reason}</p>` : nothing}
          ${this.renderChangeEffortUnits('review.effort.regenerateDefs', answer.regenerateDefs)}
          ${this.renderChangeEffortUnits('review.effort.materialize', answer.materialize)}
          <section><h4>${this.t('review.effort.runAgents')}</h4>
            ${answer.runAgents.length ? html `<ul>${answer.runAgents.map(agent => html `<li><strong>${agent.agent}</strong><code>${agent.command}</code></li>`)}</ul>`
            : html `<p>${this.t('review.effort.none')}</p>`}
          </section>
        </article>`)}</div>
      </details>`)}
    </section>`;
    }
    renderBackend(view) {
        // pool/l2/web holds the candidate result, not a snapshot of Atual or a past release.
        if (this.version !== 'tobe')
            return nothing;
        const stale = view.kind === 'pending';
        const backend = buildBackendReview(this.backendRead, stale, this.moduleName);
        const knownTables = new Set(backend.groups.map(group => group.tableId));
        return html `
      <section class="nr-review__backend" aria-label=${this.t('review.backend.title')}>
        <header>
          <div><span>${this.t('review.backend.eyebrow')}</span><h3>${this.t('review.backend.title')}</h3><p>${this.t('review.backend.moduleScope')}</p></div>
          ${backend.kind === 'ready' ? html `<strong>${this.t('review.backend.uniqueCount', { count: backend.itemCount })}</strong>` : nothing}
        </header>
        ${backend.kind === 'stale' ? html `<p class="nr-review__backend-message">${this.t('review.backend.stale')}</p>` : nothing}
        ${backend.kind === 'missing' ? html `<p class="nr-review__backend-message">${this.t('review.backend.missing')}</p>` : nothing}
        ${backend.kind === 'invalid' ? html `<p class="nr-review__backend-message" role="alert">${this.t(backend.errorCode)}</p>` : nothing}
        ${backend.kind === 'ready' ? html `
          <ul class="nr-review__backend-legend">
            ${['new', 'change', 'keep', 'remove', 'unknown'].map(tone => html `<li class=${`is-${tone}`}>${this.t(`review.backend.status.${tone}`)}</li>`)}
          </ul>
          <div class="nr-review__backend-groups">
            ${backend.groups.map(group => this.renderBackendGroup(group.entity ? this.tableTitle(group.entity) : this.t('review.backend.removedTable'), group.tableId, group.items, knownTables))}
            ${backend.shared.length ? this.renderBackendGroup(this.t('review.backend.shared'), '', backend.shared, knownTables) : nothing}
            ${backend.unassociated.length ? this.renderBackendGroup(this.t('review.backend.unassociated'), '', backend.unassociated, knownTables) : nothing}
          </div>
          ${this.renderTestSupport(backend.testSupport)}
        ` : nothing}
      </section>
    `;
    }
    renderTestSupportField(labelKey, value) {
        return value ? html `<p><span>${this.t(labelKey)}</span> ${value}</p>` : nothing;
    }
    renderTestSupportItem(item) {
        const tone = backendTone(item.status);
        const status = `${this.t(`review.backend.status.${tone}`)}${tone === 'unknown' ? ` (${item.status})` : ''}`;
        return html `
      <details class=${`nr-review__backend-item is-${tone}`}>
        <summary>
          <div>
            <span>${this.t('review.backend.testSupport.item')}</span>
            <strong>${item.id}</strong>
            ${item.gap ? html `<small class="nr-review__test-gap">${this.t('review.backend.testSupport.gap')}: ${item.gap}</small>` : nothing}
          </div>
          <small class=${`nr-review__badge is-${tone}`}>${status}</small>
        </summary>
        <div class="nr-review__backend-item-detail">
          ${this.renderTestSupportField('review.backend.testSupport.id', item.id)}
          ${this.renderTestSupportField('review.backend.testSupport.actorRefs', item.actorRefs.join(', '))}
          ${this.renderTestSupportField('review.backend.testSupport.entityRefs', item.entityRefs.join(', '))}
          ${this.renderTestSupportField('review.backend.testSupport.sourceRefs', item.sourceRefs.join(', '))}
          ${this.renderTestSupportField('review.backend.testSupport.status', status)}
          ${this.renderTestSupportField('review.backend.testSupport.owner', item.owner)}
          ${this.renderTestSupportField('review.backend.testSupport.executorRef', item.executorRef)}
          ${this.renderTestSupportField('review.backend.testSupport.cleanupRef', item.cleanupRef)}
          ${this.renderTestSupportField('review.backend.testSupport.gap', item.gap)}
        </div>
      </details>
    `;
    }
    gapCount(items) {
        return items.filter(item => item.gap !== '').length;
    }
    gapCountMark(count) {
        return count > 0
            ? html `<small class="nr-review__test-gap">${this.t('review.backend.testSupport.gapCount', { count })}</small>`
            : nothing;
    }
    renderTestSupport(groups) {
        const allItems = groups.flatMap(owner => owner.groups.flatMap(status => status.items));
        return html `
      <details class="nr-review__backend-group nr-review__test-support">
        <summary><span><strong>${this.t('review.backend.testSupport')}</strong></span><small>${this.t('review.backend.itemCount', { count: allItems.length })}</small>${this.gapCountMark(this.gapCount(allItems))}</summary>
        <div>
          ${groups.length ? groups.map(owner => {
            const ownerItems = owner.groups.flatMap(status => status.items);
            return html `
            <details class="nr-review__backend-group">
              <summary><span><strong>${this.t('review.backend.testSupport.owner')}</strong><code>${owner.owner}</code></span><small>${this.t('review.backend.itemCount', { count: ownerItems.length })}</small>${this.gapCountMark(this.gapCount(ownerItems))}</summary>
              <div>
                ${owner.groups.map(status => html `
                  <details class="nr-review__backend-group">
                    <summary><span><strong>${this.t(`review.backend.status.${backendTone(status.status)}`)}</strong><code>${status.status}</code></span><small>${this.t('review.backend.itemCount', { count: status.items.length })}</small>${this.gapCountMark(this.gapCount(status.items))}</summary>
                    <div>${status.items.map(item => this.renderTestSupportItem(item))}</div>
                  </details>
                `)}
              </div>
            </details>
          `;
        }) : html `<p class="nr-review__backend-empty">${this.t('review.backend.testSupport.empty')}</p>`}
        </div>
      </details>
    `;
    }
    renderPool() {
        return html `
      <details class="nr-review__pool">
        <summary>${this.t('review.pool')}</summary>
        <p>${this.t('review.pool.description')}</p>
        ${this.pool.map(box => html `
          <section>
            <h3>${this.t(`review.pool.box.${box.box}`)}</h3>
            ${box.messages.length ? box.messages.map(message => html `
              <article class=${message.unreadable ? 'is-unreadable' : ''}>
                <code>${message.file}</code>
                ${message.unreadable ? html `<span>${this.t('review.pool.unreadable')}</span>` : html `
                  <span>${this.t('review.pool.from')}: ${message.from}</span>
                  <span>${this.t('review.pool.round', { round: message.round, max: message.maxRound })}</span>
                  <span>${this.t('review.pool.mode')}: ${message.mode}</span>
                  <span>${this.t('review.pool.subject')}: ${message.subject}</span>
                `}
              </article>
            `) : html `<p>${this.t('review.pool.empty')}</p>`}
          </section>
        `)}
      </details>
    `;
    }
    renderEffortPanel(view, changeEffort, resultVisible, calculate) {
        const summary = parseEffortSummary(this.effortRead, this.moduleName);
        const planVisible = resultVisible && (!!this.data?.diffs.some(diff => diff.entries.length) || this.implementationComplete());
        const calculating = this.effortRefreshPending && (this.actionBusy || !!this.channelRun && !['ready', 'failed', 'disputed'].includes(this.channelRun.status));
        const hasTask = !!(this.channelRun?.executions.at(-1)?.taskId ?? this.reviewRun?.taskId);
        return html `<section class="nr-review__panel nr-review__effort-panel">
      <h3>${this.t('review.panels.effort')}</h3>
      ${!this.hasRelease ? html `<p class="nr-review__panel-note">${this.t('review.panels.fullGenerationBody')}</p>` : nothing}
      ${calculate.map(block => this.renderPrimaryAction(block))}
      ${this.changesContent === nothing ? html `<details class="nr-review__text-detail"><summary>${this.t('tobe.diffTitle', { count: 0 })}</summary>
        <p>${this.t('review.release.unchanged')}</p></details>` : this.changesContent}
      <details class="nr-review__text-detail"><summary>${this.t('review.panels.plannedChanges')}
        ${planVisible && summary.kind === 'counts' ? html `<span>${summary.counts.filter(item => item.category !== 'endpoints').map(item => `${this.t(`review.backend.count.${item.category}`)}: ${item.statuses.reduce((count, value) => count + value.count, 0)}`).join(' · ')}</span>` : nothing}
      </summary>
        ${this.renderDetailCopy('planned', { effort: this.effortRead.value, changeEffort: this.changeEffortRead.value, backend: this.backendRead.value })}
        ${planVisible ? html `${this.renderEffort(changeEffort)}${this.renderChangeEffort(changeEffort)}${this.renderBackend(view)}`
            : html `<p>${this.t('review.panels.notCalculated')}</p>`}
      </details>
      ${hasTask ? this.renderReviewTask() : calculating ? html `<div class="nr-review__task-loading" role="status">${this.t('review.panels.starting')}</div>` : nothing}
    </section>`;
    }
    renderPublish() {
        const pending = this.confirmedRounds.length > 0;
        return html `<section class="nr-review__panel nr-review__publish" aria-label=${this.t('review.panels.publish')}>
      <h3>${this.t('review.panels.publish')}</h3>
      <section class="nr-review__primary-action is-top"><div><p role="status">${this.t(pending ? 'review.panels.publishPending' : 'review.panels.inDevelopment')}</p>
        ${this.publishFeedback ? html `<small>${this.publishFeedback}</small>` : nothing}</div>
        <button type="button" ?disabled=${!pending} aria-disabled=${pending ? 'false' : 'true'}
          @click=${() => { this.publishFeedback = this.t('review.panels.publishUnavailable'); }}>${this.t('review.panels.publishAction')}</button>
      </section>
    </section>`;
    }
    renderSnapshotReview() {
        const snapshot = this.data?.confirmedRound;
        if (!snapshot)
            return nothing;
        const round = this.confirmedRounds.find(item => item.record.changeId === snapshot.changeId
            && item.record.revisionId === snapshot.revisionId);
        const effort = buildChangeEffortView(this.changeEffortRead);
        const date = new Date(snapshot.confirmedAt).toLocaleString(document.documentElement.lang || 'pt-BR');
        return html `<section class="nr-review nr-review--snapshot">
      <header class="nr-review__hero"><div><span>${this.t('review.snapshot.title')}</span><h2>${date}</h2>
        <p>${this.t('review.snapshot.readOnly')}</p></div></header>
      ${this.loading || !this.isCurrentLoad() ? html `<p class="nr-review__loading">${this.t('state.loading')}</p>` : nothing}
      <section class="nr-review__panel nr-review__effort-panel">
        <h3>${this.t('review.panels.effort')}</h3>
        ${this.changesContent === nothing ? html `<details class="nr-review__text-detail"><summary>${this.t('tobe.diffTitle', { count: 0 })}</summary>
          <p>${this.t('review.release.unchanged')}</p></details>` : this.changesContent}
        <details class="nr-review__text-detail"><summary>${this.t('review.panels.plannedChanges')}</summary>
          ${this.renderDetailCopy('snapshot-effort', { effort: this.effortRead.value, changeEffort: this.changeEffortRead.value })}
          ${this.effortRead.status === 'ok' || this.changeEffortRead.status === 'ok'
            ? html `${this.renderEffort(effort)}${this.renderChangeEffort(effort)}`
            : html `<p>${this.t('review.snapshot.effortMissing')}</p>`}
        </details>
      </section>
      <section class="nr-review__panel nr-review__apply">
        <h3>${this.t('review.panels.apply')}</h3>
        ${round ? html `<details class="nr-review__text-detail"><summary>${this.t('review.implementation.details')}</summary>
          ${this.renderDetailCopy('snapshot-implementation', { plan: round.record.merged, phases: round.record.phases })}
          ${['create', 'regenerateDefs', 'materialize', 'remove'].map(operation => html `<section>
            <h4>${this.t(`review.effort.operation.${operation}`)}</h4>
            ${round.record.merged[operation].length ? html `<ul>${round.record.merged[operation].map(unit => html `<li>${unit.kind}: ${unit.id} <code>${unit.path}</code></li>`)}</ul>`
            : html `<p>${this.t('review.effort.none')}</p>`}
          </section>`)}
          ${round.record.phases.map(phase => phase.report ? html `<details><summary>${phase.agent}</summary><pre>${this.implementationReport(phase.report)}</pre></details>` : nothing)}
        </details>
        <div class="nr-review__task-grid">${implementationCommands(round.record, this.project, this.moduleName).map((command, index) => {
            const phase = round.record.phases.find(item => item.name === `runAgents:${index}`);
            return html `<div class="nr-review__task-slot"><span>${command.agent}</span>${phase ? this.renderConfirmedTask(phase) : nothing}</div>`;
        })}</div>` : html `<p class="nr-review__panel-note">${this.t('review.snapshot.missingRound')}</p>`}
      </section>
    </section>`;
    }
    render() {
        if (this.data?.confirmedRound)
            return this.renderSnapshotReview();
        const view = this.view();
        const current = this.isCurrentLoad();
        const changeEffort = buildChangeEffortView(this.changeEffortRead);
        const action = this.actionPresentation(view, current);
        const resultVisible = !this.effortRefreshPending && ((!this.hasRelease && !!this.initialPlan && !this.loading && current) || reviewResultVisible({ version: this.version, loading: this.loading, current, resultCurrent: this.data?.resultCurrent === true }));
        const initialPending = !!this.implementation?.initial && this.hasImplementation() && !this.implementationComplete();
        const lifecycle = initialPending ? 'new' : reviewReleaseState({ hasRelease: this.hasRelease,
            changed: !!this.data?.diffs.some(diff => diff.entries.length),
            effortCurrent: this.data?.resultCurrent === true && changeEffort.kind === 'ready' && this.effortCurrent,
            implementationComplete: this.implementationComplete(),
        });
        const retryRun = this.channelRun?.status === 'failed' || this.channelRun?.status === 'disputed';
        const calculate = [{ placement: 'top', announceError: action.kind === 'calculate' || action.kind === 'retry',
                action: { ...action, labelKey: retryRun ? 'review.retry' : 'review.calculate',
                    disabled: action.disabled || !this.hasRelease || !['calculate', 'retry'].includes(action.kind),
                    descriptionKey: !this.hasRelease ? 'review.panels.generationPending'
                        : this.loading || !current ? 'review.actionLoading'
                            : action.kind === 'calculate' || action.kind === 'retry' || action.descriptionKey === 'review.actionRetryExhausted'
                                ? action.descriptionKey : 'review.actionLater',
                    availabilityKey: !this.loading && current && (action.kind === 'calculate' || action.kind === 'retry') ? action.availabilityKey : '',
                    error: action.kind === 'calculate' || action.kind === 'retry' ? action.error : '' } }];
        const apply = [{ placement: 'top', announceError: action.kind === 'continue',
                action: { ...action, labelKey: 'review.panels.applyAction', disabled: action.disabled || action.kind !== 'continue',
                    descriptionKey: this.loading || !current ? 'review.actionLoading'
                        : action.kind === 'continue' ? action.descriptionKey
                            : !this.hasRelease ? 'review.panels.generationPending' : 'review.actionUnavailableBody',
                    availabilityKey: !this.loading && current && action.kind === 'continue' ? action.availabilityKey : '',
                    error: action.kind === 'continue' ? action.error : '' } }];
        return html `<section class="nr-review">
      ${lifecycle !== 'calculate' || this.supersededRevisionId ? html `<header class="nr-review__hero">
        ${lifecycle !== 'calculate' ? html `<h2>${this.t(`review.release.${lifecycle}`)}</h2>` : nothing}
        ${this.supersededRevisionId ? html `<p role="status">${this.t('review.run.replacedPrevious', { revisionId: this.supersededRevisionId.slice(-8) })}</p>` : nothing}
      </header>` : nothing}
      ${this.loading || !current ? html `<p class="nr-review__loading">${this.t('state.loading')}</p>` : nothing}
        ${this.renderEffortPanel(view, changeEffort, resultVisible, calculate)}
        <section class="nr-review__panel nr-review__apply" aria-label=${this.t('review.panels.apply')}>
          <h3>${this.t('review.panels.apply')}</h3>
          ${apply.map(block => this.renderPrimaryAction(block, true))}
          ${this.implementationUndoFeedback ? html `<p class="nr-review__undo-feedback" role="status">${this.implementationUndoFeedback}</p>` : nothing}
          ${this.hasImplementation() ? this.renderImplementation('top') : this.renderPlannedImplementation(changeEffort)}
        </section>
        <section class="nr-review__panel nr-review__confirm" aria-label=${this.t('review.panels.confirm')}>
          <h3>${this.t('review.panels.confirm')}</h3>
          <section class="nr-review__primary-action is-top"><div><p>${this.t('review.panels.confirmBody')}</p></div>
            <button type="button" ?disabled=${!this.implementationComplete() || this.implementationRestored || this.confirmationBusy || !this.applicationCheckpoint}
              @click=${() => void this.finalizeImplementation(this.loadToken)}>${this.t('review.panels.confirmAction')}</button>
          </section>
        </section>
        ${this.renderPublish()}
      ${this.renderConfirmedRounds()}
      ${this.renderReviewRun()}
      ${resultVisible && !this.version.startsWith('release:') ? this.renderPool() : nothing}
    </section>`;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseReview102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseReview102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseReview102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseReview102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseReview102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseReview102035.prototype, "request", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseReview102035.prototype, "changesContent", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseReview102035.prototype, "identityError", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "menuRead", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "pool", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "backendRead", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "effortRead", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "changeEffortRead", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "loading", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "hasRelease", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "effortCurrent", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "effortRefreshPending", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "initialPlan", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "selectedActor", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "selectedId", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "selectedScope", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "expandedKeys", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "actionBusy", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "actionError", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "supersededRevisionId", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "initialErrorDetail", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "reviewRun", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "reviewRunLoadError", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "channelRun", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "reviewTask", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "reviewTaskSettled", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "reviewCopyFeedback", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationBusy", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementation", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationTasks", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationTaskSettled", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationPolling", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationCheckBusy", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationCheckFeedback", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationCopyFeedback", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "detailCopyKey", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "detailCopyFeedback", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationHashes", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "confirmedRounds", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "confirmedTasks", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "confirmationBusy", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "publishFeedback", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationDiff", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationDiffError", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationRestored", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "applicationCheckpoint", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationCancelBusy", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "implementationUndoFeedback", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "discardBusy", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "discardError", void 0);
NewReleaseReview102035 = __decorate([
    customElement('new-release--widgets--review-102035')
], NewReleaseReview102035);
export { NewReleaseReview102035 };
