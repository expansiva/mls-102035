/// <mls fileReference="_102035_/l2/newRelease/widgets/review/reviewModel.ts" enhancement="_blank" />
import { implementationCommands } from '/_102035_/l2/solution/candidate/moduleImplementation.js';
import { listPoolBoxForProject } from '/_102035_/l2/solution/pool.js';
import { validateChangeEffort } from '/_102035_/l2/solution/gates/changeEffort/gate.js';
import { MENU_ACTIONS, MENU_ORGANISM_KINDS, MENU_SCHEMA_VERSION, } from '/_102035_/l2/solution/poolPlan.js';
export const REVIEW_ALL_ACTORS = 'all';
/** Agent completion only; this view makes no publication or materialization claim. */
export function implementationProgress(record, currentChangeId, project = 0, moduleName = '') {
    const current = currentChangeId && record?.changeId === currentChangeId ? record : null;
    const phases = current?.phases ?? [];
    return (current ? implementationCommands(current, project, moduleName) : []).map((_, index) => {
        const name = `runAgents:${index}`;
        const phase = phases.find(item => item.name === name);
        if (!phase)
            return { name, status: 'aguardando', podeTentarDeNovo: false };
        return {
            name,
            status: phase.status === 'running' ? 'executando' : phase.status === 'done' ? 'concluido' : 'falhou',
            attempt: phase.attempt,
            ...(phase.status === 'done' ? { changedDefs: phase.changedDefs } : {}),
            ...(phase.status === 'failed' ? { error: phase.error, previousAttempts: phase.previousAttempts } : {}),
            podeTentarDeNovo: phase.status === 'failed' && phase.attempt < 2 && phase.error !== 'review.implementation.error.missingCommand',
        };
    });
}
/** Presentation gate; acceptance repeats the active revision CAS under the module writer. */
export function canAcceptImplementation(input) {
    const { data, implementation, hashes } = input;
    if (!input.project || !input.moduleName || input.runStatus !== 'ready'
        || !data?.resultCurrent || !data.changeId || !data.revisionId)
        return false;
    const path = `l4/${input.moduleName}/pipeline/changes/${data.changeId}/revisions/${data.revisionId}/l4/pool/l4/changeEffort.json`;
    if (input.changeEffort.status !== 'ok' || input.changeEffort.path !== path || !hashes.changeEffort)
        return false;
    const checked = validateChangeEffort(input.changeEffort.value);
    if (!checked.ok || checked.file.module !== input.moduleName || checked.file.status === 'blocked')
        return false;
    if (implementation && (implementation.changeId !== data.changeId
        || implementation.revisionId !== data.revisionId
        || implementation.hashes.changeEffort !== hashes.changeEffort))
        return false;
    return ['l4', 'l2', 'l1'].every(box => listPoolBoxForProject(input.project, input.moduleName, box).length === 0);
}
function sortedEntries(record) {
    return Object.entries(record).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0);
}
/** Full fence between the snapshot rendered by preflight and the authoritative click reread. */
export function sameReviewStartSnapshot(loaded, fresh) {
    if (!loaded || !fresh)
        return false;
    const left = loaded.manifest;
    const right = fresh.manifest;
    if (loaded.request !== fresh.request
        || left.project !== right.project || left.moduleName !== right.moduleName
        || left.changeId !== right.changeId || left.revisionId !== right.revisionId
        || left.baseId !== right.baseId || left.requestRevision !== right.requestRevision
        || left.requestHash !== right.requestHash
        || JSON.stringify(sortedEntries(left.files)) !== JSON.stringify(sortedEntries(right.files)))
        return false;
    const normalize = (sources) => [...sources]
        .sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0)
        .map(item => [item.path, item.source]);
    return JSON.stringify(normalize(loaded.sources)) === JSON.stringify(normalize(fresh.sources));
}
/** Synchronous presentation gate; the click repeats the authoritative sealed read before start. */
export function canStartReviewRun(input) {
    const sealed = input.sealedRevision;
    const manifest = sealed?.manifest;
    return !input.hasRun
        && !!input.userId
        && !!input.request.trim()
        && input.request === input.request.trim()
        && sealed?.request === input.request
        && !!sealed.sources.length
        && manifest?.project === input.project
        && manifest.moduleName === input.moduleName
        && manifest.changeId === input.changeId
        && manifest.revisionId === input.revisionId
        && /^[A-Za-z0-9][A-Za-z0-9-]{0,127}$/u.test(manifest.baseId)
        && Number.isSafeInteger(manifest.requestRevision) && manifest.requestRevision > 0
        && /^sha256:[a-f0-9]{64}$/u.test(manifest.requestHash || '');
}
export function buildReviewActionPresentation(input) {
    let kind = 'unavailable';
    if (!input.loading && input.current && input.version === 'tobe') {
        if (input.retry && input.retryAvailable)
            kind = 'retry';
        else if (!input.retry && input.viewKind === 'pending')
            kind = 'calculate';
        else if (input.viewKind === 'ready' && input.resultCurrent
            && input.backendKind === 'ready' && input.effortKind !== 'invalid')
            kind = 'continue';
    }
    const labelKey = input.busy
        ? 'review.actionBusy'
        : kind === 'retry' ? 'review.retry'
            : kind === 'calculate' ? 'review.calculate'
                : kind === 'continue' ? 'review.continue'
                    : 'review.actionUnavailable';
    const expectsCurrentResult = input.viewKind === 'ready' && input.resultCurrent;
    const descriptionKey = input.loading || !input.current
        ? 'review.actionLoading'
        : input.retry && !input.retryAvailable ? 'review.actionRetryExhausted'
            : kind === 'retry' ? 'review.actionRetryBody'
                : kind === 'calculate' ? 'review.actionCalculateBody'
                    : kind === 'continue' ? 'review.actionContinueBody'
                        : expectsCurrentResult && input.backendKind === 'missing' ? 'review.actionBackendMissing'
                            : expectsCurrentResult && input.backendKind === 'invalid' ? 'review.actionBackendInvalid'
                                : expectsCurrentResult && input.backendKind === 'stale' ? 'review.actionBackendStale'
                                    : expectsCurrentResult && input.effortKind === 'invalid' ? 'review.actionEffortInvalid'
                                        : 'review.actionUnavailableBody';
    return {
        kind,
        labelKey,
        descriptionKey,
        availabilityKey: input.busy ? 'review.actionBusy' : input.connected ? '' : 'review.actionReadinessBlocked',
        disabled: input.busy || !input.connected || kind === 'unavailable',
        busy: input.busy,
        error: input.error,
    };
}
export function reviewResultVisible(input) {
    return !input.loading && input.current && (input.version !== 'tobe' || input.resultCurrent);
}
export function buildReviewActionPlacements(action, version = 'tobe') {
    return version === 'tobe' ? [{ placement: 'top', action, announceError: true }] : [];
}
export function beginReviewPrimaryAction(action) {
    return action.disabled || action.busy ? { accepted: false, busy: action.busy } : { accepted: true, busy: true };
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function asNonEmpty(value) {
    return typeof value === 'string' && value.trim() ? value : null;
}
function parseAction(value) {
    return typeof value === 'string' && MENU_ACTIONS.includes(value) ? value : null;
}
function parseOrganism(value) {
    if (!isRecord(value))
        return null;
    const kind = value.kind;
    const text = asNonEmpty(value.text);
    if (typeof kind !== 'string' || !MENU_ORGANISM_KINDS.includes(kind) || !text)
        return null;
    return { kind: kind, text };
}
function parseNode(value) {
    if (!isRecord(value))
        return null;
    const id = asNonEmpty(value.id);
    const label = asNonEmpty(value.label);
    const action = parseAction(value.action);
    if (!id || !label || !action)
        return null;
    if (value.kind === 'page') {
        if (!Array.isArray(value.organisms))
            return null;
        const organisms = [];
        for (const item of value.organisms) {
            const organism = parseOrganism(item);
            if (!organism)
                return null;
            organisms.push(organism);
        }
        return { id, kind: 'page', label, action, organisms };
    }
    if (value.kind !== 'hub' && value.kind !== 'group')
        return null;
    if (!Array.isArray(value.children))
        return null;
    const children = [];
    for (const item of value.children) {
        const child = parseNode(item);
        if (!child)
            return null;
        children.push(child);
    }
    const text = asNonEmpty(value.text);
    if (!text)
        return null;
    if (value.kind === 'hub') {
        const context = asNonEmpty(value.context);
        if (!context)
            return null;
        return { id, kind: 'hub', label, action, context, text, children };
    }
    return { id, kind: 'group', label, action, text, children };
}
function parseAuthorities(value) {
    if (!isRecord(value))
        return null;
    const authorities = {};
    for (const [key, ids] of Object.entries(value)) {
        if (!key || !Array.isArray(ids) || ids.some(id => typeof id !== 'string' || !id))
            return null;
        authorities[key] = ids;
    }
    return authorities;
}
function parseForest(value) {
    if (!Array.isArray(value))
        return null;
    const nodes = [];
    for (const item of value) {
        const node = parseNode(item);
        if (!node)
            return null;
        nodes.push(node);
    }
    return nodes;
}
export function parseReviewMenu(raw) {
    var _a;
    if (!isRecord(raw))
        return { ok: false, errorCode: 'review.error.invalid' };
    if (raw.source === 'config') {
        const moduleName = asNonEmpty(raw.moduleName);
        if (!moduleName || !Array.isArray(raw.navigation))
            return { ok: false, errorCode: 'review.error.invalid' };
        const tree = [];
        const authorities = {};
        const configPages = Object.create(null);
        for (const page of raw.navigation) {
            if (!isRecord(page) || !asNonEmpty(page.id) || !asNonEmpty(page.label) || !asNonEmpty(page.href)
                || typeof page.description !== 'string' || !Array.isArray(page.actors)
                || page.actors.some(actor => !asNonEmpty(actor))
                || (page.landing !== undefined && typeof page.landing !== 'boolean')
                || Object.hasOwn(configPages, page.id))
                return { ok: false, errorCode: 'review.error.invalid' };
            const entry = {
                id: page.id, label: page.label, href: page.href,
                description: page.description, actors: page.actors,
                ...(page.landing === undefined ? {} : { landing: page.landing }),
            };
            tree.push({ id: entry.id, kind: 'page', label: entry.label, action: 'keep', organisms: [] });
            configPages[entry.id] = entry;
            for (const actor of entry.actors)
                (authorities[_a = `actor:${actor}`] ?? (authorities[_a] = [])).push(entry.id);
        }
        return { ok: true, menu: { schemaVersion: MENU_SCHEMA_VERSION, moduleName,
                device: 'web', tree, authorities, removed: [], configPages } };
    }
    if (raw.schemaVersion !== MENU_SCHEMA_VERSION)
        return { ok: false, errorCode: 'review.error.schema' };
    const moduleName = asNonEmpty(raw.moduleName);
    const device = asNonEmpty(raw.device);
    const tree = parseForest(raw.tree);
    const authorities = parseAuthorities(raw.authorities);
    if (!moduleName || !device || !tree || !authorities || !isRecord(raw.meta)) {
        return { ok: false, errorCode: 'review.error.invalid' };
    }
    const removed = raw.meta.removed === undefined ? [] : parseForest(raw.meta.removed);
    if (!removed)
        return { ok: false, errorCode: 'review.error.invalid' };
    return { ok: true, menu: { schemaVersion: MENU_SCHEMA_VERSION, moduleName, device, tree, authorities, removed, configPages: {} } };
}
export function actorIdFromKey(key) {
    return key.startsWith('actor:') ? key.slice('actor:'.length) : key;
}
export function resolveSelectedActor(actors, selected) {
    if (selected === REVIEW_ALL_ACTORS)
        return REVIEW_ALL_ACTORS;
    if (actors.some(actor => actor.key === selected))
        return selected;
    return actors[0]?.key || REVIEW_ALL_ACTORS;
}
function toTree(nodes) {
    return nodes.map(node => ({
        id: node.id,
        kind: node.kind,
        label: node.label,
        action: node.action,
        children: node.kind === 'page' ? [] : toTree(node.children),
    }));
}
function walk(nodes, visit, ancestors = []) {
    for (const node of nodes) {
        visit(node, ancestors);
        if (node.kind !== 'page')
            walk(node.children, visit, [...ancestors, node]);
    }
}
function addDescendants(node, visible) {
    if (node.kind === 'page')
        return;
    for (const child of node.children) {
        visible.add(child.id);
        addDescendants(child, visible);
    }
}
function filterVisible(nodes, visible) {
    const out = [];
    for (const node of nodes) {
        if (!visible.has(node.id)) {
            if (node.kind !== 'page')
                out.push(...filterVisible(node.children, visible));
            continue;
        }
        if (node.kind === 'page') {
            out.push(node);
            continue;
        }
        out.push({ ...node, children: filterVisible(node.children, visible) });
    }
    return out;
}
export function menuTreeForActor(menu, actorKey) {
    if (actorKey === REVIEW_ALL_ACTORS)
        return menu.tree;
    const explicit = menu.authorities[actorKey] || [];
    const visible = new Set(explicit);
    walk(menu.tree, node => {
        if (visible.has(node.id))
            addDescendants(node, visible);
    });
    const filtered = filterVisible(menu.tree, visible);
    const order = new Map(explicit.map((id, index) => [id, index]));
    return [...filtered].sort((left, right) => (order.get(left.id) ?? Number.POSITIVE_INFINITY) - (order.get(right.id) ?? Number.POSITIVE_INFINITY));
}
function indexNodes(nodes) {
    const found = new Map();
    walk(nodes, node => {
        if (!found.has(node.id))
            found.set(node.id, node);
    });
    return found;
}
function containsId(nodes, id) {
    return nodes.some(node => node.id === id || containsId(node.children, id));
}
export function toggleReviewSelection(selectedId, selectedScope, id, scope) {
    return selectedId === id && selectedScope === scope
        ? { selectedId: '', selectedScope: scope }
        : { selectedId: id, selectedScope: scope };
}
export function reviewExpansionKey(scope, id) {
    return `${scope}:${id}`;
}
function ancestorIds(nodes, id) {
    const found = [];
    const walk = (list, trail) => {
        for (const node of list) {
            if (node.id === id) {
                found.push(...trail);
                return true;
            }
            if (node.children.length && walk(node.children, [...trail, node.id]))
                return true;
        }
        return false;
    };
    walk(nodes, []);
    return found;
}
export function openReviewExpansionKeys(expandedKeys, view) {
    const keys = new Set(expandedKeys);
    const forest = view.selectedScope === 'removed' ? view.removed : view.tree;
    for (const id of ancestorIds(forest, view.selectedId))
        keys.add(reviewExpansionKey(view.selectedScope, id));
    return keys;
}
export function toggleReviewExpansion(expandedKeys, view, id, scope) {
    const key = reviewExpansionKey(scope, id);
    const wasOpen = openReviewExpansionKeys(expandedKeys, view).has(key);
    const forest = scope === 'removed' ? view.removed : view.tree;
    const closesSelectedAncestor = wasOpen && view.selectedScope === scope && ancestorIds(forest, view.selectedId).includes(id);
    return {
        expandedKeys: wasOpen ? expandedKeys.filter(item => item !== key) : [...expandedKeys, key],
        selectedId: closesSelectedAncestor ? '' : view.selectedId,
    };
}
function detailOf(node, scope, configPage) {
    return {
        id: node.id,
        kind: node.kind,
        label: node.label,
        action: node.action,
        scope,
        text: node.kind === 'page' ? '' : node.text,
        context: node.kind === 'hub' ? node.context : '',
        organisms: node.kind === 'page' ? node.organisms : [],
        href: configPage?.href ?? '',
        description: configPage?.description ?? '',
        actors: configPage?.actors ?? [],
        landing: configPage?.landing === true,
    };
}
const EMPTY_VIEW = {
    actors: [],
    selectedActor: REVIEW_ALL_ACTORS,
    selectedId: '',
    selectedScope: 'future',
    tree: [],
    removed: [],
    selected: null,
};
export function buildReviewView(input) {
    if (input.pendingCount > 0) {
        return {
            ...EMPTY_VIEW,
            kind: 'pending',
            errorCode: '',
            showContinue: false,
            showCalculate: true,
        };
    }
    if (input.readStatus === 'missing') {
        return {
            ...EMPTY_VIEW,
            kind: 'empty',
            errorCode: 'review.emptyBody',
            showContinue: false,
            showCalculate: false,
        };
    }
    if (input.readStatus === 'configMissing' || input.readStatus === 'moduleMissing') {
        return {
            ...EMPTY_VIEW,
            kind: 'invalid',
            errorCode: input.readStatus === 'configMissing' ? 'review.error.configMissing' : 'review.error.moduleMissing',
            showContinue: false,
            showCalculate: false,
        };
    }
    if (input.readStatus === 'invalid') {
        return {
            ...EMPTY_VIEW,
            kind: 'invalid',
            errorCode: 'review.error.invalid',
            showContinue: false,
            showCalculate: false,
        };
    }
    const parsed = parseReviewMenu(input.raw);
    if (!parsed.ok) {
        return {
            ...EMPTY_VIEW,
            kind: 'invalid',
            errorCode: parsed.errorCode,
            showContinue: false,
            showCalculate: false,
        };
    }
    const actors = Object.keys(parsed.menu.authorities).map(key => ({ key, actorId: actorIdFromKey(key) }));
    const selectedActor = resolveSelectedActor(actors, input.selectedActor);
    const future = menuTreeForActor(parsed.menu, selectedActor);
    const tree = toTree(future);
    const removed = selectedActor === REVIEW_ALL_ACTORS ? toTree(parsed.menu.removed) : [];
    const futureIndex = indexNodes(future);
    const removedIndex = selectedActor === REVIEW_ALL_ACTORS ? indexNodes(parsed.menu.removed) : new Map();
    let selectedScope = input.selectedScope;
    let selectedId = input.selectedId;
    if (selectedScope === 'removed' && !containsId(removed, selectedId)) {
        selectedScope = 'future';
        selectedId = '';
    }
    if (selectedScope === 'future' && !containsId(tree, selectedId))
        selectedId = '';
    const selectedNode = selectedScope === 'removed' ? removedIndex.get(selectedId) : futureIndex.get(selectedId);
    return {
        kind: 'ready',
        errorCode: '',
        actors,
        selectedActor,
        selectedId,
        selectedScope,
        tree,
        removed,
        selected: selectedNode ? detailOf(selectedNode, selectedScope, parsed.menu.configPages[selectedNode.id]) : null,
        showContinue: true,
        showCalculate: false,
    };
}
export function reviewReleaseState(input) {
    if (input.implementationComplete)
        return 'unchanged';
    if (!input.hasRelease)
        return 'new';
    if (!input.changed)
        return 'unchanged';
    return input.effortCurrent ? 'apply' : 'calculate';
}
/** L2 product sources prove first generation; L1 alone and a captured base do not. */
export function moduleHasGeneratedSources(project, moduleName, files) {
    return files.some(file => file.project === project && file.level === 2
        && file.status !== 'deleted' && (file.folder === moduleName || file.folder.startsWith(`${moduleName}/`))
        && !file.folder.startsWith(`${moduleName}/pipeline`) && file.extension === '.ts'
        && !file.shortName.endsWith('.test') && !file.shortName.endsWith('.defs'));
}
/** A clean, newly captured editing base can still show the previous completion report. */
export function reviewImplementationVisible(record, data) {
    if (!record)
        return false;
    if (record.changeId === data?.changeId && record.revisionId === data?.revisionId)
        return true;
    return !data?.resultCurrent && !data?.diffs.some(diff => diff.entries.length);
}
