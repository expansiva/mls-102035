/// <mls fileReference="_102035_/l2/newRelease/widgets/integration/integration.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { hasItemDiff, hasPluginDiff, idScope } from '/_102035_/l2/newRelease/helpers/itemDiffs.js';
import { changedDot } from '/_102035_/l2/newRelease/helpers/changedDot.js';
import { readIntegrationWorkspace, } from '/_102035_/l2/newRelease/integrationRequests.js';
import { announceNewReleaseChange, canDiscardNewReleaseDraft, requestNewReleasePresentation, requestNewReleaseEdit, } from '/_102035_/l2/newRelease/editContract.js';
import { ns5OntologyEntityView } from '/_102035_/l2/solution/ontologyView.js';
import { INTEGRATION_ITEM_LABELS, integrationOracleIssues, normalizeIntegration, patchIntegrationItem, } from '/_102035_/l2/newRelease/widgets/integration/integrationModel.js';
// Keep the Studio widget independent from the generator/runtime graph: solution/types.js
// re-exports level-1 values that are intentionally unavailable in the browser.
const INTEGRATION_KINDS = ['event', 'moduleEndpoint', 'external'];
const INTEGRATION_EFFECTS = ['create', 'update', 'transition'];
let NewReleaseIntegration102035 = class NewReleaseIntegration102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--integration-102035 {
  color-scheme: dark;
  --page-bg: #0d1117;
  --surface-bg: #161b22;
  --surface-alt-bg: #1c2330;
  --text-strong: #f0f4fc;
  --text-default: #d0d8e8;
  --text-muted: #92a0b8;
  --border-subtle: #303b50;
  --border-default: #46546d;
  --link-text: #8fb9ff;
  --selected-bg: #223854;
  --selected-text: #bdd6ff;
  --selected-border: #6198e8;
  --focus-ring: #83b4ff;
  background: var(--page-bg);
  color: var(--text-default);
  font-family: var(--font-family, system-ui, sans-serif);
  line-height: 1.5;
  overflow-wrap: anywhere;
  display: block;
}
new-release--widgets--integration-102035 button,
new-release--widgets--integration-102035 input,
new-release--widgets--integration-102035 select,
new-release--widgets--integration-102035 textarea {
  font: inherit;
}
new-release--widgets--integration-102035 button:focus-visible,
new-release--widgets--integration-102035 summary:focus-visible {
  outline: 2px solid var(--focus-ring);
  outline-offset: 3px;
}
new-release--widgets--integration-102035 * {
  box-sizing: border-box;
}
new-release--widgets--integration-102035 h2,
new-release--widgets--integration-102035 h4,
new-release--widgets--integration-102035 p,
new-release--widgets--integration-102035 dl,
new-release--widgets--integration-102035 dd {
  margin: 0;
}
new-release--widgets--integration-102035 button,
new-release--widgets--integration-102035 input,
new-release--widgets--integration-102035 select,
new-release--widgets--integration-102035 textarea {
  font: inherit;
}
new-release--widgets--integration-102035 button {
  cursor: pointer;
}
new-release--widgets--integration-102035 code {
  font-family: var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--integration-102035 input,
new-release--widgets--integration-102035 select,
new-release--widgets--integration-102035 textarea {
  width: 100%;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--integration-102035 input,
new-release--widgets--integration-102035 select {
  min-height: 2.25rem;
  padding: 0.42rem 0.58rem;
}
new-release--widgets--integration-102035 textarea {
  min-height: 4.6rem;
  padding: 0.55rem 0.62rem;
  resize: vertical;
  line-height: 1.45;
}
new-release--widgets--integration-102035 select[multiple] {
  min-height: 6rem;
}
new-release--widgets--integration-102035 input:focus,
new-release--widgets--integration-102035 select:focus,
new-release--widgets--integration-102035 textarea:focus,
new-release--widgets--integration-102035 button:focus-visible,
new-release--widgets--integration-102035 summary:focus-visible {
  border-color: var(--focus-border, #1273d4);
  outline: 2px solid color-mix(in srgb, var(--focus-border, #1273d4) 22%, transparent);
  outline-offset: 1px;
}
new-release--widgets--integration-102035 .nr-integration {
  display: grid;
  min-width: 0;
  color: var(--text-default, #2f3a48);
}
new-release--widgets--integration-102035 .nr-integration__hero {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.2rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: radial-gradient(circle at 82% -45%, color-mix(in srgb, var(--chart-series-5, #168aad) 22%, transparent), transparent 42%), linear-gradient(135deg, var(--surface-bg, #fff), color-mix(in srgb, var(--selected-bg, #e3f1ff) 40%, var(--surface-bg, #fff)));
}
new-release--widgets--integration-102035 .nr-integration__hero > div {
  min-width: 16rem;
  flex: 1 1 22rem;
}
new-release--widgets--integration-102035 .nr-integration__hero > div > span,
new-release--widgets--integration-102035 .nr-integration__lane > header span,
new-release--widgets--integration-102035 .nr-integration__plugins > header span,
new-release--widgets--integration-102035 .nr-integration__requests > header span,
new-release--widgets--integration-102035 .nr-integration__item > header span,
new-release--widgets--integration-102035 .nr-integration__plugin > header span {
  color: var(--link-text, #0f62b8);
  font-size: 0.62rem;
  font-weight: 800;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
new-release--widgets--integration-102035 .nr-integration__hero h2 {
  margin-top: 0.28rem;
  color: var(--text-strong, #111827);
  font-size: 1.5rem;
  letter-spacing: -0.03em;
}
new-release--widgets--integration-102035 .nr-integration__hero p {
  max-width: 48rem;
  margin-top: 0.42rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--integration-102035 .nr-integration__hero small {
  display: inline-flex;
  margin-top: 0.55rem;
  padding: 0.22rem 0.42rem;
  border-radius: 999px;
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
  font-size: 0.56rem;
  font-weight: 750;
}
new-release--widgets--integration-102035 .nr-integration__hero small.schema-v1 {
  background: var(--status-warning-bg, #fff1c2);
  color: var(--status-warning-text, #7a4b00);
}
new-release--widgets--integration-102035 .nr-integration__hero dl {
  display: flex;
  max-width: 100%;
  flex: 0 1 auto;
  overflow: hidden;
  border: 1px solid color-mix(in srgb, var(--chart-series-5, #168aad) 26%, var(--border-subtle, #e4e9f0));
  border-radius: 0.82rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--integration-102035 .nr-integration__hero dl div {
  display: grid;
  min-width: 5rem;
  place-items: center;
  padding: 0.55rem 0.75rem;
}
new-release--widgets--integration-102035 .nr-integration__hero dl div + div {
  border-left: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--integration-102035 .nr-integration__hero dt {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.54rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--integration-102035 .nr-integration__hero dd {
  order: -1;
  color: var(--text-strong, #111827);
  font-size: 1.2rem;
  font-weight: 800;
}
new-release--widgets--integration-102035 .nr-integration__toolbar {
  display: flex;
  min-height: 3rem;
  align-items: center;
  justify-content: flex-end;
  padding: 0.55rem 1.25rem 0;
}
new-release--widgets--integration-102035 .nr-integration__toolbar button {
  min-height: 2.1rem;
  padding: 0.4rem 0.72rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.67rem;
  font-weight: 750;
}
new-release--widgets--integration-102035 .nr-integration__toolbar span {
  padding: 0.35rem 0.55rem;
  border-radius: 999px;
  background: var(--status-warning-bg, #fff1c2);
  color: var(--status-warning-text, #7a4b00);
  font-size: 0.59rem;
}
new-release--widgets--integration-102035 .nr-integration__lanes {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.85rem;
  padding: 0.7rem 1.25rem 1rem;
}
new-release--widgets--integration-102035 .nr-integration__lane,
new-release--widgets--integration-102035 .nr-integration__plugins,
new-release--widgets--integration-102035 .nr-integration__requests {
  overflow: hidden;
  min-width: 0;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.82rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--integration-102035 .nr-integration__lane {
  border-top: 0.2rem solid var(--chart-series-1, #1273d4);
}
new-release--widgets--integration-102035 .nr-integration__lane.lane-outbound {
  border-top-color: var(--chart-series-5, #168aad);
}
new-release--widgets--integration-102035 .nr-integration__lane > header,
new-release--widgets--integration-102035 .nr-integration__plugins > header,
new-release--widgets--integration-102035 .nr-integration__requests > header {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.65rem 0.72rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--integration-102035 .nr-integration__lane > header p,
new-release--widgets--integration-102035 .nr-integration__plugins > header p,
new-release--widgets--integration-102035 .nr-integration__requests > header p {
  margin-top: 0.18rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
}
new-release--widgets--integration-102035 .nr-integration__lane > header strong,
new-release--widgets--integration-102035 .nr-integration__plugins > header strong,
new-release--widgets--integration-102035 .nr-integration__requests > header strong {
  display: grid;
  min-width: 1.55rem;
  height: 1.55rem;
  place-items: center;
  border-radius: 999px;
  background: var(--surface-bg, #fff);
  color: var(--text-strong, #111827);
  font-size: 0.62rem;
}
new-release--widgets--integration-102035 .nr-integration__lane > div,
new-release--widgets--integration-102035 .nr-integration__plugins > div {
  display: grid;
  gap: 0.58rem;
  padding: 0.65rem;
}
new-release--widgets--integration-102035 .nr-integration__item,
new-release--widgets--integration-102035 .nr-integration__plugin {
  display: grid;
  gap: 0.5rem;
  padding: 0.68rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.68rem;
  background: linear-gradient(145deg, var(--surface-bg, #fff), color-mix(in srgb, var(--surface-alt-bg, #f5f7fa) 65%, var(--surface-bg, #fff)));
}
new-release--widgets--integration-102035 .nr-integration__item > header,
new-release--widgets--integration-102035 .nr-integration__plugin > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.65rem;
}
new-release--widgets--integration-102035 .nr-integration__item > header > div,
new-release--widgets--integration-102035 .nr-integration__plugin > header {
  min-width: 0;
}
new-release--widgets--integration-102035 .nr-integration__item h4,
new-release--widgets--integration-102035 .nr-integration__plugin h4 {
  margin-top: 0.18rem;
  overflow-wrap: anywhere;
  color: var(--text-strong, #111827);
  font: 750 0.72rem var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--integration-102035 .nr-integration__item > header b {
  flex: 0 0 auto;
  padding: 0.2rem 0.34rem;
  border-radius: 999px;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.51rem;
}
new-release--widgets--integration-102035 .nr-integration__item > header button,
new-release--widgets--integration-102035 .nr-integration__plugin > header button {
  width: 1.6rem;
  height: 1.6rem;
  flex: 0 0 auto;
  border: 0;
  border-radius: 0.42rem;
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--integration-102035 .nr-integration__item > p,
new-release--widgets--integration-102035 .nr-integration__plugin > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
  line-height: 1.5;
}
new-release--widgets--integration-102035 .nr-integration__item dl {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.35rem;
}
new-release--widgets--integration-102035 .nr-integration__item dl div {
  display: grid;
  gap: 0.1rem;
  padding: 0.38rem;
  border-radius: 0.46rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--integration-102035 .nr-integration__item dt,
new-release--widgets--integration-102035 .nr-integration__item > section > span,
new-release--widgets--integration-102035 .nr-integration__plugin > div > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.49rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--integration-102035 .nr-integration__item dd {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.56rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--integration-102035 .nr-integration__item > section {
  display: grid;
  gap: 0.3rem;
  padding-top: 0.42rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--integration-102035 .nr-integration__chips {
  display: flex;
  flex-wrap: wrap;
  gap: 0.28rem;
}
new-release--widgets--integration-102035 .nr-integration__chips span {
  display: grid;
  gap: 0.03rem;
  padding: 0.24rem 0.36rem;
  border-radius: 0.42rem;
  background: color-mix(in srgb, var(--chart-series-5, #168aad) 11%, var(--surface-alt-bg, #f5f7fa));
  color: var(--text-strong, #111827);
  font-size: 0.55rem;
}
new-release--widgets--integration-102035 .nr-integration__chips code {
  color: var(--link-text, #0f62b8);
  font-size: 0.47rem;
}
new-release--widgets--integration-102035 .nr-integration__item small,
new-release--widgets--integration-102035 .nr-integration__plugin small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.55rem;
}
new-release--widgets--integration-102035 .nr-integration__form,
new-release--widgets--integration-102035 .nr-integration__request-form {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.48rem;
}
new-release--widgets--integration-102035 .nr-integration__form label,
new-release--widgets--integration-102035 .nr-integration__plugin.is-edit > label,
new-release--widgets--integration-102035 .nr-integration__plugin.is-edit header label,
new-release--widgets--integration-102035 .nr-integration__request-form label {
  display: grid;
  gap: 0.24rem;
}
new-release--widgets--integration-102035 .nr-integration__form label > span,
new-release--widgets--integration-102035 .nr-integration__plugin.is-edit label > span,
new-release--widgets--integration-102035 .nr-integration__request-form label > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
  font-weight: 750;
}
new-release--widgets--integration-102035 .nr-integration__form .is-wide,
new-release--widgets--integration-102035 .nr-integration__request-form .is-wide {
  grid-column: 1 / -1;
}
new-release--widgets--integration-102035 .nr-integration__add {
  min-height: 3.5rem;
  border: 1px dashed var(--selected-border, #1273d4);
  border-radius: 0.62rem;
  background: color-mix(in srgb, var(--selected-bg, #e3f1ff) 35%, transparent);
  color: var(--selected-text, #0d5296);
  font-size: 0.66rem;
  font-weight: 750;
}
new-release--widgets--integration-102035 .nr-integration__lane-empty {
  padding: 0.8rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
  text-align: center;
}
new-release--widgets--integration-102035 .nr-integration__plugins {
  margin: 0 1.25rem 1rem;
  border-top: 0.2rem solid var(--chart-series-3, #8250df);
}
new-release--widgets--integration-102035 .nr-integration__plugins > div {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
new-release--widgets--integration-102035 .nr-integration__plugin > div {
  display: flex;
  flex-wrap: wrap;
  gap: 0.28rem;
}
new-release--widgets--integration-102035 .nr-integration__plugin > div > span {
  flex: 0 0 100%;
}
new-release--widgets--integration-102035 .nr-integration__plugin > div code {
  padding: 0.2rem 0.32rem;
  border-radius: 0.36rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--link-text, #0f62b8);
  font-size: 0.5rem;
}
new-release--widgets--integration-102035 .nr-integration__plugin.is-edit header label {
  flex: 1;
}
new-release--widgets--integration-102035 .nr-integration__requests {
  margin: 0 1.25rem 1.25rem;
  border-top: 0.2rem solid var(--chart-series-4, #d17a00);
}
new-release--widgets--integration-102035 .nr-integration__request-list {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.55rem;
  padding: 0.65rem;
}
new-release--widgets--integration-102035 .nr-integration__request-list > p {
  grid-column: 1 / -1;
  padding: 0.7rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
  text-align: center;
}
new-release--widgets--integration-102035 .nr-integration__request-list article {
  display: grid;
  grid-template-columns: 0.6rem minmax(0, 1fr) auto;
  gap: 0.48rem;
  align-items: start;
  padding: 0.58rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.6rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--integration-102035 .nr-integration__request-list article > i {
  width: 0.55rem;
  height: 0.55rem;
  margin-top: 0.1rem;
  border-radius: 999px;
  background: var(--chart-series-4, #d17a00);
}
new-release--widgets--integration-102035 .nr-integration__request-list article.is-received > i {
  background: var(--chart-series-1, #1273d4);
}
new-release--widgets--integration-102035 .nr-integration__request-list article > div {
  display: grid;
  min-width: 0;
  gap: 0.1rem;
}
new-release--widgets--integration-102035 .nr-integration__request-list article span {
  color: var(--link-text, #0f62b8);
  font-size: 0.49rem;
  font-weight: 800;
  text-transform: uppercase;
}
new-release--widgets--integration-102035 .nr-integration__request-list article strong {
  color: var(--text-strong, #111827);
  font-size: 0.65rem;
}
new-release--widgets--integration-102035 .nr-integration__request-list article p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.57rem;
  line-height: 1.4;
}
new-release--widgets--integration-102035 .nr-integration__request-list article code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.48rem;
}
new-release--widgets--integration-102035 .nr-integration__request-list article b {
  padding: 0.18rem 0.3rem;
  border-radius: 999px;
  background: var(--status-warning-bg, #fff1c2);
  color: var(--status-warning-text, #7a4b00);
  font-size: 0.48rem;
}
new-release--widgets--integration-102035 .nr-integration__requests details {
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--integration-102035 .nr-integration__requests summary {
  padding: 0.62rem 0.72rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 750;
  cursor: pointer;
}
new-release--widgets--integration-102035 .nr-integration__request-form {
  padding: 0.7rem;
}
new-release--widgets--integration-102035 .nr-integration__request-form footer {
  display: flex;
  grid-column: 1 / -1;
  align-items: center;
  justify-content: space-between;
  gap: 0.6rem;
}
new-release--widgets--integration-102035 .nr-integration__request-form footer span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
}
new-release--widgets--integration-102035 .nr-integration__request-form footer button {
  min-height: 2.1rem;
  padding: 0.4rem 0.68rem;
  border: 0;
  border-radius: 0.52rem;
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
  font-size: 0.64rem;
  font-weight: 750;
}
new-release--widgets--integration-102035 .nr-integration__issues {
  margin: 0.65rem 1.25rem 0;
  display: grid;
  gap: 0.38rem;
  padding: 0.65rem 0.72rem;
  border: 1px solid color-mix(in srgb, var(--status-warning-text, #7a4b00) 28%, var(--border-subtle, #e4e9f0));
  border-radius: 0.65rem;
  background: var(--status-warning-bg, #fff1c2);
}
new-release--widgets--integration-102035 .nr-integration__integrity {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.55rem;
  margin: 0.65rem 1.25rem 0;
}
new-release--widgets--integration-102035 .nr-integration__integrity article {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  gap: 0.45rem;
  align-items: center;
  padding: 0.55rem 0.65rem;
  border: 1px solid color-mix(in srgb, var(--status-success-text, #25640e) 24%, var(--border-subtle, #e4e9f0));
  border-radius: 0.62rem;
  background: color-mix(in srgb, var(--status-success-bg, #e2f5db) 56%, var(--surface-bg, #fff));
}
new-release--widgets--integration-102035 .nr-integration__integrity article > span {
  display: grid;
  width: 1.7rem;
  height: 1.7rem;
  place-items: center;
  border-radius: 0.45rem;
  background: var(--status-success-text, #25640e);
  color: var(--status-success-bg, #e2f5db);
  font-size: 0.55rem;
  font-weight: 800;
}
new-release--widgets--integration-102035 .nr-integration__integrity article > strong {
  color: var(--text-strong, #111827);
  font-size: 0.6rem;
}
new-release--widgets--integration-102035 .nr-integration__integrity article > p,
new-release--widgets--integration-102035 .nr-integration__integrity article > small {
  color: var(--status-success-text, #25640e);
  font-size: 0.53rem;
}
new-release--widgets--integration-102035 .nr-integration__integrity article > small {
  grid-column: 2 / -1;
}
new-release--widgets--integration-102035 .nr-integration__integrity article.is-warned {
  border-color: color-mix(in srgb, var(--status-warning-text, #7a4b00) 26%, var(--border-subtle, #e4e9f0));
  background: var(--status-warning-bg, #fff1c2);
}
new-release--widgets--integration-102035 .nr-integration__integrity article.is-failed {
  border-color: color-mix(in srgb, var(--status-error-text, #ab2328) 26%, var(--border-subtle, #e4e9f0));
  background: var(--status-error-bg, #fde8e9);
}
new-release--widgets--integration-102035 .nr-integration__issues > strong,
new-release--widgets--integration-102035 .nr-integration__issues > p {
  font-size: 0.64rem;
}
new-release--widgets--integration-102035 .nr-integration__issues > div {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 0.42rem;
}
new-release--widgets--integration-102035 .nr-integration__issues code {
  font-size: 0.52rem;
  font-weight: 700;
}
new-release--widgets--integration-102035 .nr-integration__issues p {
  font-size: 0.61rem;
}
new-release--widgets--integration-102035 .nr-integration__issues .is-error {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--integration-102035 .nr-integration__empty,
new-release--widgets--integration-102035 .nr-integration__unknown {
  display: grid;
  min-height: 18rem;
  place-items: center;
  align-content: center;
  gap: 0.42rem;
  padding: 2rem 1.25rem;
  text-align: center;
}
new-release--widgets--integration-102035 .nr-integration__empty > h2,
new-release--widgets--integration-102035 .nr-integration__unknown h2 {
  color: var(--text-strong, #111827);
  font-size: 1rem;
}
new-release--widgets--integration-102035 .nr-integration__empty > p,
new-release--widgets--integration-102035 .nr-integration__unknown > p {
  max-width: 34rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--integration-102035 .nr-integration__empty .nr-integration__issues,
new-release--widgets--integration-102035 .nr-integration__empty .nr-integration__requests {
  width: 100%;
  margin: 0.6rem 0 0;
  text-align: left;
}
new-release--widgets--integration-102035 .nr-integration__unknown pre {
  width: 100%;
  max-height: 24rem;
  overflow: auto;
  padding: 0.75rem;
  border-radius: 0.65rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-default, #2f3a48);
  font-size: 0.58rem;
  text-align: left;
}
new-release--widgets--integration-102035 .nr-integration__edit-footer {
  position: sticky;
  z-index: 5;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.72rem 1.25rem;
  border-top: 1px solid var(--border-default, #cfd8e3);
  background: color-mix(in srgb, var(--surface-bg, #fff) 94%, transparent);
  box-shadow: 0 -0.5rem 1.4rem color-mix(in srgb, var(--text-strong, #111827) 8%, transparent);
  backdrop-filter: blur(10px);
}
new-release--widgets--integration-102035 .nr-integration__edit-footer > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--integration-102035 .nr-integration__edit-footer > div {
  display: flex;
  gap: 0.5rem;
}
new-release--widgets--integration-102035 .nr-integration__edit-footer button {
  min-height: 2.15rem;
  padding: 0.42rem 0.72rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--integration-102035 .nr-integration__edit-footer button.is-primary {
  border-color: var(--action-primary-bg, #126fc2);
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
}
new-release--widgets--integration-102035 .nr-integration__edit-footer button:disabled {
  cursor: not-allowed;
  opacity: 0.48;
}
@media (max-width: 1080px) {
  new-release--widgets--integration-102035 .nr-integration__lanes {
    grid-template-columns: 1fr;
  }
  new-release--widgets--integration-102035 .nr-integration__plugins > div {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 720px) {
  new-release--widgets--integration-102035 .nr-integration__hero,
  new-release--widgets--integration-102035 .nr-integration__edit-footer {
    align-items: stretch;
    flex-direction: column;
  }
  new-release--widgets--integration-102035 .nr-integration__hero dl {
    align-self: flex-start;
  }
  new-release--widgets--integration-102035 .nr-integration__plugins > div,
  new-release--widgets--integration-102035 .nr-integration__request-list,
  new-release--widgets--integration-102035 .nr-integration__form,
  new-release--widgets--integration-102035 .nr-integration__request-form {
    grid-template-columns: 1fr;
  }
  new-release--widgets--integration-102035 .nr-integration__form .is-wide,
  new-release--widgets--integration-102035 .nr-integration__request-form .is-wide,
  new-release--widgets--integration-102035 .nr-integration__request-form footer {
    grid-column: auto;
  }
  new-release--widgets--integration-102035 .nr-integration__request-form footer {
    align-items: stretch;
    flex-direction: column;
  }
  new-release--widgets--integration-102035 .nr-integration__edit-footer > div {
    justify-content: flex-end;
  }
}
new-release--widgets--integration-102035 .nr-integration__flow {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr) auto minmax(0, 1fr);
  align-items: center;
  gap: 0.6rem;
  padding: 0.8rem;
  border: 1px solid var(--border-subtle);
  border-radius: 0.6rem;
}
new-release--widgets--integration-102035 .nr-integration__flow span {
  overflow-wrap: anywhere;
}
new-release--widgets--integration-102035 .nr-integration__flow button,
new-release--widgets--integration-102035 .nr-integration__plugin > button,
new-release--widgets--integration-102035 .nr-integration__detail > header button {
  min-height: 44px;
  padding: 0.6rem;
  border: 1px solid var(--selected-border);
  border-radius: 0.5rem;
  background: var(--selected-bg);
  color: var(--selected-text);
  cursor: pointer;
  overflow-wrap: anywhere;
}
new-release--widgets--integration-102035 .nr-integration__detail {
  margin: 1rem;
  padding: 1rem;
  border: 1px solid var(--border-subtle);
  border-radius: 0.8rem;
  background: var(--surface-bg);
}
new-release--widgets--integration-102035 .nr-integration__detail > header {
  display: flex;
  justify-content: space-between;
  gap: 1rem;
  align-items: center;
}
new-release--widgets--integration-102035 .nr-integration__detail fieldset {
  min-width: 0;
  padding: 0;
  border: 0;
  margin: 1rem 0;
}
new-release--widgets--integration-102035 .nr-integration__detail dl {
  display: grid;
  gap: 0.8rem;
}
new-release--widgets--integration-102035 .nr-integration__detail dt {
  color: var(--text-muted);
}
new-release--widgets--integration-102035 .nr-integration__detail dd {
  margin: 0.25rem 0 0;
  white-space: pre-wrap;
}
new-release--widgets--integration-102035 .nr-integration__form input,
new-release--widgets--integration-102035 .nr-integration__form select,
new-release--widgets--integration-102035 .nr-integration__form textarea,
new-release--widgets--integration-102035 .nr-integration__plugin input,
new-release--widgets--integration-102035 .nr-integration__plugin select,
new-release--widgets--integration-102035 .nr-integration__plugin textarea {
  box-sizing: border-box;
  width: 100%;
  min-height: 44px;
  border: 1px solid var(--border-default);
  border-radius: 0.4rem;
  padding: 0.6rem;
  background: var(--surface-alt-bg);
  color: var(--text-default);
}
new-release--widgets--integration-102035 .nr-integration__form textarea {
  min-height: 8rem;
}
new-release--widgets--integration-102035 .nr-integration__form label > span,
new-release--widgets--integration-102035 .nr-integration__lane-empty {
  font-size: 0.8rem;
}
new-release--widgets--integration-102035 .nr-integration__item > header code {
  font-size: 0.85rem;
}
@media (max-width: 540px) {
  new-release--widgets--integration-102035 .nr-integration__flow {
    grid-template-columns: minmax(0, 1fr);
  }
  new-release--widgets--integration-102035 .nr-integration__flow > span[aria-hidden] {
    transform: rotate(90deg);
    justify-self: center;
  }
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.selected = '';
        this.saving = false;
        this.snapshot = '';
        this.draft = null;
        this.workspace = { siblings: [], received: [], sent: [], errors: [] };
        this.loadingWorkspace = false;
        this.gateIssues = [];
        this.suppliedIssues = [];
        this.editMessage = '';
    }
    createRenderRoot() { return this; }
    updated(changed) {
        if (changed.has('project') || changed.has('moduleName'))
            void this.loadWorkspace();
        if (changed.has('data') || changed.has('version') || changed.has('moduleName') || changed.has('project')) {
            this.cancelEdit();
            this.selected = '';
        }
        if (changed.has('data') || changed.has('selected') || changed.has('mode') || changed.has('t'))
            this.present();
    }
    getDraft() {
        const artifact = this.currentArtifact();
        return artifact ? structuredClone(artifact) : null;
    }
    setIssues(issues) { this.suppliedIssues = integrationOracleIssues(issues); }
    sourceValue() { return this.data?.artifacts.integration.value || null; }
    changedItem(lane, id) {
        if (!id)
            return false;
        if (lane === 'plugins')
            return hasPluginDiff(this.data?.diffs || [], this.view().plugins, id);
        return hasItemDiff(this.data?.diffs || [], 'integration.defs.ts', idScope(lane, 'id', id));
    }
    view() { return normalizeIntegration(this.mode === 'edit' && this.draft ? this.draft : this.sourceValue()); }
    currentArtifact() {
        if (this.mode === 'edit' && this.draft)
            return this.draft;
        const view = normalizeIntegration(this.sourceValue());
        return view.schema === 'v2' ? view.raw : null;
    }
    entities() { return this.data?.artifacts.entities.flatMap(item => item.value ? [item.value] : []) || []; }
    journeys() { return this.data?.artifacts.journeys.map(item => item.value).filter((item) => !!item) || []; }
    workflows() { return this.data?.artifacts.workflows.value; }
    actors() { return this.data?.artifacts.access.value?.actors || []; }
    async loadWorkspace() {
        if (!this.project || !this.moduleName)
            return;
        this.loadingWorkspace = true;
        this.workspace = await readIntegrationWorkspace(this.project, this.moduleName);
        this.loadingWorkspace = false;
    }
    beginEdit() {
        const artifact = this.currentArtifact();
        if (!artifact || this.version.startsWith('release:'))
            return;
        this.draft = structuredClone(artifact);
        this.snapshot = JSON.stringify(this.draft);
        this.mode = 'edit';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    cancelEdit() {
        this.draft = null;
        this.mode = 'view';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateDraft(next) {
        this.draft = next;
        this.dirty = JSON.stringify(next) !== this.snapshot;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateItem(lane, index, patch) {
        if (!this.draft)
            return;
        this.updateDraft(patchIntegrationItem(this.draft, lane, index, patch));
    }
    updatePlugin(index, patch) {
        if (!this.draft)
            return;
        this.updateDraft({ ...this.draft, plugins: this.draft.plugins.map((plugin, position) => position === index ? { ...plugin, ...patch } : plugin) });
    }
    transitionOptions() { return this.entities().flatMap(entity => ['create', ...ns5OntologyEntityView(entity).transitions.map(transition => transition.transitionId)].map(transition => `${entity.entityId}.${transition}`)); }
    usedByOptions() {
        const journeys = this.journeys().flatMap(journey => journey.business.steps.map(step => `${journey.journeyId}.${step.stepId}`));
        const processes = this.workflows()?.processes.flatMap(process => process.tasks.map(task => `${process.processId}.${task.taskId}`)) || [];
        return [...journeys, ...processes];
    }
    siblingsForGate() { return this.workspace.siblings; }
    async saveEdit() {
        if (!this.draft || !this.dirty || this.saving || this.version.startsWith('release:'))
            return;
        this.saving = true;
        try {
            const gate = await import('/_102035_/l2/solution/gates/integration70/gate.js');
            const result = gate.validateNs5Integration(this.draft.inbound, this.draft.outbound, this.draft.plugins, {
                moduleName: this.moduleName,
                actors: this.actors(),
                entities: this.entities().map(ns5OntologyEntityView),
                registryModuleNames: [this.moduleName, ...this.workspace.siblings.map(sibling => sibling.moduleName)],
                siblings: this.siblingsForGate(),
                sourcePrompt: this.data?.module?.sourcePrompt || '',
                journeySteps: this.journeys().map(journey => ({ journeyId: journey.journeyId, stepIds: journey.business.steps.map(step => step.stepId) })),
                processTasks: this.workflows()?.processes.map(process => ({ processId: process.processId, taskIds: process.tasks.map(task => task.taskId) })) || [],
            });
            this.gateIssues = result.issues;
            if (!result.ok) {
                this.editMessage = this.t('integration.gateBlocked');
                return;
            }
            await announceNewReleaseChange(this, { path: 'integration.defs.ts', jsonPath: '$', value: structuredClone(this.draft) });
            this.cancelEdit();
        }
        catch (error) {
            this.editMessage = this.t('integration.gateUnavailable', { message: error instanceof Error ? error.message : String(error) });
        }
        finally {
            this.saving = false;
        }
    }
    renderIssues() {
        const oracle = integrationOracleIssues([...(this.data?.validation.issues || []), ...this.suppliedIssues]);
        const issues = [...new Map([...oracle, ...this.gateIssues].map(issue => [`${issue.code}:${issue.message}`, issue])).values()];
        if (!issues.length && !this.editMessage)
            return this.renderIntegrity();
        return html `${this.renderIntegrity()}<section class="nr-integration__issues" role="alert"><strong>${this.t('integration.issues')}</strong>${this.editMessage ? html `<p>${this.editMessage}</p>` : nothing}${issues.map(issue => html `<div class=${`is-${issue.severity}`}><code>${issue.code}</code><p>${issue.message}</p></div>`)}</section>`;
    }
    renderIntegrity() {
        const checks = (this.data?.finalizeReport?.checks || []).filter(item => item.checkId === 'I11' || item.checkId === 'I12');
        if (!checks.length)
            return nothing;
        return html `<section class="nr-integration__integrity">${checks.map(check => html `<article class=${`is-${check.status}`}><span>${check.checkId}</span><strong>${this.t(`oracle.${check.checkId}`)}</strong><p>${this.t(`oracle.status.${check.status}`)}</p><small>${this.t('general.oracleCounts', { errors: check.errorCount, warnings: check.warningCount })}</small></article>`)}</section>`;
    }
    renderItem(item, lane, index) {
        if (this.mode === 'edit' && this.draft) {
            const peer = lane === 'inbound' ? item.from || '' : item.to || '';
            const transitions = item.writes?.length === 1 ? this.entities().filter(entity => entity.entityId === item.writes[0]).flatMap(entity => ns5OntologyEntityView(entity).transitions) : [];
            return html `<article class="nr-integration__item is-edit">
        <header><div><span>${this.t(`integration.${lane}.singular`)}</span><code>${item.id}</code></div></header>
        <div class="nr-integration__form">
          <label><span>${this.t('integration.kind')}</span><select @change=${(event) => this.updateItem(lane, index, { kind: event.currentTarget.value })}>${INTEGRATION_KINDS.map(kind => html `<option value=${kind} ?selected=${item.kind === kind}>${this.t(`integration.kind.${kind}`)}</option>`)}</select></label>
          <label><span>${lane === 'inbound' ? this.t('integration.from') : this.t('integration.to')}</span>${item.kind === 'external' ? html `<input .value=${peer} @input=${(event) => this.updateItem(lane, index, lane === 'inbound' ? { from: event.currentTarget.value } : { to: event.currentTarget.value })}>` : html `<select @change=${(event) => this.updateItem(lane, index, lane === 'inbound' ? { from: event.currentTarget.value } : { to: event.currentTarget.value })}>${lane === 'inbound' ? html `<option value="organization" ?selected=${peer === 'organization'}>${this.t('integration.organization')}</option>` : html `<option value="any" ?selected=${peer === 'any'}>${this.t('integration.any')}</option>`}${[...new Set([peer, ...this.workspace.siblings.map(sibling => sibling.moduleName)])].filter(value => value && value !== "any" && value !== "organization").map(value => html `<option value=${value} ?selected=${peer === value}>${value}</option>`)}</select>`}</label>
          <label><span>${this.t('integration.id')}</span><input readonly .value=${item.id}></label>
          <label><span>${this.t('integration.event')}</span><input readonly .value=${item.event || ''}></label>
          ${lane === 'inbound' ? html `
            <label><span>${this.t('integration.effect')}</span><select @change=${(event) => this.updateItem(lane, index, { effect: event.currentTarget.value, transitionRef: undefined })}>${INTEGRATION_EFFECTS.map(effect => html `<option value=${effect} ?selected=${item.effect === effect}>${this.t(`integration.effect.${effect}`)}</option>`)}</select></label>
            <label><span>${this.t('integration.writes')}</span><select multiple @change=${(event) => this.updateItem(lane, index, { writes: [...event.currentTarget.selectedOptions].map(option => option.value) })}>${[...new Set([...(item.writes || []), ...this.entities().map(entity => entity.entityId)])].map(id => html `<option value=${id} ?selected=${item.writes?.includes(id)}>${this.entities().find(entity => entity.entityId === id)?.title || id}</option>`)}</select></label>
            ${item.effect === 'transition' ? html `<label><span>${this.t('integration.transition')}</span><select @change=${(event) => this.updateItem(lane, index, { transitionRef: event.currentTarget.value })}><option value="" ?selected=${!item.transitionRef}>${this.t('integration.choose')}</option>${[...new Set([...(item.transitionRef ? [item.transitionRef] : []), ...transitions.map(transition => transition.transitionId)])].map(id => html `<option value=${id} ?selected=${item.transitionRef === id}>${id}</option>`)}</select></label>` : nothing}
          ` : html `
            <label><span>${this.t('integration.on')}</span><select @change=${(event) => this.updateItem(lane, index, { on: event.currentTarget.value })}><option value="" ?selected=${!item.on}>${this.t('integration.choose')}</option>${[...new Set([...(item.on ? [item.on] : []), ...this.transitionOptions()])].map(option => html `<option value=${option} ?selected=${item.on === option}>${option}</option>`)}</select></label>
          `}
            <label><span>${this.t('integration.entities')}</span><select multiple @change=${(event) => this.updateItem(lane, index, { entityRefs: [...event.currentTarget.selectedOptions].map(option => option.value) })}>${[...new Set([...item.entityRefs, ...this.entities().map(entity => entity.entityId)])].map(id => html `<option value=${id} ?selected=${item.entityRefs.includes(id)}>${this.entities().find(entity => entity.entityId === id)?.title || id}</option>`)}</select></label>
          <label class="is-wide"><span>${this.t('integration.itemDescription')}</span><textarea .value=${item.description} @input=${(event) => this.updateItem(lane, index, { description: event.currentTarget.value })}></textarea></label>
        </div>
      </article>`;
        }
        const trigger = lane === 'inbound' ? item.from : item.on;
        const destination = lane === 'inbound' ? (item.writes || item.entityRefs).join(', ') : item.to;
        return html `<article class="nr-integration__flow"><span>${trigger || this.t('integration.notDeclared')}</span><span aria-hidden="true">→</span><button type="button" @click=${() => this.select(`${lane}:${index}`)}>${item.event || item.id}${changedDot(this.changedItem(lane, item.id), this.t)}</button><span aria-hidden="true">→</span><span>${destination === 'any' ? this.t('integration.any') : destination || this.t('integration.notDeclared')}</span></article>`;
    }
    renderLane(lane, items) {
        return html `<section class=${`nr-integration__lane lane-${lane}`}><header><span>${this.t(`integration.${lane}`)}</span><strong>${items.length}</strong></header><div>${items.map((item, index) => this.renderItem(item, lane, index))}${!items.length ? html `<p class="nr-integration__lane-empty">${this.t(`integration.${lane}Empty`)}</p>` : nothing}</div></section>`;
    }
    renderPlugin(plugin, index) {
        if (this.mode === 'edit' && this.draft) {
            const current = this.draft.plugins[index];
            if (!current)
                return nothing;
            const options = [...new Set([...current.usedBy, ...this.usedByOptions()])];
            return html `<article class="nr-integration__plugin is-edit"><header><label>${this.t('integration.plugin')}<input readonly .value=${current.pluginId}></label></header><label>${this.t('integration.usedBy')}<select multiple @change=${(event) => this.updatePlugin(index, { usedBy: [...event.currentTarget.selectedOptions].map(option => option.value) })}>${options.map(value => html `<option value=${value} ?selected=${current.usedBy.includes(value)}>${value}</option>`)}</select></label><label>${this.t('integration.itemDescription')}<textarea .value=${current.description} @input=${(event) => this.updatePlugin(index, { description: event.currentTarget.value })}></textarea></label></article>`;
        }
        return html `<article class="nr-integration__plugin"><button type="button" @click=${() => this.select(`plugins:${index}`)}>${plugin.pluginId}${changedDot(this.changedItem('plugins', plugin.pluginId), this.t)}</button><p>${plugin.description}</p>${(plugin.usedBy.length ? plugin.usedBy : plugin.legacyEntityRefs).map(value => html `<code>${value}</code>`)}</article>`;
    }
    select(id) {
        if (this.saving || !canDiscardNewReleaseDraft(this))
            return;
        if (this.version === 'asis' && this.currentArtifact()) {
            requestNewReleaseEdit(this, id);
            return;
        }
        this.cancelEdit();
        this.selected = id;
        if (!this.version.startsWith('release:'))
            this.beginEdit();
        this.present();
    }
    back() {
        if (this.saving || !canDiscardNewReleaseDraft(this))
            return;
        this.cancelEdit();
        this.selected = '';
        requestNewReleasePresentation(this, 'graph');
        this.present();
    }
    present() {
        const view = this.view();
        const presentation = {
            detail: !!this.selected, back: () => this.back(), select: id => { if (id.includes(':'))
                this.select(id); },
            nodes: ['inbound', 'outbound', 'plugins'].map(lane => ({ id: lane, label: this.t(`integration.${lane}`), value: '', children: view[lane].map((item, index) => ({ id: `${lane}:${index}`, label: 'pluginId' in item ? item.pluginId : item.id, value: '', searchText: `${'event' in item ? item.event || '' : ''} ${item.description}`, changed: this.changedItem(lane, 'pluginId' in item ? item.pluginId : item.id), children: [] })) })),
        };
        this.dispatchEvent(new CustomEvent('nr-view-state', { bubbles: true, composed: true, detail: presentation }));
    }
    renderRequests() {
        const requests = [...this.workspace.received.map(item => ({ ...item, direction: 'received' })), ...this.workspace.sent.map(item => ({ ...item, direction: 'sent' }))];
        return html `<section class="nr-integration__requests"><header><div><span>${this.t('integration.requests')}</span><p>${this.t('integration.requestsDescription')}</p></div><strong>${requests.length}</strong></header><div class="nr-integration__request-list">${this.loadingWorkspace ? html `<p>${this.t('integration.requestsLoading')}</p>` : requests.map(request => html `<article class=${`is-${request.direction}`}><i></i><div><span>${request.direction === 'sent' ? this.t('integration.requestSent') : this.t('integration.requestReceived')}</span><strong>${request.value.eventId}</strong><p>${request.value.description}</p><code>${request.value.requestedBy} → ${request.targetModule === 'organization' ? request.value.to : request.targetModule}</code></div><b>${this.t('integration.requested')}</b></article>`)}${!this.loadingWorkspace && !requests.length ? html `<p>${this.t('integration.requestsEmpty')}</p>` : nothing}</div></section>`;
    }
    render() {
        const view = this.view();
        if (!this.sourceValue())
            return html `<section class="nr-integration__empty"><h2>${this.t('integration.emptyTitle')}</h2><p>${this.t('integration.emptyBody')}</p>${this.renderIssues()}${this.renderRequests()}</section>`;
        if (view.schema === 'unknown')
            return html `<section class="nr-integration__unknown" role="alert"><h2>${this.t('integration.unknownTitle')}</h2><p>${this.t('integration.unknownBody', { version: view.schemaVersion || this.t('integration.notRecorded') })}</p><pre>${JSON.stringify(view.raw, null, 2)}</pre></section>`;
        const [lane, position] = this.selected.split(':');
        const index = Number(position);
        const item = lane === 'inbound' || lane === 'outbound' ? view[lane][index] : null;
        const plugin = lane === 'plugins' ? view.plugins[index] : null;
        return html `<section class="nr-integration">
      ${this.selected ? html `<section class="nr-integration__detail"><header><h2>${plugin?.pluginId || item?.event || item?.id}</h2>${view.schema === 'v2' && this.mode === 'view' && !this.version.startsWith('release:') ? html `<button type="button" @click=${this.beginEdit}>${this.t('integration.edit')}</button>` : nothing}</header>
        <fieldset ?disabled=${this.saving}>${item && (lane === 'inbound' || lane === 'outbound') ? (this.mode === 'edit' ? this.renderItem(item, lane, index) : html `<dl>${Object.entries(item).map(([key, value]) => html `<div><dt>${this.t(INTEGRATION_ITEM_LABELS[key])}</dt><dd>${Array.isArray(value) ? value.join(', ') : value}</dd></div>`)}</dl>`) : plugin ? this.renderPlugin(plugin, index) : nothing}</fieldset>
        ${this.mode === 'edit' ? html `<footer class="nr-integration__edit-footer"><span>${this.t(this.dirty ? 'integration.unsaved' : 'integration.noChanges')}</span><div><button type="button" ?disabled=${this.saving} @click=${() => { if (canDiscardNewReleaseDraft(this))
            this.cancelEdit(); }}>${this.t('integration.cancel')}</button><button class="is-primary" type="button" ?disabled=${!this.dirty || this.saving} @click=${this.saveEdit}>${this.t('integration.save')}</button></div></footer>` : nothing}
      </section>` : html `<div class="nr-integration__lanes">${this.renderLane('inbound', view.inbound)}${this.renderLane('outbound', view.outbound)}</div><section class="nr-integration__plugins"><header><span>${this.t('integration.plugins')}</span><strong>${view.plugins.length}</strong></header><div>${view.plugins.map((plugin, index) => this.renderPlugin(plugin, index))}${!view.plugins.length ? html `<p>${this.t('integration.pluginsEmpty')}</p>` : nothing}</div></section>${this.renderRequests()}`}
      ${this.renderIssues()}
    </section>`;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseIntegration102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseIntegration102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseIntegration102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseIntegration102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseIntegration102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseIntegration102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseIntegration102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseIntegration102035.prototype, "selected", void 0);
__decorate([
    state()
], NewReleaseIntegration102035.prototype, "saving", void 0);
__decorate([
    state()
], NewReleaseIntegration102035.prototype, "draft", void 0);
__decorate([
    state()
], NewReleaseIntegration102035.prototype, "workspace", void 0);
__decorate([
    state()
], NewReleaseIntegration102035.prototype, "loadingWorkspace", void 0);
__decorate([
    state()
], NewReleaseIntegration102035.prototype, "gateIssues", void 0);
__decorate([
    state()
], NewReleaseIntegration102035.prototype, "suppliedIssues", void 0);
__decorate([
    state()
], NewReleaseIntegration102035.prototype, "editMessage", void 0);
NewReleaseIntegration102035 = __decorate([
    customElement('new-release--widgets--integration-102035')
], NewReleaseIntegration102035);
export { NewReleaseIntegration102035 };
