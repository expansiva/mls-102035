/// <mls fileReference="_102035_/l2/newRelease/widgets/shared/iconModel.ts" enhancement="_blank" />
import { LUCIDE_ICONS, isLucideIcon } from '../../../solution/lucideIcons.js';
export const JOURNEY_ICON_DEFAULTS = {
    locate: 'search', inspect: 'eye', act: 'check', decide: 'git-branch', handoff: 'arrow-right-left',
};
export const WORKFLOW_ICON_DEFAULTS = {
    human: 'user', mechanical: 'settings', system: 'settings', llm: 'bot', wait: 'clock', alert: 'bell',
};
export function resolveNewReleaseIcon(value, fallback) {
    return value && isLucideIcon(value) ? value : fallback;
}
export function iconNeedsFallback(value) { return !value || !isLucideIcon(value); }
export function searchNewReleaseIcons(query) {
    const search = query.trim().toLowerCase();
    return LUCIDE_ICONS.filter(name => name.includes(search));
}
/** Only catalog selections reach the editor; empty selection removes the optional property. */
export function withNewReleaseIcon(item, value) {
    if (value && !isLucideIcon(value))
        return item;
    const next = { ...item };
    if (value)
        next.icon = value;
    else
        delete next.icon;
    return next;
}
