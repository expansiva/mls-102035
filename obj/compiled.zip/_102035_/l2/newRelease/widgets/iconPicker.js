/// <mls fileReference="_102035_/l2/newRelease/widgets/iconPicker.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, svg } from 'lit';
import { unsafeSVG } from 'lit/directives/unsafe-svg.js';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { lucideArtwork } from '/_102035_/l2/newRelease/widgets/lucideArtwork.js';
import { iconNeedsFallback, resolveNewReleaseIcon, searchNewReleaseIcons } from '/_102035_/l2/newRelease/widgets/iconModel.js';
export function renderNewReleaseIcon(value, fallback) {
    // unsafeSVG receives only checked, versioned local artwork, never user text or URLs.
    return svg `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${unsafeSVG(lucideArtwork(resolveNewReleaseIcon(value, fallback)))}</svg>`;
}
let NewReleaseIconPicker102035 = class NewReleaseIconPicker102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--icon-picker-102035 {
  display: block;
  grid-column: 1 / -1;
}
new-release--widgets--icon-picker-102035 .nr-icon-picker {
  padding: 12px;
  border: 1px solid #344155;
  border-radius: 8px;
  color: #e2e8f0;
  background: #111b2b;
}
new-release--widgets--icon-picker-102035 .nr-icon-picker__preview {
  display: flex;
  align-items: center;
  gap: 10px;
  overflow-wrap: anywhere;
}
new-release--widgets--icon-picker-102035 .nr-icon-picker__notice {
  color: #fbbf24;
}
new-release--widgets--icon-picker-102035 summary {
  cursor: pointer;
  padding: 12px 0;
}
new-release--widgets--icon-picker-102035 label {
  display: grid;
  gap: 6px;
}
new-release--widgets--icon-picker-102035 input {
  width: 100%;
  box-sizing: border-box;
  padding: 10px;
  background: #0b1220;
  border: 1px solid #475569;
  color: inherit;
}
new-release--widgets--icon-picker-102035 button {
  min-height: 44px;
  border: 1px solid #475569;
  border-radius: 6px;
  background: #172338;
  color: inherit;
  cursor: pointer;
  padding: 8px;
}
new-release--widgets--icon-picker-102035 button:focus-visible,
new-release--widgets--icon-picker-102035 summary:focus-visible,
new-release--widgets--icon-picker-102035 input:focus-visible {
  outline: 2px solid #60a5fa;
  outline-offset: 2px;
}
new-release--widgets--icon-picker-102035 button[aria-pressed="true"] {
  border-color: #60a5fa;
  background: #1e3a5f;
}
new-release--widgets--icon-picker-102035 .nr-icon-picker__results {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
  gap: 6px;
  max-height: 300px;
  overflow: auto;
  margin: 10px 0;
}
new-release--widgets--icon-picker-102035 .nr-icon-picker__results button {
  display: flex;
  align-items: center;
  gap: 8px;
  text-align: left;
  overflow-wrap: anywhere;
}
new-release--widgets--icon-picker-102035 svg {
  flex: 0 0 24px;
  width: 24px;
  height: 24px;
}
`);
        this.value = '';
        this.fallback = 'route';
        this.t = key => key;
        this.query = '';
        this.limit = 60;
    }
    createRenderRoot() { return this; }
    choose(value) {
        if (value === this.value)
            return;
        this.dispatchEvent(new CustomEvent('nr-icon-selected', { detail: value, bubbles: true, composed: true }));
    }
    render() {
        const matches = searchNewReleaseIcons(this.query);
        return html `<div class="nr-icon-picker">
      <p>${this.t('icons.label')}</p>
      <div class="nr-icon-picker__preview">${renderNewReleaseIcon(this.value, this.fallback)}<span>${this.value || this.t('icons.default')}</span></div>
      ${iconNeedsFallback(this.value) ? html `<p class="nr-icon-picker__notice" role="status">${this.t(this.value ? 'icons.unknown' : 'icons.absent')}</p>` : nothing}
      <details><summary>${this.t('icons.choose')}</summary>
        <label>${this.t('icons.search')}<input type="search" .value=${this.query} placeholder=${this.t('icons.searchPlaceholder')} @input=${(event) => { this.query = event.currentTarget.value; this.limit = 60; }}></label>
        <button type="button" @click=${() => this.choose('')}>${this.t('icons.default')}</button>
        <p role="status">${this.t('icons.results', { count: matches.length })}</p>
        <div class="nr-icon-picker__results">${matches.slice(0, this.limit).map(name => html `<button type="button" aria-pressed=${this.value === name} @click=${() => this.choose(name)}>${renderNewReleaseIcon(name, this.fallback)}<span>${name}</span></button>`)}</div>
        ${matches.length > this.limit ? html `<button type="button" @click=${() => { this.limit += 60; }}>${this.t('icons.more')}</button>` : nothing}
      </details>
    </div>`;
    }
};
__decorate([
    property({ type: String })
], NewReleaseIconPicker102035.prototype, "value", void 0);
__decorate([
    property({ type: String })
], NewReleaseIconPicker102035.prototype, "fallback", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseIconPicker102035.prototype, "t", void 0);
__decorate([
    state()
], NewReleaseIconPicker102035.prototype, "query", void 0);
__decorate([
    state()
], NewReleaseIconPicker102035.prototype, "limit", void 0);
NewReleaseIconPicker102035 = __decorate([
    customElement('new-release--widgets--icon-picker-102035')
], NewReleaseIconPicker102035);
export { NewReleaseIconPicker102035 };
