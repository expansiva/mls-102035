/// <mls fileReference="_102035_/l2/newRelease/widgets/general.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { languages } from '/_102027_/l2/collabLanguages.js';
import { NS5_STEP_IDS } from '/_102035_/l2/solution/types.js';
import { announceNewReleaseChange, } from '/_102035_/l2/newRelease/editContract.js';
import { GENERAL_DETAIL_NAME, GENERAL_DETAIL_TYPES, addGeneralDetail, generalOracleTab, removeGeneralDetail, setGeneralLanguages, } from '/_102035_/l2/newRelease/widgets/generalModel.js';
const ORACLE_CHECK_IDS = Array.from({ length: 13 }, (_, index) => `I${index + 1}`);
const LANGUAGE_OPTIONS = [...languages]
    .map(language => ({ code: language.code, name: language.name }))
    .sort((a, b) => a.name.localeCompare(b.name));
let NewReleaseGeneral102035 = class NewReleaseGeneral102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--general-102035 {
  display: block;
}
new-release--widgets--general-102035 .nr-general {
  display: grid;
}
new-release--widgets--general-102035 .nr-general__section-title,
new-release--widgets--general-102035 .nr-summary-card > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.66rem;
  font-weight: 800;
  letter-spacing: 0.115em;
  text-transform: uppercase;
}
new-release--widgets--general-102035 .nr-general__progress {
  padding: 1.05rem 1.25rem 0.95rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-bg, #fff);
}
new-release--widgets--general-102035 .nr-general__section-title {
  margin-bottom: 0.8rem;
}
new-release--widgets--general-102035 .nr-general__progress ol {
  display: grid;
  grid-template-columns: repeat(8, minmax(4.5rem, 1fr));
  gap: 0;
  margin: 0;
  padding: 0;
  list-style: none;
}
new-release--widgets--general-102035 .nr-step {
  position: relative;
  display: flex;
  align-items: center;
  min-width: 0;
  gap: 0.48rem;
}
new-release--widgets--general-102035 .nr-step::after {
  content: '';
  position: absolute;
  z-index: 0;
  top: 0.72rem;
  left: 1.45rem;
  width: calc(100% - 1.45rem);
  height: 2px;
  background: var(--border-subtle, #e4e9f0);
}
new-release--widgets--general-102035 .nr-step:last-child::after {
  display: none;
}
new-release--widgets--general-102035 .nr-step__marker {
  position: relative;
  z-index: 1;
  display: grid;
  flex: none;
  width: 1.45rem;
  height: 1.45rem;
  place-items: center;
  border: 2px solid var(--border-default, #cfd8e3);
  border-radius: 50%;
  background: var(--surface-bg, #fff);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
  font-weight: 800;
}
new-release--widgets--general-102035 .nr-step__copy {
  position: relative;
  z-index: 1;
  display: grid;
  min-width: 0;
  padding-right: 0.25rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--general-102035 .nr-step__copy strong,
new-release--widgets--general-102035 .nr-step__copy small {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--general-102035 .nr-step__copy strong {
  color: var(--text-default, #2f3a48);
  font-size: 0.7rem;
}
new-release--widgets--general-102035 .nr-step__copy small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
}
new-release--widgets--general-102035 .nr-step--approved .nr-step__marker,
new-release--widgets--general-102035 .nr-step--approved::after {
  border-color: var(--status-success-text, #25640e);
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--general-102035 .nr-step--running .nr-step__marker {
  border-color: var(--status-info-text, #0b5497);
  color: var(--status-info-text, #0b5497);
  animation: nr-general-pulse 1.7s ease-in-out infinite;
}
new-release--widgets--general-102035 .nr-step--failed .nr-step__marker {
  border-color: var(--status-error-text, #ab2328);
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--general-102035 .nr-general__summary {
  display: grid;
  grid-template-columns: 1.4fr repeat(2, minmax(0, 0.8fr));
  gap: 0.75rem;
  padding: 1rem 1.25rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--general-102035 .nr-summary-card {
  min-width: 0;
  padding: 0.85rem 0.95rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.8rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--general-102035 .nr-summary-card strong {
  display: block;
  margin-top: 0.3rem;
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.88rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--general-102035 .nr-summary-card div {
  display: flex;
  gap: 0.7rem;
  margin-top: 0.28rem;
}
new-release--widgets--general-102035 .nr-summary-card small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.66rem;
}
new-release--widgets--general-102035 .nr-summary-card--oracle {
  border-left: 0.24rem solid var(--status-success-text, #25640e);
}
new-release--widgets--general-102035 .nr-summary-card--oracle.nr-summary-card--failed {
  border-left-color: var(--status-error-text, #ab2328);
}
new-release--widgets--general-102035 .nr-summary-card--oracle.nr-summary-card--pending {
  border-left-color: var(--border-default, #cfd8e3);
}
new-release--widgets--general-102035 .nr-general__foundation {
  display: grid;
  gap: 1.15rem;
  padding: 1.3rem 1.25rem 1.5rem;
}
new-release--widgets--general-102035 .nr-general__group {
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.9rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--general-102035 .nr-general__group > summary {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.85rem 1rem;
  cursor: pointer;
  list-style: none;
}
new-release--widgets--general-102035 .nr-general__group > summary::-webkit-details-marker {
  display: none;
}
new-release--widgets--general-102035 .nr-general__group > summary > div {
  display: grid;
  gap: 0.16rem;
}
new-release--widgets--general-102035 .nr-general__group > summary strong {
  color: var(--text-strong, #111827);
  font-size: 0.76rem;
}
new-release--widgets--general-102035 .nr-general__group > summary small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.66rem;
  line-height: 1.4;
}
new-release--widgets--general-102035 .nr-general__group > summary > span {
  color: var(--link-text, #0f62b8);
  font-size: 1rem;
  transition: transform 0.16s ease;
}
new-release--widgets--general-102035 .nr-general__group[open] > summary > span {
  transform: rotate(180deg);
}
new-release--widgets--general-102035 .nr-general__group-content {
  display: grid;
  gap: 1rem;
  padding: 1rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  background: color-mix(in srgb, var(--surface-alt-bg, #f5f7fa) 58%, transparent);
}
new-release--widgets--general-102035 .nr-general__group-content--process .nr-general__progress {
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.85rem;
}
new-release--widgets--general-102035 .nr-general__group-content--process .nr-general__summary {
  padding: 0;
  border-bottom: 0;
}
new-release--widgets--general-102035 .nr-general__intro {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 2rem;
}
new-release--widgets--general-102035 .nr-general__eyebrow {
  display: block;
  margin-bottom: 0.45rem;
  color: var(--link-text, #0f62b8);
  font-size: 0.68rem;
  font-weight: 800;
  letter-spacing: 0.13em;
  text-transform: uppercase;
}
new-release--widgets--general-102035 h2 {
  margin: 0;
  color: var(--text-strong, #111827);
  font-size: clamp(1.35rem, 2.3vw, 2rem);
  font-weight: 750;
  letter-spacing: -0.035em;
  line-height: 1.08;
}
new-release--widgets--general-102035 .nr-general__intro p {
  max-width: 46rem;
  margin: 0.65rem 0 0;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.9rem;
  line-height: 1.6;
}
new-release--widgets--general-102035 .nr-general__schema {
  flex: none;
  padding: 0.42rem 0.7rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-family: var(--font-family-mono, ui-monospace, monospace);
  font-size: 0.66rem;
}
new-release--widgets--general-102035 .nr-general__language-panel {
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.9rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--general-102035 .nr-general__language-panel > header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.72rem 0.9rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--general-102035 .nr-general__language-panel > header > div {
  display: grid;
  gap: 0.15rem;
}
new-release--widgets--general-102035 .nr-general__language-panel > header span {
  color: var(--text-strong, #111827);
  font-size: 0.74rem;
  font-weight: 800;
}
new-release--widgets--general-102035 .nr-general__language-panel > header small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
}
new-release--widgets--general-102035 .nr-general__languages,
new-release--widgets--general-102035 .nr-general__metrics {
  display: grid;
  gap: 0.75rem;
}
new-release--widgets--general-102035 .nr-general__languages {
  grid-template-columns: repeat(3, minmax(0, 1fr));
  padding: 0.85rem;
}
new-release--widgets--general-102035 .nr-general__languages > div,
new-release--widgets--general-102035 .nr-general__metric {
  min-width: 0;
  padding: 0.85rem 0.95rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.78rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--general-102035 .nr-general__languages span,
new-release--widgets--general-102035 .nr-general__languages label,
new-release--widgets--general-102035 .nr-general__metric span {
  display: block;
  margin-bottom: 0.35rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.055em;
  text-transform: uppercase;
}
new-release--widgets--general-102035 .nr-general__languages strong {
  color: var(--text-default, #2f3a48);
  font-size: 0.88rem;
}
new-release--widgets--general-102035 .nr-general__languages > div > small {
  display: block;
  margin-top: 0.3rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
}
new-release--widgets--general-102035 .nr-general select,
new-release--widgets--general-102035 .nr-general input {
  width: 100%;
  min-height: 2.25rem;
  padding: 0.45rem 0.6rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  outline: none;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font: inherit;
  font-size: 0.78rem;
}
new-release--widgets--general-102035 .nr-general select:focus,
new-release--widgets--general-102035 .nr-general input:focus {
  border-color: var(--focus-ring, #1273d4);
  box-shadow: 0 0 0 0.18rem color-mix(in srgb, var(--focus-ring, #1273d4) 18%, transparent);
}
new-release--widgets--general-102035 .nr-general__languages p {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem;
  margin: 0;
}
new-release--widgets--general-102035 .nr-general__languages p strong {
  display: inline-flex;
  align-items: center;
  gap: 0.28rem;
  padding: 0.25rem 0.48rem;
  border: 1px solid var(--selected-border, #1273d4);
  border-radius: 0.45rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.72rem;
}
new-release--widgets--general-102035 .nr-general__languages p strong button {
  display: grid;
  width: 1rem;
  height: 1rem;
  padding: 0;
  place-items: center;
  border: 0;
  border-radius: 50%;
  background: transparent;
  color: inherit;
  cursor: pointer;
}
new-release--widgets--general-102035 .nr-general__languages p strong button:disabled {
  cursor: not-allowed;
  opacity: 0.38;
}
new-release--widgets--general-102035 .nr-general__add-language {
  display: grid;
  gap: 0.3rem;
  margin-top: 0.7rem;
}
new-release--widgets--general-102035 .nr-general__metrics {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}
new-release--widgets--general-102035 .nr-general__metric strong {
  color: var(--text-strong, #111827);
  font-size: 1.75rem;
  font-weight: 750;
  letter-spacing: -0.04em;
}
new-release--widgets--general-102035 .nr-general__identity-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.75rem;
}
new-release--widgets--general-102035 .nr-general__identity-grid article {
  display: grid;
  min-width: 0;
  gap: 0.3rem;
  padding: 0.78rem 0.9rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.78rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--general-102035 .nr-general__identity-grid span,
new-release--widgets--general-102035 .nr-general__identity-grid small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
}
new-release--widgets--general-102035 .nr-general__identity-grid span {
  font-weight: 750;
  letter-spacing: 0.065em;
  text-transform: uppercase;
}
new-release--widgets--general-102035 .nr-general__identity-grid strong {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.8rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--general-102035 .nr-button {
  min-height: 2.2rem;
  padding: 0.42rem 0.75rem;
  border-radius: 0.58rem;
  font: inherit;
  font-size: 0.72rem;
  font-weight: 750;
  cursor: pointer;
}
new-release--widgets--general-102035 .nr-button--secondary {
  border: 1px solid var(--border-default, #cfd8e3);
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--general-102035 .nr-button--primary {
  border: 1px solid var(--button-primary-bg, #126ac2);
  background: var(--button-primary-bg, #126ac2);
  color: var(--button-primary-text, #fff);
}
new-release--widgets--general-102035 .nr-button:disabled {
  cursor: not-allowed;
  opacity: 0.48;
}
new-release--widgets--general-102035 .nr-general__editing {
  padding: 0.3rem 0.55rem;
  border-radius: 999px;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.65rem;
  font-weight: 750;
}
new-release--widgets--general-102035 .nr-general__prompt,
new-release--widgets--general-102035 .nr-general__details-section,
new-release--widgets--general-102035 .nr-general__cost-section,
new-release--widgets--general-102035 .nr-general__adjustments,
new-release--widgets--general-102035 .nr-general__oracle {
  padding: 1.05rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.95rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--general-102035 .nr-general__details-section > header,
new-release--widgets--general-102035 .nr-general__cost-section > header,
new-release--widgets--general-102035 .nr-general__adjustments > header,
new-release--widgets--general-102035 .nr-general__oracle > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1rem;
  margin-bottom: 0.85rem;
}
new-release--widgets--general-102035 .nr-general__details-section > header p,
new-release--widgets--general-102035 .nr-general__adjustments > header p,
new-release--widgets--general-102035 .nr-general__oracle > header p {
  margin: 0.28rem 0 0;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.72rem;
  line-height: 1.45;
}
new-release--widgets--general-102035 .nr-general__details-section > header > strong,
new-release--widgets--general-102035 .nr-general__cost-section > header > strong {
  color: var(--text-default, #2f3a48);
  font-size: 0.72rem;
}
new-release--widgets--general-102035 .nr-general__detail-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.7rem;
}
new-release--widgets--general-102035 .nr-general__detail-card {
  position: relative;
  display: grid;
  align-content: start;
  gap: 0.62rem;
  min-width: 0;
  padding: 0.85rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.75rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--general-102035 .nr-general__detail-card > div {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
}
new-release--widgets--general-102035 .nr-general__detail-card code {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.74rem;
  font-weight: 750;
  text-overflow: ellipsis;
}
new-release--widgets--general-102035 .nr-general__detail-card label {
  display: grid;
  gap: 0.3rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
  font-weight: 700;
}
new-release--widgets--general-102035 .nr-general__detail-card p {
  margin: 0;
  color: var(--text-default, #2f3a48);
  font-size: 0.72rem;
  line-height: 1.5;
}
new-release--widgets--general-102035 .nr-general__detail-type {
  justify-self: start;
  padding: 0.22rem 0.42rem;
  border-radius: 0.4rem;
  background: color-mix(in srgb, var(--chart-series-3, #7c3aed) 12%, transparent);
  color: var(--chart-series-3, #7c3aed);
  font-family: var(--font-family-mono, ui-monospace, monospace);
  font-size: 0.64rem;
}
new-release--widgets--general-102035 .nr-general__remove-detail {
  border: 0;
  background: transparent;
  color: var(--status-error-text, #ab2328);
  font-size: 1rem;
  cursor: pointer;
}
new-release--widgets--general-102035 .nr-general__add-detail {
  display: grid;
  grid-template-columns: minmax(9rem, 1.2fr) minmax(7rem, 0.7fr) auto;
  align-items: end;
  gap: 0.65rem;
  margin-top: 0.8rem;
  padding-top: 0.8rem;
  border-top: 1px dashed var(--border-default, #cfd8e3);
}
new-release--widgets--general-102035 .nr-general__add-detail label {
  display: grid;
  gap: 0.3rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.63rem;
  font-weight: 700;
}
new-release--widgets--general-102035 .nr-general__add-detail > small {
  grid-column: 1 / -1;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
}
new-release--widgets--general-102035 .nr-general__edit-message {
  margin: 0.55rem 0 0;
  color: var(--status-error-text, #ab2328);
  font-size: 0.68rem;
}
new-release--widgets--general-102035 .nr-general__empty-section {
  padding: 0.8rem;
  border: 1px dashed var(--border-default, #cfd8e3);
  border-radius: 0.65rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
  text-align: center;
}
new-release--widgets--general-102035 .nr-general__prompt {
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--general-102035 .nr-general__issues {
  margin: 0;
  padding: 0.78rem 0.9rem;
  border: 1px solid color-mix(in srgb, var(--status-error-text, #ab2328) 24%, transparent);
  border-radius: 0.72rem;
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
  font-size: 0.7rem;
}
new-release--widgets--general-102035 .nr-general__issues p {
  margin: 0.3rem 0 0;
  line-height: 1.45;
}
new-release--widgets--general-102035 .nr-general__issues code {
  margin-right: 0.35rem;
  font-size: 0.64rem;
}
new-release--widgets--general-102035 .nr-general__prompt h3 {
  margin: 0 0 0.45rem;
  color: var(--text-strong, #111827);
  font-size: 0.78rem;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}
new-release--widgets--general-102035 .nr-general__prompt p {
  margin: 0;
  color: var(--text-default, #2f3a48);
  font-size: 0.88rem;
  line-height: 1.65;
}
new-release--widgets--general-102035 .nr-general__prompt blockquote {
  margin: 0.9rem 0 0 1.1rem;
  padding-left: 0.8rem;
  border-left: 2px solid var(--border-default, #cfd8e3);
  color: var(--text-default, #2f3a48);
  font-size: 0.8rem;
  line-height: 1.65;
}
new-release--widgets--general-102035 .nr-general__invocation {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.6rem;
  margin: 0.9rem 0 0 1.1rem;
}
new-release--widgets--general-102035 .nr-general__invocation span {
  display: grid;
  gap: 0.2rem;
  padding: 0.62rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.58rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--general-102035 .nr-general__invocation small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
  text-transform: uppercase;
}
new-release--widgets--general-102035 .nr-general__invocation strong {
  color: var(--text-strong, #111827);
  font-size: 0.72rem;
}
new-release--widgets--general-102035 .nr-general__rebuild {
  display: grid;
  gap: 0.25rem;
  margin: 0.65rem 0 0 1.1rem;
  padding: 0.62rem 0.7rem;
  border-radius: 0.58rem;
  background: color-mix(in srgb, var(--status-info-text, #0b5497) 8%, transparent);
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
}
new-release--widgets--general-102035 .nr-general__cost-chart {
  display: grid;
  gap: 0.52rem;
}
new-release--widgets--general-102035 .nr-cost-row {
  display: grid;
  grid-template-columns: 7rem minmax(3rem, 1fr) 5rem;
  align-items: center;
  gap: 0.65rem;
}
new-release--widgets--general-102035 .nr-cost-row > span {
  overflow: hidden;
  color: var(--text-default, #2f3a48);
  font-size: 0.67rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--general-102035 .nr-cost-row > div {
  height: 0.48rem;
  overflow: hidden;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--general-102035 .nr-cost-row i {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(90deg, var(--chart-series-1, #1273d4), var(--chart-series-3, #7c3aed));
}
new-release--widgets--general-102035 .nr-cost-row > strong {
  color: var(--text-muted, #5d6b7e);
  font-family: var(--font-family-mono, ui-monospace, monospace);
  font-size: 0.62rem;
  text-align: right;
}
new-release--widgets--general-102035 .nr-general__adjustment-list {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.62rem;
}
new-release--widgets--general-102035 .nr-general__adjustment-list article {
  padding: 0.72rem 0.78rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-left: 0.2rem solid var(--chart-series-1, #1273d4);
  border-radius: 0.65rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--general-102035 .nr-general__adjustment-list article.is-lifted {
  border-left-color: var(--chart-series-3, #7c3aed);
}
new-release--widgets--general-102035 .nr-general__adjustment-list span {
  display: block;
  margin-bottom: 0.25rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
  font-weight: 750;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}
new-release--widgets--general-102035 .nr-general__adjustment-list strong {
  color: var(--text-strong, #111827);
  font-size: 0.7rem;
}
new-release--widgets--general-102035 .nr-general__adjustment-list p {
  margin: 0.28rem 0 0;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
  line-height: 1.45;
}
new-release--widgets--general-102035 .nr-general__oracle-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 0.6rem;
}
new-release--widgets--general-102035 .nr-oracle-card {
  display: grid;
  min-width: 0;
  gap: 0.38rem;
  padding: 0.72rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.68rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}
new-release--widgets--general-102035 .nr-oracle-card:hover {
  border-color: var(--selected-border, #1273d4);
  transform: translateY(-1px);
}
new-release--widgets--general-102035 .nr-oracle-card > span {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
}
new-release--widgets--general-102035 .nr-oracle-card > span strong {
  color: var(--text-strong, #111827);
  font-size: 0.78rem;
}
new-release--widgets--general-102035 .nr-oracle-card i {
  padding: 0.18rem 0.32rem;
  border-radius: 999px;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
  font-style: normal;
}
new-release--widgets--general-102035 .nr-oracle-card--passed i {
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--general-102035 .nr-oracle-card--failed i {
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--general-102035 .nr-oracle-card--warned i {
  background: var(--status-warning-bg, #fff4d1);
  color: var(--status-warning-text, #795500);
}
new-release--widgets--general-102035 .nr-oracle-card p {
  min-height: 2.7em;
  margin: 0;
  color: var(--text-default, #2f3a48);
  font-size: 0.63rem;
  line-height: 1.4;
}
new-release--widgets--general-102035 .nr-oracle-card small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
}
new-release--widgets--general-102035 .nr-oracle-card em {
  color: var(--link-text, #0f62b8);
  font-size: 0.59rem;
  font-style: normal;
  font-weight: 700;
}
new-release--widgets--general-102035 .nr-general__step-error {
  display: grid;
  gap: 0.25rem;
  margin-top: 0.8rem;
  padding: 0.65rem 0.75rem;
  border-radius: 0.62rem;
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
  font-size: 0.68rem;
}
new-release--widgets--general-102035 .nr-general__edit-actions {
  position: sticky;
  z-index: 4;
  bottom: 0.65rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.75rem 0.85rem;
  border: 1px solid var(--selected-border, #1273d4);
  border-radius: 0.75rem;
  background: color-mix(in srgb, var(--surface-bg, #fff) 94%, transparent);
  box-shadow: 0 0.65rem 2rem rgba(15, 23, 42, 0.18);
  backdrop-filter: blur(10px);
}
new-release--widgets--general-102035 .nr-general__edit-actions > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--general-102035 .nr-general__edit-actions > div {
  display: flex;
  gap: 0.5rem;
}
@keyframes nr-general-pulse {
  50% {
    box-shadow: 0 0 0 0.28rem color-mix(in srgb, var(--status-info-text, #0b5497) 15%, transparent);
  }
}
@media (max-width: 1050px) {
  new-release--widgets--general-102035 .nr-general__progress ol {
    grid-template-columns: repeat(4, minmax(6rem, 1fr));
    gap: 0.65rem 0;
  }
  new-release--widgets--general-102035 .nr-step:nth-child(4)::after {
    display: none;
  }
  new-release--widgets--general-102035 .nr-general__detail-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  new-release--widgets--general-102035 .nr-general__oracle-grid {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
@media (max-width: 780px) {
  new-release--widgets--general-102035 .nr-general__progress {
    padding-inline: 0.85rem;
    overflow-x: auto;
  }
  new-release--widgets--general-102035 .nr-general__progress ol {
    min-width: 42rem;
  }
  new-release--widgets--general-102035 .nr-general__summary {
    grid-template-columns: 1fr;
    padding: 0.85rem;
  }
  new-release--widgets--general-102035 .nr-general__foundation {
    padding: 1rem 0.85rem 1.15rem;
  }
  new-release--widgets--general-102035 .nr-general__intro {
    flex-direction: column;
    gap: 0.8rem;
  }
  new-release--widgets--general-102035 .nr-general__languages {
    grid-template-columns: 1fr;
  }
  new-release--widgets--general-102035 .nr-general__metrics {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  new-release--widgets--general-102035 .nr-general__identity-grid,
  new-release--widgets--general-102035 .nr-general__detail-grid,
  new-release--widgets--general-102035 .nr-general__adjustment-list,
  new-release--widgets--general-102035 .nr-general__oracle-grid,
  new-release--widgets--general-102035 .nr-general__invocation {
    grid-template-columns: 1fr;
  }
  new-release--widgets--general-102035 .nr-general__add-detail {
    grid-template-columns: 1fr;
  }
  new-release--widgets--general-102035 .nr-cost-row {
    grid-template-columns: 5.5rem minmax(2rem, 1fr) 4.4rem;
  }
  new-release--widgets--general-102035 .nr-general__edit-actions {
    align-items: flex-start;
    flex-direction: column;
  }
}
@media (prefers-reduced-motion: reduce) {
  new-release--widgets--general-102035 .nr-step--running .nr-step__marker {
    animation: none;
  }
  new-release--widgets--general-102035 .nr-general__group > summary > span {
    transition: none;
  }
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.issues = [];
        this.draft = null;
        this.newDetailName = '';
        this.newDetailType = 'number';
        this.editMessage = '';
    }
    createRenderRoot() { return this; }
    getDraft() {
        const source = this.draft || this.data?.module;
        return source ? structuredClone(source) : null;
    }
    setIssues(issues) {
        this.issues = issues.filter(issue => issue.artifact === 'module.defs.ts' || issue.artifact === 'module');
    }
    currentModule() {
        return this.mode === 'edit' && this.draft ? this.draft : this.data?.module || null;
    }
    beginEdit() {
        if (!this.data?.module)
            return;
        this.draft = structuredClone(this.data.module);
        this.mode = 'edit';
        this.dirty = false;
        this.editMessage = '';
    }
    cancelEdit() {
        this.draft = null;
        this.mode = 'view';
        this.dirty = false;
        this.newDetailName = '';
        this.editMessage = '';
    }
    updateDraft(next) {
        this.draft = next;
        this.dirty = true;
        this.editMessage = '';
    }
    saveEdit() {
        if (!this.draft || !this.dirty)
            return;
        announceNewReleaseChange(this, {
            path: 'module.defs.ts',
            jsonPath: '$',
            value: structuredClone(this.draft),
        });
        this.mode = 'view';
        this.dirty = false;
        this.draft = null;
        this.newDetailName = '';
    }
    addLanguage(code) {
        if (!this.draft || !code || this.draft.productLanguages.includes(code))
            return;
        this.updateDraft(setGeneralLanguages(this.draft, [...this.draft.productLanguages, code], this.draft.defaultLanguage));
    }
    removeLanguage(code) {
        if (!this.draft || this.draft.productLanguages.length <= 1)
            return;
        this.updateDraft(setGeneralLanguages(this.draft, this.draft.productLanguages.filter(language => language !== code), this.draft.defaultLanguage));
    }
    setDefaultLanguage(code) {
        if (!this.draft || !this.draft.productLanguages.includes(code))
            return;
        this.updateDraft(setGeneralLanguages(this.draft, this.draft.productLanguages, code));
    }
    setDetailType(name, type) {
        if (!this.draft?.details?.[name])
            return;
        this.updateDraft({
            ...this.draft,
            details: {
                ...this.draft.details,
                [name]: { ...this.draft.details[name], type },
            },
        });
    }
    addDetail() {
        if (!this.draft)
            return;
        const name = this.newDetailName.trim();
        if (!GENERAL_DETAIL_NAME.test(name)) {
            this.editMessage = this.t('general.detailNameInvalid');
            return;
        }
        if (this.draft.details?.[name]) {
            this.editMessage = this.t('general.detailNameDuplicate');
            return;
        }
        this.updateDraft(addGeneralDetail(this.draft, name, this.newDetailType));
        this.newDetailName = '';
    }
    removeDetail(name) {
        if (!this.draft)
            return;
        this.updateDraft(removeGeneralDetail(this.draft, name));
    }
    formatDate(value) {
        if (!value)
            return this.t('general.notRecorded');
        const date = new Date(value);
        if (Number.isNaN(date.valueOf()))
            return value;
        return date.toLocaleString(document.documentElement.lang || this.currentModule()?.userLanguage || 'pt-BR');
    }
    metric(key, value) {
        return html `<article class="nr-general__metric"><span>${this.t(key)}</span><strong>${value ?? 0}</strong></article>`;
    }
    renderProgress() {
        const failed = NS5_STEP_IDS.find(step => this.data?.pipeline?.steps[step]?.status === 'failed');
        const failedError = failed ? this.data?.pipeline?.steps[failed]?.error : '';
        return html `
      <section class="nr-general__progress" aria-label=${this.t('a11y.progress')}>
        <div class="nr-general__section-title">${this.t('summary.pipeline')}</div>
        <ol>
          ${NS5_STEP_IDS.map((step, index) => {
            const status = this.data?.pipeline?.steps[step]?.status ?? 'pending';
            return html `
              <li class="nr-step nr-step--${status}">
                <span class="nr-step__marker">${index + 1}</span>
                <span class="nr-step__copy"><strong>${this.t(`step.${step}`)}</strong><small>${this.t(`step.${status}`)}</small></span>
              </li>
            `;
        })}
        </ol>
        ${failedError ? html `
          <div class="nr-general__step-error" role="alert">
            <strong>${this.t('general.failedStep', { step: this.t(`step.${failed}`) })}</strong><span>${failedError}</span>
          </div>
        ` : nothing}
      </section>
    `;
    }
    renderSummary() {
        const report = this.data?.finalizeReport;
        const errors = report?.errors?.length ?? 0;
        const warnings = report?.warnings?.length ?? 0;
        const cost = this.data?.run?.cost?.total;
        const changes = this.data?.tobeChanges ?? 0;
        return html `
      <section class="nr-general__summary">
        <article class="nr-summary-card nr-summary-card--oracle nr-summary-card--${report?.finalStatus || 'pending'}">
          <span>${this.t('summary.oracle')}</span>
          <strong>${report?.finalStatus === 'passed' ? this.t('summary.oraclePassed') : report?.finalStatus === 'failed' ? this.t('summary.oracleFailed') : this.t('summary.oraclePending')}</strong>
          <div><small>${this.t('summary.errors', { count: errors })}</small><small>${this.t('summary.warnings', { count: warnings })}</small></div>
        </article>
        <article class="nr-summary-card"><span>${this.t('summary.cost')}</span><strong>${typeof cost === 'number' ? this.t('summary.costValue', { value: cost.toFixed(4) }) : this.t('summary.costEmpty')}</strong></article>
        <article class="nr-summary-card"><span>${this.t('summary.changes')}</span><strong>${changes ? this.t('summary.changesValue', { count: changes }) : this.t('summary.changesEmpty')}</strong></article>
      </section>
    `;
    }
    renderIdentity(module) {
        const lastRun = this.data?.run?.savedAt || this.data?.pipeline?.updatedAt;
        return html `
      <section class="nr-general__identity-grid" aria-label=${this.t('general.identity')}>
        <article><span>${this.t('general.moduleName')}</span><strong><code>${module.moduleName}</code></strong></article>
        <article><span>${this.t('general.lastRun')}</span><strong>${this.formatDate(lastRun)}</strong><small>${this.data?.run?.verdict || this.data?.pipeline?.status || ''}</small></article>
        <article><span>${this.t('general.requestLanguage')}</span><strong>${module.userLanguage}</strong></article>
      </section>
    `;
    }
    renderLanguagePanel(module) {
        const available = LANGUAGE_OPTIONS.filter(option => !module.productLanguages.includes(option.code));
        return html `
      <section class="nr-general__language-panel" aria-label=${this.t('general.languageScope')}>
        <header>
          <div><span>${this.t('general.languageConfig')}</span><small>${this.t('general.languageScope')}</small></div>
          ${this.mode === 'view'
            ? html `<button type="button" class="nr-button nr-button--secondary" @click=${this.beginEdit}>${this.t('general.edit')}</button>`
            : html `<span class="nr-general__editing">${this.t('general.editing')}</span>`}
        </header>
        <div class="nr-general__languages">
          <div><span>${this.t('general.userLanguage')}</span><strong>${module.userLanguage || '—'}</strong><small>${this.t('general.readonly')}</small></div>
          <div>
            <label for="nr-general-default">${this.t('general.language')}</label>
            ${this.mode === 'edit' ? html `
              <select id="nr-general-default" .value=${module.defaultLanguage} @change=${(event) => this.setDefaultLanguage(event.target.value)}>
                ${module.productLanguages.map(language => html `<option value=${language}>${language}</option>`)}
              </select>
            ` : html `<strong>${module.defaultLanguage || '—'}</strong>`}
          </div>
          <div class="nr-general__product-languages">
            <span>${this.t('general.languages')}</span>
            <p>${module.productLanguages.map(language => html `
              <strong>${language}${this.mode === 'edit' ? html `<button type="button" aria-label=${this.t('general.removeLanguage', { language })} ?disabled=${module.productLanguages.length <= 1} @click=${() => this.removeLanguage(language)}>&times;</button>` : nothing}</strong>
            `)}</p>
            ${this.mode === 'edit' ? html `
              <label class="nr-general__add-language"><span>${this.t('general.addLanguage')}</span>
                <select @change=${(event) => {
            const select = event.target;
            this.addLanguage(select.value);
            select.value = '';
        }}>
                  <option value="">${this.t('general.chooseLanguage')}</option>
                  ${available.map(option => html `<option value=${option.code}>${option.name} · ${option.code}</option>`)}
                </select>
              </label>
            ` : nothing}
          </div>
        </div>
      </section>
    `;
    }
    renderDetails(module) {
        const details = Object.entries(module.details || {});
        return html `
      <section class="nr-general__details-section">
        <header><div><span class="nr-general__section-title">${this.t('general.detailsTitle')}</span><p>${this.t('general.detailsDescription')}</p></div><strong>${this.t('general.detailsCount', { count: details.length })}</strong></header>
        ${details.length ? html `
          <div class="nr-general__detail-grid">
            ${details.map(([name, detail]) => html `
              <article class="nr-general__detail-card">
                <div><code>${name}</code>${this.mode === 'edit' ? html `<button type="button" class="nr-general__remove-detail" aria-label=${this.t('general.removeDetail', { name })} @click=${() => this.removeDetail(name)}>&times;</button>` : nothing}</div>
                ${this.mode === 'edit' ? html `
                  <label>${this.t('general.detailType')}<select .value=${detail.type} @change=${(event) => this.setDetailType(name, event.target.value)}>${GENERAL_DETAIL_TYPES.map(type => html `<option value=${type}>${type}</option>`)}</select></label>
                ` : html `<span class="nr-general__detail-type">${detail.type}</span>`}
                <p>${detail.description}</p>
              </article>
            `)}
          </div>
        ` : html `<div class="nr-general__empty-section">${this.t('general.detailsEmpty')}</div>`}
        ${this.mode === 'edit' ? html `
          <div class="nr-general__add-detail">
            <label>${this.t('general.detailName')}<input type="text" .value=${this.newDetailName} placeholder="totalDoMes" @input=${(event) => { this.newDetailName = event.target.value; this.editMessage = ''; }}></label>
            <label>${this.t('general.detailType')}<select .value=${this.newDetailType} @change=${(event) => { this.newDetailType = event.target.value; }}>${GENERAL_DETAIL_TYPES.map(type => html `<option value=${type}>${type}</option>`)}</select></label>
            <button type="button" class="nr-button nr-button--secondary" @click=${this.addDetail}>${this.t('general.addDetail')}</button>
            <small>${this.t('general.detailDescriptionAutomatic')}</small>
          </div>
          ${this.editMessage ? html `<p class="nr-general__edit-message" role="alert">${this.editMessage}</p>` : nothing}
        ` : nothing}
      </section>
    `;
    }
    renderPrompt(module) {
        const invocation = this.data?.pipeline?.invocation;
        const rebuild = this.data?.pipeline?.rebuildAll;
        return html `
      <section class="nr-general__prompt">
        <h3>${this.t('general.promptTitle')}</h3>
        <blockquote>${module.sourcePrompt || this.t('general.promptEmpty')}</blockquote>
        <div class="nr-general__invocation">
          <span><small>${this.t('general.invocationModule')}</small><strong>${invocation?.module || module.moduleName}</strong></span>
          <span><small>${this.t('general.invocationFast')}</small><strong>${invocation?.fast ? this.t('general.yes') : this.t('general.no')}</strong></span>
          <span><small>${this.t('general.invocationRebuild')}</small><strong>${invocation?.rebuildAll ? this.t('general.yes') : this.t('general.no')}</strong></span>
        </div>
        ${rebuild ? html `<div class="nr-general__rebuild"><strong>${this.t('general.rebuildTitle')}</strong><span>${this.t('general.rebuildSummary', { deleted: rebuild.deleted.length, edited: rebuild.edited.length, date: this.formatDate(rebuild.at) })}</span></div>` : nothing}
      </section>
    `;
    }
    renderCostChart() {
        const byStep = this.data?.run?.cost?.byStep;
        const values = NS5_STEP_IDS.map(step => byStep?.[step] || 0);
        const max = Math.max(...values, 0);
        return html `
      <section class="nr-general__cost-section">
        <header><span class="nr-general__section-title">${this.t('general.costByStep')}</span><strong>${typeof this.data?.run?.cost?.total === 'number' ? this.t('summary.costValue', { value: this.data.run.cost.total.toFixed(4) }) : this.t('summary.costEmpty')}</strong></header>
        ${max ? html `<div class="nr-general__cost-chart">${NS5_STEP_IDS.map(step => {
            const value = byStep?.[step] || 0;
            const width = max ? Math.max((value / max) * 100, value ? 2 : 0) : 0;
            return html `<div class="nr-cost-row"><span>${this.t(`step.${step}`)}</span><div><i style=${`width:${width}%`}></i></div><strong>${this.t('general.costValue', { value: value.toFixed(4) })}</strong></div>`;
        })}</div>` : html `<div class="nr-general__empty-section">${this.t('general.costEmpty')}</div>`}
      </section>
    `;
    }
    renderAdjustments() {
        const adjustments = NS5_STEP_IDS.flatMap(step => (this.data?.pipeline?.steps[step]?.normalizations || []).map(item => ({ step, ...item })));
        const liftedEntities = this.data?.pipeline?.steps.ontology30?.liftedAggregateEntities || [];
        const liftedFields = this.data?.pipeline?.steps.ontology30?.liftedFields || [];
        return html `
      <section class="nr-general__adjustments">
        <header><span class="nr-general__section-title">${this.t('general.adjustmentsTitle')}</span><p>${this.t('general.adjustmentsDescription')}</p></header>
        ${adjustments.length || liftedEntities.length || liftedFields.length ? html `
          <div class="nr-general__adjustment-list">
            ${adjustments.map(item => html `<article><span>${this.t(`step.${item.step}`)}</span><strong>${this.t('general.normalization', { kind: item.kind })}</strong><p>${item.detail}</p></article>`)}
            ${liftedEntities.map(entity => html `<article class="is-lifted"><span>${this.t('step.ontology30')}</span><strong>${this.t('general.liftedEntity', { entity })}</strong><p>${this.t('general.liftedEntityDescription')}</p></article>`)}
            ${liftedFields.map(field => html `<article class="is-lifted"><span>${this.t('step.ontology30')}</span><strong>${this.t('general.liftedField', { entity: field.entityId })}</strong><p>${field.detail}</p></article>`)}
          </div>
        ` : html `<div class="nr-general__empty-section">${this.t('general.adjustmentsEmpty')}</div>`}
      </section>
    `;
    }
    navigate(tab) {
        this.dispatchEvent(new CustomEvent('nr-navigate', { bubbles: true, composed: true, detail: { tab } }));
    }
    renderOracle() {
        const checks = new Map((this.data?.finalizeReport?.checks || []).map(check => [check.checkId, check]));
        return html `
      <section class="nr-general__oracle">
        <header><span class="nr-general__section-title">${this.t('general.oracleTitle')}</span><p>${this.t('general.oracleDescription')}</p></header>
        <div class="nr-general__oracle-grid">
          ${ORACLE_CHECK_IDS.map(checkId => {
            const check = checks.get(checkId);
            const status = check?.status || 'pending';
            const tab = generalOracleTab(checkId);
            return html `
              <button type="button" class="nr-oracle-card nr-oracle-card--${status}" @click=${() => this.navigate(tab)}>
                <span><strong>${checkId}</strong><i>${this.t(`oracle.status.${status}`)}</i></span>
                <p>${this.t(`oracle.${checkId}`)}</p>
                <small>${check ? this.t('general.oracleCounts', { errors: check.errorCount, warnings: check.warningCount }) : this.t('general.oracleUnavailable')}</small>
                <em>${this.t('general.openTab', { tab: this.t(`tab.${tab}`) })}</em>
              </button>
            `;
        })}
        </div>
      </section>
    `;
    }
    renderEditActions() {
        if (this.mode !== 'edit')
            return nothing;
        return html `
      <div class="nr-general__edit-actions">
        <span>${this.dirty ? this.t('general.unsaved') : this.t('general.noChanges')}</span>
        <div><button type="button" class="nr-button nr-button--secondary" @click=${this.cancelEdit}>${this.t('general.cancel')}</button><button type="button" class="nr-button nr-button--primary" ?disabled=${!this.dirty} @click=${this.saveEdit}>${this.t('general.save')}</button></div>
      </div>
    `;
    }
    render() {
        const module = this.currentModule();
        if (!module)
            return nothing;
        const counts = this.data?.finalizeReport?.counts ?? {};
        const actors = this.data?.pipeline?.steps.module10?.actors?.length ?? 0;
        const issues = this.data?.validation.issues.filter(issue => issue.artifact === 'module.defs.ts' || issue.artifact === 'module') ?? this.issues;
        return html `
      <section class="nr-general" aria-label=${this.t('general.title', { module: module.title || module.moduleName })}>
        <div class="nr-general__foundation">
          ${this.renderLanguagePanel(module)}
          <div class="nr-general__metrics">${this.metric('general.actors', actors)}${this.metric('general.journeys', counts.journeys)}${this.metric('general.entities', counts.entities)}${this.metric('general.rules', counts.rules)}</div>
          ${issues.length ? html `<section class="nr-general__issues" aria-live="polite"><strong>${this.t('general.validationTitle')}</strong>${issues.map(issue => html `<p><code>${issue.path}</code> ${issue.message}</p>`)}</section>` : nothing}
          <details class="nr-general__group">
            <summary><div><strong>${this.t('general.advancedTitle')}</strong><small>${this.t('general.advancedDescription')}</small></div><span aria-hidden="true">⌄</span></summary>
            <div class="nr-general__group-content">
              ${this.renderIdentity(module)}
              ${this.renderDetails(module)}
              ${this.renderPrompt(module)}
            </div>
          </details>
          <details class="nr-general__group">
            <summary><div><strong>${this.t('general.processTitle')}</strong><small>${this.t('general.processDescription')}</small></div><span aria-hidden="true">⌄</span></summary>
            <div class="nr-general__group-content nr-general__group-content--process">
              ${this.renderProgress()}
              ${this.renderSummary()}
              ${this.renderCostChart()}
              ${this.renderAdjustments()}
              ${this.renderOracle()}
            </div>
          </details>
          ${this.renderEditActions()}
        </div>
      </section>
    `;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseGeneral102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseGeneral102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseGeneral102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseGeneral102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseGeneral102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseGeneral102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseGeneral102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseGeneral102035.prototype, "issues", void 0);
__decorate([
    state()
], NewReleaseGeneral102035.prototype, "draft", void 0);
__decorate([
    state()
], NewReleaseGeneral102035.prototype, "newDetailName", void 0);
__decorate([
    state()
], NewReleaseGeneral102035.prototype, "newDetailType", void 0);
__decorate([
    state()
], NewReleaseGeneral102035.prototype, "editMessage", void 0);
NewReleaseGeneral102035 = __decorate([
    customElement('new-release--widgets--general-102035')
], NewReleaseGeneral102035);
export { NewReleaseGeneral102035 };
