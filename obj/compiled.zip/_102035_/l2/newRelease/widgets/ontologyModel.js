/// <mls fileReference="_102035_/l2/newRelease/widgets/ontologyModel.ts" enhancement="_blank" />
export const ONTOLOGY_FIELD_TYPES = [
    'uuid', 'string', 'text', 'number', 'integer', 'boolean', 'money', 'date', 'datetime', 'json',
];
export const ONTOLOGY_DETAIL_NAME = /^[a-z][A-Za-z0-9]*$/u;
export const ONTOLOGY_ENUM_VALUE = /^[a-z][A-Za-z0-9]*$/u;
const KINDS = ['core', 'event', 'supporting', 'mdm', 'valueObject'];
export function ontologyFieldCounts(entity) {
    const namespace = entity.fields.length;
    const base = entity.fieldsBase?.length || 0;
    return { namespace, base, total: namespace + base };
}
export function ontologyResolvableFields(entity) {
    return [...entity.fields, ...(entity.fieldsBase || [])];
}
export function ontologyCardinality(type) {
    return { oneToOne: '1:1', oneToMany: '1:N', manyToOne: 'N:1', manyToMany: 'N:N' }[type] || type;
}
export function buildOntologyGraph(index, entities, colors) {
    const usedKinds = KINDS.filter(kind => entities.some(entity => entity.kind === kind));
    const categories = usedKinds.map((kind, category) => ({
        name: kind,
        itemStyle: { color: colors[category % Math.max(colors.length, 1)] || 'currentColor' },
    }));
    const categoryOf = (kind) => Math.max(0, usedKinds.indexOf(kind));
    const nodes = entities.map(entity => {
        const category = categoryOf(entity.kind);
        const fieldCounts = ontologyFieldCounts(entity);
        return {
            id: entity.entityId,
            name: entity.entityId,
            title: entity.title,
            category,
            symbolSize: Math.min(78, 34 + fieldCounts.total * 2 + Object.keys(entity.details || {}).length),
            value: entity.description,
            itemStyle: { color: categories[category]?.itemStyle.color || colors[0] || 'currentColor' },
            namespaceFields: entity.fields.map(field => field.fieldId),
            baseFields: (entity.fieldsBase || []).map(field => field.fieldId),
            displayField: entity.displayField,
        };
    });
    const persistenceStyle = (mode) => {
        if (mode === 'crossStoreReference' || mode === 'externalReference')
            return 'dashed';
        if (mode === 'mdmRelationship')
            return 'dotted';
        return 'solid';
    };
    const links = (index?.relationships || []).map(relationship => ({
        id: relationship.relationshipId,
        source: relationship.fromEntity,
        target: relationship.toEntity,
        value: ontologyCardinality(relationship.type),
        lineStyle: {
            type: persistenceStyle(relationship.persistence.mode),
            width: relationship.required ? 2.2 : 1.35,
            opacity: relationship.required ? .78 : .5,
        },
    }));
    return { nodes, links, categories };
}
export function sanitizeOntologyConstraints(type, constraints) {
    if (!constraints)
        return undefined;
    const next = {};
    if (type === 'number' || type === 'integer' || type === 'money') {
        if (typeof constraints.min === 'number')
            next.min = constraints.min;
        if (typeof constraints.max === 'number')
            next.max = constraints.max;
    }
    if (type === 'number' || type === 'money') {
        if (typeof constraints.precision === 'number')
            next.precision = constraints.precision;
    }
    if (type === 'string' || type === 'text') {
        if (typeof constraints.maxLength === 'number')
            next.maxLength = constraints.maxLength;
    }
    return Object.keys(next).length ? next : undefined;
}
export function updateOntologyField(entity, fieldId, patch) {
    return {
        ...entity,
        fields: entity.fields.map(field => {
            if (field.fieldId !== fieldId)
                return field;
            const next = { ...field, ...patch };
            if (patch.type)
                next.constraints = sanitizeOntologyConstraints(patch.type, next.constraints);
            if (next.type !== 'string')
                delete next.enum;
            if (!next.unique)
                delete next.unique;
            if (!next.constraints)
                delete next.constraints;
            return next;
        }),
    };
}
export function removeOntologyState(entity, state) {
    return {
        ...entity,
        lifecycleStates: entity.lifecycleStates.filter(item => item.state !== state),
        transitions: entity.transitions.filter(item => item.to !== state && !item.from.includes(state)),
    };
}
export function updateOntologyRelationship(index, relationshipId, patch) {
    return {
        ...index,
        relationships: index.relationships.map(relationship => relationship.relationshipId === relationshipId ? { ...relationship, ...patch } : relationship),
    };
}
export function ontologyEntityIssues(issues, entityId) {
    const artifact = `ontology/${entityId}.defs.ts`;
    return issues.filter(issue => issue.artifact === artifact || issue.path.startsWith(`${entityId}.`));
}
export function ontologyEntityPath(entityId) {
    return `ontology/${entityId}.defs.ts`;
}
