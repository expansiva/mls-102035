var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102035_/l2/newRelease/widgets/index.ts" enhancement="_102027_/l2/enhancementLit" />
import { ensureUserId, getUserId } from '/_102025_/l2/collabMessagesHelper.js';
import { addOrUpdateTask } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { dispatchThreadOpen } from '/_102025_/l2/collabMessagesEvents.js';
import { applyDirectLanguages, hasPendingLanguages } from '/_102035_/l2/newRelease/helpers/directLanguages.js';
import { resolveModuleThread } from '/_102035_/l2/newRelease/helpers/moduleThread.js';
import { summarizeNewReleaseRequest, runNewReleaseRequest, newReleaseTaskCost } from '/_102035_/l2/newRelease/helpers/agentCommandRunner.js';
import { html, nothing, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { NEW_RELEASE_CONTEXT_EVENT, NEW_RELEASE_IMPLEMENTATION_STATE_EVENT, NEW_RELEASE_TOBE_UPDATED_EVENT, historicalReleaseId, } from '/_102035_/l2/newRelease/helpers/context.js';
import { readNs5Module, } from '/_102035_/l2/newRelease/helpers/l4Reader.js';
import { createNewReleaseTranslator, loadNewReleaseMessages, observeNewReleaseLanguage, } from '/_102035_/l2/newRelease/helpers/i18n.js';
import { sealL4Revision, readChangeRequest, readActiveL4Change } from '/_102035_/l2/solution/candidate/moduleRevision.js';
import { readL4Implementation } from '/_102035_/l2/solution/candidate/moduleImplementation.js';
import { bindStructuredEditsRequest, ChangeRequestDrafts, contextStillCurrent, reuseHistoricalRelease, saveChangeRequest } from '/_102035_/l2/newRelease/helpers/revisionSelection.js';
import { discardTobe, saveTobeArtifact, NewReleaseSaveValidationError } from '/_102035_/l2/newRelease/tobe.js';
import { visibleDiffs } from '/_102035_/l2/newRelease/helpers/visibleDiffs.js';
import { readChangeOrigins, originForChange } from '/_102035_/l2/newRelease/helpers/changeOrigins.js';
import { NEW_RELEASE_CHANGED_EVENT, NEW_RELEASE_GENERAL_INDICATORS_EDIT_ID, tabForArtifactPath, } from '/_102035_/l2/newRelease/editContract.js';
import { textTree, filterTextTree, hasDraftChanges } from '/_102035_/l2/newRelease/widgets/shared/commonModel.js';
import '/_102035_/l2/newRelease/widgets/general/general.js';
import '/_102035_/l2/newRelease/widgets/access/access.js';
import '/_102035_/l2/newRelease/widgets/journeys/journeys.js';
import '/_102035_/l2/newRelease/widgets/ontology/ontology.js';
import '/_102035_/l2/newRelease/widgets/rules/rules.js';
import '/_102035_/l2/newRelease/widgets/workflows/workflows.js';
import '/_102035_/l2/newRelease/widgets/integration/integration.js';
import '/_102035_/l2/newRelease/widgets/review/review.js';
const TABS = ['general', 'journeys', 'ontology', 'access', 'rules', 'workflows', 'integration', 'review'];
const REQUEST_TIMEOUT_MS = 10 * 60 * 1000;
let NewReleaseIndex102035 = class NewReleaseIndex102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--index-102035 {
  display: block;
  min-width: 0;
  min-height: 100%;
  color: var(--text-default, #2f3a48);
}
new-release--widgets--index-102035 * {
  box-sizing: border-box;
}
new-release--widgets--index-102035 .nr-index {
  --nr-space-1: 0.25rem;
  --nr-space-2: 0.5rem;
  --nr-space-3: 0.75rem;
  --nr-space-4: 1rem;
  min-height: 100%;
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 1.15rem;
  background: var(--page-bg, #eef1f5);
  box-shadow: 0 1.25rem 3rem rgba(15, 23, 42, 0.08);
  font-family: var(--font-family-sans, Inter, system-ui, sans-serif);
  line-height: 1.45;
  container-type: inline-size;
  container-name: nr-index;
}
new-release--widgets--index-102035 .nr-index :where(button, input, select, textarea, summary, [tabindex]):focus-visible {
  outline: 0.15rem solid var(--focus-ring, #1273d4);
  outline-offset: 0.12rem;
}
new-release--widgets--index-102035 .nr-index__tabs {
  position: sticky;
  z-index: 3;
  top: 0;
  display: grid;
  grid-template-columns: repeat(8, minmax(0, 1fr));
  align-items: stretch;
  gap: 0.18rem;
  padding: 0.55rem 1.15rem 0;
  overflow-x: hidden;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: color-mix(in srgb, var(--surface-bg, #fff) 96%, transparent);
  backdrop-filter: blur(0.7rem);
}
new-release--widgets--index-102035 .nr-index__tabs button {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  min-width: 0;
  width: 100%;
  height: 100%;
  gap: 0.22rem;
  padding: 0.55rem 0.2rem 0.5rem;
  border: 0;
  outline: none;
  background: transparent;
  color: var(--text-muted, #5d6b7e);
  cursor: pointer;
  font: inherit;
  font-size: 0.7rem;
  font-weight: 700;
}
new-release--widgets--index-102035 .nr-index__tabs button::after {
  content: '';
  position: absolute;
  right: 0.2rem;
  bottom: -1px;
  left: 0.2rem;
  height: 0.18rem;
  border-radius: 0.2rem 0.2rem 0 0;
  background: transparent;
}
new-release--widgets--index-102035 .nr-tab__icon {
  position: relative;
  display: grid;
  flex: none;
  width: 1.15rem;
  height: 1.15rem;
  place-items: center;
}
new-release--widgets--index-102035 .nr-tab__icon svg {
  width: 100%;
  height: 100%;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 1.8;
  transition: fill 0.16s ease, color 0.16s ease;
}
new-release--widgets--index-102035 .nr-tab__label {
  display: block;
  min-width: 0;
  max-width: 100%;
  overflow: visible;
  color: inherit;
  font: inherit;
  letter-spacing: -0.01em;
  line-height: 1.15;
  text-align: center;
  overflow-wrap: anywhere;
  white-space: normal;
}
new-release--widgets--index-102035 .nr-index__tabs button:hover {
  color: var(--text-strong, #111827);
}
new-release--widgets--index-102035 .nr-index__tabs button:focus-visible {
  border-radius: 0.45rem;
  outline-offset: -0.18rem;
}
new-release--widgets--index-102035 .nr-index__tabs button.is-active {
  color: var(--selected-text, #0d5296);
}
new-release--widgets--index-102035 .nr-index__tabs button.is-active::after {
  background: var(--selected-border, #1273d4);
}
new-release--widgets--index-102035 .nr-index__tabs button.is-active .nr-tab__icon svg {
  fill: color-mix(in srgb, currentColor 28%, transparent);
}
new-release--widgets--index-102035 .nr-index__implementation-lock {
  margin: 0.7rem 1.15rem;
  padding: 0.75rem 1rem;
  border: 1px solid var(--border-default, #46546d);
  border-radius: 0.7rem;
  background: var(--surface-alt-bg, #1c2330);
  color: var(--text-default, #d0d8e8);
  font-size: 0.78rem;
}
new-release--widgets--index-102035 .nr-index__request {
  margin: 0.7rem 1.15rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.7rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--index-102035 .nr-index__request summary {
  display: flex;
  justify-content: space-between;
  gap: 0.7rem;
  padding: 0.65rem 0.85rem;
  cursor: pointer;
}
new-release--widgets--index-102035 .nr-index__request summary strong {
  font-size: 0.76rem;
}
new-release--widgets--index-102035 .nr-index__request summary span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--index-102035 .nr-index__request-body {
  display: grid;
  gap: 0.42rem;
  padding: 0 0.85rem 0.8rem;
}
new-release--widgets--index-102035 .nr-index__request-body p,
new-release--widgets--index-102035 .nr-index__request--history p {
  margin: 0;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
}
new-release--widgets--index-102035 .nr-index__base-warning {
  margin: -0.35rem 1.15rem 0.65rem;
  color: var(--status-warning-text, #775700);
  font-size: 0.68rem;
}
new-release--widgets--index-102035 .nr-index__changes-summary {
  margin: 0.65rem 1.15rem;
  padding: 0.25rem 0;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
  overflow-wrap: anywhere;
}
new-release--widgets--index-102035 .nr-index__request-body label {
  font-size: 0.7rem;
  font-weight: 700;
}
new-release--widgets--index-102035 .nr-index__request textarea {
  width: 100%;
  min-height: 4rem;
  resize: vertical;
  padding: 0.5rem 0.6rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.4rem;
  background: var(--surface-bg, #fff);
  color: inherit;
  font: inherit;
  font-size: 0.75rem;
}
new-release--widgets--index-102035 .nr-index__request-actions {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.45rem;
}
new-release--widgets--index-102035 .nr-index__request-actions small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
}
new-release--widgets--index-102035 .nr-index__request button {
  padding: 0.42rem 0.6rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.4rem;
  background: var(--surface-bg, #fff);
  color: inherit;
  cursor: pointer;
  font: inherit;
  font-size: 0.7rem;
}
new-release--widgets--index-102035 .nr-index__request button:disabled {
  cursor: not-allowed;
  opacity: 0.6;
}
new-release--widgets--index-102035 .nr-index__request button.nr-request-action:not(:disabled) {
  border-color: var(--button-primary-bg, #1273d4);
  background: var(--button-primary-bg, #1273d4);
  color: var(--button-primary-text, #fff);
  font-weight: 750;
}
new-release--widgets--index-102035 .nr-index__request .nr-index__request-error {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--index-102035 .nr-index__request-failure {
  padding: 0.6rem;
  border: 1px solid var(--status-error-text, #ab2328);
  border-radius: 0.4rem;
}
new-release--widgets--index-102035 .nr-index__request-failure pre {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  margin: 0 0 0.5rem;
}
new-release--widgets--index-102035 .nr-index__request-task collab-messages-task-102025 {
  display: block;
  max-width: 100%;
}
new-release--widgets--index-102035 .nr-index__request--history {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.8rem;
  padding: 0.65rem 0.85rem;
}
new-release--widgets--index-102035 .nr-index__request--history strong {
  font-size: 0.74rem;
}
new-release--widgets--index-102035 .nr-index__request--history button {
  flex: none;
}
new-release--widgets--index-102035 .nr-index__request-progress {
  position: fixed;
  inset: 0;
  z-index: 2147483640;
  display: grid;
  place-items: center;
  padding: 1rem;
  background: rgba(5, 13, 25, 0.78);
  backdrop-filter: blur(0.35rem);
}
new-release--widgets--index-102035 .nr-index__request-progress-card {
  display: grid;
  justify-items: center;
  gap: 0.8rem;
  width: min(100%, 28rem);
  padding: 2rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 1rem;
  background: var(--surface-bg, #fff);
  box-shadow: 0 1.5rem 4rem rgba(0, 0, 0, 0.3);
  text-align: center;
}
new-release--widgets--index-102035 .nr-index__request-progress-card strong {
  font-size: 1.1rem;
}
new-release--widgets--index-102035 .nr-index__request-progress-card p {
  margin: 0;
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--index-102035 .nr-index__request-progress-card small {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--index-102035 .nr-index__request-progress-card progress {
  width: 100%;
  height: 0.65rem;
  accent-color: var(--button-primary-bg, #1273d4);
}
new-release--widgets--index-102035 .nr-index__request-progress-icon {
  display: grid;
  width: 2.75rem;
  height: 2.75rem;
  place-items: center;
  color: var(--button-primary-bg, #1273d4);
}
new-release--widgets--index-102035 .nr-index__request-progress-icon svg {
  width: 100%;
  height: 100%;
  fill: none;
  stroke: currentColor;
  stroke-width: 2.5;
  stroke-linecap: round;
  animation: nr-request-spin 1.2s linear infinite;
}
@keyframes nr-request-spin {
  to {
    transform: rotate(360deg);
  }
}
@media (prefers-reduced-motion: reduce) {
  new-release--widgets--index-102035 .nr-index__request-progress-icon svg {
    animation: none;
  }
}
new-release--widgets--index-102035 .nr-index__revision-content {
  min-width: 0;
  margin: 0;
  padding: 0;
  border: 0;
}
new-release--widgets--index-102035 .nr-tab__source {
  position: absolute;
  top: -0.12rem;
  right: -0.22rem;
  width: 0.42rem;
  height: 0.42rem;
  border: 0.1rem solid var(--surface-bg, #fff);
  border-radius: 50%;
  background: var(--status-warning-text, #9a6700);
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--status-warning-text, #9a6700) 35%, transparent);
}
new-release--widgets--index-102035 .nr-item__changed {
  display: inline-block;
  flex: none;
  width: 0.48rem;
  height: 0.48rem;
  margin-inline: 0.3rem;
  border: 0.1rem solid var(--surface-bg, #fff);
  border-radius: 50%;
  background: var(--status-warning-text, #9a6700);
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--status-warning-text, #9a6700) 35%, transparent);
  vertical-align: middle;
}
@container nr-index (max-width: 419px) {
  new-release--widgets--index-102035 .nr-index__request--history {
    align-items: stretch;
    flex-direction: column;
  }
  new-release--widgets--index-102035 .nr-index__tabs {
    display: flex;
    gap: 0.1rem;
  }
  new-release--widgets--index-102035 .nr-index__tabs button {
    flex: 0 0 2rem;
    width: 2rem;
    min-width: 2rem;
    padding: 0.5rem 0.12rem 0.42rem;
  }
  new-release--widgets--index-102035 .nr-index__tabs button.is-active {
    flex: 1 1 auto;
    width: auto;
    min-width: 6.5rem;
  }
  new-release--widgets--index-102035 .nr-index__tabs button:not(.is-active) .nr-tab__label {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0;
  }
}
new-release--widgets--index-102035 .nr-index__tobe {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.65rem 1.25rem;
  border-bottom: 1px solid color-mix(in srgb, var(--status-info-text, #0b5497) 18%, transparent);
  background: var(--status-info-bg, #eaf3fc);
}
new-release--widgets--index-102035 .nr-index__tobe-main {
  display: flex;
  align-items: baseline;
  min-width: 0;
  gap: 0.7rem;
}
new-release--widgets--index-102035 .nr-index__tobe-main strong {
  color: var(--status-info-text, #0b5497);
  font-size: 0.72rem;
}
new-release--widgets--index-102035 .nr-index__tobe-main span {
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--index-102035 .nr-index__tobe-health {
  display: flex;
  flex: none;
  gap: 0.38rem;
}
new-release--widgets--index-102035 .nr-index__tobe-health span {
  padding: 0.2rem 0.42rem;
  border-radius: 999px;
  background: color-mix(in srgb, var(--surface-bg, #fff) 72%, transparent);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
  font-weight: 700;
}
new-release--widgets--index-102035 .nr-index__tobe-health .has-errors {
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--index-102035 .nr-index__tobe-health .has-warnings {
  background: var(--status-warning-bg, #fcf2d7);
  color: var(--status-warning-text, #775700);
}
new-release--widgets--index-102035 .nr-index__stale {
  display: grid;
  grid-template-columns: minmax(10rem, 0.8fr) minmax(14rem, 1.2fr);
  gap: 0.8rem 1.2rem;
  margin: 0.85rem 1.25rem 0;
  padding: 0.85rem 1rem;
  border: 1px solid color-mix(in srgb, var(--status-warning-text, #775700) 28%, transparent);
  border-radius: 0.78rem;
  background: var(--status-warning-bg, #fcf2d7);
  color: var(--status-warning-text, #775700);
}
new-release--widgets--index-102035 .nr-index__stale strong {
  font-size: 0.73rem;
}
new-release--widgets--index-102035 .nr-index__stale p {
  margin: 0.28rem 0 0;
  color: inherit;
  font-size: 0.68rem;
  line-height: 1.45;
}
new-release--widgets--index-102035 .nr-index__stale-list {
  display: grid;
  gap: 0.38rem;
}
new-release--widgets--index-102035 .nr-index__stale-list > span {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.7rem;
}
new-release--widgets--index-102035 .nr-index__stale code {
  overflow: hidden;
  font-size: 0.64rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--index-102035 .nr-index__stale button {
  padding: 0.38rem 0.58rem;
  border: 1px solid currentColor;
  border-radius: 0.5rem;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font: inherit;
  font-size: 0.64rem;
  font-weight: 750;
}
new-release--widgets--index-102035 .nr-index__stale button:focus-visible {
  outline: 0.15rem solid var(--focus-ring, #7ab8f5);
  outline-offset: 0.12rem;
}
new-release--widgets--index-102035 .nr-index__content {
  min-height: 17rem;
}
new-release--widgets--index-102035 .nr-index__content:focus-visible {
  outline-offset: -0.2rem;
}
new-release--widgets--index-102035 .nr-index__placeholder,
new-release--widgets--index-102035 .nr-index__empty {
  display: grid;
  place-items: center;
  align-content: center;
  min-height: 18rem;
  padding: 2rem;
  text-align: center;
}
new-release--widgets--index-102035 .nr-index__placeholder-mark,
new-release--widgets--index-102035 .nr-index__empty > span {
  display: block;
  width: 3.2rem;
  height: 0.32rem;
  margin: 0 auto 1rem;
  border-radius: 999px;
  background: linear-gradient(90deg, var(--chart-series-1, #1273d4), var(--chart-series-3, #7c3aed));
}
new-release--widgets--index-102035 .nr-index__placeholder h2,
new-release--widgets--index-102035 .nr-index__empty h2 {
  margin: 0;
  color: var(--text-strong, #111827);
  font-size: 1.1rem;
}
new-release--widgets--index-102035 .nr-index__placeholder p,
new-release--widgets--index-102035 .nr-index__empty p {
  max-width: 34rem;
  margin: 0.55rem auto 0;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--index-102035 .nr-index__loading {
  display: grid;
  gap: 0.7rem;
  padding: 1.4rem 1.25rem;
}
new-release--widgets--index-102035 .nr-index__loading span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.75rem;
}
new-release--widgets--index-102035 .nr-index__loading div {
  height: 3.5rem;
  border-radius: 0.75rem;
  background: linear-gradient(90deg, var(--surface-alt-bg, #f5f7fa), var(--surface-bg, #fff), var(--surface-alt-bg, #f5f7fa));
  background-size: 240% 100%;
  animation: nr-shimmer 1.5s linear infinite;
}
new-release--widgets--index-102035 .nr-index__errors {
  margin: 0.9rem 1.25rem 0;
  padding: 0.85rem 1rem;
  border: 1px solid color-mix(in srgb, var(--status-error-text, #ab2328) 24%, transparent);
  border-radius: 0.75rem;
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
  font-size: 0.75rem;
}
new-release--widgets--index-102035 .nr-index__errors p {
  margin: 0.3rem 0 0;
}
new-release--widgets--index-102035 .nr-index__log {
  margin: 0 1.25rem 1.15rem;
  padding: 0.85rem 1rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.8rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--index-102035 .nr-index__log h2 {
  margin: 0 0 0.6rem;
  color: var(--text-strong, #111827);
  font-size: 0.9rem;
}
new-release--widgets--index-102035 .nr-index__log > p {
  margin: 0;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.74rem;
}
new-release--widgets--index-102035 .nr-index__log ul {
  display: grid;
  gap: 0.5rem;
  margin: 0;
  padding: 0;
  list-style: none;
}
new-release--widgets--index-102035 .nr-index__log li {
  padding: 0.6rem 0.75rem;
  border-left: 0.2rem solid var(--status-warning-text, #775700);
  border-radius: 0.35rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--index-102035 .nr-index__previous {
  margin-top: 0.6rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.74rem;
}
new-release--widgets--index-102035 .nr-index__previous summary {
  cursor: pointer;
  margin-bottom: 0.5rem;
}
new-release--widgets--index-102035 .nr-index__previous li {
  border-left-color: var(--border-subtle, #e4e9f0);
}
new-release--widgets--index-102035 .nr-index__log li.is-error {
  border-left-color: var(--status-error-text, #ab2328);
}
new-release--widgets--index-102035 .nr-index__log li > div {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem 0.65rem;
  align-items: baseline;
}
new-release--widgets--index-102035 .nr-index__log strong {
  color: var(--text-strong, #111827);
  font-size: 0.7rem;
}
new-release--widgets--index-102035 .nr-index__log code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.65rem;
  overflow-wrap: anywhere;
}
new-release--widgets--index-102035 .nr-index__log li p {
  margin: 0.28rem 0 0;
  color: var(--text-default, #2f3a48);
  font-size: 0.74rem;
  line-height: 1.45;
}
new-release--widgets--index-102035 .nr-index__diff {
  margin: 0.85rem 1.25rem 1.15rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.8rem;
  background: var(--surface-bg, #fff);
  overflow: hidden;
}
new-release--widgets--index-102035 .nr-index__diff--plain {
  margin: 0.5rem 0.9rem;
  padding: 0.35rem 0.25rem;
  border: 0;
  border-radius: 0;
  background: transparent;
  overflow: visible;
  font-size: 12px;
}
new-release--widgets--index-102035 .nr-index__diff.nr-index__diff--plain > summary {
  display: list-item;
  padding: 0.25rem 0;
  font-size: 12px;
  font-weight: 400;
}
new-release--widgets--index-102035 .nr-index__diff > summary {
  padding: 0.72rem 0.9rem;
  color: var(--text-strong, #111827);
  cursor: pointer;
  font-size: 0.72rem;
  font-weight: 760;
}
new-release--widgets--index-102035 .nr-index__diff section {
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--index-102035 .nr-index__diff section > header {
  display: flex;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.55rem 0.9rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--index-102035 .nr-index__diff section > header code {
  color: var(--link-text, #0f62b8);
  font-size: 0.66rem;
  font-weight: 750;
}
new-release--widgets--index-102035 .nr-index__diff section > header > div {
  display: flex;
  align-items: center;
  gap: 0.65rem;
}
new-release--widgets--index-102035 .nr-index__diff section > header span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
}
new-release--widgets--index-102035 .nr-index__diff section > header button {
  min-height: 2rem;
  padding: 0.4rem 0.7rem;
  border: 1px solid color-mix(in srgb, var(--status-error-text, #ab2328) 34%, transparent);
  border-radius: 0.45rem;
  background: transparent;
  color: var(--status-error-text, #ab2328);
  cursor: pointer;
  font-size: 0.62rem;
  font-weight: 750;
}
new-release--widgets--index-102035 .nr-index__diff section > header button:focus-visible {
  outline: 2px solid var(--focus-ring, #0f62b8);
  outline-offset: 2px;
}
new-release--widgets--index-102035 .nr-index__diff section > header button:disabled {
  cursor: not-allowed;
  opacity: 0.58;
}
new-release--widgets--index-102035 .nr-index__diff-lines {
  display: grid;
}
new-release--widgets--index-102035 .nr-index__diff-lines article {
  display: grid;
  grid-template-columns: minmax(8rem, 0.8fr) minmax(0, 1fr) auto minmax(0, 1fr);
  align-items: center;
  gap: 0.5rem;
  padding: 0.52rem 0.9rem;
  border-top: 1px solid color-mix(in srgb, var(--border-subtle, #e4e9f0) 65%, transparent);
  font-size: 0.64rem;
}
new-release--widgets--index-102035 .nr-index__diff-lines code {
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--index-102035 .nr-index__diff-lines span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--index-102035 .nr-index__diff-lines .is-before {
  color: var(--status-error-text, #ab2328);
  text-decoration: line-through;
}
new-release--widgets--index-102035 .nr-index__diff-lines .is-after {
  color: var(--status-success-text, #25640e);
  font-weight: 700;
}
new-release--widgets--index-102035 .nr-index__diff-detail {
  grid-column: 1 / -1;
  min-width: 0;
}
new-release--widgets--index-102035 .nr-index__diff-detail > summary {
  width: fit-content;
  color: var(--link-text, #0f62b8);
  cursor: pointer;
}
new-release--widgets--index-102035 .nr-index__diff-detail > div {
  margin-top: 0.55rem;
}
new-release--widgets--index-102035 .nr-index__diff-detail > p {
  margin: 0.5rem 0;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
new-release--widgets--index-102035 .nr-index__diff-detail > button {
  margin: 0.2rem 0;
  padding: 0.25rem 0.45rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.35rem;
  background: var(--surface-bg, #fff);
  color: var(--link-text, #0f62b8);
  cursor: pointer;
}
new-release--widgets--index-102035 .nr-index__diff-detail pre {
  margin: 0.2rem 0;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
@keyframes nr-shimmer {
  to {
    background-position: -240% 0;
  }
}
@media (max-width: 780px) {
  new-release--widgets--index-102035 .nr-index__tabs {
    padding-inline: 0.65rem;
  }
  new-release--widgets--index-102035 .nr-index__tobe {
    align-items: flex-start;
    flex-direction: column;
    padding-inline: 0.9rem;
  }
  new-release--widgets--index-102035 .nr-index__stale {
    grid-template-columns: 1fr;
    margin-inline: 0.85rem;
  }
  new-release--widgets--index-102035 .nr-index__diff {
    margin-inline: 0.85rem;
  }
  new-release--widgets--index-102035 .nr-index__diff-lines article {
    grid-template-columns: 1fr;
  }
}
@media (prefers-reduced-motion: reduce) {
  new-release--widgets--index-102035 .nr-index *,
  new-release--widgets--index-102035 .nr-index *::before,
  new-release--widgets--index-102035 .nr-index *::after {
    scroll-behavior: auto !important;
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
new-release--widgets--index-102035 .nr-index {
  color-scheme: dark;
  --page-bg: #0d1117;
  --surface-bg: #161b22;
  --surface-alt-bg: #1c2330;
  --text-default: #d8dee9;
  --text-strong: #f0f4fc;
  --text-muted: #98a6ba;
  --border-subtle: #30394a;
  --selected-text: #a8c7ff;
  --selected-border: #79aaff;
  --focus-ring: #9ec5ff;
  --link-text: #9ec5ff;
  --status-error-bg: #371d28;
  --status-error-text: #ffadb5;
  --status-warning-bg: #342c1d;
  --status-warning-text: #e7c988;
  --status-info-bg: #17283c;
  --status-info-text: #a3cbff;
  --status-success-text: #9bd4aa;
  color: var(--text-default);
}
new-release--widgets--index-102035 .nr-common__toolbar {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.6rem;
  padding: 0.8rem 1.2rem;
  border-bottom: 1px solid var(--border-subtle);
}
new-release--widgets--index-102035 .nr-common__toolbar > div {
  display: flex;
  gap: 0.2rem;
}
new-release--widgets--index-102035 .nr-common__toolbar button,
new-release--widgets--index-102035 .nr-common__toolbar summary {
  min-height: 2.25rem;
  padding: 0.45rem 0.7rem;
  color: var(--text-default);
  background: var(--surface-bg);
  border: 1px solid var(--border-subtle);
  border-radius: 0.5rem;
  cursor: pointer;
  font: inherit;
  font-size: 0.75rem;
}
new-release--widgets--index-102035 .nr-common__toolbar button[aria-pressed='true'] {
  color: var(--selected-text);
  border-color: var(--selected-border);
}
new-release--widgets--index-102035 .nr-common__toolbar button:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}
new-release--widgets--index-102035 .nr-common__hint {
  position: relative;
  margin-left: auto;
}
new-release--widgets--index-102035 .nr-common__hint summary {
  list-style: none;
}
new-release--widgets--index-102035 .nr-common__hint p {
  position: absolute;
  z-index: 5;
  top: 100%;
  right: 0;
  width: min(18rem, 70vw);
  padding: 0.8rem;
  border: 1px solid var(--border-subtle);
  border-radius: 0.5rem;
  background: var(--surface-bg);
  color: var(--text-default);
  box-shadow: 0 0.5rem 1.5rem #0008;
  font-size: 0.8rem;
}
new-release--widgets--index-102035 .nr-common__hint:focus-within p {
  outline: 1px solid var(--focus-ring);
}
new-release--widgets--index-102035 .nr-common__graph {
  overflow: auto;
  max-width: 100%;
}
new-release--widgets--index-102035 .nr-common__graph[hidden] {
  display: none;
}
new-release--widgets--index-102035 .nr-common__text {
  padding: 1rem;
  display: flex;
  flex-wrap: wrap;
  gap: 0.8rem;
}
new-release--widgets--index-102035 .nr-common__text label {
  display: grid;
  gap: 0.3rem;
  font-size: 0.8rem;
}
new-release--widgets--index-102035 .nr-common__text input,
new-release--widgets--index-102035 .nr-common__text select {
  padding: 0.55rem;
  border: 1px solid var(--border-subtle);
  border-radius: 0.4rem;
  color: var(--text-default);
  background: var(--surface-bg);
  max-width: 100%;
}
new-release--widgets--index-102035 .nr-common__text > ul {
  flex-basis: 100%;
  padding-left: 0;
}
new-release--widgets--index-102035 .nr-common__text ul {
  list-style: none;
  margin: 0;
  padding-left: 1rem;
}
new-release--widgets--index-102035 .nr-common__text li {
  padding: 0.35rem 0;
  overflow-wrap: anywhere;
}
new-release--widgets--index-102035 .nr-common__text li > strong {
  font-size: 0.8rem;
  color: var(--text-muted);
  margin-right: 0.6rem;
}
new-release--widgets--index-102035 .nr-common__text li > span {
  white-space: pre-wrap;
  font-size: 0.85rem;
}
new-release--widgets--index-102035 .nr-common__text summary {
  padding: 0.35rem 0;
  cursor: pointer;
  color: var(--selected-text);
}
new-release--widgets--index-102035 .nr-common__text .nr-common__tree-select {
  appearance: none;
  border: 0;
  border-radius: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  padding: 0;
  text-align: left;
  cursor: pointer;
}
new-release--widgets--index-102035 .nr-common__text .nr-common__tree-select:hover {
  text-decoration: underline;
}
new-release--widgets--index-102035 .nr-common__text .nr-common__tree-select:focus-visible {
  outline: 2px solid var(--focus-ring);
  outline-offset: 3px;
}
new-release--widgets--index-102035 .nr-common__text details > ul > li:first-child > .nr-common__tree-select {
  color: var(--link-text, #0f62b8);
  font-weight: 700;
}
new-release--widgets--index-102035:has(new-release--widgets--rules-102035) .nr-common__text > ul > li > details > ul {
  max-height: 30rem;
  overflow-y: auto;
}
new-release--widgets--index-102035:has(new-release--widgets--rules-102035) .nr-common__text > ul > li > details > ul > li {
  height: 3rem;
  overflow: hidden;
  padding: 0.35rem 0;
}
new-release--widgets--index-102035:has(new-release--widgets--rules-102035) .nr-common__text > ul > li > details > ul .nr-common__tree-select {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  width: 100%;
  height: 100%;
}
new-release--widgets--index-102035:has(new-release--widgets--rules-102035) .nr-common__text > ul > li > details > ul .nr-common__tree-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--index-102035:has(new-release--widgets--rules-102035) .nr-common__text > ul > li > details > ul .nr-common__tree-suffix {
  flex: 0 0 auto;
}
new-release--widgets--index-102035:has(new-release--widgets--rules-102035) .nr-common__text > ul > li > details > ul li > span {
  display: none;
}
new-release--widgets--index-102035 pre {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  max-width: 100%;
}
new-release--widgets--index-102035 .is-primary:not(:disabled) {
  border-color: var(--button-primary-bg, #1273d4);
  background: var(--button-primary-bg, #1273d4);
  color: var(--button-primary-text, #fff);
}
new-release--widgets--index-102035 .nr-index input[readonly] {
  appearance: none;
  border-color: transparent;
  background: transparent;
  box-shadow: none;
  color: var(--text-default, #2f3a48);
  font-weight: 600;
  cursor: text;
}
new-release--widgets--index-102035 .nr-index__diff-actions {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.5rem;
  padding: 0.5rem 0.9rem 0.8rem;
}
new-release--widgets--index-102035 .nr-index__diff-actions button {
  min-height: 2.25rem;
  padding: 0.45rem 0.7rem;
  border: 1px solid var(--status-error-text, #ab2328);
  border-radius: 0.5rem;
  background: transparent;
  color: var(--status-error-text, #ab2328);
  cursor: pointer;
  font: inherit;
  font-size: 0.75rem;
}
new-release--widgets--index-102035 .nr-index__diff-actions .nr-index__copy-button {
  border-color: var(--button-primary-bg, #1273d4);
  color: var(--link-text, #8fb9ff);
}
new-release--widgets--index-102035 .nr-index__diff-actions span {
  color: var(--text-muted, #92a0b8);
  font-size: 0.72rem;
}
new-release--widgets--index-102035 .nr-index__diff-actions button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.activeTab = 'general';
        this.loading = true;
        this.changing = false;
        this.implementationActive = false;
        this.mutationError = '';
        this.languagePending = false;
        this.requestText = '';
        this.savedRequest = '';
        this.requestBusy = false;
        this.requestTimedOut = false;
        this.requestElapsedSeconds = 0;
        this.requestStartedAt = 0;
        this.requestError = '';
        this.identityError = 'pending';
        this.requestResult = '';
        this.requestFileStates = [];
        this.requestAssumptions = [];
        this.requestResultModule = '';
        this.requestFeedbackTab = null;
        this.requestNeedsRetry = false;
        this.requestReady = false;
        this.requestTask = null;
        this.requestCopyFeedback = '';
        this.changeOrigins = [];
        this.diffCopyFeedback = '';
        this.presentation = 'graph';
        this.textSearch = '';
        this.textFilter = '';
        this.graphZoom = 1;
        this.tabDetail = false;
        this.t = key => key;
        this.loadToken = 0;
        this.implementationLockToken = 0;
        this.languageToken = 0;
        this.mutationQueue = Promise.resolve();
        this.pendingMutations = 0;
        this.expectedChangeId = null;
        this.expectedRevisionId = null;
        this.changeByModule = new Map();
        this.revisionByModule = new Map();
        this.requestDrafts = new ChangeRequestDrafts();
        this.requestKey = null;
        this.implementationReader = readL4Implementation;
        this.onContextChange = (event) => {
            const context = event.detail;
            if (!context?.project || !context.moduleName)
                return;
            if (this.pendingEdit && (context.project !== this.pendingEdit.project || context.moduleName !== this.pendingEdit.moduleName || context.version !== 'tobe'))
                this.pendingEdit = undefined;
            const projectChanged = context.project !== this.project;
            this.project = context.project;
            this.moduleName = context.moduleName;
            this.version = context.version;
            this.tabPresentation = undefined;
            this.tabDetail = false;
            this.expectedChangeId = null;
            this.expectedRevisionId = null;
            this.mutationError = '';
            this.requestReady = false;
            this.requestTask = null;
            this.changing = this.pendingMutations > 0;
            if (projectChanged)
                void this.loadLanguage();
            void this.loadModule();
        };
        this.onNavigate = (event) => {
            const tab = event.detail?.tab;
            if (tab && TABS.includes(tab))
                void this.activateTab(tab);
        };
        this.editSnapshots = new WeakMap();
        this.refreshControls = () => {
            queueMicrotask(() => {
                const editor = this.activeEditor();
                if (editor?.mode === 'edit' && !editor.dirty && editor.getDraft)
                    this.editSnapshots.set(editor, structuredClone(editor.getDraft()));
                if (editor?.mode !== 'edit' && editor)
                    this.editSnapshots.delete(editor);
                this.requestUpdate();
            });
        };
        // Tabs can announce detail navigation without coupling their models to the container.
        this.onPresentationRequest = (event) => {
            const detail = event.detail;
            this.presentation = detail.mode;
        };
        this.onEditRequested = (event) => {
            if (this.implementationActive)
                return;
            const source = event.target;
            const id = event.detail?.id;
            if (!id || this.version !== 'asis' || source.project !== this.project || source.moduleName !== this.moduleName || source.version !== 'asis')
                return;
            this.pendingEdit = { project: this.project, moduleName: this.moduleName, tab: this.activeTab, id };
            window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project: this.project, moduleName: this.moduleName } }));
        };
        this.onViewState = (event) => {
            this.tabPresentation = event.detail;
            this.tabDetail = !!this.tabPresentation?.detail;
        };
        this.beforeDiscard = (event) => { if (!this.canLeaveTab())
            event.preventDefault(); };
        this.openChangeRequest = async (event) => {
            if (this.implementationActive || historicalReleaseId(this.version))
                return;
            const text = event?.detail?.text;
            if (!this.requestText.trim())
                this.requestText = text || this.t('common.requestTemplate', { tab: this.t(`tab.${this.activeTab}`) });
            this.presentation = 'prompt';
            await this.updateComplete;
            const panel = this.querySelector('.nr-index__request');
            if (panel)
                panel.open = true;
            this.querySelector('#nr-change-request')?.focus();
            panel?.scrollIntoView({ block: 'nearest' });
        };
        this.closeHintsOnScroll = () => {
            this.querySelectorAll('details.nr-common__hint[open]').forEach(hint => { hint.open = false; });
            this.querySelectorAll('[popover][data-nr-hint]:popover-open').forEach(hint => hint.hidePopover());
        };
        this.onTabKeydown = (event) => {
            const current = TABS.indexOf(this.activeTab);
            let next = current;
            if (event.key === 'ArrowRight')
                next = (current + 1) % TABS.length;
            else if (event.key === 'ArrowLeft')
                next = (current + TABS.length - 1) % TABS.length;
            else if (event.key === 'Home')
                next = 0;
            else if (event.key === 'End')
                next = TABS.length - 1;
            else
                return;
            event.preventDefault();
            void this.activateTab(TABS[next], true);
        };
        this.onTobeUpdated = (event) => {
            const detail = event.detail;
            if (detail?.project !== this.project || detail?.moduleName !== this.moduleName)
                return;
            // The context owner will announce the selected version after refreshing its choices.
            if (detail.version === 'tobe' && this.version === 'asis')
                return;
            if (this.pendingEdit && this.version === 'asis')
                return;
            this.scheduleOverlayReload();
        };
        this.onImplementationState = (event) => {
            const detail = event.detail;
            if (detail?.project !== this.project || detail.moduleName !== this.moduleName)
                return;
            if (detail.active) {
                ++this.implementationLockToken;
                this.setImplementationActive(true);
            }
            else
                void this.refreshImplementationLock();
        };
        this.onArtifactChanged = (event) => {
            const detail = event.detail;
            if (this.implementationActive) {
                event.preventDefault();
                detail?.complete?.(new Error(this.t('request.applicationActive')));
                this.mutationError = this.t('request.applicationActive');
                return;
            }
            if (historicalReleaseId(this.version)) {
                event.preventDefault();
                detail?.complete?.(new Error(this.t('review.snapshot.readOnly')));
                return;
            }
            const source = event.target;
            if (!detail?.path
                || source.project !== this.project || source.moduleName !== this.moduleName || source.version !== this.version)
                return;
            event.preventDefault();
            const project = this.project;
            const moduleName = this.moduleName;
            const version = this.version;
            const moduleKey = `${project}/${moduleName}`;
            const initialChange = this.expectedChangeId;
            const initialRevision = this.expectedRevisionId;
            this.requestDrafts.remember(this.requestKey, this.requestText, this.savedRequest);
            this.pendingMutations += 1;
            this.changing = true;
            this.mutationError = '';
            this.mutationQueue = this.mutationQueue.then(async () => {
                try {
                    if (!contextStillCurrent({ project, moduleName, version }, this)) {
                        detail.complete?.(new Error(this.t('request.conflict')));
                        return;
                    }
                    if (detail.languageOnly && detail.path === 'module.defs.ts' && this.data?.module) {
                        const value = detail.value;
                        const before = this.data.module;
                        const normalized = { ...before, productLanguages: value.productLanguages, defaultLanguage: value.defaultLanguage };
                        if (JSON.stringify(normalized) !== JSON.stringify(value))
                            throw new Error(this.t('general.languagesInvalid'));
                        const revisionId = await applyDirectLanguages(project, moduleName, value, {
                            changeId: this.changeByModule.has(moduleKey) ? this.changeByModule.get(moduleKey) : initialChange,
                            revisionId: this.revisionByModule.has(moduleKey) ? this.revisionByModule.get(moduleKey) : initialRevision,
                        }, key => { this.mutationError = this.t(key); });
                        this.revisionByModule.set(moduleKey, revisionId);
                        if (!contextStillCurrent({ project, moduleName, version }, this)) {
                            detail.complete?.(new Error(this.t('request.conflict')));
                            return;
                        }
                        const refreshed = await readNs5Module(project, moduleName, version);
                        const languagePending = await hasPendingLanguages(project, moduleName);
                        if (!contextStillCurrent({ project, moduleName, version }, this)) {
                            detail.complete?.(new Error(this.t('request.conflict')));
                            return;
                        }
                        this.expectedRevisionId = revisionId;
                        this.data = refreshed;
                        this.languagePending = languagePending;
                        detail.complete?.();
                        return;
                    }
                    const manifest = await saveTobeArtifact(project, moduleName, detail.path, detail.value, {
                        jsonPath: detail.jsonPath,
                        expectedChangeId: this.changeByModule.has(moduleKey) ? this.changeByModule.get(moduleKey) : initialChange,
                        expectedRevisionId: this.revisionByModule.has(moduleKey) ? this.revisionByModule.get(moduleKey) : initialRevision,
                    });
                    if (manifest.changeId && manifest.revisionId) {
                        const bound = await bindStructuredEditsRequest(project, moduleName, manifest.changeId, manifest.revisionId, this.t('request.structuredEdits'));
                        manifest.revisionId = bound.revisionId;
                        if (this.project === project && this.moduleName === moduleName) {
                            const draft = this.requestText;
                            const dirty = draft !== this.savedRequest;
                            this.savedRequest = bound.text;
                            if (!dirty)
                                this.requestText = bound.text;
                            else
                                this.requestDrafts.remember(ChangeRequestDrafts.key(project, moduleName, bound.changeId), draft, bound.text);
                        }
                    }
                    detail.complete?.();
                    if (initialChange === null && manifest.changeId) {
                        this.requestDrafts.move(ChangeRequestDrafts.key(project, moduleName, null), ChangeRequestDrafts.key(project, moduleName, manifest.changeId));
                    }
                    this.changeByModule.set(moduleKey, manifest.changeId ?? null);
                    this.revisionByModule.set(moduleKey, manifest.revisionId ?? null);
                    if (this.project === project && this.moduleName === moduleName) {
                        this.expectedChangeId = manifest.changeId ?? null;
                        this.expectedRevisionId = manifest.revisionId ?? null;
                        this.version = 'tobe';
                        this.scheduleOverlayReload();
                    }
                }
                catch (error) {
                    detail.complete?.(new Error(this.revisionError(error)));
                    if (this.project === project && this.moduleName === moduleName) {
                        this.mutationError = this.revisionError(error);
                        if (detail.path === 'module.defs.ts') {
                            const active = await readActiveL4Change(project, moduleName);
                            this.expectedRevisionId = active?.activeRevisionId ?? null;
                            this.revisionByModule.set(moduleKey, this.expectedRevisionId);
                            this.languagePending = await hasPendingLanguages(project, moduleName);
                        }
                    }
                }
                finally {
                    this.pendingMutations -= 1;
                    this.changing = this.pendingMutations > 0;
                }
            });
        };
        this.moduleThread = resolveModuleThread;
        this.openThread = dispatchThreadOpen;
    }
    createRenderRoot() { return this; }
    revisionError(error) {
        if (error instanceof NewReleaseSaveValidationError)
            return this.t(`common.validation.${error.reason}`) + (error.reason === 'invalid' ? ` ${error.issues.map(issue => issue.message).join(' · ')}` : '');
        const message = error instanceof Error ? error.message : String(error);
        if (message.includes('revision conflict') || message.includes('change conflict'))
            return this.t('request.conflict');
        if (message.startsWith('general.languages'))
            return this.t(message);
        if (message === 'new-release.application_active')
            return this.t('request.applicationActive');
        if (message === 'new-release.request_empty')
            return this.t('request.empty');
        if (message.startsWith('new-release.candidate_unindexed_file:'))
            return this.t('request.newArtifactUnsupported', { path: message.slice('new-release.candidate_unindexed_file:'.length) });
        if (message.startsWith('collab_messages_'))
            return this.t('request.identityUnavailable', { reason: message });
        if (message === 'implementation.user_unavailable')
            return this.t('request.userUnavailable');
        if (message.startsWith('new-release.thread_invalid'))
            return this.t('request.threadInvalid', { reason: message.slice('new-release.thread_invalid'.length).replace(/^:/, '') });
        if (message.startsWith('new-release.thread_forbidden'))
            return this.t('request.threadForbidden', { reason: message.slice('new-release.thread_forbidden'.length).replace(/^:/, '') });
        if (message.includes('Historical release is incomplete'))
            return this.t('request.historyUnavailable');
        if (message.includes('Historical inventory differs'))
            return this.t('request.historyIncompatible');
        if (message.includes('Discard the active candidate'))
            return this.t('request.activeCandidate');
        return message;
    }
    async ensureIdentity() {
        try {
            await ensureUserId();
            this.identityError = '';
        }
        catch (error) {
            console.error(error);
            this.identityError = error instanceof Error ? error.message : String(error);
        }
        this.requestUpdate();
    }
    connectedCallback() {
        super.connectedCallback();
        this.identityFlight ?? (this.identityFlight = this.ensureIdentity());
        this.project = this.project || Number(mls.actualProject || 0);
        this.languageObserver = observeNewReleaseLanguage(() => this.loadLanguage());
        this.addEventListener('scroll', this.closeHintsOnScroll, true);
        this.addEventListener('nr-before-discard', this.beforeDiscard);
        this.addEventListener('nr-view-state', this.onViewState);
        this.addEventListener('nr-presentation-request', this.onPresentationRequest);
        this.addEventListener('nr-request-edit', this.onEditRequested);
        this.addEventListener('nr-request-change', this.openChangeRequest);
        this.addEventListener('input', this.refreshControls);
        this.addEventListener('change', this.refreshControls);
        this.addEventListener('click', this.refreshControls);
        this.addEventListener('nr-navigate', this.onNavigate);
        this.addEventListener(NEW_RELEASE_CHANGED_EVENT, this.onArtifactChanged);
        window.addEventListener(NEW_RELEASE_CONTEXT_EVENT, this.onContextChange);
        window.addEventListener(NEW_RELEASE_TOBE_UPDATED_EVENT, this.onTobeUpdated);
        window.addEventListener(NEW_RELEASE_IMPLEMENTATION_STATE_EVENT, this.onImplementationState);
        void this.initialize();
    }
    disconnectedCallback() {
        this.languageObserver?.disconnect();
        if (this.validationTimer)
            window.clearTimeout(this.validationTimer);
        this.removeEventListener('scroll', this.closeHintsOnScroll, true);
        this.removeEventListener('nr-before-discard', this.beforeDiscard);
        this.removeEventListener('nr-view-state', this.onViewState);
        this.removeEventListener('nr-presentation-request', this.onPresentationRequest);
        this.removeEventListener('nr-request-edit', this.onEditRequested);
        this.removeEventListener('nr-request-change', this.openChangeRequest);
        this.removeEventListener('input', this.refreshControls);
        this.removeEventListener('change', this.refreshControls);
        this.removeEventListener('click', this.refreshControls);
        this.removeEventListener('nr-navigate', this.onNavigate);
        this.removeEventListener(NEW_RELEASE_CHANGED_EVENT, this.onArtifactChanged);
        window.removeEventListener(NEW_RELEASE_CONTEXT_EVENT, this.onContextChange);
        window.removeEventListener(NEW_RELEASE_TOBE_UPDATED_EVENT, this.onTobeUpdated);
        window.removeEventListener(NEW_RELEASE_IMPLEMENTATION_STATE_EVENT, this.onImplementationState);
        super.disconnectedCallback();
    }
    async initialize() {
        await this.loadLanguage();
        await this.loadModule();
    }
    async loadLanguage() {
        const token = ++this.languageToken;
        const project = this.project || Number(mls.actualProject || 0);
        const bundles = await loadNewReleaseMessages(project);
        if (token !== this.languageToken)
            return;
        this.t = createNewReleaseTranslator(bundles);
        this.requestUpdate();
    }
    async loadModule() {
        const resultModule = `${this.project}/${this.moduleName}`;
        this.diffCopyFeedback = '';
        if (this.requestResultModule !== resultModule) {
            this.requestResult = '';
            this.requestFileStates = [];
            this.requestAssumptions = [];
            this.requestNeedsRetry = false;
            this.requestReady = false;
            this.requestTask = null;
            this.requestResultModule = resultModule;
        }
        const retryText = this.requestNeedsRetry ? this.requestText : '';
        this.requestDrafts.remember(this.requestKey, this.requestText, this.savedRequest);
        this.requestKey = null;
        if (this.validationTimer) {
            window.clearTimeout(this.validationTimer);
            this.validationTimer = undefined;
        }
        const token = ++this.loadToken;
        const lockToken = ++this.implementationLockToken;
        this.data = null;
        this.requestText = '';
        this.savedRequest = '';
        this.requestError = '';
        this.expectedChangeId = null;
        this.expectedRevisionId = null;
        if (!this.project || !this.moduleName) {
            this.data = null;
            this.setImplementationActive(false);
            this.loading = false;
            return;
        }
        this.loading = true;
        const context = { project: this.project, moduleName: this.moduleName, version: this.version };
        let data;
        let request = null;
        let changeOrigins = [];
        try {
            data = await readNs5Module(context.project, context.moduleName, context.version);
            if (context.version === 'asis' || context.version === 'tobe')
                request = await readChangeRequest(context.project, context.moduleName);
            if (context.version === 'tobe')
                changeOrigins = await readChangeOrigins(context.project, context.moduleName);
        }
        catch (error) {
            if (token === this.loadToken && contextStillCurrent(context, this)) {
                if (this.pendingEdit?.project === context.project && this.pendingEdit.moduleName === context.moduleName && context.version === 'tobe')
                    this.pendingEdit = undefined;
                this.mutationError = this.revisionError(error);
                this.loading = false;
            }
            return;
        }
        if (token !== this.loadToken || !contextStillCurrent(context, this))
            return;
        let implementationActive = true;
        let lockError = '';
        try {
            implementationActive = !!await this.implementationReader(context.project, context.moduleName);
        }
        catch (error) {
            lockError = this.revisionError(error);
        }
        if (token !== this.loadToken || !contextStillCurrent(context, this))
            return;
        const languagePending = !historicalReleaseId(context.version) && await hasPendingLanguages(context.project, context.moduleName);
        if (token !== this.loadToken || !contextStillCurrent(context, this))
            return;
        this.data = data;
        if (data.confirmedRound && this.presentation === 'prompt')
            this.presentation = 'graph';
        if (lockToken === this.implementationLockToken)
            this.setImplementationActive(implementationActive);
        if (lockError)
            this.mutationError = lockError;
        this.changeOrigins = changeOrigins;
        this.languagePending = languagePending;
        this.expectedChangeId = data.changeId;
        this.expectedRevisionId = data.revisionId;
        this.changeByModule.set(`${this.project}/${this.moduleName}`, data.changeId);
        this.revisionByModule.set(`${this.project}/${this.moduleName}`, data.revisionId);
        this.savedRequest = request?.text ?? '';
        this.requestKey = context.version === 'asis' || context.version === 'tobe'
            ? ChangeRequestDrafts.key(context.project, context.moduleName, request?.changeId ?? data.changeId)
            : null;
        this.requestText = this.requestKey ? this.requestDrafts.restore(this.requestKey, this.savedRequest) ?? retryText : '';
        this.loading = false;
        if (this.pendingEdit && context.version === 'tobe')
            void this.resumePendingEdit(context, token);
    }
    async resumePendingEdit(context, token) {
        const pending = this.pendingEdit;
        if (!pending)
            return;
        if (pending.project !== context.project || pending.moduleName !== context.moduleName || pending.tab !== this.activeTab) {
            this.pendingEdit = undefined;
            return;
        }
        await this.updateComplete;
        const editor = this.activeEditor();
        await editor?.updateComplete;
        if (token !== this.loadToken || !contextStillCurrent(context, this) || this.activeTab !== pending.tab || this.pendingEdit !== pending)
            return;
        this.pendingEdit = undefined;
        if (pending.tab === 'general' && pending.id === NEW_RELEASE_GENERAL_INDICATORS_EDIT_ID) {
            editor?.openIndicatorsForEdit?.();
            return;
        }
        this.tabPresentation?.select(pending.id);
    }
    async activateTab(tab, focus = false) {
        if (this.requestBusy && !this.requestTimedOut)
            return;
        if (tab !== this.activeTab)
            await this.refreshImplementationLock();
        if (tab !== this.activeTab && !this.canLeaveTab())
            return;
        if (tab !== this.activeTab) {
            this.pendingEdit = undefined;
            if (!this.requestBusy) {
                this.requestResult = '';
                this.requestFileStates = [];
                this.requestAssumptions = [];
                this.requestError = '';
                this.requestFeedbackTab = null;
            }
        }
        const previous = this.activeEditor();
        if (previous && tab !== this.activeTab) {
            previous.mode = 'view';
            previous.dirty = false;
        }
        this.activeTab = tab;
        this.tabDetail = false;
        this.tabPresentation = undefined;
        this.textSearch = '';
        this.textFilter = '';
        this.graphZoom = 1;
        if (tab === 'review' && this.version === 'asis') {
            const context = { project: this.project, moduleName: this.moduleName, version: this.version };
            try {
                const candidate = await readActiveL4Change(context.project, context.moduleName);
                if (candidate && this.activeTab === 'review' && contextStillCurrent(context, this)) {
                    window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { ...context, version: 'tobe' } }));
                }
            }
            catch (error) {
                if (this.activeTab === 'review' && contextStillCurrent(context, this))
                    this.mutationError = this.revisionError(error);
            }
        }
        if (!focus)
            return;
        await this.updateComplete;
        this.querySelector(`#nr-tab-${tab}`)?.focus();
    }
    activeEditor() {
        return this.querySelector(`.nr-index__revision-content new-release--widgets--${this.activeTab}-102035`);
    }
    canLeaveTab() {
        const editor = this.activeEditor();
        if (!editor || editor.mode !== 'edit' || !editor.dirty)
            return true;
        if (editor.getDraft && this.editSnapshots.has(editor) && !hasDraftChanges(this.editSnapshots.get(editor), editor.getDraft()))
            return true;
        return window.confirm(this.t('common.discardChanges'));
    }
    treeNodes() {
        if (this.tabPresentation)
            return this.tabPresentation.nodes;
        return (this.data?.artifacts.all ?? [])
            .filter(artifact => tabForArtifactPath(artifact.path) === this.activeTab)
            .map(artifact => textTree(artifact.path, artifact.value));
    }
    renderTreeNode(node, depth = 0) {
        const dot = node.changed ? html `<span class="nr-item__changed" role="img" aria-label=${this.t('tobe.itemChanged')} title=${this.t('tobe.itemChanged')}></span>` : nothing;
        if (!node.children.length && !(depth === 0 && this.tabPresentation && node.value))
            return html `<li>${this.tabPresentation && (depth > 0 || node.value) ? html `<button class="nr-common__tree-select" type="button" @click=${() => { this.tabPresentation?.select(node.id); }}><span class="nr-common__tree-name">${node.label}</span>${dot}${node.suffix ? html `<span class="nr-common__tree-suffix">${node.suffix}</span>` : nothing}</button>` : html `<strong>${node.label}</strong>`}${node.value ? html `<span>${node.value}</span>` : nothing}</li>`;
        return html `<li><details ?open=${!!this.textSearch}><summary>${node.label}${dot}</summary><ul>${this.tabPresentation && node.value ? html `<li><button class="nr-common__tree-select" type="button" @click=${() => { this.tabPresentation?.select(node.id); }}>${this.t('common.details')}</button></li>` : nothing}${node.children.map(child => this.renderTreeNode(child, depth + 1))}</ul></details></li>`;
    }
    renderCommonControls() {
        if (this.activeTab === 'general' || this.activeTab === 'review')
            return nothing;
        const editing = this.activeEditor()?.mode === 'edit';
        const nested = this.tabDetail || editing;
        return html `<div class="nr-common__toolbar">
      ${nested || this.tabPresentation?.canBack ? html `<button type="button" @click=${() => {
            if (this.tabPresentation) {
                this.tabPresentation.back();
                return;
            }
            if (!this.canLeaveTab())
                return;
            const editor = this.activeEditor();
            if (editor?.mode === 'edit') {
                editor.mode = 'view';
                editor.dirty = false;
            }
            editor?.dispatchEvent(new CustomEvent('nr-back'));
            this.tabDetail = false;
        }}>${this.t('common.back')}</button>` : nothing}
      ${!nested ? html `<div role="group" aria-label=${this.t('common.presentation')}>
        ${(this.implementationActive || !!this.data?.confirmedRound ? ['graph', 'text'] : ['graph', 'text', 'prompt']).map(view => html `<button type="button" aria-pressed=${this.presentation === view ? 'true' : 'false'} @click=${() => { this.presentation = view; }}>${this.t(`common.${view}`)}</button>`)}
      </div>` : nothing}
      ${this.presentation === 'graph' && !nested ? html `<div role="group" aria-label=${this.t('common.zoom')}>
        <button type="button" aria-label=${this.t('common.zoomOut')} ?disabled=${this.graphZoom <= .5} @click=${() => { this.graphZoom = Math.max(.5, this.graphZoom - .1); }}>−</button>
        <button type="button" aria-label=${this.t('common.zoomReset')} @click=${() => { this.graphZoom = 1; }}>${Math.round(this.graphZoom * 100)}%</button>
        <button type="button" aria-label=${this.t('common.zoomIn')} ?disabled=${this.graphZoom >= 2} @click=${() => { this.graphZoom = Math.min(2, this.graphZoom + .1); }}>+</button>
      </div>` : nothing}
      <details class="nr-common__hint"><summary aria-label=${this.t('common.help')}>?</summary><p>${this.t('common.hint')}</p></details>
    </div>`;
    }
    renderTextTree() {
        const roots = this.treeNodes();
        const filters = this.tabPresentation?.filters;
        const selected = filters?.find(filter => filter.id === this.textFilter);
        const nodes = filterTextTree(selected ? roots.filter(root => selected.rootIds.includes(root.id)) : roots, this.textSearch, filters ? '' : this.textFilter);
        return html `<section class="nr-common__text">
      <label>${this.t('common.search')}<input type="search" .value=${this.textSearch} @input=${(event) => { this.textSearch = event.target.value; }}></label>
      <label>${this.t('common.filter')}<select .value=${this.textFilter} @change=${(event) => { this.textFilter = event.target.value; }}><option value="">${this.t('common.all')}</option>${(filters || roots).map(root => html `<option value=${root.id}>${root.label}</option>`)}</select></label>
      ${nodes.length ? html `<ul>${nodes.map(node => this.renderTreeNode(node))}</ul>` : html `<p role="status">${this.t('common.noResults')}</p>`}
    </section>`;
    }
    setImplementationActive(active) {
        if (active) {
            const editor = this.activeEditor();
            if (editor?.mode === 'edit') {
                editor.mode = 'view';
                editor.dirty = false;
                this.activeTab = 'review';
                this.tabDetail = false;
                this.tabPresentation = undefined;
            }
            if (this.presentation === 'prompt')
                this.presentation = 'graph';
            this.pendingEdit = undefined;
        }
        this.implementationActive = active;
    }
    async refreshImplementationLock() {
        const project = this.project;
        const moduleName = this.moduleName;
        const token = ++this.implementationLockToken;
        if (!project || !moduleName) {
            this.setImplementationActive(false);
            return;
        }
        try {
            const active = !!await this.implementationReader(project, moduleName);
            if (token === this.implementationLockToken && project === this.project && moduleName === this.moduleName)
                this.setImplementationActive(active);
        }
        catch (error) {
            if (token === this.implementationLockToken && project === this.project && moduleName === this.moduleName) {
                this.setImplementationActive(true);
                this.mutationError = this.revisionError(error);
            }
        }
    }
    scheduleOverlayReload() {
        if (this.validationTimer)
            window.clearTimeout(this.validationTimer);
        this.validationTimer = window.setTimeout(() => {
            this.validationTimer = undefined;
            void this.loadModule();
        }, 180);
    }
    canSubmitRequest() {
        if (this.implementationActive)
            return false;
        const text = this.requestText.trim();
        return !!text && (this.requestReady || text !== this.savedRequest.trim() || this.requestNeedsRetry);
    }
    startRequestProgress(context) {
        this.requestTimedOut = false;
        this.requestElapsedSeconds = 0;
        this.requestStartedAt = Date.now();
        this.requestProgressTimer = window.setInterval(() => {
            this.requestElapsedSeconds = Math.min(600, Math.floor((Date.now() - this.requestStartedAt) / 1000));
        }, 1000);
        this.requestTimeoutTimer = window.setTimeout(() => {
            this.requestTimedOut = true;
            this.requestElapsedSeconds = 600;
            if (this.requestProgressTimer !== undefined)
                window.clearInterval(this.requestProgressTimer);
            this.requestProgressTimer = undefined;
            if (contextStillCurrent(context, this))
                this.requestError = this.t('request.timedOut');
        }, REQUEST_TIMEOUT_MS);
    }
    stopRequestProgress() {
        if (this.requestProgressTimer !== undefined)
            window.clearInterval(this.requestProgressTimer);
        if (this.requestTimeoutTimer !== undefined)
            window.clearTimeout(this.requestTimeoutTimer);
        this.requestProgressTimer = undefined;
        this.requestTimeoutTimer = undefined;
        this.requestTimedOut = false;
        this.requestElapsedSeconds = 0;
    }
    async saveRequest() {
        if (this.implementationActive || this.requestBusy || this.changing || !this.canSubmitRequest())
            return;
        const context = { project: this.project, moduleName: this.moduleName, version: this.version };
        this.requestFeedbackTab = this.activeTab;
        const text = this.requestText.trim();
        const expectedChange = this.expectedChangeId;
        const expectedRevision = this.expectedRevisionId;
        this.requestBusy = true;
        this.startRequestProgress(context);
        this.requestError = '';
        this.requestResult = '';
        this.requestFileStates = [];
        this.requestAssumptions = [];
        this.requestNeedsRetry = false;
        this.requestReady = false;
        this.requestTask = null;
        this.requestCopyFeedback = '';
        try {
            const active = context.version === 'asis' ? await readActiveL4Change(context.project, context.moduleName) : null;
            if (!contextStillCurrent(context, this))
                return;
            const saved = await saveChangeRequest(context.project, context.moduleName, text, active ? active.changeId : expectedChange, active ? active.activeRevisionId : expectedRevision);
            if (!contextStillCurrent(context, this))
                return;
            this.expectedChangeId = saved.changeId;
            this.expectedRevisionId = saved.revisionId;
            this.changeByModule.set(`${context.project}/${context.moduleName}`, saved.changeId);
            this.revisionByModule.set(`${context.project}/${context.moduleName}`, saved.revisionId);
            this.savedRequest = text;
            const outcome = await runNewReleaseRequest(context.moduleName, text, task => {
                if (contextStillCurrent(context, this))
                    this.requestResult = this.t('request.running');
            }, { project: context.project });
            if (!contextStillCurrent(context, this))
                return;
            this.requestError = '';
            const summary = summarizeNewReleaseRequest(outcome.results, outcome.task.status);
            await this.rememberRequestTask(outcome.task, context);
            if (!contextStillCurrent(context, this))
                return;
            this.requestResult = summary.summary || this.t(summary.key, summary.values);
            this.requestFileStates = summary.fileStates ?? [];
            this.requestAssumptions = summary.assumptions ?? [];
            this.requestNeedsRetry = summary.retry;
            if (summary.key === 'request.question')
                this.requestText = '';
            if (outcome.task.status === 'failed')
                return;
            const written = outcome.results.some(result => { try {
                return JSON.parse(result).written === true;
            }
            catch {
                return false;
            } });
            if (written) {
                const revision = await sealL4Revision(context.project, context.moduleName, saved.revisionId, text);
                this.expectedRevisionId = revision.revisionId;
                this.revisionByModule.set(`${context.project}/${context.moduleName}`, revision.revisionId);
            }
            if (!summary.retry)
                this.requestText = '';
            this.requestDrafts.forget(this.requestKey);
            this.version = 'tobe';
            window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project: context.project, moduleName: context.moduleName } }));
            await this.loadModule();
            if (!summary.retry && context.project === this.project && context.moduleName === this.moduleName) {
                this.requestText = '';
                this.requestReady = true;
                this.requestDrafts.forget(this.requestKey);
            }
        }
        catch (error) {
            if (contextStillCurrent(context, this)) {
                if (!this.requestNeedsRetry) {
                    this.requestResult = '';
                    this.requestFileStates = [];
                    this.requestAssumptions = [];
                }
                this.requestNeedsRetry = true;
                this.requestError = this.revisionError(error);
            }
        }
        finally {
            this.stopRequestProgress();
            this.requestBusy = false;
        }
    }
    async rememberRequestTask(task, context, storeTask = addOrUpdateTask) {
        await storeTask(task);
        if (!contextStillCurrent(context, this))
            return;
        this.requestTask = {
            id: task.PK,
            threadId: (task.messageid_created || '').split('/')[0] || '',
            messageId: task.messageid_created || '',
            cost: newReleaseTaskCost(task),
            snapshot: task,
        };
    }
    async retryLanguages() {
        if (this.implementationActive || !this.data?.module || this.changing || this.requestBusy || this.activeEditor()?.dirty || historicalReleaseId(this.version))
            return;
        this.changing = true;
        try {
            await applyDirectLanguages(this.project, this.moduleName, this.data.module, { changeId: this.expectedChangeId, revisionId: this.expectedRevisionId }, key => { this.mutationError = this.t(key); });
            await this.loadModule();
        }
        catch (error) {
            this.mutationError = this.revisionError(error);
            const active = await readActiveL4Change(this.project, this.moduleName);
            this.expectedRevisionId = active?.activeRevisionId ?? null;
            this.revisionByModule.set(`${this.project}/${this.moduleName}`, this.expectedRevisionId);
        }
        finally {
            this.changing = false;
        }
    }
    async reuseHistory() {
        if (this.implementationActive || !historicalReleaseId(this.version) || this.changing)
            return;
        const context = { project: this.project, moduleName: this.moduleName, version: this.version };
        this.changing = true;
        this.mutationError = '';
        try {
            try {
                await reuseHistoricalRelease(context.project, context.moduleName, context.version);
            }
            catch (error) {
                if (!(error instanceof Error) || !error.message.includes('Discard the active candidate')
                    || !contextStillCurrent(context, this) || !window.confirm(this.t('request.replaceCandidateConfirm')))
                    throw error;
                await discardTobe(context.project, context.moduleName, undefined, false);
                if (!contextStillCurrent(context, this))
                    return;
                await reuseHistoricalRelease(context.project, context.moduleName, context.version);
            }
            if (!contextStillCurrent(context, this))
                return;
            this.version = 'tobe';
            window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project: context.project, moduleName: context.moduleName } }));
            await this.loadModule();
        }
        catch (error) {
            if (this.project === context.project && this.moduleName === context.moduleName)
                this.mutationError = this.revisionError(error);
        }
        finally {
            this.changing = this.pendingMutations > 0;
        }
    }
    tabIcon(tab) {
        const common = (content) => svg `
      <svg viewBox="0 0 24 24" aria-hidden="true">${content}</svg>
    `;
        switch (tab) {
            case 'general': return common(svg `<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>`);
            case 'journeys': return common(svg `<circle cx="6" cy="17" r="2.5"/><circle cx="18" cy="7" r="2.5"/><path d="M8.5 16c4.5 0 2.5-8 7-8"/>`);
            case 'ontology': return common(svg `<circle cx="12" cy="5" r="3"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="18" r="3"/><path d="M10.7 7.7 7.4 15M13.3 7.7l3.3 7.3M9 18h6"/>`);
            case 'access': return common(svg `<path d="M12 3 20 6v5c0 5-3.2 8.5-8 10-4.8-1.5-8-5-8-10V6Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/>`);
            case 'rules': return common(svg `<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>`);
            case 'workflows': return common(svg `<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="12" cy="18" r="2.5"/><path d="M8.5 6h7M7.5 8l3.5 7.5M16.5 8 13 15.5"/>`);
            case 'integration': return common(svg `<path d="M9 8 6.5 5.5a3.5 3.5 0 0 0-5 5L5 14a3.5 3.5 0 0 0 5 0l1-1M15 16l2.5 2.5a3.5 3.5 0 0 0 5-5L19 10a3.5 3.5 0 0 0-5 0l-1 1M8 12h8"/>`);
            case 'review': return common(svg `<path d="M7 5h13M7 12h13M7 19h9"/><circle cx="4" cy="5" r="1.4"/><circle cx="4" cy="12" r="1.4"/><circle cx="4" cy="19" r="1.4"/>`);
        }
    }
    renderTabs() {
        return html `
      <nav class="nr-index__tabs" role="tablist" aria-label=${this.t('a11y.tabs')} @keydown=${this.onTabKeydown}>
        ${TABS.map(tab => {
            const label = this.t(`tab.${tab}`);
            return html `
            <button
              id=${`nr-tab-${tab}`}
              type="button"
              role="tab"
              class=${this.activeTab === tab ? 'is-active' : ''}
              aria-label=${label}
              title=${label}
              aria-selected=${this.activeTab === tab ? 'true' : 'false'}
              aria-controls=${`nr-panel-${tab}`}
              tabindex=${this.activeTab === tab ? '0' : '-1'}
              @click=${() => void this.activateTab(tab)}
            ><span class="nr-tab__icon">${this.tabIcon(tab)}${this.tabHasTobe(tab) ? html `<i class="nr-tab__source" title=${this.t('tobe.tabSource')}></i>` : nothing}</span><span class="nr-tab__label">${label}</span></button>
          `;
        })}
      </nav>
    `;
    }
    tabHasTobe(tab) {
        return !!this.data?.artifacts.all.some(artifact => artifact.source === 'tobe' && tabForArtifactPath(artifact.path) === tab);
    }
    hasPreparedChanges() {
        return !!this.data?.changeId || !!this.data?.manifest?.changes.length;
    }
    async cancelChanges() {
        if (this.implementationActive || this.version !== 'tobe' || !this.hasPreparedChanges() || this.loading || this.changing || this.requestBusy)
            return;
        if (!window.confirm(this.t('review.clearConfirm')))
            return;
        const context = { project: this.project, moduleName: this.moduleName, version: this.version };
        const moduleKey = `${context.project}/${context.moduleName}`;
        const requestKeys = [this.requestKey,
            ChangeRequestDrafts.key(context.project, context.moduleName, this.expectedChangeId),
            ChangeRequestDrafts.key(context.project, context.moduleName, null)];
        this.pendingMutations += 1;
        this.changing = true;
        this.mutationError = '';
        try {
            await discardTobe(context.project, context.moduleName, undefined, false);
            for (const key of requestKeys)
                this.requestDrafts.forget(key);
            this.changeByModule.delete(moduleKey);
            this.revisionByModule.delete(moduleKey);
            if (!contextStillCurrent(context, this))
                return;
            this.requestText = '';
            this.savedRequest = '';
            this.requestKey = null;
            this.requestError = '';
            this.expectedChangeId = null;
            this.expectedRevisionId = null;
            this.version = 'asis';
            window.dispatchEvent(new CustomEvent(NEW_RELEASE_TOBE_UPDATED_EVENT, { detail: { project: context.project, moduleName: context.moduleName, version: 'asis' } }));
            await this.loadModule();
        }
        catch (error) {
            if (contextStillCurrent(context, this))
                this.mutationError = this.revisionError(error);
        }
        finally {
            this.pendingMutations -= 1;
            this.changing = this.pendingMutations > 0;
        }
    }
    async discardPaths(paths) {
        if (this.implementationActive || !paths.length || this.changing)
            return;
        if (!window.confirm(this.t('tobe.discardConfirm', { count: paths.length })))
            return;
        this.changing = true;
        this.mutationError = '';
        try {
            for (const path of paths)
                await discardTobe(this.project, this.moduleName, path);
            if (!this.data?.manifest || Object.keys(this.data.manifest.base).length <= paths.length)
                this.version = 'asis';
            await this.loadModule();
        }
        catch (error) {
            this.mutationError = this.revisionError(error);
        }
        finally {
            this.changing = false;
        }
    }
    validationIssues() {
        return this.data?.validation.issues ?? [];
    }
    formatDiffValue(value) {
        const text = this.fullDiffValue(value);
        return text.length > 140 ? `${text.slice(0, 137)}…` : text;
    }
    fullDiffValue(value) {
        if (value === undefined)
            return this.t('tobe.diffEmpty');
        return typeof value === 'string' ? value : JSON.stringify(value, null, 2);
    }
    originLabel(origin) {
        if (!origin)
            return this.t('tobe.origin.unknown');
        const date = new Date(origin.operation.at);
        const at = Number.isNaN(date.getTime()) ? origin.operation.at : date.toLocaleString(document.documentElement?.lang || 'pt-BR');
        return this.t(`tobe.origin.${origin.operation.source}`, { at })
            + (origin.earlier ? ` · ${this.t('tobe.origin.earlier', { count: origin.earlier })}` : '');
    }
    diffCopyText() {
        const diffs = visibleDiffs(this.data?.diffs ?? [], 'review');
        return diffs.map(diff => [diff.path, ...diff.entries.map(entry => {
                const origin = originForChange(this.changeOrigins, diff.path, entry.jsonPath);
                return [
                    entry.jsonPath,
                    `${this.t('tobe.diffBefore')}: ${this.fullDiffValue(entry.before)}`,
                    `${this.t('tobe.diffAfter')}: ${this.fullDiffValue(entry.after)}`,
                    ...(origin ? [this.originLabel(origin)] : []),
                    ...(origin?.operation.request ? [`${this.t('tobe.origin.request')}: ${origin.operation.request}`] : []),
                    ...(origin?.operation.taskId ? [this.t('tobe.origin.task', { id: origin.operation.taskId })] : []),
                ].join('\n');
            })].join('\n\n')).join('\n\n');
    }
    async copyDiffs() {
        try {
            await navigator.clipboard.writeText(this.diffCopyText());
            this.diffCopyFeedback = this.t('common.copied');
        }
        catch {
            this.diffCopyFeedback = this.t('common.copyFailed');
        }
    }
    async openOriginTask(taskId) {
        try {
            const thread = await this.moduleThread(this.project, this.moduleName);
            this.openThread(thread.threadId, taskId);
        }
        catch (error) {
            this.mutationError = this.revisionError(error);
        }
    }
    renderTobeStatus() {
        const manifest = this.data?.manifest;
        if (!manifest)
            return nothing;
        const errors = this.validationIssues().filter(issue => issue.severity === 'error').length;
        const warnings = this.validationIssues().filter(issue => issue.severity === 'warning' && !issue.baseline).length;
        const previous = this.validationIssues().filter(issue => issue.severity === 'warning' && issue.baseline).length;
        return html `
      ${this.activeTab === 'review' ? html `<section class="nr-index__tobe" aria-label=${this.t('tobe.statusLabel')} aria-live="polite">
        <div class="nr-index__tobe-main">
          <strong>${this.t('status.tobe', { count: manifest.changes.length })}</strong>
          <span>${this.t('tobe.byline', {
            author: manifest.author,
            date: new Date(manifest.updatedAt).toLocaleString(document.documentElement.lang || 'pt-BR'),
        })}</span>
        </div>
        <div class="nr-index__tobe-health">
          <span class=${errors ? 'has-errors' : ''}>${this.t('summary.errors', { count: errors })}</span>
          <span class=${warnings ? 'has-warnings' : ''}>${this.t('summary.warnings', { count: warnings })}</span>
          ${previous ? html `<span>${this.t('review.log.previous', { count: previous })}</span>` : nothing}
        </div>
      </section>` : nothing}
      ${this.data?.stalePaths.length ? html `
        <section class="nr-index__stale" role="alert">
          <div><strong>${this.t('tobe.staleTitle')}</strong><p>${this.t('tobe.staleBody')}</p></div>
          <div class="nr-index__stale-list">
            ${this.data.stalePaths.map(path => html `
              <span><code>${path}</code><button type="button" ?disabled=${this.changing || this.implementationActive} @click=${() => void this.discardPaths([path])}>${this.t('tobe.recopy')}</button></span>
            `)}
          </div>
        </section>
      ` : nothing}
    `;
    }
    renderValidationLog() {
        if (this.activeTab !== 'review' || this.version !== 'tobe' || !this.hasPreparedChanges())
            return nothing;
        const issues = this.validationIssues().filter(issue => issue.severity !== 'warning' || !issue.baseline);
        const previous = this.validationIssues().filter(issue => issue.severity === 'warning' && issue.baseline);
        return html `<section class="nr-index__log" aria-label=${this.t('review.log.title')}>
      <h2>${this.t('review.log.title')}</h2>
      ${issues.length ? html `<ul>${issues.map(issue => html `<li class=${`is-${issue.severity}`}>
        <div><strong>${this.t(`review.log.${issue.severity}`)}</strong><code>${issue.artifact}${issue.path && issue.path !== '$' ? ` · ${issue.path}` : ''}</code></div>
        <p>${issue.message}</p>
      </li>`)}</ul>` : previous.length ? nothing : html `<p>${this.t('review.log.empty')}</p>`}
      ${previous.length ? html `<details class="nr-index__previous">
        <summary>${this.t('review.log.previous', { count: previous.length })}</summary>
        <ul>${previous.map(issue => html `<li>
          <div><code>${issue.artifact}${issue.path && issue.path !== '$' ? ` · ${issue.path}` : ''}</code></div>
          <p>${issue.message}</p>
        </li>`)}</ul>
      </details>` : nothing}
    </section>`;
    }
    renderDiffs() {
        const diffs = visibleDiffs(this.data?.diffs ?? [], this.activeTab);
        if (!diffs.length)
            return nothing;
        return html `
      <details class=${`nr-index__diff${this.activeTab === 'review' ? ' nr-index__diff--plain' : ''}`}>
        <summary>${this.t('tobe.diffTitle', { count: diffs.reduce((total, item) => total + item.entries.length, 0) })}</summary>
        ${this.activeTab === 'review' ? html `
          <div class="nr-index__diff-actions">
            <button type="button" class="nr-index__copy-button" ?disabled=${this.loading || this.requestBusy}
              @click=${() => void this.copyDiffs()}>${this.t('common.copy')}</button>
            ${this.version === 'tobe' && this.hasPreparedChanges() ? html `<button type="button" ?disabled=${this.loading || this.changing || this.requestBusy || this.implementationActive}
              @click=${() => void this.cancelChanges()}>${this.t('review.clearChanges')}</button>` : nothing}
            ${this.diffCopyFeedback ? html `<span role="status">${this.diffCopyFeedback}</span>` : nothing}
          </div>
        ` : nothing}
        ${diffs.map(diff => html `
          <section>
            <header>
              <code>${diff.path}</code>
              <div>
                <span>${this.t('tobe.diffCount', { count: diff.entries.length })}</span>
                ${this.version === 'tobe' ? html `<button type="button" ?disabled=${this.changing || this.implementationActive} @click=${() => void this.discardPaths([diff.path])}>${this.t('tobe.discardPath')}</button>` : nothing}
              </div>
            </header>
            <div class="nr-index__diff-lines">
              ${diff.entries.map(entry => {
            const origin = originForChange(this.changeOrigins, diff.path, entry.jsonPath);
            return html `
                <article>
                  <code>${entry.jsonPath}</code>
                  <span class="is-before">${this.formatDiffValue(entry.before)}</span>
                  <span aria-hidden="true">${this.t('tobe.diffArrow')}</span>
                  <span class="is-after">${this.formatDiffValue(entry.after)}</span>
                  <details class="nr-index__diff-detail">
                    <summary>${this.t('tobe.diffDetails')} · ${this.originLabel(origin)}</summary>
                    ${origin?.operation.request ? html `<p>${this.t('tobe.origin.request')}: ${origin.operation.request}</p>` : nothing}
                    ${origin?.operation.taskId ? html `<button type="button" @click=${() => void this.openOriginTask(origin.operation.taskId)}>${this.t('tobe.origin.task', { id: origin.operation.taskId })}</button>` : nothing}
                    <div><strong>${this.t('tobe.diffBefore')}</strong><pre>${this.fullDiffValue(entry.before)}</pre></div>
                    <div><strong>${this.t('tobe.diffAfter')}</strong><pre>${this.fullDiffValue(entry.after)}</pre></div>
                  </details>
                </article>
              `;
        })}
            </div>
          </section>
        `)}
      </details>
    `;
    }
    renderTabContent() {
        const contentVersion = this.implementationActive && !historicalReleaseId(this.version)
            ? 'release:implementation-active' : this.version;
        if (this.activeTab === 'general') {
            return html `
        <new-release--widgets--general-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${contentVersion}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--general-102035>
      `;
        }
        if (this.activeTab === 'ontology') {
            return html `
        <new-release--widgets--ontology-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${contentVersion}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--ontology-102035>
      `;
        }
        if (this.activeTab === 'journeys') {
            return html `
        <new-release--widgets--journeys-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${contentVersion}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--journeys-102035>
      `;
        }
        if (this.activeTab === 'access') {
            return html `
        <new-release--widgets--access-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${contentVersion}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--access-102035>
      `;
        }
        if (this.activeTab === 'rules') {
            return html `
        <new-release--widgets--rules-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${contentVersion}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--rules-102035>
      `;
        }
        if (this.activeTab === 'workflows') {
            return html `
        <new-release--widgets--workflows-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${contentVersion}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--workflows-102035>
      `;
        }
        if (this.activeTab === 'integration') {
            return html `
        <new-release--widgets--integration-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${contentVersion}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--integration-102035>
      `;
        }
        if (this.activeTab === 'review') {
            return html `
        <new-release--widgets--review-102035
          .identityError=${this.identityError}
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .request=${this.savedRequest}
          .changesContent=${this.renderDiffs()}
          .t=${this.t}
        ></new-release--widgets--review-102035>
      `;
        }
        return html `
      <section class="nr-index__placeholder">
        <span class="nr-index__placeholder-mark" aria-hidden="true"></span>
        <div>
          <h2>${this.t('tab.placeholder.title', { tab: this.t(`tab.${this.activeTab}`) })}</h2>
          <p>${this.t('tab.placeholder.body')}</p>
        </div>
      </section>
    `;
    }
    renderLoading() {
        return html `
      <div class="nr-index__loading" aria-live="polite">
        <span>${this.t('state.loading')}</span>
        <div></div><div></div><div></div>
      </div>
    `;
    }
    renderRequest() {
        if (this.implementationActive)
            return nothing;
        if (this.data?.confirmedRound)
            return nothing;
        if (historicalReleaseId(this.version))
            return html `
      <section class="nr-index__request nr-index__request--history">
        <div><strong>${this.t('request.historyTitle')}</strong><p>${this.t('request.historyBody')}</p></div>
        <button type="button" ?disabled=${this.changing} @click=${() => void this.reuseHistory()}>${this.t('request.reuseHistory')}</button>
      </section>
    `;
        const showFeedback = this.requestFeedbackTab === this.activeTab;
        const unsaved = (!this.savedRequest && !this.requestText.trim()) || this.canSubmitRequest();
        return html `
      <details class="nr-index__request" ?open=${this.presentation === 'prompt' || this.requestReady || !this.savedRequest || !!(showFeedback && (this.requestResult || this.requestError))}>
        <summary><strong>${this.t('request.title')}</strong><span>${this.requestBusy && !this.requestTimedOut ? this.t('request.running') : this.requestTimedOut ? this.t('request.timedOutShort') : this.requestReady && !this.requestText.trim() ? this.t('request.ready') : unsaved ? this.t('request.unsaved') : this.t('request.saved')}</span></summary>
        <div class="nr-index__request-body">
          <p>${this.t('request.description')}</p>
          <label for="nr-change-request">${this.t('request.label')}</label>
          <textarea id="nr-change-request" rows="15" .value=${this.requestText} ?disabled=${this.requestBusy} placeholder=${this.t('request.placeholder')} @input=${(event) => { this.requestText = event.currentTarget.value; }}></textarea>
          ${showFeedback && this.requestResult && this.requestTask?.snapshot.status !== 'failed' ? html `<pre aria-live="polite">${this.requestResult}</pre>` : nothing}
          ${showFeedback && this.requestAssumptions.length ? html `<div><strong>${this.t('request.assumptions')}:</strong><ul>${this.requestAssumptions.map(item => html `<li>${item}</li>`)}</ul></div>` : nothing}
          ${showFeedback && this.requestTask ? this.renderRequestTask() : nothing}
          ${showFeedback && this.requestTask?.snapshot.status === 'failed' ? html `<div class="nr-index__request-failure" role="alert">${this.requestTask.snapshot.last_update_log ? html `<p>${this.t('request.failed')}</p>` : nothing}<pre>${this.requestTask.snapshot.last_update_log || this.requestResult}</pre><button type="button" @click=${() => void this.copyRequestFailure()}>${this.t('common.copy')}</button><span role="status">${this.requestCopyFeedback}</span></div>` : nothing}
          ${showFeedback && this.requestFileStates.length ? html `<ul>${this.requestFileStates.map(item => html `<li><code>${item.path}</code> — ${this.t(`request.fileState.${item.state}`)}</li>`)}</ul>` : nothing}
          ${this.identityError ? html `<p class="nr-index__request-error" role="alert">${this.identityError === 'pending' ? this.t('request.identityPending') : this.t('request.identityUnavailable', { reason: this.identityError })}</p>` : nothing}
          ${showFeedback && this.requestError ? html `<p class="nr-index__request-error" role="alert">${this.requestError}</p>` : nothing}
          <div class="nr-index__request-actions">
            <button class="nr-request-action" type="button" ?disabled=${this.requestBusy || this.changing || !this.canSubmitRequest()} @click=${() => void this.saveRequest()}>${this.t('request.save')}</button>
          </div>
        </div>
      </details>
    `;
    }
    renderRequestTask() {
        const requestTask = this.requestTask;
        const orderAt = requestTask.messageId.split('/').pop() || '';
        const context = {
            message: { threadId: requestTask.threadId, orderAt, createAt: orderAt.slice(0, 14), senderId: requestTask.snapshot.owner,
                content: '', taskId: requestTask.id.replace(/^task(?:\/#?|#)/u, ''), taskStatus: requestTask.snapshot.status },
            task: requestTask.snapshot,
            isTest: false,
        };
        return html `<div class="nr-index__request-task">
      <p>${this.t('request.taskExecuted', { id: requestTask.id, cost: requestTask.cost === null ? this.t('request.costUnavailable') : `$${requestTask.cost.toFixed(2)}` })}</p>
      <collab-messages-task-102025 .context=${context} taskid=${context.message.taskId} threadId=${requestTask.threadId}
        messageid=${requestTask.messageId} userId=${getUserId() || ''} lastChanged=${`${requestTask.id}:${requestTask.snapshot.last_updated}`}
        @taskclick=${() => { if (requestTask.threadId)
            dispatchThreadOpen(requestTask.threadId, context.message.taskId); }}
      ></collab-messages-task-102025>
    </div>`;
    }
    async copyRequestFailure() {
        try {
            await navigator.clipboard.writeText(this.requestTask?.snapshot.last_update_log || this.requestResult);
            this.requestCopyFeedback = this.t('common.copied');
        }
        catch {
            this.requestCopyFeedback = this.t('common.copyFailed');
        }
    }
    renderEmpty() {
        const selectedModule = !!this.project && !!this.moduleName;
        return html `
      <section class="nr-index__empty">
        <span aria-hidden="true"></span>
        <h2>${this.t(selectedModule ? 'state.unreadableTitle' : 'state.emptyTitle')}</h2>
        <p>${this.t(selectedModule ? 'state.unreadableBody' : 'state.emptyBody')}</p>
        ${selectedModule && this.mutationError ? html `<p role="alert">${this.mutationError}</p>` : nothing}
        ${selectedModule && this.data?.errors?.length ? html `<ul>${this.data.errors.map(error => html `<li>${this.t('state.errorPath', { path: error.path, message: error.message })}</li>`)}</ul>` : nothing}
      </section>
    `;
    }
    renderRequestProgress() {
        if (!this.requestBusy || this.requestTimedOut)
            return nothing;
        return html `<div class="nr-index__request-progress" role="dialog" aria-modal="true" aria-label=${this.t('request.progressTitle')}>
      <div class="nr-index__request-progress-card">
        <span class="nr-index__request-progress-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 0 9 9"/></svg></span>
        <strong>${this.t('request.progressTitle')}</strong>
        <p>${this.t('request.progressHint')}</p>
        <progress max="600" value=${this.requestElapsedSeconds} aria-label=${this.t('request.progressElapsed')}></progress>
        <small>${this.t('request.progressElapsed')} · ${Math.floor(this.requestElapsedSeconds / 60)} / 10 ${this.t('request.minutes')}</small>
      </div>
    </div>`;
    }
    render() {
        const historical = !!historicalReleaseId(this.version);
        const pendingChanges = !this.loading && this.version === 'tobe' && this.data?.module
            ? visibleDiffs(this.data.diffs, 'review').reduce((count, diff) => count + diff.entries.length, 0)
            : null;
        return html `
      <main class="nr-index" ?inert=${this.requestBusy && !this.requestTimedOut} aria-busy=${this.loading || (this.requestBusy && !this.requestTimedOut) ? 'true' : 'false'}>
        ${this.renderTabs()}
        ${this.implementationActive ? html `<p class="nr-index__implementation-lock" role="status">${this.t('request.applicationActive')}</p>` : nothing}
        ${pendingChanges !== null && this.activeTab !== 'review' ? html `<p class="nr-index__changes-summary" role="status">${this.t(pendingChanges === 0 ? 'tobe.noChanges' : pendingChanges === 1 ? 'tobe.onePendingChange' : 'tobe.pendingChanges', { count: pendingChanges })}</p>` : nothing}

        ${!this.loading && this.data?.module && this.activeTab === 'general' ? this.renderRequest() : nothing}
        ${!this.loading && this.version !== 'tobe' && this.data?.baseProvenance?.status === 'unverified' ? html `<p class="nr-index__base-warning" role="status">${this.t('request.baseUnverified')}</p>` : nothing}

        ${this.renderTobeStatus()}

        ${this.loading ? this.renderLoading() : !this.data?.module ? this.renderEmpty() : html `
          ${this.languagePending ? html `<button type="button" class="nr-button" ?disabled=${this.changing || this.requestBusy || this.implementationActive || !!this.activeEditor()?.dirty} @click=${this.retryLanguages}>${this.t('general.languagesRetry')}</button>` : nothing}
          ${this.data.errors.length || this.mutationError ? html `
            <section class="nr-index__errors">
              ${this.data.errors.length ? html `<strong>${this.t('state.errorTitle')}</strong>` : nothing}
              ${this.mutationError ? html `<p>${this.mutationError}</p>` : nothing}
              ${this.data.errors.map(error => html `<p>${this.t('state.errorPath', { path: error.path, message: error.message })}</p>`)}
            </section>
          ` : nothing}
          <section
            id=${`nr-panel-${this.activeTab}`}
            class="nr-index__content"
            role="tabpanel"
            aria-labelledby=${`nr-tab-${this.activeTab}`}
            tabindex="0"
          ><fieldset class="nr-index__revision-content" ?disabled=${historical && !this.data?.confirmedRound}>
            ${this.renderCommonControls()}
            ${this.presentation === 'prompt' && !this.tabDetail && this.activeTab !== 'review' && this.activeTab !== 'general' && this.activeEditor()?.mode !== 'edit' ? this.renderRequest() : nothing}
            <div class="nr-common__graph" ?hidden=${this.presentation !== 'graph' && !this.tabDetail && this.activeTab !== 'general' && this.activeTab !== 'review' && this.activeEditor()?.mode !== 'edit'}>
              <div style=${`zoom: ${this.activeTab === 'general' || this.activeTab === 'review' || this.tabDetail || this.activeEditor()?.mode === 'edit' ? 1 : this.graphZoom}`}>
                ${this.renderTabContent()}
              </div>
            </div>
            ${this.presentation === 'text' && !this.tabDetail && this.activeTab !== 'general' && this.activeTab !== 'review' && this.activeEditor()?.mode !== 'edit' ? this.renderTextTree() : nothing}
          </fieldset></section>
          ${this.activeTab !== 'review' ? this.renderDiffs() : nothing}
          ${this.renderValidationLog()}
        `}
      </main>
      ${this.renderRequestProgress()}
    `;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseIndex102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseIndex102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseIndex102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseIndex102035.prototype, "data", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "activeTab", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "loading", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "changing", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "implementationActive", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "mutationError", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "languagePending", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestText", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "savedRequest", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestBusy", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestTimedOut", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestElapsedSeconds", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestError", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "identityError", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestResult", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestFileStates", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestAssumptions", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestNeedsRetry", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestReady", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestTask", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "requestCopyFeedback", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "changeOrigins", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "diffCopyFeedback", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "presentation", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "textSearch", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "textFilter", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "graphZoom", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "tabDetail", void 0);
NewReleaseIndex102035 = __decorate([
    customElement('new-release--widgets--index-102035')
], NewReleaseIndex102035);
export { NewReleaseIndex102035 };
