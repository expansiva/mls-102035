/// <mls fileReference="_102035_/l2/newRelease/widgets/index.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { NEW_RELEASE_CONTEXT_EVENT, } from '/_102035_/l2/newRelease/helpers/context.js';
import { readNs5Module, } from '/_102035_/l2/newRelease/helpers/l4Reader.js';
import { createNewReleaseTranslator, loadNewReleaseMessages, observeNewReleaseLanguage, } from '/_102035_/l2/newRelease/helpers/i18n.js';
import { discardTobe, NEW_RELEASE_TOBE_UPDATED_EVENT, saveTobeArtifact, } from '/_102035_/l2/newRelease/tobe.js';
import { NEW_RELEASE_CHANGED_EVENT, tabForArtifactPath, } from '/_102035_/l2/newRelease/editContract.js';
import '/_102035_/l2/newRelease/widgets/general.js';
import '/_102035_/l2/newRelease/widgets/access.js';
import '/_102035_/l2/newRelease/widgets/journeys.js';
import '/_102035_/l2/newRelease/widgets/ontology.js';
import '/_102035_/l2/newRelease/widgets/rules.js';
import '/_102035_/l2/newRelease/widgets/workflows.js';
import '/_102035_/l2/newRelease/widgets/integration.js';
const TABS = ['general', 'journeys', 'ontology', 'access', 'rules', 'workflows', 'integration'];
let NewReleaseIndex102035 = class NewReleaseIndex102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--index-102035 {
  display: block;
  min-width: 0;
  min-height: 100%;
  color: var(--text-default, #2f3a48);
}
new-release--widgets--index-102035 * {
  box-sizing: border-box;
}
new-release--widgets--index-102035 .nr-index {
  --nr-space-1: 0.25rem;
  --nr-space-2: 0.5rem;
  --nr-space-3: 0.75rem;
  --nr-space-4: 1rem;
  min-height: 100%;
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 1.15rem;
  background: var(--page-bg, #eef1f5);
  box-shadow: 0 1.25rem 3rem rgba(15, 23, 42, 0.08);
  font-family: var(--font-family-sans, Inter, system-ui, sans-serif);
  line-height: 1.45;
}
new-release--widgets--index-102035 .nr-index :where(button, input, select, textarea, summary, [tabindex]):focus-visible {
  outline: 0.15rem solid var(--focus-ring, #1273d4);
  outline-offset: 0.12rem;
}
new-release--widgets--index-102035 .nr-index__tabs {
  position: sticky;
  z-index: 3;
  top: 0;
  display: flex;
  gap: 0.18rem;
  padding: 0.55rem 1.15rem 0;
  overflow-x: auto;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: color-mix(in srgb, var(--surface-bg, #fff) 96%, transparent);
  backdrop-filter: blur(0.7rem);
  scrollbar-width: thin;
}
new-release--widgets--index-102035 .nr-index__tabs button {
  position: relative;
  display: inline-flex;
  align-items: center;
  flex: none;
  gap: 0.42rem;
  padding: 0.7rem 0.62rem 0.66rem;
  border: 0;
  outline: none;
  background: transparent;
  color: var(--text-muted, #5d6b7e);
  cursor: pointer;
  font: inherit;
  font-size: 0.7rem;
  font-weight: 700;
}
new-release--widgets--index-102035 .nr-index__tabs button::after {
  content: '';
  position: absolute;
  right: 0.55rem;
  bottom: -1px;
  left: 0.55rem;
  height: 0.18rem;
  border-radius: 0.2rem 0.2rem 0 0;
  background: transparent;
}
new-release--widgets--index-102035 .nr-tab__icon {
  display: grid;
  width: 1.15rem;
  height: 1.15rem;
  place-items: center;
}
new-release--widgets--index-102035 .nr-tab__icon svg {
  width: 100%;
  height: 100%;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 1.8;
  transition: fill 0.16s ease, color 0.16s ease;
}
new-release--widgets--index-102035 .nr-index__tabs button:hover {
  color: var(--text-strong, #111827);
}
new-release--widgets--index-102035 .nr-index__tabs button:focus-visible {
  border-radius: 0.45rem;
  outline-offset: -0.18rem;
}
new-release--widgets--index-102035 .nr-index__tabs button.is-active {
  color: var(--selected-text, #0d5296);
}
new-release--widgets--index-102035 .nr-index__tabs button.is-active::after {
  background: var(--selected-border, #1273d4);
}
new-release--widgets--index-102035 .nr-index__tabs button.is-active .nr-tab__icon svg {
  fill: color-mix(in srgb, currentColor 28%, transparent);
}
new-release--widgets--index-102035 .nr-tab__source {
  width: 0.42rem;
  height: 0.42rem;
  border: 0.1rem solid var(--surface-bg, #fff);
  border-radius: 50%;
  background: var(--status-warning-text, #9a6700);
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--status-warning-text, #9a6700) 35%, transparent);
}
new-release--widgets--index-102035 .nr-index__tobe {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.65rem 1.25rem;
  border-bottom: 1px solid color-mix(in srgb, var(--status-info-text, #0b5497) 18%, transparent);
  background: var(--status-info-bg, #eaf3fc);
}
new-release--widgets--index-102035 .nr-index__tobe-main {
  display: flex;
  align-items: baseline;
  min-width: 0;
  gap: 0.7rem;
}
new-release--widgets--index-102035 .nr-index__tobe-main strong {
  color: var(--status-info-text, #0b5497);
  font-size: 0.72rem;
}
new-release--widgets--index-102035 .nr-index__tobe-main span {
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--index-102035 .nr-index__tobe-health {
  display: flex;
  flex: none;
  gap: 0.38rem;
}
new-release--widgets--index-102035 .nr-index__tobe-health span {
  padding: 0.2rem 0.42rem;
  border-radius: 999px;
  background: color-mix(in srgb, var(--surface-bg, #fff) 72%, transparent);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
  font-weight: 700;
}
new-release--widgets--index-102035 .nr-index__tobe-health .has-errors {
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--index-102035 .nr-index__tobe-health .has-warnings {
  background: var(--status-warning-bg, #fcf2d7);
  color: var(--status-warning-text, #775700);
}
new-release--widgets--index-102035 .nr-index__stale {
  display: grid;
  grid-template-columns: minmax(10rem, 0.8fr) minmax(14rem, 1.2fr);
  gap: 0.8rem 1.2rem;
  margin: 0.85rem 1.25rem 0;
  padding: 0.85rem 1rem;
  border: 1px solid color-mix(in srgb, var(--status-warning-text, #775700) 28%, transparent);
  border-radius: 0.78rem;
  background: var(--status-warning-bg, #fcf2d7);
  color: var(--status-warning-text, #775700);
}
new-release--widgets--index-102035 .nr-index__stale strong {
  font-size: 0.73rem;
}
new-release--widgets--index-102035 .nr-index__stale p {
  margin: 0.28rem 0 0;
  color: inherit;
  font-size: 0.68rem;
  line-height: 1.45;
}
new-release--widgets--index-102035 .nr-index__stale-list {
  display: grid;
  gap: 0.38rem;
}
new-release--widgets--index-102035 .nr-index__stale-list > span {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.7rem;
}
new-release--widgets--index-102035 .nr-index__stale code {
  overflow: hidden;
  font-size: 0.64rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--index-102035 .nr-index__stale button,
new-release--widgets--index-102035 .nr-index__discard {
  padding: 0.38rem 0.58rem;
  border: 1px solid currentColor;
  border-radius: 0.5rem;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font: inherit;
  font-size: 0.64rem;
  font-weight: 750;
}
new-release--widgets--index-102035 .nr-index__stale button:focus-visible,
new-release--widgets--index-102035 .nr-index__discard:focus-visible {
  outline: 0.15rem solid var(--focus-ring, #7ab8f5);
  outline-offset: 0.12rem;
}
new-release--widgets--index-102035 .nr-index__content {
  min-height: 17rem;
}
new-release--widgets--index-102035 .nr-index__content:focus-visible {
  outline-offset: -0.2rem;
}
new-release--widgets--index-102035 .nr-index__placeholder,
new-release--widgets--index-102035 .nr-index__empty {
  display: grid;
  place-items: center;
  align-content: center;
  min-height: 18rem;
  padding: 2rem;
  text-align: center;
}
new-release--widgets--index-102035 .nr-index__placeholder-mark,
new-release--widgets--index-102035 .nr-index__empty > span {
  display: block;
  width: 3.2rem;
  height: 0.32rem;
  margin: 0 auto 1rem;
  border-radius: 999px;
  background: linear-gradient(90deg, var(--chart-series-1, #1273d4), var(--chart-series-3, #7c3aed));
}
new-release--widgets--index-102035 .nr-index__placeholder h2,
new-release--widgets--index-102035 .nr-index__empty h2 {
  margin: 0;
  color: var(--text-strong, #111827);
  font-size: 1.1rem;
}
new-release--widgets--index-102035 .nr-index__placeholder p,
new-release--widgets--index-102035 .nr-index__empty p {
  max-width: 34rem;
  margin: 0.55rem auto 0;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--index-102035 .nr-index__loading {
  display: grid;
  gap: 0.7rem;
  padding: 1.4rem 1.25rem;
}
new-release--widgets--index-102035 .nr-index__loading span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.75rem;
}
new-release--widgets--index-102035 .nr-index__loading div {
  height: 3.5rem;
  border-radius: 0.75rem;
  background: linear-gradient(90deg, var(--surface-alt-bg, #f5f7fa), var(--surface-bg, #fff), var(--surface-alt-bg, #f5f7fa));
  background-size: 240% 100%;
  animation: nr-shimmer 1.5s linear infinite;
}
new-release--widgets--index-102035 .nr-index__errors {
  margin: 0.9rem 1.25rem 0;
  padding: 0.85rem 1rem;
  border: 1px solid color-mix(in srgb, var(--status-error-text, #ab2328) 24%, transparent);
  border-radius: 0.75rem;
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
  font-size: 0.75rem;
}
new-release--widgets--index-102035 .nr-index__errors p {
  margin: 0.3rem 0 0;
}
new-release--widgets--index-102035 .nr-index__diff {
  margin: 0 1.25rem 1.15rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.8rem;
  background: var(--surface-bg, #fff);
  overflow: hidden;
}
new-release--widgets--index-102035 .nr-index__diff > summary {
  padding: 0.72rem 0.9rem;
  color: var(--text-strong, #111827);
  cursor: pointer;
  font-size: 0.72rem;
  font-weight: 760;
}
new-release--widgets--index-102035 .nr-index__diff section {
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--index-102035 .nr-index__diff section > header {
  display: flex;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.55rem 0.9rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--index-102035 .nr-index__diff section > header code {
  color: var(--link-text, #0f62b8);
  font-size: 0.66rem;
  font-weight: 750;
}
new-release--widgets--index-102035 .nr-index__diff section > header span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
}
new-release--widgets--index-102035 .nr-index__diff-lines {
  display: grid;
}
new-release--widgets--index-102035 .nr-index__diff-lines article {
  display: grid;
  grid-template-columns: minmax(8rem, 0.8fr) minmax(0, 1fr) auto minmax(0, 1fr);
  align-items: center;
  gap: 0.5rem;
  padding: 0.52rem 0.9rem;
  border-top: 1px solid color-mix(in srgb, var(--border-subtle, #e4e9f0) 65%, transparent);
  font-size: 0.64rem;
}
new-release--widgets--index-102035 .nr-index__diff-lines code {
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--index-102035 .nr-index__diff-lines span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--index-102035 .nr-index__diff-lines .is-before {
  color: var(--status-error-text, #ab2328);
  text-decoration: line-through;
}
new-release--widgets--index-102035 .nr-index__diff-lines .is-after {
  color: var(--status-success-text, #25640e);
  font-weight: 700;
}
new-release--widgets--index-102035 .nr-index__footer {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 1rem;
  padding: 0.85rem 1.2rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-bg, #fff);
}
new-release--widgets--index-102035 .nr-index__footer div {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
new-release--widgets--index-102035 .nr-index__footer span {
  padding: 0.28rem 0.5rem;
  border-radius: 999px;
  background: var(--status-info-bg, #e2effc);
  color: var(--status-info-text, #0b5497);
  font-size: 0.6rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--index-102035 .nr-index__footer button {
  min-width: 5rem;
  padding: 0.5rem 0.72rem;
  border: 1px solid var(--button-secondary-border-disabled, #dbe1e9);
  border-radius: 0.6rem;
  background: var(--button-secondary-bg-disabled, #f6f7fa);
  color: var(--button-secondary-text-disabled, #989fa7);
  cursor: not-allowed;
  font: inherit;
  font-size: 0.72rem;
  font-weight: 700;
}
new-release--widgets--index-102035 .nr-index__footer .nr-index__discard {
  border-color: color-mix(in srgb, var(--status-error-text, #ab2328) 45%, transparent);
  background: var(--surface-bg, #fff);
  color: var(--status-error-text, #ab2328);
  cursor: pointer;
}
@keyframes nr-shimmer {
  to {
    background-position: -240% 0;
  }
}
@media (max-width: 780px) {
  new-release--widgets--index-102035 .nr-index__tabs {
    padding-inline: 0.65rem;
  }
  new-release--widgets--index-102035 .nr-index__tobe {
    align-items: flex-start;
    flex-direction: column;
    padding-inline: 0.9rem;
  }
  new-release--widgets--index-102035 .nr-index__stale {
    grid-template-columns: 1fr;
    margin-inline: 0.85rem;
  }
  new-release--widgets--index-102035 .nr-index__diff {
    margin-inline: 0.85rem;
  }
  new-release--widgets--index-102035 .nr-index__diff-lines article {
    grid-template-columns: 1fr;
  }
  new-release--widgets--index-102035 .nr-index__footer {
    padding: 0.85rem;
  }
}
@media (prefers-reduced-motion: reduce) {
  new-release--widgets--index-102035 .nr-index *,
  new-release--widgets--index-102035 .nr-index *::before,
  new-release--widgets--index-102035 .nr-index *::after {
    scroll-behavior: auto !important;
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.activeTab = 'general';
        this.loading = true;
        this.changing = false;
        this.mutationError = '';
        this.t = key => key;
        this.loadToken = 0;
        this.mutationQueue = Promise.resolve();
        this.pendingMutations = 0;
        this.onContextChange = (event) => {
            const context = event.detail;
            if (!context?.project || !context.moduleName)
                return;
            const projectChanged = context.project !== this.project;
            this.project = context.project;
            this.moduleName = context.moduleName;
            this.version = context.version;
            if (projectChanged)
                void this.loadLanguage();
            void this.loadModule();
        };
        this.onNavigate = (event) => {
            const tab = event.detail?.tab;
            if (tab && TABS.includes(tab))
                this.activeTab = tab;
        };
        this.onTabKeydown = (event) => {
            const current = TABS.indexOf(this.activeTab);
            let next = current;
            if (event.key === 'ArrowRight')
                next = (current + 1) % TABS.length;
            else if (event.key === 'ArrowLeft')
                next = (current + TABS.length - 1) % TABS.length;
            else if (event.key === 'Home')
                next = 0;
            else if (event.key === 'End')
                next = TABS.length - 1;
            else
                return;
            event.preventDefault();
            void this.activateTab(TABS[next], true);
        };
        this.onTobeUpdated = (event) => {
            const detail = event.detail;
            if (detail?.project !== this.project || detail?.moduleName !== this.moduleName)
                return;
            this.scheduleOverlayReload();
        };
        this.onArtifactChanged = (event) => {
            const detail = event.detail;
            if (!detail?.path)
                return;
            this.pendingMutations += 1;
            this.changing = true;
            this.mutationError = '';
            this.mutationQueue = this.mutationQueue.then(async () => {
                try {
                    await saveTobeArtifact(this.project, this.moduleName, detail.path, detail.value, { jsonPath: detail.jsonPath });
                    this.version = 'tobe';
                    this.scheduleOverlayReload();
                }
                catch (error) {
                    this.mutationError = error instanceof Error ? error.message : String(error);
                }
                finally {
                    this.pendingMutations -= 1;
                    this.changing = this.pendingMutations > 0;
                }
            });
        };
    }
    createRenderRoot() { return this; }
    connectedCallback() {
        super.connectedCallback();
        this.project = this.project || Number(mls.actualProject || 0);
        this.languageObserver = observeNewReleaseLanguage(() => this.loadLanguage());
        this.addEventListener('nr-navigate', this.onNavigate);
        this.addEventListener(NEW_RELEASE_CHANGED_EVENT, this.onArtifactChanged);
        window.addEventListener(NEW_RELEASE_CONTEXT_EVENT, this.onContextChange);
        window.addEventListener(NEW_RELEASE_TOBE_UPDATED_EVENT, this.onTobeUpdated);
        void this.initialize();
    }
    disconnectedCallback() {
        this.languageObserver?.disconnect();
        if (this.validationTimer)
            window.clearTimeout(this.validationTimer);
        this.removeEventListener('nr-navigate', this.onNavigate);
        this.removeEventListener(NEW_RELEASE_CHANGED_EVENT, this.onArtifactChanged);
        window.removeEventListener(NEW_RELEASE_CONTEXT_EVENT, this.onContextChange);
        window.removeEventListener(NEW_RELEASE_TOBE_UPDATED_EVENT, this.onTobeUpdated);
        super.disconnectedCallback();
    }
    async initialize() {
        await this.loadLanguage();
        await this.loadModule();
    }
    async loadLanguage() {
        this.t = createNewReleaseTranslator(await loadNewReleaseMessages(this.project || Number(mls.actualProject || 0)));
        this.requestUpdate();
    }
    async loadModule() {
        if (this.validationTimer) {
            window.clearTimeout(this.validationTimer);
            this.validationTimer = undefined;
        }
        const token = ++this.loadToken;
        if (!this.project || !this.moduleName) {
            this.data = null;
            this.loading = false;
            return;
        }
        this.loading = true;
        const data = await readNs5Module(this.project, this.moduleName, this.version);
        if (token !== this.loadToken)
            return;
        this.data = data;
        this.loading = false;
    }
    async activateTab(tab, focus = false) {
        this.activeTab = tab;
        if (!focus)
            return;
        await this.updateComplete;
        this.querySelector(`#nr-tab-${tab}`)?.focus();
    }
    scheduleOverlayReload() {
        if (this.validationTimer)
            window.clearTimeout(this.validationTimer);
        this.validationTimer = window.setTimeout(() => {
            this.validationTimer = undefined;
            void this.loadModule();
        }, 180);
    }
    tabIcon(tab) {
        const common = (content) => svg `
      <svg viewBox="0 0 24 24" aria-hidden="true">${content}</svg>
    `;
        switch (tab) {
            case 'general': return common(svg `<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>`);
            case 'journeys': return common(svg `<circle cx="6" cy="17" r="2.5"/><circle cx="18" cy="7" r="2.5"/><path d="M8.5 16c4.5 0 2.5-8 7-8"/>`);
            case 'ontology': return common(svg `<circle cx="12" cy="5" r="3"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="18" r="3"/><path d="M10.7 7.7 7.4 15M13.3 7.7l3.3 7.3M9 18h6"/>`);
            case 'access': return common(svg `<path d="M12 3 20 6v5c0 5-3.2 8.5-8 10-4.8-1.5-8-5-8-10V6Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/>`);
            case 'rules': return common(svg `<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>`);
            case 'workflows': return common(svg `<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="12" cy="18" r="2.5"/><path d="M8.5 6h7M7.5 8l3.5 7.5M16.5 8 13 15.5"/>`);
            case 'integration': return common(svg `<path d="M9 8 6.5 5.5a3.5 3.5 0 0 0-5 5L5 14a3.5 3.5 0 0 0 5 0l1-1M15 16l2.5 2.5a3.5 3.5 0 0 0 5-5L19 10a3.5 3.5 0 0 0-5 0l-1 1M8 12h8"/>`);
        }
    }
    renderTabs() {
        return html `
      <nav class="nr-index__tabs" role="tablist" aria-label=${this.t('a11y.tabs')} @keydown=${this.onTabKeydown}>
        ${TABS.map(tab => html `
          <button
            id=${`nr-tab-${tab}`}
            type="button"
            role="tab"
            class=${this.activeTab === tab ? 'is-active' : ''}
            aria-selected=${this.activeTab === tab ? 'true' : 'false'}
            aria-controls=${`nr-panel-${tab}`}
            tabindex=${this.activeTab === tab ? '0' : '-1'}
            @click=${() => void this.activateTab(tab)}
          ><span class="nr-tab__icon">${this.tabIcon(tab)}</span><span>${this.t(`tab.${tab}`)}</span>${this.tabHasTobe(tab) ? html `<i class="nr-tab__source" title=${this.t('tobe.tabSource')}></i>` : nothing}</button>
        `)}
      </nav>
    `;
    }
    tabHasTobe(tab) {
        return !!this.data?.artifacts.all.some(artifact => artifact.source === 'tobe' && tabForArtifactPath(artifact.path) === tab);
    }
    tabTobePaths(tab = this.activeTab) {
        return this.data?.artifacts.all
            .filter(artifact => artifact.source === 'tobe' && tabForArtifactPath(artifact.path) === tab)
            .map(artifact => artifact.path) ?? [];
    }
    async discardPaths(paths) {
        if (!paths.length || this.changing)
            return;
        if (!window.confirm(this.t('tobe.discardConfirm', { count: paths.length })))
            return;
        this.changing = true;
        this.mutationError = '';
        try {
            for (const path of paths)
                await discardTobe(this.project, this.moduleName, path);
            if (!this.data?.manifest || Object.keys(this.data.manifest.base).length <= paths.length)
                this.version = 'asis';
            await this.loadModule();
        }
        catch (error) {
            this.mutationError = error instanceof Error ? error.message : String(error);
        }
        finally {
            this.changing = false;
        }
    }
    validationIssues() {
        return this.data?.validation.issues ?? [];
    }
    formatDiffValue(value) {
        if (value === undefined)
            return this.t('tobe.diffEmpty');
        const text = typeof value === 'string' ? value : JSON.stringify(value);
        return text.length > 140 ? `${text.slice(0, 137)}…` : text;
    }
    renderTobeStatus() {
        const manifest = this.data?.manifest;
        if (!manifest)
            return nothing;
        const errors = this.validationIssues().filter(issue => issue.severity === 'error').length;
        const warnings = this.validationIssues().filter(issue => issue.severity === 'warning').length;
        return html `
      <section class="nr-index__tobe" aria-label=${this.t('tobe.statusLabel')} aria-live="polite">
        <div class="nr-index__tobe-main">
          <strong>${this.t('status.tobe', { count: manifest.changes.length })}</strong>
          <span>${this.t('tobe.byline', {
            author: manifest.author,
            date: new Date(manifest.updatedAt).toLocaleString(document.documentElement.lang || 'pt-BR'),
        })}</span>
        </div>
        <div class="nr-index__tobe-health">
          <span class=${errors ? 'has-errors' : ''}>${this.t('summary.errors', { count: errors })}</span>
          <span class=${warnings ? 'has-warnings' : ''}>${this.t('summary.warnings', { count: warnings })}</span>
        </div>
      </section>
      ${this.data?.stalePaths.length ? html `
        <section class="nr-index__stale" role="alert">
          <div><strong>${this.t('tobe.staleTitle')}</strong><p>${this.t('tobe.staleBody')}</p></div>
          <div class="nr-index__stale-list">
            ${this.data.stalePaths.map(path => html `
              <span><code>${path}</code><button type="button" ?disabled=${this.changing} @click=${() => void this.discardPaths([path])}>${this.t('tobe.recopy')}</button></span>
            `)}
          </div>
        </section>
      ` : nothing}
    `;
    }
    renderDiffs() {
        const diffs = this.data?.diffs ?? [];
        if (!diffs.length)
            return nothing;
        return html `
      <details class="nr-index__diff">
        <summary>${this.t('tobe.diffTitle', { count: diffs.reduce((total, item) => total + item.entries.length, 0) })}</summary>
        ${diffs.map(diff => html `
          <section>
            <header><code>${diff.path}</code><span>${this.t('tobe.diffCount', { count: diff.entries.length })}</span></header>
            <div class="nr-index__diff-lines">
              ${diff.entries.map(entry => html `
                <article>
                  <code>${entry.jsonPath}</code>
                  <span class="is-before">${this.formatDiffValue(entry.before)}</span>
                  <span aria-hidden="true">${this.t('tobe.diffArrow')}</span>
                  <span class="is-after">${this.formatDiffValue(entry.after)}</span>
                </article>
              `)}
            </div>
          </section>
        `)}
      </details>
    `;
    }
    renderTabContent() {
        if (this.activeTab === 'general') {
            return html `
        <new-release--widgets--general-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--general-102035>
      `;
        }
        if (this.activeTab === 'ontology') {
            return html `
        <new-release--widgets--ontology-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--ontology-102035>
      `;
        }
        if (this.activeTab === 'journeys') {
            return html `
        <new-release--widgets--journeys-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--journeys-102035>
      `;
        }
        if (this.activeTab === 'access') {
            return html `
        <new-release--widgets--access-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--access-102035>
      `;
        }
        if (this.activeTab === 'rules') {
            return html `
        <new-release--widgets--rules-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--rules-102035>
      `;
        }
        if (this.activeTab === 'workflows') {
            return html `
        <new-release--widgets--workflows-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--workflows-102035>
      `;
        }
        if (this.activeTab === 'integration') {
            return html `
        <new-release--widgets--integration-102035
          .project=${this.project}
          .moduleName=${this.moduleName}
          .version=${this.version}
          .data=${this.data}
          .t=${this.t}
        ></new-release--widgets--integration-102035>
      `;
        }
        return html `
      <section class="nr-index__placeholder">
        <span class="nr-index__placeholder-mark" aria-hidden="true"></span>
        <div>
          <h2>${this.t('tab.placeholder.title', { tab: this.t(`tab.${this.activeTab}`) })}</h2>
          <p>${this.t('tab.placeholder.body')}</p>
        </div>
      </section>
    `;
    }
    renderLoading() {
        return html `
      <div class="nr-index__loading" aria-live="polite">
        <span>${this.t('state.loading')}</span>
        <div></div><div></div><div></div>
      </div>
    `;
    }
    renderEmpty() {
        return html `
      <section class="nr-index__empty">
        <span aria-hidden="true"></span>
        <h2>${this.t('state.emptyTitle')}</h2>
        <p>${this.t('state.emptyBody')}</p>
      </section>
    `;
    }
    render() {
        const editableVersion = this.version === 'asis' || this.version === 'tobe';
        return html `
      <main class="nr-index" aria-busy=${this.loading ? 'true' : 'false'}>
        ${this.renderTabs()}

        ${this.renderTobeStatus()}

        ${this.loading ? this.renderLoading() : !this.data?.module ? this.renderEmpty() : html `
          ${this.data.errors.length || this.mutationError ? html `
            <section class="nr-index__errors">
              <strong>${this.t('state.errorTitle')}</strong>
              ${this.mutationError ? html `<p>${this.mutationError}</p>` : nothing}
              ${this.data.errors.map(error => html `<p>${this.t('state.errorPath', { path: error.path, message: error.message })}</p>`)}
            </section>
          ` : nothing}
          <section
            id=${`nr-panel-${this.activeTab}`}
            class="nr-index__content"
            role="tabpanel"
            aria-labelledby=${`nr-tab-${this.activeTab}`}
            tabindex="0"
          >${this.renderTabContent()}</section>
          ${this.renderDiffs()}
        `}

        ${editableVersion ? html `
          <footer class="nr-index__footer">
            <div>
              ${this.tabTobePaths().length ? html `<button class="nr-index__discard" type="button" ?disabled=${this.changing} @click=${() => void this.discardPaths(this.tabTobePaths())}>${this.t('tobe.discardTab')}</button>` : nothing}
              <span>${this.t('action.inDevelopment')}</span>
              <button type="button" disabled>${this.t('action.apply')}</button>
              <button type="button" disabled>${this.t('action.execute')}</button>
            </div>
          </footer>
        ` : nothing}
      </main>
    `;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseIndex102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseIndex102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseIndex102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseIndex102035.prototype, "data", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "activeTab", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "loading", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "changing", void 0);
__decorate([
    state()
], NewReleaseIndex102035.prototype, "mutationError", void 0);
NewReleaseIndex102035 = __decorate([
    customElement('new-release--widgets--index-102035')
], NewReleaseIndex102035);
export { NewReleaseIndex102035 };
