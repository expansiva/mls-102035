/// <mls fileReference="_102035_/l2/newRelease/widgets/workflows.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { announceNewReleaseChange, } from '/_102035_/l2/newRelease/editContract.js';
import { nextMemberId, normalizeWorkflows, workflowNextLabels, workflowOracleIssues, workflowStartTaskIds, workflowTaskCount, } from '/_102035_/l2/newRelease/widgets/workflowsModel.js';
let NewReleaseWorkflows102035 = class NewReleaseWorkflows102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--workflows-102035 {
  display: block;
}
new-release--widgets--workflows-102035 * {
  box-sizing: border-box;
}
new-release--widgets--workflows-102035 h2,
new-release--widgets--workflows-102035 h3,
new-release--widgets--workflows-102035 h4,
new-release--widgets--workflows-102035 p,
new-release--widgets--workflows-102035 dl,
new-release--widgets--workflows-102035 dd {
  margin: 0;
}
new-release--widgets--workflows-102035 button,
new-release--widgets--workflows-102035 input,
new-release--widgets--workflows-102035 select,
new-release--widgets--workflows-102035 textarea {
  font: inherit;
}
new-release--widgets--workflows-102035 button {
  cursor: pointer;
}
new-release--widgets--workflows-102035 code {
  font-family: var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--workflows-102035 input,
new-release--widgets--workflows-102035 select,
new-release--widgets--workflows-102035 textarea {
  width: 100%;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--workflows-102035 input,
new-release--widgets--workflows-102035 select {
  min-height: 2.25rem;
  padding: 0.42rem 0.58rem;
}
new-release--widgets--workflows-102035 textarea {
  min-height: 4.8rem;
  padding: 0.55rem 0.62rem;
  resize: vertical;
  line-height: 1.45;
}
new-release--widgets--workflows-102035 select[multiple] {
  min-height: 6.5rem;
}
new-release--widgets--workflows-102035 input:focus,
new-release--widgets--workflows-102035 select:focus,
new-release--widgets--workflows-102035 textarea:focus,
new-release--widgets--workflows-102035 button:focus-visible {
  border-color: var(--focus-border, #1273d4);
  outline: 2px solid color-mix(in srgb, var(--focus-border, #1273d4) 22%, transparent);
  outline-offset: 1px;
}
new-release--widgets--workflows-102035 .nr-workflows {
  display: grid;
  min-width: 0;
  color: var(--text-default, #2f3a48);
}
new-release--widgets--workflows-102035 .nr-workflows__hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.2rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: radial-gradient(circle at 80% -50%, color-mix(in srgb, var(--chart-series-3, #8250df) 20%, transparent), transparent 44%), linear-gradient(135deg, var(--surface-bg, #fff), color-mix(in srgb, var(--selected-bg, #e3f1ff) 42%, var(--surface-bg, #fff)));
}
new-release--widgets--workflows-102035 .nr-workflows__hero > div > span,
new-release--widgets--workflows-102035 .nr-workflows__catalog > header > span,
new-release--widgets--workflows-102035 .nr-workflows__detail > header span,
new-release--widgets--workflows-102035 .nr-workflows__trigger span,
new-release--widgets--workflows-102035 .nr-workflows__flow > header span,
new-release--widgets--workflows-102035 .nr-workflows__decisions > header span {
  color: var(--link-text, #0f62b8);
  font-size: 0.62rem;
  font-weight: 800;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__hero h2 {
  margin-top: 0.28rem;
  color: var(--text-strong, #111827);
  font-size: 1.5rem;
  letter-spacing: -0.03em;
}
new-release--widgets--workflows-102035 .nr-workflows__hero p {
  max-width: 48rem;
  margin-top: 0.42rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--workflows-102035 .nr-workflows__hero small {
  display: inline-flex;
  margin-top: 0.55rem;
  padding: 0.22rem 0.42rem;
  border-radius: 999px;
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
  font-size: 0.56rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__hero small.schema-v1 {
  background: var(--status-warning-bg, #fff1c2);
  color: var(--status-warning-text, #7a4b00);
}
new-release--widgets--workflows-102035 .nr-workflows__hero dl {
  display: flex;
  overflow: hidden;
  border: 1px solid color-mix(in srgb, var(--chart-series-3, #8250df) 25%, var(--border-subtle, #e4e9f0));
  border-radius: 0.82rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--workflows-102035 .nr-workflows__hero dl div {
  display: grid;
  min-width: 5rem;
  place-items: center;
  padding: 0.55rem 0.75rem;
}
new-release--widgets--workflows-102035 .nr-workflows__hero dl div + div {
  border-left: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--workflows-102035 .nr-workflows__hero dt {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.54rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__hero dd {
  order: -1;
  color: var(--text-strong, #111827);
  font-size: 1.2rem;
  font-weight: 800;
}
new-release--widgets--workflows-102035 .nr-workflows__workspace {
  display: grid;
  grid-template-columns: minmax(15rem, 0.72fr) minmax(0, 2.28fr);
  gap: 1rem;
  align-items: start;
  padding: 1rem 1.25rem;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog,
new-release--widgets--workflows-102035 .nr-workflows__detail,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail {
  overflow: hidden;
  min-width: 0;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.85rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  padding: 0.62rem 0.68rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > header button,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail button {
  border: 0;
  border-radius: 0.48rem;
  padding: 0.36rem 0.52rem;
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
  font-size: 0.61rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > button {
  display: grid;
  width: 100%;
  grid-template-columns: 1.8rem minmax(0, 1fr) auto;
  gap: 0.5rem;
  align-items: center;
  padding: 0.68rem;
  border: 0;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: transparent;
  color: var(--text-default, #2f3a48);
  text-align: left;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > button:hover {
  background: color-mix(in srgb, var(--selected-bg, #e3f1ff) 45%, transparent);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > button.is-active {
  border-left: 0.2rem solid var(--chart-series-3, #8250df);
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button > i {
  display: grid;
  width: 1.8rem;
  height: 1.8rem;
  place-items: center;
  border-radius: 0.52rem;
  background: color-mix(in srgb, var(--chart-series-3, #8250df) 14%, var(--surface-bg, #fff));
  color: var(--chart-series-3, #8250df);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog svg {
  width: 1.05rem;
  height: 1.05rem;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 1.7;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button > span {
  display: grid;
  min-width: 0;
  gap: 0.15rem;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button strong {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.68rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button small {
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.57rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button b {
  display: grid;
  min-width: 1.45rem;
  height: 1.45rem;
  place-items: center;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  font-size: 0.57rem;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > p {
  padding: 1.2rem 0.75rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
  text-align: center;
}
new-release--widgets--workflows-102035 .nr-workflows__detail {
  display: grid;
  gap: 0.8rem;
  padding: 0.9rem;
}
new-release--widgets--workflows-102035 .nr-workflows__detail > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1rem;
}
new-release--widgets--workflows-102035 .nr-workflows__detail > header h3 {
  margin-top: 0.22rem;
  color: var(--text-strong, #111827);
  font-size: 1.05rem;
}
new-release--widgets--workflows-102035 .nr-workflows__detail > header code {
  display: block;
  margin-top: 0.2rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
}
new-release--widgets--workflows-102035 .nr-button,
new-release--widgets--workflows-102035 .nr-danger {
  min-height: 2.1rem;
  flex: 0 0 auto;
  padding: 0.4rem 0.68rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.66rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-danger {
  border-color: color-mix(in srgb, var(--status-error-text, #ab2328) 38%, var(--border-default, #cfd8e3));
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--workflows-102035 .nr-workflows__title-input {
  min-width: min(30rem, 48vw);
  color: var(--text-strong, #111827);
  font-size: 1rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__process-description {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.75rem;
  line-height: 1.55;
}
new-release--widgets--workflows-102035 .nr-workflows__description {
  display: grid;
  gap: 0.28rem;
}
new-release--widgets--workflows-102035 .nr-workflows__description > span,
new-release--widgets--workflows-102035 .nr-workflows__task-form label > span,
new-release--widgets--workflows-102035 .nr-workflows__trigger label > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger {
  display: grid;
  grid-template-columns: 2.35rem minmax(0, 1fr);
  gap: 0.65rem;
  align-items: center;
  padding: 0.68rem;
  border: 1px solid color-mix(in srgb, var(--chart-series-3, #8250df) 27%, var(--border-subtle, #e4e9f0));
  border-radius: 0.7rem;
  background: linear-gradient(135deg, color-mix(in srgb, var(--chart-series-3, #8250df) 10%, var(--surface-bg, #fff)), var(--surface-bg, #fff));
}
new-release--widgets--workflows-102035 .nr-workflows__trigger > i {
  width: 2.35rem;
  height: 2.35rem;
  border-radius: 0.65rem;
  background: var(--chart-series-3, #8250df);
  box-shadow: inset 0 0 0 0.65rem color-mix(in srgb, var(--surface-bg, #fff) 78%, transparent);
}
new-release--widgets--workflows-102035 .nr-workflows__trigger > div {
  display: grid;
  gap: 0.12rem;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger strong {
  color: var(--text-strong, #111827);
  font-size: 0.72rem;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger.is-edit {
  grid-template-columns: repeat(2, minmax(0, 1fr));
  align-items: end;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger.is-edit > div,
new-release--widgets--workflows-102035 .nr-workflows__trigger.is-edit > label {
  display: grid;
  gap: 0.28rem;
}
new-release--widgets--workflows-102035 .nr-workflows__flow {
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.75rem;
}
new-release--widgets--workflows-102035 .nr-workflows__flow > header,
new-release--widgets--workflows-102035 .nr-workflows__decisions > header {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.62rem 0.72rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--workflows-102035 .nr-workflows__flow > header p,
new-release--widgets--workflows-102035 .nr-workflows__decisions > header p {
  margin-top: 0.18rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
}
new-release--widgets--workflows-102035 .nr-workflows__flow > header > strong,
new-release--widgets--workflows-102035 .nr-workflows__decisions > header > strong {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
}
new-release--widgets--workflows-102035 .nr-workflows__flow > div {
  display: flex;
  gap: 0.65rem;
  overflow-x: auto;
  align-items: stretch;
  padding: 0.78rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task {
  position: relative;
  display: grid;
  min-width: 13.5rem;
  max-width: 17rem;
  flex: 1 0 13.5rem;
  gap: 0.5rem;
  padding: 0.7rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-top: 0.2rem solid var(--chart-series-1, #1273d4);
  border-radius: 0.68rem;
  background: var(--surface-bg, #fff);
  box-shadow: 0 0.2rem 0.75rem color-mix(in srgb, var(--text-strong, #111827) 6%, transparent);
}
new-release--widgets--workflows-102035 .nr-workflows__task.kind-mechanical,
new-release--widgets--workflows-102035 .nr-workflows__task.kind-system {
  border-top-color: var(--chart-series-2, #0c8f77);
}
new-release--widgets--workflows-102035 .nr-workflows__task.kind-llm {
  border-top-color: var(--chart-series-3, #8250df);
}
new-release--widgets--workflows-102035 .nr-workflows__task.kind-wait {
  border-top-color: var(--chart-series-4, #d17a00);
}
new-release--widgets--workflows-102035 .nr-workflows__task:not(:last-child)::after {
  position: absolute;
  top: 50%;
  right: -0.58rem;
  width: 0.52rem;
  border-top: 1px solid var(--border-default, #cfd8e3);
  content: '';
}
new-release--widgets--workflows-102035 .nr-workflows__task > header {
  display: grid;
  grid-template-columns: 1.9rem minmax(0, 1fr) auto;
  gap: 0.45rem;
  align-items: center;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header i {
  display: grid;
  width: 1.9rem;
  height: 1.9rem;
  place-items: center;
  border-radius: 0.52rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
}
new-release--widgets--workflows-102035 .nr-workflows__task > header svg {
  width: 1.05rem;
  height: 1.05rem;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 1.7;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header > div {
  display: grid;
  min-width: 0;
  gap: 0.06rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header span {
  color: var(--link-text, #0f62b8);
  font-size: 0.5rem;
  font-weight: 800;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header code {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.58rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header b {
  padding: 0.18rem 0.32rem;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.49rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header button {
  width: 1.55rem;
  height: 1.55rem;
  border: 0;
  border-radius: 0.4rem;
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--workflows-102035 .nr-workflows__task h4 {
  color: var(--text-strong, #111827);
  font-size: 0.7rem;
  overflow-wrap: anywhere;
}
new-release--widgets--workflows-102035 .nr-workflows__task > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
  line-height: 1.45;
}
new-release--widgets--workflows-102035 .nr-workflows__task-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0.28rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task-meta span,
new-release--widgets--workflows-102035 .nr-workflows__task-meta code {
  padding: 0.18rem 0.3rem;
  border-radius: 0.35rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.51rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task > footer {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  align-items: center;
  padding-top: 0.45rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--workflows-102035 .nr-workflows__task > footer span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.5rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__task > footer code,
new-release--widgets--workflows-102035 .nr-workflows__task > footer strong {
  padding: 0.16rem 0.28rem;
  border-radius: 0.32rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.49rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task-form {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.45rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task-form label {
  display: grid;
  gap: 0.22rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task-form .is-wide {
  grid-column: 1 / -1;
}
new-release--widgets--workflows-102035 .nr-workflows__task-form textarea {
  min-height: 4.2rem;
}
new-release--widgets--workflows-102035 .nr-workflows__add-task {
  min-width: 10rem;
  min-height: 7rem;
  align-self: center;
  border: 1px dashed var(--selected-border, #1273d4);
  border-radius: 0.68rem;
  background: color-mix(in srgb, var(--selected-bg, #e3f1ff) 35%, transparent);
  color: var(--selected-text, #0d5296);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions {
  margin: 0 1.25rem 1.25rem;
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.8rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions > div {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.5rem;
  padding: 0.65rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article {
  display: grid;
  grid-template-columns: 0.55rem minmax(0, 1fr) auto;
  gap: 0.45rem;
  align-items: center;
  padding: 0.5rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.58rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article > i {
  width: 0.5rem;
  height: 0.5rem;
  border-radius: 999px;
  background: var(--text-muted, #5d6b7e);
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article.is-in > i {
  background: var(--status-success-text, #25640e);
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article > div {
  display: grid;
  min-width: 0;
  gap: 0.08rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article strong {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.61rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.49rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article > span {
  padding: 0.18rem 0.32rem;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.49rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article.is-in > span {
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--workflows-102035 .nr-workflows__issues {
  display: grid;
  gap: 0.38rem;
  padding: 0.65rem 0.72rem;
  border: 1px solid color-mix(in srgb, var(--status-warning-text, #7a4b00) 28%, var(--border-subtle, #e4e9f0));
  border-radius: 0.65rem;
  background: var(--status-warning-bg, #fff1c2);
}
new-release--widgets--workflows-102035 .nr-workflows__check {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto auto;
  gap: 0.65rem;
  align-items: center;
  padding: 0.58rem 0.68rem;
  border: 1px solid color-mix(in srgb, var(--status-success-text, #25640e) 24%, var(--border-subtle, #e4e9f0));
  border-radius: 0.65rem;
  background: color-mix(in srgb, var(--status-success-bg, #e2f5db) 58%, var(--surface-bg, #fff));
}
new-release--widgets--workflows-102035 .nr-workflows__check > div {
  display: grid;
  gap: 0.08rem;
}
new-release--widgets--workflows-102035 .nr-workflows__check span {
  color: var(--status-success-text, #25640e);
  font-size: 0.5rem;
  font-weight: 800;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__check strong {
  color: var(--text-strong, #111827);
  font-size: 0.63rem;
}
new-release--widgets--workflows-102035 .nr-workflows__check p,
new-release--widgets--workflows-102035 .nr-workflows__check small {
  color: var(--status-success-text, #25640e);
  font-size: 0.56rem;
}
new-release--widgets--workflows-102035 .nr-workflows__check.is-warned {
  border-color: color-mix(in srgb, var(--status-warning-text, #7a4b00) 26%, var(--border-subtle, #e4e9f0));
  background: var(--status-warning-bg, #fff1c2);
}
new-release--widgets--workflows-102035 .nr-workflows__check.is-failed {
  border-color: color-mix(in srgb, var(--status-error-text, #ab2328) 26%, var(--border-subtle, #e4e9f0));
  background: var(--status-error-bg, #fde8e9);
}
new-release--widgets--workflows-102035 .nr-workflows__issues > strong,
new-release--widgets--workflows-102035 .nr-workflows__issues > p {
  font-size: 0.64rem;
}
new-release--widgets--workflows-102035 .nr-workflows__issues > div {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 0.42rem;
}
new-release--widgets--workflows-102035 .nr-workflows__issues code {
  font-size: 0.52rem;
  font-weight: 700;
}
new-release--widgets--workflows-102035 .nr-workflows__issues p {
  font-size: 0.61rem;
}
new-release--widgets--workflows-102035 .nr-workflows__issues .is-error {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--workflows-102035 .nr-workflows__empty,
new-release--widgets--workflows-102035 .nr-workflows__unknown,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail {
  display: grid;
  min-height: 18rem;
  place-items: center;
  align-content: center;
  gap: 0.42rem;
  padding: 2rem;
  text-align: center;
}
new-release--widgets--workflows-102035 .nr-workflows__empty h2,
new-release--widgets--workflows-102035 .nr-workflows__unknown h2,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail h3 {
  color: var(--text-strong, #111827);
  font-size: 1rem;
}
new-release--widgets--workflows-102035 .nr-workflows__empty p,
new-release--widgets--workflows-102035 .nr-workflows__unknown p,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail p {
  max-width: 32rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--workflows-102035 .nr-workflows__unknown pre {
  width: 100%;
  max-height: 24rem;
  overflow: auto;
  padding: 0.75rem;
  border-radius: 0.65rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-default, #2f3a48);
  font-size: 0.58rem;
  text-align: left;
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer {
  position: sticky;
  z-index: 5;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.72rem 1.25rem;
  border-top: 1px solid var(--border-default, #cfd8e3);
  background: color-mix(in srgb, var(--surface-bg, #fff) 94%, transparent);
  box-shadow: 0 -0.5rem 1.4rem color-mix(in srgb, var(--text-strong, #111827) 8%, transparent);
  backdrop-filter: blur(10px);
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer > div {
  display: flex;
  gap: 0.5rem;
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer button {
  min-height: 2.15rem;
  padding: 0.42rem 0.72rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer button.is-primary {
  border-color: var(--action-primary-bg, #126fc2);
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer button:disabled {
  cursor: not-allowed;
  opacity: 0.48;
}
@media (max-width: 1120px) {
  new-release--widgets--workflows-102035 .nr-workflows__workspace {
    grid-template-columns: 1fr;
  }
  new-release--widgets--workflows-102035 .nr-workflows__decisions > div {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 720px) {
  new-release--widgets--workflows-102035 .nr-workflows__hero,
  new-release--widgets--workflows-102035 .nr-workflows__detail > header,
  new-release--widgets--workflows-102035 .nr-workflows__edit-footer {
    align-items: stretch;
    flex-direction: column;
  }
  new-release--widgets--workflows-102035 .nr-workflows__hero dl {
    align-self: flex-start;
  }
  new-release--widgets--workflows-102035 .nr-workflows__decisions > div,
  new-release--widgets--workflows-102035 .nr-workflows__trigger.is-edit,
  new-release--widgets--workflows-102035 .nr-workflows__task-form {
    grid-template-columns: 1fr;
  }
  new-release--widgets--workflows-102035 .nr-workflows__task-form .is-wide {
    grid-column: auto;
  }
  new-release--widgets--workflows-102035 .nr-workflows__title-input {
    min-width: 0;
  }
  new-release--widgets--workflows-102035 .nr-workflows__edit-footer > div {
    justify-content: flex-end;
  }
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.selectedProcessId = '';
        this.draft = null;
        this.gateIssues = [];
        this.suppliedIssues = [];
        this.editMessage = '';
    }
    createRenderRoot() { return this; }
    updated(changed) {
        if (!changed.has('data') || this.mode === 'edit')
            return;
        const processes = this.view().processes;
        if (!processes.some(process => process.processId === this.selectedProcessId)) {
            this.selectedProcessId = processes[0]?.processId || '';
        }
    }
    getDraft() {
        const artifact = this.currentArtifact();
        return artifact ? structuredClone(artifact) : null;
    }
    setIssues(issues) { this.suppliedIssues = workflowOracleIssues(issues); }
    sourceValue() { return this.data?.artifacts.workflows.value || null; }
    currentArtifact() {
        if (this.mode === 'edit' && this.draft)
            return this.draft;
        const view = normalizeWorkflows(this.sourceValue());
        return view.schema === 'v2' ? view.raw : null;
    }
    view() { return normalizeWorkflows(this.mode === 'edit' && this.draft ? this.draft : this.sourceValue()); }
    actors() { return this.data?.artifacts.access.value?.actors || []; }
    journeys() { return this.data?.artifacts.journeys.map(item => item.value).filter((item) => !!item) || []; }
    entities() { return this.data?.artifacts.entities.map(item => item.value).filter((item) => !!item) || []; }
    process() { return this.view().processes.find(item => item.processId === this.selectedProcessId) || null; }
    beginEdit() {
        const artifact = this.currentArtifact();
        if (!artifact)
            return;
        this.draft = structuredClone(artifact);
        this.mode = 'edit';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    cancelEdit() {
        this.draft = null;
        this.mode = 'view';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateDraft(next) {
        this.draft = next;
        this.dirty = true;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateProcess(patch) {
        if (!this.draft)
            return;
        this.updateDraft({ ...this.draft, processes: this.draft.processes.map(process => process.processId === this.selectedProcessId ? { ...process, ...patch } : process) });
    }
    addProcess() {
        const artifact = this.currentArtifact();
        if (!artifact)
            return;
        if (this.mode !== 'edit')
            this.beginEdit();
        const source = this.draft || artifact;
        const processId = nextMemberId('process', source.processes.map(process => process.processId));
        const process = {
            processId,
            title: this.t('workflows.newProcessTitle'),
            description: this.t('workflows.newProcessDescription'),
            trigger: { kind: 'manual', actorRef: this.actors()[0]?.actorId || '' },
            tasks: [],
        };
        this.selectedProcessId = processId;
        this.updateDraft({ ...source, processes: [...source.processes, process] });
    }
    removeProcess() {
        if (!this.draft)
            return;
        const processes = this.draft.processes.filter(process => process.processId !== this.selectedProcessId);
        const journeyDecisions = this.draft.journeyDecisions.map(decision => decision.processId === this.selectedProcessId
            ? { journeyId: decision.journeyId, inProcess: false }
            : decision);
        this.selectedProcessId = processes[0]?.processId || '';
        this.updateDraft({ ...this.draft, processes, journeyDecisions });
    }
    addTask() {
        if (!this.draft)
            return;
        const process = this.draft.processes.find(item => item.processId === this.selectedProcessId);
        if (!process)
            return;
        const taskId = nextMemberId('task', process.tasks.map(task => task.taskId));
        const task = { taskId, kind: 'wait', description: this.t('workflows.newTaskDescription'), next: [] };
        this.updateProcess({ tasks: [...process.tasks, task] });
    }
    updateTask(taskId, patch) {
        if (!this.draft)
            return;
        const process = this.draft.processes.find(item => item.processId === this.selectedProcessId);
        if (!process)
            return;
        this.updateProcess({ tasks: process.tasks.map(task => task.taskId === taskId ? { ...task, ...patch } : task) });
    }
    replaceTask(taskId, next) {
        if (!this.draft)
            return;
        const process = this.draft.processes.find(item => item.processId === this.selectedProcessId);
        if (!process)
            return;
        this.updateProcess({ tasks: process.tasks.map(task => task.taskId === taskId ? next : task) });
    }
    updateTaskKind(task, kind) {
        const base = { taskId: task.taskId, kind, description: task.description, next: task.next };
        if (kind === 'human') {
            base.actorRef = this.actors()[0]?.actorId || '';
            base.journeyRef = this.journeys()[0]?.journeyId || '';
        }
        else if (kind === 'mechanical' || kind === 'llm') {
            base.entityRef = this.entities()[0]?.entityId || '';
            base.effect = 'update';
        }
        this.replaceTask(task.taskId, base);
    }
    removeTask(taskId) {
        if (!this.draft)
            return;
        const process = this.draft.processes.find(item => item.processId === this.selectedProcessId);
        if (!process)
            return;
        this.updateProcess({ tasks: process.tasks.filter(task => task.taskId !== taskId).map(task => ({ ...task, next: task.next.filter(next => next !== taskId) })) });
    }
    async saveEdit() {
        if (!this.draft || !this.dirty)
            return;
        try {
            const gate = await import('/_102035_/l2/agentNewSolution5/steps/workflows50/gate.js');
            const result = gate.validateNs5Workflows(this.draft.processes, {
                moduleName: this.moduleName,
                actorIds: this.actors().map(actor => actor.actorId),
                journeys: this.journeys(),
                entities: this.entities(),
                journeyDecisions: this.draft.journeyDecisions,
            });
            this.gateIssues = result.issues;
            if (!result.ok) {
                this.editMessage = this.t('workflows.gateBlocked');
                return;
            }
            announceNewReleaseChange(this, { path: 'workflows.defs.ts', jsonPath: '$', value: structuredClone(this.draft) });
            this.cancelEdit();
        }
        catch (error) {
            this.editMessage = this.t('workflows.gateUnavailable', { message: error instanceof Error ? error.message : String(error) });
        }
    }
    taskIcon(kind) {
        if (kind === 'human')
            return svg `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="7" r="3"/><path d="M6 20c.5-4 2.5-6 6-6s5.5 2 6 6"/></svg>`;
        if (kind === 'llm')
            return svg `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v3M4.2 7.5l2.6 1.4M19.8 7.5l-2.6 1.4M5 17h14v-6H5Z"/><circle cx="9" cy="14" r="1"/><circle cx="15" cy="14" r="1"/></svg>`;
        if (kind === 'wait')
            return svg `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></svg>`;
        return svg `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 2 3.5 4-.2-.2 4 3.2 2.2-3.2 2.2.2 4-4-.2-2 3.5-2-3.5-4 .2.2-4L3 12.5l3.2-2.2-.2-4 4 .2Z"/><circle cx="12" cy="12.5" r="2.5"/></svg>`;
    }
    triggerSummary(process) {
        const trigger = process.trigger;
        if (!trigger)
            return this.t('workflows.trigger.undeclared');
        if (trigger.kind === 'scheduled')
            return trigger.schedule || this.t('workflows.notRecorded');
        if (trigger.kind === 'event')
            return trigger.event || this.t('workflows.notRecorded');
        return trigger.actorRef || this.t('workflows.notRecorded');
    }
    renderIssues() {
        const oracle = workflowOracleIssues([...(this.data?.validation.issues || []), ...this.suppliedIssues]);
        const issues = [...new Map([...oracle, ...this.gateIssues].map(issue => [`${issue.code}:${issue.message}`, issue])).values()];
        if (!issues.length && !this.editMessage)
            return this.renderI6();
        return html `${this.renderI6()}<section class="nr-workflows__issues" role="alert"><strong>${this.t('workflows.issues')}</strong>${this.editMessage ? html `<p>${this.editMessage}</p>` : nothing}${issues.map(issue => html `<div class=${`is-${issue.severity}`}><code>${issue.code}</code><p>${issue.message}</p></div>`)}</section>`;
    }
    renderI6() {
        const check = this.data?.finalizeReport?.checks.find(item => item.checkId === 'I6');
        if (!check)
            return nothing;
        return html `<section class=${`nr-workflows__check is-${check.status}`}><div><span>${this.t('workflows.i6')}</span><strong>${this.t('oracle.I6')}</strong></div><p>${this.t(`oracle.status.${check.status}`)}</p><small>${this.t('general.oracleCounts', { errors: check.errorCount, warnings: check.warningCount })}</small></section>`;
    }
    renderTask(process, task, index) {
        const isStart = workflowStartTaskIds(process).includes(task.taskId);
        const next = workflowNextLabels(process, task);
        const title = task.journeyRef || task.entityRef || task.taskId;
        if (this.mode === 'edit' && this.draft) {
            const draftProcess = this.draft.processes.find(item => item.processId === process.processId);
            const draftTask = draftProcess?.tasks.find(item => item.taskId === task.taskId);
            if (!draftTask)
                return nothing;
            const transitions = this.entities().find(entity => entity.entityId === draftTask.entityRef)?.transitions || [];
            return html `<article class=${`nr-workflows__task kind-${draftTask.kind}`}>
        <header><i>${this.taskIcon(draftTask.kind)}</i><div><span>${isStart ? this.t('workflows.start') : this.t('workflows.step', { number: index + 1 })}</span><code>${draftTask.taskId}</code></div><button type="button" title=${this.t('workflows.removeTask')} @click=${() => this.removeTask(draftTask.taskId)}>×</button></header>
        <div class="nr-workflows__task-form">
          <label><span>${this.t('workflows.taskKind')}</span><select @change=${(event) => this.updateTaskKind(draftTask, event.currentTarget.value)}>${['human', 'mechanical', 'llm', 'wait'].map(kind => html `<option value=${kind} ?selected=${draftTask.kind === kind}>${this.t(`workflows.kind.${kind}`)}</option>`)}</select></label>
          ${draftTask.kind === 'human' ? html `
            <label><span>${this.t('workflows.actor')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { actorRef: event.currentTarget.value })}>${this.actors().map(actor => html `<option value=${actor.actorId} ?selected=${draftTask.actorRef === actor.actorId}>${actor.title} · ${actor.actorId}</option>`)}</select></label>
            <label><span>${this.t('workflows.journey')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { journeyRef: event.currentTarget.value })}>${this.journeys().map(journey => html `<option value=${journey.journeyId} ?selected=${draftTask.journeyRef === journey.journeyId}>${journey.business.title}</option>`)}</select></label>
          ` : nothing}
          ${draftTask.kind === 'mechanical' || draftTask.kind === 'llm' ? html `
            <label><span>${this.t('workflows.entity')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { entityRef: event.currentTarget.value, transitionRef: undefined })}>${this.entities().map(entity => html `<option value=${entity.entityId} ?selected=${draftTask.entityRef === entity.entityId}>${entity.title}</option>`)}</select></label>
            <label><span>${this.t('workflows.effect')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { effect: event.currentTarget.value, transitionRef: undefined })}>${['create', 'update', 'transition'].map(effect => html `<option value=${effect} ?selected=${draftTask.effect === effect}>${this.t(`workflows.effect.${effect}`)}</option>`)}</select></label>
            ${draftTask.effect === 'transition' ? html `<label><span>${this.t('workflows.transition')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { transitionRef: event.currentTarget.value })}><option value="" ?selected=${!draftTask.transitionRef}>${this.t('workflows.choose')}</option>${transitions.map(transition => html `<option value=${transition.transitionId} ?selected=${draftTask.transitionRef === transition.transitionId}>${transition.transitionId}</option>`)}</select></label>` : nothing}
          ` : nothing}
          <label class="is-wide"><span>${this.t('workflows.taskDescription')}</span><textarea .value=${draftTask.description} @input=${(event) => this.updateTask(draftTask.taskId, { description: event.currentTarget.value })}></textarea></label>
          <label class="is-wide"><span>${this.t('workflows.next')}</span><select multiple @change=${(event) => this.updateTask(draftTask.taskId, { next: [...event.currentTarget.selectedOptions].map(option => option.value) })}>${draftProcess?.tasks.filter(item => item.taskId !== draftTask.taskId).map(item => html `<option value=${item.taskId} ?selected=${draftTask.next.includes(item.taskId)}>${item.taskId}</option>`)}</select></label>
        </div>
      </article>`;
        }
        return html `<article class=${`nr-workflows__task kind-${task.kind}`}><header><i>${this.taskIcon(task.kind)}</i><div><span>${isStart ? this.t('workflows.start') : this.t('workflows.step', { number: index + 1 })}</span><code>${task.taskId}</code></div><b>${this.t(`workflows.kind.${task.kind}`)}</b></header><h4>${title}</h4><p>${task.description}</p><div class="nr-workflows__task-meta">${task.actorRef ? html `<span>${this.t('workflows.actor')}: <strong>${task.actorRef}</strong></span>` : nothing}${task.effect ? html `<span>${this.t('workflows.effect')}: <strong>${this.t(`workflows.effect.${task.effect}`)}</strong></span>` : nothing}${task.transitionRef ? html `<code>${task.transitionRef}</code>` : nothing}</div><footer><span>${this.t('workflows.next')}</span>${next.length ? next.map(label => html `<code>${label}</code>`) : html `<strong>${this.t('workflows.end')}</strong>`}</footer></article>`;
    }
    renderProcess(process) {
        const editable = this.mode === 'edit' && this.draft;
        const draftProcess = editable ? this.draft.processes.find(item => item.processId === process.processId) : null;
        const trigger = draftProcess?.trigger;
        return html `<main class="nr-workflows__detail"><header><div><span>${this.t('workflows.selected')}</span>${editable ? html `<input class="nr-workflows__title-input" .value=${draftProcess.title} @input=${(event) => this.updateProcess({ title: event.currentTarget.value })}>` : html `<h3>${process.title}</h3>`}<code>${process.processId}</code></div>${this.mode === 'view' ? html `<button class="nr-button" type="button" @click=${() => this.beginEdit()}>${this.t('workflows.edit')}</button>` : html `<button class="nr-danger" type="button" @click=${() => this.removeProcess()}>${this.t('workflows.removeProcess')}</button>`}</header>${editable ? html `<label class="nr-workflows__description"><span>${this.t('workflows.processDescription')}</span><textarea .value=${draftProcess.description} @input=${(event) => this.updateProcess({ description: event.currentTarget.value })}></textarea></label><section class="nr-workflows__trigger is-edit"><div><span>${this.t('workflows.trigger')}</span><select @change=${(event) => { const kind = event.currentTarget.value; this.updateProcess({ trigger: kind === 'manual' ? { kind, actorRef: this.actors()[0]?.actorId || '' } : kind === 'event' ? { kind, event: '' } : { kind, schedule: '' } }); }}>${['manual', 'event', 'scheduled'].map(kind => html `<option value=${kind} ?selected=${trigger.kind === kind}>${this.t(`workflows.trigger.${kind}`)}</option>`)}</select></div>${trigger.kind === 'manual' ? html `<label><span>${this.t('workflows.actor')}</span><select @change=${(event) => this.updateProcess({ trigger: { kind: 'manual', actorRef: event.currentTarget.value } })}>${this.actors().map(actor => html `<option value=${actor.actorId} ?selected=${trigger.actorRef === actor.actorId}>${actor.title}</option>`)}</select></label>` : html `<label><span>${trigger.kind === 'event' ? this.t('workflows.event') : this.t('workflows.schedule')}</span><input .value=${trigger.kind === 'event' ? trigger.event || '' : trigger.schedule || ''} @input=${(event) => this.updateProcess({ trigger: trigger.kind === 'event' ? { kind: 'event', event: event.currentTarget.value } : { kind: 'scheduled', schedule: event.currentTarget.value } })}></label>`}</section>` : html `<p class="nr-workflows__process-description">${process.description}</p><section class="nr-workflows__trigger"><i></i><div><span>${this.t('workflows.trigger')}</span><strong>${process.trigger ? this.t(`workflows.trigger.${process.trigger.kind}`) : this.t('workflows.trigger.undeclared')}</strong><code>${this.triggerSummary(process)}</code></div></section>`}${this.renderIssues()}<section class="nr-workflows__flow"><header><div><span>${this.t('workflows.flow')}</span><p>${this.t('workflows.flowDescription')}</p></div><strong>${this.t('workflows.taskCount', { count: process.tasks.length })}</strong></header><div>${process.tasks.map((task, index) => this.renderTask(process, task, index))}${editable ? html `<button class="nr-workflows__add-task" type="button" @click=${() => this.addTask()}>+ ${this.t('workflows.addTask')}</button>` : nothing}</div></section></main>`;
    }
    renderDecisions() {
        const decisions = this.view().journeyDecisions;
        if (!decisions.length)
            return nothing;
        return html `<section class="nr-workflows__decisions"><header><div><span>${this.t('workflows.decisions')}</span><p>${this.t('workflows.decisionsDescription')}</p></div><strong>${decisions.length}</strong></header><div>${decisions.map(decision => html `<article class=${decision.inProcess ? 'is-in' : 'is-out'}><i></i><div><strong>${this.journeys().find(journey => journey.journeyId === decision.journeyId)?.business.title || decision.journeyId}</strong><code>${decision.journeyId}</code></div><span>${decision.inProcess ? this.t('workflows.inProcess') : this.t('workflows.outProcess')}</span></article>`)}</div></section>`;
    }
    render() {
        const view = this.view();
        if (!this.sourceValue())
            return html `<section class="nr-workflows__empty"><h2>${this.t('workflows.emptyTitle')}</h2><p>${this.t('workflows.emptyBody')}</p></section>`;
        if (view.schema === 'unknown')
            return html `<section class="nr-workflows__unknown" role="alert"><h2>${this.t('workflows.unknownTitle')}</h2><p>${this.t('workflows.unknownBody', { version: view.schemaVersion || this.t('workflows.notRecorded') })}</p><pre>${JSON.stringify(view.raw, null, 2)}</pre></section>`;
        const process = this.process();
        return html `<section class="nr-workflows"><header class="nr-workflows__hero"><div><span>${this.t('workflows.eyebrow')}</span><h2>${this.t('workflows.title')}</h2><p>${this.t('workflows.description')}</p><small class=${`schema-${view.schema}`}>${this.t(`workflows.schema.${view.schema}`)}</small></div><dl><div><dt>${this.t('workflows.processes')}</dt><dd>${view.processes.length}</dd></div><div><dt>${this.t('workflows.tasks')}</dt><dd>${workflowTaskCount(view.processes)}</dd></div><div><dt>${this.t('workflows.decisions')}</dt><dd>${view.journeyDecisions.length}</dd></div></dl></header><div class="nr-workflows__workspace"><aside class="nr-workflows__catalog"><header><span>${this.t('workflows.catalog')}</span>${view.schema === 'v2' ? html `<button type="button" @click=${() => this.addProcess()}>+ ${this.t('workflows.addProcess')}</button>` : nothing}</header>${view.processes.map(item => html `<button type="button" class=${item.processId === this.selectedProcessId ? 'is-active' : ''} @click=${() => { this.selectedProcessId = item.processId; }}><i>${this.taskIcon(item.tasks[0]?.kind || 'wait')}</i><span><strong>${item.title}</strong><small>${this.triggerSummary(item)}</small></span><b>${item.tasks.length}</b></button>`)}${!view.processes.length ? html `<p>${this.t('workflows.noProcesses')}</p>` : nothing}</aside>${process ? this.renderProcess(process) : html `<section class="nr-workflows__empty-detail"><h3>${this.t('workflows.noSelection')}</h3><p>${this.t('workflows.noSelectionDescription')}</p>${view.schema === 'v2' ? html `<button type="button" @click=${() => this.addProcess()}>+ ${this.t('workflows.addProcess')}</button>` : nothing}</section>`}</div>${this.renderDecisions()}${this.mode === 'edit' ? html `<footer class="nr-workflows__edit-footer"><span>${this.dirty ? this.t('workflows.unsaved') : this.t('workflows.noChanges')}</span><div><button type="button" @click=${() => this.cancelEdit()}>${this.t('workflows.cancel')}</button><button class="is-primary" type="button" ?disabled=${!this.dirty} @click=${() => void this.saveEdit()}>${this.t('workflows.save')}</button></div></footer>` : nothing}</section>`;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseWorkflows102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseWorkflows102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseWorkflows102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseWorkflows102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseWorkflows102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseWorkflows102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseWorkflows102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "selectedProcessId", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "draft", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "gateIssues", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "suppliedIssues", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "editMessage", void 0);
NewReleaseWorkflows102035 = __decorate([
    customElement('new-release--widgets--workflows-102035')
], NewReleaseWorkflows102035);
export { NewReleaseWorkflows102035 };
