/// <mls fileReference="_102035_/l2/newRelease/widgets/workflows.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { ns5OntologyEntityViews } from '/_102035_/l2/solution/ontologyView.js';
import { hasItemDiff, idScope } from '/_102035_/l2/newRelease/helpers/itemDiffs.js';
import { changedDot } from '/_102035_/l2/newRelease/helpers/changedDot.js';
import { announceNewReleaseChange, requestNewReleasePresentation, requestNewReleaseEdit, canDiscardNewReleaseDraft, } from '/_102035_/l2/newRelease/editContract.js';
import { isEditableWorkflowSchema, workflowEdges, appendWorkflowTask, workflowNewTaskError, WORKFLOW_TASK_KINDS, normalizeWorkflows, workflowNextLabels, workflowOracleIssues, workflowStartTaskIds, } from '/_102035_/l2/newRelease/widgets/workflowsModel.js';
import { renderNewReleaseIcon } from '/_102035_/l2/newRelease/widgets/iconPicker.js';
import { WORKFLOW_ICON_DEFAULTS, withNewReleaseIcon } from '/_102035_/l2/newRelease/widgets/iconModel.js';
let NewReleaseWorkflows102035 = class NewReleaseWorkflows102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--workflows-102035 {
  display: block;
}
new-release--widgets--workflows-102035 * {
  box-sizing: border-box;
}
new-release--widgets--workflows-102035 h2,
new-release--widgets--workflows-102035 h3,
new-release--widgets--workflows-102035 h4,
new-release--widgets--workflows-102035 p,
new-release--widgets--workflows-102035 dl,
new-release--widgets--workflows-102035 dd {
  margin: 0;
}
new-release--widgets--workflows-102035 button,
new-release--widgets--workflows-102035 input,
new-release--widgets--workflows-102035 select,
new-release--widgets--workflows-102035 textarea {
  font: inherit;
}
new-release--widgets--workflows-102035 button {
  cursor: pointer;
}
new-release--widgets--workflows-102035 code {
  font-family: var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--workflows-102035 input,
new-release--widgets--workflows-102035 select,
new-release--widgets--workflows-102035 textarea {
  width: 100%;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--workflows-102035 input,
new-release--widgets--workflows-102035 select {
  min-height: 2.25rem;
  padding: 0.42rem 0.58rem;
}
new-release--widgets--workflows-102035 textarea {
  min-height: 4.8rem;
  padding: 0.55rem 0.62rem;
  resize: vertical;
  line-height: 1.45;
}
new-release--widgets--workflows-102035 select[multiple] {
  min-height: 6.5rem;
}
new-release--widgets--workflows-102035 input:focus,
new-release--widgets--workflows-102035 select:focus,
new-release--widgets--workflows-102035 textarea:focus,
new-release--widgets--workflows-102035 button:focus-visible {
  border-color: var(--focus-border, #1273d4);
  outline: 2px solid color-mix(in srgb, var(--focus-border, #1273d4) 22%, transparent);
  outline-offset: 1px;
}
new-release--widgets--workflows-102035 .nr-workflows {
  display: grid;
  min-width: 0;
  color: var(--text-default, #2f3a48);
}
new-release--widgets--workflows-102035 .nr-workflows__hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.2rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: radial-gradient(circle at 80% -50%, color-mix(in srgb, var(--chart-series-3, #8250df) 20%, transparent), transparent 44%), linear-gradient(135deg, var(--surface-bg, #fff), color-mix(in srgb, var(--selected-bg, #e3f1ff) 42%, var(--surface-bg, #fff)));
}
new-release--widgets--workflows-102035 .nr-workflows__hero > div > span,
new-release--widgets--workflows-102035 .nr-workflows__catalog > header > span,
new-release--widgets--workflows-102035 .nr-workflows__detail > header span,
new-release--widgets--workflows-102035 .nr-workflows__trigger span,
new-release--widgets--workflows-102035 .nr-workflows__flow > header span,
new-release--widgets--workflows-102035 .nr-workflows__decisions > header span {
  color: var(--link-text, #0f62b8);
  font-size: 0.62rem;
  font-weight: 800;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__hero h2 {
  margin-top: 0.28rem;
  color: var(--text-strong, #111827);
  font-size: 1.5rem;
  letter-spacing: -0.03em;
}
new-release--widgets--workflows-102035 .nr-workflows__hero p {
  max-width: 48rem;
  margin-top: 0.42rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--workflows-102035 .nr-workflows__hero small {
  display: inline-flex;
  margin-top: 0.55rem;
  padding: 0.22rem 0.42rem;
  border-radius: 999px;
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
  font-size: 0.56rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__hero small.schema-v1 {
  background: var(--status-warning-bg, #fff1c2);
  color: var(--status-warning-text, #7a4b00);
}
new-release--widgets--workflows-102035 .nr-workflows__hero dl {
  display: flex;
  overflow: hidden;
  border: 1px solid color-mix(in srgb, var(--chart-series-3, #8250df) 25%, var(--border-subtle, #e4e9f0));
  border-radius: 0.82rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--workflows-102035 .nr-workflows__hero dl div {
  display: grid;
  min-width: 5rem;
  place-items: center;
  padding: 0.55rem 0.75rem;
}
new-release--widgets--workflows-102035 .nr-workflows__hero dl div + div {
  border-left: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--workflows-102035 .nr-workflows__hero dt {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.54rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__hero dd {
  order: -1;
  color: var(--text-strong, #111827);
  font-size: 1.2rem;
  font-weight: 800;
}
new-release--widgets--workflows-102035 .nr-workflows__workspace {
  display: grid;
  grid-template-columns: minmax(15rem, 0.72fr) minmax(0, 2.28fr);
  gap: 1rem;
  align-items: start;
  padding: 1rem 1.25rem;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog,
new-release--widgets--workflows-102035 .nr-workflows__detail,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail {
  overflow: hidden;
  min-width: 0;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.85rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  padding: 0.62rem 0.68rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > header button,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail button {
  border: 0;
  border-radius: 0.48rem;
  padding: 0.36rem 0.52rem;
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
  font-size: 0.61rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > button {
  display: grid;
  width: 100%;
  grid-template-columns: 1.8rem minmax(0, 1fr) auto;
  gap: 0.5rem;
  align-items: center;
  padding: 0.68rem;
  border: 0;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: transparent;
  color: var(--text-default, #2f3a48);
  text-align: left;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > button:hover {
  background: color-mix(in srgb, var(--selected-bg, #e3f1ff) 45%, transparent);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > button.is-active {
  border-left: 0.2rem solid var(--chart-series-3, #8250df);
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button > i {
  display: grid;
  width: 1.8rem;
  height: 1.8rem;
  place-items: center;
  border-radius: 0.52rem;
  background: color-mix(in srgb, var(--chart-series-3, #8250df) 14%, var(--surface-bg, #fff));
  color: var(--chart-series-3, #8250df);
}
new-release--widgets--workflows-102035 .nr-workflows__catalog svg {
  width: 1.05rem;
  height: 1.05rem;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 1.7;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button > span {
  display: grid;
  min-width: 0;
  gap: 0.15rem;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button strong {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.68rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button small {
  overflow: hidden;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.57rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog button b {
  display: grid;
  min-width: 1.45rem;
  height: 1.45rem;
  place-items: center;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  font-size: 0.57rem;
}
new-release--widgets--workflows-102035 .nr-workflows__catalog > p {
  padding: 1.2rem 0.75rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
  text-align: center;
}
new-release--widgets--workflows-102035 .nr-workflows__detail {
  display: grid;
  gap: 0.8rem;
  padding: 0.9rem;
}
new-release--widgets--workflows-102035 .nr-workflows__detail > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1rem;
}
new-release--widgets--workflows-102035 .nr-workflows__detail > header h3 {
  margin-top: 0.22rem;
  color: var(--text-strong, #111827);
  font-size: 1.05rem;
}
new-release--widgets--workflows-102035 .nr-workflows__detail > header code {
  display: block;
  margin-top: 0.2rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.56rem;
}
new-release--widgets--workflows-102035 .nr-button,
new-release--widgets--workflows-102035 .nr-danger {
  min-height: 2.1rem;
  flex: 0 0 auto;
  padding: 0.4rem 0.68rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.66rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-danger {
  border-color: color-mix(in srgb, var(--status-error-text, #ab2328) 38%, var(--border-default, #cfd8e3));
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--workflows-102035 .nr-workflows__title-input {
  min-width: min(30rem, 48vw);
  color: var(--text-strong, #111827);
  font-size: 1rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__process-description {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.75rem;
  line-height: 1.55;
}
new-release--widgets--workflows-102035 .nr-workflows__description {
  display: grid;
  gap: 0.28rem;
}
new-release--widgets--workflows-102035 .nr-workflows__description > span,
new-release--widgets--workflows-102035 .nr-workflows__task-form label > span,
new-release--widgets--workflows-102035 .nr-workflows__trigger label > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger {
  display: grid;
  grid-template-columns: 2.35rem minmax(0, 1fr);
  gap: 0.65rem;
  align-items: center;
  padding: 0.68rem;
  border: 1px solid color-mix(in srgb, var(--chart-series-3, #8250df) 27%, var(--border-subtle, #e4e9f0));
  border-radius: 0.7rem;
  background: linear-gradient(135deg, color-mix(in srgb, var(--chart-series-3, #8250df) 10%, var(--surface-bg, #fff)), var(--surface-bg, #fff));
}
new-release--widgets--workflows-102035 .nr-workflows__trigger > i {
  width: 2.35rem;
  height: 2.35rem;
  border-radius: 0.65rem;
  background: var(--chart-series-3, #8250df);
  box-shadow: inset 0 0 0 0.65rem color-mix(in srgb, var(--surface-bg, #fff) 78%, transparent);
}
new-release--widgets--workflows-102035 .nr-workflows__trigger > div {
  display: grid;
  gap: 0.12rem;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger strong {
  color: var(--text-strong, #111827);
  font-size: 0.72rem;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.59rem;
}
new-release--widgets--workflows-102035 .nr-workflows__duty {
  justify-self: start;
  margin-top: 0.18rem;
  padding: 0.16rem 0.38rem;
  border-radius: 999px;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.55rem;
  font-style: normal;
  font-weight: 700;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger.is-edit {
  grid-template-columns: repeat(2, minmax(0, 1fr));
  align-items: end;
}
new-release--widgets--workflows-102035 .nr-workflows__trigger.is-edit > div,
new-release--widgets--workflows-102035 .nr-workflows__trigger.is-edit > label {
  display: grid;
  gap: 0.28rem;
}
new-release--widgets--workflows-102035 .nr-workflows__flow {
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.75rem;
}
new-release--widgets--workflows-102035 .nr-workflows__flow > header,
new-release--widgets--workflows-102035 .nr-workflows__decisions > header {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.62rem 0.72rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--workflows-102035 .nr-workflows__flow > header p,
new-release--widgets--workflows-102035 .nr-workflows__decisions > header p {
  margin-top: 0.18rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
}
new-release--widgets--workflows-102035 .nr-workflows__flow > header > strong,
new-release--widgets--workflows-102035 .nr-workflows__decisions > header > strong {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.6rem;
}
new-release--widgets--workflows-102035 .nr-workflows__flow > div {
  display: flex;
  gap: 0.65rem;
  overflow-x: auto;
  align-items: stretch;
  padding: 0.78rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task {
  position: relative;
  display: grid;
  min-width: 13.5rem;
  max-width: 17rem;
  flex: 1 0 13.5rem;
  gap: 0.5rem;
  padding: 0.7rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-top: 0.2rem solid var(--chart-series-1, #1273d4);
  border-radius: 0.68rem;
  background: var(--surface-bg, #fff);
  box-shadow: 0 0.2rem 0.75rem color-mix(in srgb, var(--text-strong, #111827) 6%, transparent);
}
new-release--widgets--workflows-102035 .nr-workflows__task.kind-mechanical,
new-release--widgets--workflows-102035 .nr-workflows__task.kind-system {
  border-top-color: var(--chart-series-2, #0c8f77);
}
new-release--widgets--workflows-102035 .nr-workflows__task.kind-llm {
  border-top-color: var(--chart-series-3, #8250df);
}
new-release--widgets--workflows-102035 .nr-workflows__task.kind-wait {
  border-top-color: var(--chart-series-4, #d17a00);
}
new-release--widgets--workflows-102035 .nr-workflows__task.kind-alert {
  border-top-color: var(--chart-series-5, #c2410c);
}
new-release--widgets--workflows-102035 .nr-workflows__task:not(:last-child)::after {
  position: absolute;
  top: 50%;
  right: -0.58rem;
  width: 0.52rem;
  border-top: 1px solid var(--border-default, #cfd8e3);
  content: none;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header {
  display: grid;
  grid-template-columns: 1.9rem minmax(0, 1fr) auto;
  gap: 0.45rem;
  align-items: center;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header i {
  display: grid;
  width: 1.9rem;
  height: 1.9rem;
  place-items: center;
  border-radius: 0.52rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
}
new-release--widgets--workflows-102035 .nr-workflows__task > header svg {
  width: 1.05rem;
  height: 1.05rem;
  fill: none;
  stroke: currentColor;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-width: 1.7;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header > div {
  display: grid;
  min-width: 0;
  gap: 0.06rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header span {
  color: var(--link-text, #0f62b8);
  font-size: 0.5rem;
  font-weight: 800;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header code {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.58rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header b {
  padding: 0.18rem 0.32rem;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.49rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task > header button {
  width: 1.55rem;
  height: 1.55rem;
  border: 0;
  border-radius: 0.4rem;
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--workflows-102035 .nr-workflows__task h4 {
  color: var(--text-strong, #111827);
  font-size: 0.7rem;
  overflow-wrap: anywhere;
}
new-release--widgets--workflows-102035 .nr-workflows__task > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
  line-height: 1.45;
}
new-release--widgets--workflows-102035 .nr-workflows__task-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0.28rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task-meta span,
new-release--widgets--workflows-102035 .nr-workflows__task-meta code {
  padding: 0.18rem 0.3rem;
  border-radius: 0.35rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.51rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task > footer {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  align-items: center;
  padding-top: 0.45rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--workflows-102035 .nr-workflows__task > footer span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.5rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__task > footer code,
new-release--widgets--workflows-102035 .nr-workflows__task > footer strong {
  padding: 0.16rem 0.28rem;
  border-radius: 0.32rem;
  background: var(--selected-bg, #e3f1ff);
  color: var(--selected-text, #0d5296);
  font-size: 0.49rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task-form {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.45rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task-form label {
  display: grid;
  gap: 0.22rem;
}
new-release--widgets--workflows-102035 .nr-workflows__task-form .is-wide {
  grid-column: 1 / -1;
}
new-release--widgets--workflows-102035 .nr-workflows__task-form textarea {
  min-height: 4.2rem;
}
new-release--widgets--workflows-102035 .nr-workflows__add-task {
  min-width: 10rem;
  min-height: 7rem;
  align-self: center;
  border: 1px dashed var(--selected-border, #1273d4);
  border-radius: 0.68rem;
  background: color-mix(in srgb, var(--selected-bg, #e3f1ff) 35%, transparent);
  color: var(--selected-text, #0d5296);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions {
  margin: 0 1.25rem 1.25rem;
  overflow: hidden;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.8rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions > div {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.5rem;
  padding: 0.65rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article {
  display: grid;
  grid-template-columns: 0.55rem minmax(0, 1fr) auto;
  gap: 0.45rem;
  align-items: center;
  padding: 0.5rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.58rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article > i {
  width: 0.5rem;
  height: 0.5rem;
  border-radius: 999px;
  background: var(--text-muted, #5d6b7e);
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article.is-in > i {
  background: var(--status-success-text, #25640e);
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article > div {
  display: grid;
  min-width: 0;
  gap: 0.08rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article strong {
  overflow: hidden;
  color: var(--text-strong, #111827);
  font-size: 0.61rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article code {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.49rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article > span {
  padding: 0.18rem 0.32rem;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.49rem;
}
new-release--widgets--workflows-102035 .nr-workflows__decisions article.is-in > span {
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--workflows-102035 .nr-workflows__issues {
  display: grid;
  gap: 0.38rem;
  padding: 0.65rem 0.72rem;
  border: 1px solid color-mix(in srgb, var(--status-warning-text, #7a4b00) 28%, var(--border-subtle, #e4e9f0));
  border-radius: 0.65rem;
  background: var(--status-warning-bg, #fff1c2);
}
new-release--widgets--workflows-102035 .nr-workflows__check {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto auto;
  gap: 0.65rem;
  align-items: center;
  padding: 0.58rem 0.68rem;
  border: 1px solid color-mix(in srgb, var(--status-success-text, #25640e) 24%, var(--border-subtle, #e4e9f0));
  border-radius: 0.65rem;
  background: color-mix(in srgb, var(--status-success-bg, #e2f5db) 58%, var(--surface-bg, #fff));
}
new-release--widgets--workflows-102035 .nr-workflows__check > div {
  display: grid;
  gap: 0.08rem;
}
new-release--widgets--workflows-102035 .nr-workflows__check span {
  color: var(--status-success-text, #25640e);
  font-size: 0.5rem;
  font-weight: 800;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
new-release--widgets--workflows-102035 .nr-workflows__check strong {
  color: var(--text-strong, #111827);
  font-size: 0.63rem;
}
new-release--widgets--workflows-102035 .nr-workflows__check p,
new-release--widgets--workflows-102035 .nr-workflows__check small {
  color: var(--status-success-text, #25640e);
  font-size: 0.56rem;
}
new-release--widgets--workflows-102035 .nr-workflows__check.is-warned {
  border-color: color-mix(in srgb, var(--status-warning-text, #7a4b00) 26%, var(--border-subtle, #e4e9f0));
  background: var(--status-warning-bg, #fff1c2);
}
new-release--widgets--workflows-102035 .nr-workflows__check.is-failed {
  border-color: color-mix(in srgb, var(--status-error-text, #ab2328) 26%, var(--border-subtle, #e4e9f0));
  background: var(--status-error-bg, #fde8e9);
}
new-release--widgets--workflows-102035 .nr-workflows__issues > strong,
new-release--widgets--workflows-102035 .nr-workflows__issues > p {
  font-size: 0.64rem;
}
new-release--widgets--workflows-102035 .nr-workflows__issues > div {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 0.42rem;
}
new-release--widgets--workflows-102035 .nr-workflows__issues code {
  font-size: 0.52rem;
  font-weight: 700;
}
new-release--widgets--workflows-102035 .nr-workflows__issues p {
  font-size: 0.61rem;
}
new-release--widgets--workflows-102035 .nr-workflows__issues .is-error {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--workflows-102035 .nr-workflows__empty,
new-release--widgets--workflows-102035 .nr-workflows__unknown,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail {
  display: grid;
  min-height: 18rem;
  place-items: center;
  align-content: center;
  gap: 0.42rem;
  padding: 2rem;
  text-align: center;
}
new-release--widgets--workflows-102035 .nr-workflows__empty h2,
new-release--widgets--workflows-102035 .nr-workflows__unknown h2,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail h3 {
  color: var(--text-strong, #111827);
  font-size: 1rem;
}
new-release--widgets--workflows-102035 .nr-workflows__empty p,
new-release--widgets--workflows-102035 .nr-workflows__unknown p,
new-release--widgets--workflows-102035 .nr-workflows__empty-detail p {
  max-width: 32rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--workflows-102035 .nr-workflows__unknown pre {
  width: 100%;
  max-height: 24rem;
  overflow: auto;
  padding: 0.75rem;
  border-radius: 0.65rem;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-default, #2f3a48);
  font-size: 0.58rem;
  text-align: left;
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer {
  position: sticky;
  z-index: 5;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.72rem 1.25rem;
  border-top: 1px solid var(--border-default, #cfd8e3);
  background: color-mix(in srgb, var(--surface-bg, #fff) 94%, transparent);
  box-shadow: 0 -0.5rem 1.4rem color-mix(in srgb, var(--text-strong, #111827) 8%, transparent);
  backdrop-filter: blur(10px);
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer > span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer > div {
  display: flex;
  gap: 0.5rem;
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer button {
  min-height: 2.15rem;
  padding: 0.42rem 0.72rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
  font-weight: 750;
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer button.is-primary {
  border-color: var(--action-primary-bg, #126fc2);
  background: var(--action-primary-bg, #126fc2);
  color: var(--action-primary-text, #fff);
}
new-release--widgets--workflows-102035 .nr-workflows__edit-footer button:disabled {
  cursor: not-allowed;
  opacity: 0.48;
}
@media (max-width: 1120px) {
  new-release--widgets--workflows-102035 .nr-workflows__workspace {
    grid-template-columns: 1fr;
  }
  new-release--widgets--workflows-102035 .nr-workflows__decisions > div {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 720px) {
  new-release--widgets--workflows-102035 .nr-workflows__hero,
  new-release--widgets--workflows-102035 .nr-workflows__detail > header,
  new-release--widgets--workflows-102035 .nr-workflows__edit-footer {
    align-items: stretch;
    flex-direction: column;
  }
  new-release--widgets--workflows-102035 .nr-workflows__hero dl {
    align-self: flex-start;
  }
  new-release--widgets--workflows-102035 .nr-workflows__decisions > div,
  new-release--widgets--workflows-102035 .nr-workflows__trigger.is-edit,
  new-release--widgets--workflows-102035 .nr-workflows__task-form {
    grid-template-columns: 1fr;
  }
  new-release--widgets--workflows-102035 .nr-workflows__task-form .is-wide {
    grid-column: auto;
  }
  new-release--widgets--workflows-102035 .nr-workflows__title-input {
    min-width: 0;
  }
  new-release--widgets--workflows-102035 .nr-workflows__edit-footer > div {
    justify-content: flex-end;
  }
}
new-release--widgets--workflows-102035 .nr-workflows__cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(17rem, 1fr));
  gap: 1rem;
  padding: 1rem;
}
new-release--widgets--workflows-102035 .nr-workflows__card,
new-release--widgets--workflows-102035 .nr-workflows__node {
  display: grid;
  gap: 0.5rem;
  padding: 1rem;
  text-align: left;
  border: 1px solid var(--border-default, #354158);
  border-radius: 0.75rem;
  background: var(--surface-bg, #151c2b);
  color: var(--text-default, #dce5f5);
}
new-release--widgets--workflows-102035 .nr-workflows__card:hover,
new-release--widgets--workflows-102035 .nr-workflows__node:hover {
  border-color: var(--focus-border, #729cff);
}
new-release--widgets--workflows-102035 .nr-workflows__graph {
  position: relative;
}
new-release--widgets--workflows-102035 .nr-workflows__edges {
  position: absolute;
  inset: 0;
  pointer-events: none;
  color: var(--text-muted, #9aacc9);
}
new-release--widgets--workflows-102035 .nr-workflows__edges > path {
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
}
new-release--widgets--workflows-102035 .nr-workflows__node {
  position: absolute;
  top: 0;
  width: 230px;
  grid-template-rows: 24px 1.2em 1.2em 1.2em;
  gap: 0.25rem;
  overflow: hidden;
}
new-release--widgets--workflows-102035 .nr-workflows__node > strong,
new-release--widgets--workflows-102035 .nr-workflows__node > code,
new-release--widgets--workflows-102035 .nr-workflows__node > span {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--workflows-102035 .nr-workflows__node svg {
  width: 24px;
  height: 24px;
  fill: none;
  stroke: currentColor;
}
new-release--widgets--workflows-102035 .nr-workflows__task-form {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
new-release--widgets--workflows-102035 .nr-workflows__detail > .nr-workflows__task {
  max-width: none;
  width: 100%;
}
new-release--widgets--workflows-102035 .nr-workflows__functions {
  display: grid;
  gap: 0.5rem;
}
new-release--widgets--workflows-102035 .nr-workflows__functions article {
  padding: 0.75rem;
  border: 1px solid var(--border-subtle, #354158);
  border-radius: 0.5rem;
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.mode = 'view';
        this.dirty = false;
        this.selectedProcessId = '';
        this.selectedTaskId = '';
        this.adding = false;
        this.newId = '';
        this.saving = false;
        this.snapshot = '';
        this.draft = null;
        this.gateIssues = [];
        this.suppliedIssues = [];
        this.editMessage = '';
    }
    createRenderRoot() { return this; }
    updated(changed) {
        if (changed.has('data') || changed.has('version') || changed.has('moduleName')) {
            this.cancelEdit();
            this.selectedProcessId = '';
            this.selectedTaskId = '';
        }
        if (['data', 'selectedProcessId', 'selectedTaskId', 'mode', 'draft', 'adding', 't'].some(key => changed.has(key)))
            this.present();
    }
    taskTitle(task) {
        return task.title || this.journeys().find(item => item.journeyId === task.journeyRef)?.business.title || task.taskId;
    }
    present() {
        const presentation = {
            detail: !!this.selectedTaskId || this.adding,
            canBack: !!this.selectedProcessId,
            filters: ['manual', 'scheduled', 'event'].map(kind => ({ id: kind, label: this.t(`workflows.trigger.${kind}`), rootIds: this.view().processes.filter(process => process.trigger?.kind === kind).map(process => JSON.stringify([process.processId])) })),
            nodes: this.view().processes.map(process => ({ id: JSON.stringify([process.processId]), label: process.title, value: `${process.trigger?.kind || ''} ${process.description}`, changed: this.changedProcess(process.processId), children: process.tasks.map(task => ({ id: JSON.stringify([process.processId, task.taskId]), label: this.taskTitle(task), value: `${task.taskId} ${task.description}`, changed: this.changedTask(process.processId, task.taskId), children: [] })) })),
            select: id => { const [processId, taskId = '', action] = JSON.parse(id); if (action === 'new') {
                this.select(processId);
                this.openNewTask();
            }
            else
                this.select(processId, taskId); },
            back: () => this.back(),
        };
        this.dispatchEvent(new CustomEvent('nr-view-state', { bubbles: true, composed: true, detail: presentation }));
    }
    select(processId, taskId = '') {
        if (this.saving || !canDiscardNewReleaseDraft(this))
            return;
        if (taskId && this.version === 'asis' && this.currentArtifact()) {
            requestNewReleaseEdit(this, JSON.stringify([processId, taskId]));
            return;
        }
        this.cancelEdit();
        this.selectedProcessId = processId;
        this.selectedTaskId = taskId;
        if (taskId && !this.version.startsWith('release:'))
            this.beginEdit();
        requestNewReleasePresentation(this, 'graph');
    }
    openNewTask() {
        if (this.version === 'asis') {
            requestNewReleaseEdit(this, JSON.stringify([this.selectedProcessId, '', 'new']));
            return;
        }
        this.adding = true;
        this.newId = '';
        this.beginEdit();
    }
    back() {
        if (this.saving || !canDiscardNewReleaseDraft(this))
            return;
        const task = !!this.selectedTaskId || this.adding;
        this.cancelEdit();
        this.selectedTaskId = '';
        if (!task)
            this.selectedProcessId = '';
        requestNewReleasePresentation(this, 'graph');
        this.present();
    }
    changedProcess(id) { return hasItemDiff(this.data?.diffs || [], 'workflows.defs.ts', idScope('processes', 'processId', id)); }
    changedTask(processId, taskId) {
        return hasItemDiff(this.data?.diffs || [], 'workflows.defs.ts', `${idScope('processes', 'processId', processId)}.tasks[taskId=${encodeURIComponent(taskId)}]`);
    }
    getDraft() {
        const artifact = this.currentArtifact();
        return artifact ? structuredClone(artifact) : null;
    }
    setIssues(issues) { this.suppliedIssues = workflowOracleIssues(issues); }
    sourceValue() { return this.data?.artifacts.workflows.value || null; }
    currentArtifact() {
        if (this.mode === 'edit' && this.draft)
            return this.draft;
        const view = normalizeWorkflows(this.sourceValue());
        return isEditableWorkflowSchema(view.schema) ? view.raw : null;
    }
    view() { return normalizeWorkflows(this.mode === 'edit' && this.draft ? this.draft : this.sourceValue()); }
    actors() { return this.data?.artifacts.access.value?.actors || []; }
    journeys() { return this.data?.artifacts.journeys.map(item => item.value).filter((item) => !!item) || []; }
    entities() { return this.data?.artifacts.entities.map(item => item.value).filter((item) => !!item) || []; }
    process() { return this.view().processes.find(item => item.processId === this.selectedProcessId) || null; }
    beginEdit() {
        const artifact = this.currentArtifact();
        if (!artifact)
            return;
        if (this.version.startsWith('release:'))
            return;
        this.draft = structuredClone(artifact);
        this.snapshot = JSON.stringify(artifact);
        this.mode = 'edit';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    cancelEdit() {
        this.adding = false;
        if (!normalizeWorkflows(this.sourceValue()).processes.find(process => process.processId === this.selectedProcessId)?.tasks.some(task => task.taskId === this.selectedTaskId))
            this.selectedTaskId = '';
        this.draft = null;
        this.mode = 'view';
        this.dirty = false;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateDraft(next) {
        this.draft = next;
        this.dirty = JSON.stringify(next) !== this.snapshot;
        this.gateIssues = [];
        this.editMessage = '';
    }
    updateProcess(patch) {
        if (!this.draft)
            return;
        this.updateDraft({ ...this.draft, processes: this.draft.processes.map(process => process.processId === this.selectedProcessId ? { ...process, ...patch } : process) });
    }
    addTask() {
        if (!this.draft)
            this.beginEdit();
        if (!this.draft)
            return;
        const process = this.draft.processes.find(item => item.processId === this.selectedProcessId);
        if (!process)
            return;
        const error = workflowNewTaskError(this.newId, process.tasks.map(task => task.taskId));
        if (error) {
            this.editMessage = this.t(`workflows.newId.${error}`);
            return;
        }
        this.updateDraft(appendWorkflowTask(this.draft, process.processId, this.newId));
        this.selectedTaskId = this.newId;
        this.adding = false;
        this.newId = '';
    }
    updateTask(taskId, patch) {
        if (!this.draft)
            return;
        const process = this.draft.processes.find(item => item.processId === this.selectedProcessId);
        if (!process)
            return;
        this.updateProcess({ tasks: process.tasks.map(task => task.taskId === taskId ? { ...task, ...patch } : task) });
    }
    replaceTask(taskId, next) {
        if (!this.draft)
            return;
        const process = this.draft.processes.find(item => item.processId === this.selectedProcessId);
        if (!process)
            return;
        this.updateProcess({ tasks: process.tasks.map(task => task.taskId === taskId ? next : task) });
    }
    updateTaskKind(task, kind) {
        const { actorRef, journeyRef, entityRef, effect, transitionRef, wake, ...rest } = task;
        const base = { ...rest, kind };
        if (kind === 'wait')
            base.wake = { mode: 'none' };
        if (kind === 'human') {
            base.actorRef = this.actors()[0]?.actorId || '';
            base.journeyRef = this.journeys()[0]?.journeyId || '';
        }
        else if (kind === 'mechanical' || kind === 'llm') {
            base.entityRef = this.entities()[0]?.entityId || '';
            base.effect = 'update';
        }
        else if (kind === 'alert') {
            base.actorRef = this.actors()[0]?.actorId || '';
        }
        this.replaceTask(task.taskId, base);
    }
    async saveEdit() {
        if (!this.draft || !this.dirty || this.saving || this.version.startsWith('release:'))
            return;
        if (this.draft.processes.some(process => process.tasks.some(task => !task.description.trim()))) {
            this.editMessage = this.t('workflows.descriptionRequired');
            return;
        }
        this.saving = true;
        try {
            const gate = await import('/_102035_/l2/solution/gates/workflows50/gate.js');
            const result = gate.validateNs5Workflows(this.draft.processes, {
                moduleName: this.moduleName,
                actorIds: this.actors().map(actor => actor.actorId),
                journeys: this.journeys(),
                entities: ns5OntologyEntityViews(this.entities()),
                journeyDecisions: this.draft.journeyDecisions,
            });
            this.gateIssues = result.issues;
            if (!result.ok) {
                this.editMessage = this.t('workflows.gateBlocked');
                return;
            }
            await announceNewReleaseChange(this, { path: 'workflows.defs.ts', jsonPath: '$', value: structuredClone(this.draft) });
            this.cancelEdit();
        }
        catch (error) {
            this.editMessage = this.t('workflows.gateUnavailable', { message: error instanceof Error ? error.message : String(error) });
        }
        finally {
            this.saving = false;
        }
    }
    /** ns5_48: derived, never written — "Recurring duty · <schedule> · <actor>". */
    recurringDutyLabel(process) {
        const schedule = process.trigger?.schedule?.trim() || this.t('workflows.notRecorded');
        const actor = process.tasks.find(task => task.actorRef)?.actorRef || this.t('workflows.notRecorded');
        return `${this.t('workflows.recurringDuty')} · ${schedule} · ${actor}`;
    }
    triggerSummary(process) {
        const trigger = process.trigger;
        if (!trigger)
            return this.t('workflows.trigger.undeclared');
        if (trigger.kind === 'scheduled')
            return trigger.schedule || this.t('workflows.notRecorded');
        if (trigger.kind === 'event')
            return trigger.event || this.t('workflows.notRecorded');
        return trigger.actorRef || this.t('workflows.notRecorded');
    }
    renderIssues() {
        const oracle = workflowOracleIssues([...(this.data?.validation.issues || []), ...this.suppliedIssues]);
        const issues = [...new Map([...oracle, ...this.gateIssues].map(issue => [`${issue.code}:${issue.message}`, issue])).values()];
        if (!issues.length && !this.editMessage)
            return this.renderI6();
        return html `${this.renderI6()}<section class="nr-workflows__issues" role="alert"><strong>${this.t('workflows.issues')}</strong>${this.editMessage ? html `<p>${this.editMessage}</p>` : nothing}${issues.map(issue => html `<div class=${`is-${issue.severity}`}><code>${issue.code}</code><p>${issue.message}</p></div>`)}</section>`;
    }
    renderI6() {
        const check = this.data?.finalizeReport?.checks.find(item => item.checkId === 'I6');
        if (!check)
            return nothing;
        return html `<section class=${`nr-workflows__check is-${check.status}`}><div><span>${this.t('workflows.i6')}</span><strong>${this.t('oracle.I6')}</strong></div><p>${this.t(`oracle.status.${check.status}`)}</p><small>${this.t('general.oracleCounts', { errors: check.errorCount, warnings: check.warningCount })}</small></section>`;
    }
    renderTask(process, task, index) {
        const isStart = workflowStartTaskIds(process).includes(task.taskId);
        const next = workflowNextLabels(process, task);
        const title = this.taskTitle(task);
        if (this.mode === 'edit' && this.draft) {
            const draftProcess = this.draft.processes.find(item => item.processId === process.processId);
            const draftTask = draftProcess?.tasks.find(item => item.taskId === task.taskId);
            if (!draftTask)
                return nothing;
            const transitions = this.entities().find(entity => entity.entityId === draftTask.entityRef)?.transitions || [];
            return html `<article class=${`nr-workflows__task kind-${draftTask.kind}`}>
        <header><i>${renderNewReleaseIcon(draftTask.icon, WORKFLOW_ICON_DEFAULTS[draftTask.kind])}</i><div><span>${isStart ? this.t('workflows.start') : this.t('workflows.step', { number: index + 1 })}</span><code>${draftTask.taskId}</code></div><input readonly aria-label=${this.t('workflows.taskId')} .value=${draftTask.taskId}></header>
        <div class="nr-workflows__task-form">
          <new-release--widgets--icon-picker-102035 .value=${draftTask.icon || ''} .fallback=${WORKFLOW_ICON_DEFAULTS[draftTask.kind]} .t=${this.t} @nr-icon-selected=${(event) => this.replaceTask(draftTask.taskId, withNewReleaseIcon(draftTask, event.detail))}></new-release--widgets--icon-picker-102035>
          <label><span>${this.t('workflows.taskKind')}</span><select @change=${(event) => this.updateTaskKind(draftTask, event.currentTarget.value)}>${WORKFLOW_TASK_KINDS.map(kind => html `<option value=${kind} ?selected=${draftTask.kind === kind}>${this.t(`workflows.kind.${kind}`)}</option>`)}</select></label>
          ${draftTask.kind === 'human' ? html `
            <label><span>${this.t('workflows.actor')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { actorRef: event.currentTarget.value })}>${this.actors().map(actor => html `<option value=${actor.actorId} ?selected=${draftTask.actorRef === actor.actorId}>${actor.title} · ${actor.actorId}</option>`)}</select></label>
            <label><span>${this.t('workflows.journey')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { journeyRef: event.currentTarget.value })}>${this.journeys().map(journey => html `<option value=${journey.journeyId} ?selected=${draftTask.journeyRef === journey.journeyId}>${journey.business.title}</option>`)}</select></label>
          ` : nothing}
          ${draftTask.kind === 'alert' ? html `
            <label><span>${this.t('workflows.actor')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { actorRef: event.currentTarget.value })}>${this.actors().map(actor => html `<option value=${actor.actorId} ?selected=${draftTask.actorRef === actor.actorId}>${actor.title} · ${actor.actorId}</option>`)}</select></label>
          ` : nothing}
          ${draftTask.kind === 'mechanical' || draftTask.kind === 'llm' ? html `
            <label><span>${this.t('workflows.entity')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { entityRef: event.currentTarget.value, transitionRef: undefined })}>${this.entities().map(entity => html `<option value=${entity.entityId} ?selected=${draftTask.entityRef === entity.entityId}>${entity.title}</option>`)}</select></label>
            <label><span>${this.t('workflows.effect')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { effect: event.currentTarget.value, transitionRef: undefined })}>${['create', 'update', 'transition'].map(effect => html `<option value=${effect} ?selected=${draftTask.effect === effect}>${this.t(`workflows.effect.${effect}`)}</option>`)}</select></label>
            ${draftTask.effect === 'transition' ? html `<label><span>${this.t('workflows.transition')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { transitionRef: event.currentTarget.value })}><option value="" ?selected=${!draftTask.transitionRef}>${this.t('workflows.choose')}</option>${transitions.map(transition => html `<option value=${transition.transitionId} ?selected=${draftTask.transitionRef === transition.transitionId}>${transition.transitionId}</option>`)}</select></label>` : nothing}
          ` : nothing}
          ${draftTask.kind === 'wait' ? html `<label><span>${this.t('workflows.wakeMode')}</span><select @change=${(event) => this.updateTask(draftTask.taskId, { wake: event.currentTarget.value === 'periodic' ? { mode: 'periodic', every: draftTask.wake?.every || '' } : { mode: 'none' } })}>${['none', 'periodic'].map(mode => html `<option value=${mode} ?selected=${(draftTask.wake?.mode || 'none') === mode}>${this.t(`workflows.wake.${mode}`)}</option>`)}</select></label>${draftTask.wake?.mode === 'periodic' ? html `<label><span>${this.t('workflows.wakeEvery')}</span><input .value=${draftTask.wake.every || ''} @input=${(event) => this.updateTask(draftTask.taskId, { wake: { mode: 'periodic', every: event.currentTarget.value } })}></label>` : nothing}` : nothing}
          <label class="is-wide"><span>${this.t('workflows.taskDescription')}</span><textarea .value=${draftTask.description} @input=${(event) => this.updateTask(draftTask.taskId, { description: event.currentTarget.value })}></textarea></label>
          <label class="is-wide"><span>${this.t('workflows.next')}</span><select multiple @change=${(event) => this.updateTask(draftTask.taskId, { next: [...event.currentTarget.selectedOptions].map(option => option.value) })}>${draftProcess?.tasks.map(item => html `<option value=${item.taskId} ?selected=${draftTask.next.includes(item.taskId)}>${item.taskId}</option>`)}</select></label>
        </div>
      </article>`;
        }
        const wake = task.kind === 'wait' && task.wake?.mode === 'periodic' && task.wake.every
            ? html `<span>${this.t('workflows.wakePeriodic', { every: task.wake.every })}</span>`
            : nothing;
        return html `<article class=${`nr-workflows__task kind-${task.kind}`}><header><i>${renderNewReleaseIcon(task.icon, WORKFLOW_ICON_DEFAULTS[task.kind])}</i><div><span>${isStart ? this.t('workflows.start') : this.t('workflows.step', { number: index + 1 })}</span><code>${task.taskId}</code></div><b>${this.t(`workflows.kind.${task.kind}`)}</b></header><h4>${title}</h4><p>${task.description}</p><div class="nr-workflows__task-meta">${task.actorRef ? html `<span>${this.t('workflows.actor')}: <strong>${task.actorRef}</strong></span>` : nothing}${task.effect ? html `<span>${this.t('workflows.effect')}: <strong>${this.t(`workflows.effect.${task.effect}`)}</strong></span>` : nothing}${task.transitionRef ? html `<code>${task.transitionRef}</code>` : nothing}${wake}</div><footer><span>${this.t('workflows.next')}</span>${next.length ? next.map(label => html `<code>${label}</code>`) : html `<strong>${this.t('workflows.end')}</strong>`}</footer></article>`;
    }
    renderFunctions(process) {
        const functions = process.functions;
        return html `<section class="nr-workflows__functions"><header><div><span>${this.t('workflows.functions')}</span></div><strong>${this.t('workflows.functionCount', { count: functions.length })}</strong></header><div>${functions.map(item => html `<article><header><code>${item.functionId}</code></header><p>${item.description}</p></article>`)}</div></section>`;
    }
    renderProcess(process) {
        const task = process.tasks.find(item => item.taskId === this.selectedTaskId);
        if (this.adding)
            return html `<section class="nr-workflows__detail"><label>${this.t('workflows.taskId')}<input .value=${this.newId} @input=${(event) => { this.newId = event.currentTarget.value; }}></label><button class="nr-button" @click=${() => this.addTask()}>${this.t('workflows.addTask')}</button>${this.renderIssues()}</section>`;
        if (task)
            return html `<main class="nr-workflows__detail">${this.mode === 'view' && !this.version.startsWith('release:') && isEditableWorkflowSchema(this.view().schema) ? html `<button class="nr-button" @click=${() => this.beginEdit()}>${this.t('workflows.edit')}</button>` : nothing}${this.renderTask(process, task, process.tasks.indexOf(task))}${this.renderIssues()}</main>`;
        const edges = workflowEdges(process);
        const width = Math.max(400, process.tasks.length * 260);
        const nodeHeight = 125;
        return html `<main class="nr-workflows__detail"><header><div><h3>${process.title}</h3><code>${process.processId}</code><p>${process.description}</p><p>${this.t('workflows.trigger')}: ${this.triggerSummary(process)}</p><p>${this.t('workflows.room')}: ${this.t(`workflows.room.${process.room}`)}</p></div>${!this.version.startsWith('release:') && isEditableWorkflowSchema(this.view().schema) ? html `<button class="nr-button" @click=${this.openNewTask}>${this.t('workflows.addTask')}</button>` : nothing}</header>
      <section class="nr-workflows__graph" style=${`width:${width}px;min-height:${220 + edges.length * 22}px`}>
      <svg class="nr-workflows__edges" width=${width} height=${220 + edges.length * 22} aria-label=${this.t('workflows.connections')} role="img"><defs><marker id="nr-workflow-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="currentColor"/></marker></defs>${edges.map((edge, index) => { const x1 = edge.from * 260 + 115; const x2 = edge.to * 260 + 130; const y = 190 + index * 22; return svg `<path d=${`M ${x1} ${nodeHeight} C ${x1} ${y}, ${x2} ${y}, ${x2} ${nodeHeight}`} marker-end="url(#nr-workflow-arrow)"/><title>${process.tasks[edge.from].taskId} → ${edge.id}</title>`; })}</svg>
      ${process.tasks.map((item, index) => html `<button class=${`nr-workflows__node kind-${item.kind}`} style=${`left:${index * 260}px;height:${nodeHeight}px`} aria-label=${this.taskTitle(item)} @click=${() => this.select(process.processId, item.taskId)}><i>${renderNewReleaseIcon(item.icon, WORKFLOW_ICON_DEFAULTS[item.kind])}</i><strong>${this.taskTitle(item)}</strong>${changedDot(this.changedTask(process.processId, item.taskId), this.t)}<code>${item.taskId}</code><span>${this.t(`workflows.kind.${item.kind}`)}</span></button>`)}</section>${this.renderFunctions(process)}${this.renderIssues()}</main>`;
    }
    renderDecisions() {
        const decisions = this.view().journeyDecisions;
        if (!decisions.length)
            return nothing;
        return html `<section class="nr-workflows__decisions"><header><div><span>${this.t('workflows.decisions')}</span><p>${this.t('workflows.decisionsDescription')}</p></div><strong>${decisions.length}</strong></header><div>${decisions.map(decision => html `<article class=${decision.inProcess ? 'is-in' : 'is-out'}><i></i><div><strong>${this.journeys().find(journey => journey.journeyId === decision.journeyId)?.business.title || decision.journeyId}</strong><code>${decision.journeyId}</code></div><span>${decision.inProcess ? this.t('workflows.inProcess') : this.t('workflows.outProcess')}</span></article>`)}</div></section>`;
    }
    render() {
        const view = this.view();
        if (!this.sourceValue())
            return html `<section class="nr-workflows__empty"><h2>${this.t('workflows.emptyTitle')}</h2><p>${this.t('workflows.emptyBody')}</p></section>`;
        if (view.schema === 'unknown')
            return html `<section class="nr-workflows__unknown" role="alert"><h2>${this.t('workflows.unknownTitle')}</h2><p>${this.t('workflows.unknownBody', { version: view.schemaVersion || this.t('workflows.notRecorded') })}</p><pre>${JSON.stringify(view.raw, null, 2)}</pre></section>`;
        const process = this.process();
        return html `<section class="nr-workflows">${process ? this.renderProcess(process) : html `<div class="nr-workflows__cards">${view.processes.map(item => html `<button class="nr-workflows__card" @click=${() => this.select(item.processId)}><h3>${item.title}${changedDot(this.changedProcess(item.processId), this.t)}</h3><code>${item.processId}</code><p>${item.description}</p><span>${this.t('workflows.trigger')}: ${item.trigger ? this.t(`workflows.trigger.${item.trigger.kind}`) : this.t('workflows.trigger.undeclared')} · ${this.triggerSummary(item)}</span><strong>${this.t('workflows.taskCount', { count: item.tasks.length })}</strong></button>`)}</div>${this.renderDecisions()}`}${this.mode === 'edit' ? html `<footer class="nr-workflows__edit-footer"><span>${this.dirty ? this.t('workflows.unsaved') : this.t('workflows.noChanges')}</span><div><button ?disabled=${this.saving} @click=${() => { if (canDiscardNewReleaseDraft(this))
            this.cancelEdit(); }}>${this.t('workflows.cancel')}</button><button class="is-primary" ?disabled=${!this.dirty || this.saving || this.adding} @click=${() => void this.saveEdit()}>${this.t('workflows.save')}</button></div></footer>` : nothing}</section>`;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseWorkflows102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseWorkflows102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseWorkflows102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseWorkflows102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseWorkflows102035.prototype, "t", void 0);
__decorate([
    property({ type: String })
], NewReleaseWorkflows102035.prototype, "mode", void 0);
__decorate([
    property({ type: Boolean })
], NewReleaseWorkflows102035.prototype, "dirty", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "selectedProcessId", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "selectedTaskId", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "adding", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "newId", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "saving", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "draft", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "gateIssues", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "suppliedIssues", void 0);
__decorate([
    state()
], NewReleaseWorkflows102035.prototype, "editMessage", void 0);
NewReleaseWorkflows102035 = __decorate([
    customElement('new-release--widgets--workflows-102035')
], NewReleaseWorkflows102035);
export { NewReleaseWorkflows102035 };
