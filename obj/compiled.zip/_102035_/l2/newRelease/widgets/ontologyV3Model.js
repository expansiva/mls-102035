/// <mls fileReference="_102035_/l2/newRelease/widgets/ontologyV3Model.ts" enhancement="_blank" />
import { NEW_RELEASE_ONTOLOGY_V3_SCHEMA_VERSION } from '/_102035_/l2/newRelease/ontologyV3Contract.js';
export function isOntologyV3Index(value) {
    return !!value
        && typeof value === 'object'
        && value.schemaVersion === NEW_RELEASE_ONTOLOGY_V3_SCHEMA_VERSION;
}
export function isOntologyV3Entity(value) {
    return !!value
        && typeof value === 'object'
        && value.schemaVersion === NEW_RELEASE_ONTOLOGY_V3_SCHEMA_VERSION;
}
export function ontologyPlatformFile(path) {
    const match = /^\/_([0-9]+)_\/l([1-4])\/(.+)\/([^/]+)\.defs\.ts$/u.exec(path);
    if (!match)
        throw new Error(`Invalid platform ontology path: ${path}`);
    return {
        project: Number(match[1]),
        level: Number(match[2]),
        folder: match[3],
        shortName: match[4],
        extension: '.defs.ts',
    };
}
export function ontologyNodeLeafCount(nodes) {
    return nodes.reduce((count, node) => {
        if (node.children?.length)
            return count + ontologyNodeLeafCount(node.children);
        return count + 1;
    }, 0);
}
export function ontologyV3FieldCount(view) {
    return view.columns.length + ontologyNodeLeafCount(view.details);
}
export function buildOntologyV3Graph(index, views, colors) {
    const moduleIds = new Set(index.entities.map(entity => entity.entityId));
    const platformIds = new Set();
    for (const link of index.relationships) {
        if (!moduleIds.has(link.from))
            platformIds.add(link.from);
        if (!moduleIds.has(link.to))
            platformIds.add(link.to);
    }
    const viewById = new Map(views.map(view => [view.entityId, view]));
    const roleColor = colors[0] || '#1677c8';
    const entityColor = colors[1] || '#008f77';
    const platformColor = colors[3] || '#7b61a8';
    const categories = [
        { name: 'role', itemStyle: { color: roleColor } },
        { name: 'entity', itemStyle: { color: entityColor } },
        { name: 'platform', itemStyle: { color: platformColor } },
    ];
    const nodes = index.entities.map(entity => {
        const view = viewById.get(entity.entityId);
        return {
            id: entity.entityId,
            title: view?.title || entity.entityId,
            value: view?.description || '',
            category: entity.kind === 'role' ? 0 : 1,
            symbolSize: entity.kind === 'role' ? 62 : 70,
            detailBranches: view?.details.map(branch => branch.id) || [],
        };
    });
    for (const id of platformIds) {
        nodes.push({
            id,
            title: id,
            value: 'platform',
            category: 2,
            symbolSize: 54,
            detailBranches: [],
            ghost: true,
            itemStyle: { color: 'transparent', borderColor: platformColor, borderType: 'dashed', borderWidth: 2, opacity: .9 },
        });
    }
    const links = index.relationships.map(link => ({
        source: link.from,
        target: link.to,
        name: link.relationshipId,
        value: link.mode === 'mdmRelationship' ? (link.catalogType || link.relationshipId) : link.mode === 'throughTable' ? (link.through || link.relationshipId) : (link.field || link.relationshipId),
        lineStyle: {
            type: link.mode === 'mdmRelationship' ? 'dashed' : link.mode === 'throughTable' ? 'dotted' : 'solid',
            width: link.mode === 'fk' ? 2.2 : 1.8,
            opacity: link.derived ? .62 : .86,
        },
    }));
    return { nodes, links, categories };
}
