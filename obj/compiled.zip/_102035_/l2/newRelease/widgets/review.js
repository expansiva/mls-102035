/// <mls fileReference="_102035_/l2/newRelease/widgets/review.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { readModuleMenu } from '/_102035_/l2/newRelease/helpers/menuReader.js';
import { readReviewArtifact } from '/_102035_/l2/newRelease/helpers/backendReader.js';
import { readReviewPoolBoxes } from '/_102035_/l2/newRelease/helpers/poolBoxes.js';
import { actorIdFromKey, buildReviewView, MENU_ACTIONS, REVIEW_ALL_ACTORS, } from '/_102035_/l2/newRelease/widgets/reviewModel.js';
import { backendTone, buildBackendReview, parseEffortSummary } from '/_102035_/l2/newRelease/widgets/backendReviewModel.js';
const EMPTY_MENU = { status: 'missing', path: '' };
const EMPTY_ARTIFACT = { status: 'missing', path: '' };
let NewReleaseReview102035 = class NewReleaseReview102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`new-release--widgets--review-102035 {
  display: block;
}
new-release--widgets--review-102035 * {
  box-sizing: border-box;
}
new-release--widgets--review-102035 h2,
new-release--widgets--review-102035 h3,
new-release--widgets--review-102035 p,
new-release--widgets--review-102035 ul,
new-release--widgets--review-102035 li {
  margin: 0;
}
new-release--widgets--review-102035 button,
new-release--widgets--review-102035 select {
  font: inherit;
}
new-release--widgets--review-102035 button {
  cursor: pointer;
}
new-release--widgets--review-102035 code {
  font-family: var(--font-family-mono, ui-monospace, monospace);
}
new-release--widgets--review-102035 select {
  min-height: 2.25rem;
  width: 100%;
  padding: 0.42rem 0.58rem;
  border: 1px solid var(--border-default, #cfd8e3);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  color: var(--text-default, #2f3a48);
}
new-release--widgets--review-102035 select:focus {
  border-color: var(--focus-border, #1273d4);
  outline: 2px solid color-mix(in srgb, var(--focus-border, #1273d4) 20%, transparent);
}
new-release--widgets--review-102035 .nr-review {
  display: grid;
  min-width: 0;
  color: var(--text-default, #2f3a48);
  container-type: inline-size;
}
new-release--widgets--review-102035 .nr-review__hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.2rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: linear-gradient(135deg, var(--surface-bg, #fff), color-mix(in srgb, var(--selected-bg, #e3f1ff) 46%, var(--surface-bg, #fff)));
}
new-release--widgets--review-102035 .nr-review__hero span,
new-release--widgets--review-102035 .nr-review__detail > header span,
new-release--widgets--review-102035 .nr-review__detail section > span,
new-release--widgets--review-102035 .nr-review__pool summary,
new-release--widgets--review-102035 .nr-review__pool h3,
new-release--widgets--review-102035 .nr-review__toolbar label span,
new-release--widgets--review-102035 .nr-review__removed > summary {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 800;
  letter-spacing: 0.11em;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__hero h2 {
  margin-top: 0.28rem;
  color: var(--text-strong, #111827);
  font-size: 1.5rem;
  letter-spacing: -0.03em;
}
new-release--widgets--review-102035 .nr-review__hero p {
  max-width: 46rem;
  margin-top: 0.42rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.82rem;
  line-height: 1.55;
}
new-release--widgets--review-102035 .nr-review__loading,
new-release--widgets--review-102035 .nr-review__empty,
new-release--widgets--review-102035 .nr-review__pending {
  display: grid;
  gap: 0.45rem;
  padding: 1.4rem 1.25rem;
}
new-release--widgets--review-102035 .nr-review__empty h3,
new-release--widgets--review-102035 .nr-review__pending h3 {
  color: var(--text-strong, #111827);
  font-size: 1.05rem;
}
new-release--widgets--review-102035 .nr-review__empty p,
new-release--widgets--review-102035 .nr-review__pending p,
new-release--widgets--review-102035 .nr-review__pending small,
new-release--widgets--review-102035 .nr-review__continue small {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.78rem;
  line-height: 1.5;
}
new-release--widgets--review-102035 .nr-review__toolbar {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.8rem 1.1rem;
  padding: 0.75rem 1.25rem;
  border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__toolbar label {
  display: grid;
  min-width: min(16rem, 100%);
  gap: 0.25rem;
}
new-release--widgets--review-102035 .nr-review__legend {
  display: flex;
  flex-wrap: wrap;
  gap: 0.55rem 0.85rem;
  padding: 0;
  list-style: none;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
  font-weight: 700;
}
new-release--widgets--review-102035 .nr-review__legend .is-new,
new-release--widgets--review-102035 .nr-review__legend .is-change {
  color: var(--text-strong, #111827);
  font-weight: 800;
}
new-release--widgets--review-102035 .nr-review__legend .is-keep {
  color: var(--text-muted, #5d6b7e);
  font-weight: 500;
}
new-release--widgets--review-102035 .nr-review__legend .is-remove {
  color: var(--text-muted, #5d6b7e);
  text-decoration: line-through;
}
new-release--widgets--review-102035 .nr-review__split {
  display: grid;
  grid-template-columns: minmax(12rem, 18rem) minmax(0, 1fr);
  align-items: start;
  min-width: 0;
}
new-release--widgets--review-102035 .nr-review__menu {
  min-width: 0;
  padding: 0.45rem 0.45rem 0.9rem 0.35rem;
  border-right: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-bg, #fff);
}
new-release--widgets--review-102035 .nr-review__menu ul {
  padding: 0;
  list-style: none;
}
new-release--widgets--review-102035 .nr-review__menu ul ul {
  padding-left: 0.75rem;
}
new-release--widgets--review-102035 .nr-review__row {
  display: flex;
  align-items: center;
  gap: 0.05rem;
}
new-release--widgets--review-102035 .nr-review__toggle {
  flex: none;
  width: 1.15rem;
  height: 1.55rem;
  padding: 0;
  border: 0;
  background: transparent;
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review__toggle::before {
  content: '';
  display: block;
  width: 0;
  height: 0;
  margin: 0 auto;
  border-style: solid;
  border-width: 0.28rem 0 0.28rem 0.4rem;
  border-color: transparent transparent transparent currentColor;
  transform-origin: 35% 50%;
  transition: transform 0.12s ease;
}
new-release--widgets--review-102035 .nr-review__toggle.is-open::before {
  transform: rotate(90deg);
}
new-release--widgets--review-102035 .nr-review__toggle.is-leaf {
  visibility: hidden;
}
new-release--widgets--review-102035 .nr-review__link {
  flex: 1;
  min-width: 0;
  margin: 0.04rem 0;
  padding: 0.32rem 0.42rem;
  overflow: hidden;
  border: 1px solid transparent;
  border-radius: 0.42rem;
  background: transparent;
  color: inherit;
  font-size: 0.78rem;
  line-height: 1.3;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
}
new-release--widgets--review-102035 .nr-review__link:hover {
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__link.is-active {
  border-color: var(--selected-border, #1273d4);
  background: var(--selected-bg, #e3f1ff);
}
new-release--widgets--review-102035 .nr-review__link.is-new,
new-release--widgets--review-102035 .nr-review__link.is-change,
new-release--widgets--review-102035 .nr-review__detail h3.is-new,
new-release--widgets--review-102035 .nr-review__detail h3.is-change {
  color: var(--text-strong, #111827);
  font-weight: 800;
}
new-release--widgets--review-102035 .nr-review__link.is-keep,
new-release--widgets--review-102035 .nr-review__detail h3.is-keep {
  color: var(--text-muted, #5d6b7e);
  font-weight: 500;
}
new-release--widgets--review-102035 .nr-review__link.is-remove,
new-release--widgets--review-102035 .nr-review__detail h3.is-remove,
new-release--widgets--review-102035 .nr-review .is-remove {
  color: var(--text-muted, #5d6b7e);
  text-decoration: line-through;
}
new-release--widgets--review-102035 .nr-review__removed {
  margin: 0.55rem 0.2rem 0;
}
new-release--widgets--review-102035 .nr-review__removed > summary {
  padding: 0.28rem 0.2rem;
  cursor: pointer;
}
new-release--widgets--review-102035 .nr-review__badge {
  display: inline-block;
  padding: 0.12rem 0.38rem;
  border-radius: 999px;
  background: var(--surface-alt-bg, #f5f7fa);
  color: var(--text-muted, #5d6b7e);
  font-size: 0.58rem;
  font-weight: 750;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__badge.is-new {
  background: var(--status-success-bg, #e2f5db);
  color: var(--status-success-text, #25640e);
}
new-release--widgets--review-102035 .nr-review__badge.is-change {
  background: var(--status-info-bg, #eaf3fc);
  color: var(--status-info-text, #0b5497);
}
new-release--widgets--review-102035 .nr-review__badge.is-remove {
  background: var(--status-error-bg, #fde8e9);
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--review-102035 .nr-review__detail,
new-release--widgets--review-102035 .nr-review__empty-detail {
  min-width: 0;
  padding: 0.7rem 1.1rem 1.1rem;
}
new-release--widgets--review-102035 .nr-review__detail {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  justify-content: flex-start;
  gap: 0.38rem;
}
new-release--widgets--review-102035 .nr-review__detail > header h3 {
  margin-top: 0.12rem;
  font-size: 1.15rem;
  letter-spacing: -0.02em;
}
new-release--widgets--review-102035 .nr-review__detail > header small {
  display: inline-block;
  margin-top: 0.28rem;
}
new-release--widgets--review-102035 .nr-review__detail > p,
new-release--widgets--review-102035 .nr-review__detail article p {
  color: var(--text-default, #2f3a48);
  font-size: 0.8rem;
  line-height: 1.5;
}
new-release--widgets--review-102035 .nr-review__detail > p span {
  display: block;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
  font-weight: 750;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__detail section {
  display: grid;
  gap: 0.45rem;
}
new-release--widgets--review-102035 .nr-review__detail section article {
  padding: 0.65rem 0.72rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.65rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--review-102035 .nr-review__detail section article strong {
  color: var(--text-strong, #111827);
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__empty-detail h3 {
  color: var(--text-strong, #111827);
}
new-release--widgets--review-102035 .nr-review__empty-detail p {
  margin-top: 0.35rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__continue,
new-release--widgets--review-102035 .nr-review__pending {
  align-items: center;
  justify-items: start;
}
new-release--widgets--review-102035 .nr-review__continue {
  display: flex;
  align-items: center;
  gap: 0.7rem;
  padding: 0.85rem 1.25rem 1.1rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
  background: var(--surface-bg, #fff);
}
new-release--widgets--review-102035 .nr-review__continue button,
new-release--widgets--review-102035 .nr-review__pending button {
  min-width: 8rem;
  padding: 0.5rem 0.78rem;
  border: 1px solid var(--button-secondary-border-disabled, #dbe1e9);
  border-radius: 0.6rem;
  background: var(--button-secondary-bg-disabled, #f6f7fa);
  color: var(--button-secondary-text-disabled, #989fa7);
  cursor: not-allowed;
  font-size: 0.72rem;
  font-weight: 700;
}
new-release--widgets--review-102035 .nr-review__backend {
  min-width: 0;
  padding: 1rem 1.25rem 1.2rem;
  border-top: 1px solid var(--border-subtle, #e4e9f0);
}
new-release--widgets--review-102035 .nr-review__backend > header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.45rem 1rem;
}
new-release--widgets--review-102035 .nr-review__backend > header span {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
  font-weight: 800;
  letter-spacing: 0.11em;
  text-transform: uppercase;
}
new-release--widgets--review-102035 .nr-review__backend > header h3 {
  margin-top: 0.2rem;
  color: var(--text-strong, #111827);
  font-size: 1.12rem;
}
new-release--widgets--review-102035 .nr-review__backend > header p {
  margin-top: 0.25rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__backend > header > strong {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__backend-message {
  margin-top: 0.7rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__backend-legend {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem 0.7rem;
  margin: 0.85rem 0;
  padding: 0;
  list-style: none;
  font-size: 0.65rem;
}
new-release--widgets--review-102035 .nr-review__backend-legend .is-new,
new-release--widgets--review-102035 .nr-review__backend-legend .is-change {
  color: var(--text-strong, #111827);
  font-weight: 800;
}
new-release--widgets--review-102035 .nr-review__backend-legend .is-keep,
new-release--widgets--review-102035 .nr-review__backend-legend .is-unknown {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review__backend-legend .is-remove {
  color: var(--status-error-text, #ab2328);
  text-decoration: line-through;
}
new-release--widgets--review-102035 .nr-review__backend-groups {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 21rem), 1fr));
  align-items: start;
  gap: 0.7rem;
  min-width: 0;
}
new-release--widgets--review-102035 .nr-review__backend-group {
  min-width: 0;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.65rem;
  background: var(--surface-bg, #fff);
}
new-release--widgets--review-102035 .nr-review__backend-group summary {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.45rem;
  padding: 0.65rem 0.75rem;
  cursor: pointer;
}
new-release--widgets--review-102035 .nr-review__backend-group summary span {
  display: grid;
  min-width: 0;
  gap: 0.1rem;
}
new-release--widgets--review-102035 .nr-review__backend-group summary strong {
  overflow-wrap: anywhere;
  color: var(--text-strong, #111827);
  font-size: 0.78rem;
}
new-release--widgets--review-102035 .nr-review__backend-group summary code {
  overflow-wrap: anywhere;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.62rem;
}
new-release--widgets--review-102035 .nr-review__backend-group summary small {
  flex: none;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.64rem;
}
new-release--widgets--review-102035 .nr-review__backend-group > div {
  display: grid;
  gap: 0.45rem;
  padding: 0 0.65rem 0.7rem;
}
new-release--widgets--review-102035 .nr-review__backend-item {
  min-width: 0;
  padding: 0.6rem 0.65rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.5rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__backend-item header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.35rem;
}
new-release--widgets--review-102035 .nr-review__backend-item header div {
  display: grid;
  min-width: 0;
  gap: 0.1rem;
}
new-release--widgets--review-102035 .nr-review__backend-item header div span {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.61rem;
}
new-release--widgets--review-102035 .nr-review__backend-item header strong {
  overflow-wrap: anywhere;
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__backend-item.is-new strong,
new-release--widgets--review-102035 .nr-review__backend-item.is-change strong {
  color: var(--text-strong, #111827);
  font-weight: 800;
}
new-release--widgets--review-102035 .nr-review__backend-item.is-keep strong {
  color: var(--text-muted, #5d6b7e);
  font-weight: 500;
}
new-release--widgets--review-102035 .nr-review__backend-item.is-remove strong {
  color: var(--text-muted, #5d6b7e);
  text-decoration: line-through;
}
new-release--widgets--review-102035 .nr-review__backend-item > code,
new-release--widgets--review-102035 .nr-review__backend-item p code {
  overflow-wrap: anywhere;
  font-size: 0.62rem;
}
new-release--widgets--review-102035 .nr-review__backend-item p {
  margin-top: 0.35rem;
  overflow-wrap: anywhere;
  color: var(--text-default, #2f3a48);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__backend-item p span {
  color: var(--text-muted, #5d6b7e);
  font-weight: 700;
}
new-release--widgets--review-102035 .nr-review__backend-item .nr-review__backend-limitation {
  color: var(--status-warning-text, #775700);
}
new-release--widgets--review-102035 .nr-review__backend-empty {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__effort {
  margin-top: 0.9rem;
  padding: 0.7rem 0.8rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.65rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__effort header {
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
  font-size: 0.72rem;
}
new-release--widgets--review-102035 .nr-review__effort header span {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review__effort p {
  margin-top: 0.25rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__effort > div {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 13rem), 1fr));
  gap: 0.45rem;
  margin-top: 0.55rem;
}
new-release--widgets--review-102035 .nr-review__effort > div > div {
  display: grid;
  gap: 0.12rem;
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__effort > div span {
  color: var(--text-muted, #5d6b7e);
}
new-release--widgets--review-102035 .nr-review :where(button, select, summary):focus-visible {
  outline: 0.15rem solid var(--focus-ring, #1273d4);
  outline-offset: 0.12rem;
}
new-release--widgets--review-102035 .nr-review__pool {
  margin: 0 1.25rem 1.2rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.8rem;
  background: var(--surface-alt-bg, #f5f7fa);
}
new-release--widgets--review-102035 .nr-review__pool summary {
  padding: 0.7rem 0.9rem;
  cursor: pointer;
  color: var(--text-muted, #5d6b7e);
  letter-spacing: 0.08em;
}
new-release--widgets--review-102035 .nr-review__pool > p {
  padding: 0 0.9rem 0.5rem;
  color: var(--text-muted, #5d6b7e);
  font-size: 0.7rem;
}
new-release--widgets--review-102035 .nr-review__pool section {
  padding: 0.15rem 0.9rem 0.8rem;
}
new-release--widgets--review-102035 .nr-review__pool h3 {
  margin-bottom: 0.4rem;
}
new-release--widgets--review-102035 .nr-review__pool article {
  display: grid;
  gap: 0.12rem;
  margin-top: 0.35rem;
  padding: 0.55rem 0.65rem;
  border: 1px solid var(--border-subtle, #e4e9f0);
  border-radius: 0.55rem;
  background: var(--surface-bg, #fff);
  font-size: 0.68rem;
}
new-release--widgets--review-102035 .nr-review__pool article code {
  color: var(--link-text, #0f62b8);
  font-size: 0.64rem;
}
new-release--widgets--review-102035 .nr-review__pool article span {
  color: var(--text-default, #2f3a48);
}
new-release--widgets--review-102035 .nr-review__pool .is-unreadable span {
  color: var(--status-error-text, #ab2328);
}
new-release--widgets--review-102035 .nr-review__pool section > p {
  color: var(--text-muted, #5d6b7e);
  font-size: 0.68rem;
}
@container (max-width: 519px) {
  new-release--widgets--review-102035 .nr-review__split {
    grid-template-columns: 1fr;
  }
  new-release--widgets--review-102035 .nr-review__menu {
    border-right: 0;
    border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  }
  new-release--widgets--review-102035 .nr-review__backend {
    padding-inline: 0.85rem;
  }
  new-release--widgets--review-102035 .nr-review__backend-groups {
    grid-template-columns: minmax(0, 1fr);
  }
}
@media (max-width: 780px) {
  new-release--widgets--review-102035 .nr-review__hero,
  new-release--widgets--review-102035 .nr-review__toolbar,
  new-release--widgets--review-102035 .nr-review__continue {
    padding-inline: 0.85rem;
  }
  new-release--widgets--review-102035 .nr-review__split {
    grid-template-columns: 1fr;
  }
  new-release--widgets--review-102035 .nr-review__menu {
    border-right: 0;
    border-bottom: 1px solid var(--border-subtle, #e4e9f0);
  }
  new-release--widgets--review-102035 .nr-review__pool {
    margin-inline: 0.85rem;
  }
}
@media (prefers-reduced-motion: reduce) {
  new-release--widgets--review-102035 .nr-review *,
  new-release--widgets--review-102035 .nr-review *::before,
  new-release--widgets--review-102035 .nr-review *::after {
    scroll-behavior: auto !important;
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
`);
        this.project = 0;
        this.moduleName = '';
        this.version = 'asis';
        this.data = null;
        this.t = key => key;
        this.menuRead = EMPTY_MENU;
        this.pool = [];
        this.backendRead = EMPTY_ARTIFACT;
        this.effortRead = EMPTY_ARTIFACT;
        this.loading = false;
        this.selectedActor = '';
        this.selectedId = '';
        this.selectedScope = 'future';
        this.expandedIds = [];
        this.loadToken = 0;
        this.loadedFor = null;
    }
    createRenderRoot() { return this; }
    updated(changed) {
        if (changed.has('project') || changed.has('moduleName') || changed.has('version') || changed.has('data')) {
            this.selectedActor = '';
            this.selectedId = '';
            this.selectedScope = 'future';
            this.expandedIds = [];
            void this.load();
        }
    }
    pendingCount() {
        return this.version === 'tobe' && this.data?.changeId && !this.data.resultCurrent ? 1 : 0;
    }
    actorTitle(key) {
        const actorId = actorIdFromKey(key);
        return this.data?.artifacts.access.value?.actors.find(actor => actor.actorId === actorId)?.title || actorId;
    }
    view() {
        return buildReviewView({
            pendingCount: this.pendingCount(),
            readStatus: this.menuRead.status,
            raw: this.menuRead.value,
            selectedActor: this.selectedActor,
            selectedId: this.selectedId,
            selectedScope: this.selectedScope,
        });
    }
    isCurrentLoad() {
        const loaded = this.loadedFor;
        return !!loaded && loaded.project === this.project && loaded.moduleName === this.moduleName
            && loaded.version === this.version && loaded.data === this.data;
    }
    async load() {
        const token = ++this.loadToken;
        const context = { project: this.project, moduleName: this.moduleName, version: this.version, data: this.data };
        this.loadedFor = null;
        if (!this.project || !this.moduleName) {
            this.menuRead = EMPTY_MENU;
            this.backendRead = EMPTY_ARTIFACT;
            this.effortRead = EMPTY_ARTIFACT;
            this.pool = [];
            this.loadedFor = context;
            this.loading = false;
            return;
        }
        this.loading = true;
        const [menuRead, backendRead, effortRead, pool] = await Promise.all([
            readModuleMenu(context.project, context.moduleName),
            readReviewArtifact(context.project, context.moduleName, 'backend'),
            readReviewArtifact(context.project, context.moduleName, 'effort'),
            readReviewPoolBoxes(context.project, context.moduleName),
        ]);
        if (token !== this.loadToken)
            return;
        this.menuRead = menuRead;
        this.backendRead = backendRead;
        this.effortRead = effortRead;
        this.pool = pool;
        this.loadedFor = context;
        this.loading = false;
    }
    selectActor(actor) {
        this.selectedActor = actor;
        this.selectedId = '';
        this.selectedScope = 'future';
        this.expandedIds = [];
    }
    selectNode(id, scope) {
        this.selectedId = id;
        this.selectedScope = scope;
    }
    ancestorIds(nodes, id) {
        const found = [];
        const walk = (list, trail) => {
            for (const node of list) {
                if (node.id === id) {
                    found.push(...trail);
                    return true;
                }
                if (node.children.length && walk(node.children, [...trail, node.id]))
                    return true;
            }
            return false;
        };
        walk(nodes, []);
        return found;
    }
    openIds(view) {
        const ids = new Set(this.expandedIds);
        const forest = view.selectedScope === 'removed' ? view.removed : view.tree;
        for (const id of this.ancestorIds(forest, view.selectedId))
            ids.add(id);
        return ids;
    }
    toggleExpand(id) {
        const view = this.view();
        const wasOpen = this.openIds(view).has(id);
        const forest = view.selectedScope === 'removed' ? view.removed : view.tree;
        if (wasOpen && this.ancestorIds(forest, view.selectedId).includes(id))
            this.selectNode(id, view.selectedScope);
        this.expandedIds = wasOpen
            ? this.expandedIds.filter(item => item !== id)
            : [...this.expandedIds, id];
    }
    actionClass(action) {
        return `is-${action}`;
    }
    nodeAria(node) {
        return this.t('review.nodeAria', {
            label: node.label,
            kind: this.t(`review.kind.${node.kind}`),
            action: this.t(`review.action.${node.action}`),
        });
    }
    renderMenuList(nodes, scope, view, openIds) {
        return html `
      <ul>
        ${nodes.map(node => {
            const selected = view.selectedId === node.id && view.selectedScope === scope;
            const expandable = node.children.length > 0;
            const expanded = expandable && openIds.has(node.id);
            return html `
            <li>
              <div class="nr-review__row">
                ${expandable ? html `
                  <button
                    type="button"
                    class=${`nr-review__toggle${expanded ? ' is-open' : ''}`}
                    aria-expanded=${expanded ? 'true' : 'false'}
                    aria-label=${this.nodeAria(node)}
                    @click=${() => this.toggleExpand(node.id)}
                  ></button>
                ` : html `<span class="nr-review__toggle is-leaf" aria-hidden="true"></span>`}
                <button
                  type="button"
                  class=${`nr-review__link ${this.actionClass(node.action)}${selected ? ' is-active' : ''}`}
                  aria-label=${this.nodeAria(node)}
                  aria-current=${selected ? 'true' : 'false'}
                  @click=${() => this.selectNode(node.id, scope)}
                >${node.label}</button>
              </div>
              ${expanded ? this.renderMenuList(node.children, scope, view, openIds) : nothing}
            </li>
          `;
        })}
      </ul>
    `;
    }
    renderDetail(detail) {
        if (!detail) {
            return html `
        <div class="nr-review__empty-detail">
          <h3>${this.t('review.noSelection')}</h3>
          <p>${this.t('review.noSelectionBody')}</p>
        </div>
      `;
        }
        const struck = detail.scope === 'removed' || detail.action === 'remove';
        return html `
      <article class="nr-review__detail" aria-live="polite">
        <header>
          <span>${this.t(`review.kind.${detail.kind}`)}</span>
          <h3 class=${this.actionClass(detail.action)}>${detail.label}</h3>
          <small class=${`nr-review__badge ${this.actionClass(detail.action)}`}>${this.t(`review.action.${detail.action}`)}</small>
        </header>
        ${detail.context ? html `<p><span>${this.t('review.context')}</span><strong>${detail.context}</strong></p>` : nothing}
        ${detail.text ? html `<p class=${struck ? 'is-remove' : ''}>${detail.text}</p>` : nothing}
        ${detail.organisms.length ? html `
          <section>
            <span>${this.t('review.organisms')}</span>
            ${detail.organisms.map(organism => html `
              <article>
                <strong>${this.t(`review.organism.${organism.kind}`)}</strong>
                <p class=${struck ? 'is-remove' : ''}>${organism.text}</p>
              </article>
            `)}
          </section>
        ` : nothing}
      </article>
    `;
    }
    renderMenu(view) {
        if (view.kind === 'pending') {
            return html `
        <section class="nr-review__pending">
          <h3>${this.t('review.pendingTitle')}</h3>
          <p>${this.t('review.pendingBody')}</p>
          <button type="button" disabled aria-disabled="true">${this.t('review.calculate')}</button>
          <small>${this.t('review.actionLater')}</small>
        </section>
      `;
        }
        if (view.kind === 'empty') {
            return html `
        <section class="nr-review__empty">
          <h3>${this.t('review.emptyTitle')}</h3>
          <p>${this.t('review.emptyBody')}</p>
        </section>
      `;
        }
        if (view.kind === 'invalid') {
            return html `
        <section class="nr-review__empty">
          <h3>${this.t('review.invalidTitle')}</h3>
          <p>${this.t(view.errorCode || 'review.error.invalid')}</p>
        </section>
      `;
        }
        const openIds = this.openIds(view);
        return html `
      <div class="nr-review__toolbar">
        <label>
          <span>${this.t('review.actor')}</span>
          <select .value=${view.selectedActor} @change=${(event) => this.selectActor(event.currentTarget.value)}>
            <option value=${REVIEW_ALL_ACTORS} ?selected=${view.selectedActor === REVIEW_ALL_ACTORS}>${this.t('review.allActors')}</option>
            ${view.actors.map(actor => html `<option value=${actor.key} ?selected=${view.selectedActor === actor.key}>${this.actorTitle(actor.key)}</option>`)}
          </select>
        </label>
        <ul class="nr-review__legend">
          ${MENU_ACTIONS.map(action => html `<li class=${this.actionClass(action)}>${this.t(`review.action.${action}`)}</li>`)}
        </ul>
      </div>
      <div class="nr-review__split">
        <nav class="nr-review__menu" aria-label=${this.t('review.futureTree')}>
          ${this.renderMenuList(view.tree, 'future', view, openIds)}
          ${view.removed.length ? html `
            <details class="nr-review__removed" ?open=${view.selectedScope === 'removed'}>
              <summary>${this.t('review.removedTree')}</summary>
              ${this.renderMenuList(view.removed, 'removed', view, openIds)}
            </details>
          ` : nothing}
        </nav>
        ${this.renderDetail(view.selected)}
      </div>
      <div class="nr-review__continue">
        <button type="button" disabled aria-disabled="true">${this.t('review.continue')}</button>
        <small>${this.t('review.actionLater')}</small>
      </div>
    `;
    }
    tableTitle(entity) {
        const value = this.data?.artifacts.entities.find(item => item.value?.entityId === entity)?.value;
        return value?.title || entity;
    }
    renderBackendItem(item, knownTables) {
        const status = this.t(`review.backend.status.${item.tone}`);
        const tableNames = item.tableRefs.join(', ');
        const unresolved = item.tableRefs.filter(ref => !knownTables.has(ref));
        return html `
      <article class=${`nr-review__backend-item is-${item.tone}`}>
        <header>
          <div><span>${this.t(`review.backend.kind.${item.kind}`)}</span><strong>${item.kind === 'table' ? this.tableTitle(item.entity) : item.label}</strong></div>
          <small class=${`nr-review__badge is-${item.tone}`} aria-label=${status}>${status}${item.tone === 'unknown' && item.status ? ` · ${item.status}` : ''}</small>
        </header>
        ${item.kind === 'table' || item.kind === 'change' ? html `<code>${item.kind === 'table' ? item.detail : item.label}</code>` : nothing}
        ${item.detail && item.kind !== 'table' ? html `<p><span>${this.t('review.backend.detail')}</span> ${item.detail}</p>` : nothing}
        ${item.reason ? html `<p><span>${this.t('review.backend.reason')}</span> ${item.reason}</p>` : nothing}
        ${item.source ? html `<p><span>${this.t('review.backend.source')}</span> <code>${item.source}</code></p>` : nothing}
        ${item.usecaseRefs.length ? html `<p><span>${this.t('review.backend.usecases')}</span> ${item.usecaseRefs.join(', ')}</p>` : nothing}
        ${item.tableRefs.length > 1 ? html `<p><span>${this.t('review.backend.tables')}</span> ${tableNames}</p>` : nothing}
        ${!item.tableRefs.length ? html `<p class="nr-review__backend-limitation">${this.t(`review.backend.noTable.${item.noTable}`)}</p>` : nothing}
        ${unresolved.length ? html `<p class="nr-review__backend-limitation">${this.t('review.backend.unresolvedRefs', { refs: unresolved.join(', ') })}</p>` : nothing}
      </article>
    `;
    }
    renderBackendGroup(title, technical, items, knownTables) {
        return html `
      <details class="nr-review__backend-group">
        <summary><span><strong>${title}</strong>${technical ? html `<code>${technical}</code>` : nothing}</span><small>${this.t('review.backend.itemCount', { count: items.length })}</small></summary>
        <div>${items.length ? items.map(item => this.renderBackendItem(item, knownTables)) : html `<p class="nr-review__backend-empty">${this.t('review.backend.noItems')}</p>`}</div>
      </details>
    `;
    }
    renderEffort() {
        const summary = parseEffortSummary(this.effortRead, this.moduleName);
        return html `
      <section class="nr-review__effort" aria-label=${this.t('review.backend.effortTitle')}>
        <header><strong>${this.t('review.backend.effortTitle')}</strong><span>${this.t(summary.kind === 'counts' ? 'review.backend.partial' : summary.kind === 'invalid' ? 'review.backend.effortInvalid' : 'review.backend.notCalculated')}</span></header>
        ${summary.kind === 'counts' ? html `
          <p>${this.t('review.backend.effortCoverage')}</p>
          <div>${summary.counts.map(category => html `
            <div><strong>${this.t(`review.backend.count.${category.category}`)}</strong>
              <span>${category.statuses.map(value => {
            const tone = backendTone(value.status);
            return `${this.t(`review.backend.status.${tone}`)}${tone === 'unknown' ? ` (${value.status})` : ''}: ${value.count}`;
        }).join(' · ')}</span>
            </div>
          `)}</div>
        ` : nothing}
      </section>
    `;
    }
    renderBackend(view) {
        // pool/l2/web holds the candidate result, not a snapshot of Atual or a past release.
        if (this.version !== 'tobe')
            return nothing;
        const stale = view.kind === 'pending';
        const backend = buildBackendReview(this.backendRead, stale, this.moduleName);
        const knownTables = new Set(backend.groups.map(group => group.tableId));
        return html `
      <section class="nr-review__backend" aria-label=${this.t('review.backend.title')}>
        <header>
          <div><span>${this.t('review.backend.eyebrow')}</span><h3>${this.t('review.backend.title')}</h3><p>${this.t('review.backend.moduleScope')}</p></div>
          ${backend.kind === 'ready' ? html `<strong>${this.t('review.backend.uniqueCount', { count: backend.itemCount })}</strong>` : nothing}
        </header>
        ${backend.kind === 'stale' ? html `<p class="nr-review__backend-message">${this.t('review.backend.stale')}</p>` : nothing}
        ${backend.kind === 'missing' ? html `<p class="nr-review__backend-message">${this.t('review.backend.missing')}</p>` : nothing}
        ${backend.kind === 'invalid' ? html `<p class="nr-review__backend-message" role="alert">${this.t(backend.errorCode)}</p>` : nothing}
        ${backend.kind === 'ready' ? html `
          <ul class="nr-review__backend-legend">
            ${['new', 'change', 'keep', 'remove', 'unknown'].map(tone => html `<li class=${`is-${tone}`}>${this.t(`review.backend.status.${tone}`)}</li>`)}
          </ul>
          <div class="nr-review__backend-groups">
            ${backend.groups.map(group => this.renderBackendGroup(group.entity ? this.tableTitle(group.entity) : this.t('review.backend.removedTable'), group.tableId, group.items, knownTables))}
            ${backend.shared.length ? this.renderBackendGroup(this.t('review.backend.shared'), '', backend.shared, knownTables) : nothing}
            ${backend.unassociated.length ? this.renderBackendGroup(this.t('review.backend.unassociated'), '', backend.unassociated, knownTables) : nothing}
          </div>
        ` : nothing}
        ${backend.kind !== 'stale' ? this.renderEffort() : nothing}
      </section>
    `;
    }
    renderPool() {
        return html `
      <details class="nr-review__pool">
        <summary>${this.t('review.pool')}</summary>
        <p>${this.t('review.pool.description')}</p>
        ${this.pool.map(box => html `
          <section>
            <h3>${this.t(`review.pool.box.${box.box}`)}</h3>
            ${box.messages.length ? box.messages.map(message => html `
              <article class=${message.unreadable ? 'is-unreadable' : ''}>
                <code>${message.file}</code>
                ${message.unreadable ? html `<span>${this.t('review.pool.unreadable')}</span>` : html `
                  <span>${this.t('review.pool.from')}: ${message.from}</span>
                  <span>${this.t('review.pool.round', { round: message.round, max: message.maxRound })}</span>
                  <span>${this.t('review.pool.mode')}: ${message.mode}</span>
                  <span>${this.t('review.pool.subject')}: ${message.subject}</span>
                `}
              </article>
            `) : html `<p>${this.t('review.pool.empty')}</p>`}
          </section>
        `)}
      </details>
    `;
    }
    render() {
        const view = this.view();
        const current = this.isCurrentLoad();
        return html `
      <section class="nr-review">
        <header class="nr-review__hero">
          <div>
            <span>${this.t('review.eyebrow')}</span>
            <h2>${this.t('review.title')}</h2>
            <p>${this.t('review.description')}</p>
          </div>
        </header>
        ${this.loading || !current ? html `<p class="nr-review__loading">${this.t('state.loading')}</p>` : html `${this.renderMenu(view)}${this.renderBackend(view)}`}
        ${current && !this.version.startsWith('release:') ? this.renderPool() : nothing}
      </section>
    `;
    }
};
__decorate([
    property({ type: Number })
], NewReleaseReview102035.prototype, "project", void 0);
__decorate([
    property({ type: String, attribute: 'module-name' })
], NewReleaseReview102035.prototype, "moduleName", void 0);
__decorate([
    property({ type: String })
], NewReleaseReview102035.prototype, "version", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseReview102035.prototype, "data", void 0);
__decorate([
    property({ attribute: false })
], NewReleaseReview102035.prototype, "t", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "menuRead", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "pool", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "backendRead", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "effortRead", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "loading", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "selectedActor", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "selectedId", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "selectedScope", void 0);
__decorate([
    state()
], NewReleaseReview102035.prototype, "expandedIds", void 0);
NewReleaseReview102035 = __decorate([
    customElement('new-release--widgets--review-102035')
], NewReleaseReview102035);
export { NewReleaseReview102035 };
