import { CHANGE_EFFORT_SCHEMA_VERSION, L4_DIFF_KINDS, L4_DIFF_OPS, POOL_DEVICES, EFFORT_UNIT_KINDS, EFFORT_MASTER_KINDS, EFFORT_ANSWER_STATUSES, CHANGE_EFFORT_STATUSES, } from '/_102035_/l2/solution/poolPlan.js';
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function masterKey(master) {
    return `${master.project}\0${master.kind}\0${master.device}`;
}
function mergedKey(unit) {
    return `${unit.project}\0${unit.kind}\0${unit.id}`;
}
function push(issues, code, path) {
    issues.push({ code, path });
}
function readString(issues, value, path) {
    if (typeof value !== 'string') {
        push(issues, 'schema', path);
        return undefined;
    }
    return value;
}
function readUnit(issues, value, path) {
    if (!isRecord(value)) {
        push(issues, 'schema', path);
        return undefined;
    }
    const kind = value.kind;
    const id = readString(issues, value.id, `${path}.id`);
    const unitPath = readString(issues, value.path, `${path}.path`);
    if (typeof kind !== 'string' || !EFFORT_UNIT_KINDS.includes(kind)) {
        push(issues, 'schema', `${path}.kind`);
        return undefined;
    }
    if (id === undefined || unitPath === undefined)
        return undefined;
    return { kind: kind, id, path: unitPath };
}
function readUnits(issues, value, path) {
    if (!Array.isArray(value)) {
        push(issues, 'schema', path);
        return undefined;
    }
    const units = [];
    let ok = true;
    for (let i = 0; i < value.length; i++) {
        const unit = readUnit(issues, value[i], `${path}[${i}]`);
        if (!unit)
            ok = false;
        else
            units.push(unit);
    }
    return ok ? units : undefined;
}
function readAgent(issues, value, path) {
    if (!isRecord(value)) {
        push(issues, 'schema', path);
        return undefined;
    }
    const agent = readString(issues, value.agent, `${path}.agent`);
    const command = readString(issues, value.command, `${path}.command`);
    if (agent === undefined || command === undefined)
        return undefined;
    return { agent, command };
}
function readAgents(issues, value, path) {
    if (!Array.isArray(value)) {
        push(issues, 'schema', path);
        return undefined;
    }
    const agents = [];
    let ok = true;
    for (let i = 0; i < value.length; i++) {
        const agent = readAgent(issues, value[i], `${path}[${i}]`);
        if (!agent)
            ok = false;
        else
            agents.push(agent);
    }
    return ok ? agents : undefined;
}
function readMaster(issues, value, path) {
    if (!isRecord(value)) {
        push(issues, 'schema', path);
        return undefined;
    }
    const project = readString(issues, value.project, `${path}.project`);
    const kind = value.kind;
    const device = value.device;
    if (typeof kind !== 'string' || !EFFORT_MASTER_KINDS.includes(kind)) {
        push(issues, 'schema', `${path}.kind`);
    }
    if (typeof device !== 'string' || !POOL_DEVICES.includes(device)) {
        push(issues, 'schema', `${path}.device`);
    }
    if (project === undefined
        || typeof kind !== 'string'
        || !EFFORT_MASTER_KINDS.includes(kind)
        || typeof device !== 'string'
        || !POOL_DEVICES.includes(device)) {
        return undefined;
    }
    return { project, kind: kind, device: device };
}
function readItem(issues, value, path) {
    if (!isRecord(value)) {
        push(issues, 'schema', path);
        return undefined;
    }
    const changeId = readString(issues, value.changeId, `${path}.changeId`);
    const entity = readString(issues, value.entity, `${path}.entity`);
    const source = readString(issues, value.source, `${path}.source`);
    const kind = value.kind;
    const op = value.op;
    if (typeof kind !== 'string' || !L4_DIFF_KINDS.includes(kind)) {
        push(issues, 'schema', `${path}.kind`);
    }
    if (typeof op !== 'string' || !L4_DIFF_OPS.includes(op)) {
        push(issues, 'schema', `${path}.op`);
    }
    if (changeId === undefined
        || entity === undefined
        || source === undefined
        || typeof kind !== 'string'
        || !L4_DIFF_KINDS.includes(kind)
        || typeof op !== 'string'
        || !L4_DIFF_OPS.includes(op)) {
        return undefined;
    }
    const item = { changeId, kind: kind, op: op, entity, source };
    if ('before' in value)
        item.before = value.before;
    if ('after' in value)
        item.after = value.after;
    return item;
}
function readAnswer(issues, value, path, itemId) {
    if (!isRecord(value)) {
        push(issues, 'schema', path);
        return undefined;
    }
    const master = readMaster(issues, value.master, `${path}.master`);
    const item = readString(issues, value.item, `${path}.item`);
    const status = value.status;
    if (item !== undefined && item !== itemId)
        push(issues, 'schema', `${path}.item`);
    if (typeof status !== 'string' || !EFFORT_ANSWER_STATUSES.includes(status)) {
        push(issues, 'schema', `${path}.status`);
    }
    const regenerateDefs = readUnits(issues, value.regenerateDefs, `${path}.regenerateDefs`);
    const materialize = readUnits(issues, value.materialize, `${path}.materialize`);
    const runAgents = readAgents(issues, value.runAgents, `${path}.runAgents`);
    let abend;
    if ('abend' in value && value.abend !== undefined) {
        if (!isRecord(value.abend))
            push(issues, 'schema', `${path}.abend`);
        else {
            const reason = readString(issues, value.abend.reason, `${path}.abend.reason`);
            if (reason !== undefined)
                abend = { reason };
        }
    }
    if (status === 'abend' && !abend)
        push(issues, 'schema', `${path}.abend`);
    if (status === 'computed' && abend)
        push(issues, 'schema', `${path}.abend`);
    if (!master
        || item === undefined
        || item !== itemId
        || typeof status !== 'string'
        || !EFFORT_ANSWER_STATUSES.includes(status)
        || !regenerateDefs
        || !materialize
        || !runAgents
        || (status === 'abend' && !abend)
        || (status === 'computed' && abend)) {
        return undefined;
    }
    const answer = {
        master,
        item,
        status: status,
        regenerateDefs,
        materialize,
        runAgents,
    };
    if (abend)
        answer.abend = abend;
    return answer;
}
function sameMaster(a, b) {
    return a.project === b.project && a.kind === b.kind && a.device === b.device;
}
function sameMergedUnit(a, b) {
    return a.project === b.project && a.kind === b.kind && a.id === b.id && a.path === b.path;
}
function sameAgent(a, b) {
    return a.agent === b.agent && a.command === b.command;
}
function sortUnits(units) {
    return [...units].sort((a, b) => mergedKey(a).localeCompare(mergedKey(b)) || a.path.localeCompare(b.path));
}
function readMergedUnit(issues, value, path) {
    const unit = readUnit(issues, value, path);
    if (!isRecord(value))
        return undefined;
    const project = readString(issues, value.project, `${path}.project`);
    if (!unit || project === undefined)
        return undefined;
    return { project, kind: unit.kind, id: unit.id, path: unit.path };
}
function readMergedUnits(issues, value, path) {
    if (!Array.isArray(value)) {
        push(issues, 'schema', path);
        return undefined;
    }
    const units = [];
    let ok = true;
    for (let i = 0; i < value.length; i++) {
        const unit = readMergedUnit(issues, value[i], `${path}[${i}]`);
        if (!unit)
            ok = false;
        else
            units.push(unit);
    }
    return ok ? units : undefined;
}
function sortAgents(agents) {
    return [...agents].sort((a, b) => a.agent.localeCompare(b.agent) || a.command.localeCompare(b.command));
}
/** União por `project + kind + id` (project do master da resposta): `regenerateDefs` vence `materialize`; abend entra por item e master. */
export function mergeChangeEffort(perItem) {
    const regen = new Map();
    const material = new Map();
    const agents = new Map();
    const abend = [];
    for (const row of perItem) {
        for (const answer of row.answers) {
            for (const unit of answer.regenerateDefs) {
                const merged = { project: answer.master.project, kind: unit.kind, id: unit.id, path: unit.path };
                regen.set(mergedKey(merged), merged);
            }
            for (const agent of answer.runAgents)
                agents.set(`${agent.agent}\0${agent.command}`, agent);
            if (answer.status === 'abend' && answer.abend) {
                abend.push({ item: row.item, master: answer.master, reason: answer.abend.reason });
            }
        }
    }
    for (const row of perItem) {
        for (const answer of row.answers) {
            for (const unit of answer.materialize) {
                const merged = { project: answer.master.project, kind: unit.kind, id: unit.id, path: unit.path };
                const key = mergedKey(merged);
                if (!regen.has(key))
                    material.set(key, merged);
            }
        }
    }
    abend.sort((a, b) => a.item.localeCompare(b.item)
        || masterKey(a.master).localeCompare(masterKey(b.master))
        || a.reason.localeCompare(b.reason));
    return {
        regenerateDefs: sortUnits([...regen.values()]),
        materialize: sortUnits([...material.values()]),
        runAgents: sortAgents([...agents.values()]),
        abend,
    };
}
function sameMerged(a, b) {
    const units = (left, right) => left.length === right.length && left.every((unit, i) => sameMergedUnit(unit, right[i]));
    const agents = (left, right) => left.length === right.length && left.every((agent, i) => sameAgent(agent, right[i]));
    const abends = a.abend.length === b.abend.length && a.abend.every((row, i) => {
        const other = b.abend[i];
        return row.item === other.item && row.reason === other.reason && sameMaster(row.master, other.master);
    });
    return units(a.regenerateDefs, b.regenerateDefs)
        && units(a.materialize, b.materialize)
        && agents(a.runAgents, b.runAgents)
        && abends;
}
function readMerged(issues, value, path) {
    if (!isRecord(value)) {
        push(issues, 'schema', path);
        return undefined;
    }
    const regenerateDefs = readMergedUnits(issues, value.regenerateDefs, `${path}.regenerateDefs`);
    const materialize = readMergedUnits(issues, value.materialize, `${path}.materialize`);
    const runAgents = readAgents(issues, value.runAgents, `${path}.runAgents`);
    if (!Array.isArray(value.abend)) {
        push(issues, 'schema', `${path}.abend`);
        return undefined;
    }
    const abend = [];
    let abendOk = true;
    for (let i = 0; i < value.abend.length; i++) {
        const row = value.abend[i];
        const rowPath = `${path}.abend[${i}]`;
        if (!isRecord(row)) {
            push(issues, 'schema', rowPath);
            abendOk = false;
            continue;
        }
        const item = readString(issues, row.item, `${rowPath}.item`);
        const master = readMaster(issues, row.master, `${rowPath}.master`);
        const reason = readString(issues, row.reason, `${rowPath}.reason`);
        if (item === undefined || !master || reason === undefined)
            abendOk = false;
        else
            abend.push({ item, master, reason });
    }
    if (!regenerateDefs || !materialize || !runAgents || !abendOk)
        return undefined;
    return { regenerateDefs, materialize, runAgents, abend };
}
export function validateChangeEffort(value) {
    const issues = [];
    if (!isRecord(value))
        return { ok: false, issues: [{ code: 'schema', path: '' }] };
    if (value.schemaVersion !== CHANGE_EFFORT_SCHEMA_VERSION)
        push(issues, 'schema', 'schemaVersion');
    const moduleName = readString(issues, value.module, 'module');
    let base;
    if (!isRecord(value.base))
        push(issues, 'schema', 'base');
    else {
        const baseId = readString(issues, value.base.baseId, 'base.baseId');
        const revisionId = readString(issues, value.base.revisionId, 'base.revisionId');
        const candidateRoot = readString(issues, value.base.candidateRoot, 'base.candidateRoot');
        if (baseId !== undefined && revisionId !== undefined && candidateRoot !== undefined) {
            base = { baseId, revisionId, candidateRoot };
        }
    }
    const changeIds = new Set();
    let items;
    let requestText;
    if (!isRecord(value.request))
        push(issues, 'schema', 'request');
    else {
        requestText = readString(issues, value.request.text, 'request.text');
        if (!Array.isArray(value.request.items))
            push(issues, 'schema', 'request.items');
        else {
            items = [];
            for (let i = 0; i < value.request.items.length; i++) {
                const item = readItem(issues, value.request.items[i], `request.items[${i}]`);
                if (!item)
                    items = undefined;
                else if (items) {
                    items.push(item);
                    changeIds.add(item.changeId);
                }
            }
        }
    }
    let masters;
    if (!Array.isArray(value.masters))
        push(issues, 'schema', 'masters');
    else {
        masters = [];
        for (let i = 0; i < value.masters.length; i++) {
            const master = readMaster(issues, value.masters[i], `masters[${i}]`);
            if (!master)
                masters = undefined;
            else if (masters)
                masters.push(master);
        }
    }
    let perItem;
    if (!Array.isArray(value.perItem))
        push(issues, 'schema', 'perItem');
    else {
        perItem = [];
        for (let i = 0; i < value.perItem.length; i++) {
            const row = value.perItem[i];
            const rowPath = `perItem[${i}]`;
            if (!isRecord(row)) {
                push(issues, 'schema', rowPath);
                perItem = undefined;
                continue;
            }
            const item = readString(issues, row.item, `${rowPath}.item`);
            if (item !== undefined && !changeIds.has(item))
                push(issues, 'unknown-item', `${rowPath}.item`);
            if (!Array.isArray(row.answers)) {
                push(issues, 'schema', `${rowPath}.answers`);
                perItem = undefined;
                continue;
            }
            const answers = [];
            let answersOk = item !== undefined;
            for (let j = 0; j < row.answers.length; j++) {
                const answer = readAnswer(issues, row.answers[j], `${rowPath}.answers[${j}]`, item ?? '');
                if (!answer)
                    answersOk = false;
                else {
                    answers.push(answer);
                    if (masters && !masters.some((master) => sameMaster(master, answer.master))) {
                        push(issues, 'unknown-master', `${rowPath}.answers[${j}].master`);
                    }
                }
            }
            if (perItem && answersOk && item !== undefined)
                perItem.push({ item, answers });
            else
                perItem = undefined;
        }
    }
    const merged = readMerged(issues, value.merged, 'merged');
    let untouched;
    if (!isRecord(value.untouched))
        push(issues, 'schema', 'untouched');
    else {
        const count = value.untouched.count;
        const sealHash = readString(issues, value.untouched.sealHash, 'untouched.sealHash');
        if (typeof count !== 'number' || !Number.isInteger(count))
            push(issues, 'schema', 'untouched.count');
        else if (count < 0)
            push(issues, 'untouched-count', 'untouched.count');
        if (typeof count === 'number' && Number.isInteger(count) && count >= 0 && sealHash !== undefined) {
            untouched = { count, sealHash };
        }
    }
    const status = value.status;
    if (typeof status !== 'string' || !CHANGE_EFFORT_STATUSES.includes(status)) {
        push(issues, 'schema', 'status');
    }
    if (perItem && merged) {
        const expected = mergeChangeEffort(perItem);
        if (!sameMerged(merged, expected))
            push(issues, 'merged-mismatch', 'merged');
        const expectedStatus = expected.abend.length > 0 ? 'blocked' : 'simple';
        if (status === 'simple' || status === 'blocked') {
            if (status !== expectedStatus)
                push(issues, 'status', 'status');
        }
    }
    if (issues.length > 0
        || moduleName === undefined
        || !base
        || requestText === undefined
        || !items
        || !masters
        || !perItem
        || !merged
        || !untouched
        || (status !== 'simple' && status !== 'blocked')) {
        return { ok: false, issues };
    }
    const file = {
        schemaVersion: CHANGE_EFFORT_SCHEMA_VERSION,
        module: moduleName,
        base,
        request: { text: requestText, items },
        masters,
        perItem,
        merged,
        untouched,
        status,
    };
    return { ok: true, file };
}
