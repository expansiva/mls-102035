/// <mls fileReference="_102035_/l2/solution/gates/journeys20/contracts.ts" enhancement="_blank"/>
import { normalizeModuleName } from '/_102035_/l2/solution/fs.js';
import { NS5_JOURNEY_SCHEMA_VERSION, } from '/_102035_/l2/solution/types.js';
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
export const NS5_JOURNEY_ACT_EFFECTS = ['create', 'update', 'transition'];
export const NS5_JOURNEY_DROP_TRANSITION_REF = 'dropTransitionRef';
export function normalizeNs5JourneysPayload(value) {
    const root = record(value);
    const normalizations = [];
    const journeys = list(root.journeys)
        .map(item => normalizeJourney(item, normalizations))
        .filter(journey => journey.journeyId || journey.business.title);
    return { journeys, normalizations };
}
export async function hashNs5Journey(draft) {
    return {
        schemaVersion: NS5_JOURNEY_SCHEMA_VERSION,
        journeyId: draft.journeyId,
        business: draft.business,
        businessHash: await sha256Ns5(draft.business),
    };
}
export function buildNs5JourneyIndex(moduleName, artifacts, systemDecisions) {
    return {
        schemaVersion: NS5_JOURNEY_SCHEMA_VERSION,
        moduleName,
        journeys: artifacts.map(artifact => ({
            journeyId: artifact.journeyId,
            actorRef: artifact.business.actorRef,
            title: artifact.business.title,
        })),
        systemDecisions,
    };
}
export function countNs5DecideSteps(journeys) {
    return journeys.reduce((total, journey) => total + journey.business.steps.filter(step => step.kind === 'decide').length, 0);
}
export function ns5JourneyOperationKey(journey) {
    return [...new Set(journey.business.steps.map(step => `${step.kind}:${step.entity}`).filter(item => item !== ':'))]
        .sort()
        .join(',');
}
export async function sha256Ns5(value) {
    const bytes = new TextEncoder().encode(stableStringify(value));
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    const hex = [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
    return `sha256:${hex}`;
}
function normalizeJourney(value, normalizations) {
    const source = record(value);
    const business = record(source.business);
    const entry = record(business.entry);
    const outcome = record(business.outcome);
    const mode = text(entry.mode);
    const journeyId = memberId(text(source.journeyId) || text(business.title), '');
    return {
        journeyId,
        business: {
            actorRef: memberId(text(business.actorRef), ''),
            title: text(business.title),
            goal: text(business.goal),
            entry: {
                mode: mode,
            },
            steps: list(business.steps).map(item => normalizeStep(item, journeyId, normalizations)),
            outcome: {
                statement: text(outcome.statement),
                evidence: strings(outcome.evidence),
            },
        },
    };
}
function normalizeStep(value, journeyId, normalizations) {
    const step = record(value);
    const kind = text(step.kind);
    const affects = uniquePascalIds(step.affects);
    const stepId = memberId(text(step.stepId) || text(step.title), '');
    // The model fills handoffTo on every step as "who does this". Only a handoff names a receiver.
    const handoffTo = kind === 'handoff' ? memberId(text(step.handoffTo), '') : '';
    // effect / transitionRef are act intent. Other kinds drop them (same class as handoffTo).
    const effect = kind === 'act' ? actEffect(step.effect) : undefined;
    const rawTransitionRef = kind === 'act' ? memberId(text(step.transitionRef), '') : '';
    if (kind === 'act' && rawTransitionRef && effect !== 'transition') {
        normalizations.push({
            kind: NS5_JOURNEY_DROP_TRANSITION_REF,
            journeyId,
            stepId,
            detail: `transitionRef ${rawTransitionRef} dropped; effect is ${effect || '(missing)'}.`,
        });
    }
    const transitionRef = effect === 'transition' ? rawTransitionRef : '';
    return {
        stepId,
        kind,
        entity: normalizeEntityId(step.entity),
        ...(affects.length ? { affects } : {}),
        ...(effect ? { effect } : {}),
        ...(transitionRef ? { transitionRef } : {}),
        title: text(step.title),
        description: text(step.description),
        ...(handoffTo ? { handoffTo } : {}),
    };
}
function actEffect(value) {
    return value === 'create' || value === 'update' || value === 'transition' ? value : undefined;
}
/**
 * ns5_43 T1. An `affects` entry is an entity id, or a path into an embedded child of one
 * (`PedidoCompra.details.itens`). Only the ROOT is an entity id and gets the PascalCase treatment; the
 * path segments are field ids written as they are, so normalising them would rename real fields.
 */
function uniquePascalIds(value) {
    const out = [];
    const seen = new Set();
    for (const raw of strings(value)) {
        const dot = raw.indexOf('.');
        const root = normalizeEntityId(dot < 0 ? raw : raw.slice(0, dot));
        if (!root)
            continue;
        const ref = dot < 0 ? root : `${root}.${raw.slice(dot + 1).trim()}`;
        if (seen.has(ref))
            continue;
        seen.add(ref);
        out.push(ref);
    }
    return out;
}
/** Lexical PascalCase id. Does not translate or substitute a domain noun. */
export function normalizeEntityId(value) {
    const raw = text(value);
    if (!raw)
        return '';
    const decomposed = raw.normalize('NFKD').replace(/[\u0300-\u036f]/g, '');
    const words = decomposed.replace(/([a-z0-9])([A-Z])/g, '$1 $2').match(/[A-Za-z0-9]+/g) || [];
    return words.map(word => {
        if (/^[A-Z0-9]+$/.test(word))
            return word;
        return `${word.charAt(0).toUpperCase()}${word.slice(1)}`;
    }).join('');
}
function stableStringify(value) {
    if (Array.isArray(value))
        return `[${value.map(stableStringify).join(',')}]`;
    if (value && typeof value === 'object') {
        const source = value;
        return `{${Object.keys(source).sort().map(key => `${JSON.stringify(key)}:${stableStringify(source[key])}`).join(',')}}`;
    }
    return JSON.stringify(value) ?? 'null';
}
function memberId(value, fallback) {
    const id = normalizeModuleName(value || fallback, fallback);
    return MEMBER_ID.test(id) ? id : fallback;
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function list(value) {
    return Array.isArray(value) ? value : [];
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function strings(value) {
    return list(value).map(text).filter(Boolean);
}
