/// <mls fileReference="_102035_/l2/solution/gates/workflows50/contracts.ts" enhancement="_blank"/>
import { normalizeModuleName } from '/_102035_/l2/solution/fs.js';
import { splitNs5EntityRef } from '/_102035_/l2/solution/ontologyView.js';
import { NS5_WORKFLOWS_SCHEMA_VERSION, NS5_WORKFLOWS_SCHEMA_VERSION_V3, } from '/_102035_/l2/solution/types.js';
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
const ENTITY_ID = /^[A-Z][A-Za-z0-9]*$/;
const EVENT_TRANSITION = /^([A-Z][A-Za-z0-9]*)\.([a-z][A-Za-z0-9]*)$/;
const TASK_KINDS = new Set(['human', 'mechanical', 'llm', 'wait', 'alert']);
const EFFECTS = new Set(['create', 'update', 'transition']);
/** Deterministic extract of time/event phrases from sourcePrompt. Not in the prompt. Accents are folded first. */
const TIME_EVENT_MARKER = /\b(?:todo|cada|quando|automaticamente|a cada|mensal|diario)\b/;
export function normalizeNs5WorkflowsPayload(value, options) {
    const root = record(value);
    const rawProcesses = list(root.processes).map(normalizeProcess).filter(process => process.processId || process.tasks.length);
    const dropped = [];
    const processes = rawProcesses.map(process => dropDuplicateTasks(process, dropped));
    return {
        processes,
        journeyDecisions: completeJourneyDecisions(list(root.journeyDecisions).map(normalizeDecision), processes, options?.journeyIds),
        systemDecisions: dropped,
    };
}
/** v2. Kept for the thirteen recorded runs the replay renders in the form they were recorded in. */
export function buildNs5WorkflowsArtifact(moduleName, processes, journeyDecisions = [], systemDecisions = []) {
    return {
        schemaVersion: NS5_WORKFLOWS_SCHEMA_VERSION,
        moduleName,
        processes,
        journeyDecisions,
        ...(systemDecisions.length ? { systemDecisions } : {}),
    };
}
/** v3 (ns5_48). What the step writes from now on: the only form that may carry an `alert` stage. */
export function buildNs5WorkflowsArtifactV3(moduleName, processes, journeyDecisions = [], systemDecisions = []) {
    return {
        schemaVersion: NS5_WORKFLOWS_SCHEMA_VERSION_V3,
        moduleName,
        processes,
        journeyDecisions,
        ...(systemDecisions.length ? { systemDecisions } : {}),
    };
}
export function collectNs5TimeEventPhrases(sourcePrompt) {
    const seen = new Set();
    const out = [];
    for (const raw of sourcePrompt.split(/(?<=[.!?;\n])\s+/)) {
        const phrase = raw.trim();
        if (!phrase || !TIME_EVENT_MARKER.test(foldAccents(phrase)))
            continue;
        const key = foldAccents(phrase);
        if (seen.has(key))
            continue;
        seen.add(key);
        out.push(phrase);
    }
    return out;
}
function foldAccents(value) {
    return value.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();
}
export function ns5WorkflowsNeedsLlm(signals, phrases) {
    return signals.length > 0 || phrases.length > 0;
}
export function parseNs5TriggerEvent(event) {
    const match = EVENT_TRANSITION.exec(event.trim());
    if (!match)
        return null;
    return { entityId: match[1], transitionId: match[2] };
}
export function collectNs5ProcessSignals(journeys, entities) {
    const signals = [];
    const seen = new Set();
    const add = (signal) => {
        const key = [
            signal.kind,
            signal.journeyId || '',
            signal.stepId || '',
            signal.entityId || '',
            signal.transitionId || '',
        ].join('|');
        if (seen.has(key))
            return;
        seen.add(key);
        signals.push(signal);
    };
    for (const journey of journeys) {
        for (const step of journey.business.steps) {
            if (step.kind === 'handoff') {
                add({ kind: 'handoff', journeyId: journey.journeyId, stepId: step.stepId });
            }
        }
    }
    for (const entity of entities) {
        const byActors = new Set();
        for (const transition of entity.transitions) {
            if (transition.by === 'system' && transition.transitionId) {
                add({ kind: 'systemBy', entityId: entity.entityId, transitionId: transition.transitionId });
            }
            else if (transition.by === 'time' && transition.transitionId) {
                add({ kind: 'timeBy', entityId: entity.entityId, transitionId: transition.transitionId });
            }
            if (!Array.isArray(transition.by))
                continue;
            for (const actor of transition.by) {
                if (actor)
                    byActors.add(actor);
            }
        }
        if (byActors.size < 2)
            continue;
        for (const transition of entity.transitions) {
            if (!Array.isArray(transition.by) || !transition.transitionId)
                continue;
            add({ kind: 'foreignBy', entityId: entity.entityId, transitionId: transition.transitionId });
        }
    }
    const actorsByEntity = new Map();
    for (const journey of journeys) {
        const actor = journey.business.actorRef;
        if (!actor)
            continue;
        for (const step of journey.business.steps) {
            // ns5_43 T1: `affects` may name an embedded child (`PedidoCompra.details.itens`); the actor
            // touches the entity that owns it, so the signal is indexed by the root.
            const entitiesTouched = [step.entity, ...(step.affects || [])]
                .filter(Boolean)
                .map(ref => splitNs5EntityRef(ref).root);
            for (const entityId of entitiesTouched) {
                const actors = actorsByEntity.get(entityId) || new Set();
                actors.add(actor);
                actorsByEntity.set(entityId, actors);
            }
        }
    }
    for (const journey of journeys) {
        for (const step of journey.business.steps) {
            if (step.kind !== 'decide' || !step.entity)
                continue;
            const actors = actorsByEntity.get(step.entity);
            if (!actors || actors.size < 2)
                continue;
            add({
                kind: 'crossActorDecide',
                journeyId: journey.journeyId,
                stepId: step.stepId,
                entityId: step.entity,
            });
        }
    }
    return signals;
}
export function collectNs5Handoffs(journeys) {
    const out = [];
    for (const journey of journeys) {
        for (const step of journey.business.steps) {
            if (step.kind !== 'handoff' || !step.stepId)
                continue;
            out.push({
                journeyId: journey.journeyId,
                stepId: step.stepId,
                handoffTo: step.handoffTo || '',
            });
        }
    }
    return out;
}
/**
 * ns5_49: the entity ids a journey names. `step.entity` may point into an embedded child
 * (`PedidoCompra.details.itens`); only the root is an entity id.
 */
export function collectNs5JourneyEntityIds(journeys) {
    const out = [];
    const seen = new Set();
    for (const journey of journeys) {
        for (const step of journey.business.steps) {
            for (const ref of [step.entity, ...(step.affects || [])]) {
                if (!ref)
                    continue;
                const root = splitNs5EntityRef(ref).root;
                if (!root || seen.has(root))
                    continue;
                seen.add(root);
                out.push(root);
            }
        }
    }
    return out;
}
/**
 * ns5_49: `Entity.transitionId` cited by a journey act. Before the reorder these came from the
 * ontology; the ontology now runs after this step, so the journeys are the only source.
 */
export function collectNs5JourneyTransitionRefs(journeys) {
    const out = [];
    const seen = new Set();
    for (const journey of journeys) {
        for (const step of journey.business.steps) {
            if (step.kind !== 'act' || step.effect !== 'transition' || !step.transitionRef || !step.entity)
                continue;
            const ref = `${splitNs5EntityRef(step.entity).root}.${step.transitionRef}`;
            if (seen.has(ref))
                continue;
            seen.add(ref);
            out.push(ref);
        }
    }
    return out;
}
export function collectNs5WorkflowsRefCatalog(journeys, actorIds, entities) {
    const journeyIds = [];
    for (const journey of journeys) {
        if (journey.journeyId)
            journeyIds.push(journey.journeyId);
    }
    // ns5_49: the journeys are the floor of the catalog. `entities` is empty in the flow v2 order and
    // carries the recorded v2 runs, where the ontology already existed; both sources are unioned.
    const entityIds = collectNs5JourneyEntityIds(journeys);
    const transitionRefs = collectNs5JourneyTransitionRefs(journeys);
    for (const entity of entities) {
        if (entity.entityId && !entityIds.includes(entity.entityId))
            entityIds.push(entity.entityId);
        for (const transition of entity.transitions) {
            if (!transition.transitionId)
                continue;
            const ref = `${entity.entityId}.${transition.transitionId}`;
            if (!transitionRefs.includes(ref))
                transitionRefs.push(ref);
        }
    }
    return {
        actorIds: actorIds.filter(Boolean),
        journeyIds,
        entityIds,
        transitionRefs,
        handoffs: collectNs5Handoffs(journeys),
    };
}
function normalizeProcess(value) {
    const source = record(value);
    const tasks = list(source.tasks).map(normalizeTask).filter(task => task.taskId || task.description);
    return {
        processId: memberId(text(source.processId) || text(source.id), ''),
        title: text(source.title),
        description: text(source.description),
        trigger: normalizeTrigger(source.trigger),
        tasks,
    };
}
function normalizeTrigger(value) {
    const source = record(value);
    const kind = text(source.kind);
    if (kind === 'scheduled')
        return { kind: 'scheduled', schedule: text(source.schedule) };
    if (kind === 'event')
        return { kind: 'event', event: text(source.event) };
    const actorRef = memberId(text(source.actorRef), '');
    return actorRef ? { kind: 'manual', actorRef } : { kind: 'manual' };
}
function normalizeTask(value) {
    const source = record(value);
    const kind = text(source.kind);
    const resolved = TASK_KINDS.has(kind) ? kind : 'human';
    const actorRef = memberId(text(source.actorRef), '');
    const journeyRef = memberId(text(source.journeyRef), '');
    const entityRef = entityId(text(source.entityRef));
    const effect = text(source.effect);
    const transitionRef = memberId(text(source.transitionRef), '');
    const task = {
        taskId: memberId(text(source.taskId) || text(source.id), ''),
        kind: resolved,
        ...((resolved === 'human' || resolved === 'alert') && actorRef ? { actorRef } : {}),
        // An alert carries no journeyRef/entityRef, but normalize KEEPS what the model wrote so the gate
        // can name the mistake (NS5_WORKFLOWS_KIND) instead of silently dropping it.
        ...((resolved === 'human' || resolved === 'alert') && journeyRef ? { journeyRef } : {}),
        ...(resolved === 'alert' && entityRef ? { entityRef } : {}),
        ...((resolved === 'mechanical' || resolved === 'llm') && actorRef ? { actorRef } : {}),
        ...((resolved === 'mechanical' || resolved === 'llm') && entityRef ? { entityRef } : {}),
        ...((resolved === 'mechanical' || resolved === 'llm') && EFFECTS.has(effect)
            ? { effect: effect }
            : {}),
        ...((resolved === 'mechanical' || resolved === 'llm') && transitionRef ? { transitionRef } : {}),
        next: unique(strings(source.next).map(item => memberId(item, '')).filter(Boolean)),
        description: text(source.description),
    };
    return task;
}
function normalizeDecision(value) {
    const source = record(value);
    const journeyId = memberId(text(source.journeyId), '');
    const processId = memberId(text(source.processId), '');
    const inProcess = source.inProcess === true;
    if (inProcess)
        return processId ? { journeyId, inProcess: true, processId } : { journeyId, inProcess: true };
    return { journeyId, inProcess: false };
}
function completeJourneyDecisions(raw, processes, journeyIds) {
    const byId = new Map();
    for (const decision of raw) {
        if (!decision.journeyId || byId.has(decision.journeyId))
            continue;
        byId.set(decision.journeyId, decision);
    }
    const ids = journeyIds?.length ? [...journeyIds] : [...byId.keys()];
    const processIds = new Set(processes.map(process => process.processId).filter(Boolean));
    return ids.filter(Boolean).map(journeyId => {
        const existing = byId.get(journeyId);
        if (!existing)
            return { journeyId, inProcess: false };
        if (!existing.inProcess)
            return { journeyId, inProcess: false };
        const processId = existing.processId && processIds.has(existing.processId) ? existing.processId : existing.processId;
        return processId ? { journeyId, inProcess: true, processId } : { journeyId, inProcess: true };
    });
}
function dropDuplicateTasks(process, dropped) {
    const kept = [];
    const seen = new Set();
    const removed = new Map();
    for (const task of process.tasks) {
        const key = duplicateKey(task);
        if (key && seen.has(key)) {
            if (task.taskId)
                removed.set(task.taskId, task.next);
            dropped.push({
                decisionId: `dropDuplicateTask${capitalize(task.taskId || 'anonymous')}`,
                chosen: 'drop',
                alternatives: ['keep', 'drop'],
                decidedBy: 'system',
            });
            continue;
        }
        if (key)
            seen.add(key);
        kept.push(task);
    }
    if (!removed.size)
        return { ...process, tasks: kept };
    const tasks = kept.map(task => ({
        ...task,
        next: spliceRemoved(task.next, removed),
    }));
    return { ...process, tasks };
}
function duplicateKey(task) {
    if (task.kind === 'human' && task.journeyRef)
        return `human|${task.journeyRef}|${task.effect || ''}`;
    if ((task.kind === 'mechanical' || task.kind === 'llm') && task.entityRef) {
        return `${task.kind}|${task.entityRef}|${task.effect || ''}`;
    }
    return null;
}
function spliceRemoved(next, removed) {
    const expand = (id, visiting) => {
        if (!removed.has(id))
            return [id];
        if (visiting.has(id))
            return [];
        visiting.add(id);
        return (removed.get(id) || []).flatMap(item => expand(item, visiting));
    };
    return unique(next.flatMap(id => expand(id, new Set())));
}
function capitalize(value) {
    return value ? value[0].toUpperCase() + value.slice(1) : value;
}
function memberId(value, fallback) {
    const trimmed = (value || '').trim();
    if (MEMBER_ID.test(trimmed))
        return trimmed;
    const id = normalizeModuleName(trimmed || fallback, fallback);
    return MEMBER_ID.test(id) ? id : fallback;
}
function entityId(value) {
    return ENTITY_ID.test(value.trim()) ? value.trim() : '';
}
function unique(values) {
    const seen = new Set();
    const out = [];
    for (const value of values) {
        if (!value || seen.has(value))
            continue;
        seen.add(value);
        out.push(value);
    }
    return out;
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function list(value) {
    return Array.isArray(value) ? value : [];
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function strings(value) {
    return list(value).map(text).filter(Boolean);
}
