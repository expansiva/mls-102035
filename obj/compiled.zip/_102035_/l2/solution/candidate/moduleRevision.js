/// <mls fileReference="_102035_/l2/solution/candidate/moduleRevision.ts" enhancement="_blank" />
import { fileExists, readDefsJson, readJson, readSourceText, writeJson, writeSourceText } from '/_102035_/l2/solution/fs.js';
import { ns5OntologyEntityIds, normalizeTobeArtifactPath, tobeArtifactFileInfo } from '/_102035_/l2/solution/candidate/tobePaths.js';
import { readModuleLayers } from '/_102035_/l2/solution/candidate/moduleLayers.js';
export const L4_REVISION_SCHEMA = '2026-09-20-nr-module-revision-v1';
export class L4SealedCandidateError extends Error {
    constructor(code) {
        super(code);
        this.code = code;
        this.name = 'L4SealedCandidateError';
    }
}
const locks = new Map();
const CORE_PATHS = [
    'module.defs.ts', 'journeys/index.defs.ts', 'ontology/index.defs.ts',
    'rules.defs.ts', 'workflows.defs.ts', 'access.defs.ts', 'integration.defs.ts',
];
const JOURNEY_FILE = /^journeys\/(?!index\.defs\.ts$)[a-z][A-Za-z0-9]*\.defs\.ts$/u;
const ONTOLOGY_FILE = /^ontology\/[A-Z][A-Za-z0-9]*\.defs\.ts$/u;
function isIndexedLeaf(path) {
    return JOURNEY_FILE.test(path) || ONTOLOGY_FILE.test(path);
}
function assertContext(project, moduleName) {
    if (!Number.isInteger(project) || project <= 0)
        throw new Error('A valid project is required.');
    if (!/^[a-z][A-Za-z0-9]{0,59}$/u.test(moduleName))
        throw new Error('Invalid module name.');
}
function assertSegment(value) {
    if (!/^[a-zA-Z0-9-]+$/u.test(value))
        throw new Error('Invalid revision identifier.');
}
export function resolveL4Folders(project, moduleName, baseId, changeId, revisionId) {
    assertContext(project, moduleName);
    assertSegment(baseId);
    if (changeId)
        assertSegment(changeId);
    if (revisionId)
        assertSegment(revisionId);
    const moduleRoot = `l4/${moduleName}`;
    const originalL4Path = `${moduleRoot}/pipeline/releases/${baseId}/l4`;
    const temporaryL4Path = `${moduleRoot}/tobe/plan`;
    if (originalL4Path === temporaryL4Path || originalL4Path.startsWith(`${temporaryL4Path}/`) || temporaryL4Path.startsWith(`${originalL4Path}/`)) {
        throw new Error('Original and temporary folders must be distinct.');
    }
    return {
        originalL4Path,
        temporaryL4Path,
        revisionL4Path: changeId && revisionId ? `${moduleRoot}/pipeline/changes/${changeId}/revisions/${revisionId}/l4` : null,
    };
}
function jsonInfo(project, moduleName, folder, shortName) {
    assertContext(project, moduleName);
    return { project, level: 4, folder: `${moduleName}/${folder}`, shortName, extension: '.json' };
}
function releaseInfo(project, moduleName, baseId) {
    assertSegment(baseId);
    return jsonInfo(project, moduleName, `pipeline/releases/${baseId}`, 'manifest');
}
function catalogInfo(project, moduleName) {
    return jsonInfo(project, moduleName, 'pipeline/releases', 'index');
}
function changeInfo(project, moduleName, changeId) {
    assertSegment(changeId);
    return jsonInfo(project, moduleName, `pipeline/changes/${changeId}`, 'change');
}
function activeInfo(project, moduleName) {
    return jsonInfo(project, moduleName, 'pipeline/changes', 'active');
}
function revisionInfo(project, moduleName, changeId, revisionId) {
    assertSegment(changeId);
    assertSegment(revisionId);
    return jsonInfo(project, moduleName, `pipeline/changes/${changeId}/revisions/${revisionId}`, 'manifest');
}
function artifactInfo(project, moduleName, path, area, id, revisionId) {
    const normalized = normalizeTobeArtifactPath(path);
    const origin = tobeArtifactFileInfo(project, moduleName, normalized, 'asis');
    if (area === 'asis')
        return origin;
    if (area === 'tobe')
        return tobeArtifactFileInfo(project, moduleName, normalized, 'tobe');
    if (!id)
        throw new Error('A snapshot identifier is required.');
    assertSegment(id);
    const prefix = area === 'release' ? `${moduleName}/pipeline/releases/${id}/l4` : `${moduleName}/pipeline/changes/${id}/revisions/${revisionId}/l4`;
    if (area === 'revision') {
        if (!revisionId)
            throw new Error('A revision identifier is required.');
        assertSegment(revisionId);
    }
    return { ...origin, folder: `${prefix}${origin.folder === moduleName ? '' : origin.folder.slice(moduleName.length)}` };
}
export function originalL4FileInfo(project, moduleName, baseId, path) {
    resolveL4Folders(project, moduleName, baseId);
    return artifactInfo(project, moduleName, path, 'release', baseId);
}
async function sourceHash(source) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(source));
    return `sha256:${[...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
}
async function mapHash(paths, project, moduleName, area, id, revisionId) {
    const hashes = {};
    for (const path of paths) {
        const info = artifactInfo(project, moduleName, path, area, id, revisionId);
        if (!fileExists(info))
            throw new Error(`Missing L4 artifact: ${path}`);
        const source = await readSourceText(info);
        if (!source.trim())
            throw new Error(`Unreadable L4 artifact: ${path}`);
        hashes[path] = await sourceHash(source);
    }
    return hashes;
}
async function mapSchemas(paths, project, moduleName, area, baseId) {
    const schemas = {};
    for (const path of paths) {
        const value = await readDefsJson(artifactInfo(project, moduleName, path, area, baseId));
        if (!value || typeof value !== 'object' || Array.isArray(value))
            throw new Error(`Unreadable L4 schema: ${path}`);
        const schema = value.schemaVersion;
        if (typeof schema === 'string' && schema.trim())
            schemas[path] = schema;
        else if (schema === undefined && (path === 'workspace-model.defs.ts' || path.startsWith('workspaces/')))
            schemas[path] = null;
        else
            throw new Error(`Unsupported L4 schema: ${path}`);
    }
    return schemas;
}
function sameHashes(left, right) {
    const keys = Object.keys(left).sort();
    return keys.length === Object.keys(right).length && keys.every(key => left[key] === right[key]);
}
function sameSchemas(left, right) {
    const keys = Object.keys(left).sort();
    return keys.length === Object.keys(right).length && keys.every(key => left[key] === right[key]);
}
async function inventory(project, moduleName, area = 'asis', baseId) {
    assertContext(project, moduleName);
    const module = await readDefsJson(artifactInfo(project, moduleName, 'module.defs.ts', area, baseId));
    const journey = await readDefsJson(artifactInfo(project, moduleName, 'journeys/index.defs.ts', area, baseId));
    const ontology = await readDefsJson(artifactInfo(project, moduleName, 'ontology/index.defs.ts', area, baseId));
    if (!module || module.moduleName !== moduleName || !journey || !ontology)
        throw new Error('Incomplete or mismatched L4 module.');
    if (module.schemaVersion !== '2026-09-10-ns5-module-v2')
        throw new Error(`Unsupported L4 module schema: ${module.schemaVersion}`);
    const paths = new Set(CORE_PATHS);
    for (const item of journey.journeys)
        paths.add(normalizeTobeArtifactPath(`journeys/${item.journeyId}.defs.ts`));
    for (const id of ns5OntologyEntityIds(ontology))
        paths.add(normalizeTobeArtifactPath(`ontology/${id}.defs.ts`));
    const workspaceModelInfo = artifactInfo(project, moduleName, 'workspace-model.defs.ts', area, baseId);
    if (fileExists(workspaceModelInfo)) {
        const workspaceModel = await readDefsJson(workspaceModelInfo);
        if (!workspaceModel || !Array.isArray(workspaceModel.menu))
            throw new Error('Unsupported L4 workspace model.');
        paths.add('workspace-model.defs.ts');
        for (const item of workspaceModel.menu) {
            if (typeof item.workspaceId !== 'string')
                throw new Error('Unsupported L4 workspace id.');
            paths.add(normalizeTobeArtifactPath(`workspaces/${item.workspaceId}.defs.ts`));
        }
    }
    const root = area === 'asis' ? moduleName : `${moduleName}/pipeline/releases/${baseId}/l4`;
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted' || file.extension !== '.defs.ts')
            continue;
        const folder = String(file.folder || '');
        if (folder !== root && folder !== `${root}/journeys` && folder !== `${root}/ontology` && folder !== `${root}/workspaces`)
            continue;
        const relative = `${folder === root ? '' : `${folder.slice(root.length + 1)}/`}${file.shortName}${file.extension}`;
        if (!paths.has(normalizeTobeArtifactPath(relative)))
            throw new Error(`Unindexed L4 source: ${relative}`);
    }
    // A schema's indexes define the complete source set; never enumerate pool/pipeline/tobe.
    const result = [...paths].sort();
    await mapHash(result, project, moduleName, area, baseId);
    return result;
}
export async function withModuleWriter(project, moduleName, work) {
    assertContext(project, moduleName);
    if (typeof navigator !== 'undefined' && navigator.locks) {
        return navigator.locks.request(`new-release-l4:${project}:${moduleName}`, () => inProcessWriter(project, moduleName, work));
    }
    return inProcessWriter(project, moduleName, work);
}
async function inProcessWriter(project, moduleName, work) {
    const key = `${project}/${moduleName}`;
    const previous = locks.get(key) ?? Promise.resolve();
    let release;
    const next = new Promise(resolve => { release = resolve; });
    const current = previous.then(() => next);
    locks.set(key, current);
    await previous;
    try {
        return await work();
    }
    finally {
        release();
        if (locks.get(key) === current)
            locks.delete(key);
    }
}
export async function readActiveL4Change(project, moduleName) {
    const pointer = await readJson(activeInfo(project, moduleName));
    if (!pointer?.changeId)
        return null;
    const change = await readJson(changeInfo(project, moduleName, pointer.changeId));
    if (!change || change.project !== project || change.moduleName !== moduleName || change.changeId !== pointer.changeId)
        throw new Error('Active L4 change is incomplete.');
    return change;
}
export async function readL4Release(project, moduleName, baseId) {
    const catalog = await readJson(catalogInfo(project, moduleName));
    if (!catalog?.releases.some(entry => entry.baseId === baseId))
        return null;
    const manifest = await readJson(releaseInfo(project, moduleName, baseId));
    if (!manifest || manifest.project !== project || manifest.moduleName !== moduleName || manifest.baseId !== baseId)
        return null;
    try {
        const paths = Object.keys(manifest.files).map(normalizeTobeArtifactPath);
        const indexed = await inventory(project, moduleName, 'release', baseId);
        if (paths.length !== indexed.length || paths.some(path => !indexed.includes(path)))
            return null;
        const actual = await mapHash(paths, project, moduleName, 'release', baseId);
        const schemas = await mapSchemas(paths, project, moduleName, 'release', baseId);
        return sameHashes(actual, manifest.files) && manifest.schemas && sameSchemas(schemas, manifest.schemas) ? manifest : null;
    }
    catch {
        return null;
    }
}
/** Called under the module writer when a completed update is confirmed. */
export async function captureConfirmedL4Release(project, moduleName, changeId, revisionId, sourceBaseId, confirmedAt, confirmedBy) {
    const sealed = await readSealedL4Candidate(project, moduleName, changeId, revisionId);
    if (!sealed || sealed.manifest.baseId !== sourceBaseId)
        throw new Error('l4.snapshot_incomplete');
    const paths = Object.keys(sealed.manifest.files).map(normalizeTobeArtifactPath).sort();
    const currentPaths = await inventory(project, moduleName);
    if (paths.length !== currentPaths.length || paths.some((path, index) => path !== currentPaths[index])
        || !sameHashes(await mapHash(paths, project, moduleName, 'asis'), sealed.manifest.files)) {
        throw new Error('l4.snapshot_current_mismatch');
    }
    const baseId = `snap-${(await sourceHash(changeId)).slice(7, 23)}`;
    const existing = await readL4Release(project, moduleName, baseId);
    if (existing) {
        if (existing.confirmedRound?.revisionId !== revisionId || !sameHashes(existing.files, sealed.manifest.files)) {
            throw new Error('l4.snapshot_conflict');
        }
        const catalog = await readJson(catalogInfo(project, moduleName));
        if (!(catalog?.releases ?? []).some(entry => entry.baseId === baseId)) {
            await writeJson(catalogInfo(project, moduleName), {
                schemaVersion: L4_REVISION_SCHEMA,
                releases: [...(catalog?.releases ?? []), { baseId, createdAt: existing.createdAt, provenance: existing.provenance }],
            });
        }
        return existing;
    }
    const schemas = await mapSchemas(paths, project, moduleName, 'asis');
    for (const { path, source } of sealed.sources) {
        await writeSourceText(artifactInfo(project, moduleName, path, 'release', baseId), source);
    }
    if (!sameHashes(await mapHash(paths, project, moduleName, 'release', baseId), sealed.manifest.files)
        || !sameSchemas(await mapSchemas(paths, project, moduleName, 'release', baseId), schemas)) {
        throw new Error('l4.snapshot_incomplete');
    }
    const manifest = {
        schemaVersion: L4_REVISION_SCHEMA, project, moduleName, baseId, createdAt: confirmedAt,
        files: sealed.manifest.files, schemas,
        provenance: { status: 'unverified', label: 'Confirmed update — publication not verified' },
        confirmedRound: { changeId, revisionId, sourceBaseId, confirmedAt, confirmedBy },
    };
    await writeJson(releaseInfo(project, moduleName, baseId), manifest);
    const catalog = await readJson(catalogInfo(project, moduleName));
    await writeJson(catalogInfo(project, moduleName), {
        schemaVersion: L4_REVISION_SCHEMA,
        releases: [...(catalog?.releases ?? []).filter(entry => entry.baseId !== baseId),
            { baseId, createdAt: confirmedAt, provenance: manifest.provenance }],
    });
    return manifest;
}
export async function prepareL4Change(project, moduleName, oldManifest) {
    return withModuleWriter(project, moduleName, async () => {
        const active = await readActiveL4Change(project, moduleName);
        if (active) {
            const release = await readL4Release(project, moduleName, active.baseId);
            if (!release)
                throw new Error('Captured L4 base is missing or incomplete.');
            // A candidate that already holds files was copied from the base when the change was prepared: an indexed file (journey,
            // entity) missing from it was REMOVED by the request, and the seal records that. Only a candidate that holds nothing yet
            // is still to be copied, and a fixed file is always put back (the seal refuses a candidate without it).
            const copied = Object.values(mls.stor.files).some(file => !!file && file.project === project && file.level === 4
                && file.status !== 'deleted' && file.extension === '.defs.ts' && String(file.folder || '').startsWith(`${moduleName}/tobe/plan`));
            for (const rawPath of Object.keys(release.files)) {
                const path = normalizeTobeArtifactPath(rawPath);
                const temporary = artifactInfo(project, moduleName, path, 'tobe');
                if (fileExists(temporary))
                    continue;
                if (copied && isIndexedLeaf(path))
                    continue;
                await writeSourceText(temporary, await readSourceText(originalL4FileInfo(project, moduleName, active.baseId, path)));
            }
            return { release, change: active, created: false };
        }
        const paths = await inventory(project, moduleName);
        const originalHashes = await mapHash(paths, project, moduleName, 'asis');
        const originalSchemas = await mapSchemas(paths, project, moduleName, 'asis');
        const planRoot = `${moduleName}/tobe/plan`;
        for (const file of Object.values(mls.stor.files)) {
            if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted' || file.extension !== '.defs.ts')
                continue;
            const folder = String(file.folder || '');
            if (folder !== planRoot && !folder.startsWith(`${planRoot}/`))
                continue;
            const relative = `${folder === planRoot ? '' : `${folder.slice(planRoot.length + 1)}/`}${file.shortName}${file.extension}`;
            if (!paths.includes(normalizeTobeArtifactPath(relative)))
                throw new Error(`Unsupported prepared artifact: ${relative}`);
        }
        if (!oldManifest) {
            for (const path of paths) {
                const temporary = artifactInfo(project, moduleName, path, 'tobe');
                if (fileExists(temporary) && await sourceHash(await readSourceText(temporary)) !== originalHashes[path]) {
                    throw new Error(`Prepared artifact lacks a base manifest: ${path}`);
                }
            }
        }
        if (oldManifest) {
            for (const [path, expected] of Object.entries(oldManifest.base)) {
                const value = await readDefsJson(artifactInfo(project, moduleName, normalizeTobeArtifactPath(path), 'asis'));
                if (value === null || !expected || await import('/_102035_/l2/solution/candidate/tobeDiff.js').then(({ sha256Tobe }) => sha256Tobe(value)) !== expected) {
                    throw new Error(`Prepared change has a stale base: ${path}`);
                }
            }
            for (const path of paths) {
                const temporary = artifactInfo(project, moduleName, path, 'tobe');
                if (fileExists(temporary) && !oldManifest.base[path] && await sourceHash(await readSourceText(temporary)) !== originalHashes[path]) {
                    throw new Error(`Prepared edit is not tracked by the manifest: ${path}`);
                }
            }
        }
        const identity = await sourceHash(JSON.stringify(originalHashes));
        let baseId = `base-${identity.slice(7, 23)}`;
        let previous = await readL4Release(project, moduleName, baseId);
        if (!previous) {
            const catalog = await readJson(catalogInfo(project, moduleName));
            const latestSnapshot = [...(catalog?.releases ?? [])].reverse().find(entry => entry.baseId.startsWith('snap-'));
            if (latestSnapshot) {
                const snapshot = await readL4Release(project, moduleName, latestSnapshot.baseId);
                const round = snapshot?.confirmedRound;
                const marker = round ? await readJson({ project, level: 4, folder: `${moduleName}/pipeline/changes/${round.changeId}`, shortName: 'confirmation', extension: '.json' }) : null;
                if (round && marker?.revisionId === round.revisionId && sameHashes(snapshot.files, originalHashes)
                    && sameSchemas(snapshot.schemas, originalSchemas)) {
                    baseId = snapshot.baseId;
                    previous = snapshot;
                }
            }
        }
        const now = new Date().toISOString();
        const release = previous ?? {
            schemaVersion: L4_REVISION_SCHEMA, project, moduleName, baseId, createdAt: now,
            files: originalHashes,
            schemas: originalSchemas,
            provenance: { status: 'unverified', label: 'Base captured — publication not verified' },
        };
        if (!previous) {
            for (const path of paths) {
                await writeSourceText(artifactInfo(project, moduleName, path, 'release', baseId), await readSourceText(artifactInfo(project, moduleName, path, 'asis')));
            }
            const captured = await mapHash(paths, project, moduleName, 'release', baseId);
            const stillCurrent = await mapHash(paths, project, moduleName, 'asis');
            const capturedSchemas = await mapSchemas(paths, project, moduleName, 'release', baseId);
            const stillSchemas = await mapSchemas(paths, project, moduleName, 'asis');
            if (!sameHashes(captured, originalHashes) || !sameHashes(stillCurrent, originalHashes)
                || !sameSchemas(capturedSchemas, originalSchemas) || !sameSchemas(stillSchemas, originalSchemas))
                throw new Error('L4 base changed during capture.');
            await writeJson(releaseInfo(project, moduleName, baseId), release);
            const catalog = await readJson(catalogInfo(project, moduleName));
            await writeJson(catalogInfo(project, moduleName), {
                schemaVersion: L4_REVISION_SCHEMA,
                releases: [...(catalog?.releases ?? []).filter(entry => entry.baseId !== baseId), { baseId, createdAt: now, provenance: release.provenance }],
            });
        }
        for (const path of paths) {
            const temporary = artifactInfo(project, moduleName, path, 'tobe');
            if (!fileExists(temporary))
                await writeSourceText(temporary, await readSourceText(artifactInfo(project, moduleName, path, 'release', baseId)));
        }
        const changeId = `change-${Date.now()}-${crypto.randomUUID()}`;
        const module = await readDefsJson(artifactInfo(project, moduleName, 'module.defs.ts', 'asis'));
        const change = {
            schemaVersion: L4_REVISION_SCHEMA, project, moduleName, changeId, baseId,
            activeRevisionId: null, requestRevision: 0, resultRevisionId: null,
            sourcePrompt: module?.sourcePrompt ?? '', updatedAt: now,
        };
        await writeJson(changeInfo(project, moduleName, changeId), change);
        await writeJson(activeInfo(project, moduleName), { changeId });
        return { release, change, created: true };
    });
}
function candidateStatesMatch(manifest, base) {
    const states = manifest.fileStates;
    if (!states)
        return false;
    const releasePaths = Object.keys(base.files).map(normalizeTobeArtifactPath);
    const described = Object.keys(states).map(normalizeTobeArtifactPath).sort();
    const expected = [...new Set([...Object.keys(manifest.files).map(normalizeTobeArtifactPath), ...releasePaths])].sort();
    if (described.length !== expected.length || described.some((path, index) => path !== expected[index]))
        return false;
    for (const path of described) {
        const state = states[path];
        const inCandidate = Object.hasOwn(manifest.files, path);
        const inRelease = Object.hasOwn(base.files, path);
        if (state === 'removed') {
            if (inCandidate || !inRelease || !isIndexedLeaf(path))
                return false;
        }
        else if (state === 'added') {
            if (!inCandidate || inRelease || !isIndexedLeaf(path))
                return false;
        }
        else if (state === 'changed') {
            if (!inCandidate || !inRelease || manifest.files[path] === base.files[path])
                return false;
        }
        else if (state === 'same') {
            if (!inCandidate || !inRelease || manifest.files[path] !== base.files[path])
                return false;
        }
        else
            return false;
    }
    return true;
}
async function assertCandidateIndex(project, moduleName, candidate) {
    const journey = await readDefsJson(artifactInfo(project, moduleName, 'journeys/index.defs.ts', 'tobe'));
    const ontology = await readDefsJson(artifactInfo(project, moduleName, 'ontology/index.defs.ts', 'tobe'));
    if (!journey?.journeys || !ontology)
        throw new Error('new-release.candidate_index_mismatch:index');
    const journeyIds = new Set(journey.journeys.map(item => item.journeyId));
    for (const id of journeyIds) {
        const path = `journeys/${id}.defs.ts`;
        if (!candidate.has(path))
            throw new Error(`new-release.candidate_index_mismatch:${path}`);
    }
    for (const path of candidate) {
        if (!JOURNEY_FILE.test(path))
            continue;
        const id = path.slice('journeys/'.length, -'.defs.ts'.length);
        if (!journeyIds.has(id))
            throw new Error(`new-release.candidate_index_mismatch:${path}`);
        const file = await readDefsJson(artifactInfo(project, moduleName, normalizeTobeArtifactPath(path), 'tobe'));
        if (file?.journeyId !== id)
            throw new Error(`new-release.candidate_index_mismatch:${path}`);
    }
    const entityIds = new Set(ns5OntologyEntityIds(ontology));
    for (const id of entityIds) {
        const path = `ontology/${id}.defs.ts`;
        if (!candidate.has(path))
            throw new Error(`new-release.candidate_index_mismatch:${path}`);
    }
    for (const path of candidate) {
        if (!ONTOLOGY_FILE.test(path))
            continue;
        const id = path.slice('ontology/'.length, -'.defs.ts'.length);
        if (!entityIds.has(id))
            throw new Error(`new-release.candidate_index_mismatch:${path}`);
        const file = await readDefsJson(artifactInfo(project, moduleName, normalizeTobeArtifactPath(path), 'tobe'));
        if (file?.entityId !== id)
            throw new Error(`new-release.candidate_index_mismatch:${path}`);
    }
}
export async function sealL4Revision(project, moduleName, expectedRevisionId, request) {
    return withModuleWriter(project, moduleName, () => sealL4RevisionInsideWriter(project, moduleName, expectedRevisionId, request));
}
export async function editL4Candidate(project, moduleName, expectedRevisionId, expectedChangeId, edit) {
    return withModuleWriter(project, moduleName, async () => {
        const current = await readActiveL4Change(project, moduleName);
        if (!current || current.changeId !== expectedChangeId || current.activeRevisionId !== expectedRevisionId)
            throw new Error('L4 revision conflict: reload before saving.');
        const value = await edit(current);
        const revision = await sealL4RevisionInsideWriter(project, moduleName, expectedRevisionId);
        return { value, revision };
    });
}
export async function revertL4CandidatePath(project, moduleName, path, expectedRevisionId, afterRestore) {
    const change = await readActiveL4Change(project, moduleName);
    if (!change)
        throw new Error('No active L4 change.');
    const result = await editL4Candidate(project, moduleName, expectedRevisionId, change.changeId, async (current) => {
        await writeSourceText(artifactInfo(project, moduleName, path, 'tobe'), await readSourceText(originalL4FileInfo(project, moduleName, current.baseId, path)));
        await afterRestore?.();
    });
    return result.revision;
}
export async function deactivateL4Change(project, moduleName, before) {
    await withModuleWriter(project, moduleName, async () => {
        await before?.();
        await writeJson(activeInfo(project, moduleName), { changeId: '' });
    });
}
/** A planner may publish a result only for the still-active, intact candidate revision. */
export async function markL4Result(project, moduleName, expectedRevisionId) {
    return withModuleWriter(project, moduleName, async () => {
        const change = await readActiveL4Change(project, moduleName);
        if (!change || change.activeRevisionId !== expectedRevisionId)
            throw new Error('L4 revision conflict: result is stale.');
        if (!await readL4Revision(project, moduleName, change.changeId, expectedRevisionId))
            throw new Error('Candidate snapshot is incomplete.');
        const updated = { ...change, resultRevisionId: expectedRevisionId, updatedAt: new Date().toISOString() };
        await writeJson(changeInfo(project, moduleName, change.changeId), updated);
        return updated;
    });
}
async function sealL4RevisionInsideWriter(project, moduleName, expectedRevisionId, request) {
    const change = await readActiveL4Change(project, moduleName);
    if (!change)
        throw new Error('No active L4 change.');
    if (change.activeRevisionId !== expectedRevisionId)
        throw new Error('L4 revision conflict: reload before saving.');
    if (request !== undefined && typeof request !== 'string')
        throw new Error('Change request must be text.');
    const requestRevision = change.requestRevision + (request === undefined ? 0 : 1);
    const storedRequest = request === undefined && requestRevision > 0
        ? await readJson(jsonInfo(project, moduleName, `pipeline/changes/${change.changeId}/requests`, `request-${requestRevision}`))
        : null;
    if (request === undefined && requestRevision > 0 && typeof storedRequest?.request !== 'string') {
        throw new Error('Current change request is missing or incomplete.');
    }
    const requestText = request ?? (typeof storedRequest?.request === 'string' ? storedRequest.request : '');
    const requestHash = await sourceHash(requestText);
    const release = await readL4Release(project, moduleName, change.baseId);
    if (!release)
        throw new Error('Captured L4 base is incomplete.');
    const releasePaths = Object.keys(release.files).map(normalizeTobeArtifactPath);
    const releaseSet = new Set(releasePaths);
    const planRoot = `${moduleName}/tobe/plan`;
    const candidatePaths = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted' || file.extension !== '.defs.ts')
            continue;
        const folder = String(file.folder || '');
        if (folder !== planRoot && !folder.startsWith(`${planRoot}/`))
            continue;
        const relative = `${folder === planRoot ? '' : `${folder.slice(planRoot.length + 1)}/`}${file.shortName}${file.extension}`;
        if (!CORE_PATHS.includes(relative) && !isIndexedLeaf(relative) && !releaseSet.has(relative)) {
            throw new Error(`new-release.candidate_path_refused:${relative}`);
        }
        candidatePaths.push(normalizeTobeArtifactPath(relative));
    }
    const candidateSet = new Set(candidatePaths);
    const removed = [];
    for (const path of releasePaths) {
        if (candidateSet.has(path))
            continue;
        if (!isIndexedLeaf(path))
            throw new Error(`new-release.candidate_fixed_file_missing:${path}`);
        removed.push(path);
    }
    await assertCandidateIndex(project, moduleName, candidateSet);
    const paths = [...candidateSet].sort();
    const current = await mapHash(paths, project, moduleName, 'tobe');
    const fileStates = {};
    for (const path of paths) {
        if (!releaseSet.has(path))
            fileStates[path] = 'added';
        else if (current[path] !== release.files[path])
            fileStates[path] = 'changed';
        else
            fileStates[path] = 'same';
    }
    for (const path of removed.sort())
        fileStates[path] = 'removed';
    const changedPaths = paths.filter(path => fileStates[path] === 'added' || fileStates[path] === 'changed');
    const hash = await sourceHash(JSON.stringify(current));
    const revisionId = `rev-${Date.now()}-${hash.slice(7, 19)}-${crypto.randomUUID()}`;
    const now = new Date().toISOString();
    for (const path of paths) {
        await writeSourceText(artifactInfo(project, moduleName, path, 'revision', change.changeId, revisionId), await readSourceText(artifactInfo(project, moduleName, path, 'tobe')));
    }
    if (!sameHashes(await mapHash(paths, project, moduleName, 'revision', change.changeId, revisionId), current))
        throw new Error('Candidate snapshot is incomplete.');
    const manifest = {
        schemaVersion: L4_REVISION_SCHEMA, project, moduleName, changeId: change.changeId, revisionId,
        baseId: change.baseId, createdAt: now, files: current, changedPaths, fileStates,
        requestRevision,
        requestHash,
    };
    if (request !== undefined) {
        await writeJson(jsonInfo(project, moduleName, `pipeline/changes/${change.changeId}/requests`, `request-${manifest.requestRevision}`), {
            schemaVersion: L4_REVISION_SCHEMA, revision: manifest.requestRevision, request, createdAt: now,
        });
    }
    await writeJson(revisionInfo(project, moduleName, change.changeId, revisionId), manifest);
    await writeJson(changeInfo(project, moduleName, change.changeId), {
        ...change, activeRevisionId: revisionId, requestRevision: manifest.requestRevision,
        resultRevisionId: null, updatedAt: now,
    });
    return manifest;
}
export async function readL4Revision(project, moduleName, changeId, revisionId) {
    const manifest = await readJson(revisionInfo(project, moduleName, changeId, revisionId));
    if (!manifest || manifest.project !== project || manifest.moduleName !== moduleName || manifest.changeId !== changeId || manifest.revisionId !== revisionId)
        return null;
    try {
        const paths = Object.keys(manifest.files).map(normalizeTobeArtifactPath);
        const base = await readL4Release(project, moduleName, manifest.baseId);
        if (!base)
            return null;
        if (manifest.fileStates) {
            if (!candidateStatesMatch(manifest, base))
                return null;
        }
        else if (paths.length !== Object.keys(base.files).length || paths.some(path => !(path in base.files)))
            return null;
        return sameHashes(await mapHash(paths, project, moduleName, 'revision', changeId, revisionId), manifest.files) ? manifest : null;
    }
    catch {
        return null;
    }
}
/** Read exact immutable revision bytes; never substitutes the mutable tobe/plan mirror. */
export async function readSealedL4Candidate(project, moduleName, changeId, revisionId) {
    const manifest = await readL4Revision(project, moduleName, changeId, revisionId);
    if (!manifest)
        return null;
    if (!manifest.requestHash) {
        throw new L4SealedCandidateError('candidate.legacy_request_hash_missing');
    }
    if (!/^sha256:[a-f0-9]{64}$/u.test(manifest.requestHash)) {
        throw new L4SealedCandidateError('candidate.request_integrity_failed');
    }
    const paths = Object.keys(manifest.files).map(normalizeTobeArtifactPath).sort();
    const sources = await Promise.all(paths.map(async (path) => ({
        path,
        source: await readSourceText(artifactInfo(project, moduleName, path, 'revision', changeId, revisionId)),
    })));
    const returnedHashes = Object.fromEntries(await Promise.all(sources.map(async (item) => [item.path, await sourceHash(item.source)])));
    if (!sameHashes(returnedHashes, manifest.files)) {
        throw new L4SealedCandidateError('candidate.source_integrity_failed');
    }
    const requestRecord = manifest.requestRevision > 0
        ? await readJson(jsonInfo(project, moduleName, `pipeline/changes/${changeId}/requests`, `request-${manifest.requestRevision}`))
        : null;
    if (manifest.requestRevision > 0 && typeof requestRecord?.request !== 'string') {
        throw new L4SealedCandidateError('candidate.request_integrity_failed');
    }
    const request = typeof requestRecord?.request === 'string' ? requestRecord.request : '';
    if (await sourceHash(request) !== manifest.requestHash) {
        throw new L4SealedCandidateError('candidate.request_integrity_failed');
    }
    return { manifest, request, sources };
}
/** Resolve only a complete active sealed revision. An incomplete active record fails closed. */
export async function readActiveSealedL4Candidate(project, moduleName) {
    const active = await readActiveL4Change(project, moduleName);
    if (!active?.activeRevisionId)
        return null;
    const sealed = await readSealedL4Candidate(project, moduleName, active.changeId, active.activeRevisionId);
    if (!sealed)
        throw new Error('Active sealed L4 candidate is incomplete.');
    return sealed;
}
export async function readChangeRequest(project, moduleName) {
    const change = await readActiveL4Change(project, moduleName);
    if (!change)
        return null;
    const stored = change.requestRevision ? await readJson({
        project, level: 4, folder: `${moduleName}/pipeline/changes/${change.changeId}/requests`,
        shortName: `request-${change.requestRevision}`, extension: '.json',
    }) : null;
    if (change.requestRevision && typeof stored?.request !== 'string')
        throw new Error('Change request is incomplete.');
    return {
        changeId: change.changeId,
        revisionId: change.activeRevisionId,
        text: stored?.request ?? '',
        resultCurrent: change.resultRevisionId !== null && change.resultRevisionId === change.activeRevisionId,
    };
}
/** Persist a complete immutable output revision from already decided sources. */
export async function writeL4OutputRevision(project, moduleName, input) {
    return withModuleWriter(project, moduleName, async () => {
        const release = await readL4Release(project, moduleName, input.baseId);
        const paths = input.sources.map(item => item.path);
        if (!release || new Set(paths).size !== paths.length
            || paths.some(path => !Object.hasOwn(release.files, path) && !isIndexedLeaf(path))
            || Object.keys(release.files).some(path => !paths.includes(path) && !isIndexedLeaf(path))) {
            throw new Error('l4.output_revision_paths');
        }
        const files = {};
        for (const item of input.sources)
            files[item.path] = await sourceHash(item.source);
        const fileStates = {};
        for (const path of paths) {
            fileStates[path] = !Object.hasOwn(release.files, path) ? 'added'
                : files[path] === release.files[path] ? 'same' : 'changed';
        }
        for (const path of Object.keys(release.files))
            if (!Object.hasOwn(files, path))
                fileStates[path] = 'removed';
        const changedPaths = paths.filter(path => fileStates[path] === 'added' || fileStates[path] === 'changed').sort();
        const info = revisionInfo(project, moduleName, input.changeId, input.revisionId);
        const existing = await readJson(info);
        if (existing) {
            if (!sameHashes(existing.files, files))
                throw new Error('l4.output_revision_conflict');
            return existing;
        }
        // A previous interrupted write may have left sources without a manifest.
        for (const item of input.sources) {
            const target = artifactInfo(project, moduleName, normalizeTobeArtifactPath(item.path), 'revision', input.changeId, input.revisionId);
            if (fileExists(target) && await readSourceText(target) !== item.source)
                throw new Error('l4.output_revision_conflict');
        }
        for (const item of input.sources) {
            await writeSourceText(artifactInfo(project, moduleName, normalizeTobeArtifactPath(item.path), 'revision', input.changeId, input.revisionId), item.source);
        }
        await writeJson(info, {
            schemaVersion: L4_REVISION_SCHEMA, project, moduleName,
            changeId: input.changeId, revisionId: input.revisionId, baseId: input.baseId,
            createdAt: new Date().toISOString(), files, changedPaths, fileStates,
            requestRevision: input.requestRevision, requestHash: input.requestHash,
        });
        const revision = await readL4Revision(project, moduleName, input.changeId, input.revisionId);
        if (!revision)
            throw new Error('l4.output_revision_unreadable');
        return revision;
    });
}
/** Adopt an immutable review output only while its input is still active. */
export async function adoptL4ReviewResult(project, moduleName, input) {
    return withModuleWriter(project, moduleName, async () => {
        const change = await readActiveL4Change(project, moduleName);
        if (change?.activeRevisionId === input.outputRevisionId && change.resultRevisionId === input.outputRevisionId)
            return change;
        if (!change || change.activeRevisionId !== input.inputRevisionId)
            throw new Error('l4.result_stale');
        const output = await readL4Revision(project, moduleName, change.changeId, input.outputRevisionId);
        if (!output)
            throw new Error('l4.result_unreadable');
        const paths = Object.keys(output.files).map(normalizeTobeArtifactPath);
        for (const path of paths) {
            await writeSourceText(artifactInfo(project, moduleName, path, 'tobe'), await readSourceText(artifactInfo(project, moduleName, path, 'revision', change.changeId, input.outputRevisionId)));
        }
        if (!sameHashes(await mapHash(paths, project, moduleName, 'tobe'), output.files))
            throw new Error('l4.result_unreadable');
        const updated = {
            ...change, activeRevisionId: input.outputRevisionId, resultRevisionId: input.outputRevisionId,
            updatedAt: new Date().toISOString(),
        };
        await writeJson(changeInfo(project, moduleName, change.changeId), updated);
        return updated;
    });
}
/** Promote the active sealed defs and the pool bytes captured from that same revision. */
export async function promoteL4Revision(project, moduleName, changeId, revisionId) {
    return withModuleWriter(project, moduleName, async () => {
        const change = await readActiveL4Change(project, moduleName);
        if (!change || change.changeId !== changeId || change.activeRevisionId !== revisionId) {
            throw new Error('module-promotion.revision_mismatch');
        }
        let sealed;
        try {
            sealed = await readSealedL4Candidate(project, moduleName, changeId, revisionId);
        }
        catch {
            throw new Error('module-promotion.revision_mismatch');
        }
        if (!sealed || sealed.manifest.baseId !== change.baseId)
            throw new Error('module-promotion.revision_mismatch');
        const removedPaths = Object.entries(sealed.manifest.fileStates ?? {})
            .filter((entry) => entry[1] === 'removed')
            .map(([path]) => normalizeTobeArtifactPath(path));
        for (const path of removedPaths) {
            const indexed = mls.stor.files[mls.stor.getKeyToFile(artifactInfo(project, moduleName, path, 'asis'))];
            if (!indexed || indexed.status === 'deleted')
                throw new Error('module-promotion.revision_mismatch');
        }
        try {
            await readModuleLayers(project, moduleName, sealed.manifest.baseId);
        }
        catch {
            throw new Error('module-promotion.layers_unsealed');
        }
        const copies = sealed.sources.map(({ path, source }) => ({
            info: artifactInfo(project, moduleName, path, 'asis'), source, sha256: sealed.manifest.files[path],
        }));
        const root = resolveL4Folders(project, moduleName, sealed.manifest.baseId, changeId, revisionId).revisionL4Path.slice(3);
        const poolRoot = `${root}/pool`;
        for (const file of Object.values(mls.stor.files)) {
            if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted'
                || (file.folder !== poolRoot && !file.folder.startsWith(`${poolRoot}/`)))
                continue;
            const source = await readSourceText(file);
            copies.push({ info: { project, level: 4, folder: `${moduleName}${file.folder.slice(root.length)}`,
                    shortName: file.shortName, extension: file.extension }, source, sha256: await sourceHash(source) });
        }
        for (const copy of copies) {
            await writeSourceText(copy.info, copy.source);
            if (await sourceHash(await readSourceText(copy.info)) !== copy.sha256) {
                throw new Error('module-promotion.revision_mismatch');
            }
        }
        if (removedPaths.length) {
            const { deleteFile } = await import('/_102027_/l2/libStor.js');
            for (const path of removedPaths) {
                const info = artifactInfo(project, moduleName, path, 'asis');
                const indexed = mls.stor.files[mls.stor.getKeyToFile(info)];
                if (!indexed || indexed.status === 'deleted')
                    throw new Error('module-promotion.revision_mismatch');
                await deleteFile(indexed);
                if (fileExists(info))
                    throw new Error('module-promotion.revision_mismatch');
            }
        }
        const promotedAt = new Date().toISOString();
        const promoted = { ...change, promotedRevisionId: revisionId, promotedAt, updatedAt: promotedAt };
        await writeJson(changeInfo(project, moduleName, changeId), promoted);
        return promoted;
    });
}
