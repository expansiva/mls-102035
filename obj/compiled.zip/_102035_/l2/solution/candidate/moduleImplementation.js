/// <mls fileReference="_102035_/l2/solution/candidate/moduleImplementation.ts" enhancement="_blank" />
import { readJson, readSourceText, writeJson } from '/_102035_/l2/solution/fs.js';
import { readActiveL4Change, withModuleWriter } from '/_102035_/l2/solution/candidate/moduleRevision.js';
import { validateChangeEffort } from '/_102035_/l2/solution/gates/changeEffort/gate.js';
export const L4_IMPLEMENTATION_SCHEMA = '2026-10-08-nr-module-implementation-v1';
export function implementationPhaseCommand(ref, project, moduleName) {
    if (ref.agent !== 'agentAddLanguage' || !ref.command.startsWith('@@agentAddLanguage '))
        throw new Error('implementation.invalid_command');
    let args;
    try {
        args = JSON.parse(ref.command.slice('@@agentAddLanguage '.length));
    }
    catch {
        throw new Error('implementation.invalid_command');
    }
    if (ref.command !== '@@agentAddLanguage ' + JSON.stringify(args))
        throw new Error('implementation.invalid_command');
    if (!Array.isArray(args) || args.length !== 1 || !args[0] || typeof args[0] !== 'object' || Array.isArray(args[0]))
        throw new Error('implementation.invalid_command');
    const value = args[0];
    if (Object.keys(value).sort().join(',') !== 'languages,moduleName,projectId'
        || value.projectId !== project || value.moduleName !== moduleName || !Array.isArray(value.languages)
        || !value.languages.every(language => language && typeof language === 'object' && !Array.isArray(language)
            && Object.keys(language).sort().join(',') === 'code,name'
            && typeof language.code === 'string' && typeof language.name === 'string'))
        throw new Error('implementation.invalid_command');
    return ref;
}
function implementationInfo(project, moduleName, changeId) {
    return { project, level: 4, folder: `${moduleName}/pipeline/changes/${changeId}`, shortName: 'implementation', extension: '.json' };
}
export async function readL4Implementation(project, moduleName) {
    const change = await readActiveL4Change(project, moduleName);
    return change ? readJson(implementationInfo(project, moduleName, change.changeId)) : null;
}
/** Keeps the fresh read, reservation and canonical task identity in the same module writer. */
export async function withL4ImplementationWriter(project, moduleName, work) {
    return withModuleWriter(project, moduleName, async () => {
        const record = await readL4Implementation(project, moduleName);
        if (!record)
            throw new Error('implementation.not_accepted');
        return work(record, async (phase) => {
            const index = Number(phase.name.slice('runAgents:'.length));
            if (!phase.name.startsWith('runAgents:') || !Number.isSafeInteger(index) || index < 0 || `runAgents:${index}` !== phase.name)
                throw new Error('implementation.invalid_phase');
            const ref = record.merged.runAgents[index];
            if (!ref || record.merged.materialize.length)
                throw new Error('implementation.invalid_phase');
            const expected = implementationPhaseCommand(ref, project, moduleName);
            if (phase.agent !== expected.agent || phase.command !== expected.command)
                throw new Error('implementation.invalid_command');
            const phaseIndex = record.phases.findIndex(item => item.name === phase.name);
            if (phaseIndex < 0)
                record.phases.push({ ...phase });
            else
                record.phases[phaseIndex] = { ...phase };
            await writeJson(implementationInfo(project, moduleName, record.changeId), record);
        });
    });
}
export async function recordL4ImplementationPhase(project, moduleName, phase) {
    return withL4ImplementationWriter(project, moduleName, async (record, save) => {
        await save(phase);
        return record;
    });
}
export async function acceptL4Implementation(project, moduleName, input) {
    return withModuleWriter(project, moduleName, async () => {
        const change = await readActiveL4Change(project, moduleName);
        if (!change || !input.revisionId || change.activeRevisionId !== input.revisionId || change.resultRevisionId !== input.revisionId) {
            throw new Error('l4.implementation_not_ready');
        }
        const effortInfo = {
            project,
            level: 4,
            folder: `${moduleName}/pipeline/changes/${change.changeId}/revisions/${input.revisionId}/l4/pool/l4`,
            shortName: 'changeEffort',
            extension: '.json',
        };
        const stored = mls.stor.files[mls.stor.getKeyToFile(effortInfo)];
        if (!stored || stored.status === 'deleted')
            throw new Error('l4.implementation_not_ready');
        let source;
        try {
            source = await readSourceText(effortInfo);
        }
        catch {
            throw new Error('l4.implementation_not_ready');
        }
        let value;
        try {
            value = JSON.parse(source);
        }
        catch {
            throw new Error('l4.implementation_not_ready');
        }
        const checked = validateChangeEffort(value);
        if (!checked.ok || checked.file.module !== moduleName)
            throw new Error('l4.implementation_not_ready');
        if (checked.file.status === 'blocked')
            throw new Error('l4.implementation_blocked');
        if (checked.file.merged.regenerateDefs.length)
            throw new Error('l4.implementation_regenerate_unsupported');
        const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(source));
        const hash = `sha256:${[...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
        if (input.hashes.changeEffort !== hash)
            throw new Error('l4.implementation_conflict');
        const info = implementationInfo(project, moduleName, change.changeId);
        const existing = await readJson(info);
        if (existing) {
            if (existing.revisionId !== input.revisionId
                || existing.hashes.changeEffort !== hash) {
                throw new Error('l4.implementation_conflict');
            }
            return existing;
        }
        const record = {
            schemaVersion: L4_IMPLEMENTATION_SCHEMA,
            changeId: change.changeId,
            revisionId: input.revisionId,
            acceptedBy: input.acceptedBy,
            acceptedAt: new Date().toISOString(),
            hashes: { changeEffort: hash },
            merged: checked.file.merged,
            phases: [],
        };
        await writeJson(info, record);
        return record;
    });
}
