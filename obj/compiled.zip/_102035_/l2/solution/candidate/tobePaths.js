/// <mls fileReference="_102035_/l2/solution/candidate/tobePaths.ts" enhancement="_blank" />
import { isNewReleaseOntologyV3Version } from '/_102035_/l2/solution/candidate/ontologyV3Contract.js';
export const NS5_TOBE_MANIFEST_SCHEMA_VERSION = '2026-09-13-ns5-tobe-plan-v1';
export function isNs5OntologyV3(value) {
    return isNewReleaseOntologyV3Version(value?.schemaVersion);
}
export function ns5OntologyEntityIds(value) {
    if (!value)
        return [];
    return isNs5OntologyV3(value)
        ? value.entities.map(entity => entity.entityId)
        : [...value.entities];
}
export function assertProject(project) {
    if (!Number.isInteger(project) || project <= 0)
        throw new Error('A valid project is required.');
}
export function normalizeTobeArtifactPath(path) {
    const value = String(path || '');
    const fixed = new Set([
        'module.defs.ts', 'journeys/index.defs.ts', 'ontology/index.defs.ts', 'rules.defs.ts',
        'workflows.defs.ts', 'access.defs.ts', 'integration.defs.ts', 'workspace-model.defs.ts',
    ]);
    if (fixed.has(value))
        return value;
    if (/^(journeys\/[a-z][A-Za-z0-9]*|ontology\/[A-Z][A-Za-z0-9]*)\.defs\.ts$/u.test(value)) {
        return value;
    }
    if (/^workspaces\/[a-z][A-Za-z0-9]*\.defs\.ts$/u.test(value))
        return value;
    throw new Error(`Unsupported tobe artifact path: ${path}`);
}
export function pathParts(path) {
    const segments = path.replace(/\.defs\.ts$/u, '').split('/');
    return { shortName: segments.pop() || '', subfolder: segments.join('/') };
}
export function tobeArtifactFileInfo(project, moduleName, path, source) {
    assertProject(project);
    const normalized = normalizeTobeArtifactPath(path);
    const parts = pathParts(normalized);
    const root = source === 'tobe' ? `${moduleName}/tobe/plan` : moduleName;
    return {
        project,
        level: 4,
        folder: parts.subfolder ? `${root}/${parts.subfolder}` : root,
        shortName: parts.shortName,
        extension: '.defs.ts',
    };
}
