/// <mls fileReference="_102035_/l2/solution/helpers/e4/contracts.ts" enhancement="_blank"/>
import { sha256Ns4 } from '/_102035_/l2/solution/helpers/e2/contracts.js';
import { resolveNs4Findings, } from '/_102035_/l2/solution/helpers/ns4Resolve.js';
export const NS4_ONTOLOGY_SCHEMA_VERSION = '2026-09-08-ns4-ontology-v7';
export const NS4_ONTOLOGY_SCHEMA_VERSION_V6 = '2026-08-11-ns4-ontology-v6';
/** Human-text JSON paths the importer may rewrite. Union of entity + index shapes that share this schemaVersion. */
export const TEXT_PATHS_2026_09_08_ns4_ontology_v7 = [
    'title',
    'description',
    'businessDomain',
    'fields[].title',
    'fields[].description',
    'fields[].constraints[].description',
    'fields[].enumLabels[].label',
    'lifecyclePredicates[].description',
    'lifecycleLabels[].label',
    'storage.notes',
    'entities[].title',
    'entities[].description',
    'entities[].fields[].title',
    'entities[].fields[].description',
    'entities[].fields[].constraints[].description',
    'entities[].fields[].enumLabels[].label',
    'entities[].lifecyclePredicates[].description',
    'entities[].lifecycleLabels[].label',
    'entities[].storage.notes',
    'relationships[].description',
    'relationships[].realization.description',
    'systemDecisions[].question',
    'systemDecisions[].chosen',
    'systemDecisions[].alternatives[]',
    'systemDecisions[].changeHint',
];
export const TEXT_PATHS_2026_08_11_ns4_ontology_v6 = TEXT_PATHS_2026_09_08_ns4_ontology_v7;
export const TEXT_PATHS_2026_08_09_ns4_ontology_v4 = TEXT_PATHS_2026_09_08_ns4_ontology_v7;
export const TEXT_PATHS_2026_08_08_ns4_ontology_v3 = TEXT_PATHS_2026_09_08_ns4_ontology_v7;
export function normalizeNs4E4Review(value, fallbackModule = '') {
    const root = record(value);
    const moduleName = text(root.moduleName) || fallbackModule;
    const rawEntities = array(root.entities);
    const entities = rawEntities.map(item => normalizeEntity(item, moduleName));
    const incoming = mergeSystemDecisions(normalizeSystemDecisions(root.systemDecisions), promoteToGeneralDecisions(rawEntities, moduleName));
    const review = {
        planId: 'e4-ontology-review',
        moduleName,
        userLanguage: text(root.userLanguage) || 'en',
        title: text(root.title) || 'Business ontology',
        reviewRound: positiveInteger(root.reviewRound, 1),
        solutionMode: 'new',
        businessDomain: text(root.businessDomain),
        entities,
        relationships: array(root.relationships).map(item => {
            const relationship = record(item);
            const fromEntity = text(relationship.fromEntity) || text(relationship.sourceEntity) || text(relationship.from);
            const toEntity = text(relationship.toEntity) || text(relationship.targetEntity) || text(relationship.to);
            const realization = normalizeRelationshipRealization(relationship.realization, fromEntity, toEntity);
            return {
                relationshipId: text(relationship.relationshipId),
                fromEntity,
                toEntity,
                type: relationshipType(relationship.type),
                required: relationship.required === true,
                description: text(relationship.description),
                persistence: { mode: relationshipPersistenceMode(entities, fromEntity, toEntity) },
                ...(realization ? { realization } : {}),
            };
        }),
        changeSummary: strings(root.changeSummary),
        systemDecisions: incoming,
    };
    return applyClosedDomainLabelBackfill(review);
}
/** `inProgress` → `In progress`. Fallback when the model omitted a user-language label. */
export function humanizeNs4EnumCode(code) {
    const words = String(code || '').replace(/[_-]+/g, ' ').replace(/([a-z0-9])([A-Z])/g, '$1 $2').trim().split(/\s+/u);
    if (!words[0])
        return code;
    const first = words[0].charAt(0).toUpperCase() + words[0].slice(1).toLowerCase();
    return [first, ...words.slice(1).map(word => word.toLowerCase())].join(' ');
}
function applyClosedDomainLabelBackfill(review) {
    const findings = closedDomainLabelFindings(review);
    if (!findings.length)
        return review;
    const resolution = resolveNs4Findings(review, findings);
    const byId = new Map((review.systemDecisions || []).map(decision => [decision.decisionId, decision]));
    resolution.systemDecisions.forEach(decision => byId.set(decision.decisionId, decision));
    return { ...resolution.artifact, systemDecisions: [...byId.values()] };
}
function closedDomainLabelFindings(review) {
    const findings = [];
    review.entities.forEach(entity => {
        // Plan drafts have no fields yet — do not poison the entity workers with humanized English.
        if (!entity.fields.length)
            return;
        if (entity.lifecycleStates.length) {
            const ids = lifecycleStateIds(entity.lifecycleStates);
            const { missing } = completeEnumLabels(ids, entity.lifecycleLabels);
            if (missing.length)
                findings.push(lifecycleLabelFinding(entity.entityId, ids));
        }
        entity.fields.forEach(field => {
            const codes = field.enum || [];
            if (!codes.length || isLifecycleStatusField(field, entity))
                return;
            const { missing } = completeEnumLabels(codes, field.enumLabels);
            if (missing.length)
                findings.push(fieldEnumLabelFinding(entity.entityId, field.fieldId, codes));
        });
    });
    return findings;
}
function lifecycleLabelFinding(entityId, codes) {
    return {
        classification: 'C',
        findingRef: `e4.lifecycleLabels.backfill:${entityId}`,
        stage: 'e4',
        question: `Entity ${entityId} is missing lifecycleLabels for one or more states.`,
        deterministicChoice: 'humanizeMissingCodes',
        alternatives: ['authorUserLanguageLabels'],
        changeHint: 'Emit lifecycleLabels in the user language next to lifecycleStates. This run filled the gap with a humanized code so the UI is never raw camelCase.',
        apply: artifact => ({
            ...artifact,
            entities: artifact.entities.map(entity => {
                if (entity.entityId !== entityId)
                    return entity;
                const { labels } = completeEnumLabels(codes, entity.lifecycleLabels);
                return { ...entity, lifecycleLabels: labels };
            }),
        }),
    };
}
function fieldEnumLabelFinding(entityId, fieldId, codes) {
    return {
        classification: 'C',
        findingRef: `e4.enumLabels.backfill:${entityId}.${fieldId}`,
        stage: 'e4',
        question: `Entity ${entityId} field ${fieldId} is missing enumLabels for one or more codes.`,
        deterministicChoice: 'humanizeMissingCodes',
        alternatives: ['authorUserLanguageLabels'],
        changeHint: 'Emit enumLabels in the user language next to the enum constraint. Status uses lifecycleLabels — do not duplicate it on the status field.',
        apply: artifact => ({
            ...artifact,
            entities: artifact.entities.map(entity => {
                if (entity.entityId !== entityId)
                    return entity;
                return {
                    ...entity,
                    fields: entity.fields.map(field => {
                        if (field.fieldId !== fieldId)
                            return field;
                        const { labels } = completeEnumLabels(codes, field.enumLabels);
                        return { ...field, enumLabels: labels };
                    }),
                };
            }),
        }),
    };
}
function completeEnumLabels(codes, existing) {
    const byCode = new Map();
    const extras = [];
    const codeSet = new Set(codes);
    (existing || []).forEach(entry => {
        if (!entry.code)
            return;
        if (!codeSet.has(entry.code))
            extras.push(entry);
        else if (entry.label)
            byCode.set(entry.code, entry.label);
    });
    const missing = [];
    const labels = codes.map(code => {
        const have = byCode.get(code);
        if (have)
            return { code, label: have };
        missing.push(code);
        return { code, label: humanizeNs4EnumCode(code) };
    });
    return { labels: extras.length ? [...labels, ...extras] : labels, missing };
}
function isLifecycleStatusField(field, entity) {
    return isStatusFieldId(field.fieldId) && entity.lifecycleStates.length > 0;
}
function normalizeSystemDecisions(value) {
    return array(value).map(item => {
        const decision = record(item);
        return {
            decisionId: text(decision.decisionId), stage: text(decision.stage), question: text(decision.question),
            chosen: text(decision.chosen), alternatives: strings(decision.alternatives), decidedBy: 'system',
            findingRef: text(decision.findingRef), changeHint: text(decision.changeHint),
        };
    }).filter(decision => decision.decisionId && decision.stage && decision.question && decision.chosen && decision.findingRef);
}
function mergeSystemDecisions(...lists) {
    const byId = new Map();
    for (const list of lists) {
        for (const decision of list) {
            if (decision.decisionId)
                byId.set(decision.decisionId, decision);
        }
    }
    return [...byId.values()];
}
function pascalIdent(value) {
    return value ? value.slice(0, 1).toUpperCase() + value.slice(1) : '';
}
/** Type B registrar: a person-registration field the model proposes for the organization `general` layer. */
function promoteToGeneralDecisions(rawEntities, moduleName) {
    const decisions = [];
    const seen = new Set();
    for (const item of rawEntities) {
        const entity = record(item);
        const entityId = text(entity.entityId);
        if (!entityId)
            continue;
        for (const fieldId of strings(entity.promoteToGeneral)) {
            const decisionId = `promoteToGeneral${pascalIdent(fieldId)}`;
            if (seen.has(decisionId))
                continue;
            seen.add(decisionId);
            decisions.push({
                decisionId,
                stage: 'e4',
                question: `Field ${fieldId} on ${entityId} is person-registration data that level 1 does not already store. Keep it on the organization general layer, or on this module namespace?`,
                chosen: 'general',
                alternatives: ['general', 'moduleNamespace'],
                decidedBy: 'system',
                findingRef: `NS4_E4_PROMOTE_TO_GENERAL:${entityId}.${fieldId}`,
                changeHint: `E10 writes ${fieldId} onto the solution registry generalFields for ${moduleName}. Alternative: keep it as a module-namespace field of ${entityId}.`,
            });
        }
    }
    return decisions;
}
export function normalizeNs4E4PlanDraft(value, fallbackModule = '') {
    const root = record(value);
    const moduleName = text(root.moduleName) || fallbackModule;
    const full = normalizeNs4E4Review({
        ...root,
        moduleName,
        entities: array(root.entities).map(item => ({ ...record(item), fields: [], useRules: [] })),
    }, moduleName);
    return {
        planId: 'e4-ontology-plan',
        moduleName,
        userLanguage: full.userLanguage,
        title: full.title,
        reviewRound: full.reviewRound,
        solutionMode: 'new',
        businessDomain: full.businessDomain,
        entities: full.entities.map(({ fields, useRules, ...entity }) => entity),
        relationships: full.relationships,
        changeSummary: full.changeSummary,
    };
}
export function normalizeNs4E4EntityDraft(value, moduleName, reviewRound, entityId) {
    const root = record(value);
    const normalized = normalizeEntity({
        entityId,
        fields: root.fields,
        useRules: root.useRules,
    }, moduleName);
    const promoteToGeneral = strings(root.promoteToGeneral);
    return {
        planId: 'e4-ontology-entity',
        moduleName,
        reviewRound,
        entityId,
        // The worker tool schema is strict and owns no union key: the entity draft is the worker's own
        // contract, so the derived union is stripped back out here and lives only in the review artifact.
        fields: stripNs4DerivedFieldUnions(normalized.fields),
        useRules: normalized.useRules,
        ...(promoteToGeneral.length ? { promoteToGeneral } : {}),
    };
}
export function stripNs4DerivedFieldUnions(value) {
    if (Array.isArray(value)) {
        return value.map(item => {
            const { enum: _union, ...field } = record(item);
            return field;
        });
    }
    const source = record(value);
    if (!Array.isArray(source.fields))
        return value;
    const { statusEnum: _states, ...entity } = source;
    return { ...entity, fields: stripNs4DerivedFieldUnions(source.fields) };
}
export function assembleNs4E4Review(plan, details) {
    const byEntity = new Map(details.map(detail => [detail.entityId, detail]));
    return normalizeNs4E4Review({
        ...plan,
        planId: 'e4-ontology-review',
        entities: plan.entities.map(entity => {
            const detail = byEntity.get(entity.entityId);
            return {
                ...entity,
                fields: detail?.fields || [],
                useRules: detail?.useRules || [],
                ...(detail?.promoteToGeneral?.length ? { promoteToGeneral: detail.promoteToGeneral } : {}),
            };
        }),
    }, plan.moduleName);
}
export function normalizeNs4E4RelationshipBindings(value, moduleName, reviewRound) {
    const root = record(value);
    return {
        planId: 'e4-relationship-bindings',
        moduleName: text(root.moduleName) || moduleName,
        reviewRound: positiveInteger(root.reviewRound, reviewRound),
        bindings: array(root.bindings).map(item => {
            const binding = record(item);
            return {
                relationshipId: text(binding.relationshipId),
                realization: normalizeRelationshipRealization(binding.realization, '', '') || {
                    kind: 'derived', ownerEntity: '',
                    from: { entityId: '', fieldIds: [] }, to: { entityId: '', fieldIds: [] }, description: '',
                },
            };
        }),
    };
}
export function applyNs4E4RelationshipBindings(review, draft) {
    const bindings = new Map(draft.bindings.map(binding => [binding.relationshipId, binding.realization]));
    return normalizeNs4E4Review({
        ...review,
        relationships: review.relationships.map(relationship => ({
            ...relationship,
            ...(bindings.has(relationship.relationshipId) ? { realization: bindings.get(relationship.relationshipId) } : {}),
        })),
    }, review.moduleName);
}
export function normalizeNs4E4DerivationBindings(value, moduleName, reviewRound) {
    const root = record(value);
    return {
        planId: 'e4-derivation-bindings',
        moduleName: text(root.moduleName) || moduleName,
        reviewRound: positiveInteger(root.reviewRound, reviewRound),
        bindings: array(root.bindings).map(item => {
            const binding = record(item);
            return {
                entityId: text(binding.entityId),
                derivation: normalizeDerivation(binding.derivation) || { from: '', filter: '', aggregate: [] },
            };
        }),
        ...(strings(root.changeSummary).length ? { changeSummary: strings(root.changeSummary) } : {}),
    };
}
export function applyNs4E4DerivationBindings(plan, payload) {
    const issues = [];
    const fieldIdChanges = [];
    const entities = plan.entities.map(entity => ({ ...entity }));
    array(record(payload).bindings).forEach((item, index) => {
        const binding = record(item);
        const extra = Object.keys(binding).filter(key => key !== 'entityId' && key !== 'derivation');
        if (extra.length) {
            issues.push({
                code: 'NS4_E4_DERIVATION_BINDING_SCOPE',
                path: `bindings[${index}]`,
                message: `A derivation binding may only replace derivation; extra keys: ${extra.join(', ')}.`,
            });
            return;
        }
        const entityId = text(binding.entityId);
        const entityIndex = entities.findIndex(entity => entity.entityId === entityId);
        if (entityIndex < 0) {
            issues.push({
                code: 'NS4_E4_DERIVATION_BINDING_SCOPE',
                path: `bindings[${index}].entityId`,
                message: `entityId '${entityId}' is not an entity in the frozen overview.`,
            });
            return;
        }
        const entity = entities[entityIndex];
        if (entity.kind !== 'projection' || entity.ownership !== 'derived') {
            issues.push({
                code: 'NS4_E4_DERIVATION_BINDING_SCOPE',
                path: `bindings[${index}].entityId`,
                message: `entityId '${entityId}' is not a derived projection; derivation binding cannot change it.`,
            });
            return;
        }
        const derivation = normalizeDerivation(binding.derivation);
        if (!derivation) {
            issues.push({
                code: 'NS4_E4_DERIVATION_BINDING_SCOPE',
                path: `bindings[${index}].derivation`,
                message: `bindings[${index}] did not supply a derivation for ${entityId}.`,
            });
            return;
        }
        const before = entity.derivation?.aggregate.map(entry => entry.fieldId) || [];
        const after = derivation.aggregate.map(entry => entry.fieldId);
        if (before.join('\0') !== after.join('\0'))
            fieldIdChanges.push({ entityId, before, after });
        entities[entityIndex] = { ...entity, derivation };
    });
    return { plan: { ...plan, entities }, issues, fieldIdChanges };
}
export async function buildNs4OntologyArtifacts(review, approvedBy, approvedAt) {
    const relationships = requireResolvedRelationships(review.relationships);
    const ontologyHash = await sha256Ns4({
        solutionMode: review.solutionMode,
        businessDomain: review.businessDomain,
        entities: review.entities,
        relationships,
    });
    const entities = review.entities.map(entity => ({
        schemaVersion: NS4_ONTOLOGY_SCHEMA_VERSION,
        moduleName: review.moduleName,
        userLanguage: review.userLanguage,
        solutionMode: review.solutionMode,
        ...entity,
        ontologyHash,
        approvedBy,
        approvedAt,
    }));
    return {
        entities,
        index: {
            schemaVersion: NS4_ONTOLOGY_SCHEMA_VERSION,
            moduleName: review.moduleName,
            userLanguage: review.userLanguage,
            solutionMode: review.solutionMode,
            title: review.title,
            businessDomain: review.businessDomain,
            entities: review.entities.map(entity => ({
                entityId: entity.entityId,
                title: entity.title,
                kind: entity.kind,
                storage: {
                    target: entity.storage.target,
                    scope: entity.storage.scope,
                    ...(entity.storage.idField ? { idField: entity.storage.idField } : {}),
                    ...(entity.storage.mdmType ? { mdmType: entity.storage.mdmType } : {}),
                },
                definitionRef: `l4/${review.moduleName}/ontology/${entity.entityId}.defs.ts`,
            })),
            relationships,
            ontologyHash,
            approvedBy,
            approvedAt,
            realization: { status: 'pending', compiledFromOntologyHash: ontologyHash },
            ...(review.systemDecisions?.length ? { systemDecisions: review.systemDecisions } : {}),
        },
    };
}
function requireResolvedRelationships(relationships) {
    return relationships.map(relationship => {
        if (!relationship.realization) {
            throw new Error(`Relationship ${relationship.relationshipId || '<unknown>'} has no field realization.`);
        }
        return { ...relationship, realization: relationship.realization };
    });
}
/** A status field is the one the lifecycle names; the suffix is the only stable structural marker. */
function isStatusFieldId(fieldId) {
    return /(^|[a-z0-9])status$/i.test(fieldId);
}
/**
 * Reads the literal values out of an enum constraint. The constraint value is authored as free text,
 * so the three shapes the generators actually produce are all accepted: a JSON array, a
 * comma-separated list and a pipe-separated list. Anything else yields no values, and the field
 * simply stays without a union.
 */
function enumValues(constraints) {
    const raw = constraints.find(constraint => constraint.kind === 'enum')?.value || '';
    if (!raw)
        return [];
    const trimmed = raw.trim();
    if (trimmed.startsWith('[')) {
        try {
            const parsed = JSON.parse(trimmed);
            if (Array.isArray(parsed))
                return unique(parsed.map(item => text(item)));
        }
        catch { /* not JSON: fall through to the separated forms */ }
    }
    const separator = trimmed.includes('|') ? '|' : ',';
    return unique(trimmed.replace(/^[[(]|[\])]$/g, '').split(separator).map(item => text(item).replace(/^['"]|['"]$/g, '')));
}
function unique(values) {
    return [...new Set(values.filter(Boolean))];
}
function enumLabels(value) {
    return array(value).map(item => {
        const entry = record(item);
        return { code: text(entry.code), label: text(entry.label) };
    }).filter(entry => entry.code || entry.label);
}
function party(value) {
    return value === 'person' || value === 'organization' || value === 'none' ? value : undefined;
}
function mutability(value) {
    if (value === 'editable' || value === 'appendOnly')
        return value;
    const raw = text(value);
    // Keep an illegal token so the gate can name it; omit when the model said nothing (absent = editable).
    return raw ? raw : undefined;
}
function derivationOp(value) {
    if (value === 'count' || value === 'sum' || value === 'min' || value === 'max'
        || value === 'first' || value === 'groupKey')
        return value;
    return undefined;
}
function normalizeSignBy(value) {
    const raw = record(value);
    const field = text(raw.field);
    const negativeValues = strings(raw.negativeValues);
    if (!field || !negativeValues.length)
        return undefined;
    return { field, negativeValues };
}
export function normalizeDerivation(value) {
    const raw = record(value);
    const from = text(raw.from);
    if (!from)
        return undefined;
    const aggregate = array(raw.aggregate).map(item => {
        const entry = record(item);
        const fieldId = text(entry.fieldId);
        const op = derivationOp(entry.op);
        if (!fieldId || !op)
            return undefined;
        const sourceField = text(entry.sourceField);
        const signBy = normalizeSignBy(entry.signBy);
        return { fieldId, op, ...(sourceField ? { sourceField } : {}), ...(signBy ? { signBy } : {}) };
    }).filter((item) => !!item);
    return { from, filter: text(raw.filter), aggregate };
}
function normalizeEntity(value, moduleName) {
    const entity = record(value);
    const sourceRefs = record(entity.sourceRefs);
    const storage = record(entity.storage);
    const entityId = text(entity.entityId);
    const kind = entityKind(entity.kind);
    const entityOwnership = ownership(entity.ownership);
    const lifecycleStates = normalizeLifecycleStates(entity.lifecycleStates);
    const lifecycleIds = lifecycleStateIds(lifecycleStates);
    const fields = array(entity.fields).map(item => {
        const field = record(item);
        const fieldId = text(field.fieldId);
        const constraints = array(field.constraints).map(constraintValue => {
            const constraint = record(constraintValue);
            return {
                constraintId: text(constraint.constraintId),
                kind: constraintKind(constraint.kind),
                value: text(constraint.value),
                description: text(constraint.description),
                source: constraintSource(constraint.source),
            };
        });
        const declared = enumValues(constraints);
        const values = declared.length ? declared : (isStatusFieldId(fieldId) ? lifecycleIds : []);
        return {
            fieldId,
            title: text(field.title),
            type: fieldType(field.type),
            required: field.required === true,
            description: text(field.description),
            constraints,
            ...(values.length ? { enum: values } : {}),
            ...(enumLabels(field.enumLabels).length ? { enumLabels: enumLabels(field.enumLabels) } : {}),
        };
    });
    const target = storageTarget(storage.target, kind, entityOwnership);
    const idField = text(storage.idField);
    const derivation = normalizeDerivation(entity.derivation);
    const subtype = text(entity.mdmSubtype);
    const displayField = text(entity.displayField);
    return {
        entityId,
        title: text(entity.title),
        description: text(entity.description),
        kind,
        ownership: entityOwnership,
        // ABSENT when the model did not declare it (or declared something outside the vocabulary), never
        // defaulted to 'none': defaulting would answer the party question on the model's behalf and the gate
        // would have nothing to complain about — which is the exact silence that let a person become a table.
        ...(party(entity.party) ? { party: party(entity.party) } : {}),
        ...(entity.cardinality === 'singleton' ? { cardinality: 'singleton' } : {}),
        ...(mutability(entity.mutability) ? { mutability: mutability(entity.mutability) } : {}),
        ...(derivation ? { derivation } : {}),
        ...(subtype ? { mdmSubtype: subtype } : {}),
        ...(kind === 'mdm' && entityId ? { role: `${moduleName}.${entityId}` } : {}),
        ...(displayField ? { displayField } : {}),
        sourceRefs: {
            journeyIds: strings(sourceRefs.journeyIds),
            featureIds: strings(sourceRefs.featureIds),
            authorityRefs: strings(sourceRefs.authorityRefs),
        },
        fields,
        lifecycleStates,
        ...(lifecycleIds.length ? { statusEnum: lifecycleIds } : {}),
        ...(enumLabels(entity.lifecycleLabels).length ? { lifecycleLabels: enumLabels(entity.lifecycleLabels) } : {}),
        ...(text(entity.initialState) ? { initialState: text(entity.initialState) } : {}),
        ...(strings(entity.terminalStates).length ? { terminalStates: strings(entity.terminalStates) } : {}),
        lifecyclePredicates: array(entity.lifecyclePredicates).map(item => {
            const predicate = record(item);
            return {
                predicateId: text(predicate.predicateId),
                description: text(predicate.description),
                stateIds: strings(predicate.stateIds),
                source: constraintSource(predicate.source),
            };
        }),
        useRules: strings(entity.useRules),
        storage: {
            target,
            scope: storageScope(storage.scope, target),
            ...(idField && (target === 'mdm' || target === 'moduleDatabase') ? { idField } : {}),
            ...(target === 'mdm' ? { mdmType: text(storage.mdmType) || `${moduleName}.${entityId}` } : {}),
            notes: text(storage.notes),
        },
    };
}
function storageTarget(value, kind, entityOwnership) {
    if (value === 'mdm' || value === 'moduleDatabase' || value === 'derived'
        || value === 'external' || value === 'embedded')
        return value;
    if (entityOwnership === 'external')
        return 'external';
    if (kind === 'mdm')
        return 'mdm';
    if (kind === 'projection')
        return 'derived';
    if (kind === 'valueObject')
        return 'embedded';
    return 'moduleDatabase';
}
function storageScope(value, target) {
    if (value === 'organization' || value === 'module' || value === 'platform' || value === 'none')
        return value;
    if (target === 'mdm')
        return 'organization';
    if (target === 'moduleDatabase')
        return 'module';
    if (target === 'external')
        return 'platform';
    return 'none';
}
function entityKind(value) {
    if (value === 'event' || value === 'supporting' || value === 'mdm' || value === 'projection' || value === 'valueObject')
        return value;
    return 'core';
}
function ownership(value) {
    if (value === 'external' || value === 'derived')
        return value;
    return 'moduleOwned';
}
function fieldType(value) {
    if (value === 'uuid' || value === 'text' || value === 'number' || value === 'integer' || value === 'boolean'
        || value === 'money' || value === 'date' || value === 'datetime' || value === 'json')
        return value;
    return 'string';
}
function constraintKind(value) {
    if (value === 'min' || value === 'max' || value === 'minLength' || value === 'maxLength'
        || value === 'pattern' || value === 'enum' || value === 'format' || value === 'unique')
        return value;
    return 'custom';
}
function constraintSource(value) {
    if (value === 'database' || value === 'journey' || value === 'user' || value === 'legacyCode')
        return value;
    return 'inferred';
}
function relationshipType(value) {
    if (value === 'oneToOne' || value === 'manyToOne' || value === 'manyToMany')
        return value;
    return 'oneToMany';
}
function relationshipPersistenceMode(entities, fromEntity, toEntity) {
    const from = entities.find(entity => entity.entityId === fromEntity)?.storage.target;
    const to = entities.find(entity => entity.entityId === toEntity)?.storage.target;
    if (from === 'embedded' || to === 'embedded')
        return 'embedded';
    if (from === 'external' || to === 'external')
        return 'externalReference';
    if (from === 'derived' || to === 'derived')
        return 'derivedJoin';
    if (from === 'mdm' && to === 'mdm')
        return 'mdmRelationship';
    if ((from === 'mdm' && to === 'moduleDatabase') || (from === 'moduleDatabase' && to === 'mdm')) {
        return 'crossStoreReference';
    }
    return 'moduleReference';
}
function normalizeRelationshipRealization(value, fallbackFromEntity, fallbackToEntity) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return undefined;
    const realization = record(value);
    const from = record(realization.from);
    const to = record(realization.to);
    return {
        kind: relationshipRealizationKind(realization.kind),
        ownerEntity: text(realization.ownerEntity),
        from: { entityId: text(from.entityId) || fallbackFromEntity, fieldIds: strings(from.fieldIds) },
        to: { entityId: text(to.entityId) || fallbackToEntity, fieldIds: strings(to.fieldIds) },
        description: text(realization.description),
    };
}
function relationshipRealizationKind(value) {
    if (value === 'fieldCollection' || value === 'mdmRelationship' || value === 'derived'
        || value === 'externalReference' || value === 'embedded')
        return value;
    return 'fieldReference';
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) { return Array.isArray(value) ? value : []; }
function strings(value) { return array(value).map(text).filter(Boolean); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
function reachedByOf(value) {
    return value === 'command' || value === 'time' ? value : 'actor';
}
/** Bare string = `actor`. After normalize, every entity carries objects. */
export function normalizeLifecycleStates(value) {
    const seen = new Set();
    const out = [];
    for (const item of array(value)) {
        const parsed = typeof item === 'string'
            ? { state: item.trim(), reachedBy: 'actor' }
            : (() => {
                const rec = record(item);
                const state = text(rec.state);
                const ruleRef = text(rec.ruleRef);
                return { state, reachedBy: reachedByOf(rec.reachedBy), ...(ruleRef ? { ruleRef } : {}) };
            })();
        if (!parsed.state || seen.has(parsed.state))
            continue;
        seen.add(parsed.state);
        out.push(parsed);
    }
    return out;
}
export function lifecycleStateIds(states) {
    return states.map(item => typeof item === 'string' ? item : item.state).filter(Boolean);
}
export function hasLifecycleState(states, state) {
    return lifecycleStateIds(states).includes(state);
}
export function lifecycleReachedBy(states, state) {
    for (const item of states) {
        if (typeof item === 'string') {
            if (item === state)
                return 'actor';
            continue;
        }
        if (item.state === state)
            return item.reachedBy === 'command' || item.reachedBy === 'time' ? item.reachedBy : 'actor';
    }
    return 'actor';
}
export function lifecycleRuleRef(states, state) {
    for (const item of states) {
        if (typeof item === 'string')
            continue;
        if (item.state === state)
            return item.ruleRef || '';
    }
    return '';
}
export function isTimeLifecycleState(states, state) {
    return lifecycleReachedBy(states, state) === 'time';
}
