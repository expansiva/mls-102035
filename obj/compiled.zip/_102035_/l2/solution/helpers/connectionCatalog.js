/// <mls fileReference="_102035_/l2/solution/helpers/connectionCatalog.ts" enhancement="_blank"/>
import cmCatalog from '/_102034_/l1/server/layer_1_external/connections/catalogs/cm.js';
import platformCatalog from '/_102034_/l1/server/layer_1_external/connections/catalogs/platform.js';
/**
 * Closed connection catalogs the NS5 gate reads: the platform's own files in `102034/l1/server/layer_1_external/connections/catalogs/`.
 * `solution/fixtures/connections/cm.defs.ts` is a test copy of the `cm` one (see `connectionCatalog.test.ts`).
 */
export function ns5ConnectionCatalogs() {
    // An operation `servedBy: 'platform'` is the platform's to answer: a module never chooses it nor serves it.
    // `platform` (releaseCatalogChanged, M5): the module that serves the catalog of the release uses it (l4_p4_108).
    // Its signal is its own operation, never the word `platform` (see CONNECTION_SIGNAL_GROUPS).
    return [cmCatalog, platformCatalog].map(catalog => ({
        ...catalog,
        operations: catalog.operations.filter(operation => !operation.servedBy),
    }));
}
export function ns5ConnectionOperation(connectionId, operationId) {
    const catalog = ns5ConnectionCatalogs().find(item => item.connectionId === connectionId);
    if (catalog === undefined)
        return undefined;
    return catalog.operations.find(item => item.operationId === operationId);
}
/**
 * What in a prompt says the module talks to a connection. Each group is a set of words that must ALL appear;
 * any group is enough. A connection with no row here answers to its `connectionId`. The id `platform` is a
 * common word, so it is never a term: the platform connection answers to its own operation or to a release
 * together with a catalog (l4_p4_108 s0).
 */
const CONNECTION_SIGNAL_GROUPS = {
    cm: [['cm']],
    platform: [['releaseCatalogChanged'], ['release', 'catalog']],
};
/** `mentions` is the word test of the caller (`promptMentionsTerm`), so this file does not import its gate. */
export function ns5ConnectionSignalHits(sourcePrompt, mentions) {
    const hits = [];
    for (const catalog of ns5ConnectionCatalogs()) {
        const groups = CONNECTION_SIGNAL_GROUPS[catalog.connectionId] ?? [[catalog.connectionId]];
        for (const group of groups) {
            if (group.every(term => mentions(sourcePrompt, term))) {
                hits.push({ connectionId: catalog.connectionId, term: group.join(' + ') });
                break;
            }
        }
    }
    return hits;
}
export function ns5ConnectionTerms() {
    return ns5ConnectionCatalogs().map(item => item.connectionId);
}
export function ns5ConnectionExists(connectionId) {
    return ns5ConnectionCatalogs().some(item => item.connectionId === connectionId);
}
/** The `serve` operations of one connection: what the connection delivers to a module. */
export function ns5ServeOperationIds(connectionId) {
    const catalog = ns5ConnectionCatalogs().find(item => item.connectionId === connectionId);
    return (catalog?.operations ?? []).filter(item => item.direction === 'serve').map(item => item.operationId);
}
/** Every arrival a connection of the catalog can deliver, as `<connectionId>.<operationId>` and its description. */
export function ns5ConnectionArrivals() {
    return ns5ConnectionCatalogs().flatMap(catalog => catalog.operations
        .filter(operation => operation.direction === 'serve')
        .map(operation => ({ ref: `${catalog.connectionId}.${operation.operationId}`, description: operation.description })));
}
