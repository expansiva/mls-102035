/// <mls fileReference="_102035_/l2/solution/helpers/ns4ContentRead.ts" enhancement="_blank"/>
/** Local-first content resolution that never sends the unsaved versionRef=0 to a remote driver. */
export async function readNs4AvailableContent(file, extension) {
    if (file.getValueInfo) {
        try {
            const local = await file.getValueInfo();
            const localText = ns4ContentText(local?.content, extension);
            if (localText !== null)
                return { text: localText, unavailableNewFile: false };
        }
        catch { /* fall through to a committed remote version */ }
    }
    if (String(file.versionRef || '').trim() === '0')
        return { text: null, unavailableNewFile: true };
    return { text: ns4ContentText(await file.getContent(), extension), unavailableNewFile: false };
}
function ns4ContentText(content, extension) {
    if (typeof content === 'string')
        return content;
    if (extension === '.json' && typeof content === 'object' && content !== null) {
        return `${JSON.stringify(content, null, 2)}\n`;
    }
    return null;
}
