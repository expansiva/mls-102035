/// <mls fileReference="_102035_/l2/solution/helpers/ns4Context.ts" enhancement="_blank"/>
/**
 * The single place where journey contexts are derived. E2 owns narrative, sequence, step kind and
 * step entity; nothing declares a context id, a cardinality or a provider. Every consumer (E7, E8,
 * E9) reads the same derivation so a context can never mean two things in two steps.
 */
import { ns4EntityIdField } from '/_102035_/l2/solution/helpers/ns4EntityFields.js';
/** A context id is a pure function of its entity, so the catalog and the E9 store are entity-keyed. */
export function ns4ContextIdOf(entity) {
    return entity ? `selected${upperCamel(entity)}` : '';
}
/**
 * Inspect of entity X that still has no selected X, while a later step locates X, is a collection
 * summary (counts of the listing) — not getById of one record. Identity-free by construction.
 */
export function isNs4CollectionInspect(steps, index) {
    const step = steps[index];
    if (!step || step.kind !== 'inspect' || !step.entity)
        return false;
    const laterLocate = steps.slice(index + 1).some(item => item.kind === 'locate' && item.entity === step.entity);
    const earlierOfSame = steps.slice(0, index).some(item => item.entity === step.entity
        && (item.kind === 'locate' || item.kind === 'act' || item.kind === 'inspect'));
    return laterLocate && !earlierOfSame;
}
/**
 * Platform-owned records are supplied by the runtime session, never selected by the user, so they
 * are not a coordination requirement of a business step.
 */
export function isNs4PlatformOwnedEntity(entity) {
    return entity.ownership === 'external' && entity.storage?.target === 'external' && entity.storage.scope === 'platform';
}
export function deriveNs4Contexts(sources) {
    const entities = new Map(sources.ontology.entities.map(entity => [entity.entityId, entity]));
    const sessionOwned = new Set([...entities.values()].filter(isNs4PlatformOwnedEntity).map(entity => entity.entityId));
    const parentsByEntity = requiredParents(sources.ontology.relationships, sessionOwned);
    const context = (entity) => {
        const idFieldRef = idFieldOf(entities.get(entity));
        return { contextId: ns4ContextIdOf(entity), businessObject: entity, cardinality: 'one', required: true,
            ...(idFieldRef ? { idFieldRef } : {}) };
    };
    const steps = [];
    for (const journey of sources.journeys.journeys) {
        const provided = new Set();
        const journeySteps = journey.business.steps;
        for (let index = 0; index < journeySteps.length; index++) {
            const step = journeySteps[index];
            const entity = step.entity;
            const creates = step.kind === 'act' && !provided.has(entity);
            const requires = new Map();
            // Collection inspect (totals of a listing) is not a selected record: it comes before a
            // locate of the same entity. A later inspect of one row still requires the identity.
            if (entity && !creates && step.kind !== 'locate' && !isNs4CollectionInspect(journeySteps, index)) {
                requires.set(entity, context(entity));
            }
            if (entity && (step.kind === 'act' || step.kind === 'decide')) {
                for (const parent of parentsByEntity.get(entity) || []) {
                    if (parent !== entity)
                        requires.set(parent, context(parent));
                }
            }
            const stepRef = `${journey.journeyId}.${step.stepId}`;
            steps.push({ journeyId: journey.journeyId, stepId: step.stepId, stepRef, kind: step.kind, entity, creates,
                requires: sortContexts([...requires.values()]), provides: entity ? [context(entity)] : [] });
            if (entity)
                provided.add(entity);
        }
    }
    const byStepRef = new Map(steps.map(step => [step.stepRef, step]));
    const entryByJourneyId = new Map();
    const profilesByActor = new Map();
    for (const profile of sources.access?.profiles || []) {
        for (const actor of profile.actorRefs || [])
            profilesByActor.set(actor, [...(profilesByActor.get(actor) || []), profile.profileId]);
    }
    for (const journey of sources.journeys.journeys) {
        const mode = journey.business.entry.mode;
        const first = journey.business.steps[0];
        if (mode === 'coldStart' || !first?.entity) {
            entryByJourneyId.set(journey.journeyId, []);
            continue;
        }
        if (mode === 'eventDriven') {
            const receiverProfiles = profilesByActor.get(journey.business.actorRef) || [];
            const sender = steps.find(step => step.kind === 'handoff' && step.journeyId !== journey.journeyId
                && receiverProfiles.includes(handoffTarget(sources, step.stepRef)));
            entryByJourneyId.set(journey.journeyId, [context(sender?.entity || first.entity)]);
            continue;
        }
        entryByJourneyId.set(journey.journeyId, [context(first.entity)]);
    }
    const catalog = sortContexts([...new Map([
            ...steps.flatMap(step => [...step.provides, ...step.requires]),
            ...[...entryByJourneyId.values()].flat(),
        ].map(item => [item.contextId, item])).values()]);
    return { catalog, steps, byStepRef, entryByJourneyId };
}
/** Business objects the ontology must realize: exactly the entities the journeys operate on. */
export function collectNs4JourneyEntities(journeys) {
    return [...new Set(journeys.journeys.flatMap(journey => journey.business.steps.flatMap(step => [
            step.entity,
            ...(step.affects || []),
        ])).filter(Boolean))].sort();
}
function handoffTarget(sources, stepRef) {
    const [journeyId, stepId] = splitRef(stepRef);
    const journey = sources.journeys.journeys.find(item => item.journeyId === journeyId);
    return journey?.business.steps.find(step => step.stepId === stepId)?.targetProfile || '';
}
function splitRef(stepRef) {
    const separator = stepRef.indexOf('.');
    return separator < 0 ? [stepRef, ''] : [stepRef.slice(0, separator), stepRef.slice(separator + 1)];
}
function requiredParents(relationships, sessionOwned) {
    const result = new Map();
    for (const relationship of relationships) {
        if (!relationship.required || sessionOwned.has(relationship.toEntity))
            continue;
        if (relationship.type !== 'manyToOne' && relationship.type !== 'oneToOne')
            continue;
        const current = result.get(relationship.fromEntity) || [];
        if (!current.includes(relationship.toEntity))
            current.push(relationship.toEntity);
        result.set(relationship.fromEntity, current);
    }
    for (const [entity, parents] of result)
        result.set(entity, [...parents].sort());
    return result;
}
function idFieldOf(entity) {
    return ns4EntityIdField(entity);
}
function sortContexts(values) {
    return [...values].sort((left, right) => left.contextId.localeCompare(right.contextId));
}
function upperCamel(value) {
    return value ? value.slice(0, 1).toUpperCase() + value.slice(1) : '';
}
