/// <mls fileReference="_102035_/l2/solution/helpers/e1/contracts.ts" enhancement="_blank"/>
import { NS4_FLOW_ID, NS4_FLOW_VERSION, NS4_MODULE_SCHEMA_VERSION, foldNs4Text, normalizeNs4Languages, normalizeNs4ModuleName, ns4LanguageMentioned, } from '/_102035_/l2/solution/helpers/ns4Core.js';
/** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
export const TEXT_PATHS_2026_08_06_ns4_module_v4 = [
    'module.title',
    'module.purpose',
    'designContext.initialPrompt',
    'designContext.clarification.mainActors',
    'designContext.clarification.mainGoal',
    'designContext.clarification.boundaries',
    'solutionStrategy.rationale',
    'solutionStrategy.modernization.sourceSystemName',
    'solutionStrategy.modernization.sourceTechnology',
    'solutionStrategy.modernization.notes',
    'businessScope.mainGoal',
    'businessScope.actors[].title',
    'businessScope.actors[].expectedOutcome',
    'businessScope.expectedOutcomes[].title',
    'businessScope.expectedOutcomes[].description',
    'businessScope.inScope[]',
    'businessScope.outOfScope[]',
    'localization.primaryMarket',
    'declaredConstraints.mandatoryIntegrations[].title',
    'declaredConstraints.mandatoryIntegrations[].reason',
    'declaredConstraints.regulatoryNotes',
    'declaredConstraints.criticalNotes',
    'presentation.stepTitles.*',
    'presentation.phrases.*',
];
export function normalizeNs4E1Review(value, fallback = {}) {
    const root = record(value);
    const module = record(root.module);
    const strategy = record(root.strategy);
    const scope = record(root.businessScope);
    const localization = record(root.localization);
    const reviewPolicy = record(root.reviewPolicy);
    const legacy = record(root.questions);
    const moduleName = normalizeNs4ModuleName(text(module.moduleName) || text(legacy.moduleName?.answer) || fallback.moduleName || fallback.sourcePrompt || 'newModule');
    const userLanguage = normalizeNs4Languages(root.userLanguage || fallback.userLanguage || 'en')[0];
    const clarificationLanguagesAnswer = text(legacy.productLanguages?.answer) || text(fallback.productLanguages);
    const requestedLanguages = normalizeNs4Languages(localization.productLanguages || clarificationLanguagesAnswer || userLanguage, userLanguage);
    // Languages are a user decision, never an LLM guess. When the caller supplies the provenance
    // context (clarification answer and/or the original prompt), every language the user did not cite
    // is discarded with a warning instead of silently reaching the l4 — run02 of 102047 shipped en/es
    // for a pt-BR-only request and the CF finalize auto-dispatched @@addLanguage for both. Under `/fast`
    // the planner answer is a proposal, not a citation (`answerIsProposal`), so only `sourcePrompt` cites.
    const provenanceKnown = fallback.sourcePrompt !== undefined || fallback.productLanguages !== undefined || Boolean(clarificationLanguagesAnswer);
    const i18nWarnings = [];
    const provenanceAnswer = fallback.answerIsProposal ? '' : clarificationLanguagesAnswer;
    const languages = provenanceKnown
        ? filterNs4LanguagesByProvenance(requestedLanguages, userLanguage, provenanceAnswer, text(fallback.sourcePrompt), i18nWarnings)
        : requestedLanguages;
    const declaredDefault = normalizeNs4Languages(localization.defaultLanguage || languages[0], languages[0])[0];
    // A default that was itself discarded follows the list; any other mismatch keeps failing the gate.
    const defaultLanguage = !languages.some(language => sameNs4Language(language, declaredDefault))
        && requestedLanguages.some(language => sameNs4Language(language, declaredDefault))
        ? languages[0]
        : declaredDefault;
    const requestedMode = strategy.mode;
    const mode = requestedMode === 'modernizePreserveDatabase' || requestedMode === 'modernizeEvolveDatabase' || requestedMode === 'replaceAndMigrateData' ? requestedMode : 'newSolution';
    const actors = list(scope.actors).map((item, index) => {
        const actor = record(item);
        return {
            actorId: stableId(text(actor.actorId) || text(actor.title), `actor${index + 1}`),
            title: text(actor.title),
            kind: actor.kind === 'external' || actor.kind === 'system' ? actor.kind : 'internal',
            origin: actor.origin === 'named' ? 'named' : 'inferred',
            expectedOutcome: text(actor.expectedOutcome),
        };
    }).filter(actor => actor.title);
    const legacyActors = text(legacy.mainActors?.answer) || fallback.mainActors || '';
    const safeActors = actors.length ? actors : legacyActors ? [{
            actorId: 'primaryActor',
            title: legacyActors,
            kind: 'internal',
            origin: 'named',
            expectedOutcome: text(scope.mainGoal) || text(legacy.mainGoal?.answer) || fallback.mainGoal || '',
        }] : [];
    const outcomes = list(scope.expectedOutcomes).map((item, index) => {
        const outcome = record(item);
        return { outcomeId: stableId(text(outcome.outcomeId) || text(outcome.title), `outcome${index + 1}`), title: text(outcome.title), description: text(outcome.description) };
    }).filter(outcome => outcome.title);
    const mainGoal = text(scope.mainGoal) || text(legacy.mainGoal?.answer) || fallback.mainGoal || '';
    const safeOutcomes = outcomes.length ? outcomes : mainGoal ? [{ outcomeId: 'primaryOutcome', title: mainGoal, description: mainGoal }] : [];
    const modernization = record(strategy.modernization);
    const policy = policyFor(mode);
    return {
        planId: 'e1-review', reviewRound: positive(root.reviewRound, 1), userLanguage,
        reviewPolicy: { mode: reviewPolicy.mode === 'guided' || reviewPolicy.mode === 'automatic' ? reviewPolicy.mode : 'smart' },
        module: { moduleName, title: text(module.title) || humanize(moduleName), purpose: text(module.purpose) || mainGoal },
        strategy: {
            mode, rationale: text(strategy.rationale), databaseChangePolicy: policy,
            ...(mode !== 'newSolution' ? { modernization: { sourceSystemName: text(modernization.sourceSystemName), sourceTechnology: text(modernization.sourceTechnology), databaseEngine: text(modernization.databaseEngine), databaseVersion: text(modernization.databaseVersion), schemaAvailability: modernization.schemaAvailability === 'metadataAtE4' || modernization.schemaAvailability === 'notAvailableYet' ? modernization.schemaAvailability : 'uploadAtE4', notes: text(modernization.notes) } } : {}),
        },
        businessScope: { mainGoal, actors: safeActors, expectedOutcomes: safeOutcomes, inScope: strings(scope.inScope), outOfScope: strings(scope.outOfScope) },
        localization: { productLanguages: languages, defaultLanguage, defaultLocale: text(localization.defaultLocale), currency: text(localization.currency), timeZone: text(localization.timeZone), primaryMarket: text(localization.primaryMarket) },
        declaredConstraints: { mandatoryIntegrations: list(record(root.declaredConstraints).mandatoryIntegrations).map((item, index) => { const dependency = record(item); return { dependencyId: stableId(text(dependency.dependencyId) || text(dependency.title), `dependency${index + 1}`), title: text(dependency.title), kind: dependency.kind === 'externalSystem' || dependency.kind === 'platform' ? dependency.kind : 'unknown', reason: text(dependency.reason) }; }).filter(item => item.title || item.reason), regulatoryNotes: text(record(root.declaredConstraints).regulatoryNotes), criticalNotes: text(record(root.declaredConstraints).criticalNotes) },
        changeSummary: strings(root.changeSummary),
        ...(i18nWarnings.length ? { i18nWarnings } : {}),
    };
}
export function policyFor(mode) {
    if (mode === 'modernizePreserveDatabase')
        return 'forbidden';
    if (mode === 'modernizeEvolveDatabase')
        return 'additiveControlled';
    if (mode === 'replaceAndMigrateData')
        return 'replacement';
    return 'new';
}
export function validateNs4E1Review(review) {
    const issues = [];
    const add = (code, message, path, severity = 'error') => {
        issues.push({ severity, code, message, ...(path ? { path } : {}) });
    };
    if (review.planId !== 'e1-review')
        add('NS4_E1_PLAN', 'The E1 review planId is invalid.', 'planId');
    if (!/^[a-z][A-Za-z0-9]*$/.test(review.module.moduleName)
        || review.module.moduleName !== normalizeNs4ModuleName(review.module.moduleName)) {
        add('NS4_E1_MODULE_ID', 'The technical module name must be normalized lower camel case.', 'module.moduleName');
    }
    if (!review.module.title.trim())
        add('NS4_E1_MODULE_TITLE', 'The friendly module title is required.', 'module.title');
    if (!review.module.purpose.trim())
        add('NS4_E1_MODULE_PURPOSE', 'The module objective is required.', 'module.purpose');
    if (!review.userLanguage.trim())
        add('NS4_E1_USER_LANGUAGE', 'The conversation language is required.', 'userLanguage');
    const normalizedLanguages = normalizeNs4Languages(review.localization.productLanguages);
    if (!review.localization.productLanguages.length) {
        add('NS4_E1_LANGUAGES', 'At least one product language is required.', 'localization.productLanguages');
    }
    else if (normalizedLanguages.length !== review.localization.productLanguages.length
        || normalizedLanguages.some((language, index) => language !== review.localization.productLanguages[index])) {
        add('NS4_E1_LANGUAGES_NORMALIZED', 'Product languages must be unique normalized BCP-47 tags.', 'localization.productLanguages');
    }
    if (!review.localization.defaultLanguage
        || !review.localization.productLanguages.includes(review.localization.defaultLanguage)) {
        add('NS4_E1_DEFAULT_LANGUAGE', 'The default language must belong to the product language list.', 'localization.defaultLanguage');
    }
    for (const warning of review.i18nWarnings || []) {
        add('NS4_E1_LANGUAGES_PROVENANCE', warning, 'localization.productLanguages', 'warning');
    }
    if (!review.businessScope.mainGoal.trim())
        add('NS4_E1_MAIN_GOAL', 'The main business goal is required.', 'businessScope.mainGoal');
    validateMembers(review.businessScope.actors, 'actorId', 'businessScope.actors', issues);
    validateMembers(review.businessScope.expectedOutcomes, 'outcomeId', 'businessScope.expectedOutcomes', issues);
    if (!review.businessScope.actors.length)
        add('NS4_E1_ACTORS', 'At least one business actor is required.', 'businessScope.actors');
    if (!review.businessScope.expectedOutcomes.length)
        add('NS4_E1_OUTCOMES', 'At least one expected outcome is required.', 'businessScope.expectedOutcomes');
    review.businessScope.actors.forEach((actor, index) => {
        if (!actor.title.trim())
            add('NS4_E1_ACTOR_TITLE', 'Every actor needs a friendly title.', `businessScope.actors[${index}].title`);
        if (!actor.expectedOutcome.trim())
            add('NS4_E1_ACTOR_OUTCOME', 'Every actor needs an expected outcome.', `businessScope.actors[${index}].expectedOutcome`);
        if (actor.origin !== 'named' && actor.origin !== 'inferred') {
            add('NS4_E1_ACTOR_ORIGIN', 'Every actor declares origin named or inferred.', `businessScope.actors[${index}].origin`);
        }
    });
    review.businessScope.expectedOutcomes.forEach((outcome, index) => {
        if (!outcome.title.trim())
            add('NS4_E1_OUTCOME_TITLE', 'Every outcome needs a title.', `businessScope.expectedOutcomes[${index}].title`);
        if (!outcome.description.trim())
            add('NS4_E1_OUTCOME_DESCRIPTION', 'Every outcome needs a description.', `businessScope.expectedOutcomes[${index}].description`);
    });
    const inScope = new Set(review.businessScope.inScope.map(item => item.trim().toLowerCase()).filter(Boolean));
    review.businessScope.outOfScope.forEach((item, index) => {
        if (inScope.has(item.trim().toLowerCase()))
            add('NS4_E1_SCOPE_CONTRADICTION', 'The same item cannot be both in and out of scope.', `businessScope.outOfScope[${index}]`);
    });
    if (review.strategy.databaseChangePolicy !== policyFor(review.strategy.mode)) {
        add('NS4_E1_DATABASE_POLICY', 'The database change policy does not match the selected strategy.', 'strategy.databaseChangePolicy');
    }
    if (!review.strategy.rationale.trim()) {
        add('NS4_E1_STRATEGY_RATIONALE', 'Explain why the selected solution strategy fits this module.', 'strategy.rationale');
    }
    if (review.strategy.mode === 'newSolution') {
        if (review.strategy.modernization?.sourceSystemName)
            add('NS4_E1_NEW_WITH_LEGACY', 'A new solution must not declare a mandatory legacy source system.', 'strategy.modernization');
    }
    else {
        if (!review.strategy.modernization?.sourceSystemName.trim())
            add('NS4_E1_SOURCE_SYSTEM', 'Modernization requires the source system name.', 'strategy.modernization.sourceSystemName');
        if (!review.strategy.modernization?.schemaAvailability)
            add('NS4_E1_SCHEMA_AVAILABILITY', 'Modernization requires schema availability.', 'strategy.modernization.schemaAvailability');
    }
    validateMembers(review.declaredConstraints.mandatoryIntegrations, 'dependencyId', 'declaredConstraints.mandatoryIntegrations', issues);
    review.declaredConstraints.mandatoryIntegrations.forEach((dependency, index) => {
        if (!dependency.title.trim())
            add('NS4_E1_DEPENDENCY_TITLE', 'Every mandatory integration needs a title.', `declaredConstraints.mandatoryIntegrations[${index}].title`);
        if (!dependency.reason.trim())
            add('NS4_E1_DEPENDENCY_REASON', 'Every mandatory integration needs a reason.', `declaredConstraints.mandatoryIntegrations[${index}].reason`);
    });
    return { ok: !issues.some(issue => issue.severity === 'error'), issues };
}
export function buildNs4ModuleArtifactFromReview(review, sourcePrompt, approvedBy, presentation, now = new Date().toISOString()) {
    const gate = validateNs4E1Review(review);
    if (!gate.ok)
        throw new Error(gate.issues.filter(issue => issue.severity === 'error').map(issue => `${issue.code}: ${issue.message}`).join('\n'));
    return {
        schemaVersion: NS4_MODULE_SCHEMA_VERSION,
        presentation,
        module: {
            moduleName: review.module.moduleName,
            title: review.module.title,
            purpose: review.module.purpose,
            languages: [...review.localization.productLanguages],
        },
        designContext: {
            initialPrompt: sourcePrompt.trim() || review.module.moduleName,
            clarification: {
                mainActors: review.businessScope.actors.map(actor => actor.title).join(', '),
                mainGoal: review.businessScope.mainGoal,
                boundaries: [
                    ...review.businessScope.inScope.map(item => `in: ${item}`),
                    ...review.businessScope.outOfScope.map(item => `out: ${item}`),
                ].join('; '),
            },
        },
        reviewPolicy: { ...review.reviewPolicy },
        solutionStrategy: {
            ...review.strategy,
            ...(review.strategy.modernization ? { modernization: { ...review.strategy.modernization } } : {}),
        },
        businessScope: {
            ...review.businessScope,
            actors: review.businessScope.actors.map(actor => ({ ...actor })),
            expectedOutcomes: review.businessScope.expectedOutcomes.map(outcome => ({ ...outcome })),
            inScope: [...review.businessScope.inScope],
            outOfScope: [...review.businessScope.outOfScope],
        },
        localization: { ...review.localization, productLanguages: [...review.localization.productLanguages] },
        declaredConstraints: {
            ...review.declaredConstraints,
            mandatoryIntegrations: review.declaredConstraints.mandatoryIntegrations.map(item => ({ ...item })),
        },
        specStatus: {
            flowId: NS4_FLOW_ID,
            flowVersion: NS4_FLOW_VERSION,
            state: 'inProgress',
            artifactCompleteness: 'partial',
            completedSteps: [{ stepId: 'e1', status: 'approved', approvedBy, approvedAt: now }],
            nextStep: 'e2-journeys',
            updatedAt: now,
        },
    };
}
function validateMembers(values, idKey, path, issues) {
    const ids = new Set();
    values.forEach((value, index) => {
        const source = record(value);
        const id = typeof source[idKey] === 'string' ? String(source[idKey]) : '';
        if (!/^[a-z][A-Za-z0-9]*$/.test(id))
            issues.push({ severity: 'error', code: 'NS4_E1_MEMBER_ID', message: `${idKey} must be lower camel case.`, path: `${path}[${index}].${idKey}` });
        if (ids.has(id))
            issues.push({ severity: 'error', code: 'NS4_E1_MEMBER_DUPLICATE', message: `Duplicate ${idKey} ${id}.`, path: `${path}[${index}].${idKey}` });
        if (id)
            ids.add(id);
    });
}
/**
 * Keeps only the product languages the user actually cited: the tag itself in the clarification
 * answer, or the tag/language name in the answer or original prompt. Everything else is discarded
 * with a warning — when in doubt, discard; the human can add the language back in the E1 review.
 */
function filterNs4LanguagesByProvenance(languages, userLanguage, clarificationAnswer, sourcePrompt, warnings) {
    const answerTags = clarificationAnswer ? normalizeNs4Languages(clarificationAnswer, userLanguage) : [];
    const citedText = foldNs4Text(`${clarificationAnswer}\n${sourcePrompt}`);
    const kept = [];
    const discarded = [];
    for (const language of languages) {
        const cited = sameNs4Language(language, userLanguage)
            || answerTags.some(tag => sameNs4Language(tag, language))
            || ns4LanguageMentioned(language, userLanguage, citedText);
        (cited ? kept : discarded).push(language);
    }
    if (discarded.length) {
        warnings.push(`localization.productLanguages: discarded ${discarded.join(', ')} — languages are a user decision and the user did not cite them in the clarification answer or in the original prompt; kept ${(kept.length ? kept : [userLanguage]).join(', ')}.`);
    }
    return kept.length ? kept : normalizeNs4Languages(userLanguage);
}
function sameNs4Language(a, b) {
    return a.toLowerCase() === b.toLowerCase() || a.split('-')[0].toLowerCase() === b.split('-')[0].toLowerCase();
}
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
function list(value) { return Array.isArray(value) ? value : []; }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function strings(value) { return list(value).map(text).filter(Boolean); }
function positive(value, fallback) { return typeof value === 'number' && value > 0 ? Math.floor(value) : fallback; }
function stableId(value, fallback) { return normalizeNs4ModuleName(value || fallback, fallback); }
function humanize(value) { return value.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/^./, item => item.toUpperCase()); }
