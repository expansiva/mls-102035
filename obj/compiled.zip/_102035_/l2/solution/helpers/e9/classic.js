/// <mls fileReference="_102035_/l2/solution/helpers/e9/classic.ts" enhancement="_blank"/>
/**
 * E9 is a transpiler. It takes no screen decision: every workspace, call, section and operation was
 * already decided by E8. What lives here is the shape the consumers read — the classic L4 format
 * that agentChangeBackend and agentMaterializeL2 already parse today.
 *
 * The one thing that must be exactly right is the `from` path of a projected field,
 * `"<operationId>.<inputId>"`, because both consumers trace an input's origin and an enumerated
 * field's literal union back through it (cbContracts.resolveBffProjection and
 * cfeL4Contract.bffCallCommandShape).
 */
import { sha256Ns4 } from '/_102035_/l2/solution/helpers/e2/contracts.js';
import { NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION, } from '/_102035_/l2/solution/helpers/e3/contracts.js';
import { ns4EntityIdField, ns4ResolvableFieldOf } from '/_102035_/l2/solution/helpers/ns4EntityFields.js';
export const NS4_CLASSIC_WORKSPACE_VERSION = '2026-08-14-ns4-classic-workspace-v6';
export const NS4_E9_OUTPUT_REF_UNKNOWN = 'NS4_E9_OUTPUT_REF_UNKNOWN';
/** Human-text JSON paths the importer may rewrite. Classic L4 has no schemaVersion on operations/siteMap. */
export const TEXT_PATHS_2026_08_14_ns4_classic_workspace_v6 = [
    'title',
    'purpose',
    'sections[].intent',
    'presentation.classificationNote',
];
export const TEXT_PATHS_CLASSIC_WORKSPACE = TEXT_PATHS_2026_08_14_ns4_classic_workspace_v6;
export const TEXT_PATHS_CLASSIC_OPERATION = [
    'title',
    'story.goal',
    'story.steps[]',
    'story.outcome',
    'accessPattern.description',
    'inputs[].description',
];
export const TEXT_PATHS_CLASSIC_SITE_MAP = [
    'note',
    'workspaces[].title',
    'workspaces[].purpose',
    'landings[].reason',
    'navigationEdges[].description',
];
export class Ns4E9OutputRefError extends Error {
    constructor(ref) {
        super(`${NS4_E9_OUTPUT_REF_UNKNOWN}: outputRef '${ref}' does not resolve to an ontology field`);
        this.code = NS4_E9_OUTPUT_REF_UNKNOWN;
        this.name = 'Ns4E9OutputRefError';
    }
}
/** `<operationId>.<inputId>`: the only path both consumers know how to trace back. */
export function ns4ClassicFrom(operationId, member) {
    return `${operationId}.${member}`;
}
export function transposeNs4ClassicOperation(model, operation, ontology, useCases = []) {
    const entity = ontology.entities.find(item => item.entityId === operation.entityRef);
    const owner = model.workspaces.find(workspace => workspace.bffCalls.some(call => call.operationId === operation.operationId));
    const call = owner?.bffCalls.find(item => item.operationId === operation.operationId);
    const list = operation.accessPattern.kind === 'list';
    const paginated = isPaginated(operation.accessPattern.pagination, call?.outputKind);
    const outputFields = resolveClassicOutputFields(operation, ontology);
    const writeIds = classicWriteIds(operation, useCases);
    const writeSet = new Set(writeIds);
    return {
        operationId: operation.operationId,
        title: operation.title,
        actors: owner?.actors || [],
        entity: operation.entityRef,
        kind: operation.kind === 'query' ? 'query' : operation.accessPattern.kind,
        reads: uniqueStrings(operation.entityRefs.filter(id => !writeSet.has(id))),
        writes: writeIds,
        rulesApplied: operation.useRules,
        story: {
            actor: owner?.actors[0] || '', goal: operation.title,
            steps: operation.story, outcome: operation.story[operation.story.length - 1] || operation.title,
        },
        accessPattern: {
            kind: operation.accessPattern.kind,
            description: operation.title,
            entity: operation.entityRef,
            keyField: `${operation.entityRef}.${identityFieldOf(entity)}`,
            pagination: operation.accessPattern.pagination ?? (paginated ? 'optional' : 'none'),
            selection: list ? 'single' : 'none',
            output: outputFields.map(field => field.fieldRef),
        },
        outputShape: paginated
            ? paginatedOutputShape(collectionFieldName(operation.entityRef), outputFields)
            : { kind: list ? 'list' : 'object', fields: outputFields },
        inputs: operation.inputs.map(input => ({
            inputId: input.inputId,
            fieldRef: `${input.fieldRef.entityId}.${input.fieldRef.fieldId}`,
            required: input.required,
            source: input.source,
            description: input.description,
            ...(input.enumValues?.length ? { enumValues: input.enumValues } : {}),
            ...(input.type ? { type: input.type } : {}),
        })),
        ...(operation.mdm ? { mdm: operation.mdm } : {}),
        pageId: owner?.workspaceId || '',
        commandName: call?.bffId || operation.operationId,
        bffName: call?.bffId || operation.operationId,
    };
}
export function transposeNs4ClassicWorkspace(model, workspace, operations, ontology, sliceHash) {
    const bffCalls = workspace.bffCalls.map(call => transposeCall(model, workspace.workspaceId, call, operations.get(call.operationId), ontology));
    return {
        workspaceId: workspace.workspaceId,
        title: workspace.title,
        actors: workspace.actors.length ? workspace.actors : workspace.profileRefs,
        kind: workspace.kind,
        entity: workspace.entity,
        ...(workspace.workflowId ? { workflowId: workspace.workflowId } : {}),
        bffCalls,
        sections: workspace.sections.map(section => ({
            sectionId: section.sectionId,
            intent: section.intent,
            organisms: section.organisms.map(organism => ({
                role: organism.role,
                ...(organism.type ? { type: organism.type } : {}),
                ...(organism.dataSource ? { dataSource: organism.dataSource } : {}),
                ...(organism.action ? { action: organism.action } : {}),
                ...(organism.usage ? { usage: organism.usage } : {}),
                ...(organism.attachTo ? { attachTo: organism.attachTo } : {}),
            })),
        })),
        operationIds: [...new Set(workspace.bffCalls.map(call => call.operationId))].sort(),
        purpose: workspace.purpose,
        presentation: {
            categoryRef: workspace.categoryRef,
            confidence: 10,
            classificationNote: `Derived from the ${workspace.tier} tier of the approved E8 model; the category is structural, not a guess.`,
        },
        sliceHash,
    };
}
function transposeCall(model, workspaceId, call, operation, ontology) {
    const entity = ontology.entities.find(item => item.entityId === call.entityRef);
    const paginated = isPaginated(operation?.accessPattern.pagination, call.outputKind);
    const list = !paginated && (call.outputKind === 'list' || operation?.accessPattern.kind === 'list');
    const collection = paginated || list;
    const outputFields = operation
        ? resolveClassicOutputFields(operation, ontology)
        : (entity?.fields || []).map(field => ({
            name: field.fieldId, type: classicType(field.type), required: field.required,
            fieldRef: `${call.entityRef}.${field.fieldId}`,
        }));
    const itemFields = outputFields.map(field => ({
        name: field.name,
        from: ns4ClassicFrom(call.operationId, collection ? `$items.${field.name}` : field.name),
        type: field.type,
        required: field.required,
    }));
    const fields = paginated
        ? paginatedBffFields(call.operationId, collectionFieldName(call.entityRef), itemFields)
        : itemFields;
    return {
        bffId: call.bffId,
        kind: call.kind,
        uses: [{ operationId: call.operationId }],
        input: (operation?.inputs || []).map(input => ({
            name: input.inputId,
            from: ns4ClassicFrom(call.operationId, input.inputId),
            ...(input.required ? { required: true } : {}),
            source: input.source,
            // `source` alone is an unusable label: the consumer needs the call the picker reads FROM, and it
            // is the one thing only this workspace knows. Absent when the value is not chosen on the page.
            ...(inputSourceOf(call, input.inputId) ? { sourceRef: inputSourceOf(call, input.inputId) } : {}),
            // Type is the input's own override (`page`/`pageSize` are numbers) or the ontology field the
            // input names — never a lucky match against an output projection path.
            type: input.type || classicType(fieldTypeOf(ontology, input.fieldRef.entityId, input.fieldRef.fieldId)),
            ...(input.enumValues?.length ? { enumValues: input.enumValues } : {}),
        })),
        // One call carries at most one collection: composition is several calls on one page.
        output: { kind: paginated ? 'paginated' : list ? 'list' : 'object', fields },
        route: `${model.moduleName}.${workspaceId}.${call.bffId}`,
    };
}
function inputSourceOf(call, inputId) {
    return (call.inputSources || []).find(entry => entry.inputId === inputId)?.bffId || '';
}
function ontologyFieldOf(ontology, entityId, fieldId) {
    const entity = ontology.entities.find(item => item.entityId === entityId);
    return ns4ResolvableFieldOf(entity, fieldId);
}
export function fieldTypeOf(ontology, entityId, fieldId) {
    return ontologyFieldOf(ontology, entityId, fieldId)?.type || 'string';
}
/**
 * The wire shape is what E8 declared in outputRefs. A catalogue command whose refs are only the
 * identity still projects the entity fields it always did, so modules without a joined projection
 * keep today's outputShape. An unknown ref is a blocking E9 finding, never a silent `unknown`.
 */
export function resolveClassicOutputFields(operation, ontology) {
    const entity = ontology.entities.find(item => item.entityId === operation.entityRef);
    const ownFields = (entity?.fields || []).map(field => ({
        name: field.fieldId, type: classicType(field.type), required: field.required,
        fieldRef: `${operation.entityRef}.${field.fieldId}`,
    }));
    const refs = operation.outputRefs || [];
    if (!refs.length)
        return ownFields;
    const ownPrefix = `${operation.entityRef}.`;
    const refsAreOwn = refs.every(ref => ref.startsWith(ownPrefix));
    if (refsAreOwn && refs.length < ownFields.length)
        return ownFields;
    return refs.map(ref => resolveOutputRef(ref, ontology)).reduce((fields, field) => {
        const name = fields.some(item => item.name === field.name)
            ? lowerCamel(field.fieldRef.slice(0, field.fieldRef.indexOf('.'))) + upperCamel(field.name)
            : field.name;
        fields.push({ ...field, name });
        return fields;
    }, []);
}
function resolveOutputRef(ref, ontology) {
    const dot = ref.indexOf('.');
    if (dot <= 0)
        throw new Ns4E9OutputRefError(ref);
    const entityId = ref.slice(0, dot);
    const fieldId = ref.slice(dot + 1);
    const field = ontologyFieldOf(ontology, entityId, fieldId);
    if (!field)
        throw new Ns4E9OutputRefError(ref);
    return { name: fieldId, type: classicType(field.type), required: field.required, fieldRef: ref };
}
/** One TypeScript contract file per bffCall, byte-compatible with what the CFE reads today. */
export function buildNs4ClassicContractSource(args) {
    const pascal = upperCamel(args.call.bffId);
    const inputFields = args.call.input.map(input => `  ${input.name}${input.required ? '' : '?'}: ${tsType(input.type, input.enumValues)};`);
    const arrayField = args.call.output.kind === 'paginated'
        ? args.call.output.fields.find(field => field.item?.fields?.length)
        : undefined;
    const outputBlock = arrayField
        ? paginatedContractOutput(pascal, arrayField, args.call.output.fields.filter(field => field !== arrayField))
        : [
            `export interface ${pascal}Output {`,
            ...(args.call.output.fields.length
                ? args.call.output.fields.map(field => `  ${field.name}${field.required ? '' : '?'}: ${tsType(field.type)};`)
                : ['  // no declared projection']),
            '}',
        ];
    return [
        `/// <mls fileReference="${args.fileRef}" enhancement="_blank"/>`,
        '',
        `// GENERATED MECHANICALLY from ${args.sourceRef} — DO NOT EDIT.`,
        `// Contract of record: bffCall ${args.call.bffId} (${args.call.kind}); Output kind=${args.call.output.kind}; route ${args.call.route}.`,
        '',
        `export interface ${pascal}Input {`,
        ...(inputFields.length ? inputFields : ['  // no public inputs (resolved from context)']),
        '}',
        '',
        ...outputBlock,
        '',
        `export const ${args.call.bffId}Route = '${args.call.route}' as const;`,
        '',
    ].join('\n');
}
function paginatedContractOutput(pascal, arrayField, meta) {
    const itemName = `${pascal}OutputItem`;
    const itemFields = (arrayField.item?.fields || []).map(field => `  ${field.name}${field.required ? '' : '?'}: ${tsType(field.type)};`);
    return [
        `export interface ${itemName} {`,
        ...(itemFields.length ? itemFields : ['  // sem colunas']),
        '}',
        '',
        `export interface ${pascal}Output {`,
        `  ${arrayField.name}: ${itemName}[];`,
        ...meta.map(field => `  ${field.name}${field.required === false ? '?' : ''}: ${tsType(field.type)};`),
        '}',
    ];
}
export function buildNs4ClassicSiteMap(model, classic) {
    const byId = new Map(model.workspaces.map(workspace => [workspace.workspaceId, workspace]));
    const hub = model.workspaces.find(workspace => workspace.tier === 'hub');
    return {
        moduleName: model.moduleName,
        note: 'Site map (permanent page index) — workspaces, landings and advisory edges. Detail (sections/organisms/bffCalls) lives per-workspace under workspaces/.',
        workspaces: classic.map(workspace => ({
            workspaceId: workspace.workspaceId, title: workspace.title, actors: workspace.actors,
            kind: workspace.kind, entity: workspace.entity, operationIds: workspace.operationIds, purpose: workspace.purpose,
        })),
        landings: model.landings.map(landing => ({
            actorId: landing.profileRef, workspaceId: landing.workspaceId,
            reason: byId.get(landing.workspaceId)?.purpose || '',
        })),
        // A journey is reached from the hub that anchors it, never from the menu: the edge records that,
        // with the prominence and order the composition chose — this is where the hub template reads them.
        navigationEdges: [
            ...model.workspaces.flatMap(workspace => (workspace.navigation || [])
                .filter(target => byId.has(target.targetWorkspaceId))
                .map(target => ({
                from: workspace.workspaceId, to: target.targetWorkspaceId, operationId: '',
                description: target.label, prominence: target.prominence, order: target.order,
            }))),
            // A tile the hub reads still links to the page that owns it, so the projection stays reachable.
            ...(hub ? (hub.hubCatalogue?.items || [])
                .filter(item => item.kind !== 'action' && item.kind !== 'pending'
                && byId.has(item.targetRef) && item.targetRef !== hub.workspaceId)
                .map(item => ({ from: hub.workspaceId, to: item.targetRef, operationId: '', description: item.label }))
                : []),
        ],
        workspaceIds: classic.map(workspace => workspace.workspaceId),
    };
}
function identityFieldOf(entity) {
    return ns4EntityIdField(entity);
}
function isPaginated(pagination, outputKind) {
    return pagination === 'optional' || pagination === 'required' || outputKind === 'paginated';
}
/** Declared collection name on the wire — never the generic `items`. */
export function collectionFieldName(entityId) {
    const base = entityId ? entityId.slice(0, 1).toLowerCase() + entityId.slice(1) : 'records';
    if (base.endsWith('s'))
        return base;
    if (/[^aeiou]y$/i.test(base))
        return `${base.slice(0, -1)}ies`;
    return `${base}s`;
}
function paginatedOutputShape(arrayName, itemFields) {
    return {
        kind: 'paginated',
        fields: [
            { name: arrayName, type: 'array', required: true, item: { fields: itemFields } },
            { name: 'total', type: 'number', required: true },
            { name: 'page', type: 'number', required: true },
            { name: 'pageSize', type: 'number', required: true },
        ],
    };
}
function paginatedBffFields(operationId, arrayName, itemFields) {
    return [
        { name: arrayName, from: ns4ClassicFrom(operationId, '$items'), type: 'array', required: true, item: { fields: itemFields } },
        { name: 'total', from: ns4ClassicFrom(operationId, 'total'), type: 'number', required: true },
        { name: 'page', from: ns4ClassicFrom(operationId, 'page'), type: 'number', required: true },
        { name: 'pageSize', from: ns4ClassicFrom(operationId, 'pageSize'), type: 'number', required: true },
    ];
}
function classicType(type) {
    if (type === 'json')
        return 'json';
    if (type === 'number' || type === 'integer' || type === 'money')
        return 'number';
    if (type === 'boolean')
        return 'boolean';
    return 'string';
}
function tsType(type, enumValues) {
    if (enumValues?.length)
        return enumValues.map(value => `'${value}'`).join(' | ');
    if (type === 'number' || type === 'boolean')
        return type;
    if (type === 'json')
        return 'Record<string, unknown>';
    return 'string';
}
function upperCamel(value) {
    return value ? value.slice(0, 1).toUpperCase() + value.slice(1) : '';
}
function lowerCamel(value) {
    return value ? value.slice(0, 1).toLowerCase() + value.slice(1) : '';
}
export async function buildNs4NavigationRealizedAccess(source, model, classic) {
    if (source.grants.some(grant => !('useRules' in grant)))
        throw new Error('E9 does not migrate a legacy access matrix.');
    const grants = source.grants;
    const useCaseAuthorityRefs = 'realization' in source
        && source.realization
        && 'useCaseAuthorityRefs' in source.realization
        ? [...source.realization.useCaseAuthorityRefs]
        : [];
    const operations = new Map(model.operations.map(operation => [operation.operationId, operation]));
    const operationAuthorityRefs = [];
    for (const workspace of classic.workspaces) {
        for (const call of workspace.bffCalls) {
            const operation = operations.get(call.uses[0]?.operationId || call.bffId);
            operationAuthorityRefs.push({
                operationRef: call.uses[0]?.operationId || call.bffId,
                route: call.route,
                workspaceId: workspace.workspaceId,
                functionId: call.bffId,
                ...(operation?.useCaseId ? { useCaseId: operation.useCaseId } : {}),
                authorityRefs: [...(operation?.authorityRefs || [])],
            });
        }
    }
    operationAuthorityRefs.sort((left, right) => `${left.route}|${left.operationRef}`.localeCompare(`${right.route}|${right.operationRef}`));
    const realizationHash = await sha256Ns4({
        accessHash: source.accessHash, useCaseAuthorityRefs, operationAuthorityRefs,
    });
    return {
        schemaVersion: NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION,
        moduleName: source.moduleName,
        userLanguage: source.userLanguage,
        title: source.title,
        profiles: source.profiles,
        authorities: source.authorities,
        grants,
        accessHash: source.accessHash,
        approvedBy: source.approvedBy,
        approvedAt: source.approvedAt,
        realization: {
            status: 'navigationCompiled',
            compiledFromAccessHash: source.accessHash,
            useCaseAuthorityRefs,
            operationAuthorityRefs,
            realizationHash,
        },
    };
}
/** The whole transposition: what E9 writes to L4 from an approved E8 model. */
export async function compileNs4ClassicL4(model, ontology, useCases = []) {
    const operations = new Map(model.operations.map(operation => [operation.operationId, operation]));
    const workspaces = [];
    for (const workspace of model.workspaces) {
        const sliceHash = await hashNs4Slice({ workspaceId: workspace.workspaceId, bffCalls: workspace.bffCalls, sections: workspace.sections });
        workspaces.push(transposeNs4ClassicWorkspace(model, workspace, operations, ontology, sliceHash));
    }
    const contracts = workspaces.flatMap(workspace => workspace.bffCalls.map(call => ({
        workspaceId: workspace.workspaceId, bffId: call.bffId, route: call.route,
        source: buildNs4ClassicContractSource({
            moduleName: model.moduleName, workspaceId: workspace.workspaceId, call,
            fileRef: `_${'{project}'}_/l4/${model.moduleName}/contracts/${workspace.workspaceId}--${call.bffId}.defs.ts`,
            sourceRef: `l4/${model.moduleName}/workspaces/${workspace.workspaceId}.defs.ts`,
        }),
    })));
    return {
        workspaces,
        operations: model.operations.map(operation => transposeNs4ClassicOperation(model, operation, ontology, useCases)),
        contracts,
        siteMap: buildNs4ClassicSiteMap(model, workspaces),
    };
}
function classicWriteIds(operation, useCases) {
    if (operation.kind !== 'command')
        return [];
    const useCase = operation.useCaseId
        ? useCases.find(item => item.useCaseId === operation.useCaseId)
        : undefined;
    const declared = (useCase?.writes || []).map(item => item.entityId).filter(Boolean);
    return uniqueStrings(declared.length ? declared : [operation.entityRef]);
}
function uniqueStrings(values) {
    return [...new Set(values.filter(Boolean))];
}
async function hashNs4Slice(value) {
    const bytes = new TextEncoder().encode(JSON.stringify(value));
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return `sha256:${[...new Uint8Array(digest)].slice(0, 4).map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
}
