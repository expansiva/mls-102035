/// <mls fileReference="_102035_/l2/solution/helpers/e2/contracts.ts" enhancement="_blank"/>
import { collectNs4JourneyEntities } from '/_102035_/l2/solution/helpers/ns4Context.js';
import { ns4Text } from '/_102035_/l2/solution/helpers/ns4Text.js';
import { analyzeNs4E2MechanicalCoverage, isNs4E2DemotionDecisionId, ns4E2DemotionDecisionId, } from '/_102035_/l2/solution/helpers/e2/coverageSignals.js';
export const NS4_JOURNEY_SCHEMA_VERSION = '2026-08-14-ns4-journey-v5';
export const NS4_JOURNEY_INDEX_SCHEMA_VERSION = '2026-08-15-ns4-journey-index-v7';
export const NS4_REALIZED_JOURNEY_SCHEMA_VERSION = '2026-08-14-ns4-journey-realized-v5';
export const NS4_E2_IMPACT_REPORT_SCHEMA_VERSION = '2026-08-13-ns4-e2-impact-report-v2';
/** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
export const TEXT_PATHS_2026_08_14_ns4_journey_v5 = [
    'business.title',
    'business.goal',
    'business.steps[].title',
    'business.steps[].description',
    'business.outcome.statement',
    'business.outcome.evidence[]',
    'policyDecisions[].question',
    'policyDecisions[].chosen',
    'policyDecisions[].alternatives[]',
    'policyDecisions[].impact',
];
export const TEXT_PATHS_2026_08_14_ns4_journey_realized_v5 = TEXT_PATHS_2026_08_14_ns4_journey_v5;
export const TEXT_PATHS_2026_08_10_ns4_journey_v4 = TEXT_PATHS_2026_08_14_ns4_journey_v5;
export const TEXT_PATHS_2026_08_10_ns4_journey_v3 = TEXT_PATHS_2026_08_14_ns4_journey_v5;
export const TEXT_PATHS_2026_08_09_ns4_journey_v2 = TEXT_PATHS_2026_08_14_ns4_journey_v5;
export const TEXT_PATHS_2026_08_04_ns4_journey_v1 = [
    'business.title',
    'business.goal',
    'business.prerequisites[].reason',
    'business.entry.carries[].description',
    'business.steps[].intent',
    'business.steps[].result',
    'business.outcome.statement',
    'business.outcome.evidence[]',
    'business.businessRules[].statement',
    'policyDecisions[].question',
    'policyDecisions[].chosen',
    'policyDecisions[].alternatives[]',
    'policyDecisions[].impact',
];
export const TEXT_PATHS_2026_08_15_ns4_journey_index_v7 = [
    'journeys[].title',
    'journeys[].goal',
    'features[].title',
    'policyDecisions[].question',
    'policyDecisions[].chosen',
    'policyDecisions[].alternatives[]',
    'policyDecisions[].impact',
    'systemDecisions[].question',
    'systemDecisions[].chosen',
    'systemDecisions[].alternatives[]',
    'systemDecisions[].changeHint',
];
export const TEXT_PATHS_2026_08_14_ns4_journey_index_v6 = TEXT_PATHS_2026_08_15_ns4_journey_index_v7;
export const TEXT_PATHS_2026_08_12_ns4_journey_index_v5 = TEXT_PATHS_2026_08_15_ns4_journey_index_v7;
export const TEXT_PATHS_2026_08_10_ns4_journey_index_v4 = TEXT_PATHS_2026_08_15_ns4_journey_index_v7;
export const TEXT_PATHS_2026_08_10_ns4_journey_index_v3 = TEXT_PATHS_2026_08_15_ns4_journey_index_v7;
export const TEXT_PATHS_2026_08_09_ns4_journey_index_v2 = TEXT_PATHS_2026_08_15_ns4_journey_index_v7;
export const TEXT_PATHS_2026_08_04_ns4_journey_index_v1 = TEXT_PATHS_2026_08_15_ns4_journey_index_v7;
/** A journey written by a previous flow version still declares its context graph; it is never compiled. */
export function isNs4CurrentJourneyBusiness(value) {
    return !('prerequisites' in value) && !('carries' in value.entry);
}
export function normalizeNs4E2Review(value, fallbackModule = '', presentation) {
    const root = record(value);
    const userLanguage = text(root.userLanguage) || 'en';
    const journeys = withNs4DemotionDecisions(array(root.journeys).map(normalizeJourney), presentation);
    const features = array(root.features).map(item => {
        const feature = record(item);
        return {
            featureId: text(feature.featureId),
            title: text(feature.title),
            priority: featurePriority(feature.priority),
            journeyStepRefs: strings(feature.journeyStepRefs),
        };
    });
    return {
        planId: 'e2-review',
        moduleName: text(root.moduleName) || fallbackModule,
        userLanguage,
        title: text(root.title) || 'Review business journeys',
        reviewRound: positiveInteger(root.reviewRound, 1),
        journeys,
        features,
        systemDecisions: normalizeSystemDecisions(root.systemDecisions),
    };
}
export async function buildNs4JourneyArtifacts(review) {
    return Promise.all(review.journeys.map(async (journey) => {
        const businessHash = await sha256Ns4(journey.business);
        return {
            schemaVersion: NS4_JOURNEY_SCHEMA_VERSION,
            journeyId: journey.journeyId,
            revision: 1,
            business: journey.business,
            policyDecisions: journey.policyDecisions,
            businessHash,
            resolution: { status: 'pending', contexts: {} },
            realization: { status: 'pending', compiledFromBusinessHash: businessHash, steps: [], transitionRefs: [] },
        };
    }));
}
export function buildNs4JourneyIndex(moduleName, review, artifacts, artifactPaths, approvedBy, approvedAt, policyDecisionSelections = []) {
    return {
        schemaVersion: NS4_JOURNEY_INDEX_SCHEMA_VERSION,
        moduleName,
        approvedAt,
        approvedBy,
        journeys: artifacts.map((artifact, index) => ({
            journeyId: artifact.journeyId,
            actorRef: artifact.business.actorRef,
            title: artifact.business.title,
            goal: artifact.business.goal,
            entryMode: artifact.business.entry.mode,
            businessHash: artifact.businessHash,
            artifactPath: artifactPaths[index],
        })),
        features: review.features,
        policyDecisions: review.journeys.flatMap(journey => journey.policyDecisions
            .map(decision => ({ ...decision, journeyRef: journey.journeyId }))),
        policyDecisionSelections,
        systemDecisions: review.systemDecisions,
    };
}
function normalizeSystemDecisions(value) {
    return array(value).map(item => {
        const decision = record(item);
        return {
            decisionId: text(decision.decisionId), stage: text(decision.stage), question: text(decision.question),
            chosen: text(decision.chosen), alternatives: strings(decision.alternatives), decidedBy: 'system',
            findingRef: text(decision.findingRef), changeHint: text(decision.changeHint),
        };
    }).filter(decision => decision.decisionId && decision.stage && decision.question && decision.chosen && decision.findingRef);
}
export function buildNs4PolicyDecisionSelections(review, selectedChoices, selectedBy, selectedAt) {
    const selections = new Map(selectedChoices.map(selection => [selection.decisionId, selection.selectedChoice]));
    return review.journeys.flatMap(journey => journey.policyDecisions.map(decision => ({
        decisionId: decision.decisionId,
        generatedChoice: decision.chosen,
        selectedChoice: selections.get(decision.decisionId) || decision.chosen,
        selectedBy,
        selectedAt,
    })));
}
export function buildNs4E2ImpactReport(moduleName, previousIndex, artifacts, generatedAt, review) {
    const previous = new Map((previousIndex?.journeys || []).map(journey => [journey.journeyId, journey.businessHash]));
    const changes = [];
    artifacts.forEach(artifact => {
        const oldHash = previous.get(artifact.journeyId);
        if (!oldHash)
            changes.push({ journeyId: artifact.journeyId, reason: 'journeyNew' });
        else if (oldHash !== artifact.businessHash)
            changes.push({ journeyId: artifact.journeyId, reason: 'hashDivergent' });
        previous.delete(artifact.journeyId);
    });
    previous.forEach((_hash, journeyId) => changes.push({ journeyId, reason: 'journeyRemoved' }));
    return {
        schemaVersion: NS4_E2_IMPACT_REPORT_SCHEMA_VERSION,
        moduleName,
        generatedAt,
        stepKindHistogram: analyzeNs4E2MechanicalCoverage(review).stepKindHistogram,
        changes: changes.sort((left, right) => left.journeyId.localeCompare(right.journeyId) || left.reason.localeCompare(right.reason)),
        affectedSteps: changes.length ? ['e3-access-matrix', 'e4-ontology', 'e4b-access-realization', 'e5-rules', 'e7-realization'] : [],
    };
}
export async function sha256Ns4(value) {
    const bytes = new TextEncoder().encode(stableNs4Stringify(value));
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    const hex = [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
    return `sha256:${hex}`;
}
export function stableNs4Stringify(value) {
    if (Array.isArray(value))
        return `[${value.map(stableNs4Stringify).join(',')}]`;
    if (value && typeof value === 'object') {
        const source = value;
        return `{${Object.keys(source).sort().map(key => `${JSON.stringify(key)}:${stableNs4Stringify(source[key])}`).join(',')}}`;
    }
    return JSON.stringify(value) ?? 'null';
}
function normalizeJourney(value) {
    const source = record(value);
    const business = record(source.business);
    const entry = record(business.entry);
    const outcome = record(business.outcome);
    return {
        journeyId: text(source.journeyId),
        policyDecisions: array(source.policyDecisions).map(item => {
            const decision = record(item);
            const impact = text(decision.impact);
            const relatedJourneyIds = strings(decision.relatedJourneyIds);
            return {
                decisionId: text(decision.decisionId),
                question: text(decision.question),
                chosen: text(decision.chosen),
                alternatives: strings(decision.alternatives),
                ...(impact ? { impact } : {}),
                ...(relatedJourneyIds.length ? { relatedJourneyIds } : {}),
            };
        }),
        business: {
            actorRef: text(business.actorRef),
            title: text(business.title),
            goal: text(business.goal),
            entry: {
                mode: entryMode(entry.mode),
                ...(text(entry.preferredFromJourneyRef) ? { preferredFromJourneyRef: text(entry.preferredFromJourneyRef) } : {}),
            },
            steps: array(business.steps).map(item => {
                const step = record(item);
                const targetProfile = text(step.targetProfile);
                const affects = uniquePascalIds(step.affects);
                return {
                    stepId: text(step.stepId),
                    kind: stepKind(step.kind),
                    entity: normalizeNs4BusinessObjectId(step.entity),
                    ...(affects.length ? { affects } : {}),
                    title: text(step.title),
                    description: text(step.description),
                    featureRefs: strings(step.featureRefs),
                    ...(targetProfile ? { targetProfile } : {}),
                };
            }),
            outcome: {
                statement: text(outcome.statement),
                evidence: strings(outcome.evidence),
            },
            useRules: strings(business.useRules),
        },
    };
}
/**
 * Turns a human-spaced or already technical business noun into the stable PascalCase id shared by
 * journeys and ontology entities. The transformation is intentionally lexical: it never translates
 * or substitutes a domain noun.
 */
export function normalizeNs4BusinessObjectId(value) {
    const raw = text(value);
    if (!raw)
        return '';
    const decomposed = raw.normalize('NFKD').replace(/[\u0300-\u036f]/g, '');
    const words = decomposed
        .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
        .match(/[A-Za-z0-9]+/g) || [];
    return words.map(word => {
        if (/^[A-Z0-9]+$/.test(word))
            return word;
        return `${word.charAt(0).toUpperCase()}${word.slice(1)}`;
    }).join('');
}
/**
 * A journey with no decision, no handoff and one single entity IS the record catalogue of that
 * entity. Tier 1 already owns that screen, so the module records the demotion as a visible product
 * choice at the E2 checkpoint instead of shipping the same catalogue twice. The decision is
 * deterministic: it is recomputed on every round and is never authored by the generator.
 */
export function withNs4DemotionDecisions(journeys, presentation) {
    const captureOnly = new Map(analyzeNs4E2MechanicalCoverage({ journeys }).captureOnlyJourneys
        .map(item => [item.journeyId, item.entity]));
    return journeys.map(journey => {
        const entity = captureOnly.get(journey.journeyId);
        const decisionId = ns4E2DemotionDecisionId(journey.journeyId);
        const kept = journey.policyDecisions.filter(decision => !isNs4E2DemotionDecisionId(decision.decisionId));
        if (!entity)
            return kept.length === journey.policyDecisions.length ? journey : { ...journey, policyDecisions: kept };
        const chosen = ns4Text(presentation, 'demotion.chosen', { entity });
        const alternative = ns4Text(presentation, 'demotion.alternative', { journey: journey.business.title });
        return {
            ...journey,
            policyDecisions: [...kept, {
                    decisionId,
                    question: ns4Text(presentation, 'demotion.question', { journey: journey.business.title, entity }),
                    chosen,
                    alternatives: [chosen, alternative],
                }],
        };
    });
}
/** The journeys the approved review demoted to the tier 1 record catalogue of their entity. */
export function collectNs4DemotedJourneyIds(review, selections = []) {
    const selected = new Map(selections.map(selection => [selection.decisionId, selection.selectedChoice]));
    return review.journeys.filter(journey => (journey.policyDecisions || []).some(decision => {
        if (!isNs4E2DemotionDecisionId(decision.decisionId))
            return false;
        return (selected.get(decision.decisionId) ?? decision.chosen) === decision.chosen;
    })).map(journey => journey.journeyId).sort();
}
/** Business objects that later ontology compilation must realize as entities or projections. */
export function collectNs4RequiredJourneyBusinessObjects(review) {
    return collectNs4JourneyEntities(review);
}
function entryMode(value) {
    return value === 'contextRequired' || value === 'contextOrLookup' || value === 'eventDriven' ? value : 'coldStart';
}
function stepKind(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : 'locate';
}
function featurePriority(value) {
    return value === 'next' || value === 'later' ? value : 'now';
}
function uniquePascalIds(value) {
    return [...new Set(strings(value).map(normalizeNs4BusinessObjectId).filter(Boolean))];
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) {
    return Array.isArray(value) ? value : [];
}
function strings(value) {
    return array(value).map(text).filter(Boolean);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function boolean(value, fallback) {
    return typeof value === 'boolean' ? value : fallback;
}
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
