/// <mls fileReference="_102035_/l2/solution/types.ts" enhancement="_blank"/>
/** Schema ids for NS5 source artifacts. Bumped when a field is added or removed. */
export const NS5_MODULE_SCHEMA_VERSION = '2026-09-10-ns5-module-v2';
export const NS5_JOURNEY_SCHEMA_VERSION = '2026-09-10-ns5-journey-v1';
export const NS5_ONTOLOGY_SCHEMA_VERSION = '2026-09-11-ns5-ontology-v2';
export const NS5_RULES_SCHEMA_VERSION = '2026-09-10-ns5-rules-v1';
export const NS5_RULES_SCHEMA_VERSION_V2 = '2026-09-16-ns5-rules-v2';
export const NS5_WORKFLOWS_SCHEMA_VERSION = '2026-09-12-ns5-workflows-v2';
export const NS5_ACCESS_SCHEMA_VERSION = '2026-09-12-ns5-access-v3';
export const NS5_INTEGRATION_SCHEMA_VERSION = '2026-09-12-ns5-integration-v2';
export const NS5_INTEGRATION_REQUEST_SCHEMA_VERSION = '2026-09-12-ns5-integration-request-v1';
export const NS5_PIPELINE_SCHEMA_VERSION = '2026-09-10-ns5-pipeline-v1';
export const NS5_STEP_IDS = [
    'module10',
    'journeys20',
    'ontology30',
    'rules40',
    'workflows50',
    'access60',
    'integration70',
    'finalize80',
];
// ===========================================================================
// Ontology v3 (ns5_39). ADDITIVE: `Ns5OntologyEntityArtifact` above stays the
// v2 form the eleven other modules and `ontology30` still use. v3 is the form
// written by hand for `agendaClinica` — a module ontology written ON TOP of the
// platform ontology (`/_102034_/l4/ontology/mdm.defs.ts`) instead of beside it:
// a `role` is a papel over an MDM subtype, an `entity` is a table of the module.
//
// The field grammar is the platform's `MdmDefField`, reused rather than
// redeclared, so there is ONE field form on both sides. Three widenings, each
// because the module legitimately says something the platform cannot:
//   `to`     platform: `readonly MdmSubtypeName[]`; a module points at its own
//            entities too (`Consulta.defs.ts:33` — `to: ["Paciente"]`).
//   `values` platform: `readonly string[]`; a module labels its domain in the
//            user language (`Paciente.defs.ts:122-131` — `{value, title}`).
//   `fields` recurses into the widened field, not the platform one.
// `of` is NOT widened: it stays `MdmValueTypeName`, which is what makes the
// compiler check every reusable type a module cites.
// ===========================================================================
export const NS5_ONTOLOGY_SCHEMA_VERSION_V3 = '2026-09-15-ns5-ontology-v3';
export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from '/_102034_/l1/mdm/defs/level1Types.js';
