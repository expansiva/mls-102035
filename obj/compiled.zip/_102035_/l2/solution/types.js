/// <mls fileReference="_102035_/l2/solution/types.ts" enhancement="_blank"/>
/** Schema ids for NS5 source artifacts. Bumped when a field is added or removed. */
export const NS5_MODULE_SCHEMA_VERSION = '2026-09-10-ns5-module-v2';
export const NS5_JOURNEY_SCHEMA_VERSION = '2026-09-10-ns5-journey-v1';
export const NS5_ONTOLOGY_SCHEMA_VERSION = '2026-09-11-ns5-ontology-v2';
export const NS5_RULES_SCHEMA_VERSION = '2026-09-10-ns5-rules-v1';
export const NS5_WORKFLOWS_SCHEMA_VERSION = '2026-09-12-ns5-workflows-v2';
export const NS5_ACCESS_SCHEMA_VERSION = '2026-09-12-ns5-access-v3';
export const NS5_INTEGRATION_SCHEMA_VERSION = '2026-09-12-ns5-integration-v2';
export const NS5_INTEGRATION_REQUEST_SCHEMA_VERSION = '2026-09-12-ns5-integration-request-v1';
export const NS5_PIPELINE_SCHEMA_VERSION = '2026-09-10-ns5-pipeline-v1';
export const NS5_STEP_IDS = [
    'module10',
    'journeys20',
    'ontology30',
    'rules40',
    'workflows50',
    'access60',
    'integration70',
    'finalize80',
];
export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from '/_102034_/l1/mdm/defs/level1Types.js';
