/// <mls fileReference="_102035_/l2/solution/types.ts" enhancement="_blank"/>
/** Schema ids for NS5 source artifacts. Bumped when a field is added or removed. */
export const NS5_MODULE_SCHEMA_VERSION = '2026-09-10-ns5-module-v2';
export const NS5_JOURNEY_SCHEMA_VERSION = '2026-09-10-ns5-journey-v1';
export const NS5_ONTOLOGY_SCHEMA_VERSION = '2026-09-11-ns5-ontology-v2';
export const NS5_RULES_SCHEMA_VERSION = '2026-09-10-ns5-rules-v1';
export const NS5_RULES_SCHEMA_VERSION_V2 = '2026-09-16-ns5-rules-v2';
export const NS5_WORKFLOWS_SCHEMA_VERSION = '2026-09-12-ns5-workflows-v2';
/**
 * ns5_48: v3 adds the `alert` stage (a recurring duty of a person). The shape is a superset of v2,
 * so there is ONE artifact interface and the version is a union — the same move ontology30 made with
 * `NS5_ONTOLOGY_SCHEMA_VERSION_V3`. `workflows50` emits v3; the thirteen recorded runs stay v2 and
 * are replayed through `buildNs5WorkflowsArtifact`.
 */
export const NS5_WORKFLOWS_SCHEMA_VERSION_V3 = '2026-09-17-ns5-workflows-v3';
export const NS5_ACCESS_SCHEMA_VERSION = '2026-09-12-ns5-access-v3';
export const NS5_INTEGRATION_SCHEMA_VERSION = '2026-09-12-ns5-integration-v2';
export const NS5_INTEGRATION_REQUEST_SCHEMA_VERSION = '2026-09-12-ns5-integration-request-v1';
export const NS5_PIPELINE_SCHEMA_VERSION = '2026-09-10-ns5-pipeline-v1';
/**
 * ns5_49: `workflows50` runs BEFORE `ontology30`. A process stage cites the entity and the transition
 * it makes happen; the ontology then declares them with the stage as owner.
 * ns5_62: `judge35` runs AFTER `ontology30` and BEFORE `rules40`/`access60`. Completeness of the
 * journeys is judged only once the ontology (and the processes) exist. The numeric suffixes are
 * identity, not order — they are frozen so recorded runs keep their step ids.
 */
export const NS5_STEP_IDS = [
    'module10',
    'journeys20',
    'workflows50',
    'ontology30',
    'judge35',
    'rules40',
    'access60',
    'integration70',
    'finalize80',
];
// ===========================================================================
// Ontology v3 (ns5_39). ADDITIVE: `Ns5OntologyEntityArtifact` above stays the
// v2 form the eleven other modules and `ontology30` still use. v3 is the form
// written by hand for `agendaClinica` — a module ontology written ON TOP of the
// platform ontology (`/_102034_/l4/ontology/mdm.defs.ts`) instead of beside it:
// a `role` is a papel over an MDM subtype, an `entity` is a table of the module.
//
// The field grammar is the platform's `MdmDefField`, reused rather than
// redeclared, so there is ONE field form on both sides. Three widenings, each
// because the module legitimately says something the platform cannot:
//   `to`     platform: `readonly MdmSubtypeName[]`; a module points at its own
//            entities too (`Consulta.defs.ts:33` — `to: ["Paciente"]`).
//   `values` platform: `readonly string[]`; a module labels its domain in the
//            user language (`Paciente.defs.ts:122-131` — `{value, title}`).
//   `fields` recurses into the widened field, not the platform one.
// `of` is NOT widened: it stays `MdmValueTypeName`, which is what makes the
// compiler check every reusable type a module cites.
// ===========================================================================
export const NS5_ONTOLOGY_SCHEMA_VERSION_V3 = '2026-09-15-ns5-ontology-v3';
/**
 * v3.1 (ns5_47): what nobody writes is a `derived` field of the row (`description` says the condition), not a
 * lifecycle state; `time` is therefore gone from `reachedBy` and from `by`. The v3 artifacts already
 * recorded stay readable — the form only lost a way of saying something, so every reader accepts both
 * versions through `isNs5OntologyV3Version` and only the generator emits v3.1.
 */
export const NS5_ONTOLOGY_SCHEMA_VERSION_V31 = '2026-09-17-ns5-ontology-v3.1';
/** Every reader of the v3 form asks this, never an equality against one constant. */
export function isNs5OntologyV3Version(value) {
    return value === NS5_ONTOLOGY_SCHEMA_VERSION_V3 || value === NS5_ONTOLOGY_SCHEMA_VERSION_V31;
}
/** The discriminator every reader of a written entity uses; accepts v3 and v3.1 alike (ns5_47). */
export function isNs5OntologyEntityV3(entity) {
    return isNs5OntologyV3Version(entity.schemaVersion);
}
export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from '/_102035_/l2/agentNewSolution/helpers/organizationTypes.js';
