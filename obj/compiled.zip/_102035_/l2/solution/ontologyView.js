/// <mls fileReference="_102035_/l2/solution/ontologyView.ts" enhancement="_blank"/>
/**
 * ONE reading of the module ontology for the steps AFTER `ontology30` (ns5_43 T1–T5).
 *
 * PURE ON PURPOSE, exactly like `ontologyPaths.ts` and `resolveMdmEntity.ts`: types only, no `node:*`,
 * no `mls.*`, no I/O. That is what lets an `l1` test import it, and therefore what puts it under
 * `tsconfig.backend.json` — `tsconfig.frontend.json` excludes `l2/**\/*.test.ts`, so an `l2` test alone
 * would be runner-checked and not compiler-checked.
 *
 * WHY IT EXISTS. `rules40`, `workflows50`, `access60`, `integration70` and `finalize80` each ran the same
 * eight lines: read `ontology/index.defs.ts` as `Ns5OntologyIndexArtifact`, walk `index.entities` as
 * `string[]`, read each entity as `Ns5OntologyEntityArtifact`. On a v3 module (`agendaClinica`)
 * `index.entities` is `[{ entityId, kind, subtype? , class? }]` and `index.relationships` carries
 * `from`/`to`/`mode` instead of `fromEntity`/`toEntity`/`persistence`, so all five broke at the same line
 * for the same reason. They now read through here and keep working on both forms.
 *
 * WHAT IT DOES NOT DO. It never invents a v2 shape for a v3 entity. A v3 `role` has no flat `fields`
 * list — its data is the MDM record's tree — so the view answers with `fieldRefs` (the `<Entity>.<path>`
 * set, the same one `resolvableFieldPaths` gives a disclosure) and `columnIds`, not with a fake `fields`.
 * The two derivations that ARE made, both asked for by ns5_43:
 *   `party`   v3 dropped it because `subtype` carries it: a `role` on `Person` is a person, on `Company`
 *             an organization, anything else `none`. finalize80 I8 reads this (T5: "I8 sobre `role`").
 *   `type`    a v3 index relationship states the cardinality (`manyToOne`), a v2 one the structural type.
 *             Both go into `type`; only `required` drives the access60 anchor walk.
 */
import { isNs5OntologyEntityV3 as isEntityV3, isNs5OntologyV3Version, } from '/_102035_/l2/solution/types.js';
import { resolvableFieldPaths } from '/_102035_/l2/solution/ontologyPaths.js';
export function isNs5OntologyV3Index(index) {
    return isNs5OntologyV3Version(index.schemaVersion);
}
export function isNs5OntologyV3Entity(entity) {
    return isEntityV3(entity);
}
/** The entity ids of the index, in declaration order — the file names the step has to open. */
export function ns5OntologyEntityIds(index) {
    if (isNs5OntologyV3Index(index))
        return index.entities.map(row => row.entityId);
    return [...index.entities];
}
/** The edges of the index, whichever form declared them. */
export function ns5OntologyEdges(index) {
    if (isNs5OntologyV3Index(index)) {
        return index.relationships.map(row => ({
            relationshipId: row.relationshipId,
            fromEntity: row.from,
            toEntity: row.to,
            required: row.required,
            type: row.type,
        }));
    }
    return (index.relationships || []).map((row) => ({
        relationshipId: row.relationshipId,
        fromEntity: row.fromEntity,
        toEntity: row.toEntity,
        required: row.required,
        type: row.type,
    }));
}
export function ns5OntologyEntityView(entity) {
    return isNs5OntologyV3Entity(entity) ? viewOfV3(entity) : viewOfV2(entity);
}
export function ns5OntologyEntityViews(entities) {
    return entities.map(ns5OntologyEntityView);
}
export function ns5OntologyEntityViewOf(views, entityId) {
    return views.find(view => view.entityId === entityId);
}
/**
 * `<Entity>` or `<Entity>.<path>` — what a journey `affects`, a rule or a grant may name (ns5_43 T1).
 * `root` is the entity id; `path` is '' when the reference is the whole record.
 */
export function splitNs5EntityRef(ref) {
    const trimmed = (ref || '').trim();
    const dot = trimmed.indexOf('.');
    if (dot < 0)
        return { root: trimmed, path: '' };
    return { root: trimmed.slice(0, dot), path: trimmed.slice(dot + 1) };
}
/** True when the reference names this entity, or a node of it. */
export function ns5EntityRefResolves(view, ref) {
    return view.fieldRefs.includes(ref.trim());
}
/**
 * The tree of a v3 record as prompt lines — `- path (type, required, derived): description`, depth first,
 * branches included. This is the ONLY honest rendering of an entity whose data is the platform document:
 * a v3 `role` has no flat `fields` list to print. Each step keeps its own v2 rendering verbatim (their
 * headers and `details` lines differ), so the eleven v2 modules see byte-identical prompts.
 */
export function ns5OntologyV3FieldLines(entity) {
    return fieldLinesV3(entity.record.fields, '');
}
function fieldLinesV3(fields, parent) {
    const lines = [];
    for (const [id, field] of Object.entries(fields ?? {})) {
        const path = parent ? `${parent}.${id}` : id;
        const marks = [
            field.type + (field.collection ? '[]' : ''),
            field.required ? 'required' : '',
            field.derived ? 'derived' : '',
        ].filter(Boolean).join(', ');
        lines.push(`- ${path} (${marks})${field.description ? `: ${field.description}` : ''}`);
        if (field.fields)
            lines.push(...fieldLinesV3(field.fields, path));
    }
    return lines;
}
function viewOfV2(entity) {
    const columnIds = [
        ...(entity.storage?.idField ? [entity.storage.idField] : []),
        ...entity.fields.map(field => field.fieldId),
    ];
    return {
        entityId: entity.entityId,
        title: entity.title,
        description: entity.description,
        kind: entity.kind,
        writerKind: entity.kind,
        party: entity.party,
        ...(entity.mdmSubtype ? { mdmSubtype: entity.mdmSubtype } : {}),
        ...(entity.writer ? { writer: entity.writer } : {}),
        displayField: entity.displayField,
        idField: entity.storage?.idField || '',
        fields: entity.fields,
        ...(entity.details ? { details: entity.details } : {}),
        ...(entity.storage ? { storage: { idField: entity.storage.idField } } : {}),
        uniqueKeys: copyKeys(entity.uniqueKeys),
        lifecycleStates: [...(entity.lifecycleStates || [])],
        transitions: copyTransitions(entity.transitions),
        fieldRefs: resolvableFieldPaths(entity),
        columnIds: [...new Set(columnIds)],
        writtenFieldIds: entity.fields.map(field => field.fieldId),
        source: entity,
    };
}
function viewOfV3(entity) {
    const subtype = entity.kind === 'role' ? entity.subtype : undefined;
    const party = entity.kind !== 'role' ? 'none'
        : subtype === 'Person' ? 'person'
            : subtype === 'Company' ? 'organization'
                : 'none';
    return {
        entityId: entity.entityId,
        title: entity.title,
        description: entity.description,
        kind: entity.kind,
        writerKind: entity.kind === 'role' ? 'mdm' : entity.class,
        party,
        ...(subtype ? { mdmSubtype: subtype } : {}),
        ...(entity.writer ? { writer: entity.writer } : {}),
        displayField: entity.displayField,
        idField: 'id',
        fields: [],
        storage: { idField: 'id' },
        uniqueKeys: copyKeys(entity.uniqueKeys),
        lifecycleStates: [...(entity.lifecycleStates || [])],
        transitions: copyTransitions(entity.transitions),
        fieldRefs: resolvableFieldPaths(entity),
        columnIds: Object.keys(entity.record.fields).filter(id => id !== 'details'),
        writtenFieldIds: writtenFieldIdsV3(entity),
        paths: resolvableFieldPaths(entity),
        source: entity,
    };
}
/**
 * ns5_54. A `derived: true` field is written by the engine, never by the module: `id` and `version` of every
 * table, a column or a `details` branch the model marked, and — on a `ddm` — the whole record, which
 * `contractsV3 markDerived` flags. So a derived node is NOT a written field on either level, and a `ddm`
 * answers with an empty list, which is what finalize80 I10 needs to stop asking a summary for a writer.
 */
function writtenFieldIdsV3(entity) {
    const branches = entity.record.fields.details?.fields ?? {};
    const written = (fields) => Object.entries(fields).filter(([, field]) => field.derived !== true).map(([id]) => id);
    if (entity.kind === 'role')
        return written(branches[entity.moduleName]?.fields ?? {});
    return [
        ...written(entity.record.fields).filter(id => id !== 'details' && id !== 'version'),
        ...written(branches).map(name => `details.${name}`),
    ];
}
function copyKeys(keys) {
    return (keys || []).map(key => [...key]);
}
function copyTransitions(transitions) {
    return (transitions || []).map(transition => ({
        transitionId: transition.transitionId,
        from: [...transition.from],
        to: transition.to,
        by: Array.isArray(transition.by) ? [...transition.by] : transition.by,
        description: transition.description,
        ...('payload' in transition && Array.isArray(transition.payload) ? { payload: [...transition.payload] } : {}),
        ...(transition.ruleRefs ? { ruleRefs: [...transition.ruleRefs] } : {}),
    }));
}
