/// <mls fileReference="_102035_/l2/solution/effortRegistry.ts" enhancement="_blank"/>
/** Empty until How publishes one neutral `describeEffort` module per master. The ensaio mutates this object. */
export const effortRegistry = {};
const resolvedByProject = new Map();
const failureByProject = new Map();
const defaultDescribeEffortImporter = (specifier) => import(specifier);
let describeEffortImporter = defaultDescribeEffortImporter;
/**
 * `undefined` restores the real `import()`. A replacement is the ensaio default (no master):
 * resolution does not load a module and does not record a load failure.
 * Either way the cache is cleared.
 */
export function setDescribeEffortImporter(fn) {
    describeEffortImporter = fn ?? defaultDescribeEffortImporter;
    clearDescribeEffortCache();
}
function modulePath(project) {
    if (!/^[0-9]+$/.test(project))
        return undefined;
    return `/_${project}_/l2/helpers/effort/describeEffort.js`;
}
/** Path is built only from the numeric master project. Nothing from the request. Hidden while a replacement importer is installed. */
export function describeEffortModulePath(project) {
    if (describeEffortImporter !== defaultDescribeEffortImporter)
        return undefined;
    return modulePath(project);
}
export function clearDescribeEffortCache() {
    resolvedByProject.clear();
    failureByProject.clear();
}
/** Why the cached resolution for `project` is missing, if the load was attempted and failed. */
export function describeEffortFailure(project) {
    return failureByProject.get(project);
}
function asDescribeEffort(mod) {
    if (!mod || typeof mod !== 'object' || !('describeEffort' in mod))
        return undefined;
    const fn = mod.describeEffort;
    return typeof fn === 'function' ? fn : undefined;
}
/**
 * Injected `effortRegistry[project]` wins. Otherwise one dynamic import per project, cached
 * (including a failed import or a module that does not export `describeEffort`).
 */
export async function resolveDescribeEffort(project, importer) {
    const injected = effortRegistry[project]?.describeEffort;
    if (injected)
        return injected;
    if (resolvedByProject.has(project))
        return resolvedByProject.get(project);
    const load = importer ?? describeEffortImporter;
    if (!importer && describeEffortImporter !== defaultDescribeEffortImporter) {
        const specifier = modulePath(project);
        if (specifier) {
            try {
                await load(specifier);
            }
            catch { /* replacement importer: no master */ }
        }
        resolvedByProject.set(project, undefined);
        return undefined;
    }
    const specifier = modulePath(project);
    if (!specifier) {
        resolvedByProject.set(project, undefined);
        return undefined;
    }
    let fn;
    let failure;
    try {
        fn = asDescribeEffort(await load(specifier));
        if (!fn)
            failure = 'module does not export describeEffort';
    }
    catch (error) {
        fn = undefined;
        const message = error instanceof Error ? error.message : String(error);
        failure = `load failed: ${message}`;
    }
    resolvedByProject.set(project, fn);
    if (failure) {
        failureByProject.set(project, failure);
        console.warn(`describeEffort unavailable at ${specifier}: ${failure}`);
    }
    return fn;
}
