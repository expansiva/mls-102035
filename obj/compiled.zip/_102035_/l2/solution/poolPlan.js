/// <mls fileReference="_102035_/l2/solution/poolPlan.ts" enhancement="_blank"/>
export const POOL_DEVICES = ['web'];
/** Plan status shared by backend.json and effort.json. */
export const POOL_PLAN_STATUSES = ['toCreate', 'toUpdate', 'toRemove', 'done'];
/** Endpoint kind shared by backend.json and effort.json. */
export const POOL_ENDPOINT_KINDS = ['qry', 'cmd'];
export const POOL_TEST_SUPPORT_OWNERS = ['L1', 'runtime'];
// ---------------------------------------------------------------- menu.json
export const MENU_SCHEMA_VERSION = '2026-09-20-p2-menu-v2.2';
export const MENU_NODE_KINDS = ['hub', 'page', 'group'];
export const MENU_ORGANISM_KINDS = [
    'list', 'detail', 'form', 'summary', 'highlights', 'timeline', 'actions', 'inbox', 'alerts',
];
export const MENU_ACTIONS = ['new', 'change', 'keep', 'remove'];
// ---------------------------------------------------------------- needs.json
export const POOL_NEEDS_SCHEMA_VERSION = '2026-09-21-p2-needs-v1';
export const POOL_NEEDS_OPERATIONS = ['create', 'update', 'transition', 'delete'];
export const POOL_NEEDS_SCOPES = ['own', 'related', 'organization'];
export const POOL_NEEDS_FAMILIES = ['mdm', 'ddm', 'tdm'];
// ---------------------------------------------------------------- backend.json
export const POOL_BACKEND_SCHEMA_VERSION = '2026-09-21-p1-backend-v1.2';
export const POOL_BACKEND_OPERATIONS = ['list', 'get', 'create', 'update', 'transition', 'delete', 'custom'];
export const POOL_BACKEND_REMOVED_KINDS = ['usecase', 'port', 'table'];
export const POOL_NO_TABLE = ['ok', 'mdm', 'none'];
export const POOL_CHANGE_KINDS = ['field', 'rule', 'grant', 'transition', 'process', 'integration', 'entity'];
export const POOL_CHANGE_OPS = ['added', 'changed', 'removed'];
// ---------------------------------------------------------------- effort.json
export const POOL_EFFORT_SCHEMA_VERSION = '2026-09-21-p2-effort-v1.2';
export const POOL_EFFORT_REMOVED_KINDS = ['endpoint', 'usecase', 'table'];
