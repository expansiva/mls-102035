/// <mls fileReference="_102035_/l2/solution/poolPlan.ts" enhancement="_blank"/>
export const POOL_DEVICES = ['web'];
/** Plan status shared by backend.json and effort.json. */
export const POOL_PLAN_STATUSES = ['toCreate', 'toUpdate', 'toRemove', 'done'];
/** Endpoint kind shared by backend.json and effort.json. */
export const POOL_ENDPOINT_KINDS = ['qry', 'cmd'];
export const POOL_TEST_SUPPORT_OWNERS = ['L1', 'runtime'];
// ---------------------------------------------------------------- menu.json
export const MENU_SCHEMA_VERSION = '2026-09-20-p2-menu-v2.2';
export const MENU_NODE_KINDS = ['hub', 'page', 'group'];
export const MENU_ORGANISM_KINDS = [
    'list', 'detail', 'form', 'summary', 'highlights', 'timeline', 'actions', 'inbox', 'alerts',
];
export const MENU_ACTIONS = ['new', 'change', 'keep', 'remove'];
export const MENU_PLACEMENTS = ['screenAction', 'menuItem', 'listWithAdd'];
// ---------------------------------------------------------------- needs.json
export const POOL_NEEDS_SCHEMA_VERSION = '2026-09-21-p2-needs-v1';
export const POOL_NEEDS_OPERATIONS = ['create', 'update', 'transition', 'delete'];
export const POOL_NEEDS_SCOPES = ['own', 'related', 'organization'];
export const POOL_NEEDS_FAMILIES = ['mdm', 'ddm', 'tdm'];
// ---------------------------------------------------------------- backend.json
export const POOL_BACKEND_SCHEMA_VERSION = '2026-09-21-p1-backend-v1.2';
export const POOL_BACKEND_OPERATIONS = ['list', 'get', 'create', 'update', 'transition', 'delete', 'custom'];
export const POOL_BACKEND_REMOVED_KINDS = ['usecase', 'port', 'table'];
export const POOL_NO_TABLE = ['ok', 'mdm', 'none'];
export const POOL_CHANGE_KINDS = ['field', 'rule', 'grant', 'transition', 'process', 'integration', 'entity'];
export const POOL_CHANGE_OPS = ['added', 'changed', 'removed'];
// ---------------------------------------------------------------- effort.json
export const POOL_EFFORT_SCHEMA_VERSION = '2026-09-21-p2-effort-v1.2';
export const POOL_EFFORT_REMOVED_KINDS = ['endpoint', 'usecase', 'table'];
export const L4_DIFF_SCHEMA = '2026-09-21-p4-l4diff-v1';
export const L4_DIFF_OPS = ['added', 'changed', 'removed'];
export const L4_DIFF_KINDS = [
    'entity', 'field', 'transition', 'rule', 'grant', 'process', 'task', 'inbound', 'outbound',
    'journey', 'step',
    'artifact',
];
/**
 * Prose on a v3 field and on an enum value (`Ns5OntologyFieldV3` / `Ns5OntologyValueV3`):
 * `title` and `description` only. `type`, `derived`, `required` and the value code are not text.
 * `values` is not in this list: a label edit is text, an added or removed code is not.
 * `icon` is presentation (Lucide name on a journey, a step or a workflow task). `decisionRef` is not text.
 */
export const L4_TEXT_ATTRIBUTES = ['title', 'description', 'icon'];
function isL4TextAttribute(key) {
    return L4_TEXT_ATTRIBUTES.includes(key);
}
function sameJson(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
}
function enumValueEntry(value) {
    if (typeof value === 'string')
        return { code: value, attrs: { value } };
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return undefined;
    const attrs = value;
    if (typeof attrs.value !== 'string')
        return undefined;
    return { code: attrs.value, attrs };
}
/** Same codes; every differing key on a value is a text attribute. */
function enumValuesTextOnly(before, after) {
    if (!Array.isArray(before) || !Array.isArray(after) || before.length !== after.length)
        return false;
    const beforeByCode = new Map();
    const afterByCode = new Map();
    for (const raw of before) {
        const entry = enumValueEntry(raw);
        if (!entry || beforeByCode.has(entry.code))
            return false;
        beforeByCode.set(entry.code, entry.attrs);
    }
    for (const raw of after) {
        const entry = enumValueEntry(raw);
        if (!entry || afterByCode.has(entry.code))
            return false;
        afterByCode.set(entry.code, entry.attrs);
    }
    if (beforeByCode.size !== afterByCode.size)
        return false;
    for (const [code, beforeAttrs] of beforeByCode) {
        const afterAttrs = afterByCode.get(code);
        if (!afterAttrs)
            return false;
        const keys = new Set([...Object.keys(beforeAttrs), ...Object.keys(afterAttrs)]);
        for (const key of keys) {
            if (sameJson(beforeAttrs[key], afterAttrs[key]))
                continue;
            if (!isL4TextAttribute(key))
                return false;
        }
    }
    return true;
}
/**
 * True when every difference on a `changed` item is text (`title` / `description` / `icon`, or an enum label).
 * A `rule` is never text: its description is the rule. Any other key is not text.
 */
export function isTextOnlyChange(item) {
    if (item.op !== 'changed' || item.kind === 'rule')
        return false;
    const before = item.before;
    const after = item.after;
    if (!before || !after || typeof before !== 'object' || typeof after !== 'object')
        return false;
    if (Array.isArray(before) || Array.isArray(after))
        return false;
    const beforeRecord = before;
    const afterRecord = after;
    const keys = new Set([...Object.keys(beforeRecord), ...Object.keys(afterRecord)]);
    for (const key of keys) {
        if (sameJson(beforeRecord[key], afterRecord[key]))
            continue;
        if (key === 'values') {
            if (!enumValuesTextOnly(beforeRecord[key], afterRecord[key]))
                return false;
            continue;
        }
        if (!isL4TextAttribute(key))
            return false;
    }
    return true;
}
const PRESENTATION_KINDS = new Set(['journey', 'step', 'task']);
/**
 * A `changed` journey, step or workflow task whose only differing attribute is `icon`.
 * Text, `decisionRef` or any other key keeps the item on the master path. Added and removed never qualify.
 */
export function isPresentationOnlyChange(item) {
    if (item.op !== 'changed' || !PRESENTATION_KINDS.has(item.kind))
        return false;
    const before = item.before;
    const after = item.after;
    if (!before || !after || typeof before !== 'object' || typeof after !== 'object')
        return false;
    if (Array.isArray(before) || Array.isArray(after))
        return false;
    const beforeRecord = before;
    const afterRecord = after;
    const keys = new Set([...Object.keys(beforeRecord), ...Object.keys(afterRecord)]);
    let sawIcon = false;
    for (const key of keys) {
        if (sameJson(beforeRecord[key], afterRecord[key]))
            continue;
        if (key !== 'icon')
            return false;
        sawIcon = true;
    }
    return sawIcon;
}
// ---------------------------------------------------------------- changeEffort.json
export const CHANGE_EFFORT_SCHEMA_VERSION = '2026-10-25-p4-change-effort-v2';
export const EFFORT_UNIT_KINDS = ['page', 'route', 'usecase', 'entity', 'request', 'table', 'shared', 'contract', 'workflow', 'repository', 'authority', 'scope', 'seeds', 'controller', 'events'];
export const EFFORT_MASTER_KINDS = ['l2', 'l1'];
export const EFFORT_ANSWER_STATUSES = ['computed', 'abend'];
export const EFFORT_CONTRACT_VALUES = ['keep', 'change'];
export const CHANGE_EFFORT_STATUSES = ['simple', 'contract', 'blocked'];
