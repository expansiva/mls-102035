/// <mls fileReference="_102035_/l2/solution/fs.ts" enhancement="_blank"/>
import { createStorFile } from '/_102027_/l2/libStor.js';
import { extractNs4ClassicJsonObject } from '/_102035_/l2/solution/helpers/ns4ClassicDefs.js';
const TYPES_IMPORT = '/_102035_/l2/solution/types.js';
const AGENT_PROJECT = 102035;
const AGENT_FOLDER = 'agentNewSolution5';
export function normalizeModuleName(value, fallback = 'newModule') {
    const raw = String(value || '').trim() || fallback;
    if (!raw)
        return '';
    const ascii = raw.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const words = ascii.replace(/([a-z0-9])([A-Z])/g, '$1 $2').split(/[^A-Za-z0-9]+/).filter(Boolean);
    if (words.length === 0)
        return 'newModule';
    const first = words[0].toLowerCase();
    const rest = words.slice(1).map(word => word.slice(0, 1).toUpperCase() + word.slice(1).toLowerCase()).join('');
    const candidate = `${first}${rest}`.replace(/^[^a-z]+/, '').slice(0, 60);
    return candidate || 'newModule';
}
function currentProject() {
    return mls.actualProject || 0;
}
const moduleRootsByMls = new WeakMap();
function moduleRoots() {
    const bag = typeof mls === 'undefined' ? undefined : mls;
    if (!bag)
        return new Map();
    let roots = moduleRootsByMls.get(bag);
    if (!roots) {
        roots = new Map();
        moduleRootsByMls.set(bag, roots);
    }
    return roots;
}
/**
 * Point `moduleFolder` at a root relative to `l4/` (example: `stockControl/tobe/plan`).
 * `null` or `''` restores the canonical folder. Lives on the current `mls` (the task process).
 */
export function setModuleRoot(moduleName, relativeRoot) {
    const name = normalizeModuleName(moduleName);
    if (!name)
        return;
    const root = typeof relativeRoot === 'string' ? relativeRoot.trim() : '';
    if (!root) {
        moduleRoots().delete(name);
        return;
    }
    moduleRoots().set(name, root);
}
/** `l4/<mod>` or the `/candidate` override when `setModuleRoot` was called. */
export function moduleFolder(moduleName) {
    const name = normalizeModuleName(moduleName);
    return moduleRoots().get(name) || name;
}
export function moduleFile(moduleName) {
    return moduleFileForProject(currentProject(), moduleName);
}
/** Read-only callers such as the Studio module browser must not depend on mls.actualProject. */
export function moduleFileForProject(project, moduleName) {
    return { project, level: 4, folder: moduleFolder(moduleName), shortName: 'module', extension: '.defs.ts' };
}
export function journeyFile(moduleName, journeyId) {
    return { project: currentProject(), level: 4, folder: `${moduleFolder(moduleName)}/journeys`, shortName: journeyId, extension: '.defs.ts' };
}
export function journeyIndexFile(moduleName) {
    return { project: currentProject(), level: 4, folder: `${moduleFolder(moduleName)}/journeys`, shortName: 'index', extension: '.defs.ts' };
}
export function ontologyEntityFile(moduleName, entityId) {
    return { project: currentProject(), level: 4, folder: `${moduleFolder(moduleName)}/ontology`, shortName: entityId, extension: '.defs.ts' };
}
export function ontologyIndexFile(moduleName) {
    return { project: currentProject(), level: 4, folder: `${moduleFolder(moduleName)}/ontology`, shortName: 'index', extension: '.defs.ts' };
}
export function rulesFile(moduleName) {
    return { project: currentProject(), level: 4, folder: moduleFolder(moduleName), shortName: 'rules', extension: '.defs.ts' };
}
export function workflowsFile(moduleName) {
    return { project: currentProject(), level: 4, folder: moduleFolder(moduleName), shortName: 'workflows', extension: '.defs.ts' };
}
export function accessFile(moduleName) {
    return { project: currentProject(), level: 4, folder: moduleFolder(moduleName), shortName: 'access', extension: '.defs.ts' };
}
export function integrationFile(moduleName) {
    return { project: currentProject(), level: 4, folder: moduleFolder(moduleName), shortName: 'integration', extension: '.defs.ts' };
}
/** `l4/<target>/tobe/integration/<requestedBy>--<eventId>.defs.ts` — no extra dot in shortName. */
export function integrationRequestFile(targetModule, requestedBy, eventId) {
    return {
        project: currentProject(),
        level: 4,
        folder: `${moduleFolder(targetModule)}/tobe/integration`,
        shortName: `${normalizeModuleName(requestedBy)}--${normalizeModuleName(eventId)}`,
        extension: '.defs.ts',
    };
}
export function collectTobeIntegrationFilesCiting(moduleName) {
    const name = normalizeModuleName(moduleName);
    const prefix = `${name}--`;
    const project = currentProject();
    const collected = [];
    const seen = new Set();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || Number(file.level) !== 4)
            continue;
        const folder = String(file.folder || '');
        if (!folder.endsWith('/tobe/integration') && folder !== 'organization/tobe/integration')
            continue;
        const shortName = String(file.shortName || '');
        if (!shortName.startsWith(prefix))
            continue;
        const key = mls.stor.getKeyToFile(file);
        if (seen.has(key))
            continue;
        seen.add(key);
        collected.push(file);
    }
    return collected;
}
export function pipelineFile(moduleName) {
    return pipelineFileForProject(currentProject(), moduleName);
}
export function pipelineFileForProject(project, moduleName) {
    return { project, level: 4, folder: `${moduleFolder(moduleName)}/pipeline`, shortName: 'pipeline', extension: '.json' };
}
export function pipelineJsonFile(moduleName, shortName) {
    return pipelineJsonFileForProject(currentProject(), moduleName, shortName);
}
export function pipelineJsonFileForProject(project, moduleName, shortName) {
    return { project, level: 4, folder: `${moduleFolder(moduleName)}/pipeline`, shortName, extension: '.json' };
}
export function finalizeReportFile(moduleName) {
    return pipelineJsonFile(moduleName, 'finalize-report');
}
export function finalizeReportFileForProject(project, moduleName) {
    return pipelineJsonFileForProject(project, moduleName, 'finalize-report');
}
export function listPipelineJsonShortNames(moduleName) {
    const project = currentProject();
    const folder = `${moduleFolder(moduleName)}/pipeline`;
    const names = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted')
            continue;
        if (file.extension !== '.json' || String(file.folder || '') !== folder)
            continue;
        if (file.shortName)
            names.push(String(file.shortName));
    }
    return names;
}
export function draftFile(moduleName, step) {
    return { project: currentProject(), level: 4, folder: `${moduleFolder(moduleName)}/pipeline`, shortName: `${step}-draft`, extension: '.json' };
}
export function agentFile(folder, shortName, extension) {
    return {
        project: AGENT_PROJECT,
        level: 2,
        folder: folder ? `${AGENT_FOLDER}/${folder}` : AGENT_FOLDER,
        shortName,
        extension,
    };
}
export function registryFile() {
    return { project: currentProject(), level: 4, folder: 'organization', shortName: 'registry', extension: '.defs.ts' };
}
export function displayPath(fileInfo) {
    const folder = fileInfo.folder ? `${fileInfo.folder}/` : '';
    return `l${fileInfo.level}/${folder}${fileInfo.shortName}${fileInfo.extension}`;
}
export function assertShortName(shortName) {
    if (shortName.includes('.')) {
        throw new Error(`[agentNewSolution5] filename out of standard: '${shortName}' — shortName must not contain dots`);
    }
}
export function fileExists(fileInfo) {
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    return !!file && file.status !== 'deleted';
}
export function listModuleFolders() {
    const project = currentProject();
    const modules = new Set();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.status === 'deleted' || !file.folder)
            continue;
        if (file.level !== 4)
            continue;
        const first = file.folder.split('/')[0];
        if (!first || first === 'organization')
            continue;
        modules.add(normalizeModuleName(first));
    }
    return modules;
}
export function isExactModuleFolder(folder, moduleName) {
    const normalized = moduleFolder(moduleName);
    const first = String(folder || '').split('/').filter(Boolean)[0] || '';
    return !!first && normalizeModuleName(first) === normalized;
}
export const MODULE_TREE_LEVELS = [1, 2, 4, 5];
export function isProtectedModuleFile(file) {
    const first = String(file.folder || '').split('/').filter(Boolean)[0] || '';
    const folder = String(file.folder || '');
    if (Number(file.level) === 4 && first === 'organization') {
        return folder !== 'organization/tobe/integration' && !folder.startsWith('organization/tobe/');
    }
    if (Number(file.level) === 2 && !first && (file.shortName === 'designSystem' || file.shortName === 'project'))
        return true;
    if (Number(file.level) === 5 && !first && (file.shortName === 'config' || file.shortName === 'project'))
        return true;
    return false;
}
export function listModuleL4Keys(files, project, moduleName) {
    const keys = [];
    for (const [key, file] of Object.entries(files)) {
        if (!file || file.project !== project || file.status === 'deleted' || !file.folder)
            continue;
        if (file.level !== 4)
            continue;
        if (!isExactModuleFolder(file.folder, moduleName))
            continue;
        keys.push(key);
    }
    return keys;
}
/** Index (`mls.stor.files`) of exact `l<level>/<mod>/**`. Never prefix; never protected paths; never host disk. */
export function collectExactModuleFiles(moduleName, levels = MODULE_TREE_LEVELS) {
    const project = currentProject();
    const files = mls.stor.files;
    const levelSet = new Set(levels);
    const keys = new Set();
    for (const [key, file] of Object.entries(files)) {
        if (!file || file.project !== project || !file.folder)
            continue;
        if (!levelSet.has(Number(file.level)))
            continue;
        if (!isExactModuleFolder(file.folder, moduleName))
            continue;
        if (isProtectedModuleFile(file))
            continue;
        keys.add(key);
    }
    const collected = [];
    for (const key of keys) {
        const file = files[key];
        if (file)
            collected.push(file);
    }
    return collected;
}
/**
 * The `mls.stor.files` entry for `info`, or undefined. The index is the only source the l4 lists,
 * deletes and judges by — it is what the Studio (browser) has; host disk never decides (p4_19).
 */
export function indexedFile(info) {
    return mls.stor.files[mls.stor.getKeyToFile(info)] || undefined;
}
/**
 * Host disk listing (`mls.stor.localStor.listFolder`); undefined outside the host.
 * The l4 no longer reads it (p4_19); still exported for the L1/L2 callers outside this spec.
 */
export function hostListFolder() {
    const fn = mls.stor.localStor?.listFolder;
    return typeof fn === 'function' ? fn : undefined;
}
/**
 * An `mls.stor.files` entry for a file seen on host disk but absent from the index.
 * The l4 no longer calls it (p4_19); still exported for the L1/L2 callers outside this spec.
 */
export function diskFileInfo(info) {
    const key = mls.stor.getKeyToFile(info);
    const existing = mls.stor.files[key];
    if (existing)
        return existing;
    return {
        ...info,
        versionRef: '0',
        inLocalStorage: true,
        status: 'changed',
        hasError: false,
    };
}
/** shortNames of `.defs.ts` in `l4/<mod>/<kind>/` from the index, including status=deleted; never host disk. */
export function listModuleDefsShortNames(moduleName, kind) {
    const project = currentProject();
    const folder = `${moduleFolder(moduleName)}/${kind}`;
    const names = new Set();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4)
            continue;
        if (String(file.folder || '') !== folder || file.extension !== '.defs.ts')
            continue;
        if (file.shortName)
            names.add(file.shortName);
    }
    return [...names].sort();
}
export function ns5DefsOrphans(diskShortNames, indexIds) {
    const keep = new Set(['index', ...indexIds.filter(Boolean)]);
    const seen = new Set();
    const orphans = [];
    for (const raw of diskShortNames) {
        const name = String(raw || '').replace(/\.defs\.ts$/, '');
        if (!name || keep.has(name) || seen.has(name))
            continue;
        seen.add(name);
        orphans.push(name);
    }
    return orphans.sort();
}
export async function reconcileModuleDefs(moduleName, kind, indexIds) {
    const orphans = ns5DefsOrphans(listModuleDefsShortNames(moduleName, kind), indexIds);
    if (!orphans.length)
        return [];
    const { deleteFile } = await import('/_102027_/l2/libStor.js');
    const removed = [];
    for (const shortName of orphans) {
        const info = kind === 'journeys' ? journeyFile(moduleName, shortName) : ontologyEntityFile(moduleName, shortName);
        const file = indexedFile(info);
        if (!file) {
            console.warn(`[agentNewSolution5] reconcileModuleDefs: ${displayPath(info)} is not in the index — not deleted`);
            continue;
        }
        await deleteFile(file);
        removed.push(shortName);
    }
    return removed;
}
export async function readJson(fileInfo) {
    const raw = await readText(fileInfo, false);
    if (!raw.trim())
        return null;
    try {
        return JSON.parse(raw);
    }
    catch {
        return null;
    }
}
export async function writeJson(fileInfo, value) {
    await writeText(fileInfo, `${JSON.stringify(value, null, 2)}\n`);
    return displayPath(fileInfo);
}
export async function writeDefs(fileInfo, exportName, value, typeName) {
    await writeText(fileInfo, renderDefsSource(fileInfo, exportName, value, typeName));
    return displayPath(fileInfo);
}
export function renderDefsSource(fileInfo, exportName, value, typeName) {
    const safeExportName = normalizeModuleName(exportName);
    const exactTypeName = `${safeExportName.slice(0, 1).toUpperCase()}${safeExportName.slice(1)}Type`;
    return `/// <mls fileReference="_${fileInfo.project}_/l${fileInfo.level}/${fileInfo.folder}/${fileInfo.shortName}${fileInfo.extension}" enhancement="_blank"/>\n\n`
        + `import type { ${typeName}, Ns5Readonly } from '${TYPES_IMPORT}';\n\n`
        // p4_20: checked against the read-only view of the type. The Studio compiler (TypeScript 5.0.2)
        // refuses an `as const` literal against a mutable array (TS1360); 5.9.3 accepts. Same value type.
        + `export const ${safeExportName} = ${JSON.stringify(value, null, 2)} as const satisfies Ns5Readonly<${typeName}>;\n\n`
        + `export type ${exactTypeName} = typeof ${safeExportName};\n\n`
        + `export default ${safeExportName};\n`;
}
export async function readPipeline(moduleName) {
    return readJson(pipelineFile(moduleName));
}
export async function readPipelineForProject(project, moduleName) {
    return readJson(pipelineFileForProject(project, moduleName));
}
export async function writePipeline(state) {
    return writeJson(pipelineFile(state.moduleName), state);
}
export async function readAgentText(folder, shortName, extension = '.md') {
    return readText(agentFile(folder, shortName, extension), true);
}
export async function readAgentJson(folder, shortName, extension = '.json') {
    const raw = await readText(agentFile(folder, shortName, extension), true);
    try {
        return JSON.parse(raw);
    }
    catch {
        throw new Error(`[agentNewSolution5] invalid JSON: ${displayPath(agentFile(folder, shortName, extension))}`);
    }
}
export async function readDefsJson(fileInfo) {
    const source = await readText(fileInfo, false);
    const json = extractNs4ClassicJsonObject(source);
    if (!json)
        return null;
    try {
        return JSON.parse(json);
    }
    catch {
        return null;
    }
}
/** Preserve the exact L4 source when sealing a release or copying it to the candidate. */
export async function readSourceText(fileInfo) {
    return readText(fileInfo, true);
}
export async function writeSourceText(fileInfo, source) {
    await writeText(fileInfo, source);
}
/**
 * An ontology entity file in whichever form it is written (ns5_39 T4). Both forms are one JSON literal,
 * so the reading is the same; only the type of what comes back changes, and `schemaVersion` is the
 * discriminator — v3 (`agendaClinica`) carries `record`, v2 (the other eleven modules) carries `fields`.
 */
export async function readOntologyEntityAny(fileInfo) {
    return readDefsJson(fileInfo);
}
export async function readSolutionRegistry() {
    return readDefsJson(registryFile());
}
async function readText(fileInfo, required) {
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    if (!file || file.status === 'deleted') {
        if (required)
            throw new Error(`[agentNewSolution5] file not found: ${displayPath(fileInfo)}`);
        return '';
    }
    if (file.getValueInfo) {
        try {
            const local = await file.getValueInfo();
            const text = contentText(local?.content, fileInfo.extension);
            if (text !== null)
                return text;
        }
        catch { /* fall through */ }
    }
    if (String(file.versionRef || '').trim() === '0') {
        if (required)
            throw new Error(`[agentNewSolution5] local content unavailable for new file: ${displayPath(fileInfo)}`);
        return '';
    }
    const text = contentText(await file.getContent(), fileInfo.extension);
    if (text !== null)
        return text;
    if (required)
        throw new Error(`[agentNewSolution5] invalid text file: ${displayPath(fileInfo)}`);
    return '';
}
async function writeText(fileInfo, content) {
    assertShortName(fileInfo.shortName);
    const key = mls.stor.getKeyToFile(fileInfo);
    let file = mls.stor.files[key];
    if (!file) {
        file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
    }
    else if (file.status === 'deleted') {
        file.status = 'changed';
        file.updatedAt = new Date().toISOString();
    }
    await mls.stor.localStor.setContent(file, { contentType: 'string', content });
}
function contentText(content, extension) {
    if (typeof content === 'string')
        return content;
    if (extension === '.json' && typeof content === 'object' && content !== null) {
        return `${JSON.stringify(content, null, 2)}\n`;
    }
    return null;
}
