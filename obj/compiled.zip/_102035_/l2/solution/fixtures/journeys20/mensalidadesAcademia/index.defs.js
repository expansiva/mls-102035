/// <mls fileReference="_102047_/l4/mensalidadesAcademia/journeys/index.defs.ts" enhancement="_blank"/>
export const mensalidadesAcademiaJourneyIndex = {
    "schemaVersion": "2026-09-10-ns5-journey-v1",
    "moduleName": "mensalidadesAcademia",
    "journeys": [
        {
            "journeyId": "cadastrarPlano",
            "actorRef": "gerencia",
            "title": "Cadastrar plano de academia"
        },
        {
            "journeyId": "atualizarPlano",
            "actorRef": "gerencia",
            "title": "Atualizar condições de um plano"
        },
        {
            "journeyId": "matricularAluno",
            "actorRef": "recepcao",
            "title": "Matricular aluno em um plano"
        },
        {
            "journeyId": "gerarMensalidadesDoMes",
            "actorRef": "gerencia",
            "title": "Gerar mensalidades do mês"
        },
        {
            "journeyId": "registrarPagamentoMensalidade",
            "actorRef": "recepcao",
            "title": "Registrar pagamento de mensalidade"
        },
        {
            "journeyId": "acompanharPainelMensal",
            "actorRef": "gerencia",
            "title": "Acompanhar painel mensal"
        },
        {
            "journeyId": "cancelarPropriaMatricula",
            "actorRef": "aluno",
            "title": "Cancelar própria matrícula"
        }
    ],
    "systemDecisions": []
};
export default mensalidadesAcademiaJourneyIndex;
