/// <mls fileReference="_102047_/l4/ordenServicio5/ontology/Diagnostico.defs.ts" enhancement="_blank"/>
export const ordenServicio5EntityDiagnostico = {
    "schemaVersion": "2026-09-11-ns5-ontology-v2",
    "moduleName": "ordenServicio5",
    "entityId": "Diagnostico",
    "title": "Diagnóstico",
    "description": "Resultado técnico del análisis del aparato y de la causa del defecto reportado.",
    "kind": "supporting",
    "party": "none",
    "displayField": "descripcion",
    "fields": [
        {
            "fieldId": "id",
            "title": "Identificador",
            "type": "uuid",
            "required": true,
            "description": "Identificador único del diagnóstico."
        },
        {
            "fieldId": "descripcion",
            "title": "Descripción del diagnóstico",
            "type": "text",
            "required": true,
            "description": "Descripción técnica del análisis realizado y de la causa del defecto informado."
        }
    ],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "moduleDatabase",
        "scope": "module",
        "idField": "id"
    },
    "mutability": "appendOnly"
};
export default ordenServicio5EntityDiagnostico;
