/// <mls fileReference="_102047_/l4/ordenServicio5/ontology/EntregaAparato.defs.ts" enhancement="_blank"/>
export const ordenServicio5EntityEntregaAparato = {
    "schemaVersion": "2026-09-11-ns5-ontology-v2",
    "moduleName": "ordenServicio5",
    "entityId": "EntregaAparato",
    "title": "Entrega de aparato",
    "description": "Constancia de la entrega del aparato al cliente al finalizar la gestión.",
    "kind": "event",
    "party": "none",
    "displayField": "fechaEntrega",
    "fields": [
        {
            "fieldId": "id",
            "title": "Identificador",
            "type": "uuid",
            "required": true,
            "description": "Identificador único de la constancia de entrega del aparato."
        },
        {
            "fieldId": "fechaEntrega",
            "title": "Fecha y hora de entrega",
            "type": "datetime",
            "required": true,
            "description": "Fecha y hora en que se entrega el aparato al cliente."
        }
    ],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "moduleDatabase",
        "scope": "module",
        "idField": "id"
    },
    "mutability": "appendOnly"
};
export default ordenServicio5EntityEntregaAparato;
