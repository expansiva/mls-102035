/// <mls fileReference="_102035_/l2/solution/fixtures/finalize80/tarefas/module.defs.ts" enhancement="_blank"/>
export const tarefasModule = {
    "schemaVersion": "2026-09-10-ns5-module-v2",
    "moduleName": "tarefas",
    "title": "Tarefas",
    "userLanguage": "pt-BR",
    "productLanguages": ["pt-BR"],
    "defaultLanguage": "pt-BR",
    "sourcePrompt": "Membros criam e executam tarefas em listas. O gestor revisa e devolve. Um aviso diário lista prazos vencidos."
};
export default tarefasModule;
