/// <mls fileReference="_102035_/l2/solution/fixtures/finalize80/tarefas/integration.defs.ts" enhancement="_blank"/>
export const tarefasIntegration = {
    "schemaVersion": "2026-09-12-ns5-integration-v2",
    "moduleName": "tarefas",
    "inbound": [],
    "outbound": [],
    "plugins": []
};
export default tarefasIntegration;
