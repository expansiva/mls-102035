/// <mls fileReference="_102035_/l2/solution/fixtures/finalize80/tarefas/rules.defs.ts" enhancement="_blank"/>
export const tarefasRules = {
    "schemaVersion": "2026-09-10-ns5-rules-v1",
    "moduleName": "tarefas",
    "rules": []
};
export default tarefasRules;
