/// <mls fileReference="_102035_/l2/agentNewSolution5/helpers/ns5Core.ts" enhancement="_blank"/>
import { deleteModuleL4, listModuleFolders, normalizeModuleName, writePipeline, } from '/_102035_/l2/solution/fs.js';
import { NS5_PIPELINE_SCHEMA_VERSION, NS5_STEP_IDS, } from '/_102035_/l2/solution/types.js';
export const NS5_FLOW_ID = 'agentNewSolution5';
export const NS5_FLOW_VERSION = '2026-09-10-ns5-flow-v1';
export const NS5_AGENT_NAME = 'agentNewSolution5';
export { NS5_STEP_IDS };
const REBUILD_ALL_RE = /(^|\s)\/rebuild\s+all(?:\s+([A-Za-z][A-Za-z0-9]*))?(?=\s|$)/i;
const MODULE_RE = /(^|\s)\/module(?:\s+([A-Za-z][A-Za-z0-9]*))?(?=\s|$)/i;
const FAST_RE = /(^|\s)\/fast(?=\s|$)/i;
export const NS5_STEP_TITLES = {
    module10: 'Module',
    journeys20: 'Journeys',
    ontology30: 'Ontology',
    rules40: 'Rules',
    workflows50: 'Workflows',
    access60: 'Access',
    integration70: 'Integration',
    finalize80: 'Finalize',
};
export const NS5_STEP_DEPENDS_ON = {
    module10: [],
    journeys20: ['module10-done'],
    ontology30: ['journeys20-done'],
    rules40: ['ontology30-done'],
    workflows50: ['ontology30-done'],
    access60: ['ontology30-done'],
    integration70: ['rules40-done', 'workflows50-done', 'access60-done'],
    finalize80: ['integration70-done'],
};
export function isNs5StepId(value) {
    return NS5_STEP_IDS.includes(value);
}
/**
 * Maps child planIds (repair/transport, ontology fan-out, bindings, finalize) back to the owning
 * step. Done-anchors and reserved clarification ids stay unmatched so they are not dispatched.
 */
export function ownerStepId(planId) {
    if (isNs5StepId(planId))
        return planId;
    for (const id of NS5_STEP_IDS) {
        if (planId === `${id}-done` || planId.startsWith(`${id}-clarification`))
            continue;
        if (planId.startsWith(`${id}-`))
            return id;
    }
    return '';
}
/** Parallel ontology children are scheduled as `entity:<PascalId>` (prompt and/or hook args). */
export function ns5OntologyEntitySelector(value) {
    if (typeof value !== 'string')
        return '';
    const match = /^entity:([A-Z][A-Za-z0-9]*)$/.exec(value.trim());
    return match?.[1] || '';
}
export function parseNs5Invocation(value) {
    const raw = String(value || '');
    const fast = FAST_RE.test(raw);
    const rebuildMatch = REBUILD_ALL_RE.exec(raw);
    const rebuildAll = !!rebuildMatch;
    const moduleMatch = MODULE_RE.exec(raw);
    const moduleFromFlag = moduleMatch?.[2] || '';
    const moduleFromRebuild = rebuildMatch?.[2] || '';
    const module = normalizeModuleName(moduleFromFlag || moduleFromRebuild, '');
    const prompt = raw
        .replace(new RegExp(FAST_RE.source, 'gi'), '$1')
        .replace(new RegExp(MODULE_RE.source, 'gi'), '$1')
        .replace(new RegExp(REBUILD_ALL_RE.source, 'gi'), '$1')
        .replace(/\s+/g, ' ')
        .trim();
    return { fast, rebuildAll, module, prompt };
}
export function createEmptyPipeline(moduleName, sourcePrompt, invocation, now = new Date().toISOString()) {
    return {
        schemaVersion: NS5_PIPELINE_SCHEMA_VERSION,
        flowId: NS5_FLOW_ID,
        moduleName,
        status: 'inProgress',
        steps: {},
        sourcePrompt,
        invocation,
        updatedAt: now,
    };
}
export function createNs5AgentStep(stepId, moduleName) {
    const dependsOn = [...NS5_STEP_DEPENDS_ON[stepId]];
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: NS5_STEP_TITLES[stepId],
        status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName: NS5_AGENT_NAME,
        prompt: JSON.stringify({ planId: stepId, moduleName }),
        rags: [],
        planning: {
            planId: stepId,
            dependsOn,
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
export function buildNs5PlannedSteps(moduleName) {
    return NS5_STEP_IDS.map(stepId => createNs5AgentStep(stepId, moduleName));
}
export function existingModuleName(moduleName) {
    const wanted = moduleName.toLowerCase();
    for (const name of listModuleFolders()) {
        if (name.toLowerCase() === wanted)
            return name;
    }
    return '';
}
export async function startNs5Pipeline(moduleName, sourcePrompt, invocation, rebuildAll) {
    let deleted = 0;
    if (rebuildAll) {
        const keys = await deleteModuleL4(moduleName);
        deleted = keys.length;
    }
    const pipeline = createEmptyPipeline(moduleName, sourcePrompt, invocation);
    if (rebuildAll)
        pipeline.rebuildAll = { deleted, at: pipeline.updatedAt };
    await writePipeline(pipeline);
    return pipeline;
}
export function moduleTokenOk(moduleName) {
    return /^[a-z][A-Za-z0-9]*$/.test(moduleName);
}
export function createNs5RetryStep(stepId, moduleName, kind, attempt, extra = {}) {
    const planId = `${stepId}-${kind}-${attempt}`;
    const suffix = kind === 'repair' ? `R${attempt}` : `T${attempt}`;
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: `${NS5_STEP_TITLES[stepId]} · ${suffix}`,
        status: 'waiting_human_input',
        nextSteps: [],
        agentName: NS5_AGENT_NAME,
        prompt: JSON.stringify({ planId: stepId, moduleName, [`${kind}Attempt`]: attempt, ...extra }),
        rags: [],
        planning: {
            planId,
            dependsOn: [],
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
export function nextNs5RunNn(existingShortNames) {
    const re = /^run(\d+)_newsolution5$/;
    let max = 0;
    for (const name of existingShortNames) {
        const match = re.exec(name);
        if (match)
            max = Math.max(max, Number(match[1]));
    }
    return String(max + 1).padStart(2, '0');
}
export function markNs5Complete(pipeline, now = new Date().toISOString()) {
    if (pipeline.status === 'failed')
        return pipeline;
    return {
        ...pipeline,
        status: 'complete',
        awaitingStep: undefined,
        updatedAt: now,
    };
}
export function markNs5Step(pipeline, stepId, next) {
    const current = pipeline.steps[stepId];
    if (current?.status === 'approved') {
        return { ...pipeline, updatedAt: next.updatedAt };
    }
    const failed = next.status === 'failed';
    const approved = next.status === 'approved';
    return {
        ...pipeline,
        steps: { ...pipeline.steps, [stepId]: next },
        updatedAt: next.updatedAt,
        ...(failed ? { status: 'failed', awaitingStep: undefined } : {}),
        ...(approved && pipeline.awaitingStep === stepId
            ? { status: 'inProgress', awaitingStep: undefined }
            : {}),
    };
}
