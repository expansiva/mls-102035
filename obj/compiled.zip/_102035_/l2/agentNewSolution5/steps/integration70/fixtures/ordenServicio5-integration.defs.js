/// <mls fileReference="_102047_/l4/ordenServicio5/integration.defs.ts" enhancement="_blank"/>
export const ordenServicio5Integration = {
    "schemaVersion": "2026-09-12-ns5-integration-v2",
    "moduleName": "ordenServicio5",
    "inbound": [],
    "outbound": [],
    "plugins": []
};
export default ordenServicio5Integration;
