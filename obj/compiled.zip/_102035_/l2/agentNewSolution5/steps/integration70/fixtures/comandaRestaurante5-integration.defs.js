/// <mls fileReference="_102047_/l4/comandaRestaurante5/integration.defs.ts" enhancement="_blank"/>
export const comandaRestaurante5Integration = {
    "schemaVersion": "2026-09-12-ns5-integration-v2",
    "moduleName": "comandaRestaurante5",
    "inbound": [],
    "outbound": [],
    "plugins": []
};
export default comandaRestaurante5Integration;
