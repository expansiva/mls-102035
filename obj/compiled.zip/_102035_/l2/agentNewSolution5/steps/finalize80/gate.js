/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/finalize80/gate.ts" enhancement="_blank"/>
/**
 * Integrity oracle across the six NS5 sources. One code per check (I1–I13).
 * Errors fail the run; warnings do not.
 *
 * I2 checks `effect: 'transition'` + `transitionRef` against ontology (actor in `by`,
 * `from` reachable from source-SCC births) for journey `act` and for workflow
 * `mechanical`/`llm` stages. `create` and `update` are not I2 errors.
 * collectNs5LifecycleSignal / ns5LifecycleHasBranchingOrigin still gate `decide`.
 * ontology30 rejects appendOnly plus a transition act or decide first, with repair.
 */
import { anchorPath } from '/_102035_/l2/agentNewSolution5/steps/access60/contracts.js';
import { collectNs5LifecycleSignal, ns5EntityHasActOrAffects, ns5EntityHasWrittenFields, ns5EntityWriter, ns5LifecycleHasBranchingOrigin, ns5ReachableStates, ns5ResolveEntityWriter, ns5SourceSccStates, } from '/_102035_/l2/agentNewSolution5/steps/ontology30/contracts.js';
import { ns5RuleEntries, ns5RuleIds } from '/_102035_/l2/solution/rulesView.js';
import { ns5FieldRefExists, splitFieldRef, } from '/_102035_/l2/agentNewSolution5/steps/rules40/contracts.js';
import { collectNs5InboundPending, parseNs5InboundEventRef, parseNs5OutboundOn, parseNs5UsedBy, } from '/_102035_/l2/agentNewSolution5/steps/integration70/contracts.js';
import { collectNs5Handoffs, collectNs5ProcessSignals, parseNs5TriggerEvent, } from '/_102035_/l2/agentNewSolution5/steps/workflows50/contracts.js';
import { isNs5OntologyV3Entity, ns5OntologyEdges, ns5OntologyEntityIds, splitNs5EntityRef, } from '/_102035_/l2/solution/ontologyView.js';
import { buildNs5FinalizeReport, NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION, NS5_FINALIZE_I2_POSSIBLE_MISSING_TRANSITION_REF, NS5_FINALIZE_I6_SYSTEM_TRANSITION_UNOWNED, NS5_FINALIZE_I8_LOGIN_PERSON_WITHOUT_REGISTRATION, NS5_FINALIZE_I11_INBOUND_PENDING_IN_SIBLING, oracleCode, } from '/_102035_/l2/agentNewSolution5/steps/finalize80/contracts.js';
export function runNs5Oracle(sources) {
    const errors = [];
    const warnings = [];
    const add = (bucket, checkId, path, message, code) => {
        bucket.push({ checkId, code: code || oracleCode(checkId), path, message });
    };
    const error = (checkId, path, message, code) => add(errors, checkId, path, message, code);
    const warning = (checkId, path, message, code) => add(warnings, checkId, path, message, code);
    checkI1(sources, error);
    checkI2(sources, error, warning);
    checkI3(sources, error);
    checkI4(sources, error);
    checkI5(sources, error);
    checkI6(sources, warning);
    checkI7(sources, error);
    checkI8(sources, error);
    checkI9(sources, error);
    checkI10(sources, error);
    checkI11(sources, warning);
    checkI12(sources, error);
    checkI13(sources, warning);
    return buildNs5FinalizeReport(sources.module.moduleName, errors, warnings, {
        actors: sources.access.actors.length,
        journeys: sources.journeys.length,
        entities: sources.entities.length,
        rules: ns5RuleEntries(sources.rules).length,
        processes: sources.workflows.processes.length,
        grants: sources.access.grants.length,
    });
}
function checkI1(sources, error) {
    const actorIds = new Set(sources.access.actors.map(actor => actor.actorId).filter(Boolean));
    const entityById = entityMap(sources);
    const entityIds = new Set(entityById.keys());
    const journeyById = new Map(sources.journeys.map(journey => [journey.journeyId, journey]));
    const journeyIds = new Set(journeyById.keys());
    for (const entry of sources.journeyIndex.journeys) {
        if (entry.actorRef && !actorIds.has(entry.actorRef)) {
            error('I1', `journeys/index.${entry.journeyId}.actorRef`, `Unknown actor ${entry.actorRef}.`);
        }
        if (entry.journeyId && !journeyIds.has(entry.journeyId)) {
            error('I1', `journeys/index.${entry.journeyId}`, `Unknown journey ${entry.journeyId}.`);
        }
    }
    for (const journey of sources.journeys) {
        const base = `journeys.${journey.journeyId}`;
        if (journey.business.actorRef && !actorIds.has(journey.business.actorRef)) {
            error('I1', `${base}.actorRef`, `Unknown actor ${journey.business.actorRef}.`);
        }
        journey.business.steps.forEach((step, index) => {
            const path = `${base}.steps[${index}]`;
            if (step.entity && !entityIds.has(step.entity) && !isLiftedModuleDetailRef(step.entity, sources)) {
                error('I1', `${path}.entity`, `Unknown entity ${step.entity}.`);
            }
            for (const extra of step.affects || []) {
                // ns5_43 T1/T5: `affects` is an entity, or a path into an embedded child of one. The root has to
                // be an entity of this module; the path has to resolve on it — on a v3 entity that means a node
                // of `record.fields`, on a v2 one a `fieldId` or a `details.<name>`.
                if (!extra)
                    continue;
                const { root, path: childPath } = splitNs5EntityRef(extra);
                if (!entityIds.has(root) && !isLiftedModuleDetailRef(root, sources)) {
                    error('I1', `${path}.affects`, `Unknown entity ${root}.`);
                    continue;
                }
                if (childPath && entityIds.has(root) && !fieldExists(extra, entityById)) {
                    error('I1', `${path}.affects`, `Unknown field ${extra}.`);
                }
            }
            if (step.handoffTo && !actorIds.has(step.handoffTo)) {
                error('I1', `${path}.handoffTo`, `Unknown actor ${step.handoffTo}.`);
            }
            if (step.transitionRef) {
                const entity = entityById.get(step.entity);
                const ids = new Set((entity?.transitions || []).map(item => item.transitionId).filter(Boolean));
                if (!ids.has(step.transitionRef)) {
                    error('I1', `${path}.transitionRef`, `Unknown transition ${step.transitionRef}.`);
                }
            }
        });
    }
    for (const entity of sources.entities) {
        const states = new Set(entity.lifecycleStates.map(item => item.state).filter(Boolean));
        entity.transitions.forEach((transition, index) => {
            const path = `ontology.${entity.entityId}.transitions[${index}]`;
            for (const from of transition.from) {
                if (from && !states.has(from))
                    error('I1', `${path}.from`, `Unknown lifecycle state ${from}.`);
            }
            if (transition.to && !states.has(transition.to)) {
                error('I1', `${path}.to`, `Unknown lifecycle state ${transition.to}.`);
            }
            if (Array.isArray(transition.by)) {
                for (const actor of transition.by) {
                    if (actor && !actorIds.has(actor))
                        error('I1', `${path}.by`, `Unknown actor ${actor}.`);
                }
            }
        });
    }
    sources.workflows.processes.forEach((process, processIndex) => {
        const base = `workflows.processes[${processIndex}]`;
        if (process.trigger.kind === 'manual' && process.trigger.actorRef && !actorIds.has(process.trigger.actorRef)) {
            error('I1', `${base}.trigger.actorRef`, `Unknown actor ${process.trigger.actorRef}.`);
        }
        if (process.trigger.kind === 'event' && process.trigger.event) {
            const parsed = parseNs5TriggerEvent(process.trigger.event);
            const inboundRef = parseNs5InboundEventRef(process.trigger.event);
            if (parsed) {
                if (!entityIds.has(parsed.entityId)) {
                    error('I1', `${base}.trigger.event`, `Unknown entity ${parsed.entityId}.`);
                }
                else {
                    const ids = new Set((entityById.get(parsed.entityId)?.transitions || []).map(item => item.transitionId));
                    if (!ids.has(parsed.transitionId)) {
                        error('I1', `${base}.trigger.event`, `Unknown transition ${parsed.entityId}.${parsed.transitionId}.`);
                    }
                }
            }
            else if (inboundRef) {
                const inboundIds = new Set(sources.integration.inbound.map(item => `${item.from || ''}.${item.event || item.id}`));
                if (!inboundIds.has(`${inboundRef.moduleName}.${inboundRef.eventId}`)) {
                    error('I1', `${base}.trigger.event`, `Unknown inbound event ${process.trigger.event}.`);
                }
            }
            else {
                error('I1', `${base}.trigger.event`, `Unknown transition ${process.trigger.event}.`);
            }
        }
        process.tasks.forEach((task, taskIndex) => {
            const path = `${base}.tasks[${taskIndex}]`;
            if (task.actorRef && !actorIds.has(task.actorRef)) {
                error('I1', `${path}.actorRef`, `Unknown actor ${task.actorRef}.`);
            }
            if (task.journeyRef && !journeyIds.has(task.journeyRef)) {
                error('I1', `${path}.journeyRef`, `Unknown journey ${task.journeyRef}.`);
            }
            if (task.entityRef && !entityIds.has(task.entityRef)) {
                error('I1', `${path}.entityRef`, `Unknown entity ${task.entityRef}.`);
            }
            if (task.transitionRef && task.entityRef) {
                const ids = new Set((entityById.get(task.entityRef)?.transitions || []).map(item => item.transitionId));
                if (!ids.has(task.transitionRef)) {
                    error('I1', `${path}.transitionRef`, `Unknown transition ${task.transitionRef}.`);
                }
            }
        });
    });
    (sources.workflows.journeyDecisions || []).forEach((decision, index) => {
        const path = `workflows.journeyDecisions[${index}]`;
        if (decision.journeyId && !journeyIds.has(decision.journeyId)) {
            error('I1', `${path}.journeyId`, `Unknown journey ${decision.journeyId}.`);
        }
        if (decision.processId) {
            const ids = new Set(sources.workflows.processes.map(process => process.processId));
            if (!ids.has(decision.processId)) {
                error('I1', `${path}.processId`, `Unknown process ${decision.processId}.`);
            }
        }
    });
    sources.access.grants.forEach((grant, index) => {
        const path = `access.grants[${index}]`;
        if (grant.actorRef && !actorIds.has(grant.actorRef)) {
            error('I1', `${path}.actorRef`, `Unknown actor ${grant.actorRef}.`);
        }
        for (const entityId of grant.entityRefs) {
            if (entityId && !entityIds.has(entityId))
                error('I1', `${path}.entityRefs`, `Unknown entity ${entityId}.`);
        }
        if (grant.dataScope.anchorEntity && !entityIds.has(grant.dataScope.anchorEntity)) {
            error('I1', `${path}.anchorEntity`, `Unknown entity ${grant.dataScope.anchorEntity}.`);
        }
        for (const ref of [...(grant.disclosure.allowedFields || []), ...(grant.disclosure.deniedFields || [])]) {
            if (!fieldExists(ref, entityById))
                error('I1', `${path}.disclosure`, `Unknown field ${ref}.`);
        }
    });
    const integrationItems = [
        ...sources.integration.inbound.map((item, index) => ({ path: `integration.inbound[${index}]`, item })),
        ...sources.integration.outbound.map((item, index) => ({ path: `integration.outbound[${index}]`, item })),
    ];
    for (const { path, item } of integrationItems) {
        for (const entityId of item.entityRefs) {
            if (entityId && !entityIds.has(entityId))
                error('I1', `${path}.entityRefs`, `Unknown entity ${entityId}.`);
        }
    }
}
function checkI2(sources, error, warning) {
    const entityById = entityMap(sources);
    const reachableByEntity = new Map();
    for (const entity of sources.entities) {
        if (!entityHasLifecycle(entity))
            continue;
        reachableByEntity.set(entity.entityId, reachableFromBirths(entity));
    }
    for (const journey of sources.journeys) {
        const actor = journey.business.actorRef;
        journey.business.steps.forEach((step, index) => {
            const path = `journeys.${journey.journeyId}.steps[${index}]`;
            if (step.kind === 'decide') {
                const signal = collectNs5LifecycleSignal(sources.journeys, step.entity);
                const entity = entityById.get(step.entity);
                if (signal.requiresBranching && (!entity || !ns5LifecycleHasBranchingOrigin(entity))) {
                    error('I2', path, `decide ${step.stepId} on ${step.entity} needs at least two transitions from the same origin state.`);
                }
                return;
            }
            if (step.kind !== 'act' || !step.entity)
                return;
            const entity = entityById.get(step.entity);
            if (step.effect === 'transition') {
                if (!step.transitionRef)
                    return;
                const transition = (entity?.transitions || []).find(item => item.transitionId === step.transitionRef);
                if (!transition)
                    return;
                if (!actorMatches(transition.by, actor)) {
                    error('I2', path, `act ${step.stepId} transitionRef ${step.transitionRef} on ${step.entity} does not include ${actor || '(missing actor)'} in by.`, NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION);
                    return;
                }
                const reachable = reachableByEntity.get(step.entity) ?? null;
                if (!fromIntersects(transition.from, reachable)) {
                    error('I2', path, `act ${step.stepId} transitionRef ${step.transitionRef} on ${step.entity} has from states unreachable from source-SCC births.`, NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION);
                }
                return;
            }
            if (step.effect === 'create')
                return;
            if (!entityHasLifecycle(entity))
                return;
            if (!(entity?.transitions || []).some(item => actorMatches(item.by, actor)))
                return;
            warning('I2', path, `act ${step.stepId} on ${step.entity} has no transitionRef; ${actor || '(missing actor)'} has declared transitions (possible missing transitionRef).`, NS5_FINALIZE_I2_POSSIBLE_MISSING_TRANSITION_REF);
        });
    }
    sources.workflows.processes.forEach((process, processIndex) => {
        process.tasks.forEach((task, taskIndex) => {
            if (task.kind !== 'mechanical' && task.kind !== 'llm')
                return;
            if (task.effect !== 'transition')
                return;
            if (!task.transitionRef || !task.entityRef)
                return;
            const path = `workflows.processes[${processIndex}].tasks[${taskIndex}]`;
            const entity = entityById.get(task.entityRef);
            const transition = (entity?.transitions || []).find(item => item.transitionId === task.transitionRef);
            if (!transition)
                return;
            if (!taskTransitionByAllows(transition.by, task.actorRef)) {
                error('I2', path, `task ${task.taskId} transitionRef ${task.transitionRef} on ${task.entityRef} does not include ${task.actorRef || 'system'} in by.`, NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION);
                return;
            }
            const reachable = reachableByEntity.get(task.entityRef) ?? null;
            if (!fromIntersects(transition.from, reachable)) {
                error('I2', path, `task ${task.taskId} transitionRef ${task.transitionRef} on ${task.entityRef} has from states unreachable from source-SCC births.`, NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION);
            }
        });
    });
}
function checkI3(sources, error) {
    const journeyActors = new Set(sources.journeys.map(journey => journey.business.actorRef).filter(Boolean));
    const grantsByActor = new Set(sources.access.grants.map(grant => grant.actorRef).filter(Boolean));
    for (const actor of sources.access.actors) {
        if (!actor.actorId)
            continue;
        if (!journeyActors.has(actor.actorId)) {
            error('I3', `access.actors.${actor.actorId}`, `Actor ${actor.actorId} has no journey.`);
        }
        if (!grantsByActor.has(actor.actorId)) {
            error('I3', `access.actors.${actor.actorId}`, `Actor ${actor.actorId} has no grant.`);
        }
    }
}
function checkI4(sources, error) {
    const ruleIds = ns5RuleIds(sources.rules);
    for (const entity of sources.entities) {
        entity.transitions.forEach((transition, index) => {
            (transition.ruleRefs || []).forEach((ruleRef, refIndex) => {
                if (!ruleRef)
                    return;
                if (ruleIds.has(ruleRef))
                    return;
                error('I4', `ontology.${entity.entityId}.transitions[${index}].ruleRefs[${refIndex}]`, `Unknown rule ${ruleRef}.`);
            });
        });
    }
}
function checkI5(sources, error) {
    const entityById = entityMap(sources);
    const relationships = ns5OntologyEdges(sources.ontologyIndex).map(item => ({
        relationshipId: item.relationshipId,
        fromEntity: item.fromEntity,
        toEntity: item.toEntity,
        required: item.required,
    }));
    const personIds = sources.entities.filter(entity => entity.party === 'person').map(entity => entity.entityId);
    for (const entity of sources.entities) {
        if (entity.kind !== 'mdm')
            continue;
        if (!entity.mdmSubtype) {
            error('I5', `ontology.${entity.entityId}.mdmSubtype`, `mdm entity ${entity.entityId} is missing mdmSubtype.`);
        }
    }
    sources.access.grants.forEach((grant, index) => {
        if (grant.dataScope.mode !== 'own')
            return;
        const anchor = grant.dataScope.anchorEntity || personIds[0] || '';
        for (const entityId of grant.entityRefs) {
            const entity = entityById.get(entityId);
            if (!entity || entity.kind === 'mdm')
                continue;
            const target = anchor && entityById.get(anchor)?.party === 'person'
                ? anchor
                : personIds.find(personId => anchorPath(entityId, personId, relationships) !== null) || '';
            if (!target || anchorPath(entityId, target, relationships) === null) {
                error('I5', `access.grants[${index}].entityRefs`, `own grant ${grant.grantId} entity ${entityId} does not reach a party:person.`);
            }
        }
    });
}
function checkI6(sources, warning) {
    const journeyViews = sources.journeys.map(journey => ({
        journeyId: journey.journeyId,
        business: {
            actorRef: journey.business.actorRef,
            steps: journey.business.steps,
        },
    }));
    const entityViews = sources.entities.map(entity => ({
        entityId: entity.entityId,
        transitions: entity.transitions.map(transition => ({ transitionId: transition.transitionId, by: transition.by })),
    }));
    const coveredJourneys = new Set();
    const ownedTransitions = new Set();
    for (const process of sources.workflows.processes) {
        if (process.trigger.kind === 'event' && process.trigger.event) {
            const parsed = parseNs5TriggerEvent(process.trigger.event);
            if (parsed)
                ownedTransitions.add(`${parsed.entityId}.${parsed.transitionId}`);
        }
        for (const task of process.tasks) {
            if (task.kind === 'human' && task.journeyRef)
                coveredJourneys.add(task.journeyRef);
            if ((task.kind === 'mechanical' || task.kind === 'llm')
                && task.effect === 'transition'
                && task.entityRef
                && task.transitionRef) {
                ownedTransitions.add(`${task.entityRef}.${task.transitionRef}`);
            }
        }
    }
    for (const handoff of collectNs5Handoffs(journeyViews)) {
        if (coveredJourneys.has(handoff.journeyId))
            continue;
        warning('I6', `journeys.${handoff.journeyId}.${handoff.stepId}`, `handoff ${handoff.stepId} has no covering process in workflows.`);
    }
    const signals = collectNs5ProcessSignals(journeyViews, entityViews);
    const needsProcess = signals.filter(signal => signal.kind === 'foreignBy' || signal.kind === 'crossActorDecide');
    if (needsProcess.length && sources.workflows.processes.length === 0) {
        warning('I6', 'workflows.processes', 'A foreign-by transition or cross-actor decide has no process in workflows.');
    }
    for (const entity of sources.entities) {
        for (const transition of entity.transitions) {
            if (transition.by !== 'system' && transition.by !== 'time')
                continue;
            const key = `${entity.entityId}.${transition.transitionId}`;
            if (ownedTransitions.has(key))
                continue;
            warning('I6', `ontology.${entity.entityId}.${transition.transitionId}`, `system/time transition ${key} is not an effect:transition stage or trigger.event.`, NS5_FINALIZE_I6_SYSTEM_TRANSITION_UNOWNED);
        }
    }
}
function checkI7(sources, error) {
    reportOrphans('journeys', sources.journeyDiskFiles, sources.journeyIndex.journeys.map(entry => entry.journeyId), error);
    reportOrphans('ontology', sources.ontologyDiskFiles, ns5OntologyEntityIds(sources.ontologyIndex), error);
}
/**
 * A party:person that anchors an own/related grant is someone who will sign in.
 * She is registered when any of: (a) an internal actor writes her (`act` entity
 * or `affects` — same writer predicate as I10, restricted to internal-actor
 * journeys); (b) `writer: 'crud'` covered by an internal-actor grant (same
 * predicate as `NS5_ACCESS_CRUD_WITHOUT_INTERNAL_GRANT` / I10); (c) an `act` of
 * her own external actor writes her (self-registration); (d) derived `parent`
 * or `attach` — attach by an internal actor is cadastro, by an external actor
 * is self-registration. Journey `entry.mode` has no public value.
 */
function checkI8(sources, error) {
    const entityById = entityMap(sources);
    const actorById = new Map(sources.access.actors.map(actor => [actor.actorId, actor]));
    const writerPlan = {
        entities: sources.entities.map(writerView),
        relationships: ns5OntologyEdges(sources.ontologyIndex),
    };
    const internalJourneys = rootedJourneys(sources.journeys).filter(journey => actorById.get(journey.business.actorRef)?.kind === 'internal');
    sources.access.grants.forEach((grant, index) => {
        const mode = grant.dataScope.mode;
        if (mode !== 'own' && mode !== 'related')
            return;
        const personId = grant.dataScope.anchorEntity || '';
        if (!personId)
            return;
        const entity = entityById.get(personId);
        if (!entity || entity.party !== 'person')
            return;
        if (ns5EntityHasActOrAffects(internalJourneys, personId))
            return;
        const crudByInternal = ns5EntityWriter(entity) === 'crud' && sources.access.grants.some(item => {
            if (!item.entityRefs.includes(personId))
                return false;
            return actorById.get(item.actorRef)?.kind === 'internal';
        });
        if (crudByInternal)
            return;
        const grantActor = actorById.get(grant.actorRef);
        if (grantActor?.kind === 'external') {
            const ownJourneys = rootedJourneys(sources.journeys).filter(journey => journey.business.actorRef === grant.actorRef);
            if (ns5EntityHasActOrAffects(ownJourneys, personId))
                return;
        }
        const resolved = ns5ResolveEntityWriter(writerView(entity), writerPlan, rootedJourneys(sources.journeys));
        if (resolved.kind === 'parent' || resolved.kind === 'attach')
            return;
        error('I8', `access.grants[${index}]`, `Person ${personId} is the ${mode} login anchor of grant ${grant.grantId} but is not registered: no internal actor writes that entity (act entity or affects), it is not writer: 'crud' with an internal-actor grant, and the grant's own external actor does not write it (self-registration).`, NS5_FINALIZE_I8_LOGIN_PERSON_WITHOUT_REGISTRATION);
    });
}
function checkI9(sources, error) {
    for (const entity of sources.entities) {
        // ns5_43 T5: uniqueness is over STORED COLUMNS. On v2 those are `fields[]` plus the identity; on a
        // v3 table they are the top-level fields other than `details`. A path into the document is not one.
        const fieldIds = new Set(entity.columnIds.filter(Boolean));
        (entity.uniqueKeys || []).forEach((key, keyIndex) => {
            key.forEach((fieldId, fieldIndex) => {
                if (!fieldId)
                    return;
                if (fieldIds.has(fieldId))
                    return;
                error('I9', `ontology.${entity.entityId}.uniqueKeys[${keyIndex}][${fieldIndex}]`, `Unknown field ${fieldId}.`);
            });
        });
    }
}
/**
 * Same writer predicates as ontology30 / access60: a written entity is an `act`
 * entity or listed in an act's `affects`, or `writer: 'crud'` / `writer: 'inbound'`,
 * or derived `parent`/`attach`; a crud entity has an internal-actor grant; inbound
 * must appear in inbound.writes. Conflicting crud is dropped by ontology30
 * normalize, not by this check.
 */
function checkI10(sources, error) {
    const actorById = new Map(sources.access.actors.map(actor => [actor.actorId, actor]));
    const inboundWrites = new Set(sources.integration.inbound.flatMap(item => item.writes || []));
    const writerPlan = {
        entities: sources.entities.map(writerView),
        relationships: ns5OntologyEdges(sources.ontologyIndex),
    };
    for (const entity of sources.entities) {
        const path = `ontology.${entity.entityId}`;
        const resolved = ns5ResolveEntityWriter(writerView(entity), writerPlan, rootedJourneys(sources.journeys));
        const crud = resolved.kind === 'crud';
        const inbound = resolved.kind === 'inbound';
        if (resolved.kind === 'none' && ns5EntityHasWrittenFields(writtenFieldsView(entity))) {
            error('I10', `${path}.writer`, `Entity ${entity.entityId} has written fields but no writer: it must be the entity of an act step or listed in an act's affects, or declare writer: 'crud' (a reference catalog with no lifecycle), or writer: 'inbound' (created by an integration event).`);
        }
        if (inbound && !inboundWrites.has(entity.entityId)) {
            error('I10', `${path}.writer`, `Entity ${entity.entityId} declares writer inbound but no inbound.writes names it.`);
        }
        if (!crud)
            continue;
        const covered = sources.access.grants.some(grant => {
            if (!grant.entityRefs.includes(entity.entityId))
                return false;
            return actorById.get(grant.actorRef)?.kind === 'internal';
        });
        if (covered)
            continue;
        error('I10', `${path}.writer`, `CRUD entity ${entity.entityId} has no grant from an internal actor.`);
    }
}
function checkI11(sources, warning) {
    const pending = collectNs5InboundPending(sources.integration.inbound, sources.module.moduleName, sources.siblings || []);
    pending.forEach((request, index) => {
        warning('I11', `integration.inbound pending[${index}]`, `inbound ${request.eventId} from ${request.to || request.targetModule} is not published by that sibling; queued at l4/${request.targetModule}/tobe/integration/.`, NS5_FINALIZE_I11_INBOUND_PENDING_IN_SIBLING);
    });
}
function checkI12(sources, error) {
    const entityById = entityMap(sources);
    const journeySteps = new Map();
    for (const journey of sources.journeys) {
        journeySteps.set(journey.journeyId, new Set(journey.business.steps.map(step => step.stepId)));
    }
    const processTasks = new Map();
    for (const process of sources.workflows.processes) {
        processTasks.set(process.processId, new Set(process.tasks.map(task => task.taskId)));
    }
    const platformEventIds = new Set(sources.platformEventIds || []);
    sources.integration.outbound.forEach((item, index) => {
        const path = `integration.outbound[${index}]`;
        const parsed = parseNs5OutboundOn(item.on || '');
        if (!parsed) {
            error('I12', `${path}.on`, 'outbound.on must be Entity.transitionId or Entity.create.');
            return;
        }
        const entity = entityById.get(parsed.entityId);
        if (!entity) {
            error('I12', `${path}.on`, `Unknown entity ${parsed.entityId}.`);
            return;
        }
        if (parsed.transitionId === 'create')
            return;
        if (!entity.transitions.some(row => row.transitionId === parsed.transitionId)) {
            error('I12', `${path}.on`, `Unknown transition ${parsed.entityId}.${parsed.transitionId}.`);
        }
    });
    sources.integration.inbound.forEach((item, index) => {
        if (item.from !== 'organization')
            return;
        const eventId = item.event || item.id;
        if (platformEventIds.size && !platformEventIds.has(eventId)) {
            error('I12', `integration.inbound[${index}].event`, `event ${eventId} is not in the platform catalog.`);
        }
    });
    sources.integration.plugins.forEach((plugin, pluginIndex) => {
        plugin.usedBy.forEach((ref, refIndex) => {
            const path = `integration.plugins[${pluginIndex}].usedBy[${refIndex}]`;
            const parsed = parseNs5UsedBy(ref);
            if (!parsed) {
                error('I12', path, 'usedBy must be journeyId.stepId or processId.taskId.');
                return;
            }
            const steps = journeySteps.get(parsed.ownerId);
            if (steps) {
                if (!steps.has(parsed.memberId))
                    error('I12', path, `Unknown step ${ref}.`);
                return;
            }
            const tasks = processTasks.get(parsed.ownerId);
            if (tasks) {
                if (!tasks.has(parsed.memberId))
                    error('I12', path, `Unknown task ${ref}.`);
                return;
            }
            error('I12', path, `Unknown journey or process ${parsed.ownerId}.`);
        });
    });
}
function checkI13(sources, warning) {
    sources.access.grants.forEach((grant, index) => {
        if (grant.dataScope.mode !== 'custom')
            return;
        warning('I13', `access.grants[${index}]`, `custom grant ${grant.grantId || index} for actor ${grant.actorRef || '(missing)'}; the backend does not apply custom.`);
    });
}
function reportOrphans(kind, diskFiles, indexIds, error) {
    if (!diskFiles)
        return;
    const keep = new Set(['index', ...indexIds.filter(Boolean)]);
    const extras = [];
    const seen = new Set();
    for (const raw of diskFiles) {
        const name = String(raw || '').replace(/\.defs\.ts$/, '');
        if (!name || keep.has(name) || seen.has(name))
            continue;
        seen.add(name);
        extras.push(name);
    }
    extras.sort();
    if (!extras.length)
        return;
    error('I7', `${kind}/`, `orphan files: ${extras.join(', ')}`);
}
function entityHasLifecycle(entity) {
    return Boolean(entity && (entity.lifecycleStates.length || entity.transitions.length));
}
function reachableFromBirths(entity) {
    const time = new Set(entity.lifecycleStates.filter(entry => entry.reachedBy === 'time').map(entry => entry.state));
    const roots = ns5SourceSccStates(entity.transitions).filter(state => !time.has(state));
    if (roots.length)
        return ns5ReachableStates(roots, entity.transitions);
    const fallback = entity.lifecycleStates
        .filter(entry => entry.reachedBy !== 'time')
        .map(entry => entry.state)
        .filter(Boolean);
    return fallback.length ? new Set(fallback) : null;
}
function actorMatches(by, actor) {
    return Boolean(actor && Array.isArray(by) && by.includes(actor));
}
function taskTransitionByAllows(by, actorRef) {
    if (by === 'system' || by === 'time')
        return true;
    return Boolean(actorRef && Array.isArray(by) && by.includes(actorRef));
}
function fromIntersects(from, reachable) {
    if (!from.length)
        return false;
    if (reachable === null)
        return true;
    return from.some(state => reachable.has(state));
}
function entityMap(sources) {
    return new Map(sources.entities.map(entity => [entity.entityId, entity]));
}
/**
 * ns5_43 T5. `ns5ResolveEntityWriter` and `ns5EntityHasWrittenFields` live in ontology30 and are closed
 * (ns5_42), so the view is said in the vocabulary they branch on: a v3 `role` IS `kind: 'mdm'`, and the
 * fields a module writes are `writtenFieldIds` (the `details.<moduleName>` branch on a role).
 */
/**
 * ns5_43 T1. `ns5EntityHasActOrAffects` and `ns5ResolveEntityWriter` live in ontology30 (closed, ns5_42)
 * and compare `affects` entries to entity ids. An act that writes an embedded child
 * (`PedidoCompra.details.itens`) writes the entity that owns it, so the journeys handed to those helpers
 * carry the ROOT of each reference.
 */
function rootedJourneys(journeys) {
    if (!journeys.some(journey => journey.business.steps.some(step => (step.affects || []).some(ref => ref.includes('.'))))) {
        return journeys;
    }
    return journeys.map(journey => ({
        ...journey,
        business: {
            ...journey.business,
            steps: journey.business.steps.map(step => (step.affects?.length
                ? { ...step, affects: [...new Set(step.affects.map(ref => splitNs5EntityRef(ref).root))] }
                : step)),
        },
    }));
}
function writerView(entity) {
    return { entityId: entity.entityId, kind: entity.writerKind, ...(entity.writer ? { writer: entity.writer } : {}) };
}
function writtenFieldsView(entity) {
    // v2 keeps reading `fields` live: it is the same list the check has always read, and nothing is
    // derived behind the caller's back. v3 has no flat list, so `writtenFieldIds` answers instead.
    return {
        kind: entity.writerKind,
        fields: isNs5OntologyV3Entity(entity.source)
            ? entity.writtenFieldIds.map(fieldId => ({ fieldId }))
            : entity.fields,
        storage: { idField: entity.idField },
    };
}
/**
 * A journey `entity`/`affects` naming an id ontology30 lifted into `module.details`
 * is a legitimate read of those aggregates — not an unknown entity. Both locks:
 * the id is in `liftedAggregateEntities` (pipeline.json) and `module.details` still
 * has keys (the absorbed aggregates). An unknown id that was never lifted stays I1.
 */
function isLiftedModuleDetailRef(id, sources) {
    if (!id)
        return false;
    if (!(sources.liftedAggregateEntities || []).includes(id))
        return false;
    const details = sources.module.details;
    return !!details && Object.keys(details).length > 0;
}
/**
 * ns5_43 T5. A reference is `<Entity>` or `<Entity>.<path>`. On a v3 entity the resolvable set is the
 * whole tree of `record.fields` (`fieldRefs`, the same one a disclosure addresses); on a v2 entity it is
 * the flat `fields` plus `details.<name>`, answered by the rules40 reader as before.
 */
function fieldExists(ref, entityById) {
    const { root } = splitNs5EntityRef(ref);
    const entity = entityById.get(root);
    if (!entity)
        return false;
    if (isNs5OntologyV3Entity(entity.source))
        return entity.fieldRefs.includes(ref.trim());
    const parsed = splitFieldRef(ref);
    if (!parsed)
        return false;
    return ns5FieldRefExists(ref, asRulesEntity(entity));
}
function asRulesEntity(entity) {
    const source = entity.source;
    return {
        entityId: entity.entityId,
        fields: entity.fields,
        details: !isNs5OntologyV3Entity(source) && source.details
            ? Object.fromEntries(Object.entries(source.details).map(([name, detail]) => [name, detail.description]))
            : undefined,
        ...(entity.storage ? { storage: entity.storage } : {}),
        transitions: entity.transitions.map(transition => ({ transitionId: transition.transitionId, by: transition.by })),
    };
}
