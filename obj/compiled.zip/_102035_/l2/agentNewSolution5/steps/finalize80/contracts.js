/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/finalize80/contracts.ts" enhancement="_blank"/>
export const NS5_FINALIZE_REPORT_SCHEMA_VERSION = '2026-09-10-ns5-finalize-report-v1';
export const NS5_ORACLE_CHECK_IDS = ['I1', 'I2', 'I3', 'I4', 'I5', 'I6', 'I7'];
export const NS5_FINALIZE_I7_ORPHAN_FILE = 'NS5_FINALIZE_I7_ORPHAN_FILE';
export const NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION = 'NS5_FINALIZE_I2_ACT_WITHOUT_TRANSITION';
export function oracleCode(checkId) {
    if (checkId === 'I7')
        return NS5_FINALIZE_I7_ORPHAN_FILE;
    return `NS5_FINALIZE_${checkId}`;
}
export function buildNs5FinalizeReport(moduleName, errors, warnings, counts) {
    const checks = NS5_ORACLE_CHECK_IDS.map(checkId => {
        const errorCount = errors.filter(issue => issue.checkId === checkId).length;
        const warningCount = warnings.filter(issue => issue.checkId === checkId).length;
        const status = errorCount
            ? 'failed'
            : warningCount
                ? 'warned'
                : 'passed';
        return { checkId, status, errorCount, warningCount };
    });
    return {
        schemaVersion: NS5_FINALIZE_REPORT_SCHEMA_VERSION,
        moduleName,
        finalStatus: errors.length ? 'failed' : 'passed',
        checks,
        errors,
        warnings,
        counts,
    };
}
export function formatNs5Oracle(report) {
    return report.errors.map(issue => `${issue.code} ${issue.path}: ${issue.message}`).join('\n');
}
export function ensureConfigListsModule(config, moduleName, userLanguage, projectId) {
    const next = { ...config };
    const patch = {
        moduleId: moduleName,
        basePath: `/${moduleName}`,
        userLanguage,
        navigation: [],
        headerLinks: [],
    };
    if (isRecord(next.projects)) {
        const projects = { ...next.projects };
        const requested = projects[String(projectId)];
        const clientKey = isRecord(requested)
            ? String(projectId)
            : Object.keys(projects).find(key => isRecord(projects[key]) && projects[key].type === 'client');
        if (clientKey) {
            const client = isRecord(projects[clientKey]) ? { ...projects[clientKey] } : {};
            client.modules = mergeModuleList(client.modules, patch);
            projects[clientKey] = client;
            next.projects = projects;
            return next;
        }
    }
    next.modules = mergeModuleList(next.modules, patch);
    return next;
}
function mergeModuleList(value, patch) {
    const modules = Array.isArray(value)
        ? value.filter(isRecord).map(item => ({ ...item }))
        : [];
    const index = modules.findIndex(item => item.moduleId === patch.moduleId);
    if (index >= 0)
        modules[index] = { ...modules[index], ...patch };
    else
        modules.push(patch);
    return modules;
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
