/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/workflows50/agentNs5Workflows.ts" enhancement="_blank"/>
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { readNs5Actors } from '/_102035_/l2/agentNewSolution5/helpers/ns5Actors.js';
import { createNs5RetryStep, markNs5Step, } from '/_102035_/l2/agentNewSolution5/helpers/ns5Core.js';
import { NS5_STEP_HOOKS, drainWaitingSiblings, updateStatus, } from '/_102035_/l2/agentNewSolution5/helpers/ns5Dispatch.js';
import { compileNs5Defs, formatNs5CompileFeedback } from '/_102035_/l2/agentNewSolution5/helpers/ns5Compile.js';
import { draftFile, journeyFile, journeyIndexFile, moduleFile, ontologyEntityFile, ontologyIndexFile, readAgentJson, readAgentText, readDefsJson, readJson, readPipeline, workflowsFile, writeDefs, writeJson, writePipeline, } from '/_102035_/l2/solution/fs.js';
import { createStrictArtifactTool, unwrapArtifactPayload } from '/_102035_/l2/solution/lib.js';
import { ns5OntologyEntityIds, ns5OntologyEntityViews, } from '/_102035_/l2/solution/ontologyView.js';
import { buildNs5WorkflowsArtifactV3, buildNs5WorkflowsTool, collectNs5ProcessSignals, collectNs5TimeEventPhrases, collectNs5WorkflowsRefCatalog, normalizeNs5WorkflowsPayload, ns5WorkflowsNeedsLlm, } from '/_102035_/l2/agentNewSolution5/steps/workflows50/contracts.js';
import { formatNs5WorkflowsGate, validateNs5Workflows, } from '/_102035_/l2/agentNewSolution5/steps/workflows50/gate.js';
const MAX_REPAIRS = 2;
const MAX_TRANSPORT_RETRIES = 1;
export function buildNs5WorkflowsHumanPrompt(input) {
    const signals = collectNs5ProcessSignals(input.journeys, input.entities);
    const phrases = collectNs5TimeEventPhrases(input.sourcePrompt);
    const catalog = collectNs5WorkflowsRefCatalog(input.journeys, input.actorIds, input.entities);
    return [
        '## Source request',
        input.sourcePrompt,
        '',
        `## userLanguage`,
        input.userLanguage,
        '',
        '## Actors',
        input.actorIds.length ? input.actorIds.map(id => `- ${id}`).join('\n') : '(none)',
        '',
        '## Journeys (business)',
        formatJourneys(input.journeys),
        '',
        '## Acts with effect create or transition',
        formatWriteActs(input.journeys),
        '',
        // ns5_49: no `## Entities with lifecycle` block — ontology30 runs AFTER this step. What a
        // mechanical or llm stage cites here is a declaration the ontology will honour.
        '## Time and event phrases from the request',
        phrases.length ? phrases.map(phrase => `- ${phrase}`).join('\n') : '(none)',
        '',
        '## Process signals (why this call ran)',
        signals.length || phrases.length ? JSON.stringify(signals, null, 2) : '(none — this call should not run)',
        '',
        '## Valid reference ids',
        JSON.stringify({
            actorIds: catalog.actorIds,
            journeyIds: catalog.journeyIds,
            entityIds: catalog.entityIds,
            transitionRefs: catalog.transitionRefs,
            handoffs: catalog.handoffs,
        }, null, 2),
        input.gateFeedback ? `## Deterministic repair required\n${input.gateFeedback}` : '',
        input.previousDraft ? `## Current draft; keep unrelated fields\n${JSON.stringify(input.previousDraft, null, 2)}` : '',
    ].filter(Boolean).join('\n');
}
export async function beforeNs5WorkflowsPromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error('[agentNewSolution5:workflows50] task invalid');
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        const moduleArtifact = await readModule(moduleName);
        const [journeys, entities, actors] = await Promise.all([
            readJourneys(moduleName),
            readEntities(moduleName),
            readNs5Actors(moduleName),
        ]);
        const actorIds = actors.map(actor => actor.actorId).filter(Boolean);
        const sourcePrompt = await readSourcePrompt(context, moduleName, moduleArtifact);
        const signals = collectNs5ProcessSignals(journeys, entities);
        const phrases = collectNs5TimeEventPhrases(sourcePrompt);
        if (!ns5WorkflowsNeedsLlm(signals, phrases)) {
            const pipeline = await requirePipeline(moduleName);
            const { artifactPath, compile } = await persistArtifacts(moduleName, [], idleJourneyDecisions(journeys), [], pipeline, true);
            // Deterministic artifact, no LLM to repair it: a compile error here is a generator defect.
            if (compile.status === 'errors')
                throw new Error(formatNs5CompileFeedback(compile));
            return [
                doneAnchor(context, findMutableParent(context, parentStep), moduleName, [artifactPath]),
                updateStatus(context, parentStep, step, hookSequential, 'completed', `workflows50 approved with noProcessSignal: ${artifactPath}`),
            ];
        }
        const [prompt, schema, previous] = await Promise.all([
            readAgentText('steps/workflows50', 'prompt', '.md'),
            readAgentJson('schemas', 'workflows.schema', '.json'),
            moduleName ? readJson(draftFile(moduleName, 'workflows50')) : Promise.resolve(null),
        ]);
        const tool = buildNs5WorkflowsTool(schema, createStrictArtifactTool);
        const humanPrompt = buildNs5WorkflowsHumanPrompt({
            sourcePrompt,
            userLanguage: moduleArtifact.userLanguage,
            actorIds,
            journeys,
            entities,
            gateFeedback: parsed.gateFeedback,
            previousDraft: previous,
        });
        return [promptReady(context, parentStep, hookSequential, args || String(step.prompt || ''), prompt, humanPrompt, tool)];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
export async function afterNs5WorkflowsPromptStep(agent, context, parentStep, step, hookSequential) {
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, step.prompt);
        moduleName = parsed.moduleName;
        const mutationParent = findMutableParent(context, parentStep);
        const payload = unwrapArtifactPayload(step.interaction?.payload?.[0]);
        if (!isRecord(payload)) {
            const failure = readPromptFailure(step, 'workflows50 returned no usable workflows artifact.');
            if (parsed.transportAttempt < MAX_TRANSPORT_RETRIES) {
                return [
                    addStep(context, mutationParent, createNs5RetryStep('workflows50', moduleName, 'transport', parsed.transportAttempt + 1)),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `workflows50 transport retry ${parsed.transportAttempt + 1} scheduled: ${failure}`),
                ];
            }
            throw new Error(failure);
        }
        const journeyIds = (await readJourneys(moduleName)).map(journey => journey.journeyId);
        const { processes, journeyDecisions, systemDecisions } = normalizeNs5WorkflowsPayload(payload, { journeyIds });
        const moduleArtifact = await readModule(moduleName);
        const [journeys, entities, actors] = await Promise.all([
            readJourneys(moduleName),
            readEntities(moduleName),
            readNs5Actors(moduleName),
        ]);
        let pipeline = await requirePipeline(moduleName);
        pipeline = await writeStepState(pipeline, {
            status: 'running',
            updatedAt: new Date().toISOString(),
        });
        const draftPath = await writeJson(draftFile(moduleName, 'workflows50'), {
            processes,
            journeyDecisions,
            ...(systemDecisions.length ? { systemDecisions } : {}),
        });
        const gate = validateNs5Workflows(processes, {
            moduleName,
            actorIds: actors.map(actor => actor.actorId),
            journeys,
            entities,
            journeyDecisions,
        });
        if (!gate.ok) {
            const feedback = formatNs5WorkflowsGate(gate.issues);
            if (parsed.repairAttempt < MAX_REPAIRS) {
                return [
                    addStep(context, mutationParent, createNs5RetryStep('workflows50', moduleName, 'repair', parsed.repairAttempt + 1, { gateFeedback: feedback })),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `workflows50 gate scheduled repair ${parsed.repairAttempt + 1}.`),
                ];
            }
            await writeStepState(pipeline, {
                status: 'failed',
                updatedAt: new Date().toISOString(),
                error: feedback,
                artifactPaths: [draftPath],
            });
            throw new Error(feedback);
        }
        const { artifactPath, compile } = await persistArtifacts(moduleName, processes, journeyDecisions, systemDecisions, pipeline, false);
        if (compile.status === 'errors') {
            const feedback = formatNs5CompileFeedback(compile);
            if (parsed.repairAttempt < MAX_REPAIRS) {
                return [
                    addStep(context, mutationParent, createNs5RetryStep('workflows50', moduleName, 'repair', parsed.repairAttempt + 1, { gateFeedback: feedback })),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `workflows50 compile scheduled repair ${parsed.repairAttempt + 1}.`),
                ];
            }
            throw new Error(feedback);
        }
        return [
            doneAnchor(context, mutationParent, moduleName, [artifactPath]),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `workflows50 approved: ${artifactPath}`),
        ];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
async function persistArtifacts(moduleName, processes, journeyDecisions, systemDecisions, pipeline, noProcessSignal) {
    const artifact = buildNs5WorkflowsArtifactV3(moduleName, processes, journeyDecisions, systemDecisions);
    const artifactPath = await writeDefs(workflowsFile(moduleName), `${moduleName}Workflows`, artifact, 'Ns5WorkflowsArtifact');
    await writeJson(draftFile(moduleName, 'workflows50'), artifact);
    // p4_20: the compiler is the last gate; errors go back to this step's repair, never approved.
    const compile = await compileNs5Defs([workflowsFile(moduleName)]);
    await writeStepState(pipeline, {
        status: compile.status === 'errors' ? 'running' : 'approved',
        updatedAt: new Date().toISOString(),
        artifactPaths: [artifactPath],
        compile,
        ...(noProcessSignal ? { noProcessSignal: true } : {}),
        ...(pipeline.invocation.fast ? { autoReason: 'fast' } : {}),
    });
    return { artifactPath, compile };
}
function idleJourneyDecisions(journeys) {
    return journeys.filter(journey => journey.journeyId).map(journey => ({
        journeyId: journey.journeyId,
        inProcess: false,
    }));
}
async function readModule(moduleName) {
    if (!moduleName)
        throw new Error('workflows50 needs a moduleName.');
    const artifact = await readDefsJson(moduleFile(moduleName));
    if (!artifact)
        throw new Error(`module.defs.ts is missing for ${moduleName}; module10 must run first.`);
    const pipeline = await readPipeline(moduleName);
    // ns5_49: workflows50 now runs on the journeys alone; the ontology comes after it.
    if (pipeline?.steps.journeys20?.status !== 'approved') {
        throw new Error(`journeys20 must be approved before workflows50 (${moduleName}).`);
    }
    return artifact;
}
async function readJourneys(moduleName) {
    const index = await readDefsJson(journeyIndexFile(moduleName));
    if (!index)
        throw new Error(`journeys/index.defs.ts is missing for ${moduleName}; journeys20 must run first.`);
    const journeys = [];
    for (const entry of index.journeys) {
        const artifact = await readDefsJson(journeyFile(moduleName, entry.journeyId));
        if (artifact)
            journeys.push(artifact);
    }
    return journeys;
}
/**
 * ns5_49: in the flow v2 order there is no ontology yet, so a missing index is the normal case and
 * returns `[]` — not a throw. A module recorded under flow v1 still has one, and it is still read
 * whole: an entity file named by the index and missing on disk stays an error.
 */
async function readEntities(moduleName) {
    const index = await readDefsJson(ontologyIndexFile(moduleName));
    if (!index)
        return [];
    const entities = [];
    for (const entityId of ns5OntologyEntityIds(index)) {
        const artifact = await readDefsJson(ontologyEntityFile(moduleName, entityId));
        if (!artifact)
            throw new Error(`ontology/${entityId}.defs.ts is missing for ${moduleName}.`);
        entities.push(artifact);
    }
    return ns5OntologyEntityViews(entities);
}
async function requirePipeline(moduleName) {
    const pipeline = await readPipeline(moduleName);
    if (!pipeline)
        throw new Error(`pipeline.json is missing for ${moduleName}.`);
    return pipeline;
}
async function writeStepState(pipeline, next) {
    const updated = markNs5Step(pipeline, 'workflows50', next);
    await writePipeline(updated);
    return updated;
}
async function recordFailure(moduleName, error) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readPipeline(moduleName);
        if (!pipeline)
            return;
        await writePipeline(markNs5Step(pipeline, 'workflows50', {
            status: 'failed',
            updatedAt: new Date().toISOString(),
            error,
        }));
    }
    catch { /* task trace remains the fallback */ }
}
async function readSourcePrompt(context, moduleName, moduleArtifact) {
    if (moduleName) {
        const pipeline = await readPipeline(moduleName);
        if (pipeline?.sourcePrompt)
            return pipeline.sourcePrompt;
    }
    return moduleArtifact.sourcePrompt || memoryString(context, 'sourcePrompt');
}
function resolveArgs(context, value) {
    const root = parseRecord(value);
    const moduleName = text(root.moduleName) || memoryString(context, 'moduleName');
    return {
        planId: text(root.planId) || 'workflows50',
        moduleName,
        repairAttempt: integer(root.repairAttempt),
        transportAttempt: integer(root.transportAttempt),
        gateFeedback: text(root.gateFeedback),
    };
}
function formatJourneys(journeys) {
    if (!journeys.length)
        return '(none)';
    return journeys.map(journey => [
        `### ${journey.journeyId} (${journey.business.actorRef})`,
        journey.business.title,
        journey.business.goal,
        ...journey.business.steps.map(step => {
            const handoff = step.kind === 'handoff' && step.handoffTo ? ` handoffTo=${step.handoffTo}` : '';
            const effect = step.kind === 'act' && step.effect ? ` effect=${step.effect}` : '';
            const transition = step.transitionRef ? ` transitionRef=${step.transitionRef}` : '';
            return `- ${step.stepId} ${step.kind} ${step.entity}${effect}${transition}${handoff}: ${step.description}`;
        }),
    ].join('\n')).join('\n\n');
}
function formatWriteActs(journeys) {
    const lines = [];
    for (const journey of journeys) {
        for (const step of journey.business.steps) {
            if (step.kind !== 'act')
                continue;
            if (step.effect !== 'create' && step.effect !== 'transition')
                continue;
            const transition = step.transitionRef ? ` transitionRef=${step.transitionRef}` : '';
            lines.push(`- ${journey.journeyId}.${step.stepId} effect=${step.effect} entity=${step.entity}${transition}`);
        }
    }
    return lines.length ? lines.join('\n') : '(none)';
}
function promptReady(context, parentStep, hookSequential, args, systemPrompt, humanPrompt, tool) {
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt,
        humanPrompt,
        tools: [tool],
        toolChoice: { type: 'function', function: { name: tool.function.name } },
    };
}
function doneAnchor(context, parentStep, moduleName, artifactPaths) {
    return addStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Workflows done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({ moduleName, artifactPaths, completedStep: 'workflows50', nextStep: 'ontology30' }),
        planning: { planId: 'workflows50-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
function findMutableParent(context, parentStep) {
    const all = getAllSteps(context.task?.iaCompressed?.nextSteps);
    const current = all.find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current))
        return current;
    const owner = all.find(candidate => isOpenAgent(candidate)
        && (candidate.nextSteps?.some(child => child.stepId === parentStep.stepId)
            || candidate.interaction?.payload?.some(child => child.stepId === parentStep.stepId)));
    if (isOpenAgent(owner))
        return owner;
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    return root?.type === 'agent' ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function readPromptFailure(step, fallback) {
    const payload = step.interaction?.payload?.[0];
    const recordValue = isRecord(payload) ? payload : parseRecord(payload);
    if (typeof recordValue.result === 'string' && recordValue.result.trim())
        return recordValue.result.trim();
    return fallback;
}
function parseRecord(value) {
    const parsed = parseMaybeJson(value);
    return isRecord(parsed) ? parsed : {};
}
function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(clean);
    }
    catch {
        return value;
    }
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function integer(value) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : 0;
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
NS5_STEP_HOOKS.workflows50 = {
    beforePromptStep: beforeNs5WorkflowsPromptStep,
    afterPromptStep: afterNs5WorkflowsPromptStep,
};
