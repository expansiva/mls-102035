/// <mls fileReference="_102047_/l4/comandaRestaurante/workflows.defs.ts" enhancement="_blank"/>
export const comandaRestauranteWorkflows = {
    "schemaVersion": "2026-09-12-ns5-workflows-v2",
    "moduleName": "comandaRestaurante",
    "processes": [],
    "journeyDecisions": [
        {
            "journeyId": "abrirComanda",
            "inProcess": false
        },
        {
            "journeyId": "lancarItemNaComanda",
            "inProcess": false
        },
        {
            "journeyId": "cancelarItemLancado",
            "inProcess": false
        },
        {
            "journeyId": "fecharComanda",
            "inProcess": false
        }
    ]
};
export default comandaRestauranteWorkflows;
