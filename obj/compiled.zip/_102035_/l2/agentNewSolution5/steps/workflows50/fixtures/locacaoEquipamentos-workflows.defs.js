/// <mls fileReference="_102047_/l4/locacaoEquipamentos/workflows.defs.ts" enhancement="_blank"/>
export const locacaoEquipamentosWorkflows = {
    "schemaVersion": "2026-09-12-ns5-workflows-v2",
    "moduleName": "locacaoEquipamentos",
    "processes": [],
    "journeyDecisions": [
        {
            "journeyId": "criarContratoLocacao",
            "inProcess": false
        },
        {
            "journeyId": "registrarDevolucao",
            "inProcess": false
        },
        {
            "journeyId": "acompanharSituacaoEquipamentos",
            "inProcess": false
        }
    ]
};
export default locacaoEquipamentosWorkflows;
