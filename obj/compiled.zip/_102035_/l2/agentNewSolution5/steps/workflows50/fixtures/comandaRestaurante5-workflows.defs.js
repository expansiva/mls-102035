/// <mls fileReference="_102047_/l4/comandaRestaurante5/workflows.defs.ts" enhancement="_blank"/>
export const comandaRestaurante5Workflows = {
    "schemaVersion": "2026-09-12-ns5-workflows-v2",
    "moduleName": "comandaRestaurante5",
    "processes": [],
    "journeyDecisions": [
        {
            "journeyId": "abrirComandaNaMesa",
            "inProcess": false
        },
        {
            "journeyId": "lancarItemNaComanda",
            "inProcess": false
        },
        {
            "journeyId": "cancelarItemLancadoPorEngano",
            "inProcess": false
        },
        {
            "journeyId": "conferirEfecharConta",
            "inProcess": false
        }
    ]
};
export default comandaRestaurante5Workflows;
