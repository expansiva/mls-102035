/// <mls fileReference="_102047_/l4/comandaRestaurante5/workflows.defs.ts" enhancement="_blank"/>
export const comandaRestaurante5Workflows = {
    "schemaVersion": "2026-09-10-ns5-workflows-v1",
    "moduleName": "comandaRestaurante5",
    "processes": []
};
export default comandaRestaurante5Workflows;
