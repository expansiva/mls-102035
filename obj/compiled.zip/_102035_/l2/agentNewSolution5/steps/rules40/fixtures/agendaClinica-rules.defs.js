/// <mls fileReference="_102047_/l4/agendaClinica/rules.defs.ts" enhancement="_blank"/>
export const agendaClinicaRules = {
    "schemaVersion": "2026-09-10-ns5-rules-v1",
    "moduleName": "agendaClinica",
    "rules": [
        {
            "ruleId": "horarioProfissionalExclusivo",
            "description": "Não pode haver duas consultas para o mesmo profissional na mesma data e horário."
        },
        {
            "ruleId": "anotacaoObrigatoriaNoAtendimento",
            "description": "O registro de atendimento deve incluir uma anotação do atendimento."
        }
    ]
};
export default agendaClinicaRules;
