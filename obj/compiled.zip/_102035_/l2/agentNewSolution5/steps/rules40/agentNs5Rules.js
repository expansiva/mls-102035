/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/rules40/agentNs5Rules.ts" enhancement="_blank"/>
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { createNs5RetryStep, markNs5Step, } from '/_102035_/l2/agentNewSolution5/helpers/ns5Core.js';
import { compileNs5Defs, formatNs5CompileFeedback } from '/_102035_/l2/agentNewSolution5/helpers/ns5Compile.js';
import { NS5_STEP_HOOKS, drainWaitingSiblings, updateStatus, } from '/_102035_/l2/agentNewSolution5/helpers/ns5Dispatch.js';
import { draftFile, journeyFile, journeyIndexFile, moduleFile, ontologyEntityFile, ontologyIndexFile, readAgentJson, readAgentText, readDefsJson, readJson, readPipeline, rulesFile, writeDefs, writeJson, writePipeline, } from '/_102035_/l2/solution/fs.js';
import { createStrictArtifactTool, unwrapArtifactPayload } from '/_102035_/l2/solution/lib.js';
import { isNs5OntologyV3Entity, ns5OntologyEntityIds, ns5OntologyEntityViews, ns5OntologyV3FieldLines, } from '/_102035_/l2/solution/ontologyView.js';
import { buildNs5RulesArtifactV2, buildNs5RulesTool, normalizeNs5RulesPayload, ns5RulesToolPayload, partitionCitedRules, } from '/_102035_/l2/agentNewSolution5/steps/rules40/contracts.js';
import { formatNs5RulesGate, validateNs5Rules, } from '/_102035_/l2/agentNewSolution5/steps/rules40/gate.js';
const MAX_REPAIRS = 2;
const MAX_TRANSPORT_RETRIES = 1;
export function buildNs5RulesHumanPrompt(input) {
    const citedRuleIds = [...new Set([
            ...input.entities.flatMap(entity => entity.transitions.flatMap(transition => transition.ruleRefs || [])),
            ...(input.citedRules || []),
        ])].filter(Boolean);
    const partitioned = partitionCitedRules(citedRuleIds);
    return [
        '## Source request',
        input.sourcePrompt,
        '',
        `## userLanguage`,
        input.userLanguage,
        '',
        '## Journeys (business)',
        formatJourneys(input.journeys),
        '',
        '## Ontology (entities, fields, transitions)',
        formatOntology(input.entities),
        partitioned.platform.length
            ? `## platform rules already defined by the platform — cite them, never restate or rename them\n${partitioned.platform.map(id => `- ${id}`).join('\n')}`
            : '',
        partitioned.module.length
            ? `## rules the ontology cited; keep these ids\n${partitioned.module.map(id => `- ${id}`).join('\n')}`
            : '',
        input.gateFeedback ? `## Deterministic repair required\n${input.gateFeedback}` : '',
        // Shown in the TOOL's shape, not the artifact's: the model is about to submit this back (ns5_45).
        input.previousDraft ? `## Current draft; keep unrelated fields\n${JSON.stringify(ns5RulesToolPayload(input.previousDraft), null, 2)}` : '',
    ].filter(Boolean).join('\n');
}
export async function beforeNs5RulesPromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error('[agentNewSolution5:rules40] task invalid');
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        const moduleArtifact = await readModule(moduleName);
        const [journeys, entities] = await Promise.all([readJourneys(moduleName), readEntities(moduleName)]);
        // ns5_43 T2: ontology30 records every rule id its entities cited, the platform ones included.
        const citedRules = (await readPipeline(moduleName))?.steps.ontology30?.citedRules || [];
        const sourcePrompt = await readSourcePrompt(context, moduleName, moduleArtifact);
        const [prompt, schema, previous] = await Promise.all([
            readAgentText('steps/rules40', 'prompt', '.md'),
            readAgentJson('schemas', 'rules.schema', '.json'),
            moduleName ? readJson(draftFile(moduleName, 'rules40')) : Promise.resolve(null),
        ]);
        const tool = buildNs5RulesTool(schema, createStrictArtifactTool);
        const humanPrompt = buildNs5RulesHumanPrompt({
            sourcePrompt,
            userLanguage: moduleArtifact.userLanguage,
            journeys,
            entities,
            citedRules,
            gateFeedback: parsed.gateFeedback,
            previousDraft: previous,
        });
        return [promptReady(context, parentStep, hookSequential, args || String(step.prompt || ''), prompt, humanPrompt, tool)];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
export async function afterNs5RulesPromptStep(agent, context, parentStep, step, hookSequential) {
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, step.prompt);
        moduleName = parsed.moduleName;
        const mutationParent = findMutableParent(context, parentStep);
        const payload = unwrapArtifactPayload(step.interaction?.payload?.[0]);
        if (!isRecord(payload)) {
            const failure = readPromptFailure(step, 'rules40 returned no usable rules artifact.');
            if (parsed.transportAttempt < MAX_TRANSPORT_RETRIES) {
                return [
                    addStep(context, mutationParent, createNs5RetryStep('rules40', moduleName, 'transport', parsed.transportAttempt + 1)),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `rules40 transport retry ${parsed.transportAttempt + 1} scheduled: ${failure}`),
                ];
            }
            throw new Error(failure);
        }
        // ns5_56: the ids ontology30 cited are read BEFORE the normalize — an id this step received
        // cited is the citator's, so a payload that only changed its case adopts the cited spelling.
        let pipeline = await requirePipeline(moduleName);
        const { rules, duplicateRuleIds, normalizations } = normalizeNs5RulesPayload(payload, pipeline.steps.ontology30?.citedRules || []);
        pipeline = await writeStepState(pipeline, {
            status: 'running',
            updatedAt: new Date().toISOString(),
        });
        const draftPath = await writeJson(draftFile(moduleName, 'rules40'), { rules });
        const gate = validateNs5Rules(rules, { moduleName, duplicateRuleIds });
        if (!gate.ok) {
            const feedback = formatNs5RulesGate(gate.issues);
            if (parsed.repairAttempt < MAX_REPAIRS) {
                return [
                    addStep(context, mutationParent, createNs5RetryStep('rules40', moduleName, 'repair', parsed.repairAttempt + 1, { gateFeedback: feedback })),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `rules40 gate scheduled repair ${parsed.repairAttempt + 1}.`),
                ];
            }
            await writeStepState(pipeline, {
                status: 'failed',
                updatedAt: new Date().toISOString(),
                error: feedback,
                artifactPaths: [draftPath],
            });
            throw new Error(feedback);
        }
        const { artifactPath, compile } = await persistArtifacts(moduleName, rules, pipeline, normalizations);
        if (compile.status === 'errors') {
            const feedback = formatNs5CompileFeedback(compile);
            if (parsed.repairAttempt < MAX_REPAIRS) {
                return [
                    addStep(context, mutationParent, createNs5RetryStep('rules40', moduleName, 'repair', parsed.repairAttempt + 1, { gateFeedback: feedback })),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `rules40 compile scheduled repair ${parsed.repairAttempt + 1}.`),
                ];
            }
            throw new Error(feedback);
        }
        return [
            doneAnchor(context, mutationParent, moduleName, [artifactPath]),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `rules40 approved: ${artifactPath}`),
        ];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
async function persistArtifacts(moduleName, rules, pipeline, normalizations) {
    const artifact = buildNs5RulesArtifactV2(moduleName, rules);
    const artifactPath = await writeDefs(rulesFile(moduleName), `${moduleName}Rules`, artifact, 'Ns5RulesArtifactV2');
    await writeJson(draftFile(moduleName, 'rules40'), artifact);
    // p4_20: the compiler is the last gate; errors go back to this step's repair, never approved.
    const compile = await compileNs5Defs([rulesFile(moduleName)]);
    await writeStepState(pipeline, {
        status: compile.status === 'errors' ? 'running' : 'approved',
        updatedAt: new Date().toISOString(),
        artifactPaths: [artifactPath],
        compile,
        ...(normalizations.length ? { normalizations: [...normalizations] } : {}),
        ...(pipeline.invocation.fast ? { autoReason: 'fast' } : {}),
    });
    return { artifactPath, compile };
}
async function readModule(moduleName) {
    if (!moduleName)
        throw new Error('rules40 needs a moduleName.');
    const artifact = await readDefsJson(moduleFile(moduleName));
    if (!artifact)
        throw new Error(`module.defs.ts is missing for ${moduleName}; module10 must run first.`);
    const pipeline = await readPipeline(moduleName);
    if (pipeline?.steps.ontology30?.status !== 'approved') {
        throw new Error(`ontology30 must be approved before rules40 (${moduleName}).`);
    }
    return artifact;
}
async function readJourneys(moduleName) {
    const index = await readDefsJson(journeyIndexFile(moduleName));
    if (!index)
        throw new Error(`journeys/index.defs.ts is missing for ${moduleName}; journeys20 must run first.`);
    const journeys = [];
    for (const entry of index.journeys) {
        const artifact = await readDefsJson(journeyFile(moduleName, entry.journeyId));
        if (artifact)
            journeys.push(artifact);
    }
    return journeys;
}
async function readEntities(moduleName) {
    const index = await readDefsJson(ontologyIndexFile(moduleName));
    if (!index)
        throw new Error(`ontology/index.defs.ts is missing for ${moduleName}; ontology30 must run first.`);
    const entities = [];
    for (const entityId of ns5OntologyEntityIds(index)) {
        const artifact = await readDefsJson(ontologyEntityFile(moduleName, entityId));
        if (!artifact)
            throw new Error(`ontology/${entityId}.defs.ts is missing for ${moduleName}.`);
        entities.push(artifact);
    }
    return ns5OntologyEntityViews(entities);
}
async function requirePipeline(moduleName) {
    const pipeline = await readPipeline(moduleName);
    if (!pipeline)
        throw new Error(`pipeline.json is missing for ${moduleName}.`);
    return pipeline;
}
async function writeStepState(pipeline, next) {
    const updated = markNs5Step(pipeline, 'rules40', next);
    await writePipeline(updated);
    return updated;
}
async function recordFailure(moduleName, error) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readPipeline(moduleName);
        if (!pipeline)
            return;
        await writePipeline(markNs5Step(pipeline, 'rules40', {
            status: 'failed',
            updatedAt: new Date().toISOString(),
            error,
        }));
    }
    catch { /* task trace remains the fallback */ }
}
async function readSourcePrompt(context, moduleName, moduleArtifact) {
    if (moduleName) {
        const pipeline = await readPipeline(moduleName);
        if (pipeline?.sourcePrompt)
            return pipeline.sourcePrompt;
    }
    return moduleArtifact.sourcePrompt || memoryString(context, 'sourcePrompt');
}
function resolveArgs(context, value) {
    const root = parseRecord(value);
    const moduleName = text(root.moduleName) || memoryString(context, 'moduleName');
    return {
        planId: text(root.planId) || 'rules40',
        moduleName,
        repairAttempt: integer(root.repairAttempt),
        transportAttempt: integer(root.transportAttempt),
        gateFeedback: text(root.gateFeedback),
    };
}
function formatJourneys(journeys) {
    if (!journeys.length)
        return '(none)';
    return journeys.map(journey => [
        `### ${journey.journeyId} (${journey.business.actorRef})`,
        journey.business.title,
        journey.business.goal,
        ...journey.business.steps.map(step => {
            const affects = step.affects?.length ? ` affects=${step.affects.join(',')}` : '';
            return `- ${step.stepId} ${step.kind} ${step.entity}${affects}: ${step.description}`;
        }),
    ].join('\n')).join('\n\n');
}
function formatOntology(views) {
    if (!views.length)
        return '(none)';
    return views.map(view => {
        const entity = view.source;
        const transitions = view.transitions.map(transition => {
            const by = Array.isArray(transition.by) ? transition.by.join(',') : transition.by;
            return `- ${view.entityId}.${transition.transitionId} ${transition.from.join('|')} -> ${transition.to} by=${by}: ${transition.description}`;
        });
        // ns5_43 T2: a v3 entity has no flat `fields` — its data is the platform record, printed as paths.
        if (isNs5OntologyV3Entity(entity)) {
            const lines = ns5OntologyV3FieldLines(entity);
            return [
                `### ${view.entityId} (${view.kind})`,
                view.description,
                'Fields:',
                ...(lines.length ? lines : ['- (none)']),
                ...(transitions.length ? ['Transitions:', ...transitions] : ['Transitions:', '- (none)']),
            ].join('\n');
        }
        const fields = entity.fields.map(field => `- ${entity.entityId}.${field.fieldId} (${field.type}${field.required ? ', required' : ''}): ${field.description}`);
        if (entity.storage?.idField && !entity.fields.some(field => field.fieldId === entity.storage.idField)) {
            fields.unshift(`- ${entity.entityId}.${entity.storage.idField} (identity)`);
        }
        const details = entity.details
            ? Object.entries(entity.details).map(([name, description]) => `- ${entity.entityId}.details.${name}: ${description}`)
            : [];
        return [
            `### ${entity.entityId} (${entity.kind})`,
            entity.description,
            'Fields:',
            ...(fields.length ? fields : ['- (none)']),
            ...(details.length ? ['Details:', ...details] : []),
            ...(transitions.length ? ['Transitions:', ...transitions] : ['Transitions:', '- (none)']),
        ].join('\n');
    }).join('\n\n');
}
function promptReady(context, parentStep, hookSequential, args, systemPrompt, humanPrompt, tool) {
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt,
        humanPrompt,
        tools: [tool],
        toolChoice: { type: 'function', function: { name: tool.function.name } },
    };
}
function doneAnchor(context, parentStep, moduleName, artifactPaths) {
    return addStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Rules done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({ moduleName, artifactPaths, completedStep: 'rules40', nextStep: 'integration70' }),
        planning: { planId: 'rules40-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
function findMutableParent(context, parentStep) {
    const all = getAllSteps(context.task?.iaCompressed?.nextSteps);
    const current = all.find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current))
        return current;
    const owner = all.find(candidate => isOpenAgent(candidate)
        && (candidate.nextSteps?.some(child => child.stepId === parentStep.stepId)
            || candidate.interaction?.payload?.some(child => child.stepId === parentStep.stepId)));
    if (isOpenAgent(owner))
        return owner;
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    return root?.type === 'agent' ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function readPromptFailure(step, fallback) {
    const payload = step.interaction?.payload?.[0];
    const recordValue = isRecord(payload) ? payload : parseRecord(payload);
    if (typeof recordValue.result === 'string' && recordValue.result.trim())
        return recordValue.result.trim();
    return fallback;
}
function parseRecord(value) {
    const parsed = parseMaybeJson(value);
    return isRecord(parsed) ? parsed : {};
}
function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(clean);
    }
    catch {
        return value;
    }
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function integer(value) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : 0;
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
NS5_STEP_HOOKS.rules40 = {
    beforePromptStep: beforeNs5RulesPromptStep,
    afterPromptStep: afterNs5RulesPromptStep,
};
