/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/rules40/gate.ts" enhancement="_blank"/>
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
/** The catalog in the artifact form: `ruleId` to the one business sentence. */
export function validateNs5Rules(rules, context = {}) {
    const issues = [];
    for (const [ruleId, description] of Object.entries(rules)) {
        const base = `rules.${ruleId}`;
        if (!MEMBER_ID.test(ruleId)) {
            error(issues, 'NS5_RULES_ID', 'ruleId must be lowerCamel.', `${base}.ruleId`);
        }
        if (!description.trim()) {
            error(issues, 'NS5_RULES_DESCRIPTION', 'Business description is required.', `${base}.description`);
        }
    }
    for (const ruleId of context.duplicateRuleIds || []) {
        error(issues, 'NS5_RULES_ID_DUPLICATE', `Duplicate ruleId ${ruleId}.`, `rules.${ruleId}.ruleId`);
    }
    return { ok: !issues.some(issue => issue.severity === 'error'), issues };
}
export function formatNs5RulesGate(issues) {
    return issues
        .filter(issue => issue.severity === 'error')
        .map(issue => {
        const where = issue.path ? ` ${issue.path}` : '';
        return `${issue.code}${where}: ${issue.message}`;
    })
        .join('\n');
}
function error(issues, code, message, path) {
    issues.push({ severity: 'error', code, message, ...(path ? { path } : {}) });
}
