/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/rules40/gate.ts" enhancement="_blank"/>
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
export function validateNs5Rules(rules, _context = {}) {
    const issues = [];
    const ruleIds = new Set();
    rules.forEach((rule, index) => {
        const base = `rules[${index}]`;
        if (!MEMBER_ID.test(rule.ruleId)) {
            error(issues, 'NS5_RULES_ID', 'ruleId must be lowerCamel.', `${base}.ruleId`);
        }
        if (rule.ruleId && ruleIds.has(rule.ruleId)) {
            error(issues, 'NS5_RULES_ID_DUPLICATE', `Duplicate ruleId ${rule.ruleId}.`, `${base}.ruleId`);
        }
        if (rule.ruleId)
            ruleIds.add(rule.ruleId);
        if (!rule.description.trim()) {
            error(issues, 'NS5_RULES_DESCRIPTION', 'Business description is required.', `${base}.description`);
        }
    });
    return { ok: !issues.some(issue => issue.severity === 'error'), issues };
}
export function formatNs5RulesGate(issues) {
    return issues
        .filter(issue => issue.severity === 'error')
        .map(issue => {
        const where = issue.path ? ` ${issue.path}` : '';
        return `${issue.code}${where}: ${issue.message}`;
    })
        .join('\n');
}
function error(issues, code, message, path) {
    issues.push({ severity: 'error', code, message, ...(path ? { path } : {}) });
}
