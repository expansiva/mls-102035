/// <mls fileReference="_102047_/l4/inscricaoEvento/journeys/index.defs.ts" enhancement="_blank"/>
export const inscricaoEventoJourneyIndex = {
    "schemaVersion": "2026-09-10-ns5-journey-v1",
    "moduleName": "inscricaoEvento",
    "journeys": [
        {
            "journeyId": "cadastrarEpublicarEvento",
            "actorRef": "organizador",
            "title": "Cadastrar e publicar evento"
        },
        {
            "journeyId": "realizarInscricaoPublica",
            "actorRef": "publico",
            "title": "Realizar inscrição em evento"
        },
        {
            "journeyId": "cancelarInscricao",
            "actorRef": "publico",
            "title": "Cancelar inscrição"
        },
        {
            "journeyId": "acompanharInscricoesDoEvento",
            "actorRef": "organizador",
            "title": "Acompanhar inscritos e exportar lista"
        }
    ],
    "systemDecisions": []
};
export default inscricaoEventoJourneyIndex;
