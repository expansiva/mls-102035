/// <mls fileReference="_102047_/l4/hiringPipeline/journeys/index.defs.ts" enhancement="_blank"/>
export const hiringPipelineJourneyIndex = {
    "schemaVersion": "2026-09-10-ns5-journey-v1",
    "moduleName": "hiringPipeline",
    "journeys": [
        {
            "journeyId": "openJobPosition",
            "actorRef": "recruiter",
            "title": "Open a job position"
        },
        {
            "journeyId": "registerCandidate",
            "actorRef": "recruiter",
            "title": "Register a candidate"
        },
        {
            "journeyId": "startApplicationScreening",
            "actorRef": "recruiter",
            "title": "Start candidate screening"
        },
        {
            "journeyId": "advanceApplicationToInterview",
            "actorRef": "recruiter",
            "title": "Advance an application to interview"
        },
        {
            "journeyId": "issueOffer",
            "actorRef": "hiringManager",
            "title": "Decide and issue an offer"
        },
        {
            "journeyId": "hireCandidate",
            "actorRef": "hiringManager",
            "title": "Decide and record a hire"
        },
        {
            "journeyId": "rejectApplication",
            "actorRef": "recruiter",
            "title": "Reject an application"
        }
    ],
    "systemDecisions": []
};
export default hiringPipelineJourneyIndex;
