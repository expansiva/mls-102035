/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/access60/contracts.ts" enhancement="_blank"/>
import { normalizeModuleName } from '/_102035_/l2/solution/fs.js';
import { resolvableFieldIds } from '/_102035_/l2/solution/lib.js';
import { NS5_ACCESS_SCHEMA_VERSION, } from '/_102035_/l2/solution/types.js';
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
const ENTITY_ID = /^[A-Z][A-Za-z0-9]*$/;
/**
 * A disclosure reference: the entity root (`Consulta`) or any path under it — one segment on a v2 module
 * (`Consulta.status`, `Comanda.details.total`), any depth on a v3 record (`Paciente.details.person.birthDate`).
 * ns5_40 T2 widened this; v2 refs match exactly as before.
 */
const FIELD_REF = /^[A-Z][A-Za-z0-9]*(?:\.[a-z][A-Za-z0-9]*)*$/;
export const NS5_ACCESS_MAX_ANCHOR_HOPS = 6;
export const NS5_ACCESS_SCOPE_MODES = ['own', 'assigned', 'related', 'public', 'organization', 'custom'];
export const NS5_ACCESS_DISCLOSURE_MODES = ['fullRecord', 'fieldsOnly', 'summaryOnly', 'aggregateOnly'];
export const NS5_ACCESS_PERSON_SCOPE_MODES = ['own', 'assigned', 'related'];
export const NS5_ACCESS_LIMITED_DISCLOSURE_MODES = ['fieldsOnly', 'summaryOnly'];
export function buildNs5AccessTool(schema, createTool) {
    return createTool('submitNs5Access', 'Submit grants by actorRef with title and description. Do not emit actors, profiles, authorities, hops, landing or realization. Disclosure names Entity.field; own/assigned/related name the person anchorEntity.', schema);
}
export function normalizeNs5AccessPayload(value) {
    const root = record(value);
    return {
        grants: list(root.grants).map(normalizeGrant).filter(grant => grant.grantId || grant.actorRef),
    };
}
/**
 * Post-LLM form cleanup: fieldsOnly with no real restriction becomes fullRecord;
 * anchorEntity is dropped unless the scope is own/assigned/related.
 */
export function applyNs5AccessFormNormalizations(grants, entities) {
    const entityById = new Map(entities.map(entity => [entity.entityId, entity]));
    const normalizations = [];
    const next = grants.map(grant => {
        let current = {
            ...grant,
            dataScope: { ...grant.dataScope },
            disclosure: {
                ...grant.disclosure,
                ...(grant.disclosure.allowedFields ? { allowedFields: [...grant.disclosure.allowedFields] } : {}),
                ...(grant.disclosure.deniedFields ? { deniedFields: [...grant.disclosure.deniedFields] } : {}),
            },
        };
        const allowed = current.disclosure.allowedFields || [];
        const denied = current.disclosure.deniedFields || [];
        const total = grantResolvableFieldRefs(current, entityById);
        if (current.disclosure.mode === 'fieldsOnly'
            && coversAllResolvable(allowed, total)
            && denied.length === 0) {
            current = {
                ...current,
                disclosure: { mode: 'fullRecord', description: current.disclosure.description },
            };
            normalizations.push({
                kind: 'disclosureFullRecord',
                grantId: current.grantId,
                detail: 'fieldsOnly allowedFields covered every resolvable field; mode is fullRecord.',
            });
        }
        if (current.dataScope.anchorEntity && !isPersonScopeMode(current.dataScope.mode)) {
            current = {
                ...current,
                dataScope: { mode: current.dataScope.mode, description: current.dataScope.description },
            };
            normalizations.push({
                kind: 'dropAnchorEntity',
                grantId: current.grantId,
                detail: `anchorEntity removed; ${current.dataScope.mode} is not own/assigned/related.`,
            });
        }
        return current;
    });
    return { grants: next, normalizations };
}
export function grantResolvableFieldRefs(grant, entityById) {
    const refs = [];
    const seen = new Set();
    for (const entityId of grant.entityRefs) {
        const entity = entityById.get(entityId);
        if (!entity)
            continue;
        for (const ref of ns5AccessResolvableFieldRefs(entity)) {
            if (seen.has(ref))
                continue;
            seen.add(ref);
            refs.push(ref);
        }
    }
    return refs;
}
export function disclosureListIsProprio(list, total) {
    return list.length > 0 && !coversAllResolvable(list, total);
}
function coversAllResolvable(list, total) {
    if (!total.length)
        return list.length === 0;
    const have = new Set(list);
    return total.every(ref => have.has(ref));
}
export function buildNs5AccessArtifact(moduleName, actors, grants) {
    return {
        schemaVersion: NS5_ACCESS_SCHEMA_VERSION,
        moduleName,
        actors,
        grants,
    };
}
export function collectNs5AccessRefCatalog(actors, entities, journeys) {
    const entityIds = [];
    const fieldRefs = [];
    const personEntityIds = [];
    for (const entity of entities) {
        if (!entity.entityId)
            continue;
        entityIds.push(entity.entityId);
        if (entity.party === 'person')
            personEntityIds.push(entity.entityId);
        for (const ref of ns5AccessResolvableFieldRefs(entity))
            fieldRefs.push(ref);
    }
    const journeyActorIds = [];
    const seenActors = new Set();
    for (const journey of journeys) {
        const actorRef = journey.business.actorRef;
        if (!actorRef || seenActors.has(actorRef))
            continue;
        seenActors.add(actorRef);
        journeyActorIds.push(actorRef);
    }
    return {
        actorIds: actors.map(actor => actor.actorId).filter(Boolean),
        entityIds,
        fieldRefs,
        personEntityIds,
        journeyActorIds,
    };
}
/**
 * Shortest path of required relationships from `fromEntity` to `anchorEntity`.
 * Empty array when they are the same entity. Null when unreachable.
 * The path is derived for the gate and the backend; it is never stored on the grant.
 */
export function anchorPath(fromEntity, anchorEntity, relationships, maxHops = NS5_ACCESS_MAX_ANCHOR_HOPS) {
    if (!fromEntity || !anchorEntity)
        return null;
    if (fromEntity === anchorEntity)
        return [];
    const edges = requiredEdges(relationships);
    const queue = [
        { entity: fromEntity, hops: [] },
    ];
    const visited = new Set([fromEntity]);
    while (queue.length) {
        const current = queue.shift();
        if (current.hops.length >= maxHops)
            continue;
        const outgoing = edges.get(current.entity);
        if (!outgoing)
            continue;
        for (const hop of outgoing) {
            if (visited.has(hop.toEntity))
                continue;
            const hops = [...current.hops, hop];
            if (hop.toEntity === anchorEntity)
                return hops;
            visited.add(hop.toEntity);
            queue.push({ entity: hop.toEntity, hops });
        }
    }
    return null;
}
export function ns5AccessFieldRefExists(ref, entity) {
    const parsed = splitAccessFieldRef(ref);
    if (!parsed || parsed.entityId !== entity.entityId)
        return false;
    // v3: the enumerated tree is the whole truth, branches and leaves alike.
    if (entity.paths)
        return entity.paths.includes(ref);
    if (parsed.detailsName)
        return Boolean(entity.details && parsed.detailsName in entity.details);
    if (resolvableFieldIds(entity).has(parsed.fieldId))
        return true;
    return Boolean(entity.details && parsed.fieldId in entity.details);
}
export function ns5AccessResolvableFieldRefs(entity) {
    if (entity.paths)
        return [...entity.paths];
    const refs = [];
    const seen = new Set();
    const add = (ref) => {
        if (!ref || seen.has(ref))
            return;
        seen.add(ref);
        refs.push(ref);
    };
    for (const fieldId of resolvableFieldIds(entity))
        add(`${entity.entityId}.${fieldId}`);
    if (entity.details) {
        for (const name of Object.keys(entity.details)) {
            if (!name)
                continue;
            add(`${entity.entityId}.details.${name}`);
        }
    }
    return refs;
}
/** The identity reference of a view: `<Entity>.<idField>`. Empty when the view declares no storage. */
export function ns5AccessIdentityRef(entity) {
    return entity.storage?.idField ? `${entity.entityId}.${entity.storage.idField}` : '';
}
/**
 * `Entity`, `Entity.field`, `Entity.details.name`, `Entity.details.branch.leaf` — split at the first dot.
 * `fieldId` and `detailsName` keep exactly the v2 meaning: a deeper path leaves `detailsName` empty and
 * puts the whole path in `fieldId`, which no v2 `fields` list can contain, so a v2 view still says no.
 */
export function splitAccessFieldRef(ref) {
    if (!isAccessFieldRef(ref))
        return null;
    const dot = ref.indexOf('.');
    const entityId = dot < 0 ? ref : ref.slice(0, dot);
    const path = dot < 0 ? '' : ref.slice(dot + 1);
    const details = /^details\.([a-z][A-Za-z0-9]*)$/.exec(path);
    return {
        entityId,
        path,
        fieldId: details ? details[1] : path,
        detailsName: details ? details[1] : '',
    };
}
export function isAccessFieldRef(ref) {
    return FIELD_REF.test(ref);
}
export function isPersonScopeMode(mode) {
    return NS5_ACCESS_PERSON_SCOPE_MODES.includes(mode);
}
export function isLimitedDisclosureMode(mode) {
    return NS5_ACCESS_LIMITED_DISCLOSURE_MODES.includes(mode);
}
function requiredEdges(relationships) {
    const edges = new Map();
    const add = (fromEntity, toEntity, relationshipId) => {
        if (!fromEntity || !toEntity || fromEntity === toEntity)
            return;
        const hop = { fromEntity, toEntity, relationshipId };
        const listFor = edges.get(fromEntity) || [];
        if (listFor.some(item => item.toEntity === toEntity && item.relationshipId === relationshipId))
            return;
        listFor.push(hop);
        edges.set(fromEntity, listFor);
    };
    for (const relationship of relationships) {
        if (!relationship.required)
            continue;
        add(relationship.fromEntity, relationship.toEntity, relationship.relationshipId);
        add(relationship.toEntity, relationship.fromEntity, relationship.relationshipId);
    }
    return edges;
}
function normalizeGrant(value) {
    const source = record(value);
    const scope = record(source.dataScope);
    const disclosure = record(source.disclosure);
    const dataScope = {
        mode: text(scope.mode),
        description: text(scope.description),
    };
    const anchorEntity = entityId(text(scope.anchorEntity));
    if (anchorEntity)
        dataScope.anchorEntity = anchorEntity;
    const next = {
        grantId: memberId(text(source.grantId) || text(source.id), ''),
        actorRef: memberId(text(source.actorRef) || text(source.profileRef), ''),
        title: text(source.title),
        description: text(source.description),
        entityRefs: unique(strings(source.entityRefs).map(entityId).filter(Boolean)),
        dataScope,
        disclosure: {
            mode: text(disclosure.mode),
            description: text(disclosure.description),
        },
    };
    const allowed = unique(strings(disclosure.allowedFields));
    const denied = unique(strings(disclosure.deniedFields));
    if (allowed.length)
        next.disclosure.allowedFields = allowed;
    if (denied.length)
        next.disclosure.deniedFields = denied;
    return next;
}
function memberId(value, fallback) {
    const id = normalizeModuleName(value || fallback, fallback);
    return MEMBER_ID.test(id) ? id : fallback;
}
function entityId(value) {
    return ENTITY_ID.test(value) ? value : '';
}
function unique(values) {
    const seen = new Set();
    const out = [];
    for (const value of values) {
        if (!value || seen.has(value))
            continue;
        seen.add(value);
        out.push(value);
    }
    return out;
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function list(value) {
    return Array.isArray(value) ? value : [];
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function strings(value) {
    return list(value).map(text).filter(Boolean);
}
