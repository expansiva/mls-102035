/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/access60/contracts.ts" enhancement="_blank"/>
import { normalizeModuleName } from '/_102035_/l2/solution/fs.js';
import { resolvableFieldIds } from '/_102035_/l2/solution/lib.js';
import { NS5_ACCESS_SCHEMA_VERSION, } from '/_102035_/l2/solution/types.js';
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
const ENTITY_ID = /^[A-Z][A-Za-z0-9]*$/;
const FIELD_REF = /^[A-Z][A-Za-z0-9]*\.(?:details\.)?[a-z][A-Za-z0-9]*$/;
export const NS5_ACCESS_MAX_ANCHOR_HOPS = 6;
export const NS5_ACCESS_PROFILE_KINDS = ['internal', 'external', 'anonymous'];
export const NS5_ACCESS_SCOPE_MODES = ['own', 'assigned', 'related', 'public', 'organization', 'custom'];
export const NS5_ACCESS_DISCLOSURE_MODES = ['fullRecord', 'fieldsOnly', 'summaryOnly', 'aggregateOnly'];
export const NS5_ACCESS_PERSON_SCOPE_MODES = ['own', 'assigned', 'related'];
export const NS5_ACCESS_LIMITED_DISCLOSURE_MODES = ['fieldsOnly', 'summaryOnly'];
export function buildNs5AccessTool(schema, createTool) {
    return createTool('submitNs5Access', 'Submit profiles, authorities and grants. Disclosure names Entity.field; own/assigned/related name the person anchorEntity. Do not emit hops, landing or realization.', schema);
}
export function normalizeNs5AccessPayload(value) {
    const root = record(value);
    return {
        profiles: list(root.profiles).map(normalizeProfile).filter(profile => profile.profileId || profile.kind),
        authorities: list(root.authorities).map(normalizeAuthority).filter(item => item.authorityId || item.title),
        grants: list(root.grants).map(normalizeGrant).filter(grant => grant.grantId || grant.profileRef),
    };
}
/**
 * Post-LLM form cleanup: fieldsOnly with no real restriction becomes fullRecord;
 * anchorEntity is dropped unless the scope is own/assigned/related.
 */
export function applyNs5AccessFormNormalizations(grants, entities) {
    const entityById = new Map(entities.map(entity => [entity.entityId, entity]));
    const normalizations = [];
    const next = grants.map(grant => {
        let current = {
            ...grant,
            dataScope: { ...grant.dataScope },
            disclosure: {
                ...grant.disclosure,
                ...(grant.disclosure.allowedFields ? { allowedFields: [...grant.disclosure.allowedFields] } : {}),
                ...(grant.disclosure.deniedFields ? { deniedFields: [...grant.disclosure.deniedFields] } : {}),
            },
        };
        const allowed = current.disclosure.allowedFields || [];
        const denied = current.disclosure.deniedFields || [];
        const total = grantResolvableFieldRefs(current, entityById);
        if (current.disclosure.mode === 'fieldsOnly'
            && coversAllResolvable(allowed, total)
            && denied.length === 0) {
            current = {
                ...current,
                disclosure: { mode: 'fullRecord', description: current.disclosure.description },
            };
            normalizations.push({
                kind: 'disclosureFullRecord',
                grantId: current.grantId,
                detail: 'fieldsOnly allowedFields covered every resolvable field; mode is fullRecord.',
            });
        }
        if (current.dataScope.anchorEntity && !isPersonScopeMode(current.dataScope.mode)) {
            current = {
                ...current,
                dataScope: { mode: current.dataScope.mode, description: current.dataScope.description },
            };
            normalizations.push({
                kind: 'dropAnchorEntity',
                grantId: current.grantId,
                detail: `anchorEntity removed; ${current.dataScope.mode} is not own/assigned/related.`,
            });
        }
        return current;
    });
    return { grants: next, normalizations };
}
export function grantResolvableFieldRefs(grant, entityById) {
    const refs = [];
    const seen = new Set();
    for (const entityId of grant.entityRefs) {
        const entity = entityById.get(entityId);
        if (!entity)
            continue;
        for (const ref of ns5AccessResolvableFieldRefs(entity)) {
            if (seen.has(ref))
                continue;
            seen.add(ref);
            refs.push(ref);
        }
    }
    return refs;
}
export function disclosureListIsProprio(list, total) {
    return list.length > 0 && !coversAllResolvable(list, total);
}
function coversAllResolvable(list, total) {
    if (!total.length)
        return list.length === 0;
    const have = new Set(list);
    return total.every(ref => have.has(ref));
}
export function buildNs5AccessArtifact(moduleName, profiles, authorities, grants) {
    return {
        schemaVersion: NS5_ACCESS_SCHEMA_VERSION,
        moduleName,
        profiles,
        authorities,
        grants,
    };
}
export function collectNs5AccessRefCatalog(actors, entities, journeys) {
    const entityIds = [];
    const fieldRefs = [];
    const personEntityIds = [];
    for (const entity of entities) {
        if (!entity.entityId)
            continue;
        entityIds.push(entity.entityId);
        if (entity.party === 'person')
            personEntityIds.push(entity.entityId);
        for (const ref of ns5AccessResolvableFieldRefs(entity))
            fieldRefs.push(ref);
    }
    const journeyActorIds = [];
    const seenActors = new Set();
    for (const journey of journeys) {
        const actorRef = journey.business.actorRef;
        if (!actorRef || seenActors.has(actorRef))
            continue;
        seenActors.add(actorRef);
        journeyActorIds.push(actorRef);
    }
    return {
        actorIds: actors.map(actor => actor.actorId).filter(Boolean),
        entityIds,
        fieldRefs,
        personEntityIds,
        journeyActorIds,
    };
}
/**
 * Shortest path of required relationships from `fromEntity` to `anchorEntity`.
 * Empty array when they are the same entity. Null when unreachable.
 * The path is derived for the gate and the backend; it is never stored on the grant.
 */
export function anchorPath(fromEntity, anchorEntity, relationships, maxHops = NS5_ACCESS_MAX_ANCHOR_HOPS) {
    if (!fromEntity || !anchorEntity)
        return null;
    if (fromEntity === anchorEntity)
        return [];
    const edges = requiredEdges(relationships);
    const queue = [
        { entity: fromEntity, hops: [] },
    ];
    const visited = new Set([fromEntity]);
    while (queue.length) {
        const current = queue.shift();
        if (current.hops.length >= maxHops)
            continue;
        const outgoing = edges.get(current.entity);
        if (!outgoing)
            continue;
        for (const hop of outgoing) {
            if (visited.has(hop.toEntity))
                continue;
            const hops = [...current.hops, hop];
            if (hop.toEntity === anchorEntity)
                return hops;
            visited.add(hop.toEntity);
            queue.push({ entity: hop.toEntity, hops });
        }
    }
    return null;
}
export function ns5AccessFieldRefExists(ref, entity) {
    const parsed = splitAccessFieldRef(ref);
    if (!parsed || parsed.entityId !== entity.entityId)
        return false;
    if (parsed.detailsName)
        return Boolean(entity.details && parsed.detailsName in entity.details);
    if (resolvableFieldIds(entity).has(parsed.fieldId))
        return true;
    return Boolean(entity.details && parsed.fieldId in entity.details);
}
export function ns5AccessResolvableFieldRefs(entity) {
    const refs = [];
    const seen = new Set();
    const add = (ref) => {
        if (!ref || seen.has(ref))
            return;
        seen.add(ref);
        refs.push(ref);
    };
    for (const fieldId of resolvableFieldIds(entity))
        add(`${entity.entityId}.${fieldId}`);
    if (entity.details) {
        for (const name of Object.keys(entity.details)) {
            if (!name)
                continue;
            add(`${entity.entityId}.details.${name}`);
        }
    }
    return refs;
}
export function splitAccessFieldRef(ref) {
    const details = /^([A-Z][A-Za-z0-9]*)\.details\.([a-z][A-Za-z0-9]*)$/.exec(ref);
    if (details)
        return { entityId: details[1], fieldId: details[2], detailsName: details[2] };
    const field = /^([A-Z][A-Za-z0-9]*)\.([a-z][A-Za-z0-9]*)$/.exec(ref);
    if (field)
        return { entityId: field[1], fieldId: field[2], detailsName: '' };
    return null;
}
export function isAccessFieldRef(ref) {
    return FIELD_REF.test(ref);
}
export function isPersonScopeMode(mode) {
    return NS5_ACCESS_PERSON_SCOPE_MODES.includes(mode);
}
export function isLimitedDisclosureMode(mode) {
    return NS5_ACCESS_LIMITED_DISCLOSURE_MODES.includes(mode);
}
function requiredEdges(relationships) {
    const edges = new Map();
    const add = (fromEntity, toEntity, relationshipId) => {
        if (!fromEntity || !toEntity || fromEntity === toEntity)
            return;
        const hop = { fromEntity, toEntity, relationshipId };
        const listFor = edges.get(fromEntity) || [];
        if (listFor.some(item => item.toEntity === toEntity && item.relationshipId === relationshipId))
            return;
        listFor.push(hop);
        edges.set(fromEntity, listFor);
    };
    for (const relationship of relationships) {
        if (!relationship.required)
            continue;
        add(relationship.fromEntity, relationship.toEntity, relationship.relationshipId);
        add(relationship.toEntity, relationship.fromEntity, relationship.relationshipId);
    }
    return edges;
}
function normalizeProfile(value) {
    const source = record(value);
    const kind = text(source.kind);
    return {
        profileId: memberId(text(source.profileId) || text(source.id), ''),
        actorRefs: unique(strings(source.actorRefs).map(item => memberId(item, '')).filter(Boolean)),
        kind: kind,
    };
}
function normalizeAuthority(value) {
    const source = record(value);
    return {
        authorityId: memberId(text(source.authorityId) || text(source.authorityRef) || text(source.id), ''),
        title: text(source.title),
        description: text(source.description),
    };
}
function normalizeGrant(value) {
    const source = record(value);
    const scope = record(source.dataScope);
    const disclosure = record(source.disclosure);
    const dataScope = {
        mode: text(scope.mode),
        description: text(scope.description),
    };
    const anchorEntity = entityId(text(scope.anchorEntity));
    if (anchorEntity)
        dataScope.anchorEntity = anchorEntity;
    const next = {
        grantId: memberId(text(source.grantId) || text(source.id), ''),
        profileRef: memberId(text(source.profileRef), ''),
        authorityRef: memberId(text(source.authorityRef) || text(source.authorityId), ''),
        entityRefs: unique(strings(source.entityRefs).map(entityId).filter(Boolean)),
        dataScope,
        disclosure: {
            mode: text(disclosure.mode),
            description: text(disclosure.description),
        },
    };
    const allowed = unique(strings(disclosure.allowedFields));
    const denied = unique(strings(disclosure.deniedFields));
    if (allowed.length)
        next.disclosure.allowedFields = allowed;
    if (denied.length)
        next.disclosure.deniedFields = denied;
    return next;
}
function memberId(value, fallback) {
    const id = normalizeModuleName(value || fallback, fallback);
    return MEMBER_ID.test(id) ? id : fallback;
}
function entityId(value) {
    return ENTITY_ID.test(value) ? value : '';
}
function unique(values) {
    const seen = new Set();
    const out = [];
    for (const value of values) {
        if (!value || seen.has(value))
            continue;
        seen.add(value);
        out.push(value);
    }
    return out;
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function list(value) {
    return Array.isArray(value) ? value : [];
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function strings(value) {
    return list(value).map(text).filter(Boolean);
}
