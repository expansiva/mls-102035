/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/access60/agentNs5Access.ts" enhancement="_blank"/>
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { readNs5Actors } from '/_102035_/l2/agentNewSolution5/helpers/ns5Actors.js';
import { createNs5RetryStep, markNs5Step, } from '/_102035_/l2/agentNewSolution5/helpers/ns5Core.js';
import { NS5_STEP_HOOKS, drainWaitingSiblings, updateStatus, } from '/_102035_/l2/agentNewSolution5/helpers/ns5Dispatch.js';
import { compileNs5Defs, formatNs5CompileFeedback } from '/_102035_/l2/agentNewSolution5/helpers/ns5Compile.js';
import { composeNs5SystemPrompt, readNs5MdmSkill } from '/_102035_/l2/agentNewSolution5/helpers/ns5Skills.js';
import { accessFile, draftFile, journeyFile, journeyIndexFile, moduleFile, ontologyEntityFile, ontologyIndexFile, readAgentJson, readAgentText, readDefsJson, readJson, readPipeline, writeDefs, writeJson, writePipeline, } from '/_102035_/l2/solution/fs.js';
import { createStrictArtifactTool, unwrapArtifactPayload } from '/_102035_/l2/solution/lib.js';
import { isNs5OntologyV3Entity, ns5OntologyEdges, ns5OntologyEntityIds, ns5OntologyEntityViews, ns5OntologyV3FieldLines, } from '/_102035_/l2/solution/ontologyView.js';
import { applyNs5AccessFormNormalizations, buildNs5AccessArtifact, collectNs5AccessRefCatalog, mergeNs5AccessActors, normalizeNs5AccessPayload, } from '/_102035_/l2/solution/gates/access60/contracts.js';
import { formatNs5AccessGate, validateNs5Access, } from '/_102035_/l2/solution/gates/access60/gate.js';
export function buildNs5AccessTool(schema, createTool) {
    return createTool('submitNs5Access', 'Submit grants by actorRef with title and description, plus actorPersons (one item per given actor; personEntity is the role entity they are, or ""). Do not emit actors, profiles, authorities, hops, landing or realization. Disclosure names Entity.field. own/assigned anchor on that personEntity; related anchors on the other person.', schema);
}
const MAX_REPAIRS = 2;
const MAX_TRANSPORT_RETRIES = 1;
export function buildNs5AccessHumanPrompt(input) {
    const catalog = collectNs5AccessRefCatalog(input.actors, input.entities, input.journeys);
    return [
        '## Source request',
        input.sourcePrompt,
        '',
        `## userLanguage`,
        input.userLanguage,
        '',
        '## Actors',
        formatActors(input.actors),
        '',
        '## Journeys (business)',
        formatJourneys(input.journeys),
        '',
        '## Ontology (entities, fields, party)',
        formatOntology(input.entities),
        '',
        '## Required relationships (anchor walk)',
        formatRelationships(input.relationships),
        '',
        '## Valid reference ids',
        JSON.stringify({
            actorIds: catalog.actorIds,
            entityIds: catalog.entityIds,
            fieldRefs: catalog.fieldRefs,
            personEntityIds: catalog.personEntityIds,
            journeyActorIds: catalog.journeyActorIds,
        }, null, 2),
        input.gateFeedback ? `## Deterministic repair required\n${input.gateFeedback}` : '',
        input.previousDraft ? `## Current draft; keep unrelated fields\n${JSON.stringify(input.previousDraft, null, 2)}` : '',
    ].filter(Boolean).join('\n');
}
export async function beforeNs5AccessPromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error('[agentNewSolution5:access60] task invalid');
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        const moduleArtifact = await readModule(moduleName);
        const [journeys, ontology, actors] = await Promise.all([
            readJourneys(moduleName),
            readOntology(moduleName),
            readNs5Actors(moduleName),
        ]);
        const sourcePrompt = await readSourcePrompt(context, moduleName, moduleArtifact);
        const [mdm, prompt, schema, previous] = await Promise.all([
            readNs5MdmSkill(),
            readAgentText('steps/access60', 'prompt', '.md'),
            readAgentJson('schemas', 'access.schema', '.json'),
            moduleName ? readJson(draftFile(moduleName, 'access60')) : Promise.resolve(null),
        ]);
        const tool = buildNs5AccessTool(schema, createStrictArtifactTool);
        const humanPrompt = buildNs5AccessHumanPrompt({
            sourcePrompt,
            userLanguage: moduleArtifact.userLanguage,
            actors,
            journeys,
            entities: ontology.entities,
            relationships: ontology.relationships,
            gateFeedback: parsed.gateFeedback,
            previousDraft: previous,
        });
        return [promptReady(context, parentStep, hookSequential, args || String(step.prompt || ''), composeNs5SystemPrompt(mdm, prompt), humanPrompt, tool)];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
export async function afterNs5AccessPromptStep(agent, context, parentStep, step, hookSequential) {
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, step.prompt);
        moduleName = parsed.moduleName;
        const mutationParent = findMutableParent(context, parentStep);
        const payload = unwrapArtifactPayload(step.interaction?.payload?.[0]);
        if (!isRecord(payload)) {
            const failure = readPromptFailure(step, 'access60 returned no usable access artifact.');
            if (parsed.transportAttempt < MAX_TRANSPORT_RETRIES) {
                return [
                    addStep(context, mutationParent, createNs5RetryStep('access60', moduleName, 'transport', parsed.transportAttempt + 1)),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `access60 transport retry ${parsed.transportAttempt + 1} scheduled: ${failure}`),
                ];
            }
            throw new Error(failure);
        }
        const { grants: rawGrants, actorPersons } = normalizeNs5AccessPayload(payload);
        await readModule(moduleName);
        const [journeys, ontology, pipelineActors] = await Promise.all([
            readJourneys(moduleName),
            readOntology(moduleName),
            readNs5Actors(moduleName),
        ]);
        const merged = mergeNs5AccessActors(pipelineActors, actorPersons);
        const { grants, normalizations: formNormalizations } = applyNs5AccessFormNormalizations(rawGrants, ontology.entities, merged.actors);
        const normalizations = [...merged.normalizations, ...formNormalizations];
        let pipeline = await requirePipeline(moduleName);
        pipeline = await writeStepState(pipeline, {
            status: 'running',
            updatedAt: new Date().toISOString(),
        });
        const draftPath = await writeJson(draftFile(moduleName, 'access60'), { grants, normalizations });
        const gate = validateNs5Access(grants, {
            moduleName,
            actors: merged.actors,
            entities: ontology.entities,
            relationships: ontology.relationships,
            journeys,
        });
        if (!gate.ok) {
            const feedback = formatNs5AccessGate(gate.issues);
            if (parsed.repairAttempt < MAX_REPAIRS) {
                return [
                    addStep(context, mutationParent, createNs5RetryStep('access60', moduleName, 'repair', parsed.repairAttempt + 1, { gateFeedback: feedback })),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `access60 gate scheduled repair ${parsed.repairAttempt + 1}.`),
                ];
            }
            await writeStepState(pipeline, {
                status: 'failed',
                updatedAt: new Date().toISOString(),
                error: feedback,
                artifactPaths: [draftPath],
            });
            throw new Error(feedback);
        }
        const { artifactPath, compile } = await persistArtifacts(moduleName, merged.actors, grants, pipeline, normalizations);
        if (compile.status === 'errors') {
            const feedback = formatNs5CompileFeedback(compile);
            if (parsed.repairAttempt < MAX_REPAIRS) {
                return [
                    addStep(context, mutationParent, createNs5RetryStep('access60', moduleName, 'repair', parsed.repairAttempt + 1, { gateFeedback: feedback })),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `access60 compile scheduled repair ${parsed.repairAttempt + 1}.`),
                ];
            }
            throw new Error(feedback);
        }
        return [
            doneAnchor(context, mutationParent, moduleName, [artifactPath]),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `access60 approved: ${artifactPath}`),
        ];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
async function persistArtifacts(moduleName, actors, grants, pipeline, normalizations = []) {
    const artifact = buildNs5AccessArtifact(moduleName, actors, grants);
    const artifactPath = await writeDefs(accessFile(moduleName), `${moduleName}Access`, artifact, 'Ns5AccessArtifact');
    await writeJson(draftFile(moduleName, 'access60'), {
        ...artifact,
        ...(normalizations.length ? { normalizations } : {}),
    });
    // p4_20: the compiler is the last gate; errors go back to this step's repair, never approved.
    const compile = await compileNs5Defs([accessFile(moduleName)]);
    await writeStepState(pipeline, {
        status: compile.status === 'errors' ? 'running' : 'approved',
        updatedAt: new Date().toISOString(),
        artifactPaths: [artifactPath],
        compile,
        ...(normalizations.length ? { normalizations } : {}),
        ...(pipeline.invocation.fast ? { autoReason: 'fast' } : {}),
    });
    return { artifactPath, compile };
}
async function readModule(moduleName) {
    if (!moduleName)
        throw new Error('access60 needs a moduleName.');
    const artifact = await readDefsJson(moduleFile(moduleName));
    if (!artifact)
        throw new Error(`module.defs.ts is missing for ${moduleName}; module10 must run first.`);
    const pipeline = await readPipeline(moduleName);
    if (pipeline?.steps.ontology30?.status !== 'approved') {
        throw new Error(`ontology30 must be approved before access60 (${moduleName}).`);
    }
    return artifact;
}
async function readJourneys(moduleName) {
    const index = await readDefsJson(journeyIndexFile(moduleName));
    if (!index)
        throw new Error(`journeys/index.defs.ts is missing for ${moduleName}; journeys20 must run first.`);
    const journeys = [];
    for (const entry of index.journeys) {
        const artifact = await readDefsJson(journeyFile(moduleName, entry.journeyId));
        if (artifact)
            journeys.push(artifact);
    }
    return journeys;
}
async function readOntology(moduleName) {
    const index = await readDefsJson(ontologyIndexFile(moduleName));
    if (!index)
        throw new Error(`ontology/index.defs.ts is missing for ${moduleName}; ontology30 must run first.`);
    const entities = [];
    for (const entityId of ns5OntologyEntityIds(index)) {
        const artifact = await readDefsJson(ontologyEntityFile(moduleName, entityId));
        if (!artifact)
            throw new Error(`ontology/${entityId}.defs.ts is missing for ${moduleName}.`);
        entities.push(artifact);
    }
    return { entities: ns5OntologyEntityViews(entities), relationships: ns5OntologyEdges(index) };
}
async function requirePipeline(moduleName) {
    const pipeline = await readPipeline(moduleName);
    if (!pipeline)
        throw new Error(`pipeline.json is missing for ${moduleName}.`);
    return pipeline;
}
async function writeStepState(pipeline, next) {
    const updated = markNs5Step(pipeline, 'access60', next);
    await writePipeline(updated);
    return updated;
}
async function recordFailure(moduleName, error) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readPipeline(moduleName);
        if (!pipeline)
            return;
        await writePipeline(markNs5Step(pipeline, 'access60', {
            status: 'failed',
            updatedAt: new Date().toISOString(),
            error,
        }));
    }
    catch { /* task trace remains the fallback */ }
}
async function readSourcePrompt(context, moduleName, moduleArtifact) {
    if (moduleName) {
        const pipeline = await readPipeline(moduleName);
        if (pipeline?.sourcePrompt)
            return pipeline.sourcePrompt;
    }
    return moduleArtifact.sourcePrompt || memoryString(context, 'sourcePrompt');
}
function resolveArgs(context, value) {
    const root = parseRecord(value);
    const moduleName = text(root.moduleName) || memoryString(context, 'moduleName');
    return {
        planId: text(root.planId) || 'access60',
        moduleName,
        repairAttempt: integer(root.repairAttempt),
        transportAttempt: integer(root.transportAttempt),
        gateFeedback: text(root.gateFeedback),
    };
}
function formatActors(actors) {
    if (!actors.length)
        return '(none)';
    return actors.map(actor => `- ${actor.actorId} (${actor.kind}): ${actor.title} — ${actor.description}`).join('\n');
}
function formatJourneys(journeys) {
    if (!journeys.length)
        return '(none)';
    return journeys.map(journey => [
        `### ${journey.journeyId} (${journey.business.actorRef})`,
        journey.business.title,
        journey.business.goal,
        ...journey.business.steps.map(step => {
            const affects = step.affects?.length ? ` affects=${step.affects.join(',')}` : '';
            return `- ${step.stepId} ${step.kind} ${step.entity}${affects}: ${step.description}`;
        }),
    ].join('\n')).join('\n\n');
}
function formatOntology(views) {
    if (!views.length)
        return '(none)';
    return views.map(view => {
        const entity = view.source;
        // ns5_43 T3: a v3 entity resolves a tree, so the prompt names the paths a grant may disclose.
        if (isNs5OntologyV3Entity(entity)) {
            const lines = ns5OntologyV3FieldLines(entity).map(line => `- ${view.entityId}.${line.slice(2)}`);
            return [
                `### ${view.entityId} (${view.kind}, party=${view.party}${view.writer && view.writer !== 'journey' ? `, writer=${view.writer}` : ''})`,
                view.description,
                'Fields:',
                ...(lines.length ? lines : ['- (none)']),
            ].join('\n');
        }
        const fields = entity.fields.map(field => `- ${entity.entityId}.${field.fieldId} (${field.type}${field.required ? ', required' : ''}): ${field.description}`);
        if (entity.storage?.idField && !entity.fields.some(field => field.fieldId === entity.storage.idField)) {
            fields.unshift(`- ${entity.entityId}.${entity.storage.idField} (identity)`);
        }
        const details = entity.details
            ? Object.entries(entity.details).map(([name, detail]) => `- ${entity.entityId}.details.${name} (${detail.type}): ${detail.description}`)
            : [];
        return [
            `### ${entity.entityId} (${entity.kind}, party=${entity.party}${entity.writer && entity.writer !== 'journey' ? `, writer=${entity.writer}` : ''})`,
            entity.description,
            'Fields:',
            ...(fields.length ? fields : ['- (none)']),
            ...(details.length ? ['Details:', ...details] : []),
        ].join('\n');
    }).join('\n\n');
}
function formatRelationships(relationships) {
    const required = relationships.filter(item => item.required);
    if (!required.length)
        return '(none)';
    return required.map(item => `- ${item.relationshipId}: ${item.fromEntity} -> ${item.toEntity} (${item.type})`).join('\n');
}
function promptReady(context, parentStep, hookSequential, args, systemPrompt, humanPrompt, tool) {
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt,
        humanPrompt,
        tools: [tool],
        toolChoice: { type: 'function', function: { name: tool.function.name } },
    };
}
function doneAnchor(context, parentStep, moduleName, artifactPaths) {
    return addStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Access done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({ moduleName, artifactPaths, completedStep: 'access60', nextStep: 'integration70' }),
        planning: { planId: 'access60-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
function findMutableParent(context, parentStep) {
    const all = getAllSteps(context.task?.iaCompressed?.nextSteps);
    const current = all.find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current))
        return current;
    const owner = all.find(candidate => isOpenAgent(candidate)
        && (candidate.nextSteps?.some(child => child.stepId === parentStep.stepId)
            || candidate.interaction?.payload?.some(child => child.stepId === parentStep.stepId)));
    if (isOpenAgent(owner))
        return owner;
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    return root?.type === 'agent' ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function readPromptFailure(step, fallback) {
    const payload = step.interaction?.payload?.[0];
    const recordValue = isRecord(payload) ? payload : parseRecord(payload);
    if (typeof recordValue.result === 'string' && recordValue.result.trim())
        return recordValue.result.trim();
    return fallback;
}
function parseRecord(value) {
    const parsed = parseMaybeJson(value);
    return isRecord(parsed) ? parsed : {};
}
function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(clean);
    }
    catch {
        return value;
    }
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function integer(value) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : 0;
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
NS5_STEP_HOOKS.access60 = {
    beforePromptStep: beforeNs5AccessPromptStep,
    afterPromptStep: afterNs5AccessPromptStep,
};
