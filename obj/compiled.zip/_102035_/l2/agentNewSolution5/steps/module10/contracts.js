/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/module10/contracts.ts" enhancement="_blank"/>
import { foldNs4Text, normalizeNs4Languages, ns4LanguageMentioned, } from '/_102035_/l2/agentNewSolution/helpers/ns4Core.js';
import { normalizeModuleName } from '/_102035_/l2/solution/fs.js';
import { NS5_MODULE_SCHEMA_VERSION, } from '/_102035_/l2/solution/types.js';
const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
export function buildNs5ModuleTool(schema, createTool) {
    return createTool('submitNs5Module', 'Submit the module artifact: name, actors and languages.', schema);
}
export function normalizeNs5ModuleArtifact(value, options) {
    const root = record(value);
    const sourcePrompt = text(options.sourcePrompt) || text(root.sourcePrompt);
    const userLanguageRaw = normalizeNs4Languages(root.userLanguage || 'en')[0];
    const requested = normalizeNs4Languages(root.productLanguages || userLanguageRaw, userLanguageRaw);
    const i18nWarnings = [];
    const languagesRaw = filterLanguagesByProvenance(requested, userLanguageRaw, sourcePrompt, i18nWarnings);
    const declaredDefault = normalizeNs4Languages(root.defaultLanguage || languagesRaw[0], languagesRaw[0])[0];
    const defaultRaw = languagesRaw.some(language => sameLanguage(language, declaredDefault))
        ? languagesRaw.find(language => sameLanguage(language, declaredDefault)) || languagesRaw[0]
        : languagesRaw[0];
    const { userLanguage, productLanguages, defaultLanguage, normalizations } = canonicalizeNs5Languages(userLanguageRaw, languagesRaw, defaultRaw);
    const proposedName = normalizeModuleName(text(root.moduleName) || options.fixedModuleName || sourcePrompt, 'newModule');
    const moduleName = options.fixedModuleName || proposedName;
    const actors = list(root.actors).map((item, index) => normalizeActor(item, index)).filter(actor => actor.title);
    return {
        artifact: {
            schemaVersion: NS5_MODULE_SCHEMA_VERSION,
            moduleName,
            title: text(root.title) || humanize(moduleName),
            userLanguage,
            productLanguages,
            defaultLanguage,
            sourcePrompt,
        },
        actors,
        i18nWarnings,
        normalizations,
    };
}
/** Platform canonical for Portuguese is BCP-47 with region. `en` is not rewritten to `en-US`. */
function canonicalizeNs5Language(tag) {
    return tag === 'pt' ? 'pt-BR' : tag;
}
function canonicalizeNs5Languages(userLanguage, productLanguages, defaultLanguage) {
    const replaced = [];
    const map = (tag) => {
        const next = canonicalizeNs5Language(tag);
        if (next !== tag)
            replaced.push(`${tag}→${next}`);
        return next;
    };
    const seen = new Set();
    const languages = [];
    for (const tag of productLanguages) {
        const next = map(tag);
        const key = next.toLowerCase();
        if (seen.has(key))
            continue;
        seen.add(key);
        languages.push(next);
    }
    const user = map(userLanguage);
    if (!languages.some(language => sameLanguage(language, user)))
        languages.unshift(user);
    const fallback = languages[0] || user;
    const declared = map(defaultLanguage);
    const normalizedDefault = languages.some(language => sameLanguage(language, declared))
        ? languages.find(language => sameLanguage(language, declared)) || fallback
        : fallback;
    return {
        userLanguage: user,
        productLanguages: languages,
        defaultLanguage: normalizedDefault,
        normalizations: replaced.length
            ? [{ kind: 'ptToPtBR', detail: [...new Set(replaced)].join(', ') }]
            : [],
    };
}
function normalizeActor(value, index) {
    const actor = record(value);
    return {
        actorId: memberId(text(actor.actorId) || text(actor.title), `actor${index + 1}`),
        kind: actor.kind === 'external' || actor.kind === 'system' ? actor.kind : 'internal',
        origin: actor.origin === 'named' ? 'named' : 'inferred',
        title: text(actor.title),
        description: text(actor.description),
    };
}
function filterLanguagesByProvenance(languages, userLanguage, sourcePrompt, warnings) {
    const citedText = foldNs4Text(sourcePrompt);
    const kept = [];
    const discarded = [];
    for (const language of languages) {
        const cited = sameLanguage(language, userLanguage) || ns4LanguageMentioned(language, userLanguage, citedText);
        (cited ? kept : discarded).push(language);
    }
    if (discarded.length) {
        warnings.push(`productLanguages: discarded ${discarded.join(', ')} — languages are a user decision and the request did not cite them; kept ${(kept.length ? kept : [userLanguage]).join(', ')}.`);
    }
    const withUser = kept.length ? kept : normalizeNs4Languages(userLanguage);
    if (!withUser.some(language => sameLanguage(language, userLanguage))) {
        return [userLanguage, ...withUser];
    }
    return withUser;
}
function sameLanguage(a, b) {
    return a.toLowerCase() === b.toLowerCase()
        || a.split('-')[0].toLowerCase() === b.split('-')[0].toLowerCase();
}
function memberId(value, fallback) {
    const id = normalizeModuleName(value || fallback, fallback);
    return MEMBER_ID.test(id) ? id : fallback;
}
function humanize(value) {
    return value.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/^./, item => item.toUpperCase());
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function list(value) {
    return Array.isArray(value) ? value : [];
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
