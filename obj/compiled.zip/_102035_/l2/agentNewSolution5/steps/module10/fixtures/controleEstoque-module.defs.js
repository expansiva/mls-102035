/// <mls fileReference="_102047_/l4/controleEstoque/module.defs.ts" enhancement="_blank"/>
export const controleEstoqueModule = {
    "schemaVersion": "2026-09-10-ns5-module-v2",
    "moduleName": "controleEstoque",
    "title": "Controle de estoque",
    "userLanguage": "pt-BR",
    "productLanguages": [
        "pt-BR"
    ],
    "defaultLanguage": "pt-BR",
    "sourcePrompt": "controle de estoque: produtos, entradas e saídas, saldo atual por produto e aviso quando o saldo ficar abaixo do mínimo. movimentação não pode ser alterada depois de registrada. um perfil: estoquista."
};
export default controleEstoqueModule;
