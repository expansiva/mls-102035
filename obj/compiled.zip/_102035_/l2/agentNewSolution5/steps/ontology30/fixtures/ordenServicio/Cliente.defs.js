/// <mls fileReference="_102047_/l4/ordenServicio/ontology/Cliente.defs.ts" enhancement="_blank"/>
export const ordenServicioEntityCliente = {
    "schemaVersion": "2026-09-11-ns5-ontology-v2",
    "moduleName": "ordenServicio",
    "entityId": "Cliente",
    "title": "Cliente",
    "description": "Persona cliente identificada para registrar sus órdenes de servicio y consultar sus propias órdenes desde el portal.",
    "kind": "mdm",
    "party": "person",
    "mdmSubtype": "Person",
    "displayField": "name",
    "fields": [],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "mdm",
        "scope": "organization",
        "idField": "id",
        "mdmType": "ordenServicio.Cliente"
    }
};
export default ordenServicioEntityCliente;
