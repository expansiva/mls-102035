/// <mls fileReference="_102047_/l4/comandaRestaurante5/ontology/ItemCardapio.defs.ts" enhancement="_blank"/>
export const comandaRestaurante5EntityItemCardapio = {
    "schemaVersion": "2026-09-11-ns5-ontology-v2",
    "moduleName": "comandaRestaurante5",
    "entityId": "ItemCardapio",
    "title": "Item do cardápio",
    "description": "Produto oferecido no cardápio do restaurante que pode ser lançado em uma comanda.",
    "kind": "mdm",
    "party": "none",
    "mdmSubtype": "Product",
    "displayField": "name",
    "fields": [
        {
            "fieldId": "price",
            "title": "Preço",
            "type": "money",
            "required": true,
            "description": "Preço de venda do item no cardápio."
        }
    ],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "mdm",
        "scope": "organization",
        "idField": "id",
        "mdmType": "comandaRestaurante5.ItemCardapio"
    }
};
export default comandaRestaurante5EntityItemCardapio;
