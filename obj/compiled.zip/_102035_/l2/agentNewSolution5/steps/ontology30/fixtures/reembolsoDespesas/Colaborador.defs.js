/// <mls fileReference="_102047_/l4/reembolsoDespesas/ontology/Colaborador.defs.ts" enhancement="_blank"/>
export const reembolsoDespesasEntityColaborador = {
    "schemaVersion": "2026-09-11-ns5-ontology-v2",
    "moduleName": "reembolsoDespesas",
    "entityId": "Colaborador",
    "title": "Colaborador",
    "description": "Pessoa que registra, acompanha e corrige as próprias despesas para reembolso.",
    "kind": "mdm",
    "party": "person",
    "mdmSubtype": "Person",
    "displayField": "name",
    "fields": [],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "mdm",
        "scope": "organization",
        "idField": "colaboradorId",
        "mdmType": "reembolsoDespesas.Colaborador"
    },
    "writer": "crud"
};
export default reembolsoDespesasEntityColaborador;
