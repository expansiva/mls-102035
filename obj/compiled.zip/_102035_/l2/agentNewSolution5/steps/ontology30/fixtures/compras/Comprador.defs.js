/// <mls fileReference="_102047_/l4/compras/ontology/Comprador.defs.ts" enhancement="_blank"/>
export const comprasEntityComprador = {
    "schemaVersion": "2026-09-11-ns5-ontology-v2",
    "moduleName": "compras",
    "entityId": "Comprador",
    "title": "Comprador",
    "description": "Profissional da organização responsável por cadastrar fornecedores, definir seus produtos e preços e abrir pedidos de compra.",
    "kind": "mdm",
    "party": "person",
    "mdmSubtype": "Person",
    "displayField": "name",
    "fields": [],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "mdm",
        "scope": "organization",
        "idField": "id",
        "mdmType": "compras.Comprador"
    },
    "writer": "crud"
};
export default comprasEntityComprador;
