/// <mls fileReference="_102047_/l4/ordenServicio5/ontology/Cliente.defs.ts" enhancement="_blank"/>
export const ordenServicio5EntityCliente = {
    "schemaVersion": "2026-09-11-ns5-ontology-v2",
    "moduleName": "ordenServicio5",
    "entityId": "Cliente",
    "title": "Cliente",
    "description": "Persona que presenta el aparato, consulta su orden en el portal y responde al presupuesto.",
    "kind": "mdm",
    "party": "person",
    "mdmSubtype": "Person",
    "displayField": "name",
    "fields": [],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "mdm",
        "scope": "organization",
        "idField": "id",
        "mdmType": "ordenServicio5.Cliente"
    }
};
export default ordenServicio5EntityCliente;
