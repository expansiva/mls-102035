/// <mls fileReference="_102047_/l4/mensalidadesAcademia/ontology/Aluno.defs.ts" enhancement="_blank"/>
export const mensalidadesAcademiaEntityAluno = {
    "schemaVersion": "2026-09-11-ns5-ontology-v2",
    "moduleName": "mensalidadesAcademia",
    "entityId": "Aluno",
    "title": "Aluno",
    "description": "Pessoa que possui matrícula na academia e para a qual são geradas mensalidades.",
    "kind": "mdm",
    "party": "person",
    "mdmSubtype": "Person",
    "displayField": "name",
    "fields": [],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "mdm",
        "scope": "organization",
        "idField": "id",
        "mdmType": "mensalidadesAcademia.Aluno"
    }
};
export default mensalidadesAcademiaEntityAluno;
