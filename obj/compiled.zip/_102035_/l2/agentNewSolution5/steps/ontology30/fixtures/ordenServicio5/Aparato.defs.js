/// <mls fileReference="_102047_/l4/ordenServicio5/ontology/Aparato.defs.ts" enhancement="_blank"/>
export const ordenServicio5EntityAparato = {
    "schemaVersion": "2026-09-10-ns5-ontology-v1",
    "moduleName": "ordenServicio5",
    "entityId": "Aparato",
    "title": "Aparato",
    "description": "Equipo electrónico recibido para análisis, reparación y posterior entrega o retiro.",
    "kind": "mdm",
    "party": "none",
    "mdmSubtype": "AssetEquipment",
    "displayField": "serialNumber",
    "fields": [],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "mdm",
        "scope": "organization",
        "idField": "id",
        "mdmType": "ordenServicio5.Aparato"
    }
};
export default ordenServicio5EntityAparato;
