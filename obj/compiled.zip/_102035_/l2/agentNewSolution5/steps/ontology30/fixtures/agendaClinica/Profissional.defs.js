/// <mls fileReference="_102047_/l4/agendaClinica/ontology/Profissional.defs.ts" enhancement="_blank"/>
export const agendaClinicaEntityProfissional = {
    "schemaVersion": "2026-09-11-ns5-ontology-v2",
    "moduleName": "agendaClinica",
    "entityId": "Profissional",
    "title": "Profissional",
    "description": "Médico ou terapeuta da clínica que realiza consultas e acessa a própria agenda.",
    "kind": "mdm",
    "party": "person",
    "mdmSubtype": "Person",
    "displayField": "name",
    "fields": [],
    "lifecycleStates": [],
    "transitions": [],
    "storage": {
        "target": "mdm",
        "scope": "organization",
        "idField": "id",
        "mdmType": "agendaClinica.Profissional"
    },
    "writer": "crud"
};
export default agendaClinicaEntityProfissional;
