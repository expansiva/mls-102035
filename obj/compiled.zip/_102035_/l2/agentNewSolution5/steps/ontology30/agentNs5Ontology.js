/// <mls fileReference="_102035_/l2/agentNewSolution5/steps/ontology30/agentNs5Ontology.ts" enhancement="_blank"/>
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { ddm } from '/_102034_/l4/ontology/ddm.defs.js';
import { mdm } from '/_102034_/l4/ontology/mdm.defs.js';
import { tdm } from '/_102034_/l4/ontology/tdm.defs.js';
import { resolvePlatformEntity } from '/_102034_/l2/mdm/resolveMdmEntity.js';
import { readNs5Actors } from '/_102035_/l2/agentNewSolution5/helpers/ns5Actors.js';
import { formatNs5Siblings, readNs5Siblings } from '/_102035_/l2/solution/ns5Siblings.js';
import { NS5_AGENT_NAME, createNs5RetryStep, markNs5Step, ns5OntologyEntitySelector, } from '/_102035_/l2/agentNewSolution5/helpers/ns5Core.js';
import { composeNs5SystemPrompt, readNs5MdmSkill, readNs5OntologyTableSkill, } from '/_102035_/l2/agentNewSolution5/helpers/ns5Skills.js';
import { NS5_STEP_HOOKS, drainWaitingSiblings, updateStatus, } from '/_102035_/l2/agentNewSolution5/helpers/ns5Dispatch.js';
import { compileNs5Defs, formatNs5CompileFeedback } from '/_102035_/l2/agentNewSolution5/helpers/ns5Compile.js';
import { draftFile, journeyFile, journeyIndexFile, displayPath, moduleFile, ontologyEntityFile, ontologyIndexFile, readAgentJson, readAgentText, readDefsJson, readJson, readPipeline, reconcileModuleDefs, workflowsFile, writeDefs, writeJson, writePipeline, } from '/_102035_/l2/solution/fs.js';
import { createStrictArtifactTool, unwrapArtifactPayload, } from '/_102035_/l2/solution/lib.js';
import { applyNs5ModuleDetails, collectNs5CitedProcessStages, collectNs5CitedTransitions, collectNs5PersonalScopeActors, formatNs5PersonalScopeActors, } from '/_102035_/l2/solution/gates/ontology30/contracts.js';
import { NS5_ONTOLOGY_V3_MAX_PARALLEL, assembleNs5OntologyIndexV3, collectNs5CitedCapabilitiesV3, collectNs5CitedEntitiesV3, collectNs5CitedRulesV3, formatNs5FamilyStartingPoint, formatNs5PlatformCatalog, formatNs5PlatformStartingPoint, liftNs5AggregateOnlyEntitiesV3, normalizeNs5OntologyEntityV3, normalizeNs5OntologyPlanV3, ns5FamilyOfV3, } from '/_102035_/l2/solution/gates/ontology30/contractsV3.js';
import { formatNs5OntologyV3Gate, validateNs5OntologyAssemblyV3, validateNs5OntologyEntityV3, validateNs5OntologyPlanV3, } from '/_102035_/l2/solution/gates/ontology30/gateV3.js';
export function buildNs5OntologyPlanTool(schema, createTool) {
    return createTool('submitNs5OntologyPlan', 'Submit the frozen ontology overview: entities (kind, party, mdmSubtype, displayField, mutability, writer, storage), relationships without realization, and moduleDetails for organization-wide aggregates.', schema);
}
export function buildNs5OntologyEntityTool(schema, createTool) {
    return createTool('submitNs5Entity', 'Submit fields, uniqueKeys, calculated details, lifecycle states, allowed transitions and writer (journey, crud or inbound) for one frozen entity.', schema);
}
export function buildNs5OntologyBindingsTool(schema, createTool) {
    return createTool('submitNs5RelationshipBindings', 'Bind every frozen relationship to existing fields. mdm endpoints use exactly the identity field.', schema);
}
export function buildNs5OntologyPlanV3Tool(schema, createTool) {
    return createTool('submitNs5OntologyPlan', 'Submit the frozen ontology overview: entities (role over an MDM subtype, or a table of the module), '
        + 'each with its family and where its rows live, and the relationships between them. '
        + 'Never roleTag, source, or the target and the name of the table: those are derived.', schema);
}
export function buildNs5OntologyEntityV3Tool(schema, createTool) {
    return createTool('submitNs5Entity', 'Submit one entity: the record tree (columns and details), the links it reads, the capabilities '
        + 'with the sentence of this module, and the rule ids it obeys.', schema);
}
const MAX_REPAIRS = 2;
const MAX_TRANSPORT_RETRIES = 1;
const MAX_ENTITY_REPAIR_ROUNDS = 2;
export function buildNs5OntologyPlanHumanPrompt(input) {
    return [
        '## Source request',
        input.sourcePrompt,
        '',
        '## userLanguage',
        input.userLanguage,
        '',
        '## Actors',
        formatActors(input.actors),
        '',
        '## Journeys (business)',
        formatJourneys(input.journeys),
        '',
        formatNs5PersonalScopeActors(collectNs5PersonalScopeActors(input.actors, input.journeys)),
        '',
        '## Entities the process stages write',
        formatProcessStages(input.workflows, ''),
        '',
        input.siblingsText || '',
        input.platformCatalog,
        input.gateFeedback ? `## Deterministic repair required\n${input.gateFeedback}` : '',
        input.previousDraft ? `## Current draft; keep unrelated fields\n${JSON.stringify(input.previousDraft, null, 2)}` : '',
    ].filter(Boolean).join('\n');
}
export function buildNs5OntologyEntityHumanPrompt(input) {
    const entity = input.plan.entities.find(item => item.entityId === input.entityId);
    const touching = input.plan.relationships.filter(item => item.from === input.entityId || item.to === input.entityId);
    return [
        '## Source request',
        input.sourcePrompt,
        '',
        '## userLanguage',
        input.userLanguage,
        '',
        '## Actors',
        formatActors(input.actors),
        '',
        '## Journeys that touch this entity',
        formatJourneys(input.journeys.filter(journey => journeyTouches(journey, input.entityId))),
        '',
        '## Process stages that touch this entity',
        formatProcessStages(input.workflows, input.entityId),
        '',
        '## Cited transitions this entity must declare',
        formatCitedTransitions(input.journeys, input.workflows, input.entityId),
        '',
        '## Frozen entity',
        JSON.stringify(entity, null, 2),
        '',
        '## Links this entity reads (relationshipId is frozen)',
        JSON.stringify(touching, null, 2),
        '',
        '## All entity ids of this module',
        JSON.stringify(input.plan.entities.map(item => ({ entityId: item.entityId, kind: item.kind, family: item.family, subtype: item.subtype, class: item.class }))),
        '',
        input.startingPoint || '',
        // A role's starting point IS the platform record, so the catalog would repeat it. A table now has a
        // starting point of its own and still needs the catalog: the value types it may reuse (`of`) and the
        // subtypes its foreign keys point at live there.
        entity?.kind === 'role' && input.startingPoint ? '' : input.platformCatalog,
        input.gateFeedback ? `## Deterministic repair required\n${input.gateFeedback}` : '',
        input.previousDraft ? `## Current draft; keep unrelated fields\n${JSON.stringify(input.previousDraft, null, 2)}` : '',
    ].filter(Boolean).join('\n');
}
export async function beforeNs5OntologyPromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error('[agentNewSolution5:ontology30] task invalid');
    const entityId = ns5OntologyEntitySelector(args) || ns5OntologyEntitySelector(step.prompt);
    let moduleName = '';
    try {
        const parsed = entityId ? ns5OntologyChildArgs(context, step.prompt) : resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        if (entityId)
            return [await buildEntityPrompt(context, parentStep, hookSequential, args || String(step.prompt || ''), parsed, entityId)];
        if (parsed.stage === 'finalize') {
            return await finalizeOntology(context, parentStep, step, hookSequential, parsed);
        }
        return [await buildPlanPrompt(context, parentStep, hookSequential, args || String(step.prompt || ''), parsed)];
    }
    catch (error) {
        const message = errorMessage(error);
        if (entityId) {
            return [updateStatus(context, parentStep, step, hookSequential, 'completed', `Entity ${entityId} prompt failed; finalizer will repair it. | ${message}`)];
        }
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
export async function afterNs5OntologyPromptStep(agent, context, parentStep, step, hookSequential, args) {
    const entityId = ns5OntologyEntitySelector(args) || ns5OntologyEntitySelector(step.prompt);
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, entityId ? JSON.stringify({ planId: 'ontology30', moduleName: memoryString(context, 'moduleName') }) : step.prompt);
        moduleName = parsed.moduleName;
        const mutationParent = findMutableParent(context, parentStep);
        if (entityId) {
            return await handleEntityResult(context, mutationParent, step, hookSequential, parsed, entityId);
        }
        if (parsed.stage === 'finalize') {
            throw new Error('ontology30 finalize is deterministic and must not call a model.');
        }
        return await handlePlanResult(agent, context, mutationParent, step, hookSequential, parsed);
    }
    catch (error) {
        const message = errorMessage(error);
        if (entityId) {
            return [updateStatus(context, parentStep, step, hookSequential, 'completed', `Entity ${entityId} failed; finalizer will repair it. | ${message}`)];
        }
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
/** The system prompt of every ontology30 pass: the MDM skill, then the table skill, then the step. */
async function ontologySystemPrompt(stepPrompt) {
    const [mdmSkill, tableSkill] = await Promise.all([readNs5MdmSkill(), readNs5OntologyTableSkill()]);
    return composeNs5SystemPrompt([mdmSkill, tableSkill], stepPrompt);
}
async function buildPlanPrompt(context, parentStep, hookSequential, args, parsed) {
    const [moduleArtifact, journeys, workflows, prompt, schema, previous, siblings] = await Promise.all([
        readModule(parsed.moduleName),
        readJourneys(parsed.moduleName),
        readWorkflows(parsed.moduleName),
        readAgentText('steps/ontology30', 'prompt', '.md'),
        readAgentJson('schemas', 'ontology-plan-v3.schema', '.json'),
        readJson(draftFile(parsed.moduleName, 'ontology30-plan')),
        readNs5Siblings(parsed.moduleName),
    ]);
    const sourcePrompt = await readSourcePrompt(context, parsed.moduleName, moduleArtifact);
    const tool = buildNs5OntologyPlanV3Tool(schema, createStrictArtifactTool);
    const humanPrompt = buildNs5OntologyPlanHumanPrompt({
        sourcePrompt,
        userLanguage: moduleArtifact.userLanguage,
        actors: await readNs5Actors(parsed.moduleName),
        journeys,
        workflows,
        platformCatalog: formatNs5PlatformCatalog(mdm),
        siblingsText: formatNs5Siblings(siblings),
        gateFeedback: parsed.gateFeedback,
        previousDraft: previous,
    });
    return promptReady(context, parentStep, hookSequential, args, await ontologySystemPrompt(prompt), humanPrompt, tool);
}
async function buildEntityPrompt(context, parentStep, hookSequential, args, parsed, entityId) {
    const plan = await readPlanDraft(parsed.moduleName);
    const frozen = plan.entities.find(entity => entity.entityId === entityId);
    if (!frozen) {
        throw new Error(`Entity ${entityId} is not present in the ontology30 overview.`);
    }
    const [moduleArtifact, journeys, workflows, prompt, schema, previous] = await Promise.all([
        readModule(parsed.moduleName),
        readJourneys(parsed.moduleName),
        readWorkflows(parsed.moduleName),
        readAgentText('steps/ontology30', 'promptEntity', '.md'),
        readAgentJson('schemas', 'ontology-entity-v3.schema', '.json'),
        readJson(entityDraftFile(parsed.moduleName, entityId)),
    ]);
    const sourcePrompt = await readSourcePrompt(context, parsed.moduleName, moduleArtifact);
    const tool = buildNs5OntologyEntityV3Tool(schema, createStrictArtifactTool);
    const humanPrompt = buildNs5OntologyEntityHumanPrompt({
        sourcePrompt,
        userLanguage: moduleArtifact.userLanguage,
        actors: await readNs5Actors(parsed.moduleName),
        journeys,
        workflows,
        plan,
        entityId,
        startingPoint: startingPointFor(frozen, parsed.moduleName),
        platformCatalog: formatNs5PlatformCatalog(mdm),
        gateFeedback: ns5EntityGateFeedback(parsed, entityId),
        previousDraft: previous,
    });
    return promptReady(context, parentStep, hookSequential, args, await ontologySystemPrompt(prompt), humanPrompt, tool);
}
/**
 * Every entity starts from the catalog of its family (ns5_46): a role from the platform record of its
 * subtype, a table from `tdm.defs.ts` or `ddm.defs.ts`. Before this, a table started from nothing, and
 * each call of the fan-out invented what a table may do.
 */
function startingPointFor(entity, moduleName) {
    const family = ns5FamilyOfV3(entity);
    if (family === 'mdm') {
        if (entity.kind !== 'role' || !entity.subtype)
            return undefined;
        if (!(entity.subtype in mdm.subtypes))
            return undefined;
        const view = resolvePlatformEntity(mdm, entity.subtype, moduleName);
        return formatNs5PlatformStartingPoint(view, entity.subtype);
    }
    return formatNs5FamilyStartingPoint(family === 'ddm' ? ddm : tdm, entity);
}
async function handlePlanResult(agent, context, mutationParent, step, hookSequential, parsed) {
    const payload = unwrapArtifactPayload(step.interaction?.payload?.[0]);
    if (!isRecord(payload)) {
        const failure = readPromptFailure(step, 'ontology30 returned no usable plan artifact.');
        if (parsed.transportAttempt < MAX_TRANSPORT_RETRIES) {
            return [
                addStep(context, mutationParent, createNs5RetryStep('ontology30', parsed.moduleName, 'transport', parsed.transportAttempt + 1)),
                updateStatus(context, mutationParent, step, hookSequential, 'completed', `ontology30 transport retry ${parsed.transportAttempt + 1} scheduled: ${failure}`),
            ];
        }
        throw new Error(failure);
    }
    await readModule(parsed.moduleName);
    const journeys = await readJourneys(parsed.moduleName);
    const workflows = await readWorkflows(parsed.moduleName);
    const plan = normalizeNs5OntologyPlanV3(payload, parsed.moduleName);
    plan.moduleName = parsed.moduleName;
    let pipeline = await requirePipeline(parsed.moduleName);
    pipeline = await writeStepState(pipeline, { status: 'running', updatedAt: new Date().toISOString() });
    await writeJson(draftFile(parsed.moduleName, 'ontology30-plan'), plan);
    const gate = validateNs5OntologyPlanV3(plan, { moduleName: parsed.moduleName, mdm, tdm, ddm, journeys, workflows });
    if (!gate.ok) {
        const feedback = formatNs5OntologyV3Gate(gate.issues);
        if (parsed.repairAttempt < MAX_REPAIRS) {
            return [
                addStep(context, mutationParent, createNs5RetryStep('ontology30', parsed.moduleName, 'repair', parsed.repairAttempt + 1, { gateFeedback: feedback })),
                updateStatus(context, mutationParent, step, hookSequential, 'completed', `ontology30 plan gate scheduled repair ${parsed.repairAttempt + 1}.`),
            ];
        }
        await writeStepState(pipeline, {
            status: 'failed',
            updatedAt: new Date().toISOString(),
            error: feedback,
        });
        throw new Error(feedback);
    }
    const parallel = parallelEntityStep(context, step, agent.agentName, plan, 0);
    return [
        parallel,
        addStep(context, mutationParent, createFinalizeStep(parsed.moduleName, 0, [String(parallel.step.planning?.planId || '')])),
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `ontology30 overview ready; detailing ${plan.entities.length} entities with maxParallel=${NS5_ONTOLOGY_V3_MAX_PARALLEL}.`),
    ];
}
async function handleEntityResult(context, mutationParent, step, hookSequential, parsed, entityId) {
    const plan = await readPlanDraft(parsed.moduleName);
    const payload = unwrapArtifactPayload(step.interaction?.payload?.[0]);
    if (!isRecord(payload)) {
        return [updateStatus(context, mutationParent, step, hookSequential, 'completed', `Entity ${entityId} returned no usable payload; finalizer will repair it.`)];
    }
    const moduleArtifact = await readModule(parsed.moduleName);
    const journeys = await readJourneys(parsed.moduleName);
    const workflows = await readWorkflows(parsed.moduleName);
    const normalizations = [];
    const entity = normalizeNs5OntologyEntityV3(payload, entityId, {
        moduleName: parsed.moduleName,
        mdm,
        plan,
        journeys,
        workflows,
    }, normalizations);
    if (!entity) {
        return [updateStatus(context, mutationParent, step, hookSequential, 'completed', `Entity ${entityId} is not in the plan; finalizer will repair it.`)];
    }
    await writeJson(entityDraftFile(parsed.moduleName, entityId), { entity, normalizations });
    const gate = validateNs5OntologyEntityV3(entity, plan, {
        moduleName: parsed.moduleName,
        mdm,
        tdm,
        ddm,
        journeys,
        workflows,
        evidenceText: await evidenceText(context, parsed.moduleName, moduleArtifact, journeys),
        actors: (await readNs5Actors(parsed.moduleName)).map(actor => actor.actorId),
    });
    if (!gate.ok) {
        return [updateStatus(context, mutationParent, step, hookSequential, 'completed', `Entity ${entityId} gate failed; finalizer will repair it. | ${formatNs5OntologyV3Gate(gate.issues)}`)];
    }
    // A gate that only warns is still a gate: without this the warning would be written nowhere
    // (the failure branch above is the only place the issues were ever formatted) — ns5_57.
    const warnings = gate.issues.filter(issue => issue.severity === 'warning');
    const suffix = warnings.length ? ` | ${formatNs5OntologyV3Gate(warnings)}` : '';
    return [updateStatus(context, mutationParent, step, hookSequential, 'completed', `Entity ${entityId} detail saved.${suffix}`)];
}
/** Where a module field has to have a trace: the request plus the journey prose. */
async function evidenceText(context, moduleName, moduleArtifact, journeys) {
    const sourcePrompt = await readSourcePrompt(context, moduleName, moduleArtifact);
    return [sourcePrompt, formatJourneys(journeys)].join('\n');
}
async function finalizeOntology(context, parentStep, step, hookSequential, parsed) {
    const mutationParent = findMutableParent(context, parentStep);
    const plan = await readPlanDraft(parsed.moduleName);
    const moduleArtifact = await readModule(parsed.moduleName);
    const [journeys, workflows, actors] = await Promise.all([
        readJourneys(parsed.moduleName),
        readWorkflows(parsed.moduleName),
        readNs5Actors(parsed.moduleName),
    ]);
    const gateContext = {
        moduleName: parsed.moduleName,
        mdm,
        tdm,
        ddm,
        journeys,
        workflows,
        evidenceText: await evidenceText(context, parsed.moduleName, moduleArtifact, journeys),
        actors: actors.map(actor => actor.actorId),
    };
    const invalid = [];
    const entityFeedback = {};
    const entities = [];
    const normalizations = [];
    for (const planned of plan.entities) {
        const saved = await readJson(entityDraftFile(parsed.moduleName, planned.entityId));
        const entity = saved?.entity;
        const gate = entity ? validateNs5OntologyEntityV3(entity, plan, gateContext) : null;
        if (!entity || !gate?.ok) {
            invalid.push(planned.entityId);
            // ns5_58: without this the repair round reran the entity blind — the model never saw the issue.
            entityFeedback[planned.entityId] = gate
                ? formatNs5OntologyV3Gate(gate.issues)
                : `The draft of ${planned.entityId} is missing; write it again from the frozen plan.`;
            continue;
        }
        entities.push(entity);
        normalizations.push(...(saved?.normalizations || []));
    }
    if (invalid.length && parsed.entityRepairRound < MAX_ENTITY_REPAIR_ROUNDS) {
        const parallel = parallelEntityStep(context, step, NS5_AGENT_NAME, plan, parsed.entityRepairRound + 1, invalid, entityFeedback);
        return [
            parallel,
            addStep(context, mutationParent, createFinalizeStep(parsed.moduleName, parsed.entityRepairRound + 1, [String(parallel.step.planning?.planId || '')])),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `${invalid.length} invalid/missing entities; targeted parallel repair started: ${invalid.join(', ')}.`),
        ];
    }
    if (invalid.length) {
        throw new Error(`ontology30 entities remain invalid after repair: ${invalid.join(', ')}.`);
    }
    // A panel is not a table: an entity nobody writes, with no lifecycle and no link, is lifted into
    // `module.details` and leaves the ontology (ns5_42 T6, the v3 form of the v2 aggregate lift).
    const lift = liftNs5AggregateOnlyEntitiesV3(plan, entities, journeys, workflows);
    const index = assembleNs5OntologyIndexV3(lift.plan, moduleNamespaceDescription(parsed.moduleName));
    const assembly = validateNs5OntologyAssemblyV3(index, lift.entities, gateContext);
    if (!assembly.ok)
        throw new Error(formatNs5OntologyV3Gate(assembly.issues));
    if (lift.liftedEntityIds.length) {
        await writeJson(draftFile(parsed.moduleName, 'ontology30-plan'), lift.plan);
        await writeDefs(moduleFile(parsed.moduleName), `${parsed.moduleName}Module`, applyNs5ModuleDetails(moduleArtifact, lift.moduleDetails), 'Ns5ModuleArtifact');
    }
    const pipeline = await requirePipeline(parsed.moduleName);
    const { artifactPaths, compile } = await persistArtifacts(parsed.moduleName, lift.plan, index, lift.entities, [...normalizations, ...lift.normalizations], pipeline, journeys, lift.liftedEntityIds);
    if (compile.status === 'errors') {
        // p4_20: a compile error of an entity file goes to that entity's targeted repair, same budget as
        // the gate. An error outside the entity files (index, lifted module) has no LLM to repair it.
        const errors = compile.errors || [];
        const compileFeedback = {};
        for (const entity of lift.entities) {
            const prefix = `${displayPath(ontologyEntityFile(parsed.moduleName, entity.entityId))}: `;
            const lines = errors.filter(line => line.startsWith(prefix));
            if (lines.length)
                compileFeedback[entity.entityId] = formatNs5CompileFeedback({ ...compile, errors: lines });
        }
        const failedIds = Object.keys(compileFeedback);
        const attributed = errors.filter(line => failedIds.some(id => line.startsWith(`${displayPath(ontologyEntityFile(parsed.moduleName, id))}: `)));
        if (failedIds.length && attributed.length === errors.length && parsed.entityRepairRound < MAX_ENTITY_REPAIR_ROUNDS) {
            const parallel = parallelEntityStep(context, step, NS5_AGENT_NAME, lift.plan, parsed.entityRepairRound + 1, failedIds, compileFeedback);
            return [
                parallel,
                addStep(context, mutationParent, createFinalizeStep(parsed.moduleName, parsed.entityRepairRound + 1, [String(parallel.step.planning?.planId || '')])),
                updateStatus(context, mutationParent, step, hookSequential, 'completed', `${failedIds.length} entities failed the Studio compile; targeted parallel repair started: ${failedIds.join(', ')}.`),
            ];
        }
        throw new Error(formatNs5CompileFeedback(compile));
    }
    const intents = [];
    if (!hasPlanId(context, 'ontology30-done')) {
        intents.push(doneAnchor(context, mutationParent, parsed.moduleName, artifactPaths));
    }
    intents.push(updateStatus(context, mutationParent, step, hookSequential, 'completed', `ontology30 approved: ${artifactPaths.join(', ')}`));
    return intents;
}
function moduleNamespaceDescription(moduleName) {
    return `Branch details.${moduleName} of the master records this module has a role on; only this module writes it.`;
}
async function persistArtifacts(moduleName, plan, index, entities, entityNormalizations, pipeline, journeys, liftedAggregateEntities = []) {
    const artifactPaths = [];
    for (const entity of entities) {
        artifactPaths.push(await writeDefs(ontologyEntityFile(moduleName, entity.entityId), `${moduleName}Entity${entity.entityId}`, entity, 'Ns5OntologyEntityV3'));
    }
    artifactPaths.push(await writeDefs(ontologyIndexFile(moduleName), `${moduleName}OntologyIndex`, index, 'Ns5OntologyIndexV3'));
    // p4_20: the compiler is the last gate; errors go back to the entity repair, never approved.
    const compile = await compileNs5Defs([
        ...entities.map(entity => ontologyEntityFile(moduleName, entity.entityId)),
        ontologyIndexFile(moduleName),
        ...(liftedAggregateEntities.length ? [moduleFile(moduleName)] : []),
    ]);
    if (compile.status === 'errors') {
        await writeStepState(pipeline, { status: 'running', updatedAt: new Date().toISOString(), artifactPaths, compile });
        return { artifactPaths, compile };
    }
    const removedOrphans = await reconcileModuleDefs(moduleName, 'ontology', entities.map(entity => entity.entityId));
    const normalizations = [...(plan.normalizations || []), ...entityNormalizations];
    const citedRules = collectNs5CitedRulesV3(entities);
    const citedCapabilities = collectNs5CitedCapabilitiesV3(entities);
    const cited = collectNs5CitedEntitiesV3(journeys);
    const uncitedEntities = entities.map(entity => entity.entityId).filter(entityId => !cited.has(entityId));
    await writeJson(draftFile(moduleName, 'ontology30'), {
        plan,
        entities,
        relationships: index.relationships,
        removedOrphans,
        liftedAggregateEntities,
        ...(normalizations.length ? { normalizations } : {}),
    });
    await writeStepState(pipeline, {
        status: 'approved',
        updatedAt: new Date().toISOString(),
        artifactPaths,
        uncitedEntities,
        liftedAggregateEntities,
        compile,
        ...(normalizations.length ? { normalizations } : {}),
        ...(citedRules.length ? { citedRules } : {}),
        ...(citedCapabilities.length ? { citedCapabilities } : {}),
        ...(pipeline.invocation.fast ? { autoReason: 'fast' } : {}),
    });
    return { artifactPaths, compile };
}
export function parallelEntityStep(context, hostStep, agentName, plan, repairRound, entityIds = plan.entities.map(entity => entity.entityId), entityFeedback = {}) {
    if (!context.task)
        throw new Error('[agentNewSolution5:ontology30] task invalid');
    if (!entityIds.length)
        throw new Error('ontology30 entity fan-out cannot be empty.');
    const planId = `ontology30-entities-${repairRound}`;
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task.PK,
        parentStepId: hostStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: {
                input: [{ type: 'system', content: '<!-- modelType: reasoning -->' }],
                cost: 0,
                trace: [`queued ${entityIds.length} ontology30 entities with maxParallel=${NS5_ONTOLOGY_V3_MAX_PARALLEL}`],
                payload: null,
            },
            stepTitle: 'Detailing {{completed}}/{{total}} ontology entities, failed {{failed}}',
            status: 'in_progress',
            nextSteps: [],
            agentName,
            onFailure: 'wait_after_prompt',
            prompt: JSON.stringify({
                planId: 'ontology30',
                moduleName: plan.moduleName,
                ...(Object.keys(entityFeedback).length ? { entityFeedback } : {}),
            }),
            rags: [],
            planning: { planId, dependsOn: [], executionMode: 'parallel_dynamic', executionHost: 'client' },
        },
        executionMode: { type: 'parallel', args: entityIds.map(entityId => `entity:${entityId}`), maxParallel: NS5_ONTOLOGY_V3_MAX_PARALLEL },
    };
}
export function createFinalizeStep(moduleName, entityRepairRound, dependsOn) {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: entityRepairRound ? `Finalize ontology · ${entityRepairRound}` : 'Finalize ontology',
        status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName: NS5_AGENT_NAME,
        prompt: JSON.stringify({ planId: 'ontology30', moduleName, stage: 'finalize', entityRepairRound }),
        rags: [],
        planning: {
            planId: `ontology30-finalize-${entityRepairRound}`,
            dependsOn,
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
async function readModule(moduleName) {
    if (!moduleName)
        throw new Error('ontology30 needs a moduleName.');
    const artifact = await readDefsJson(moduleFile(moduleName));
    if (!artifact)
        throw new Error(`module.defs.ts is missing for ${moduleName}; module10 must run first.`);
    const pipeline = await readPipeline(moduleName);
    if (pipeline?.steps.journeys20?.status !== 'approved') {
        throw new Error(`journeys20 must be approved before ontology30 (${moduleName}).`);
    }
    // ns5_49: the ontology honours the entities and transitions the process stages cite, so it waits
    // for workflows50 too.
    if (pipeline?.steps.workflows50?.status !== 'approved') {
        throw new Error(`workflows50 must be approved before ontology30 (${moduleName}).`);
    }
    return artifact;
}
async function readJourneys(moduleName) {
    const index = await readDefsJson(journeyIndexFile(moduleName));
    if (!index)
        throw new Error(`journeys/index.defs.ts is missing for ${moduleName}; journeys20 must run first.`);
    const journeys = [];
    for (const entry of index.journeys) {
        const artifact = await readDefsJson(journeyFile(moduleName, entry.journeyId));
        if (artifact)
            journeys.push(artifact);
    }
    return journeys;
}
/**
 * ns5_49: workflows50 runs before this step, so `workflows.defs.ts` is on disk. It is missing only on
 * a module recorded under flow v1, and then there is simply nothing cited forward — `null`, not a throw.
 */
async function readWorkflows(moduleName) {
    return await readDefsJson(workflowsFile(moduleName));
}
async function readPlanDraft(moduleName) {
    const plan = await readJson(draftFile(moduleName, 'ontology30-plan'));
    if (!plan?.entities?.length)
        throw new Error(`ontology30 plan draft is missing for ${moduleName}.`);
    return plan;
}
/**
 * ns5_52b achado 4: the `entity-` segment keeps an entity called `Plan` off the plan draft
 * (`ontology30-plan-draft.json`), which on a case-insensitive file system (APFS) overwrote it and
 * failed the step with "ontology30 plan draft is missing". Lower-casing the id would make the
 * collision certain on every OS instead.
 */
function entityDraftFile(moduleName, entityId) {
    return draftFile(moduleName, `ontology30-entity-${entityId}`);
}
async function requirePipeline(moduleName) {
    const pipeline = await readPipeline(moduleName);
    if (!pipeline)
        throw new Error(`pipeline.json is missing for ${moduleName}.`);
    return pipeline;
}
async function writeStepState(pipeline, next) {
    const updated = markNs5Step(pipeline, 'ontology30', next);
    await writePipeline(updated);
    return updated;
}
async function recordFailure(moduleName, error) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readPipeline(moduleName);
        if (!pipeline)
            return;
        await writePipeline(markNs5Step(pipeline, 'ontology30', {
            status: 'failed',
            updatedAt: new Date().toISOString(),
            error,
        }));
    }
    catch { /* task trace remains the fallback */ }
}
async function readSourcePrompt(context, moduleName, moduleArtifact) {
    if (moduleName) {
        const pipeline = await readPipeline(moduleName);
        if (pipeline?.sourcePrompt)
            return pipeline.sourcePrompt;
    }
    return moduleArtifact.sourcePrompt || memoryString(context, 'sourcePrompt');
}
function resolveArgs(context, value) {
    const root = parseRecord(value);
    const stage = text(root.stage);
    return {
        planId: text(root.planId) || 'ontology30',
        moduleName: text(root.moduleName) || memoryString(context, 'moduleName'),
        stage: stage === 'finalize' ? stage : 'plan',
        repairAttempt: integer(root.repairAttempt),
        transportAttempt: integer(root.transportAttempt),
        entityRepairRound: integer(root.entityRepairRound),
        gateFeedback: text(root.gateFeedback),
        entityFeedback: textRecord(root.entityFeedback),
    };
}
/**
 * ns5_58: a fan-out child resolves its args from a stub — it must not inherit the host's stage or
 * repair counters. Its gate issues, though, live only on the host prompt, so they are carried over.
 */
export function ns5OntologyChildArgs(context, hostPrompt) {
    const host = resolveArgs(context, hostPrompt);
    return resolveArgs(context, JSON.stringify({ planId: 'ontology30', entityFeedback: host.entityFeedback }));
}
/**
 * ns5_58: the entity fan-out is one step for every entity, so a repair round cannot carry a single
 * feedback string — the issues travel keyed by entityId and each prompt reads only its own.
 */
export function ns5EntityGateFeedback(parsed, entityId) {
    return parsed.entityFeedback[entityId] || parsed.gateFeedback;
}
function formatActors(actors) {
    if (!actors.length)
        return '(none)';
    return actors.map(actor => `- ${actor.actorId} (${actor.kind}, ${actor.origin}): ${actor.title} — ${actor.description}`).join('\n');
}
function formatJourneys(journeys) {
    if (!journeys.length)
        return '(none)';
    return journeys.map(journey => [
        `### ${journey.journeyId} (${journey.business.actorRef})`,
        journey.business.title,
        journey.business.goal,
        ...journey.business.steps.map(step => {
            const affects = step.affects?.length ? ` affects=${step.affects.join(',')}` : '';
            const effect = step.effect ? ` effect=${step.effect}` : '';
            const transition = step.effect === 'transition' && step.transitionRef ? ` transitionRef=${step.transitionRef}` : '';
            const decide = step.kind === 'decide' ? ' decide' : '';
            return `- ${step.stepId} ${step.kind} ${step.entity}${affects}${effect}${transition}${decide}: ${step.description}`;
        }),
    ].join('\n')).join('\n\n');
}
/**
 * ns5_49: a transition may be cited by a journey act (a person applies it) or by a process stage
 * (nobody does — the process owns it, and `by` is written as `[]`). Both are listed, tagged.
 */
function formatCitedTransitions(journeys, workflows, entityId) {
    const lines = collectNs5CitedTransitions(journeys)
        .filter(item => item.entityId === entityId)
        .map(item => `- ${item.transitionId} by ${item.actorRef} (${item.stepId})`);
    const byJourney = new Set(collectNs5CitedTransitions(journeys).filter(item => item.entityId === entityId).map(item => item.transitionId));
    for (const stage of collectNs5CitedProcessStages(workflows)) {
        if (stage.entityId !== entityId || stage.effect !== 'transition' || !stage.transitionId)
            continue;
        if (byJourney.has(stage.transitionId))
            continue;
        lines.push(`- ${stage.transitionId} by: (process) (${stage.processId}.${stage.taskId})`);
    }
    return lines.length ? lines.join('\n') : '(none)';
}
/** The `mechanical`/`llm` stages, all of them or only the ones writing `entityId`. */
function formatProcessStages(workflows, entityId) {
    const lines = collectNs5CitedProcessStages(workflows)
        .filter(stage => !entityId || stage.entityId === entityId)
        .map(stage => {
        const transition = stage.effect === 'transition' && stage.transitionId ? ` transitionRef=${stage.transitionId}` : '';
        return `- ${stage.processId}.${stage.taskId} ${stage.entityId} effect=${stage.effect}${transition}`;
    });
    return lines.length ? lines.join('\n') : '(none)';
}
function journeyTouches(journey, entityId) {
    return journey.business.steps.some(step => step.entity === entityId || step.affects?.includes(entityId));
}
function promptReady(context, parentStep, hookSequential, args, systemPrompt, humanPrompt, tool) {
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt,
        humanPrompt,
        tools: [tool],
        toolChoice: { type: 'function', function: { name: tool.function.name } },
    };
}
function doneAnchor(context, parentStep, moduleName, artifactPaths) {
    return addStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Ontology done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({ moduleName, artifactPaths, completedStep: 'ontology30', nextStep: 'rules40' }),
        planning: { planId: 'ontology30-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
function hasPlanId(context, planId) {
    return getAllSteps(context.task?.iaCompressed?.nextSteps).some(step => step.planning?.planId === planId);
}
function findMutableParent(context, parentStep) {
    const all = getAllSteps(context.task?.iaCompressed?.nextSteps);
    const current = all.find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current))
        return current;
    const owner = all.find(candidate => isOpenAgent(candidate)
        && (candidate.nextSteps?.some(child => child.stepId === parentStep.stepId)
            || candidate.interaction?.payload?.some(child => child.stepId === parentStep.stepId)));
    if (isOpenAgent(owner))
        return owner;
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    return root?.type === 'agent' ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function readPromptFailure(step, fallback) {
    const payload = step.interaction?.payload?.[0];
    const recordValue = isRecord(payload) ? payload : parseRecord(payload);
    if (typeof recordValue.result === 'string' && recordValue.result.trim())
        return recordValue.result.trim();
    return fallback;
}
function parseRecord(value) {
    const parsed = parseMaybeJson(value);
    return isRecord(parsed) ? parsed : {};
}
function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(clean);
    }
    catch {
        return value;
    }
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function textRecord(value) {
    const out = {};
    if (!isRecord(value))
        return out;
    for (const [key, item] of Object.entries(value)) {
        const content = text(item);
        if (content)
            out[key] = content;
    }
    return out;
}
function integer(value) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : 0;
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
NS5_STEP_HOOKS.ontology30 = {
    beforePromptStep: beforeNs5OntologyPromptStep,
    afterPromptStep: afterNs5OntologyPromptStep,
};
