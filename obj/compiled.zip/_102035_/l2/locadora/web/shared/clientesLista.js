/// <mls fileReference="_102035_/l2/locadora/web/shared/clientesLista.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState, initState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Locadora',
    pageTitle: 'Clientes - Lista',
    pageSubtitle: 'Consultar clientes cadastrados.',
    loadingListarClientes: 'Carregando clientes...',
    couldNotLoad: 'Nao foi possivel carregar os dados.',
    itemsAvailable: 'itens disponiveis',
    // common actions
    reload: 'Recarregar',
    save: 'Salvar',
    saving: 'Salvando...',
    confirm: 'Confirmar',
    confirming: 'Confirmando...',
    // field labels (filters / list)
    nome: 'Nome',
    cpf: 'CPF',
    cnh: 'CNH',
    telefone: 'Telefone',
    email: 'E-mail',
    statusValidacao: 'Status de validacao',
    page: 'Pagina',
    pageSize: 'Itens por pagina',
    sortBy: 'Ordenar por',
    sortDir: 'Direcao',
};
const message_en = {
    brand: 'Car rental',
    pageTitle: 'Clients - List',
    pageSubtitle: 'Consult registered clients.',
    loadingListarClientes: 'Loading clients...',
    couldNotLoad: 'Could not load data.',
    itemsAvailable: 'items available',
    // common actions
    reload: 'Reload',
    save: 'Save',
    saving: 'Saving...',
    confirm: 'Confirm',
    confirming: 'Confirming...',
    // field labels (filters / list)
    nome: 'Name',
    cpf: 'CPF',
    cnh: 'CNH',
    telefone: 'Phone',
    email: 'Email',
    statusValidacao: 'Validation status',
    page: 'Page',
    pageSize: 'Items per page',
    sortBy: 'Sort by',
    sortDir: 'Direction',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LocadoraClientesListaBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            // dataShape fields
            'db.cliente.nome',
            'db.cliente.cpf',
            'db.cliente.cnh',
            'db.cliente.telefone',
            'db.cliente.email',
            // dataShape collection
            'db.cliente[]',
            // organism tempStates
            'ui.clientesLista.selection.clienteId',
            'ui.clientesLista.view.compact',
            'ui.clientesLista.filter.nome',
            'ui.clientesLista.filter.cpf',
            'ui.clientesLista.filter.cnh',
            'ui.clientesLista.filter.telefone',
            'ui.clientesLista.filter.email',
            'ui.clientesLista.filter.statusValidacao',
            // page tempStates
            'ui.clientesLista.pagination.page',
            'ui.clientesLista.pagination.pageSize',
            'ui.clientesLista.sort.by',
            'ui.clientesLista.sort.dir',
            'ui.clientesLista.search.lastPayload',
            // actionStates (prefer exclusive subscription)
            '*ui.clientesLista.loadingList',
            '*ui.clientesLista.loadingSearch',
            '*ui.clientesLista.error',
        ];
        this.cliente = [];
        this.status = '';
        // fields (shape: fields)
        this.nome = '';
        this.cpf = '';
        this.cnh = '';
        this.telefone = '';
        this.email = '';
        // tempStates
        this.clienteId = '';
        this.compact = false;
        this.filterNome = '';
        this.filterCpf = '';
        this.filterCnh = '';
        this.filterTelefone = '';
        this.filterEmail = '';
        this.statusValidacao = 'todos';
        this.page = 1;
        this.pageSize = 20;
        this.by = 'nome';
        this.dir = 'asc';
        this.lastPayload = undefined;
        // actionStates
        this.loadingList = 'idle';
        this.loadingSearch = 'idle';
        this.error = 'idle';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, {
            // mode: pendingLoad ? 'blocking' : 'silent',
            mode: 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        // initState for tempStates with initialValue
        initState('ui.clientesLista.view.compact', false);
        initState('ui.clientesLista.filter.statusValidacao', 'todos');
        initState('ui.clientesLista.pagination.page', 1);
        initState('ui.clientesLista.pagination.pageSize', 20);
        initState('ui.clientesLista.sort.by', 'nome');
        initState('ui.clientesLista.sort.dir', 'asc');
        // subscribe to all observed state keys
        subscribe(this._stateKeys, this);
        // read current values from global state
        this._stateKeys.forEach((key) => {
            const normalizedKey = key.startsWith('*') ? key.slice(1) : key;
            const v = getState(normalizedKey);
            if (v !== undefined)
                this.handleIcaStateChange(normalizedKey, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'db.cliente.nome':
                this.nome = value ?? '';
                break;
            case 'db.cliente.cpf':
                this.cpf = value ?? '';
                break;
            case 'db.cliente.cnh':
                this.cnh = value ?? '';
                break;
            case 'db.cliente.telefone':
                this.telefone = value ?? '';
                break;
            case 'db.cliente.email':
                this.email = value ?? '';
                break;
            case 'db.cliente[]':
                this.cliente = value ?? [];
                break;
            case 'ui.clientesLista.selection.clienteId':
                this.clienteId = value ?? '';
                break;
            case 'ui.clientesLista.view.compact':
                this.compact = value ?? false;
                break;
            case 'ui.clientesLista.filter.nome':
                this.filterNome = value ?? '';
                break;
            case 'ui.clientesLista.filter.cpf':
                this.filterCpf = value ?? '';
                break;
            case 'ui.clientesLista.filter.cnh':
                this.filterCnh = value ?? '';
                break;
            case 'ui.clientesLista.filter.telefone':
                this.filterTelefone = value ?? '';
                break;
            case 'ui.clientesLista.filter.email':
                this.filterEmail = value ?? '';
                break;
            case 'ui.clientesLista.filter.statusValidacao':
                this.statusValidacao = value ?? 'todos';
                break;
            case 'ui.clientesLista.pagination.page':
                this.page = value ?? 1;
                break;
            case 'ui.clientesLista.pagination.pageSize':
                this.pageSize = value ?? 20;
                break;
            case 'ui.clientesLista.sort.by':
                this.by = value ?? 'nome';
                break;
            case 'ui.clientesLista.sort.dir':
                this.dir = value ?? 'asc';
                break;
            case 'ui.clientesLista.search.lastPayload':
                this.lastPayload = value ?? undefined;
                break;
            case 'ui.clientesLista.loadingList':
                this.loadingList = value ?? 'idle';
                break;
            case 'ui.clientesLista.loadingSearch':
                this.loadingSearch = value ?? 'idle';
                break;
            case 'ui.clientesLista.error':
                this.error = value ?? 'idle';
                break;
            default:
                break;
        }
    }
    // ── initial load ──
    async loadInitialData(_params, options) {
        await this.loadListarClientes(undefined, options);
    }
    // ── load methods ──
    async loadListarClientes(params, options) {
        setState('ui.clientesLista.loadingList', 'loading');
        try {
            const effectiveParams = {
                nome: params?.nome ?? getState('ui.clientesLista.filter.nome'),
                cpf: params?.cpf ?? getState('ui.clientesLista.filter.cpf'),
                cnh: params?.cnh ?? getState('ui.clientesLista.filter.cnh'),
                telefone: params?.telefone ?? getState('ui.clientesLista.filter.telefone'),
                email: params?.email ?? getState('ui.clientesLista.filter.email'),
                statusValidacao: params?.statusValidacao ?? getState('ui.clientesLista.filter.statusValidacao'),
                page: params?.page ?? getState('ui.clientesLista.pagination.page'),
                pageSize: params?.pageSize ?? getState('ui.clientesLista.pagination.pageSize'),
                sortBy: params?.sortBy ?? getState('ui.clientesLista.sort.by'),
                sortDir: params?.sortDir ?? getState('ui.clientesLista.sort.dir'),
            };
            this.status = this.msg.loadingListarClientes;
            if (window.mls) {
                this.cliente = [
                    {
                        nome: 'Joao Silva',
                        cpf: '123.456.789-09',
                        cnh: '12345678900',
                        telefone: '(11) 91234-5678',
                        email: 'joao.silva@exemplo.com',
                    },
                    {
                        nome: 'Maria Oliveira',
                        cpf: '987.654.321-00',
                        cnh: '00987654321',
                        telefone: '(21) 99876-5432',
                        email: 'maria.oliveira@exemplo.com',
                    },
                    {
                        nome: 'Carlos Souza',
                        cpf: '321.654.987-10',
                        cnh: '11223344556',
                        telefone: '(31) 93456-7890',
                        email: 'carlos.souza@exemplo.com',
                    },
                ];
                setState('db.cliente[]', this.cliente);
                this.status = `${this.cliente.length} ${this.msg.itemsAvailable}`;
                setState('ui.clientesLista.loadingList', 'success');
                return;
            }
            const response = await execBff('locadora.clientesLista.listarClientes', effectiveParams, options);
            if (!response.ok || !response.data) {
                if (options?.mode === 'blocking') {
                    setState('ui.clientesLista.loadingList', 'error');
                    throw (response.error ??
                        {
                            code: 'UNEXPECTED_ERROR',
                            message: this.msg.couldNotLoad,
                        });
                }
                this.status = this.msg.couldNotLoad;
                this.cliente = [];
                setState('db.cliente[]', this.cliente);
                setState('ui.clientesLista.loadingList', 'error');
                return;
            }
            this.cliente = response.data ?? [];
            setState('db.cliente[]', this.cliente);
            this.status = `${this.cliente.length} ${this.msg.itemsAvailable}`;
            setState('ui.clientesLista.loadingList', 'success');
        }
        catch (e) {
            setState('ui.clientesLista.loadingList', 'error');
            throw e;
        }
    }
    // ── helpers ──
    handleBuscarClick() {
        setState('ui.clientesLista.loadingSearch', 'loading');
        try {
            const payload = {
                nome: this.filterNome,
                cpf: this.filterCpf,
                cnh: this.filterCnh,
                telefone: this.filterTelefone,
                email: this.filterEmail,
                statusValidacao: this.statusValidacao,
            };
            setState('ui.clientesLista.search.lastPayload', payload);
            // reset to first page on new search
            this.page = 1;
            setState('ui.clientesLista.pagination.page', 1);
            void runBlockingUiAction(async (signal) => {
                await this.loadListarClientes({
                    ...payload,
                    page: 1,
                    pageSize: this.pageSize,
                    sortBy: this.by,
                    sortDir: this.dir,
                }, { mode: 'blocking', signal });
            }, {
                busyLabel: this.msg.loadingListarClientes,
                errorTitle: this.msg.couldNotLoad,
                retry: () => this.loadListarClientes({
                    ...payload,
                    page: 1,
                    pageSize: this.pageSize,
                    sortBy: this.by,
                    sortDir: this.dir,
                }),
            });
            setState('ui.clientesLista.loadingSearch', 'success');
        }
        catch (e) {
            setState('ui.clientesLista.loadingSearch', 'error');
            throw e;
        }
    }
    handleLimparFiltrosClick() {
        // clear filter states
        this.filterNome = '';
        this.filterCpf = '';
        this.filterCnh = '';
        this.filterTelefone = '';
        this.filterEmail = '';
        this.statusValidacao = 'todos';
        setState('ui.clientesLista.filter.nome', this.filterNome);
        setState('ui.clientesLista.filter.cpf', this.filterCpf);
        setState('ui.clientesLista.filter.cnh', this.filterCnh);
        setState('ui.clientesLista.filter.telefone', this.filterTelefone);
        setState('ui.clientesLista.filter.email', this.filterEmail);
        setState('ui.clientesLista.filter.statusValidacao', this.statusValidacao);
        // reset paging
        this.page = 1;
        setState('ui.clientesLista.pagination.page', 1);
        this.lastPayload = undefined;
        setState('ui.clientesLista.search.lastPayload', this.lastPayload);
    }
}
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "cliente", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "status", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "nome", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "cpf", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "cnh", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "telefone", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "email", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "clienteId", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "compact", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "filterNome", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "filterCpf", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "filterCnh", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "filterTelefone", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "filterEmail", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "statusValidacao", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "page", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "pageSize", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "by", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "dir", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "lastPayload", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "loadingList", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "loadingSearch", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "error", void 0);
