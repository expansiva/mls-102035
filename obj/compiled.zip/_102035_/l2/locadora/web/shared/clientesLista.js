/// <mls fileReference="_102035_/l2/locadora/web/shared/clientesLista.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Locadora',
    pageTitle: 'Clientes - Lista',
    pageSubtitle: 'Consultar clientes cadastrados.',
    loadingListarClientes: 'Carregando clientes...',
    itemsAvailable: 'itens disponiveis',
    couldNotLoad: 'Nao foi possivel carregar os dados.',
    reload: 'Recarregar',
    filterNome: 'Nome',
    filterCpf: 'CPF',
    filterCnh: 'CNH',
    filterTelefone: 'Telefone',
    filterEmail: 'E-mail',
    filterStatusValidacao: 'Status de validacao',
};
const message_en = {
    brand: 'Rental',
    pageTitle: 'Customers - List',
    pageSubtitle: 'Review registered customers.',
    loadingListarClientes: 'Loading customers...',
    itemsAvailable: 'items available',
    couldNotLoad: 'Could not load data.',
    reload: 'Reload',
    filterNome: 'Name',
    filterCpf: 'CPF',
    filterCnh: 'CNH',
    filterTelefone: 'Phone',
    filterEmail: 'Email',
    filterStatusValidacao: 'Validation status',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LocadoraClientesListaBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.cliente = [];
        this.status = '';
        this.msg = messages['en'];
        // ── action methods (one per write routine) ──
        // (no write routines defined for this page)
        // ── form submit handlers (one per write routine that originates from a form) ──
    }
    createRenderRoot() { return this; }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, {
            // mode: pendingLoad ? 'blocking' : 'silent',
            mode: 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
    }
    async loadInitialData(_params, options) {
        await this.loadListarClientes(undefined, options);
    }
    // ── load methods (one per read routine) ──
    async loadListarClientes(params, options) {
        this.status = this.msg.loadingListarClientes;
        if (window.mls) {
            this.cliente = [
                {
                    nome: 'Joao Silva',
                    cpf: '123.456.789-09',
                    cnh: '12345678900',
                    telefone: '(11) 98888-7777',
                    email: 'joao.silva@exemplo.com',
                },
                {
                    nome: 'Maria Oliveira',
                    cpf: '987.654.321-00',
                    cnh: '00987654321',
                    telefone: '(21) 97777-6666',
                    email: 'maria.oliveira@exemplo.com',
                },
                {
                    nome: 'Carlos Pereira',
                    cpf: '111.222.333-44',
                    cnh: '11223344556',
                    telefone: '(31) 96666-5555',
                    email: 'carlos.pereira@exemplo.com',
                },
            ];
            this.status = `${this.cliente.length} ${this.msg.itemsAvailable}`;
            return;
        }
        else {
            const response = await execBff('locadora.clientesLista.listarClientes', params, options);
            if (!response.ok || !response.data) {
                if (options?.mode === 'blocking') {
                    throw (response.error ?? {
                        code: 'UNEXPECTED_ERROR',
                        message: this.msg.couldNotLoad,
                    });
                }
                this.status = this.msg.couldNotLoad;
                this.cliente = [];
                return;
            }
            this.cliente = response.data ?? [];
            this.status = `${this.cliente.length} ${this.msg.itemsAvailable}`;
        }
    }
}
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "cliente", void 0);
__decorate([
    property()
], LocadoraClientesListaBase.prototype, "status", void 0);
