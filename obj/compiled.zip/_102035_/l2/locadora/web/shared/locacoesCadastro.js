/// <mls fileReference="_102035_/l2/locadora/web/shared/locacoesCadastro.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Locadora',
    pageTitle: 'Cadastro de locacoes',
    pageSubtitle: 'Registrar nova locacao com validacoes de cliente e disponibilidade do veiculo.',
    loadingCreateLocacao: 'Carregando dados da nova locacao...',
    loadingValidateCliente: 'Validando cliente...',
    loadingCheckVeiculoAvailability: 'Verificando disponibilidade do veiculo...',
    couldNotLoad: 'Nao foi possivel carregar os dados.',
    couldNotSave: 'Nao foi possivel salvar.',
    savedSuccessfully: 'Salvo com sucesso.',
    reload: 'Recarregar',
    save: 'Salvar',
    saving: 'Salvando...',
    confirm: 'Confirmar',
    confirming: 'Confirmando...',
    fieldDataRetirada: 'Data de retirada',
    fieldDataDevolucao: 'Data de devolucao',
    fieldValorDiario: 'Valor diario',
    fieldSeguroOpcional: 'Seguro opcional',
    fieldFormaPagamento: 'Forma de pagamento',
    fieldDevolucaoPrevista: 'Devolucao prevista',
    fieldPlacaVeiculo: 'Placa do veiculo',
    fieldClienteId: 'Cliente',
};
const message_en = {
    brand: 'Car Rental',
    pageTitle: 'Rentals registration',
    pageSubtitle: 'Register a new rental with customer validation and vehicle availability checks.',
    loadingCreateLocacao: 'Loading new rental data...',
    loadingValidateCliente: 'Validating customer...',
    loadingCheckVeiculoAvailability: 'Checking vehicle availability...',
    couldNotLoad: 'Could not load data.',
    couldNotSave: 'Could not save.',
    savedSuccessfully: 'Saved successfully.',
    reload: 'Reload',
    save: 'Save',
    saving: 'Saving...',
    confirm: 'Confirm',
    confirming: 'Confirming...',
    fieldDataRetirada: 'Pickup date',
    fieldDataDevolucao: 'Return date',
    fieldValorDiario: 'Daily rate',
    fieldSeguroOpcional: 'Optional insurance',
    fieldFormaPagamento: 'Payment method',
    fieldDevolucaoPrevista: 'Expected return',
    fieldPlacaVeiculo: 'Vehicle plate',
    fieldClienteId: 'Customer',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LocadoraLocacoesCadastroBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.novaLocacao = undefined;
        this.clienteValidacao = undefined;
        this.veiculoDisponibilidade = undefined;
        this.status = '';
        this.msg = messages['en'];
        // ── form submit handlers (one per write routine that originates from a form) ──
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, {
            // mode: pendingLoad ? 'blocking' : 'silent',
            mode: 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
    }
    async loadInitialData(_params, options) {
        await this.loadCreateLocacao(undefined, options);
    }
    // ── load methods (one per read routine) ──
    async loadCreateLocacao(params, options) {
        this.status = this.msg.loadingCreateLocacao;
        if (window.mls) {
            this.novaLocacao = {
                dataRetirada: '2026-06-01',
                dataDevolucao: '2026-06-05',
                valorDiario: 149.9,
                seguroOpcional: true,
                formaPagamento: 'cartao_credito',
                devolucaoPrevista: '2026-06-05T18:00:00',
                placaVeiculo: 'ABC1D23',
                cpf: '123.456.789-09',
            };
            this.status = '';
            return;
        }
        else {
            const response = await execBff('locadora.locacoesCadastro.createLocacao', params, options);
            if (!response.ok || !response.data) {
                if (options?.mode === 'blocking') {
                    throw (response.error ??
                        {
                            code: 'UNEXPECTED_ERROR',
                            message: this.msg.couldNotLoad,
                        });
                }
                this.status = this.msg.couldNotLoad;
                this.novaLocacao = undefined;
                return;
            }
            this.novaLocacao = response.data;
            this.status = '';
        }
    }
    async loadValidateCliente(params, options) {
        this.status = this.msg.loadingValidateCliente;
        if (window.mls) {
            this.clienteValidacao = {
                nome: 'Joao Silva',
                cpf: '123.456.789-09',
                cnh: '12345678900',
                telefone: '(11) 98888-7777',
                email: 'joao.silva@exemplo.com',
            };
            this.status = '';
            return;
        }
        else {
            const response = await execBff('locadora.locacoesCadastro.validateCliente', params, options);
            if (!response.ok || !response.data) {
                if (options?.mode === 'blocking') {
                    throw (response.error ??
                        {
                            code: 'UNEXPECTED_ERROR',
                            message: this.msg.couldNotLoad,
                        });
                }
                this.status = this.msg.couldNotLoad;
                this.clienteValidacao = undefined;
                return;
            }
            this.clienteValidacao = response.data;
            this.status = '';
        }
    }
    async loadCheckVeiculoAvailability(params, options) {
        this.status = this.msg.loadingCheckVeiculoAvailability;
        if (window.mls) {
            this.veiculoDisponibilidade = {
                placa: params?.placa || 'DEF4G56',
                modelo: 'Fiat Argo',
                ano: 2023,
                categoria: 'hatch',
                status: 'disponível',
                quilometragem: 28540,
            };
            this.status = '';
            return;
        }
        else {
            const response = await execBff('locadora.locacoesCadastro.checkVeiculoAvailability', params, options);
            if (!response.ok || !response.data) {
                if (options?.mode === 'blocking') {
                    throw (response.error ??
                        {
                            code: 'UNEXPECTED_ERROR',
                            message: this.msg.couldNotLoad,
                        });
                }
                this.status = this.msg.couldNotLoad;
                this.veiculoDisponibilidade = undefined;
                return;
            }
            this.veiculoDisponibilidade = response.data;
            this.status = '';
        }
    }
    // ── action methods (one per write routine) ──
    async cancel(params, signal) {
        if (window.mls) {
            console.log('[mls mock] ui.locacoesCadastro.cancel', params);
            this.status = this.msg.savedSuccessfully;
            return;
        }
        // No backend routine specified for cancel in the page spec.
        // Keep as a no-op action with local status.
        if (signal?.aborted)
            return;
        this.status = '';
    }
    async handleCancelClick() {
        const params = {};
        void runBlockingUiAction(async (signal) => {
            await this.cancel(params, signal);
        }, {
            busyLabel: this.msg.confirming,
            errorTitle: this.msg.couldNotSave,
            retry: () => this.cancel(params),
        });
    }
    async save(params, options) {
        if (window.mls) {
            console.log('[mls mock] locadora.locacoesCadastro.save', params);
            this.status = this.msg.savedSuccessfully;
            await this.loadCreateLocacao(undefined, { mode: 'silent' });
            return;
        }
        const response = await execBff('locadora.locacoesCadastro.save', params, options);
        if (!response.ok) {
            if (options?.mode === 'blocking') {
                throw (response.error ??
                    {
                        code: 'UNEXPECTED_ERROR',
                        message: this.msg.couldNotSave,
                    });
            }
            this.status = this.msg.couldNotSave;
            return;
        }
        this.status = this.msg.savedSuccessfully;
        await this.loadCreateLocacao(undefined, { mode: 'silent', signal: options?.signal });
    }
    async handleSaveSubmit(event) {
        event.preventDefault();
        // Expect form controls to be named following the field ids; adjust in the view layer as needed.
        const form = event.currentTarget;
        const fd = new FormData(form);
        const params = {
            dataRetirada: String(fd.get('dataRetirada') ?? ''),
            dataDevolucao: String(fd.get('dataDevolucao') ?? ''),
            valorDiario: Number(fd.get('valorDiario') ?? 0),
            seguroOpcional: String(fd.get('seguroOpcional') ?? '') === 'true' || fd.get('seguroOpcional') === 'on',
            formaPagamento: String(fd.get('formaPagamento') ?? ''),
            devolucaoPrevista: String(fd.get('devolucaoPrevista') ?? ''),
            placaVeiculo: String(fd.get('placaVeiculo') ?? ''),
            cpf: String(fd.get('clienteId') ?? ''),
        };
        void runBlockingUiAction(async (signal) => {
            await this.save(params, { mode: 'blocking', signal });
        }, {
            busyLabel: this.msg.saving,
            errorTitle: this.msg.couldNotSave,
            retry: () => this.save(params, { mode: 'blocking' }),
        });
    }
    async validateCliente(params, signal) {
        await this.loadValidateCliente(params, { mode: 'blocking', signal });
    }
    async handleValidateClienteClick(cpf) {
        const params = { cpf };
        void runBlockingUiAction(async (signal) => {
            await this.validateCliente(params, signal);
        }, {
            busyLabel: this.msg.loadingValidateCliente,
            errorTitle: this.msg.couldNotLoad,
            retry: () => this.validateCliente(params),
        });
    }
    async checkVeiculo(params, signal) {
        await this.loadCheckVeiculoAvailability(params, { mode: 'blocking', signal });
    }
    async handleCheckVeiculoClick(placa) {
        const params = { placa };
        void runBlockingUiAction(async (signal) => {
            await this.checkVeiculo(params, signal);
        }, {
            busyLabel: this.msg.loadingCheckVeiculoAvailability,
            errorTitle: this.msg.couldNotLoad,
            retry: () => this.checkVeiculo(params),
        });
    }
}
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "novaLocacao", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "clienteValidacao", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "veiculoDisponibilidade", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "status", void 0);
