/// <mls fileReference="_102035_/l2/locadora/web/shared/locacoesCadastro.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState, initState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Locadora',
    pageTitle: 'Cadastro de locacoes',
    pageSubtitle: 'Registrar nova locacao com validacoes de cliente e disponibilidade do veiculo.',
    loadingCreateLocacao: 'Carregando dados da nova locacao...',
    loadingValidateCliente: 'Validando cliente...',
    loadingCheckVeiculoAvailability: 'Verificando disponibilidade do veiculo...',
    couldNotLoad: 'Nao foi possivel carregar os dados.',
    couldNotSave: 'Nao foi possivel salvar a locacao.',
    savedSuccessfully: 'Locacao salva com sucesso.',
    reload: 'Recarregar',
    save: 'Salvar',
    saving: 'Salvando...',
    confirm: 'Confirmar',
    confirming: 'Confirmando...',
    // Form labels
    labelDataRetirada: 'Data de retirada',
    labelDataDevolucao: 'Data de devolucao',
    labelValorDiario: 'Valor diario',
    labelSeguroOpcional: 'Seguro opcional',
    labelFormaPagamento: 'Forma de pagamento',
    labelDevolucaoPrevista: 'Devolucao prevista',
    labelPlacaVeiculo: 'Placa do veiculo',
    labelCpf: 'CPF',
    // Validation / availability labels
    labelClienteNome: 'Nome do cliente',
    labelClienteCpf: 'CPF',
    labelClienteCnh: 'CNH',
    labelClienteTelefone: 'Telefone',
    labelClienteEmail: 'E-mail',
    labelVeiculoPlaca: 'Placa',
    labelVeiculoModelo: 'Modelo',
    labelVeiculoAno: 'Ano',
    labelVeiculoCategoria: 'Categoria',
    labelVeiculoStatus: 'Status',
    labelVeiculoQuilometragem: 'Quilometragem',
};
const message_en = {
    brand: 'Car Rental',
    pageTitle: 'Rental registration',
    pageSubtitle: 'Register a new rental with customer validation and vehicle availability checks.',
    loadingCreateLocacao: 'Loading new rental data...',
    loadingValidateCliente: 'Validating customer...',
    loadingCheckVeiculoAvailability: 'Checking vehicle availability...',
    couldNotLoad: 'Could not load data.',
    couldNotSave: 'Could not save the rental.',
    savedSuccessfully: 'Rental saved successfully.',
    reload: 'Reload',
    save: 'Save',
    saving: 'Saving...',
    confirm: 'Confirm',
    confirming: 'Confirming...',
    // Form labels
    labelDataRetirada: 'Pickup date',
    labelDataDevolucao: 'Return date',
    labelValorDiario: 'Daily rate',
    labelSeguroOpcional: 'Optional insurance',
    labelFormaPagamento: 'Payment method',
    labelDevolucaoPrevista: 'Expected return',
    labelPlacaVeiculo: 'Vehicle plate',
    labelCpf: 'CPF',
    // Validation / availability labels
    labelClienteNome: 'Customer name',
    labelClienteCpf: 'CPF',
    labelClienteCnh: 'Driver license',
    labelClienteTelefone: 'Phone',
    labelClienteEmail: 'Email',
    labelVeiculoPlaca: 'Plate',
    labelVeiculoModelo: 'Model',
    labelVeiculoAno: 'Year',
    labelVeiculoCategoria: 'Category',
    labelVeiculoStatus: 'Status',
    labelVeiculoQuilometragem: 'Mileage',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LocadoraLocacoesCadastroBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'db.locacoesCadastro.novaLocacao',
            'db.locacoesCadastro.clienteValidacao',
            'db.locacoesCadastro.veiculoDisponibilidade',
            'ui.locacoesCadastro.form.dataRetirada',
            'ui.locacoesCadastro.form.dataDevolucao',
            'ui.locacoesCadastro.form.valorDiario',
            'ui.locacoesCadastro.form.seguroOpcional',
            'ui.locacoesCadastro.form.formaPagamento',
            'ui.locacoesCadastro.form.devolucaoPrevista',
            'ui.locacoesCadastro.form.clienteSelecionado',
            'ui.locacoesCadastro.form.veiculoSelecionado',
            'ui.locacoesCadastro.form.erroValidacao',
            'ui.locacoesCadastro.clienteValidation.cpfValido',
            'ui.locacoesCadastro.clienteValidation.cnhValida',
            'ui.locacoesCadastro.clienteValidation.mensagemErro',
            'ui.locacoesCadastro.veiculoAvailability.disponivel',
            'ui.locacoesCadastro.veiculoAvailability.alertaExibido',
            'ui.locacoesCadastro.veiculoAvailability.mensagemAlerta',
            'ui.locacoesCadastro.formDirty',
            'ui.locacoesCadastro.confirmacaoAberta',
            'ui.locacoesCadastro.erroGeral',
            '*ui.locacoesCadastro.save',
            '*ui.locacoesCadastro.validateCliente',
            '*ui.locacoesCadastro.checkVeiculo',
            '*ui.locacoesCadastro.cancel',
        ];
        this.novaLocacao = undefined;
        this.clienteValidacao = undefined;
        this.veiculoDisponibilidade = undefined;
        this.status = '';
        // tempStates (form)
        this.dataRetirada = '';
        this.dataDevolucao = '';
        this.valorDiario = 0;
        this.seguroOpcional = false;
        this.formaPagamento = '';
        this.devolucaoPrevista = '';
        this.clienteSelecionado = '';
        this.veiculoSelecionado = '';
        this.erroValidacao = '';
        // tempStates (validations)
        this.cpfValido = false;
        this.cnhValida = false;
        this.mensagemErro = '';
        // tempStates (availability)
        this.disponivel = false;
        this.alertaExibido = false;
        this.mensagemAlerta = '';
        // page tempStates
        this.formDirty = false;
        this.confirmacaoAberta = false;
        this.erroGeral = '';
        // actionStates
        this.save = 'idle';
        this.validateCliente = 'idle';
        this.checkVeiculo = 'idle';
        this.cancel = 'idle';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, {
            // mode: pendingLoad ? 'blocking' : 'silent',
            mode: 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        // initState for tempStates with initialValue
        initState('ui.locacoesCadastro.form.dataRetirada', '');
        initState('ui.locacoesCadastro.form.dataDevolucao', '');
        initState('ui.locacoesCadastro.form.valorDiario', 0);
        initState('ui.locacoesCadastro.form.seguroOpcional', false);
        initState('ui.locacoesCadastro.form.formaPagamento', '');
        initState('ui.locacoesCadastro.form.devolucaoPrevista', '');
        initState('ui.locacoesCadastro.form.clienteSelecionado', '');
        initState('ui.locacoesCadastro.form.veiculoSelecionado', '');
        initState('ui.locacoesCadastro.form.erroValidacao', '');
        initState('ui.locacoesCadastro.clienteValidation.cpfValido', false);
        initState('ui.locacoesCadastro.clienteValidation.cnhValida', false);
        initState('ui.locacoesCadastro.clienteValidation.mensagemErro', '');
        initState('ui.locacoesCadastro.veiculoAvailability.disponivel', false);
        initState('ui.locacoesCadastro.veiculoAvailability.alertaExibido', false);
        initState('ui.locacoesCadastro.veiculoAvailability.mensagemAlerta', '');
        initState('ui.locacoesCadastro.formDirty', false);
        initState('ui.locacoesCadastro.confirmacaoAberta', false);
        initState('ui.locacoesCadastro.erroGeral', '');
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'db.locacoesCadastro.novaLocacao':
                this.novaLocacao = value ?? undefined;
                break;
            case 'db.locacoesCadastro.clienteValidacao':
                this.clienteValidacao = value ?? undefined;
                break;
            case 'db.locacoesCadastro.veiculoDisponibilidade':
                this.veiculoDisponibilidade = value ?? undefined;
                break;
            case 'ui.locacoesCadastro.form.dataRetirada':
                this.dataRetirada = value ?? '';
                break;
            case 'ui.locacoesCadastro.form.dataDevolucao':
                this.dataDevolucao = value ?? '';
                break;
            case 'ui.locacoesCadastro.form.valorDiario':
                this.valorDiario = value ?? 0;
                break;
            case 'ui.locacoesCadastro.form.seguroOpcional':
                this.seguroOpcional = value ?? false;
                break;
            case 'ui.locacoesCadastro.form.formaPagamento':
                this.formaPagamento = value ?? '';
                break;
            case 'ui.locacoesCadastro.form.devolucaoPrevista':
                this.devolucaoPrevista = value ?? '';
                break;
            case 'ui.locacoesCadastro.form.clienteSelecionado':
                this.clienteSelecionado = value ?? '';
                break;
            case 'ui.locacoesCadastro.form.veiculoSelecionado':
                this.veiculoSelecionado = value ?? '';
                break;
            case 'ui.locacoesCadastro.form.erroValidacao':
                this.erroValidacao = value ?? '';
                break;
            case 'ui.locacoesCadastro.clienteValidation.cpfValido':
                this.cpfValido = value ?? false;
                break;
            case 'ui.locacoesCadastro.clienteValidation.cnhValida':
                this.cnhValida = value ?? false;
                break;
            case 'ui.locacoesCadastro.clienteValidation.mensagemErro':
                this.mensagemErro = value ?? '';
                break;
            case 'ui.locacoesCadastro.veiculoAvailability.disponivel':
                this.disponivel = value ?? false;
                break;
            case 'ui.locacoesCadastro.veiculoAvailability.alertaExibido':
                this.alertaExibido = value ?? false;
                break;
            case 'ui.locacoesCadastro.veiculoAvailability.mensagemAlerta':
                this.mensagemAlerta = value ?? '';
                break;
            case 'ui.locacoesCadastro.formDirty':
                this.formDirty = value ?? false;
                break;
            case 'ui.locacoesCadastro.confirmacaoAberta':
                this.confirmacaoAberta = value ?? false;
                break;
            case 'ui.locacoesCadastro.erroGeral':
                this.erroGeral = value ?? '';
                break;
            case '*ui.locacoesCadastro.save':
                this.save = value ?? 'idle';
                break;
            case '*ui.locacoesCadastro.validateCliente':
                this.validateCliente = value ?? 'idle';
                break;
            case '*ui.locacoesCadastro.checkVeiculo':
                this.checkVeiculo = value ?? 'idle';
                break;
            case '*ui.locacoesCadastro.cancel':
                this.cancel = value ?? 'idle';
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadCreateLocacao(params, options);
        if (this.clienteSelecionado) {
            await this.loadValidateCliente({ clienteId: this.clienteSelecionado }, options);
        }
        if (this.veiculoSelecionado) {
            await this.loadCheckVeiculoAvailability({ placa: this.veiculoSelecionado }, options);
        }
    }
    // ── load methods (one per read routine) ──
    async loadCreateLocacao(params, options) {
        this.status = this.msg.loadingCreateLocacao;
        if (window.mls) {
            const mock = {
                dataRetirada: '2026-06-10',
                dataDevolucao: '2026-06-15',
                valorDiario: 189.9,
                seguroOpcional: true,
                formaPagamento: 'cartao_credito',
                devolucaoPrevista: '2026-06-15T10:00:00',
                placaVeiculo: 'ABC1D23',
                cpf: '123.456.789-09',
            };
            this.novaLocacao = mock;
            setState('db.locacoesCadastro.novaLocacao', mock);
            this.status = '';
            return;
        }
        const response = await execBff('locadora.locacoesCadastro.createLocacao', (params ?? {}), options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            this.novaLocacao = undefined;
            setState('db.locacoesCadastro.novaLocacao', undefined);
            return;
        }
        this.novaLocacao = response.data ?? undefined;
        setState('db.locacoesCadastro.novaLocacao', this.novaLocacao);
        this.status = '';
    }
    async loadValidateCliente(params, options) {
        this.status = this.msg.loadingValidateCliente;
        const effectiveParams = {
            clienteId: params?.clienteId ?? this.clienteSelecionado,
        };
        if (window.mls) {
            const mock = {
                nome: 'Joao Silva',
                cpf: '123.456.789-09',
                cnh: '12345678900',
                telefone: '(11) 98888-7777',
                email: 'joao.silva@email.com',
            };
            this.clienteValidacao = mock;
            setState('db.locacoesCadastro.clienteValidacao', mock);
            this.status = '';
            return;
        }
        const response = await execBff('locadora.locacoesCadastro.validateCliente', effectiveParams, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            this.clienteValidacao = undefined;
            setState('db.locacoesCadastro.clienteValidacao', undefined);
            return;
        }
        this.clienteValidacao = response.data ?? undefined;
        setState('db.locacoesCadastro.clienteValidacao', this.clienteValidacao);
        this.status = '';
    }
    async loadCheckVeiculoAvailability(params, options) {
        this.status = this.msg.loadingCheckVeiculoAvailability;
        const effectiveParams = {
            placa: params?.placa ?? this.veiculoSelecionado,
        };
        if (window.mls) {
            const mock = {
                placa: effectiveParams.placa || 'DEF4G56',
                modelo: 'Fiat Argo',
                ano: 2023,
                categoria: 'hatch',
                status: 'disponível',
                quilometragem: 35210,
            };
            this.veiculoDisponibilidade = mock;
            setState('db.locacoesCadastro.veiculoDisponibilidade', mock);
            this.status = '';
            return;
        }
        const response = await execBff('locadora.locacoesCadastro.checkVeiculoAvailability', effectiveParams, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            this.veiculoDisponibilidade = undefined;
            setState('db.locacoesCadastro.veiculoDisponibilidade', undefined);
            return;
        }
        this.veiculoDisponibilidade = response.data ?? undefined;
        setState('db.locacoesCadastro.veiculoDisponibilidade', this.veiculoDisponibilidade);
        this.status = '';
    }
    // ── action methods (one per write routine) ──
    async saveLocacao(params, signal) {
        setState('ui.locacoesCadastro.save', 'loading');
        this.status = this.msg.saving;
        try {
            if (window.mls) {
                console.log('[mls mock] locadora.locacoesCadastro.save', params);
                this.status = this.msg.savedSuccessfully;
                setState('ui.locacoesCadastro.save', 'success');
                // refresh reads
                await this.loadCreateLocacao(undefined, { mode: 'silent', signal });
                return;
            }
            const response = await execBff('locadora.locacoesCadastro.save', params, { mode: 'blocking', signal });
            if (!response.ok) {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotSave,
                });
            }
            this.status = this.msg.savedSuccessfully;
            setState('ui.locacoesCadastro.save', 'success');
            await this.loadCreateLocacao(undefined, { mode: 'silent', signal });
            await this.loadValidateCliente({ clienteId: this.clienteSelecionado }, { mode: 'silent', signal });
            await this.loadCheckVeiculoAvailability({ placa: this.veiculoSelecionado }, { mode: 'silent', signal });
        }
        catch (e) {
            setState('ui.locacoesCadastro.save', 'error');
            this.status = this.msg.couldNotSave;
            throw e;
        }
    }
    handleSaveLocacaoSubmit(event) {
        event.preventDefault();
        const params = {
            dataRetirada: this.dataRetirada,
            dataDevolucao: this.dataDevolucao,
            valorDiario: this.valorDiario,
            seguroOpcional: this.seguroOpcional,
            formaPagamento: this.formaPagamento,
            devolucaoPrevista: this.devolucaoPrevista,
            placaVeiculo: this.veiculoSelecionado || (this.novaLocacao?.placaVeiculo ?? ''),
            cpf: this.clienteSelecionado || (this.novaLocacao?.cpf ?? ''),
        };
        void runBlockingUiAction(async (signal) => {
            await this.saveLocacao(params, signal);
        }, {
            busyLabel: this.msg.saving,
            errorTitle: this.msg.couldNotSave,
            retry: () => this.saveLocacao(params),
        });
    }
}
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "novaLocacao", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "clienteValidacao", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "veiculoDisponibilidade", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "status", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "dataRetirada", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "dataDevolucao", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "valorDiario", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "seguroOpcional", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "formaPagamento", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "devolucaoPrevista", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "clienteSelecionado", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "veiculoSelecionado", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "erroValidacao", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "cpfValido", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "cnhValida", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "mensagemErro", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "disponivel", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "alertaExibido", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "mensagemAlerta", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "formDirty", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "confirmacaoAberta", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "erroGeral", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "save", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "validateCliente", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "checkVeiculo", void 0);
__decorate([
    property()
], LocadoraLocacoesCadastroBase.prototype, "cancel", void 0);
