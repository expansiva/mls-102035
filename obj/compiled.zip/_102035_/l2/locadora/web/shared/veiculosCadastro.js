/// <mls fileReference="_102035_/l2/locadora/web/shared/veiculosCadastro.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState, initState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Locadora',
    pageTitle: 'Cadastro de veiculos',
    pageSubtitle: 'Cadastrar veiculo da frota com dados obrigatorios.',
    loadingStatusOptions: 'Carregando opcoes de status...',
    couldNotLoad: 'Nao foi possivel carregar os dados.',
    couldNotSave: 'Nao foi possivel salvar.',
    savedSuccessfully: 'Salvo com sucesso.',
    reload: 'Recarregar',
    save: 'Salvar',
    saving: 'Salvando...',
    placa: 'Placa',
    modelo: 'Modelo',
    ano: 'Ano',
    categoria: 'Categoria',
    status: 'Status',
    quilometragem: 'Quilometragem',
};
const message_en = {
    brand: 'Car rental',
    pageTitle: 'Vehicle registration',
    pageSubtitle: 'Register a fleet vehicle with required data.',
    loadingStatusOptions: 'Loading status options...',
    couldNotLoad: 'Could not load data.',
    couldNotSave: 'Could not save.',
    savedSuccessfully: 'Saved successfully.',
    reload: 'Reload',
    save: 'Save',
    saving: 'Saving...',
    placa: 'Plate',
    modelo: 'Model',
    ano: 'Year',
    categoria: 'Category',
    status: 'Status',
    quilometragem: 'Mileage',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LocadoraVeiculosCadastroBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'db.veiculo.placa',
            'db.veiculo.modelo',
            'db.veiculo.ano',
            'db.veiculo.categoria',
            'db.veiculo.status',
            'db.veiculo.quilometragem',
            'config.locadora.statusVeiculoOptions',
            'ui.veiculosCadastro.form.errors',
            'ui.veiculosCadastro.form.dirty',
            'ui.veiculosCadastro.statusOptions',
            '*ui.veiculosCadastro.saveVeiculo',
            '*ui.veiculosCadastro.loadStatusOptions',
        ];
        this.placa = '';
        this.modelo = '';
        this.ano = 0;
        this.categoria = '';
        this.statusVeiculo = '';
        this.quilometragem = 0;
        this.statusVeiculoOptions = undefined;
        this.formErrors = {};
        this.formDirty = false;
        this.statusOptions = [];
        this.saveVeiculo = 'idle';
        this.loadStatusOptions = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, {
            mode: 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        initState('ui.veiculosCadastro.form.dirty', false);
        initState('ui.veiculosCadastro.statusOptions', ['disponível', 'locado', 'manutenção']);
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach((key) => {
            const k = key.startsWith('*') ? key.slice(1) : key;
            const v = getState(k);
            if (v !== undefined)
                this.handleIcaStateChange(k, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'db.veiculo.placa':
                this.placa = value ?? '';
                break;
            case 'db.veiculo.modelo':
                this.modelo = value ?? '';
                break;
            case 'db.veiculo.ano':
                this.ano = value ?? 0;
                break;
            case 'db.veiculo.categoria':
                this.categoria = value ?? '';
                break;
            case 'db.veiculo.status':
                this.statusVeiculo = value ?? '';
                break;
            case 'db.veiculo.quilometragem':
                this.quilometragem = value ?? 0;
                break;
            case 'config.locadora.statusVeiculoOptions':
                this.statusVeiculoOptions = value ?? undefined;
                break;
            case 'ui.veiculosCadastro.form.errors':
                this.formErrors = value ?? {};
                break;
            case 'ui.veiculosCadastro.form.dirty':
                this.formDirty = value ?? false;
                break;
            case 'ui.veiculosCadastro.statusOptions':
                this.statusOptions = value ?? [];
                break;
            case 'ui.veiculosCadastro.saveVeiculo':
                this.saveVeiculo = value ?? 'idle';
                break;
            case 'ui.veiculosCadastro.loadStatusOptions':
                this.loadStatusOptions = value ?? 'idle';
                break;
            default:
                break;
        }
    }
    async loadInitialData(_params, options) {
        await this.loadGetStatusVeiculoOptions(undefined, options);
    }
    async loadGetStatusVeiculoOptions(_params, options) {
        setState('ui.veiculosCadastro.loadStatusOptions', 'loading');
        try {
            if (window.mls) {
                const mockValues = ['disponível', 'locado', 'manutenção'];
                this.statusVeiculoOptions = { values: mockValues };
                this.statusOptions = [...mockValues];
                setState('config.locadora.statusVeiculoOptions', this.statusVeiculoOptions);
                setState('ui.veiculosCadastro.statusOptions', this.statusOptions);
                this.status = `${this.statusOptions.length} ${this.msg.status}`;
                setState('ui.veiculosCadastro.loadStatusOptions', 'success');
                return;
            }
            const response = await execBff('locadora.veiculosCadastro.getStatusVeiculoOptions', _params, options);
            if (!response.ok || !response.data) {
                setState('ui.veiculosCadastro.loadStatusOptions', 'error');
                if (options?.mode === 'blocking') {
                    throw (response.error ?? {
                        code: 'UNEXPECTED_ERROR',
                        message: this.msg.couldNotLoad,
                    });
                }
                this.status = this.msg.couldNotLoad;
                this.statusVeiculoOptions = undefined;
                this.statusOptions = [];
                setState('config.locadora.statusVeiculoOptions', this.statusVeiculoOptions);
                setState('ui.veiculosCadastro.statusOptions', this.statusOptions);
                return;
            }
            this.statusVeiculoOptions = response.data;
            this.statusOptions = [...(response.data.values ?? [])];
            setState('config.locadora.statusVeiculoOptions', this.statusVeiculoOptions);
            setState('ui.veiculosCadastro.statusOptions', this.statusOptions);
            this.status = `${this.statusOptions.length} ${this.msg.status}`;
            setState('ui.veiculosCadastro.loadStatusOptions', 'success');
        }
        catch (e) {
            setState('ui.veiculosCadastro.loadStatusOptions', 'error');
            throw e;
        }
    }
    async saveVeiculoAction(params, signal) {
        setState('ui.veiculosCadastro.saveVeiculo', 'loading');
        try {
            if (window.mls) {
                console.log('[mls mock] locadora.veiculosCadastro.saveVeiculo', params);
                this.status = this.msg.savedSuccessfully;
                setState('ui.veiculosCadastro.saveVeiculo', 'success');
                return;
            }
            const response = await execBff('locadora.veiculosCadastro.saveVeiculo', params, { mode: 'blocking', signal });
            if (!response.ok || !response.data) {
                setState('ui.veiculosCadastro.saveVeiculo', 'error');
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotSave,
                });
            }
            this.status = this.msg.savedSuccessfully;
            setState('ui.veiculosCadastro.saveVeiculo', 'success');
            // Refresh dependent data if needed
            await this.loadGetStatusVeiculoOptions(undefined, { mode: 'silent', signal });
        }
        catch (e) {
            setState('ui.veiculosCadastro.saveVeiculo', 'error');
            throw e;
        }
    }
    handleSaveVeiculoSubmit(event) {
        event.preventDefault();
        const params = {
            placa: this.placa,
            modelo: this.modelo,
            ano: this.ano,
            categoria: this.categoria,
            status: this.statusVeiculo || undefined,
            quilometragem: this.quilometragem,
            author: 'admin',
        };
        void runBlockingUiAction(async (signal) => {
            await this.saveVeiculoAction(params, signal);
        }, {
            busyLabel: this.msg.saving,
            errorTitle: this.msg.couldNotSave,
            retry: () => this.saveVeiculoAction(params),
        });
    }
}
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "placa", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "modelo", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "ano", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "categoria", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "statusVeiculo", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "quilometragem", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "statusVeiculoOptions", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "formErrors", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "formDirty", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "statusOptions", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "saveVeiculo", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "loadStatusOptions", void 0);
__decorate([
    property()
], LocadoraVeiculosCadastroBase.prototype, "status", void 0);
