/// <mls fileReference="_102035_/l2/locadora/web/shared/veiculosCadastro.ts" enhancement="_blank" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Locadora',
    pageTitle: 'Cadastro de veiculos',
    pageSubtitle: 'Cadastrar veiculo da frota com dados obrigatorios.',
    loadingStatusVeiculoOptions: 'Carregando opcoes de status do veiculo...',
    couldNotLoad: 'Nao foi possivel carregar os dados.',
    couldNotSave: 'Nao foi possivel salvar o veiculo.',
    savedSuccessfully: 'Veiculo salvo com sucesso.',
    reload: 'Recarregar',
    save: 'Salvar',
    saving: 'Salvando...',
    placa: 'Placa',
    modelo: 'Modelo',
    ano: 'Ano',
    categoria: 'Categoria',
    status: 'Status',
    quilometragem: 'Quilometragem',
};
const message_en = {
    brand: 'Car rental',
    pageTitle: 'Vehicle registration',
    pageSubtitle: 'Register a fleet vehicle with required data.',
    loadingStatusVeiculoOptions: 'Loading vehicle status options...',
    couldNotLoad: 'Could not load data.',
    couldNotSave: 'Could not save vehicle.',
    savedSuccessfully: 'Vehicle saved successfully.',
    reload: 'Reload',
    save: 'Save',
    saving: 'Saving...',
    placa: 'License plate',
    modelo: 'Model',
    ano: 'Year',
    categoria: 'Category',
    status: 'Status',
    quilometragem: 'Mileage',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LocadoraVeiculosCadastroBase extends CollabLitElement {
    constructor() {
        super();
        this.msg = messages['en'];
        this.statusVeiculoOptions = [];
        this.placa = '';
        this.modelo = '';
        this.ano = undefined;
        this.categoria = '';
        this.statusVeiculo = '';
        this.quilometragem = undefined;
        this.formErrors = {};
        this.formDirty = false;
        this.status = '';
    }
    createRenderRoot() { return this; }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, {
            // mode: pendingLoad ? 'blocking' : 'silent',
            mode: 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
    }
    async loadInitialData(_params, options) {
        await this.loadGetStatusVeiculoOptions(undefined, options);
    }
    // ── load methods (one per read routine) ──
    async loadGetStatusVeiculoOptions(_params, options) {
        this.status = this.msg.loadingStatusVeiculoOptions;
        this.statusVeiculoOptions = ['disponivel', 'locado', 'manutencao'];
        this.status = '';
        return;
    }
    // ── action methods (one per write routine) ──
    async save(params, signal) {
        const options = signal ? { mode: 'blocking', signal } : { mode: 'blocking' };
        if (window.mls) {
            console.log('[mls mock] locadora.veiculosCadastro.saveVeiculo', params);
            this.status = this.msg.savedSuccessfully;
            return;
        }
        const response = await execBff('locadora.veiculosCadastro.saveVeiculo', params, options);
        if (!response.ok) {
            throw (response.error ?? {
                code: 'UNEXPECTED_ERROR',
                message: this.msg.couldNotSave,
            });
        }
        this.status = this.msg.savedSuccessfully;
        await this.loadGetStatusVeiculoOptions(undefined, { mode: 'silent' });
    }
    // ── form submit handlers (one per write routine that originates from a form) ──
    handleSaveSubmit(event) {
        event.preventDefault();
        const params = {
            placa: this.placa,
            modelo: this.modelo,
            ano: this.ano,
            categoria: this.categoria,
            status: this.statusVeiculo,
            quilometragem: this.quilometragem,
        };
        void runBlockingUiAction(async (signal) => { await this.save(params, signal); }, {
            busyLabel: this.msg.saving,
            errorTitle: this.msg.couldNotSave,
            retry: () => this.save(params),
        });
    }
}
LocadoraVeiculosCadastroBase.properties = {
    statusVeiculoOptions: { state: true },
    placa: { state: true },
    modelo: { state: true },
    ano: { state: true },
    categoria: { state: true },
    statusVeiculo: { state: true },
    quilometragem: { state: true },
    formErrors: { state: true },
    formDirty: { state: true },
    status: { state: true },
};
