/// <mls fileReference="_102035_/l2/locadora/web/shared/adminDashboard.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState, initState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Locadora',
    pageTitle: 'adminDashboard',
    pageSubtitle: 'Acesso as areas de frota, clientes e locacoes para cadastro e consulta.',
    loadingQuickAccess: 'Carregando atalhos...',
    loadingSummary: 'Carregando resumo...',
    couldNotLoad: 'Nao foi possivel carregar os dados.',
    reload: 'Recarregar',
    save: 'Salvar',
    saving: 'Salvando...',
    confirm: 'Confirmar',
    confirming: 'Confirmando...',
    itemsAvailable: 'itens disponiveis',
    fieldHoveredCard: 'Cartao em foco',
    fieldFilterStatus: 'Status do veiculo',
};
const message_en = {
    brand: 'Car Rental',
    pageTitle: 'adminDashboard',
    pageSubtitle: 'Access to fleet, customers and rentals areas for registration and lookup.',
    loadingQuickAccess: 'Loading shortcuts...',
    loadingSummary: 'Loading summary...',
    couldNotLoad: 'Could not load data.',
    reload: 'Reload',
    save: 'Save',
    saving: 'Saving...',
    confirm: 'Confirm',
    confirming: 'Confirming...',
    itemsAvailable: 'items available',
    fieldHoveredCard: 'Focused card',
    fieldFilterStatus: 'Vehicle status',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LocadoraAdminDashboardBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'db.adminDashboard.quickAccess',
            'db.adminDashboard.summary',
            'ui.adminDashboard.quickAccess.hoveredCard',
            'ui.adminDashboard.summary.filterStatus',
            'ui.adminDashboard.activeSection',
            '*ui.adminDashboard.load',
        ];
        this.quickAccess = undefined;
        this.summary = undefined;
        this.hoveredCard = '';
        this.filterStatus = 'disponível';
        this.activeSection = 'main';
        this.load = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, {
            // mode: pendingLoad ? 'blocking' : 'silent',
            mode: 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        initState('ui.adminDashboard.quickAccess.hoveredCard', '');
        initState('ui.adminDashboard.summary.filterStatus', 'disponível');
        initState('ui.adminDashboard.activeSection', 'main');
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach((key) => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'db.adminDashboard.quickAccess':
                this.quickAccess = value ?? undefined;
                break;
            case 'db.adminDashboard.summary':
                this.summary = value ?? undefined;
                break;
            case 'ui.adminDashboard.quickAccess.hoveredCard':
                this.hoveredCard = value ?? '';
                break;
            case 'ui.adminDashboard.summary.filterStatus':
                this.filterStatus = value ?? 'disponível';
                break;
            case 'ui.adminDashboard.activeSection':
                this.activeSection = value ?? 'main';
                break;
            case '*ui.adminDashboard.load':
            case 'ui.adminDashboard.load':
                this.load = value ?? 'idle';
                break;
            default:
                break;
        }
    }
    async loadInitialData(_params, options) {
        setState('ui.adminDashboard.load', 'loading');
        try {
            await this.loadGetQuickAccess(undefined, options);
            await this.loadGetSummary(undefined, options);
            this.status = '';
            setState('ui.adminDashboard.load', 'success');
        }
        catch (e) {
            this.status = this.msg.couldNotLoad;
            setState('ui.adminDashboard.load', 'error');
            throw e;
        }
    }
    // ── load methods ──
    async loadGetQuickAccess(_params, options) {
        this.status = this.msg.loadingQuickAccess;
        if (window.mls) {
            const data = {
                cards: [
                    { id: 'frota', label: 'Gestao de Frota', target: 'gestaoFrotaList' },
                    { id: 'clientes', label: 'Gestao de Clientes', target: 'gestaoClientesList' },
                    { id: 'locacoes', label: 'Gestao de Locacoes', target: 'gestaoLocacoesList' },
                ],
                updatedAt: new Date().toISOString(),
            };
            this.quickAccess = data;
            setState('db.adminDashboard.quickAccess', data);
            this.status = `${data.cards?.length ?? 0} ${this.msg.itemsAvailable}`;
            return;
        }
        const response = await execBff('locadora.adminDashboard.getQuickAccess', _params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ??
                    {
                        code: 'UNEXPECTED_ERROR',
                        message: this.msg.couldNotLoad,
                    });
            }
            this.status = this.msg.couldNotLoad;
            this.quickAccess = undefined;
            return;
        }
        this.quickAccess = response.data ?? undefined;
        setState('db.adminDashboard.quickAccess', this.quickAccess);
        const len = this.quickAccess?.cards?.length ?? 0;
        this.status = `${len} ${this.msg.itemsAvailable}`;
    }
    async loadGetSummary(_params, options) {
        this.status = this.msg.loadingSummary;
        if (window.mls) {
            const veiculos = [
                {
                    placa: 'ABC-1D23',
                    modelo: 'Fiat Argo',
                    ano: 2022,
                    categoria: 'Hatch',
                    status: 'disponível',
                    quilometragem: 32500,
                },
                {
                    placa: 'DEF-4G56',
                    modelo: 'Volkswagen T-Cross',
                    ano: 2021,
                    categoria: 'SUV',
                    status: 'locado',
                    quilometragem: 48700,
                },
                {
                    placa: 'GHI-7J89',
                    modelo: 'Chevrolet Onix',
                    ano: 2020,
                    categoria: 'Sedan',
                    status: 'manutenção',
                    quilometragem: 61200,
                },
            ];
            const clientes = [
                {
                    nome: 'Joao Silva',
                    cpf: '123.456.789-10',
                    cnh: '12345678900',
                    telefone: '(11) 98888-1111',
                    email: 'joao.silva@exemplo.com',
                },
                {
                    nome: 'Maria Oliveira',
                    cpf: '987.654.321-00',
                    cnh: '00987654321',
                    telefone: '(21) 97777-2222',
                    email: 'maria.oliveira@exemplo.com',
                },
            ];
            const locacoes = [
                {
                    dataRetirada: '2026-05-20',
                    dataDevolucao: '2026-05-25',
                    valorDiario: 149.9,
                    seguroOpcional: true,
                    formaPagamento: 'cartao',
                    devolucaoPrevista: '2026-05-25',
                    placaVeiculo: 'DEF-4G56',
                    cpf: '123.456.789-10',
                },
                {
                    dataRetirada: '2026-05-28',
                    dataDevolucao: '2026-06-02',
                    valorDiario: 189.9,
                    seguroOpcional: false,
                    formaPagamento: 'pix',
                    devolucaoPrevista: '2026-06-02',
                    placaVeiculo: 'ABC-1D23',
                    cpf: '987.654.321-00',
                },
            ];
            const data = {
                veiculos,
                clientes,
                locacoes,
            };
            this.summary = data;
            setState('db.adminDashboard.summary', data);
            this.status = `${(veiculos?.length ?? 0) + (clientes?.length ?? 0) + (locacoes?.length ?? 0)} ${this.msg.itemsAvailable}`;
            return;
        }
        const response = await execBff('locadora.adminDashboard.getSummary', _params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ??
                    {
                        code: 'UNEXPECTED_ERROR',
                        message: this.msg.couldNotLoad,
                    });
            }
            this.status = this.msg.couldNotLoad;
            this.summary = undefined;
            return;
        }
        this.summary = response.data ?? undefined;
        setState('db.adminDashboard.summary', this.summary);
        const veiculosLen = this.summary?.veiculos?.length ?? 0;
        const clientesLen = this.summary?.clientes?.length ?? 0;
        const locacoesLen = this.summary?.locacoes?.length ?? 0;
        this.status = `${veiculosLen + clientesLen + locacoesLen} ${this.msg.itemsAvailable}`;
    }
    // No write routines were defined for this page.
    async handleReloadClick() {
        void runBlockingUiAction(async (signal) => {
            await this.loadInitialData(undefined, { mode: 'blocking', signal });
        }, {
            busyLabel: this.msg.loadingSummary,
            errorTitle: this.msg.couldNotLoad,
            retry: () => this.loadInitialData(undefined, { mode: 'blocking' }),
        });
    }
}
__decorate([
    property()
], LocadoraAdminDashboardBase.prototype, "quickAccess", void 0);
__decorate([
    property()
], LocadoraAdminDashboardBase.prototype, "summary", void 0);
__decorate([
    property()
], LocadoraAdminDashboardBase.prototype, "hoveredCard", void 0);
__decorate([
    property()
], LocadoraAdminDashboardBase.prototype, "filterStatus", void 0);
__decorate([
    property()
], LocadoraAdminDashboardBase.prototype, "activeSection", void 0);
__decorate([
    property()
], LocadoraAdminDashboardBase.prototype, "load", void 0);
__decorate([
    property()
], LocadoraAdminDashboardBase.prototype, "status", void 0);
