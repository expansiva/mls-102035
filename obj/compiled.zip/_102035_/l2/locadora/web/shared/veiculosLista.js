/// <mls fileReference="_102035_/l2/locadora/web/shared/veiculosLista.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState, initState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Locadora',
    pageTitle: 'Lista de veiculos',
    pageSubtitle: 'Consultar e filtrar veiculos cadastrados.',
    loadingVeiculos: 'Carregando veiculos...',
    couldNotLoad: 'Nao foi possivel carregar os dados.',
    itemsAvailable: 'itens disponiveis',
    reload: 'Recarregar',
    filterStatus: 'Status',
    placa: 'Placa',
    modelo: 'Modelo',
    ano: 'Ano',
    categoria: 'Categoria',
    status: 'Status',
    quilometragem: 'Quilometragem',
};
const message_en = {
    brand: 'Car Rental',
    pageTitle: 'Vehicles list',
    pageSubtitle: 'Browse and filter registered vehicles.',
    loadingVeiculos: 'Loading vehicles...',
    couldNotLoad: 'Could not load data.',
    itemsAvailable: 'items available',
    reload: 'Reload',
    filterStatus: 'Status',
    placa: 'Plate',
    modelo: 'Model',
    ano: 'Year',
    categoria: 'Category',
    status: 'Status',
    quilometragem: 'Mileage',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LocadoraVeiculosListaBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'db.veiculo.status',
            'db.veiculo[]',
            'ui.veiculosLista.filter.status',
            'ui.veiculosLista.sort.by',
            '*ui.veiculosLista.loading',
            '*ui.veiculosLista.error',
        ];
        this.veiculo = [];
        this.status = '';
        // shape 'fields'
        this.veiculoStatus = '';
        // tempStates
        this.filterStatus = 'todos';
        this.sortBy = 'placa';
        // actionStates
        this.loading = 'idle';
        this.error = 'idle';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, {
            // mode: pendingLoad ? 'blocking' : 'silent',
            mode: 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        initState('ui.veiculosLista.filter.status', 'todos');
        initState('ui.veiculosLista.sort.by', 'placa');
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach((key) => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'db.veiculo.status':
                this.veiculoStatus = value ?? '';
                break;
            case 'db.veiculo[]':
                this.veiculo = value ?? [];
                break;
            case 'ui.veiculosLista.filter.status':
                this.filterStatus = value ?? 'todos';
                break;
            case 'ui.veiculosLista.sort.by':
                this.sortBy = value ?? 'placa';
                break;
            case '*ui.veiculosLista.loading':
                // some runtimes may emit exclusive keys; normalize
                this.loading = value ?? 'idle';
                break;
            case 'ui.veiculosLista.loading':
                this.loading = value ?? 'idle';
                break;
            case '*ui.veiculosLista.error':
                this.error = value ?? 'idle';
                break;
            case 'ui.veiculosLista.error':
                this.error = value ?? 'idle';
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadListVeiculos(params, options);
    }
    // ── load methods ──
    async loadListVeiculos(params, options) {
        const statusParam = params?.status ?? getState('ui.veiculosLista.filter.status') ?? this.filterStatus;
        setState('ui.veiculosLista.loading', 'loading');
        setState('ui.veiculosLista.error', 'idle');
        this.status = this.msg.loadingVeiculos;
        try {
            if (window.mls) {
                const mocked = [
                    {
                        placa: 'ABC1D23',
                        modelo: 'Fiat Argo',
                        ano: 2022,
                        categoria: 'Hatch',
                        status: 'disponível',
                        quilometragem: 35210,
                    },
                    {
                        placa: 'DEF4G56',
                        modelo: 'Chevrolet Onix',
                        ano: 2021,
                        categoria: 'Hatch',
                        status: 'locado',
                        quilometragem: 48700,
                    },
                    {
                        placa: 'HIJ7K89',
                        modelo: 'Volkswagen T-Cross',
                        ano: 2023,
                        categoria: 'SUV',
                        status: 'manutenção',
                        quilometragem: 12990,
                    },
                ];
                const filtered = statusParam && statusParam !== 'todos' ? mocked.filter((v) => v.status === statusParam) : mocked;
                this.veiculo = filtered;
                setState('db.veiculo[]', filtered);
                this.status = `${this.veiculo.length} ${this.msg.itemsAvailable}`;
                setState('ui.veiculosLista.loading', 'success');
                return;
            }
            const response = await execBff('locadora.veiculosLista.listVeiculos', { status: statusParam }, options);
            if (!response.ok || !response.data) {
                setState('ui.veiculosLista.error', 'error');
                setState('ui.veiculosLista.loading', 'error');
                if (options?.mode === 'blocking') {
                    throw (response.error ?? {
                        code: 'UNEXPECTED_ERROR',
                        message: this.msg.couldNotLoad,
                    });
                }
                this.status = this.msg.couldNotLoad;
                this.veiculo = [];
                setState('db.veiculo[]', []);
                return;
            }
            this.veiculo = response.data ?? [];
            setState('db.veiculo[]', this.veiculo);
            this.status = `${this.veiculo.length} ${this.msg.itemsAvailable}`;
            setState('ui.veiculosLista.loading', 'success');
        }
        catch (e) {
            setState('ui.veiculosLista.error', 'error');
            setState('ui.veiculosLista.loading', 'error');
            throw e;
        }
    }
    // ── helpers ──
    handleReloadClick() {
        void runBlockingUiAction(async (signal) => {
            await this.loadListVeiculos(undefined, { mode: 'blocking', signal });
        }, {
            busyLabel: this.msg.loadingVeiculos,
            errorTitle: this.msg.couldNotLoad,
            retry: () => this.loadListVeiculos(),
        });
    }
}
__decorate([
    property()
], LocadoraVeiculosListaBase.prototype, "veiculo", void 0);
__decorate([
    property()
], LocadoraVeiculosListaBase.prototype, "status", void 0);
__decorate([
    property()
], LocadoraVeiculosListaBase.prototype, "veiculoStatus", void 0);
__decorate([
    property()
], LocadoraVeiculosListaBase.prototype, "filterStatus", void 0);
__decorate([
    property()
], LocadoraVeiculosListaBase.prototype, "sortBy", void 0);
__decorate([
    property()
], LocadoraVeiculosListaBase.prototype, "loading", void 0);
__decorate([
    property()
], LocadoraVeiculosListaBase.prototype, "error", void 0);
