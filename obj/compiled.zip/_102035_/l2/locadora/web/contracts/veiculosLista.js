/// <mls fileReference="_102035_/l2/locadora/web/contracts/veiculosLista.ts" enhancement="_blank" />
export {};
