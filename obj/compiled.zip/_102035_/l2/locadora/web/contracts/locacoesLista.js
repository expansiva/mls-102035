/// <mls fileReference="_102035_/l2/locadora/web/contracts/locacoesLista.ts" enhancement="_blank" />
export {};
