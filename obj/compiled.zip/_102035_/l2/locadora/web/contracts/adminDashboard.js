/// <mls fileReference="_102035_/l2/locadora/web/contracts/adminDashboard.ts" enhancement="_blank" />
export {};
