/// <mls fileReference="_102035_/l2/locadora/web/contracts/locacoesCadastro.ts" enhancement="_blank" />
export {};
