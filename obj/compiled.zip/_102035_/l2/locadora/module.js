export const moduleGenome = {
    'web/desktop/page11': {
        designSystem: 'default',
        device: 'desktop',
        layout: 'standard',
    }
};
export const skills = {
    web: {
        sharedPath: '/_102035_/l2/locadora/web/shared',
        sharedSkill: '/_102020_/l2/agents/newModule/skills/genPageShared.ts'
    }
};
export const moduleStates = {};
export const moduleShellPreferences = {
    layout: {
        asideMode: {
            desktop: 'inline',
            mobile: 'fullscreen',
        },
    },
};
export const moduleFrontendDefinition = {
    pageTitle: 'locadora',
    device: 'desktop',
    navigation: [
        {
            id: 'veiculosCadastro',
            label: 'veiculosCadastro',
            href: '/locadora/veiculosCadastro',
            description: 'veiculosCadastro',
        },
        {
            id: 'veiculosLista',
            label: 'veiculosLista',
            href: '/locadora/veiculosLista',
            description: 'veiculosLista',
        },
    ],
    routes: [
        {
            path: '/locadora/veiculosCadastro',
            aliases: [],
            entrypoint: '/_102035_/l2/locadora/web/desktop/page11/veiculosCadastro.js',
            tag: 'locadora--web--desktop--page11--veiculos-cadastro-102035',
            title: 'veiculosCadastro',
        },
        {
            path: '/locadora/veiculosLista',
            aliases: [],
            entrypoint: '/_102035_/l2/locadora/web/desktop/page11/veiculosLista.js',
            tag: 'locadora--web--desktop--page11--veiculos-lista-102035',
            title: 'veiculosLista',
        },
    ],
};
