/// <mls fileReference="_102035_/l2/agentNewSolution/helpers/organizationTypes.ts" enhancement="_blank"/>
export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from '/_102034_/l1/mdm/defs/level1Types.js';
/** Schema of the per-project solution registry written by E10. */
export const NS4_SOLUTION_REGISTRY_SCHEMA_VERSION = 'ns4-solution-registry-v1';
export function ns4RegistryRoleSubtype(role) {
    return role.subtype || role.mdmSubtype || '';
}
export function ns4RegistryRoleTag(role) {
    return role.roleTag || role.role || '';
}
