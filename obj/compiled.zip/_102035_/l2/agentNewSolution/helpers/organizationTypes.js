/// <mls fileReference="_102035_/l2/agentNewSolution/helpers/organizationTypes.ts" enhancement="_blank"/>
/** Schema of the platform level-1 ontology defs. Bumped when the engine subtype set or field shape changes. */
export const NS4_LEVEL1_SCHEMA_VERSION = 'ns4-level1-v1';
/** Schema of the per-project solution registry written by E10. */
export const NS4_SOLUTION_REGISTRY_SCHEMA_VERSION = 'ns4-solution-registry-v1';
/** Closed platform subtype set. Grows only on a platform release, never per module. */
export const NS4_LEVEL1_SUBTYPE_VALUES = [
    'Person', 'Company', 'Product', 'Service', 'Location',
    'AssetGeneric', 'AssetVehicle', 'AssetProperty', 'AssetEquipment',
    'Animal', 'BankAccount', 'Document', 'ContactChannel',
];
