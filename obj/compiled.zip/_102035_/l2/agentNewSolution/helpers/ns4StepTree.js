/** Resolves the open phase that owns dynamically-created New Solution 4 steps. */
export function resolveNs4MutableParent(allSteps, parentStep, phaseStep) {
    const steps = allSteps || [];
    const root = steps[0];
    const current = steps.find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current) && (!phaseStep || current.stepId !== root?.stepId))
        return current;
    const phase = phaseStep && steps.find(item => item.stepId === phaseStep.stepId);
    if (isOpenAgent(phase))
        return phase;
    if (isOpenAgent(current))
        return current;
    const owner = steps.find(candidate => isOpenAgent(candidate)
        && (candidate.nextSteps?.some(child => child.stepId === parentStep.stepId)
            || candidate.interaction?.payload?.some(child => child.stepId === parentStep.stepId)));
    return isOpenAgent(owner) ? owner : isOpenAgent(root) ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
