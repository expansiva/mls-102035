/// <mls fileReference="_102035_/l2/agentNewSolution/helpers/ns4ReviewPolicy.ts" enhancement="_blank"/>
export const NS4_SMART_SKIP_REASON = 'nenhum finding A';
export const NS4_UNAVAILABLE_SMART_SIGNAL = { available: false };
export function isNs4AutomaticCheckpoint(context, module) {
    if (context.task?.iaCompressed?.longMemory?.fastMode === 'true')
        return true;
    return module?.reviewPolicy?.mode === 'automatic';
}
export function decideNs4LaterCheckpoint(context, module, signal = NS4_UNAVAILABLE_SMART_SIGNAL) {
    if (isNs4AutomaticCheckpoint(context, module))
        return { open: false };
    if (module?.reviewPolicy?.mode !== 'smart')
        return { open: true };
    if (!signal.available || signal.classA || signal.classB)
        return { open: true };
    return { open: false, autoReason: NS4_SMART_SKIP_REASON };
}
/** E2 coverage records Type B as systemDecisions; journey policyDecisions are reversible choices. Type A does not reach the checkpoint. */
export function ns4E2SmartSignal(review) {
    return {
        available: true,
        classA: false,
        classB: Boolean(review.systemDecisions?.length)
            || Boolean(review.journeys?.some(journey => journey.policyDecisions?.length)),
    };
}
/**
 * E4 has NO A/B vocabulary: its systemDecisions are Type C label backfills, and nothing else on the
 * review expresses "a human should look at this". That is absence of SIGNAL, not evidence that the
 * ontology is uncontroversial — so the checkpoint OPENS, per the rule "sem sinal, mostra".
 *
 * Reporting `available: true, classA/B: false` instead would hardcode "never open the ontology", and
 * because `smart` is the DEFAULT policy that would quietly remove the entity/enum review from every
 * run. When E4 gains real A/B findings, return them here and it joins the same decider.
 */
export function ns4E4SmartSignal(_review) {
    return NS4_UNAVAILABLE_SMART_SIGNAL;
}
