/// <mls fileReference="_102035_/l2/agentNewSolution/helpers/ns4EntityFields.ts" enhancement="_blank"/>
export const NS4_IDENTITY_FIELD_DESCRIPTION = 'Logical record identity. Required uuid named by storage.idField.';
export function ns4EntityIdField(entity) {
    return entity?.storage?.idField || '';
}
export function ns4ResolvableFields(entity) {
    const declared = [...(entity?.fields ?? [])];
    const idField = ns4EntityIdField(entity);
    if (!idField || declared.some(field => field.fieldId === idField))
        return declared;
    return [...declared, {
            fieldId: idField,
            title: idField,
            type: 'uuid',
            required: true,
            description: NS4_IDENTITY_FIELD_DESCRIPTION,
            constraints: [],
        }];
}
export function ns4ResolvableFieldIds(entity) {
    return new Set(ns4ResolvableFields(entity).map(field => field.fieldId));
}
export function ns4ResolvableFieldOf(entity, fieldId) {
    return ns4ResolvableFields(entity).find(field => field.fieldId === fieldId);
}
/** Compact entity payload for the E4 relationship-binding prompt: exact available fields. */
export function ns4BindingPromptEntity(entity) {
    return {
        entityId: entity.entityId,
        kind: entity.kind,
        storage: entity.storage,
        fields: ns4ResolvableFields(entity).map(field => ({
            fieldId: field.fieldId,
            type: field.type,
            required: field.required,
            description: field.description,
        })),
    };
}
