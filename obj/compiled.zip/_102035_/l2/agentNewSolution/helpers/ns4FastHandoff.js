/// <mls fileReference="_102035_/l2/agentNewSolution/helpers/ns4FastHandoff.ts" enhancement="_blank"/>
/**
 * `/fast` chain + E1 skip. Pure: the finalize step and the E1 after-prompt hook decide from this;
 * sending the thread message is the agent's I/O, not this file's.
 */
export const NS4_FAST_SKIP_REASON = 'fast skipped clarification';
export const NS4_FAST_HANDOFF_PLAN_ID = 'fast-handoff-changeBackend';
export const NS4_FAST_HANDOFF_AGENT = 'agentChangeBackend';
export function isNs4FastMode(longMemory) {
    return longMemory?.fastMode === 'true';
}
export function isNs4NochainMode(longMemory) {
    return longMemory?.nochainMode === 'true';
}
export function ns4NochainSuppressedNote(moduleName) {
    const module = String(moduleName || '').trim();
    return module ? `handoff: suppressed by /nochain — next: @@agentChangeBackend /rebuild all ${module}` : '';
}
export function ns4E1SkippedDefaults(review) {
    return {
        productLanguages: [...review.localization.productLanguages],
        defaultLanguage: review.localization.defaultLanguage,
        moduleName: review.module.moduleName,
        title: review.module.title,
        reviewPolicy: review.reviewPolicy.mode,
        userLanguage: review.userLanguage,
        ...(review.i18nWarnings?.length ? { i18nWarnings: [...review.i18nWarnings] } : {}),
    };
}
export function decideNs4E1Clarification(fast) {
    return fast ? 'skip' : 'open';
}
export function buildNs4ChangeBackendHandoffMessage(moduleName) {
    const module = String(moduleName || '').trim();
    return module ? `@@agentChangeBackend /fast /rebuild all ${module}` : '';
}
export function decideNs4FastHandoff(input) {
    const message = buildNs4ChangeBackendHandoffMessage(input.moduleName);
    if (!input.fast || !input.success || input.alreadyDispatched || !message) {
        return { dispatch: false, message: '', suppressed: false };
    }
    if (input.nochain) {
        const module = String(input.moduleName || '').trim();
        return { dispatch: false, message: `@@agentChangeBackend /rebuild all ${module}`, suppressed: true };
    }
    return { dispatch: true, message, suppressed: false };
}
/**
 * Send + persist the `/fast` handoff. Never throws: a dispatch failure is a recorded
 * degradation so the parent step can complete (the NS work is already on disk).
 */
export async function sendNs4FastHandoff(input) {
    if (!input.threadId) {
        return { dispatched: false, note: '; changeBackend: SKIPPED (no threadId)', degradation: null };
    }
    try {
        await input.send(input.threadId, input.message);
        await input.persist();
        return { dispatched: true, note: `; changeBackend: dispatched (${input.message})`, degradation: null };
    }
    catch (error) {
        const reason = error instanceof Error ? error.message : String(error);
        return {
            dispatched: false,
            note: `; changeBackend: DISPATCH FAILED (${reason}) — re-send manually: ${input.message}`,
            degradation: {
                at: new Date().toISOString(),
                kind: 'fast-handoff-dispatch',
                reason: `${reason} — re-send manually: ${input.message}`,
            },
        };
    }
}
