/// <mls fileReference="_102035_/l2/agentNewSolution/helpers/ns4RebuildAll.ts" enhancement="_blank"/>
import { normalizeNs4ModuleName, } from '/_102035_/l2/agentNewSolution/helpers/ns4Core.js';
/**
 * Exact module-folder prefix: the first path segment, after the same canonicalization every other
 * NS folder uses. Never `includes`, never a loose regex — `listaAssinatura` must not match
 * `listaAssinaturaAntiga`, and `todo` must not match `todoList` or anything else.
 */
export function isNs4ExactModuleFolderPrefix(folder, moduleName) {
    const normalized = normalizeNs4ModuleName(moduleName);
    const first = String(folder || '').split('/').filter(Boolean)[0] || '';
    return !!first && normalizeNs4ModuleName(first) === normalized;
}
export function recoverNs4RebuildAllPrompt(input) {
    const initial = typeof input.initialPrompt === 'string' ? input.initialPrompt.trim() : '';
    if (initial)
        return { ok: true, prompt: initial };
    const source = typeof input.sourcePrompt === 'string' ? input.sourcePrompt.trim() : '';
    if (source)
        return { ok: true, prompt: source };
    return {
        ok: false,
        reason: 'Could not recover the original prompt (neither designContext.initialPrompt in module.defs.ts nor sourcePrompt on the pipeline). Nothing was deleted.',
    };
}
/** l1, l2, l4 and per-module l5 of THAT module only. Project-level l5 (config.json, project.json) stays. */
export function listNs4RebuildAllDeletionKeys(files, project, moduleName) {
    const keys = [];
    for (const [key, file] of Object.entries(files)) {
        if (!file || file.project !== project || file.status === 'deleted' || !file.folder)
            continue;
        if (file.level !== 1 && file.level !== 2 && file.level !== 4 && file.level !== 5)
            continue;
        if (!isNs4ExactModuleFolderPrefix(file.folder, moduleName))
            continue;
        keys.push(key);
    }
    return keys;
}
export function countNs4RebuildAllByLayer(files, keys) {
    const deleted = { l1: 0, l2: 0, l4: 0, l5: 0 };
    for (const key of keys) {
        const level = files[key]?.level;
        if (level === 1)
            deleted.l1 += 1;
        else if (level === 2)
            deleted.l2 += 1;
        else if (level === 4)
            deleted.l4 += 1;
        else if (level === 5)
            deleted.l5 += 1;
    }
    return deleted;
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function moduleEntryName(item) {
    if (typeof item === 'string')
        return item.trim();
    if (!isRecord(item))
        return '';
    for (const field of ['moduleName', 'moduleId', 'name']) {
        const value = item[field];
        if (typeof value === 'string' && value.trim())
            return value.trim();
    }
    return '';
}
function isSameModule(name, moduleName) {
    return !!name && normalizeNs4ModuleName(name) === normalizeNs4ModuleName(moduleName);
}
function stripModuleList(value, moduleName) {
    if (!Array.isArray(value))
        return { list: value, removed: 0 };
    const kept = [];
    let removed = 0;
    for (const item of value) {
        if (isSameModule(moduleEntryName(item), moduleName))
            removed += 1;
        else
            kept.push(item);
    }
    return { list: kept, removed };
}
export function stripNs4ModuleFromProjectJson(projectJson, moduleName) {
    if (!isRecord(projectJson))
        return { value: null, removed: 0 };
    const stripped = stripModuleList(projectJson.modules, moduleName);
    return { value: { ...projectJson, modules: stripped.list }, removed: stripped.removed };
}
export function stripNs4ModuleFromConfigJson(config, moduleName) {
    if (!isRecord(config))
        return { value: null, removed: 0 };
    const next = { ...config };
    let removed = 0;
    const root = stripModuleList(next.modules, moduleName);
    if (Array.isArray(next.modules)) {
        next.modules = root.list;
        removed += root.removed;
    }
    if (isRecord(next.projects)) {
        const projects = { ...next.projects };
        for (const [key, project] of Object.entries(projects)) {
            if (!isRecord(project) || !Array.isArray(project.modules))
                continue;
            const nested = stripModuleList(project.modules, moduleName);
            projects[key] = { ...project, modules: nested.list };
            removed += nested.removed;
        }
        next.projects = projects;
    }
    return { value: next, removed };
}
export function planNs4RebuildAll(input) {
    const recovered = recoverNs4RebuildAllPrompt({
        initialPrompt: input.initialPrompt,
        sourcePrompt: input.sourcePrompt,
    });
    if (!recovered.ok)
        return { ok: false, reason: recovered.reason, keys: [] };
    const keys = listNs4RebuildAllDeletionKeys(input.files, input.project, input.moduleName);
    const projectJson = stripNs4ModuleFromProjectJson(input.projectJson, input.moduleName);
    const configJson = stripNs4ModuleFromConfigJson(input.configJson, input.moduleName);
    return {
        ok: true,
        prompt: recovered.prompt,
        keys,
        projectJson: projectJson.value,
        configJson: configJson.value,
        report: {
            at: input.at || new Date().toISOString(),
            deleted: countNs4RebuildAllByLayer(input.files, keys),
            sanitized: {
                projectJsonRemoved: projectJson.removed,
                configJsonRemoved: configJson.removed,
            },
        },
    };
}
export function stampNs4RebuildAll(pipeline, report) {
    return { ...pipeline, rebuildAll: report, rebuiltAt: report.at };
}
export function parseNs4RebuildAllReport(value) {
    const raw = typeof value === 'string' ? value.trim() : '';
    if (!raw)
        return null;
    try {
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== 'object')
            return null;
        if (typeof parsed.at !== 'string' || !parsed.deleted)
            return null;
        return parsed;
    }
    catch {
        return null;
    }
}
export function formatNs4RebuildAllNote(moduleName, report) {
    const { l1, l2, l4, l5 } = report.deleted;
    return `/rebuild all ${moduleName}: deleted l1=${l1} l2=${l2} l4=${l4} l5=${l5}; sanitized projectJson=${report.sanitized.projectJsonRemoved} configJson=${report.sanitized.configJsonRemoved}`;
}
