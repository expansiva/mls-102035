/// <mls fileReference="_102035_/l2/agentNewSolution/helpers/organizationRegistry.ts" enhancement="_blank"/>
import mdm from '/_102034_/l4/ontology/mdm.defs.js';
import { NS4_SOLUTION_REGISTRY_SCHEMA_VERSION, } from '/_102035_/l2/agentNewSolution/helpers/organizationTypes.js';
/** ns5_43 T4: the level-1 the registry is written against IS `mdm.defs.ts`, so it states its version. */
export const NS4_REGISTRY_LEVEL1_SCHEMA_VERSION = mdm.schemaVersion;
export function emptyNs4SolutionRegistry(level1SchemaVersion = NS4_REGISTRY_LEVEL1_SCHEMA_VERSION) {
    return {
        schemaVersion: NS4_SOLUTION_REGISTRY_SCHEMA_VERSION,
        level1SchemaVersion,
        modules: [],
    };
}
/**
 * Replace only the named module block. Other modules keep their object identity so a stable
 * stringify leaves them byte-identical.
 */
export function upsertNs4SolutionRegistryModule(registry, block) {
    const modules = registry.modules.slice();
    const index = modules.findIndex(item => item.moduleName === block.moduleName);
    if (index >= 0)
        modules[index] = block;
    else
        modules.push(block);
    return { ...registry, modules };
}
export function inferNs4RegistryMdmSubtype(entity) {
    if (entity.mdmSubtype)
        return entity.mdmSubtype;
    if (entity.party === 'person')
        return 'Person';
    if (entity.party === 'organization')
        return 'Company';
    return null;
}
export function buildNs4SolutionRegistryModuleBlock(input) {
    const roles = [];
    const seen = new Set();
    const listed = [];
    const listedIds = new Set();
    for (const entity of input.entities) {
        if (entity.entityId && !listedIds.has(entity.entityId)) {
            listedIds.add(entity.entityId);
            listed.push({
                entityId: entity.entityId,
                kind: entity.kind || 'core',
                ...(entity.mdmSubtype ? { mdmSubtype: entity.mdmSubtype } : {}),
                ...(entity.class ? { class: entity.class } : {}),
            });
        }
        const isMdm = entity.kind === 'mdm' || entity.kind === 'role' || entity.storage?.target === 'mdm';
        if (!isMdm)
            continue;
        const subtype = inferNs4RegistryMdmSubtype(entity);
        if (!subtype)
            continue;
        const roleTag = entity.roleTag || entity.storage?.mdmType || `${input.moduleName}.${entity.entityId}`;
        if (seen.has(roleTag))
            continue;
        seen.add(roleTag);
        roles.push({ subtype, roleTag, namespace: input.moduleName });
    }
    const events = [];
    const seenEvents = new Set();
    for (const event of input.events || []) {
        if (!event.eventId || seenEvents.has(event.eventId))
            continue;
        seenEvents.add(event.eventId);
        events.push({ eventId: event.eventId, on: event.on });
    }
    return {
        moduleName: input.moduleName,
        actors: input.actors.map(actor => ({ actorId: actor.actorId, kind: actor.kind })),
        roles,
        generalFields: input.generalFields ? input.generalFields.slice() : [],
        entities: listed,
        events,
        updatedAt: input.updatedAt,
    };
}
export function serializeNs4SolutionRegistry(registry) {
    return `${JSON.stringify(registry, null, 2)}\n`;
}
