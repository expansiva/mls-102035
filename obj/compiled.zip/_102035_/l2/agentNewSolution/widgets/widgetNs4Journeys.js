/// <mls fileReference="_102035_/l2/agentNewSolution/widgets/widgetNs4Journeys.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { ns4WidgetLabels } from '/_102035_/l2/agentNewSolution/helpers/ns4Text.js';
let WidgetNs4Journeys102035 = class WidgetNs4Journeys102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.value = null;
        this.readonly = false;
        this.adjustment = '';
        this.submitting = false;
        this.selectedActorRef = 'all';
        this.selectedJourneyId = '';
        this.activeTab = 'steps';
        this.selectedPolicyOptions = {};
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.msgError = '';
        this.msgOk = '';
        this.feedbackFocusPending = false;
        this.feedbackScrollPending = false;
        this.cancelOrigin = null;
    }
    labels() {
        return ns4WidgetLabels(this.presentation, 'journeys');
    }
    setFeedback(feedback) {
        this.feedbackIssues = feedback?.issues || [];
        this.msgError = feedback?.kind === 'error' ? feedback.message : '';
        this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : '';
        this.feedbackFocusPending = feedback?.kind === 'error';
    }
    setSubmitting(submitting) { this.submitting = submitting; }
    updated() {
        if (this.feedbackFocusPending && this.msgError) {
            this.feedbackFocusPending = false;
            setTimeout(() => this.querySelector('.ns4-feedback[role="alert"]')?.focus());
        }
        if (this.cancelOpen)
            setTimeout(() => this.querySelector('.ns4-cancel-stay')?.focus());
        if (this.feedbackScrollPending && (this.msgError || this.msgOk)) {
            this.feedbackScrollPending = false;
            this.querySelector('.ns4-feedback')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const labels = this.labels();
        const policyChanges = this.policyChanges();
        const adjustment = this.submissionAdjustment(policyChanges);
        if (action === 'requestChanges' && !adjustment) {
            this.setFeedback({ kind: 'error', message: labels.adjustmentRequired });
            return;
        }
        this.setFeedback({ kind: 'information', message: action === 'approve' ? labels.processingApproval : action === 'cancel' ? labels.processingCancel : labels.processingChanges });
        this.feedbackScrollPending = true;
        this.setSubmitting(true);
        this.dispatchEvent(new CustomEvent('ns4-journeys-review', {
            detail: { action, adjustment, review: this.value, policyDecisionSelections: this.policyDecisionSelections() },
            bubbles: true,
            composed: true,
        }));
    }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    trapCancel(event) {
        if (event.key === 'Escape') {
            event.preventDefault();
            this.closeCancel();
            return;
        }
        if (event.key !== 'Tab')
            return;
        const controls = [...this.querySelectorAll('.ns4-cancel-dialog button')];
        const index = controls.indexOf(document.activeElement);
        event.preventDefault();
        controls[(index + (event.shiftKey ? controls.length - 1 : 1)) % controls.length]?.focus();
    }
    renderFeedback(labels) {
        if (!this.msgError && !this.msgOk)
            return '';
        const error = Boolean(this.msgError);
        return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} aria-live=${error ? 'assertive' : 'polite'} tabindex="-1">
      ${error ? html `<strong>${labels.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>
      ${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(issue => html `<li>${issue.path ? html `<code>${issue.path}</code> — ` : ''}${issue.message}</li>`)}</ul>` : ''}
    </section>`;
    }
    renderCancelDialog(labels) {
        if (!this.cancelOpen)
            return '';
        return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true" aria-labelledby="ns4-journeys-cancel-title" @keydown=${this.trapCancel}>
      <h3 id="ns4-journeys-cancel-title">${labels.cancelTitle}</h3><p>${labels.cancelText}</p><div><button class="secondary ns4-cancel-stay" @click=${this.closeCancel}>${labels.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${labels.cancel}</button></div>
    </section></div>`;
    }
    render() {
        if (!this.value)
            return html `<div class="ns4-empty">No E2 review available.</div>`;
        const labels = this.labels();
        const actorRefs = [...new Set(this.value.journeys.map(item => item.business.actorRef))];
        const visibleJourneys = this.value.journeys.filter(item => this.selectedActorRef === 'all' || item.business.actorRef === this.selectedActorRef);
        const journey = visibleJourneys.find(item => item.journeyId === this.selectedJourneyId) || visibleJourneys[0] || this.value.journeys[0];
        const hasChanges = Boolean(this.adjustment.trim()) || this.policyChanges().length > 0;
        if (!journey)
            return html `<div class="ns4-empty">${labels.selectJourney}</div>`;
        const journeyView = this.view(journey);
        return html `
      <section class="ns4-journeys">
        <header class="ns4-header">
          <div>
            <div class="ns4-breadcrumb">${labels.step} 2 ${labels.of} 6 · ${labels.journeys}</div>
            <h2>${this.value.title}</h2>
            <p>${labels.subtitle}</p>
          </div>
          <div class="ns4-header-meta">
            <span>${labels.round} ${this.value.reviewRound}</span>
            <strong>${this.value.journeys.length} ${labels.journeysFound}</strong>
          </div>
        </header>
        ${this.renderFeedback(labels)}
        ${this.value.systemDecisions.length ? html `
          <details class="ns4-system-decisions">
            <summary>${labels.assumedDecisions} (${this.value.systemDecisions.length})</summary>
            <div>${this.value.systemDecisions.map(decision => html `
              <article>
                <strong>${decision.question}</strong>
                <p>${decision.chosen}</p>
                <small><b>${labels.changeHint}:</b> ${decision.changeHint}</small>
              </article>
            `)}</div>
          </details>
        ` : ''}

        <details class="ns4-filters">
          <summary>${labels.filters}</summary>
          <div class="ns4-filter-content">
            <div class="ns4-actor-filter" role="group" aria-label=${labels.actorMap}>
              <button class=${this.selectedActorRef === 'all' ? 'is-active' : ''} @click=${() => this.selectActor('all', this.value?.journeys || [])}>${labels.allActors}</button>
              ${actorRefs.map(actorRef => html `
                <button class=${this.selectedActorRef === actorRef ? 'is-active' : ''} @click=${() => this.selectActor(actorRef, this.value?.journeys || [])}>${this.actorLabel(actorRef)}</button>
              `)}
            </div>
            <section class="ns4-actor-map">
              <div class="ns4-section-title"><strong>${labels.actorMap}</strong><span>${actorRefs.length} ${labels.actors} / ${this.value.journeys.length} ${labels.journeys}</span></div>
              <div class="ns4-lanes">
                ${actorRefs.map(actorRef => {
            const actorJourneys = this.value?.journeys.filter(item => item.business.actorRef === actorRef) || [];
            return html `
                    <div class="ns4-lane ${this.selectedActorRef === actorRef ? 'is-filtered' : ''}">
                      <button class="ns4-lane-head" @click=${() => this.selectActor(actorRef, actorJourneys)}><span>${this.actorLabel(actorRef)}</span><strong>${actorJourneys.length}</strong></button>
                      <div class="ns4-lane-items">${actorJourneys.map(item => html `
                        <button class=${item.journeyId === journey.journeyId ? 'is-selected' : ''} @click=${() => this.selectJourney(item.journeyId)}>${item.business.title}</button>
                      `)}</div>
                    </div>
                  `;
        })}
              </div>
            </section>
          </div>
        </details>

        <div class="ns4-main">
          <aside class="ns4-list">
            <div class="ns4-section-title"><strong>${labels.journeys}</strong><span>${visibleJourneys.length} ${labels.journeysFound}</span></div>
            <div class="ns4-list-items">
              ${visibleJourneys.map(item => html `
                <button class="ns4-journey-card ${item.journeyId === journey.journeyId ? 'is-selected' : ''}"
                  @click=${() => this.selectJourney(item.journeyId)}>
                  <code>${item.journeyId}</code>
                  <strong>${item.business.title}</strong>
                  <span>${this.actorLabel(item.business.actorRef)}</span>
                  <small><em>${labels.goal}</em>${item.business.goal}</small>
                </button>
              `)}
            </div>
          </aside>

          <article class="ns4-detail">
            <div class="ns4-detail-head">${this.renderPolicySelector(journeyView, labels)}</div>

            <nav class="ns4-tabs" role="tablist">
              ${this.renderTab('steps', labels.steps)}
              ${this.renderTab('overview', labels.overview)}
              ${this.renderTab('rules', labels.rules)}
              ${this.renderTab('outcome', labels.outcome)}
            </nav>

            ${this.activeTab === 'steps' ? this.renderSteps(journeyView, labels)
            : this.activeTab === 'overview' ? this.renderOverview(journeyView, labels)
                : this.activeTab === 'rules' ? this.renderRules(journeyView, labels)
                    : this.renderOutcome(journeyView, labels)}
          </article>
        </div>

        <footer class="ns4-review">
          <label><span>${labels.adjustment}</span><textarea
            .value=${this.adjustment}
            placeholder=${labels.placeholder}
            ?disabled=${this.submitting || this.readonly}
            @input=${(event) => { this.adjustment = event.target.value; }}
          ></textarea></label>
          <div>
            <button class="cancel" ?disabled=${this.submitting || this.readonly} @click=${this.openCancel}>${labels.cancel}</button>
            <button class="secondary ${hasChanges ? 'is-active' : ''}" ?disabled=${this.submitting || this.readonly || !hasChanges} @click=${() => this.submit('requestChanges')}>${labels.requestChanges}</button>
            <button class="primary ${hasChanges ? '' : 'is-active'}" ?disabled=${this.submitting || this.readonly || hasChanges} @click=${() => this.submit('approve')}>${labels.approve}</button>
          </div>
        </footer>
        ${this.renderCancelDialog(labels)}
      </section>
    `;
    }
    selectActor(actorRef, journeys) {
        this.selectedActorRef = actorRef;
        this.selectedJourneyId = journeys.find(item => actorRef === 'all' || item.business.actorRef === actorRef)?.journeyId || '';
        this.activeTab = 'steps';
    }
    actorLabel(actorRef) {
        const readable = actorRef.replace(/([a-z])([A-Z])/g, '$1 $2');
        return `${readable.slice(0, 1).toUpperCase()}${readable.slice(1)}`;
    }
    selectJourney(journeyId) {
        this.selectedJourneyId = journeyId;
        this.activeTab = 'steps';
    }
    view(journey) { return journey; }
    policyChanges() {
        return (this.value?.journeys || []).flatMap(journey => {
            const view = this.view(journey);
            return (view.policyDecisions || []).flatMap(decision => {
                const selectionKey = `${journey.journeyId}:${decision.decisionId}`;
                const selectedValue = this.selectedPolicyOptions[selectionKey];
                if (!selectedValue || selectedValue === `${decision.decisionId}:actual`)
                    return [];
                const alternativeIndex = Number(selectedValue.split(':').at(-1));
                const selectedChoice = decision.alternatives[alternativeIndex];
                if (!selectedChoice)
                    return [];
                return [{
                        journeyId: journey.journeyId,
                        journeyTitle: view.business.title,
                        decisionId: decision.decisionId,
                        question: decision.question,
                        generatedChoice: decision.chosen,
                        selectedChoice,
                        impact: decision.impact,
                    }];
            });
        });
    }
    submissionAdjustment(policyChanges) {
        const requestedDecisions = policyChanges.length ? [
            'Human-selected policy decisions:',
            ...policyChanges.map(change => [
                `- Journey: ${change.journeyId} — ${change.journeyTitle}`,
                `  Question: ${change.question}`,
                `  Generated choice: ${change.generatedChoice}`,
                `  Human selected: ${change.selectedChoice}`,
                change.impact ? `  Impact: ${change.impact}` : '',
            ].filter(Boolean).join('\n')),
        ].join('\n') : '';
        return [this.adjustment.trim(), requestedDecisions].filter(Boolean).join('\n\n');
    }
    policyDecisionSelections() {
        return (this.value?.journeys || []).flatMap(journey => {
            const view = this.view(journey);
            return (view.policyDecisions || []).map(decision => {
                const selectionKey = `${journey.journeyId}:${decision.decisionId}`;
                const selected = this.selectedPolicyOptions[selectionKey] || `${decision.decisionId}:actual`;
                const alternativeIndex = selected === `${decision.decisionId}:actual` ? -1 : Number(selected.split(':').at(-1));
                return { decisionId: decision.decisionId, selectedChoice: alternativeIndex < 0 ? decision.chosen : decision.alternatives[alternativeIndex] || decision.chosen };
            });
        });
    }
    renderPolicySelector(journey, labels) {
        const decisions = journey.policyDecisions || [];
        if (!decisions.length)
            return html `<p class="ns4-no-policy">${labels.noPolicyDecision}</p>`;
        return html `<section class="ns4-policy-decisions">${decisions.map(decision => {
            const actualValue = `${decision.decisionId}:actual`;
            const selectionKey = `${journey.journeyId}:${decision.decisionId}`;
            const options = [actualValue, ...decision.alternatives.map((_alternative, index) => `${decision.decisionId}:alternative:${index}`)];
            const selected = options.includes(this.selectedPolicyOptions[selectionKey]) ? this.selectedPolicyOptions[selectionKey] : actualValue;
            return html `<label class="ns4-policy-selector"><span>${decision.question}</span><select ?disabled=${this.submitting || this.readonly} @change=${(event) => {
                this.selectedPolicyOptions = { ...this.selectedPolicyOptions, [selectionKey]: event.target.value };
            }}>
        <option value=${actualValue} .selected=${selected === actualValue}>${labels.actual} ${decision.chosen}</option>
        ${decision.alternatives.map((alternative, index) => {
                const value = `${decision.decisionId}:alternative:${index}`;
                return html `<option value=${value} .selected=${selected === value}>${alternative}</option>`;
            })}
      </select>${decision.impact ? html `<p class="ns4-policy-impact"><span aria-hidden="true">⚠</span><span><strong>${labels.impact}</strong>${decision.impact}</span></p>` : ''}</label>`;
        })}</section>`;
    }
    renderTab(tab, label) {
        return html `<button role="tab" aria-selected=${this.activeTab === tab ? 'true' : 'false'} class=${this.activeTab === tab ? 'is-active' : ''} @click=${() => { this.activeTab = tab; }}>${label}</button>`;
    }
    renderOverview(journey, labels) {
        return html `
      <dl class="ns4-summary">
        <div><dt>${labels.actor}</dt><dd>${this.actorLabel(journey.business.actorRef)}</dd></div>
        <div><dt>${labels.goal}</dt><dd>${journey.business.goal}</dd></div>
      </dl>
    `;
    }
    renderSteps(journey, labels) {
        return html `
      <section class="ns4-steps-section">
        <h4>${labels.steps}</h4>
        <ol class="ns4-steps">${journey.business.steps.map((step, index) => html `
          <li>
            <span class="ns4-step-index">${index + 1}</span>
            <div>
              <div class="ns4-step-title"><span>${step.kind}</span><strong>${step.title}</strong><code>${step.entity}</code>${step.affects?.length ? html ` <code>${step.affects.join(', ')}</code>` : ''}</div>
              <p>${step.description}</p>
            </div>
          </li>
        `)}</ol>
      </section>
    `;
    }
    renderRules(journey, labels) {
        return html `
      <section class="ns4-rules">
        <p>${labels.rulesHelp}</p>
        <ol>${(journey.business.useRules || []).map(ruleId => html `<li><code>${ruleId}</code></li>`)}</ol>
      </section>
    `;
    }
    renderOutcome(journey, labels) {
        return html `<section class="ns4-outcome"><h4>${labels.outcome}</h4><p>${journey.business.outcome.statement}</p><ul>${journey.business.outcome.evidence.map(item => html `<li>${item}</li>`)}</ul></section>`;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Journeys102035.prototype, "value", void 0);
__decorate([
    property({ type: Object })
], WidgetNs4Journeys102035.prototype, "presentation", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Journeys102035.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4Journeys102035.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Journeys102035.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Journeys102035.prototype, "selectedActorRef", void 0);
__decorate([
    state()
], WidgetNs4Journeys102035.prototype, "selectedJourneyId", void 0);
__decorate([
    state()
], WidgetNs4Journeys102035.prototype, "activeTab", void 0);
__decorate([
    state()
], WidgetNs4Journeys102035.prototype, "selectedPolicyOptions", void 0);
__decorate([
    state()
], WidgetNs4Journeys102035.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4Journeys102035.prototype, "cancelOpen", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Journeys102035.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Journeys102035.prototype, "msgOk", void 0);
WidgetNs4Journeys102035 = __decorate([
    customElement('widget-ns4-journeys-102035')
], WidgetNs4Journeys102035);
export { WidgetNs4Journeys102035 };
