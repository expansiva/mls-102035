/// <mls fileReference="_102035_/l2/agentNewSolution/widgets/widgetNs4Composition.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { ns4WidgetLabels } from '/_102035_/l2/agentNewSolution/helpers/ns4Text.js';
let WidgetNs4Composition102035 = class WidgetNs4Composition102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.value = null;
        this.readonly = false;
        this.msgError = '';
        this.msgOk = '';
        this.adjustment = '';
        this.submitting = false;
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.cancelOrigin = null;
    }
    text() {
        return ns4WidgetLabels(this.presentation, 'composition');
    }
    setFeedback(feedback) {
        this.feedbackIssues = feedback?.issues || [];
        this.msgError = feedback?.kind === 'error' ? feedback.message : '';
        this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : '';
    }
    setSubmitting(submitting) { this.submitting = submitting; }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const text = this.text();
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            this.setFeedback({ kind: 'error', message: text.adjustmentRequired });
            return;
        }
        this.setFeedback({ kind: 'information', message: action === 'approve' ? text.processingApproval : action === 'cancel' ? text.processingCancel : text.processingChanges });
        this.setSubmitting(true);
        this.dispatchEvent(new CustomEvent('ns4-composition-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value }, bubbles: true, composed: true,
        }));
    }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    render() {
        const text = this.text();
        if (!this.value)
            return html `<div class="ns4-empty">${text.empty}</div>`;
        const hasAdjustment = Boolean(this.adjustment.trim());
        return html `<section class="ns4-composition">
      <header><div><p class="ns4-step">${text.step}</p><h2>${this.value.title}</h2><p>${text.hint}</p></div><span>${text.review} ${this.value.reviewRound}</span></header>
      ${this.renderFeedback(text)}
      <section class="ns4-summary"><p>${this.value.analysisSummary}</p></section>
      <section class="ns4-recommendations">
        ${this.value.recommendations.length ? this.value.recommendations.map(item => html `<article>
          <div><span class="kind">${item.kind === 'horizontalModule' ? text.horizontalModule : text.plugin}</span><span class="decision ${item.decision}">${item.decision === 'include' ? text.include : text.defer}</span></div>
          <h3>${item.title}</h3><p>${item.purpose}</p><code>${item.id}</code>
        </article>`) : html `<div class="ns4-empty-state"><strong>✓</strong><p>${text.empty}</p></div>`}
      </section>
      <footer><label><span>${text.adjustment}</span><textarea .value=${this.adjustment} placeholder=${text.placeholder}
        ?disabled=${this.submitting || this.readonly} @input=${(event) => { this.adjustment = event.target.value; }}></textarea></label><div>
        <button class="cancel" ?disabled=${this.submitting || this.readonly} @click=${this.openCancel}>${text.cancel}</button>
        <button class="secondary ${hasAdjustment ? 'is-active' : ''}" ?disabled=${this.submitting || this.readonly || !hasAdjustment} @click=${() => this.submit('requestChanges')}>${text.request}</button>
        <button class="primary ${hasAdjustment ? '' : 'is-active'}" ?disabled=${this.submitting || this.readonly || hasAdjustment} @click=${() => this.submit('approve')}>${text.approve}</button>
      </div></footer>${this.renderCancelDialog(text)}
    </section>`;
    }
    renderFeedback(text) {
        if (!this.msgError && !this.msgOk)
            return '';
        const error = Boolean(this.msgError);
        return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} tabindex="-1">${error ? html `<strong>${text.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(issue => html `<li>${issue.path ? html `<code>${issue.path}</code> — ` : ''}${issue.message}</li>`)}</ul>` : ''}</section>`;
    }
    renderCancelDialog(text) {
        if (!this.cancelOpen)
            return '';
        return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true"><h3>${text.cancelTitle}</h3><p>${text.cancelText}</p><div><button class="secondary" @click=${this.closeCancel}>${text.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${text.cancel}</button></div></section></div>`;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Composition102035.prototype, "value", void 0);
__decorate([
    property({ type: Object })
], WidgetNs4Composition102035.prototype, "presentation", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Composition102035.prototype, "readonly", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Composition102035.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Composition102035.prototype, "msgOk", void 0);
__decorate([
    state()
], WidgetNs4Composition102035.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Composition102035.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Composition102035.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4Composition102035.prototype, "cancelOpen", void 0);
WidgetNs4Composition102035 = __decorate([
    customElement('widget-ns4-composition-102035')
], WidgetNs4Composition102035);
export { WidgetNs4Composition102035 };
