/// <mls fileReference="_102035_/l2/agentNewSolution/widgets/widgetNs4LifecycleResolution.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WidgetNs4LifecycleResolution102035 = class WidgetNs4LifecycleResolution102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.value = null;
        this.choices = {};
    }
    render() {
        const review = this.value;
        if (!review)
            return html ``;
        return html `<section class="ns4-lifecycle-resolution">
      <header><p>👤 E7 — Lifecycle decisions</p><h2>Resolve each lifecycle finding</h2>
        <p>Choose whether a journey must operate the state (E2) or whether the lifecycle must shrink (E4). No model retry will run.</p></header>
      ${review.findings.map(finding => html `<article>
        <strong>${finding.code}</strong><p>${finding.message}</p>
        <label>Resolution <select .value=${this.choices[finding.findingId] || ''}
          @change=${(event) => { const action = event.target.value; if (action === 'operateState' || action === 'shrinkLifecycle')
            this.choices = { ...this.choices, [finding.findingId]: action }; }}>
          <option value="">Choose…</option><option value="operateState">Operate state in E2</option><option value="shrinkLifecycle">Shrink lifecycle in E4</option>
        </select></label>
      </article>`)}
      <footer><button ?disabled=${review.findings.some(finding => !this.choices[finding.findingId])} @click=${this.submit}>Continue with selected upstream rounds</button></footer>
    </section>`;
    }
    submit() {
        if (!this.value || this.value.findings.some(finding => !this.choices[finding.findingId]))
            return;
        const detail = {
            moduleName: this.value.moduleName,
            selections: this.value.findings.map(finding => ({ findingId: finding.findingId, action: this.choices[finding.findingId] })),
        };
        this.dispatchEvent(new CustomEvent('ns4-lifecycle-resolution', { detail, bubbles: true, composed: true }));
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4LifecycleResolution102035.prototype, "value", void 0);
__decorate([
    state()
], WidgetNs4LifecycleResolution102035.prototype, "choices", void 0);
WidgetNs4LifecycleResolution102035 = __decorate([
    customElement('widget-ns4-lifecycle-resolution-102035')
], WidgetNs4LifecycleResolution102035);
export { WidgetNs4LifecycleResolution102035 };
