/// <mls fileReference="_102035_/l2/agentNewSolution/widgets/widgetNs4AccessMatrix.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { ns4WidgetLabels } from '/_102035_/l2/agentNewSolution/helpers/ns4Text.js';
let WidgetNs4AccessMatrix102035 = class WidgetNs4AccessMatrix102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.value = null;
        this.readonly = false;
        this.adjustment = '';
        this.submitting = false;
        this.selectedGrantKey = '';
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.msgError = '';
        this.msgOk = '';
        this.feedbackFocusPending = false;
        this.feedbackScrollPending = false;
        this.cancelOrigin = null;
    }
    text() {
        return ns4WidgetLabels(this.presentation, 'accessMatrix');
    }
    setFeedback(feedback) {
        this.feedbackIssues = feedback?.issues || [];
        this.msgError = feedback?.kind === 'error' ? feedback.message : '';
        this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : '';
        this.feedbackFocusPending = feedback?.kind === 'error';
    }
    setSubmitting(submitting) { this.submitting = submitting; }
    updated() {
        if (this.feedbackFocusPending && this.msgError) {
            this.feedbackFocusPending = false;
            setTimeout(() => this.querySelector('.ns4-feedback[role="alert"]')?.focus());
        }
        if (this.cancelOpen)
            setTimeout(() => this.querySelector('.ns4-cancel-stay')?.focus());
        if (this.feedbackScrollPending && (this.msgError || this.msgOk)) {
            this.feedbackScrollPending = false;
            this.querySelector('.ns4-feedback')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const text = this.text();
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            this.setFeedback({ kind: 'error', message: text.adjustmentRequired });
            return;
        }
        this.setFeedback({ kind: 'information', message: action === 'approve' ? text.processingApproval : action === 'cancel' ? text.processingCancel : text.processingChanges });
        this.feedbackScrollPending = true;
        this.setSubmitting(true);
        this.dispatchEvent(new CustomEvent('ns4-access-matrix-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value },
            bubbles: true,
            composed: true,
        }));
    }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    trapCancel(event) {
        if (event.key === 'Escape') {
            event.preventDefault();
            this.closeCancel();
            return;
        }
        if (event.key !== 'Tab')
            return;
        const controls = [...this.querySelectorAll('.ns4-cancel-dialog button')];
        const index = controls.indexOf(document.activeElement);
        event.preventDefault();
        controls[(index + (event.shiftKey ? controls.length - 1 : 1)) % controls.length]?.focus();
    }
    renderFeedback(text) {
        if (!this.msgError && !this.msgOk)
            return '';
        const error = Boolean(this.msgError);
        return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} aria-live=${error ? 'assertive' : 'polite'} tabindex="-1">${error ? html `<strong>${text.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(issue => html `<li>${issue.path ? html `<code>${issue.path}</code> — ` : ''}${issue.message}</li>`)}</ul>` : ''}</section>`;
    }
    renderCancelDialog(text) {
        if (!this.cancelOpen)
            return '';
        return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true" aria-labelledby="ns4-access-cancel-title" @keydown=${this.trapCancel}><h3 id="ns4-access-cancel-title">${text.cancelTitle}</h3><p>${text.cancelText}</p><div><button class="secondary ns4-cancel-stay" @click=${this.closeCancel}>${text.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${text.cancel}</button></div></section></div>`;
    }
    grantKey(grant) {
        return `${grant.profileRef}\u0000${grant.authorityRef}`;
    }
    selectedGrant() {
        if (!this.value)
            return undefined;
        return this.value.grants.find(grant => this.grantKey(grant) === this.selectedGrantKey);
    }
    render() {
        const text = this.text();
        if (!this.value)
            return html `<div class="ns4-empty">${text.empty}</div>`;
        const selected = this.selectedGrant();
        const hasAdjustment = Boolean(this.adjustment.trim());
        return html `
      <section class="ns4-access-matrix">
        <header>
          <div><p class="ns4-step">${text.step} 3 ${text.of} 6</p><h2>${this.value.title}</h2><p>${text.subtitle}</p></div>
          <span>${text.round} ${this.value.reviewRound}</span>
        </header>
        ${this.renderFeedback(text)}

        ${this.renderMatrix(selected, text)}

        ${selected ? this.renderDetails(selected, text) : ''}

        <footer>
          <label><span>${text.adjustment}</span><textarea
            .value=${this.adjustment}
            placeholder=${text.placeholder}
            ?disabled=${this.submitting || this.readonly}
            @input=${(event) => { this.adjustment = event.target.value; }}
          ></textarea></label>
          <div>
            <button class="cancel" ?disabled=${this.submitting || this.readonly} @click=${this.openCancel}>${text.cancel}</button>
            <button class="secondary ${hasAdjustment ? 'is-active' : ''}" ?disabled=${this.submitting || this.readonly || !hasAdjustment} @click=${() => this.submit('requestChanges')}>${text.requestChanges}</button>
            <button class="primary ${hasAdjustment ? '' : 'is-active'}" ?disabled=${this.submitting || this.readonly || hasAdjustment} @click=${() => this.submit('approve')}>${text.approve}</button>
          </div>
        </footer>
        ${this.renderCancelDialog(text)}
      </section>
    `;
    }
    renderDetails(grant, text) {
        const profile = this.value.profiles.find(item => item.profileId === grant.profileRef);
        const authority = this.value.authorities.find(item => item.authorityRef === grant.authorityRef);
        return html `
      <section class="ns4-details">
        <div class="ns4-details-head"><div><h3>${text.details}</h3><p>${profile?.title} → ${authority?.title}</p></div><div><code>${grant.authorityRef}</code><button class="ns4-close" @click=${() => { this.selectedGrantKey = ''; }}>${text.close}</button></div></div>
        <div class="ns4-detail-grid">
          <article><h4>${text.reason}</h4><p>${grant.reason}</p></article>
          <article><h4>${text.scope}</h4><strong>${grant.dataScope.mode}</strong><p>${grant.dataScope.description}</p></article>
          <article><h4>${text.disclosure}</h4><strong>${grant.disclosure.mode}</strong><p>${grant.disclosure.description}</p></article>
          <article><h4>${text.journeySteps}</h4><p>${authority?.journeyStepRefs.join(', ') || '—'}</p></article>
        </div>
        <div class="ns4-detail-lists">
          <article><h4>${text.allowed}</h4><ul>${grant.disclosure.allowedInformation.map(item => html `<li>${item}</li>`)}</ul></article>
          <article><h4>${text.denied}</h4><ul>${grant.disclosure.deniedInformation.map(item => html `<li>${item}</li>`)}</ul></article>
          <article><h4>${text.ruleRefs}</h4><ul>${grant.useRules.map(ruleId => html `<li><code>${ruleId}</code></li>`)}</ul></article>
          <article><h4>${text.informationNeeds}</h4><ul>${authority?.informationNeeds.map(item => html `<li>${item}</li>`)}</ul></article>
        </div>
      </section>
    `;
    }
    renderMatrix(selected, text) {
        return html `
      <section class="ns4-matrix-card">
        <h3>${text.matrix}</h3>
        <div class="ns4-table-scroll"><table>
          <thead><tr><th>${text.authority}</th>${this.value.profiles.map(profile => html `<th>${profile.title}</th>`)}</tr></thead>
          <tbody>${this.value.authorities.map(authority => html `
            <tr><th><strong>${authority.title}</strong><code>${authority.authorityRef}</code></th>
              ${this.value.profiles.map(profile => {
            const grant = this.value.grants.find(item => item.profileRef === profile.profileId && item.authorityRef === authority.authorityRef);
            if (!grant)
                return html `<td><span class="ns4-none" title=${text.noAccess}>—</span></td>`;
            const full = grant.disclosure.mode === 'fullRecord';
            const key = this.grantKey(grant);
            return html `<td><label class="ns4-grant ${selected === grant ? 'selected' : ''} ${full ? 'full' : 'limited'}">
                  <input type="radio" name="ns4-access-grant" .checked=${selected === grant} @change=${() => { this.selectedGrantKey = key; }}>
                  <span>${full ? text.full : text.limited}</span>
                </label></td>`;
        })}
            </tr>
          `)}</tbody>
        </table></div>
      </section>
    `;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4AccessMatrix102035.prototype, "value", void 0);
__decorate([
    property({ type: Object })
], WidgetNs4AccessMatrix102035.prototype, "presentation", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4AccessMatrix102035.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "selectedGrantKey", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "cancelOpen", void 0);
__decorate([
    property({ type: String })
], WidgetNs4AccessMatrix102035.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4AccessMatrix102035.prototype, "msgOk", void 0);
WidgetNs4AccessMatrix102035 = __decorate([
    customElement('widget-ns4-access-matrix-102035')
], WidgetNs4AccessMatrix102035);
export { WidgetNs4AccessMatrix102035 };
