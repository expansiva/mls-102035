/// <mls fileReference="_102035_/l2/agentNewSolution/widgets/widgetNs4AccessMatrix.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { ns4WidgetLabels } from '/_102035_/l2/agentNewSolution/helpers/ns4Text.js';
let WidgetNs4AccessMatrix102035 = class WidgetNs4AccessMatrix102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-access-matrix-102035 {
  display: block;
  color: #172033;
}
widget-ns4-access-matrix-102035 * {
  box-sizing: border-box;
}
widget-ns4-access-matrix-102035 h2,
widget-ns4-access-matrix-102035 h3,
widget-ns4-access-matrix-102035 h4,
widget-ns4-access-matrix-102035 p,
widget-ns4-access-matrix-102035 dl,
widget-ns4-access-matrix-102035 dd {
  margin: 0;
}
widget-ns4-access-matrix-102035 ul {
  margin: 8px 0 0;
  padding-left: 20px;
}
widget-ns4-access-matrix-102035 li {
  line-height: 1.45;
  margin: 4px 0;
}
widget-ns4-access-matrix-102035 code {
  color: #475569;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
}
widget-ns4-access-matrix-102035 button:focus-visible,
widget-ns4-access-matrix-102035 textarea:focus-visible,
widget-ns4-access-matrix-102035 input:focus-visible {
  outline: 3px solid #a5b4fc;
  outline-offset: 2px;
}
widget-ns4-access-matrix-102035 .ns4-access-matrix {
  display: grid;
  gap: 16px;
}
widget-ns4-access-matrix-102035 header {
  align-items: flex-start;
  display: flex;
  gap: 16px;
  justify-content: space-between;
}
widget-ns4-access-matrix-102035 header p {
  color: #64748b;
  margin-top: 6px;
  max-width: 780px;
}
widget-ns4-access-matrix-102035 header .ns4-step {
  color: #4f46e5;
  font-size: 12px;
  font-weight: 650;
  margin: 0 0 5px;
}
widget-ns4-access-matrix-102035 header > span {
  background: #eef2ff;
  border-radius: 999px;
  color: #3730a3;
  font-size: 12px;
  padding: 6px 10px;
  white-space: nowrap;
}
widget-ns4-access-matrix-102035 .ns4-feedback {
  border: 1px solid;
  border-radius: 10px;
  display: grid;
  gap: 5px;
  padding: 11px 13px;
}
widget-ns4-access-matrix-102035 .ns4-feedback strong,
widget-ns4-access-matrix-102035 .ns4-feedback span,
widget-ns4-access-matrix-102035 .ns4-feedback li {
  font-size: 13px;
  line-height: 1.4;
}
widget-ns4-access-matrix-102035 .ns4-feedback.is-error {
  background: #fff1f2;
  border-color: #fda4af;
  color: #9f1239;
}
widget-ns4-access-matrix-102035 .ns4-feedback.is-ok {
  background: #ecfdf5;
  border-color: #86efac;
  color: #166534;
}
widget-ns4-access-matrix-102035 .ns4-matrix-card,
widget-ns4-access-matrix-102035 .ns4-details,
widget-ns4-access-matrix-102035 footer {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 15px;
}
widget-ns4-access-matrix-102035 .ns4-matrix-card h3 {
  margin-bottom: 10px;
}
widget-ns4-access-matrix-102035 .ns4-table-scroll {
  overflow-x: auto;
}
widget-ns4-access-matrix-102035 table {
  border-collapse: separate;
  border-spacing: 0;
  min-width: 720px;
  width: 100%;
}
widget-ns4-access-matrix-102035 th,
widget-ns4-access-matrix-102035 td {
  border-bottom: 1px solid #e2e8f0;
  padding: 9px;
  text-align: center;
  vertical-align: middle;
}
widget-ns4-access-matrix-102035 thead th {
  background: #f8fafc;
  color: #475569;
  font-size: 12px;
  position: sticky;
  top: 0;
}
widget-ns4-access-matrix-102035 th:first-child {
  min-width: 250px;
  text-align: left;
}
widget-ns4-access-matrix-102035 tbody th strong,
widget-ns4-access-matrix-102035 tbody th code {
  display: block;
}
widget-ns4-access-matrix-102035 tbody th code {
  margin-top: 3px;
}
widget-ns4-access-matrix-102035 .ns4-none {
  color: #94a3b8;
}
widget-ns4-access-matrix-102035 .ns4-grant {
  align-items: center;
  border: 1px solid transparent;
  border-radius: 999px;
  cursor: pointer;
  display: inline-flex;
  font-size: 11px;
  gap: 6px;
  padding: 6px 9px;
  white-space: nowrap;
}
widget-ns4-access-matrix-102035 .ns4-grant input {
  accent-color: currentColor;
  margin: 0;
}
widget-ns4-access-matrix-102035 .ns4-grant.full {
  background: #dcfce7;
  color: #166534;
}
widget-ns4-access-matrix-102035 .ns4-grant.limited {
  background: #fef3c7;
  color: #92400e;
}
widget-ns4-access-matrix-102035 .ns4-grant.selected {
  border-color: #4338ca;
  box-shadow: 0 0 0 2px #e0e7ff;
}
widget-ns4-access-matrix-102035 .ns4-details {
  display: grid;
  gap: 12px;
}
widget-ns4-access-matrix-102035 .ns4-details-head {
  align-items: center;
  display: flex;
  gap: 12px;
  justify-content: space-between;
}
widget-ns4-access-matrix-102035 .ns4-details-head p {
  color: #64748b;
  margin-top: 3px;
}
widget-ns4-access-matrix-102035 .ns4-details-head > div:last-child {
  align-items: end;
  display: grid;
  gap: 7px;
  justify-items: end;
}
widget-ns4-access-matrix-102035 .ns4-close {
  background: #fff;
  border: 1px solid #cbd5e1;
  border-radius: 7px;
  color: #475569;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  padding: 6px 9px;
}
widget-ns4-access-matrix-102035 .ns4-detail-grid,
widget-ns4-access-matrix-102035 .ns4-detail-lists {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-access-matrix-102035 .ns4-detail-grid article,
widget-ns4-access-matrix-102035 .ns4-detail-lists article {
  background: #f8fafc;
  border-radius: 9px;
  padding: 11px;
}
widget-ns4-access-matrix-102035 .ns4-detail-grid h4,
widget-ns4-access-matrix-102035 .ns4-detail-lists h4 {
  color: #475569;
  font-size: 12px;
  margin-bottom: 5px;
}
widget-ns4-access-matrix-102035 .ns4-detail-grid p {
  line-height: 1.4;
  margin-top: 3px;
}
widget-ns4-access-matrix-102035 footer {
  display: grid;
  gap: 12px;
}
widget-ns4-access-matrix-102035 footer label,
widget-ns4-access-matrix-102035 footer label span {
  display: grid;
  gap: 6px;
}
widget-ns4-access-matrix-102035 textarea {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  font: inherit;
  min-height: 105px;
  padding: 10px;
  resize: vertical;
  width: 100%;
}
widget-ns4-access-matrix-102035 footer > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-access-matrix-102035 footer button {
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  font: inherit;
  padding: 9px 14px;
}
widget-ns4-access-matrix-102035 footer button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}
widget-ns4-access-matrix-102035 footer button.secondary {
  background: #fff;
  color: #334155;
}
widget-ns4-access-matrix-102035 footer button.secondary.is-active {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-access-matrix-102035 footer button.primary {
  background: #4338ca;
  border-color: #4338ca;
  color: #fff;
}
widget-ns4-access-matrix-102035 footer button.cancel {
  background: #fff;
  border-color: #fecaca;
  color: #b91c1c;
  margin-right: auto;
}
widget-ns4-access-matrix-102035 .ns4-dialog-backdrop {
  align-items: center;
  background: rgba(15, 23, 42, 0.46);
  display: flex;
  inset: 0;
  justify-content: center;
  padding: 20px;
  position: fixed;
  z-index: 20;
}
widget-ns4-access-matrix-102035 .ns4-cancel-dialog {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 20px 50px rgba(15, 23, 42, 0.28);
  display: grid;
  gap: 12px;
  max-width: 460px;
  padding: 20px;
  width: 100%;
}
widget-ns4-access-matrix-102035 .ns4-cancel-dialog p {
  color: #475569;
}
widget-ns4-access-matrix-102035 .ns4-cancel-dialog > div {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-access-matrix-102035 .ns4-cancel-dialog button {
  background: #fff;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  cursor: pointer;
  padding: 9px 12px;
}
widget-ns4-access-matrix-102035 .ns4-cancel-dialog button.danger {
  background: #b91c1c;
  border-color: #b91c1c;
  color: #fff;
}
@media (max-width: 760px) {
  widget-ns4-access-matrix-102035 header,
  widget-ns4-access-matrix-102035 .ns4-details-head {
    display: grid;
  }
  widget-ns4-access-matrix-102035 .ns4-detail-grid,
  widget-ns4-access-matrix-102035 .ns4-detail-lists {
    grid-template-columns: 1fr;
  }
  widget-ns4-access-matrix-102035 footer > div {
    display: grid;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.adjustment = '';
        this.submitting = false;
        this.selectedGrantKey = '';
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.msgError = '';
        this.msgOk = '';
        this.feedbackFocusPending = false;
        this.feedbackScrollPending = false;
        this.cancelOrigin = null;
    }
    text() {
        return ns4WidgetLabels(this.presentation, 'accessMatrix');
    }
    setFeedback(feedback) {
        this.feedbackIssues = feedback?.issues || [];
        this.msgError = feedback?.kind === 'error' ? feedback.message : '';
        this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : '';
        this.feedbackFocusPending = feedback?.kind === 'error';
    }
    setSubmitting(submitting) { this.submitting = submitting; }
    updated() {
        if (this.feedbackFocusPending && this.msgError) {
            this.feedbackFocusPending = false;
            setTimeout(() => this.querySelector('.ns4-feedback[role="alert"]')?.focus());
        }
        if (this.cancelOpen)
            setTimeout(() => this.querySelector('.ns4-cancel-stay')?.focus());
        if (this.feedbackScrollPending && (this.msgError || this.msgOk)) {
            this.feedbackScrollPending = false;
            this.querySelector('.ns4-feedback')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const text = this.text();
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            this.setFeedback({ kind: 'error', message: text.adjustmentRequired });
            return;
        }
        this.setFeedback({ kind: 'information', message: action === 'approve' ? text.processingApproval : action === 'cancel' ? text.processingCancel : text.processingChanges });
        this.feedbackScrollPending = true;
        this.setSubmitting(true);
        this.dispatchEvent(new CustomEvent('ns4-access-matrix-review', {
            detail: { action, adjustment: this.adjustment.trim(), review: this.value },
            bubbles: true,
            composed: true,
        }));
    }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    trapCancel(event) {
        if (event.key === 'Escape') {
            event.preventDefault();
            this.closeCancel();
            return;
        }
        if (event.key !== 'Tab')
            return;
        const controls = [...this.querySelectorAll('.ns4-cancel-dialog button')];
        const index = controls.indexOf(document.activeElement);
        event.preventDefault();
        controls[(index + (event.shiftKey ? controls.length - 1 : 1)) % controls.length]?.focus();
    }
    renderFeedback(text) {
        if (!this.msgError && !this.msgOk)
            return '';
        const error = Boolean(this.msgError);
        return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} aria-live=${error ? 'assertive' : 'polite'} tabindex="-1">${error ? html `<strong>${text.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(issue => html `<li>${issue.path ? html `<code>${issue.path}</code> — ` : ''}${issue.message}</li>`)}</ul>` : ''}</section>`;
    }
    renderCancelDialog(text) {
        if (!this.cancelOpen)
            return '';
        return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true" aria-labelledby="ns4-access-cancel-title" @keydown=${this.trapCancel}><h3 id="ns4-access-cancel-title">${text.cancelTitle}</h3><p>${text.cancelText}</p><div><button class="secondary ns4-cancel-stay" @click=${this.closeCancel}>${text.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${text.cancel}</button></div></section></div>`;
    }
    grantKey(grant) {
        return `${grant.profileRef}\u0000${grant.authorityRef}`;
    }
    selectedGrant() {
        if (!this.value)
            return undefined;
        return this.value.grants.find(grant => this.grantKey(grant) === this.selectedGrantKey);
    }
    render() {
        const text = this.text();
        if (!this.value)
            return html `<div class="ns4-empty">${text.empty}</div>`;
        const selected = this.selectedGrant();
        const hasAdjustment = Boolean(this.adjustment.trim());
        return html `
      <section class="ns4-access-matrix">
        <header>
          <div><p class="ns4-step">${text.step} 3 ${text.of} 6</p><h2>${this.value.title}</h2><p>${text.subtitle}</p></div>
          <span>${text.round} ${this.value.reviewRound}</span>
        </header>
        ${this.renderFeedback(text)}

        ${this.renderMatrix(selected, text)}

        ${selected ? this.renderDetails(selected, text) : ''}

        <footer>
          <label><span>${text.adjustment}</span><textarea
            .value=${this.adjustment}
            placeholder=${text.placeholder}
            ?disabled=${this.submitting || this.readonly}
            @input=${(event) => { this.adjustment = event.target.value; }}
          ></textarea></label>
          <div>
            <button class="cancel" ?disabled=${this.submitting || this.readonly} @click=${this.openCancel}>${text.cancel}</button>
            <button class="secondary ${hasAdjustment ? 'is-active' : ''}" ?disabled=${this.submitting || this.readonly || !hasAdjustment} @click=${() => this.submit('requestChanges')}>${text.requestChanges}</button>
            <button class="primary ${hasAdjustment ? '' : 'is-active'}" ?disabled=${this.submitting || this.readonly || hasAdjustment} @click=${() => this.submit('approve')}>${text.approve}</button>
          </div>
        </footer>
        ${this.renderCancelDialog(text)}
      </section>
    `;
    }
    renderDetails(grant, text) {
        const profile = this.value.profiles.find(item => item.profileId === grant.profileRef);
        const authority = this.value.authorities.find(item => item.authorityRef === grant.authorityRef);
        return html `
      <section class="ns4-details">
        <div class="ns4-details-head"><div><h3>${text.details}</h3><p>${profile?.title} → ${authority?.title}</p></div><div><code>${grant.authorityRef}</code><button class="ns4-close" @click=${() => { this.selectedGrantKey = ''; }}>${text.close}</button></div></div>
        <div class="ns4-detail-grid">
          <article><h4>${text.reason}</h4><p>${grant.reason}</p></article>
          <article><h4>${text.scope}</h4><strong>${grant.dataScope.mode}</strong><p>${grant.dataScope.description}</p></article>
          <article><h4>${text.disclosure}</h4><strong>${grant.disclosure.mode}</strong><p>${grant.disclosure.description}</p></article>
          <article><h4>${text.journeySteps}</h4><p>${authority?.journeyStepRefs.join(', ') || '—'}</p></article>
        </div>
        <div class="ns4-detail-lists">
          <article><h4>${text.allowed}</h4><ul>${grant.disclosure.allowedInformation.map(item => html `<li>${item}</li>`)}</ul></article>
          <article><h4>${text.denied}</h4><ul>${grant.disclosure.deniedInformation.map(item => html `<li>${item}</li>`)}</ul></article>
          <article><h4>${text.ruleRefs}</h4><ul>${grant.useRules.map(ruleId => html `<li><code>${ruleId}</code></li>`)}</ul></article>
          <article><h4>${text.informationNeeds}</h4><ul>${authority?.informationNeeds.map(item => html `<li>${item}</li>`)}</ul></article>
        </div>
      </section>
    `;
    }
    renderMatrix(selected, text) {
        return html `
      <section class="ns4-matrix-card">
        <h3>${text.matrix}</h3>
        <div class="ns4-table-scroll"><table>
          <thead><tr><th>${text.authority}</th>${this.value.profiles.map(profile => html `<th>${profile.title}</th>`)}</tr></thead>
          <tbody>${this.value.authorities.map(authority => html `
            <tr><th><strong>${authority.title}</strong><code>${authority.authorityRef}</code></th>
              ${this.value.profiles.map(profile => {
            const grant = this.value.grants.find(item => item.profileRef === profile.profileId && item.authorityRef === authority.authorityRef);
            if (!grant)
                return html `<td><span class="ns4-none" title=${text.noAccess}>—</span></td>`;
            const full = grant.disclosure.mode === 'fullRecord';
            const key = this.grantKey(grant);
            return html `<td><label class="ns4-grant ${selected === grant ? 'selected' : ''} ${full ? 'full' : 'limited'}">
                  <input type="radio" name="ns4-access-grant" .checked=${selected === grant} @change=${() => { this.selectedGrantKey = key; }}>
                  <span>${full ? text.full : text.limited}</span>
                </label></td>`;
        })}
            </tr>
          `)}</tbody>
        </table></div>
      </section>
    `;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4AccessMatrix102035.prototype, "value", void 0);
__decorate([
    property({ type: Object })
], WidgetNs4AccessMatrix102035.prototype, "presentation", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4AccessMatrix102035.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "selectedGrantKey", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4AccessMatrix102035.prototype, "cancelOpen", void 0);
__decorate([
    property({ type: String })
], WidgetNs4AccessMatrix102035.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4AccessMatrix102035.prototype, "msgOk", void 0);
WidgetNs4AccessMatrix102035 = __decorate([
    customElement('widget-ns4-access-matrix-102035')
], WidgetNs4AccessMatrix102035);
export { WidgetNs4AccessMatrix102035 };
