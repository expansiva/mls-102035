/// <mls fileReference="_102035_/l2/agentNewSolution/widgets/widgetNs4Intake.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { ns4WidgetLabels } from '/_102035_/l2/agentNewSolution/helpers/ns4Text.js';
import { policyFor } from '/_102035_/l2/agentNewSolution/steps/e1/contracts.js';
const strategies = [
    { id: 'newSolution', title: 'New solution', description: 'Build a new module without a mandatory legacy database.', preserves: 'No legacy schema is required.', changes: 'Data model may be designed from the approved flow.', e4: 'No legacy schema is required.' },
    { id: 'modernizePreserveDatabase', title: 'Modernize, preserving the current database', description: 'Keep the existing schema as the immutable source of truth.', preserves: 'Tables, columns, keys and relationships.', changes: 'The new system adapts to the existing model.', e4: 'Schema metadata is required for validation.' },
    { id: 'modernizeEvolveDatabase', title: 'Modernize with controlled database evolution', description: 'Start from the current schema and evolve it with explicit approval.', preserves: 'Existing schema remains the initial reference.', changes: 'Prefer additive, compatible changes.', e4: 'Compare the desired ontology with the legacy schema.' },
    { id: 'replaceAndMigrateData', title: 'Replace the system and migrate data', description: 'Create a new model while migrating data from the current system.', preserves: 'Legacy data remains a migration source.', changes: 'The destination model may be redesigned.', e4: 'Source structure and destination requirements are required.' },
];
let WidgetNs4Intake102035 = class WidgetNs4Intake102035 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ns4-intake-102035 {
  --ns4-bg: var(--color-background-primary, #ffffff);
  --ns4-text: var(--color-text-primary, #172033);
  --ns4-muted: var(--color-text-secondary, #52606d);
  --ns4-subtle: var(--ct-text-tertiary, #64748b);
  --ns4-border: var(--color-border-secondary, #cbd5e1);
  --ns4-border-soft: var(--color-border-tertiary, #e2e8f0);
  --ns4-accent: #6366f1;
  --ns4-accent-bg: #eef2ff;
  --ns4-accent-text: #3730a3;
  background: var(--ns4-bg);
  color: var(--ns4-text);
  display: block;
}
widget-ns4-intake-102035 * {
  box-sizing: border-box;
}
widget-ns4-intake-102035 h2,
widget-ns4-intake-102035 h3,
widget-ns4-intake-102035 p,
widget-ns4-intake-102035 dl,
widget-ns4-intake-102035 dd {
  margin: 0;
}
widget-ns4-intake-102035 button,
widget-ns4-intake-102035 input,
widget-ns4-intake-102035 textarea,
widget-ns4-intake-102035 select {
  font: inherit;
}
widget-ns4-intake-102035 button:focus-visible,
widget-ns4-intake-102035 input:focus-visible,
widget-ns4-intake-102035 textarea:focus-visible,
widget-ns4-intake-102035 select:focus-visible {
  outline: 3px solid #a5b4fc;
  outline-offset: 2px;
}
widget-ns4-intake-102035 input,
widget-ns4-intake-102035 textarea,
widget-ns4-intake-102035 select {
  background: var(--ns4-bg);
  border: 1px solid var(--ns4-border);
  border-radius: 8px;
  color: var(--ns4-text);
  padding: 9px;
  width: 100%;
}
widget-ns4-intake-102035 textarea {
  min-height: 74px;
  resize: vertical;
}
widget-ns4-intake-102035 input:disabled,
widget-ns4-intake-102035 textarea:disabled,
widget-ns4-intake-102035 select:disabled {
  color: var(--ns4-muted);
  opacity: 0.78;
}
widget-ns4-intake-102035 .ns4-intake {
  background: var(--ns4-bg);
  display: grid;
  gap: 18px;
}
widget-ns4-intake-102035 header {
  align-items: flex-start;
  border-bottom: 1px solid var(--ns4-border-soft);
  display: flex;
  justify-content: space-between;
  padding-bottom: 14px;
}
widget-ns4-intake-102035 h2,
widget-ns4-intake-102035 h3,
widget-ns4-intake-102035 strong,
widget-ns4-intake-102035 dd {
  color: var(--ns4-text);
}
widget-ns4-intake-102035 header > div > p:last-child {
  color: var(--ns4-muted);
  margin-top: 5px;
}
widget-ns4-intake-102035 header > span {
  background: var(--ns4-accent-bg);
  border-radius: 999px;
  color: var(--ns4-accent-text);
  font-size: 12px;
  padding: 6px 10px;
  white-space: nowrap;
}
widget-ns4-intake-102035 .ns4-step {
  color: var(--ns4-accent);
  font-size: 12px;
  font-weight: 650;
  margin-bottom: 5px;
}
widget-ns4-intake-102035 .ns4-feedback {
  border: 1px solid;
  border-radius: 9px;
  display: grid;
  gap: 5px;
  padding: 11px 13px;
}
widget-ns4-intake-102035 .ns4-feedback strong,
widget-ns4-intake-102035 .ns4-feedback span,
widget-ns4-intake-102035 .ns4-feedback li {
  font-size: 13px;
  line-height: 1.4;
}
widget-ns4-intake-102035 .ns4-feedback.is-error {
  background: #fff1f2;
  border-color: #fda4af;
  color: #9f1239;
}
widget-ns4-intake-102035 .ns4-feedback.is-ok {
  background: #ecfdf5;
  border-color: #86efac;
  color: #166534;
}
widget-ns4-intake-102035 section > h3 {
  font-size: 15px;
  margin-bottom: 10px;
}
widget-ns4-intake-102035 label {
  display: grid;
  gap: 5px;
}
widget-ns4-intake-102035 label > span {
  color: var(--ns4-muted);
  font-size: 12px;
  font-weight: 600;
}
widget-ns4-intake-102035 .ns4-grid {
  display: grid;
  gap: 12px;
}
widget-ns4-intake-102035 .ns4-grid.two {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-intake-102035 .ns4-grid.three {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
widget-ns4-intake-102035 .ns4-grid .wide {
  grid-column: 1 / -1;
}
widget-ns4-intake-102035 .ns4-strategies {
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
widget-ns4-intake-102035 .ns4-strategy,
widget-ns4-intake-102035 .ns4-policies > label {
  background: var(--ns4-bg);
  border: 1px solid var(--ns4-border-soft);
  border-radius: 10px;
  cursor: pointer;
  display: flex;
  gap: 9px;
  padding: 11px;
}
widget-ns4-intake-102035 .ns4-strategy input,
widget-ns4-intake-102035 .ns4-policies input {
  accent-color: #4338ca;
  height: 16px;
  margin-top: 2px;
  width: 16px;
}
widget-ns4-intake-102035 .ns4-strategy > span,
widget-ns4-intake-102035 .ns4-policies > label > span {
  display: grid;
  gap: 4px;
}
widget-ns4-intake-102035 .ns4-strategy small,
widget-ns4-intake-102035 .ns4-policies small {
  color: var(--ns4-muted);
  line-height: 1.4;
}
widget-ns4-intake-102035 .ns4-strategy em {
  color: var(--ns4-accent);
  font-size: 11px;
  font-style: normal;
  font-weight: 650;
}
widget-ns4-intake-102035 .ns4-strategy dl {
  border-top: 1px solid var(--ns4-border-soft);
  display: grid;
  gap: 5px;
  margin-top: 5px;
  padding-top: 7px;
}
widget-ns4-intake-102035 .ns4-strategy dt {
  color: var(--ns4-subtle);
  font-size: 10px;
}
widget-ns4-intake-102035 .ns4-strategy dd {
  font-size: 11px;
  line-height: 1.35;
}
widget-ns4-intake-102035 .ns4-strategy.selected,
widget-ns4-intake-102035 .ns4-policies > label.selected {
  background: var(--ns4-accent-bg);
  border-color: #818cf8;
}
widget-ns4-intake-102035 .ns4-modernization {
  border-left: 3px solid #f59e0b;
  padding-left: 12px;
}
widget-ns4-intake-102035 .ns4-policies {
  display: grid;
  gap: 9px;
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
widget-ns4-intake-102035 footer {
  border-top: 1px solid var(--ns4-border);
  display: grid;
  gap: 10px;
  padding-top: 15px;
}
widget-ns4-intake-102035 footer > div {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-intake-102035 footer button {
  border: 1px solid var(--ns4-border);
  border-radius: 8px;
  cursor: pointer;
  padding: 9px 14px;
}
widget-ns4-intake-102035 footer button:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}
widget-ns4-intake-102035 footer .secondary,
widget-ns4-intake-102035 footer .primary {
  background: var(--ns4-bg);
  color: var(--ns4-text);
}
widget-ns4-intake-102035 footer .is-active {
  background: #4f46e5;
  border-color: #4f46e5;
  color: #fff;
}
widget-ns4-intake-102035 footer .cancel {
  border-color: #fecaca;
  color: #b91c1c;
  margin-right: auto;
}
widget-ns4-intake-102035 .ns4-dialog-backdrop {
  align-items: center;
  background: rgba(15, 23, 42, 0.46);
  display: flex;
  inset: 0;
  justify-content: center;
  padding: 20px;
  position: fixed;
  z-index: 20;
}
widget-ns4-intake-102035 .ns4-cancel-dialog {
  background: var(--ns4-bg);
  border: 1px solid var(--ns4-border);
  border-radius: 12px;
  box-shadow: 0 20px 50px rgba(15, 23, 42, 0.28);
  color: var(--ns4-text);
  display: grid;
  gap: 12px;
  max-width: 460px;
  padding: 20px;
  width: 100%;
}
widget-ns4-intake-102035 .ns4-cancel-dialog p {
  color: var(--ns4-muted);
}
widget-ns4-intake-102035 .ns4-cancel-dialog > div {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  justify-content: flex-end;
}
widget-ns4-intake-102035 .ns4-cancel-dialog button {
  background: var(--ns4-bg);
  border: 1px solid var(--ns4-border);
  border-radius: 8px;
  color: var(--ns4-text);
  cursor: pointer;
  padding: 9px 12px;
}
widget-ns4-intake-102035 .ns4-cancel-dialog button.danger {
  background: #b91c1c;
  border-color: #b91c1c;
  color: #fff;
}
@media (max-width: 820px) {
  widget-ns4-intake-102035 header,
  widget-ns4-intake-102035 .ns4-grid.two,
  widget-ns4-intake-102035 .ns4-grid.three,
  widget-ns4-intake-102035 .ns4-strategies,
  widget-ns4-intake-102035 .ns4-policies {
    grid-template-columns: 1fr;
    display: grid;
  }
  widget-ns4-intake-102035 footer > div {
    display: grid;
  }
}
@media (prefers-color-scheme: dark) {
  widget-ns4-intake-102035 {
    --ns4-bg: #0f141b;
    --ns4-text: #f1f5f9;
    --ns4-muted: #b8c4d3;
    --ns4-subtle: #9baabd;
    --ns4-border: #64748b;
    --ns4-border-soft: #344152;
    --ns4-accent: #a5b4fc;
    --ns4-accent-bg: #25294a;
    --ns4-accent-text: #c7d2fe;
  }
  widget-ns4-intake-102035 .ns4-feedback.is-error {
    background: #3b1721;
    border-color: #fb7185;
    color: #fecdd3;
  }
  widget-ns4-intake-102035 .ns4-feedback.is-ok {
    background: #103226;
    border-color: #4ade80;
    color: #bbf7d0;
  }
  widget-ns4-intake-102035 footer .cancel {
    border-color: #ef4444;
    color: #fca5a5;
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.adjustment = '';
        this.submitting = false;
        this.feedbackIssues = [];
        this.cancelOpen = false;
        this.msgError = '';
        this.msgOk = '';
        this.feedbackFocusPending = false;
        this.cancelOrigin = null;
    }
    patch(patch) { if (!this.value || this.readonly)
        return; this.value = { ...this.value, ...patch }; }
    text(path) { return path; }
    updateInput(path, event) {
        if (!this.value)
            return;
        const value = event.target.value;
        const split = (item) => item.split(/\n|,/).map(part => part.trim()).filter(Boolean);
        if (path === 'moduleName')
            return this.patch({ module: { ...this.value.module, moduleName: value } });
        if (path === 'title')
            return this.patch({ module: { ...this.value.module, title: value } });
        if (path === 'purpose')
            return this.patch({ module: { ...this.value.module, purpose: value }, businessScope: { ...this.value.businessScope, mainGoal: value } });
        if (path === 'languages')
            return this.patch({ localization: { ...this.value.localization, productLanguages: split(value) } });
        if (path === 'defaultLanguage')
            return this.patch({ localization: { ...this.value.localization, defaultLanguage: value } });
        if (path === 'actors')
            return this.patch({ businessScope: { ...this.value.businessScope, actors: split(value).map((title, index) => ({ actorId: `actor${index + 1}`, title, kind: 'internal', origin: 'named', expectedOutcome: '' })) } });
        if (path === 'outcomes')
            return this.patch({ businessScope: { ...this.value.businessScope, expectedOutcomes: split(value).map((title, index) => ({ outcomeId: `outcome${index + 1}`, title, description: title })) } });
        if (path === 'inScope' || path === 'outOfScope')
            return this.patch({ businessScope: { ...this.value.businessScope, [path]: split(value) } });
        if (path === 'integrations')
            return this.patch({ declaredConstraints: { ...this.value.declaredConstraints, mandatoryIntegrations: split(value).map((title, index) => ({ dependencyId: `dependency${index + 1}`, title, kind: 'unknown', reason: title })) } });
        const modernization = { ...(this.value.strategy.modernization || { sourceSystemName: '', schemaAvailability: 'uploadAtE4' }), [path]: value };
        this.patch({ strategy: { ...this.value.strategy, modernization } });
    }
    selectStrategy(mode) {
        if (!this.value || this.readonly)
            return;
        this.patch({ strategy: { ...this.value.strategy, mode, databaseChangePolicy: policyFor(mode), ...(mode === 'newSolution' ? {} : { modernization: this.value.strategy.modernization || { sourceSystemName: '', schemaAvailability: 'uploadAtE4' } }) } });
    }
    selectReviewPolicy(mode) { if (this.value && !this.readonly)
        this.patch({ reviewPolicy: { mode } }); }
    labels() {
        return ns4WidgetLabels(this.presentation, 'intake');
    }
    setFeedback(feedback) { this.feedbackIssues = feedback?.issues || []; this.msgError = feedback?.kind === 'error' ? feedback.message : ''; this.msgOk = feedback && feedback.kind !== 'error' ? feedback.message : ''; this.feedbackFocusPending = feedback?.kind === 'error'; }
    setSubmitting(submitting) { this.submitting = submitting; }
    updated() { if (this.feedbackFocusPending && this.msgError) {
        this.feedbackFocusPending = false;
        setTimeout(() => this.querySelector('.ns4-feedback[role="alert"]')?.focus());
    } if (this.cancelOpen)
        setTimeout(() => this.querySelector('.ns4-cancel-stay')?.focus()); }
    submit(action) {
        if (!this.value || this.readonly || this.submitting)
            return;
        const labels = this.labels();
        if (action === 'requestChanges' && !this.adjustment.trim()) {
            this.setFeedback({ kind: 'error', message: labels.adjustmentRequired });
            return;
        }
        this.setFeedback({ kind: 'information', message: action === 'approve' ? labels.processingApproval : action === 'cancel' ? labels.processingCancel : labels.processingChanges });
        this.setSubmitting(true);
        this.dispatchEvent(new CustomEvent('ns4-intake-review', { detail: { action, adjustment: this.adjustment.trim(), review: this.value }, bubbles: true, composed: true }));
    }
    openCancel(event) { this.cancelOrigin = event.currentTarget; this.cancelOpen = true; }
    closeCancel() { this.cancelOpen = false; setTimeout(() => this.cancelOrigin?.focus()); }
    trapCancel(event) {
        if (event.key === 'Escape') {
            event.preventDefault();
            this.closeCancel();
            return;
        }
        if (event.key !== 'Tab')
            return;
        const controls = [...this.querySelectorAll('.ns4-cancel-dialog button')];
        const index = controls.indexOf(document.activeElement);
        event.preventDefault();
        controls[(index + (event.shiftKey ? controls.length - 1 : 1)) % controls.length]?.focus();
    }
    renderFeedback() { const labels = this.labels(); if (!this.msgError && !this.msgOk)
        return ''; const error = Boolean(this.msgError); return html `<section class="ns4-feedback ${error ? 'is-error' : 'is-ok'}" role=${error ? 'alert' : 'status'} aria-live=${error ? 'assertive' : 'polite'} tabindex="-1">${error ? html `<strong>${labels.revise}</strong>` : ''}<span>${this.msgError || this.msgOk}</span>${this.feedbackIssues.length ? html `<ul>${this.feedbackIssues.map(issue => html `<li>${issue.path ? html `<code>${issue.path}</code> — ` : ''}${issue.message}</li>`)}</ul>` : ''}</section>`; }
    renderCancelDialog() { const labels = this.labels(); if (!this.cancelOpen)
        return ''; return html `<div class="ns4-dialog-backdrop"><section class="ns4-cancel-dialog" role="dialog" aria-modal="true" aria-labelledby="ns4-intake-cancel-title" @keydown=${this.trapCancel}><h3 id="ns4-intake-cancel-title">${labels.cancelTitle}</h3><p>${labels.cancelText}</p><div><button class="secondary ns4-cancel-stay" @click=${this.closeCancel}>${labels.keepWorking}</button><button class="danger" @click=${() => { this.closeCancel(); this.submit('cancel'); }}>${labels.cancel}</button></div></section></div>`; }
    render() {
        const review = this.value;
        if (!review)
            return html `<div class="ns4-empty">No initial definition is available.</div>`;
        const modernizing = review.strategy.mode !== 'newSolution';
        const hasAdjustment = Boolean(this.adjustment.trim());
        const disabled = this.readonly || this.submitting;
        return html `<section class="ns4-intake"><header><div><p class="ns4-step">👤 Step 1 of 6</p><h2>Initial solution definition</h2><p>Confirm the intent, scope and constraints that guide the following reviews.</p></div><span>Review ${review.reviewRound}</span></header>${this.renderFeedback()}
      <section><h3>Solution identity</h3><div class="ns4-grid three"><label><span>Technical module name</span><input .value=${review.module.moduleName} ?disabled=${disabled} @input=${(e) => this.updateInput('moduleName', e)}></label><label><span>Friendly title</span><input .value=${review.module.title} ?disabled=${disabled} @input=${(e) => this.updateInput('title', e)}></label><label class="wide"><span>Main objective</span><textarea .value=${review.module.purpose} ?disabled=${disabled} @input=${(e) => this.updateInput('purpose', e)}></textarea></label></div></section>
      <section><h3>Build strategy</h3><div class="ns4-strategies">${strategies.map(strategy => html `<label class="ns4-strategy ${review.strategy.mode === strategy.id ? 'selected' : ''}"><input type="radio" name="ns4-strategy" .checked=${review.strategy.mode === strategy.id} ?disabled=${disabled} @change=${() => this.selectStrategy(strategy.id)}><span><strong>${strategy.title}</strong><small>${strategy.description}</small><em>Data policy: ${policyFor(strategy.id)}</em><dl><div><dt>Preserves</dt><dd>${strategy.preserves}</dd></div><div><dt>May change</dt><dd>${strategy.changes}</dd></div><div><dt>E4</dt><dd>${strategy.e4}</dd></div></dl></span></label>`)}</div></section>
      <section><h3>Business scope</h3><div class="ns4-grid two"><label><span>Initial business actors</span><textarea .value=${review.businessScope.actors.map(item => item.title).join('\n')} ?disabled=${disabled} @input=${(e) => this.updateInput('actors', e)}></textarea></label><label><span>Expected outcomes</span><textarea .value=${review.businessScope.expectedOutcomes.map(item => item.title).join('\n')} ?disabled=${disabled} @input=${(e) => this.updateInput('outcomes', e)}></textarea></label><label><span>In scope</span><textarea .value=${review.businessScope.inScope.join('\n')} ?disabled=${disabled} @input=${(e) => this.updateInput('inScope', e)}></textarea></label><label><span>Out of scope</span><textarea .value=${review.businessScope.outOfScope.join('\n')} ?disabled=${disabled} @input=${(e) => this.updateInput('outOfScope', e)}></textarea></label></div></section>
      <section><h3>Languages and region</h3><div class="ns4-grid three"><label><span>Conversation language</span><input .value=${review.userLanguage} disabled></label><label><span>Product languages</span><input .value=${review.localization.productLanguages.join(', ')} ?disabled=${disabled} @input=${(e) => this.updateInput('languages', e)}></label><label><span>Default language</span><input .value=${review.localization.defaultLanguage} ?disabled=${disabled} @input=${(e) => this.updateInput('defaultLanguage', e)}></label></div></section>
      ${modernizing ? html `<section class="ns4-modernization"><h3>Modernization information</h3><div class="ns4-grid three"><label><span>Source system name</span><input .value=${review.strategy.modernization?.sourceSystemName || ''} ?disabled=${disabled} @input=${(e) => this.updateInput('sourceSystemName', e)}></label><label><span>Source technology</span><input .value=${review.strategy.modernization?.sourceTechnology || ''} ?disabled=${disabled} @input=${(e) => this.updateInput('sourceTechnology', e)}></label><label><span>Schema availability</span><select .value=${review.strategy.modernization?.schemaAvailability || 'uploadAtE4'} ?disabled=${disabled} @change=${(e) => this.updateInput('schemaAvailability', e)}><option value="uploadAtE4">Upload at E4</option><option value="metadataAtE4">Metadata at E4</option><option value="notAvailableYet">Not available yet</option></select></label></div></section>` : ''}
      <section><h3>Declared constraints</h3><label><span>Mandatory integrations or critical constraints</span><textarea .value=${review.declaredConstraints.mandatoryIntegrations.map(item => item.title).join('\n')} ?disabled=${disabled} @input=${(e) => this.updateInput('integrations', e)}></textarea></label></section>
      <section><h3>Follow-up mode</h3><div class="ns4-policies">${[{ id: 'guided', title: 'Guided review', text: 'Show every review from E1 to E6.' }, { id: 'smart', title: 'Smart review', text: 'Show later reviews only when there is risk or a relevant decision.' }, { id: 'automatic', title: 'Automatic execution', text: 'Generate and validate all artifacts; open later reviews only when forced.' }].map(policy => html `<label class=${review.reviewPolicy.mode === policy.id ? 'selected' : ''}><input type="radio" name="ns4-review-policy" .checked=${review.reviewPolicy.mode === policy.id} ?disabled=${disabled} @change=${() => this.selectReviewPolicy(policy.id)}><span><strong>${policy.title}</strong><small>${policy.text}</small></span></label>`)}</div></section>
      <footer><label><span>Request an adjustment</span><textarea .value=${this.adjustment} placeholder="Example: Include Spanish, keep the current database immutable and require SAP integration." ?disabled=${disabled} @input=${(e) => { this.adjustment = e.target.value; }}></textarea></label><div><button class="cancel" ?disabled=${disabled} @click=${this.openCancel}>${this.labels().cancel}</button><button class="secondary ${hasAdjustment ? 'is-active' : ''}" ?disabled=${disabled || !hasAdjustment} @click=${() => this.submit('requestChanges')}>Generate another proposal</button><button class="primary ${hasAdjustment ? '' : 'is-active'}" ?disabled=${disabled || hasAdjustment} @click=${() => this.submit('approve')}>Approve initial definition</button></div></footer>${this.renderCancelDialog()}
    </section>`;
    }
};
__decorate([
    property({ type: Object })
], WidgetNs4Intake102035.prototype, "value", void 0);
__decorate([
    property({ type: Object })
], WidgetNs4Intake102035.prototype, "presentation", void 0);
__decorate([
    property({ type: Boolean })
], WidgetNs4Intake102035.prototype, "readonly", void 0);
__decorate([
    state()
], WidgetNs4Intake102035.prototype, "adjustment", void 0);
__decorate([
    state()
], WidgetNs4Intake102035.prototype, "submitting", void 0);
__decorate([
    state()
], WidgetNs4Intake102035.prototype, "feedbackIssues", void 0);
__decorate([
    state()
], WidgetNs4Intake102035.prototype, "cancelOpen", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Intake102035.prototype, "msgError", void 0);
__decorate([
    property({ type: String })
], WidgetNs4Intake102035.prototype, "msgOk", void 0);
WidgetNs4Intake102035 = __decorate([
    customElement('widget-ns4-intake-102035')
], WidgetNs4Intake102035);
export { WidgetNs4Intake102035 };
