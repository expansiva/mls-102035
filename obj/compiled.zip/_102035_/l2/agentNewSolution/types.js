/// <mls fileReference="_102035_/l2/agentNewSolution/types.ts" enhancement="_blank"/>
export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, NS4_SOLUTION_REGISTRY_SCHEMA_VERSION, } from '/_102035_/l2/agentNewSolution/helpers/organizationTypes.js';
export { TEXT_PATHS_BY_SCHEMA, TEXT_PATHS_VERSION, textPathsForArtifact, } from '/_102035_/l2/agentNewSolution/helpers/ns4TextPaths.js';
export const NS4_PERMANENT_ARTIFACT_TYPE_NAMES = [
    'Ns4ModuleArtifact',
    'Ns4JourneyArtifact',
    'Ns4JourneyIndex',
    'Ns4AccessMatrixArtifact',
    'Ns4AccessBindingsArtifact',
    'Ns4OntologyEntityArtifact',
    'Ns4OntologyIndexArtifact',
    'Ns4RulesArtifact',
    'Ns4CompositionArtifact',
    'Ns4UseCaseArtifact',
    'Ns4UseCaseArtifactV3',
    'Ns4UseCaseIndexArtifact',
    'Ns4UseCaseIndexArtifactV3',
    'Ns4WorkflowArtifact',
    'Ns4WorkflowArtifactV2',
    'Ns4WorkflowIndexArtifact',
    'Ns4WorkflowIndexArtifactV2',
    'Ns4WorkflowIndexArtifactV3',
    'Ns4L5TodoFrontendArtifact',
    'Ns4L5TodoBackendArtifact',
    'Ns4L5ProcessArtifact',
    'Ns4Level1EntityArtifact',
    'Ns4Level1IndexArtifact',
    'Ns4SolutionRegistryArtifact',
];
