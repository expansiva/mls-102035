import { sha256Ns4 } from '/_102035_/l2/agentNewSolution/steps/e2/contracts.js';
export const NS4_COMPOSITION_SCHEMA_VERSION = '2026-08-09-ns4-composition-v1';
/** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
export const TEXT_PATHS_2026_08_09_ns4_composition_v1 = [
    'analysisSummary',
    'recommendations[].title',
    'recommendations[].purpose',
];
export function normalizeNs4E6Review(value, fallbackModule = '') {
    const root = record(value);
    return {
        planId: 'e6-composition-review',
        moduleName: text(root.moduleName) || fallbackModule,
        userLanguage: text(root.userLanguage) || 'en',
        title: text(root.title) || 'Additional modules and plugins',
        reviewRound: positiveInteger(root.reviewRound, 1),
        analysisSummary: text(root.analysisSummary),
        recommendations: array(root.recommendations).map(item => {
            const recommendation = record(item);
            return {
                id: text(recommendation.id),
                kind: text(recommendation.kind),
                title: text(recommendation.title),
                purpose: text(recommendation.purpose),
                decision: text(recommendation.decision),
                ...(recommendation.existing === true ? { existing: true } : {}),
            };
        }),
        changeSummary: strings(root.changeSummary),
    };
}
export async function buildNs4CompositionArtifact(review, approvedBy, approvedAt) {
    const source = {
        analysisSummary: review.analysisSummary,
        recommendations: review.recommendations,
    };
    const compositionHash = await sha256Ns4(source);
    return {
        schemaVersion: NS4_COMPOSITION_SCHEMA_VERSION,
        moduleName: review.moduleName,
        userLanguage: review.userLanguage,
        ...source,
        compositionHash,
        approvedBy,
        approvedAt,
        realization: { status: 'pending', compiledFromCompositionHash: compositionHash },
    };
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function array(value) { return Array.isArray(value) ? value : []; }
function strings(value) { return array(value).map(text).filter(Boolean); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function positiveInteger(value, fallback) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : fallback;
}
