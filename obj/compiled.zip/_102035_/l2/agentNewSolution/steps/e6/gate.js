const MEMBER_ID = /^[a-z][A-Za-z0-9]*$/;
const KINDS = new Set(['horizontalModule', 'plugin']);
const DECISIONS = new Set(['include', 'defer']);
export function validateNs4E6Review(review, module) {
    const issues = [];
    const add = (code, path, message) => issues.push({ code, path, message });
    if (review.moduleName !== module.module.moduleName)
        add('NS4_E6_MODULE', 'moduleName', 'Must match the approved module.');
    if (!review.analysisSummary)
        add('NS4_E6_SUMMARY', 'analysisSummary', 'A short analysis summary is required.');
    const ids = new Set();
    review.recommendations.forEach((item, index) => {
        const path = `recommendations[${index}]`;
        if (!MEMBER_ID.test(item.id))
            add('NS4_E6_ID', `${path}.id`, 'Must be a lower-camel id.');
        if (ids.has(item.id))
            add('NS4_E6_DUPLICATE', `${path}.id`, `Duplicate recommendation ${item.id}.`);
        if (item.id)
            ids.add(item.id);
        if (!KINDS.has(item.kind))
            add('NS4_E6_KIND', `${path}.kind`, 'Must be horizontalModule or plugin.');
        if (!DECISIONS.has(item.decision))
            add('NS4_E6_DECISION', `${path}.decision`, 'Must be include or defer.');
        if (!item.title)
            add('NS4_E6_TITLE', `${path}.title`, 'A title is required.');
        if (!item.purpose)
            add('NS4_E6_PURPOSE', `${path}.purpose`, 'A business purpose is required.');
    });
    return { ok: issues.length === 0, issues };
}
