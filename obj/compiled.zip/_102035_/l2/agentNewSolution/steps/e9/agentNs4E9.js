import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { resolveNs4MutableParent } from '/_102035_/l2/agentNewSolution/helpers/ns4StepTree.js';
import { isNs4Pipeline, markNs4E9Approved, markNs4E9Failed, markNs4E9Running, markNs4ModuleE9Approved, } from '/_102035_/l2/agentNewSolution/helpers/ns4Core.js';
import { readNs4DisclosureProjections } from '/_102035_/l2/agentNewSolution/helpers/ns4ApprovedArtifacts.js';
import { listNs4E7UseCaseDraftFiles, ns4AccessBindingsFile, ns4AccessMatrixFile, ns4UseCaseFile, ns4UseCaseIndexFile, ns4WorkspaceModelFile, readNs4DefsJson, readNs4Module, readNs4Pipeline, readNs4Text, writeNs4AccessMatrix, writeNs4ClassicContract, writeNs4ClassicWorkspace, writeNs4Module, writeNs4Operation, writeNs4Pipeline, writeNs4SiteMap, } from '/_102035_/l2/agentNewSolution/helpers/ns4Fs.js';
import { readNs4ApprovedOntology as readOntology } from '/_102035_/l2/agentNewSolution/helpers/ns4ApprovedArtifacts.js';
import { ns4OntologyWithDisclosure } from '/_102035_/l2/agentNewSolution/steps/e8/contracts.js';
import { buildNs4NavigationRealizedAccess, compileNs4ClassicL4 } from '/_102035_/l2/agentNewSolution/steps/e9/classic.js';
import { applyNs4UseCaseCoverage, compareE7ToOperations, useCaseCoverageLogLine, } from '/_102035_/l2/agentNewSolution/steps/e9/coverage.js';
export async function beforeNs4E9PromptStep(_agent, context, parent, step, hookSequential, args) {
    let moduleName = '';
    let failureOrigin = 'skeleton';
    try {
        const parsed = resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        const pipeline = await requirePipeline(moduleName);
        if (pipeline.steps.e8?.status !== 'approved')
            throw new Error(`E9 requires an approved E8 workspace index for ${moduleName}.`);
        await writeNs4Pipeline(markNs4E9Running(pipeline));
        // E9 takes no screen decision: it transposes the approved E8 model into the classic L4 format.
        const [model, ontology] = await Promise.all([readApprovedModel(moduleName), readOntology(moduleName)]);
        const accessBindings = await readNs4DefsJson(ns4AccessBindingsFile(moduleName), false) || undefined;
        const useCases = await readApprovedUseCases(moduleName);
        const l4 = await compileNs4ClassicL4(model, ns4OntologyWithDisclosure(ontology, await readNs4DisclosureProjections(moduleName, accessBindings)), useCases);
        const artifactPaths = [];
        for (const workspace of l4.workspaces)
            artifactPaths.push(await writeNs4ClassicWorkspace(moduleName, workspace.workspaceId, workspace));
        for (const operation of l4.operations)
            artifactPaths.push(await writeNs4Operation(moduleName, operation.operationId, operation));
        for (const contract of l4.contracts)
            artifactPaths.push(await writeNs4ClassicContract(moduleName, contract.workspaceId, contract.bffId, contract.source));
        artifactPaths.push(await writeNs4SiteMap(moduleName, l4.siteMap));
        const access = await readNs4DefsJson(ns4AccessMatrixFile(moduleName), true);
        if (access) {
            const realized = await buildNs4NavigationRealizedAccess(access, model, l4);
            artifactPaths.push(await writeNs4AccessMatrix(moduleName, realized));
        }
        const module = await readNs4Module(moduleName);
        if (!module)
            throw new Error(`Module artifact not found for ${moduleName}.`);
        const approvedAt = new Date().toISOString();
        await writeNs4Module(moduleName, markNs4ModuleE9Approved(module, approvedAt));
        const coverage = await auditE7ToOperations(moduleName, model, l4.operations.map(operation => operation.operationId));
        const approved = markNs4E9Approved(await requirePipeline(moduleName), artifactPaths, approvedAt);
        await writeNs4Pipeline(coverage ? applyNs4UseCaseCoverage(approved, coverage) : approved);
        const mutationParent = resolveNs4MutableParent(getAllSteps(context.task?.iaCompressed?.nextSteps), parent, step);
        const coverageFields = coverageFieldsForResult(coverage);
        return [result(context, mutationParent, {
                moduleName, workspaceCount: l4.workspaces.length, operationCount: l4.operations.length,
                contractCount: l4.contracts.length, artifactPaths, ...coverageFields,
            }), status(context, mutationParent, step, hookSequential, 'completed', `E9 emitted ${l4.workspaces.length} workspaces, ${l4.operations.length} operations and ${l4.contracts.length} contracts.${coverage ? ` ${useCaseCoverageLogLine(coverage)}.` : ''}`, 'input_output')];
    }
    catch (error) {
        const message = errorMessage(error);
        if (moduleName)
            await fail(moduleName, message, failureOrigin);
        return [status(context, parent, step, hookSequential, 'failed', message, 'input_output')];
    }
}
export async function afterNs4E9PromptStep(_agent, context, parent, step, hookSequential) {
    const message = 'E9 is deterministic and must never receive an LLM response.';
    const parsed = resolveArgs(context, step.prompt);
    await fail(parsed.moduleName, message, 'compiler');
    return [status(context, parent, step, hookSequential, 'failed', message, 'input_output')];
}
async function readApprovedUseCases(moduleName) {
    const index = await readNs4DefsJson(ns4UseCaseIndexFile(moduleName), false);
    if (!index?.useCases?.length)
        return [];
    const loaded = await Promise.all(index.useCases.map(entry => readNs4DefsJson(ns4UseCaseFile(moduleName, entry.useCaseId), false)));
    return loaded.filter((item) => !!item);
}
async function readApprovedModel(moduleName) {
    const parsed = await readNs4DefsJson(ns4WorkspaceModelFile(moduleName), true);
    if (!parsed || parsed.planId !== 'e8-workspace-model' || parsed.moduleName !== moduleName) {
        throw new Error(`Approved E8 workspace model not found for ${moduleName}.`);
    }
    return parsed;
}
function resolveArgs(context, value) {
    const root = parse(value);
    const moduleName = isRecord(root) && text(root.moduleName) ? text(root.moduleName) : findE8Module(context) || memory(context, 'resumeModule');
    if (!isRecord(root) || root.planId !== 'e9-navigation-compiler' || !moduleName)
        throw new Error('Invalid E9 step arguments or missing E8 module handoff.');
    return { planId: 'e9-navigation-compiler', moduleName };
}
function findE8Module(context) {
    const anchor = getAllSteps(context.task?.iaCompressed?.nextSteps).find(step => step.planning?.planId === 'e8-result');
    const value = anchor?.type === 'result' ? parse(anchor.result) : null;
    return isRecord(value) ? text(value.moduleName) : '';
}
async function requirePipeline(moduleName) { const pipeline = await readNs4Pipeline(moduleName); if (!isNs4Pipeline(pipeline))
    throw new Error(`Current agentNewSolution pipeline not found for ${moduleName}.`); return pipeline; }
/** Compare E7 drafts to written operations. A miss here never fails E9. */
async function auditE7ToOperations(moduleName, model, emittedOperationIds) {
    try {
        const approved = [];
        for (const file of listNs4E7UseCaseDraftFiles(moduleName)) {
            const useCaseId = file.shortName.replace(/-draft$/, '');
            if (!useCaseId)
                continue;
            let compiledFrom = [];
            const raw = await readNs4Text(file, false);
            if (raw) {
                try {
                    const parsed = JSON.parse(raw);
                    if (Array.isArray(parsed.compiledFrom)) {
                        compiledFrom = parsed.compiledFrom.filter((item) => typeof item === 'string');
                    }
                }
                catch { /* the filename is the approved id */ }
            }
            approved.push({ useCaseId, compiledFrom });
        }
        const hostedStepRefs = model.workspaces.flatMap(workspace => workspace.hostedStepRefs);
        return compareE7ToOperations({ approved, emittedOperationIds, hostedStepRefs });
    }
    catch {
        return undefined;
    }
}
function coverageFieldsForResult(coverage) {
    if (!coverage)
        return {};
    if (coverage.useCases === 'ok')
        return { useCases: 'ok' };
    return { useCases: 'degraded', useCasesDropped: coverage.useCasesDropped };
}
async function fail(moduleName, message, origin) { try {
    const pipeline = await readNs4Pipeline(moduleName);
    if (isNs4Pipeline(pipeline))
        await writeNs4Pipeline(markNs4E9Failed(pipeline, message, origin));
}
catch { /* task trace remains the fallback */ } }
function result(context, parent, value) { return { type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parent.stepId, step: { type: 'result', stepId: 0, interaction: null, stepTitle: 'E9 navigation compiled', status: 'completed', nextSteps: [], result: JSON.stringify({ ...value, completedStep: 'e9-navigation-compiler', nextStep: 'e10-validation' }, null, 2), planning: { planId: 'e9-result', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' } } }; }
function status(context, parent, step, hookSequential, state, traceMsg, cleaner) { return { type: 'update-status', hookSequential, messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parent.stepId, stepId: step.stepId, status: state, traceMsg, cleaner }; }
function formatGate(issues) { return issues.map(issue => `${issue.code} [${issue.origin}] ${issue.path}: ${issue.message}`).join('\n'); }
function parse(value) { if (typeof value !== 'string')
    return value; try {
    return JSON.parse(value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''));
}
catch {
    return value;
} }
function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function memory(context, key) { const value = context.task?.iaCompressed?.longMemory?.[key]; return typeof value === 'string' ? value.trim() : ''; }
function errorMessage(error) { return error instanceof Error ? error.message : String(error); }
