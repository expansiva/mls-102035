/// <mls fileReference="_102035_/l2/agentNewSolution/steps/e2/hookArgs.ts" enhancement="_blank"/>
export function resolveNs4E2HookArgs(args, stepPrompt) {
    return args || stepPrompt || JSON.stringify({ planId: 'e2-journeys', reviewRound: 1 });
}
