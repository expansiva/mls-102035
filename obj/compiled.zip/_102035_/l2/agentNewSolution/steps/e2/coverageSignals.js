export const NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL = 'moduleWithoutDecide';
export const NS4_E2_JOURNEY_WITHOUT_PROCESS_SIGNAL = 'journeyWithoutProcess';
const STEP_KINDS = ['locate', 'inspect', 'act', 'decide', 'handoff'];
export function analyzeNs4E2MechanicalCoverage(source) {
    const stepKindHistogram = {
        locate: 0,
        inspect: 0,
        act: 0,
        decide: 0,
        handoff: 0,
    };
    source.journeys.forEach(journey => journey.business.steps.forEach(step => {
        if (STEP_KINDS.includes(step.kind)) {
            stepKindHistogram[step.kind] += 1;
        }
    }));
    return {
        stepKindHistogram,
        findings: stepKindHistogram.decide === 0
            ? [{ signalId: NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL, severity: 'registrar' }]
            : [],
        captureOnlyJourneys: source.journeys.flatMap(journey => {
            const journeyId = typeof journey.journeyId === 'string' ? journey.journeyId : '';
            const entities = [...new Set(journey.business.steps.flatMap(stepEntities).filter(Boolean))];
            const hasProcess = journey.business.steps.some(step => step.kind === 'decide' || step.kind === 'handoff');
            const touchesRecords = journey.business.steps.some(step => step.kind === 'act');
            return journeyId && touchesRecords && !hasProcess && entities.length === 1
                ? [{ journeyId, entity: entities[0] }]
                : [];
        }),
    };
}
/**
 * A journey with no decision, no handoff and one single entity is the record catalogue of that
 * entity written as a flow. Tier 1 already owns that screen, so the module records the demotion as
 * a visible product choice instead of shipping the same catalogue twice.
 */
export function ns4E2DemotionDecisionId(journeyId) {
    return `demote${journeyId.slice(0, 1).toUpperCase()}${journeyId.slice(1)}ToRecordCatalogue`;
}
export function isNs4E2DemotionDecisionId(decisionId) {
    return /^demote[A-Z][A-Za-z0-9]*ToRecordCatalogue$/.test(decisionId);
}
/** The step's own entity plus every business object it lists in `affects`. */
function stepEntities(step) {
    const own = typeof step.entity === 'string' ? step.entity : '';
    const affects = Array.isArray(step.affects)
        ? step.affects.filter((item) => typeof item === 'string' && !!item)
        : [];
    return own ? [own, ...affects] : affects;
}
