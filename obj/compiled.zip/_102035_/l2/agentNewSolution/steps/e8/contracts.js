import { deriveNs4Contexts, isNs4PlatformOwnedEntity, } from '/_102035_/l2/agentNewSolution/helpers/ns4Context.js';
export { TEXT_PATHS_2026_08_14_ns4_e8_model_v1 } from '/_102035_/l2/agentNewSolution/steps/e8/model.js';
/** E9/E10 compile against the E4 index plus disclosure views that E8 already pointed at. */
export function ns4OntologyWithDisclosure(ontology, projections = []) {
    if (!projections.length)
        return ontology;
    const have = new Set(ontology.entities.map(entity => entity.entityId));
    const extra = projections.filter(entity => !have.has(entity.entityId));
    return extra.length ? { ...ontology, entities: [...ontology.entities, ...extra] } : ontology;
}
export function deriveE8HubScore(sources, derived = deriveNs4Contexts(sources)) {
    const journeysByEntity = new Map();
    for (const step of derived.steps) {
        if (!step.entity)
            continue;
        journeysByEntity.set(step.entity, new Set([...(journeysByEntity.get(step.entity) || []), step.journeyId]));
    }
    const results = sources.ontology.entities
        .filter(entity => !isPlatformOwnedEntity(entity))
        .map(entity => {
        const anchoredJourneyIds = journeysByEntity.get(entity.entityId) || new Set();
        const requiredRelationshipCount = sources.ontology.relationships
            .filter(relationship => relationship.required && relationship.toEntity === entity.entityId).length;
        const projectionCount = sources.ontology.entities.filter(candidate => candidate.kind === 'projection'
            && candidate.sourceRefs.journeyIds.some(id => anchoredJourneyIds.has(id))).length;
        const locateUseCaseCount = derived.steps.filter(step => step.kind === 'locate' && step.entity === entity.entityId).length;
        const anchoredJourneyCount = anchoredJourneyIds.size;
        return { entityRef: entity.entityId, anchoredJourneyCount, requiredRelationshipCount, projectionCount, locateUseCaseCount,
            score: anchoredJourneyCount + requiredRelationshipCount + projectionCount + locateUseCaseCount };
    })
        .filter(item => item.score > 0)
        .sort((left, right) => right.score - left.score || left.entityRef.localeCompare(right.entityRef));
    return results;
}
/**
 * The hub is the entity the module structurally revolves around. A clear score dominance decides it;
 * when derived scores are too flat to separate, the strict maximum of incoming required relationships
 * still names one anchor, because a module without a hub degenerates into single-scenario workspaces.
 */
function selectHubEntity(ranking) {
    const first = ranking[0];
    if (!first || first.score <= 0)
        return '';
    const secondScore = ranking[1]?.score || 0;
    if (secondScore === 0 || first.score >= secondScore * 2)
        return first.entityRef;
    const byRelationship = [...ranking].sort((left, right) => right.requiredRelationshipCount - left.requiredRelationshipCount
        || right.score - left.score || left.entityRef.localeCompare(right.entityRef));
    const [best, runnerUp] = byRelationship;
    return best.requiredRelationshipCount > 0 && best.requiredRelationshipCount > (runnerUp?.requiredRelationshipCount || 0)
        ? best.entityRef : '';
}
export function isPlatformOwnedEntity(entity) {
    return isNs4PlatformOwnedEntity(entity);
}
