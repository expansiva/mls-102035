/// <mls fileReference="_102035_/l2/agentNewSolution/steps/e8/model.ts" enhancement="_blank"/>
/**
 * The E8 workspace model: every screen of the module, in the shape E9 transposes into the classic
 * L4 format without taking a single decision of its own.
 *
 * A screen is a place: the record catalogue of an entity (tier 1), an approved journey that is
 * itself a place (tier 2: distinct actor, eventDriven/contextRequired, or more than one entity),
 * the hub of the dominant anchor when it has related lists or projection tiles (tier 3),
 * or a content page (`contentPage`) when E1 names an informative/institutional/public-campaign
 * page. A journey of the same actor on an entity the catalogue already shows is hosted there
 * (`hostedStepRefs`); it is not another kind of page.
 */
import { buildNs4ParentIndex, ns4FkParentOf } from '/_102035_/l2/agentNewSolution/helpers/ns4ForeignKeys.js';
export const NS4_E8_MODEL_VERSION = '2026-08-14-ns4-e8-model-v1';
/**
 * The record-owner handle: a field that points at a `party: person` entity (its own identity, or a
 * foreign key to one) when every E3 grant that operates the record is `dataScope.mode: own` — or
 * when the session actor is that person (an `own`/`assigned`/`related` grant). Never a field name.
 */
export function isNs4OwnerHandleInput(input, sources) {
    const ownerId = input.fieldRef.entityId;
    const fieldId = input.fieldRef.fieldId;
    const entities = new Map(sources.ontology.entities.map(entity => [entity.entityId, entity]));
    const owner = entities.get(ownerId);
    if (!owner)
        return false;
    const parent = ns4FkParentOf(buildNs4ParentIndex(sources.ontology.relationships), ownerId, fieldId);
    const referenced = parent ? entities.get(parent.parent) : undefined;
    const person = referenced?.party === 'person' ? referenced : owner.party === 'person' ? owner : undefined;
    if (!person)
        return false;
    if (person.entityId === ownerId) {
        const idField = person.storage?.idField
            || person.fields.find(field => /Id$/.test(field.fieldId))?.fieldId
            || '';
        if (fieldId !== idField)
            return false;
        // Pagination borrows the identity fieldRef (`page`/`pageSize`); that is not a handle.
        if (input.inputId && input.inputId !== fieldId)
            return false;
        return sources.access.grants.some(grant => {
            const mode = grant.dataScope?.mode;
            return mode === 'own' || mode === 'assigned' || mode === 'related';
        });
    }
    return entityOwnedByOwnGrants(ownerId, sources);
}
function entityOwnedByOwnGrants(entityId, sources) {
    const modes = new Set();
    for (const authority of sources.access.authorities) {
        const operates = authority.journeyStepRefs.some(ref => {
            const dot = ref.lastIndexOf('.');
            const journeyId = dot >= 0 ? ref.slice(0, dot) : ref;
            const stepId = dot >= 0 ? ref.slice(dot + 1) : '';
            const journey = sources.journeys.journeys.find(item => item.journeyId === journeyId);
            const step = journey?.business.steps.find(item => item.stepId === stepId);
            return step?.entity === entityId;
        });
        if (!operates)
            continue;
        for (const grant of sources.access.grants) {
            if (grant.authorityRef === authority.authorityRef && grant.dataScope?.mode)
                modes.add(grant.dataScope.mode);
        }
    }
    return modes.size === 1 && modes.has('own');
}
