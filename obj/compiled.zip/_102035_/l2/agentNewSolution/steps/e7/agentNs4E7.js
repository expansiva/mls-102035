/// <mls fileReference="_102035_/l2/agentNewSolution/steps/e7/agentNs4E7.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { msgApplyIntents } from '/_102036_/l2/shared/api.js';
import { resolveNs4MutableParent } from '/_102035_/l2/agentNewSolution/helpers/ns4StepTree.js';
import { createNs4FlexibleWorkerTool, unwrapNs4FlexibleWorkerPayload } from '/_102035_/l2/agentNewSolution/helpers/ns4WorkerTools.js';
import { showNs4ClarificationError } from '/_102035_/l2/agentNewSolution/helpers/ns4Clarification.js';
import { createNs4E2Step, createNs4E4Step, isNs4Pipeline, markNs4E7Approved, markNs4E7Failed, markNs4E7Running, markNs4ModuleE7Approved, NS4_E7_MAX_PARALLEL, } from '/_102035_/l2/agentNewSolution/helpers/ns4Core.js';
import { readNs4ApprovedAccess, readNs4ApprovedJourneys, readNs4ApprovedOntology, } from '/_102035_/l2/agentNewSolution/helpers/ns4ApprovedArtifacts.js';
import { ns4AccessMatrixFile, ns4AgentFile, ns4E7PlanDraftFile, ns4E7UseCaseDraftFile, ns4E7ValidationReportFile, ns4JourneyFile, ns4JourneyIndexFile, ns4OntologyIndexFile, ns4RulesFile, readNs4AgentText, readNs4DefsJson, readNs4Module, readNs4Pipeline, readNs4Text, writeNs4AccessMatrix, writeNs4E7PlanDraft, writeNs4E7UseCaseDraft, writeNs4E7ValidationReport, writeNs4Journey, writeNs4JourneyIndex, writeNs4Module, writeNs4Pipeline, writeNs4UseCase, writeNs4UseCaseIndex, writeNs4Workflow, writeNs4WorkflowIndex, } from '/_102035_/l2/agentNewSolution/helpers/ns4Fs.js';
import { buildNs4E7Plan, buildNs4RealizedAccessArtifact, buildNs4RealizedJourneyArtifact, buildNs4RealizedJourneyIndex, buildNs4UseCaseArtifacts, buildNs4WorkflowArtifacts, normalizeNs4UseCaseDraft, NS4_USE_CASE_DRAFT_VERSION, workflowLifecycleOf, } from '/_102035_/l2/agentNewSolution/steps/e7/contracts.js';
import { ns4E7WriteIntentDecisions, validateNs4E7Plan, validateNs4UseCaseDraft, validateNs4Workflows, } from '/_102035_/l2/agentNewSolution/steps/e7/gate.js';
import { deriveNs4Contexts } from '/_102035_/l2/agentNewSolution/helpers/ns4Context.js';
import { createNs4E7LifecycleResolutionReview } from '/_102035_/l2/agentNewSolution/steps/e7/lifecycleResolution.js';
import { isNs4E7ValidationReport, mergeNs4E7ValidationAttempts, NS4_E7_VALIDATION_REPORT_VERSION, } from '/_102035_/l2/agentNewSolution/steps/e7/validationReport.js';
const MAX_REPAIR_ROUNDS = 1;
export async function beforeNs4E7PromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error('[agentNewSolution:e7] task invalid');
    const selector = parseUseCaseSelector(args) || parseUseCaseSelector(step.prompt);
    let moduleName = '';
    try {
        if (selector) {
            moduleName = resolveModuleName(context);
            if (!moduleName)
                throw new Error('E6 module result not found for E7 worker.');
            return [await buildUseCasePrompt(context, parentStep, hookSequential, args || selector, moduleName, selector)];
        }
        const invocation = resolveArgs(context, args || step.prompt);
        moduleName = invocation.moduleName;
        if (invocation.stage === 'finalize')
            return finalizeE7(context, parentStep, step, hookSequential, invocation);
        return startE7(context, parentStep, step, hookSequential, moduleName, agent.agentName);
    }
    catch (error) {
        const message = errorMessage(error);
        if (selector)
            return [updateStatus(context, parentStep, step, hookSequential, 'completed', `Use case ${selector} prompt failed; finalizer will repair it. | ${message}`, 'input_output')];
        await recordFailure(moduleName, message);
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', message, 'input_output')];
    }
}
export async function afterNs4E7PromptStep(agent, context, parentStep, step, hookSequential, args) {
    const useCaseId = parseUseCaseSelector(args) || parseUseCaseSelector(step.prompt);
    if (!useCaseId) {
        const message = 'E7 deterministic plan/finalizer must not invoke an LLM afterPrompt.';
        return [updateStatus(context, parentStep, step, hookSequential, 'failed', message, 'input_output')];
    }
    let moduleName = '';
    try {
        moduleName = resolveModuleName(context);
        const [plan, bundle] = await Promise.all([readPlan(moduleName), loadBundle(moduleName)]);
        const payload = unwrap(step.interaction?.payload?.[0]);
        if (!isRecord(payload))
            return [updateStatus(context, parentStep, step, hookSequential, 'completed', `Use case ${useCaseId} returned no usable payload; finalizer will repair it.`, 'input_output')];
        const draft = normalizeNs4UseCaseDraft(payload, plan, useCaseId);
        await writeNs4E7UseCaseDraft(moduleName, useCaseId, draft);
        const gate = validateNs4UseCaseDraft(plan, draft, bundle);
        return [updateStatus(context, parentStep, step, hookSequential, 'completed', gate.ok
                ? `Use case ${useCaseId} detail saved.`
                : `Use case ${useCaseId} gate failed; finalizer will repair it. | ${formatGate(gate.issues)}`, 'input_output')];
    }
    catch (error) {
        return [updateStatus(context, parentStep, step, hookSequential, 'completed', `Use case ${useCaseId} failed; finalizer will repair it. | ${errorMessage(error)}`, 'input_output')];
    }
}
async function startE7(context, parentStep, step, hookSequential, moduleName, agentName) {
    const bundle = await loadBundle(moduleName);
    if (bundle.pipeline.steps.e6?.status !== 'approved')
        throw new Error(`E6 approved pipeline not found for ${moduleName}.`);
    const plan = buildNs4E7Plan(moduleName, bundle.module.presentation.userLanguage, bundle.journeys, bundle.sourceHashes, deriveNs4Contexts(bundle), bundle.module.presentation);
    const gate = validateNs4E7Plan(plan, bundle);
    if (!gate.ok)
        throw new Error(formatGate(gate.issues));
    const planPath = await writeNs4E7PlanDraft(moduleName, plan);
    await writeNs4Pipeline(markNs4E7Running(bundle.pipeline, planPath));
    const existing = await Promise.all(plan.useCases.map(async (target) => ({
        useCaseId: target.useCaseId,
        draft: await readDraft(moduleName, target.useCaseId, plan),
    })));
    const pending = existing.filter(item => !item.draft || !validateNs4UseCaseDraft(plan, item.draft, bundle).ok)
        .map(item => item.useCaseId);
    if (!pending.length) {
        return finalizeE7(context, parentStep, step, hookSequential, { planId: 'e7-realization', moduleName, stage: 'finalize', repairRound: 0 });
    }
    const mutationParent = findMutableParent(context, parentStep, step);
    const parallel = parallelUseCaseStep(context, step, agentName, plan, 0, pending);
    return [
        parallel,
        addStep(context, mutationParent, createFinalizeStep(moduleName, 0, [String(parallel.step.planning?.planId || '')])),
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `E7 planned ${plan.useCases.length} use cases; ${plan.useCases.length - pending.length} valid drafts reused and ${pending.length} detailing with maxParallel=${NS4_E7_MAX_PARALLEL}.`, 'input_output'),
    ];
}
async function buildUseCasePrompt(context, parentStep, hookSequential, hookArgs, moduleName, useCaseId) {
    const [plan, bundle, prompt, tool] = await Promise.all([
        readPlan(moduleName), loadBundle(moduleName), readNs4AgentText('steps/e7', 'promptUseCase'), readNs4UseCaseWorkerTool(),
    ]);
    const current = await readDraft(moduleName, useCaseId, plan);
    const target = plan.useCases.find(item => item.useCaseId === useCaseId);
    if (!target)
        throw new Error(`Use case ${useCaseId} is not present in the E7 plan.`);
    const sourceRefs = new Set(target.compiledFrom);
    const journeyIds = new Set(target.compiledFrom.map(ref => ref.split('.')[0]));
    const derived = deriveNs4Contexts(bundle);
    const journeys = bundle.journeys.journeys.filter(journey => journeyIds.has(journey.journeyId)).map(journey => {
        const compiledSteps = journey.business.steps.filter(step => sourceRefs.has(`${journey.journeyId}.${step.stepId}`));
        const requiredContexts = new Set(compiledSteps.flatMap(step => derived.byStepRef.get(`${journey.journeyId}.${step.stepId}`)?.requires.map(context => context.contextId) || []));
        const producerSteps = journey.business.steps.filter(step => (derived.byStepRef.get(`${journey.journeyId}.${step.stepId}`)?.provides || [])
            .some(context => requiredContexts.has(context.contextId)));
        const relevantStepIds = new Set([...compiledSteps, ...producerSteps].map(step => step.stepId));
        return { journeyId: journey.journeyId, entry: journey.business.entry, useRules: journey.business.useRules,
            steps: journey.business.steps.filter(step => relevantStepIds.has(step.stepId)).map(step => ({
                ...step, contexts: derived.byStepRef.get(`${journey.journeyId}.${step.stepId}`)
            })) };
    });
    const businessObjects = new Set(journeys.flatMap(journey => journey.steps.map(step => step.entity)).filter(Boolean));
    const relationships = bundle.ontology.relationships.filter(rel => businessObjects.has(rel.fromEntity) || businessObjects.has(rel.toEntity));
    const entityIds = new Set([
        ...businessObjects,
        ...relationships.flatMap(rel => [rel.fromEntity, rel.toEntity]),
    ]);
    const entities = bundle.ontology.entities.filter(entity => entityIds.has(entity.entityId))
        .map(entity => ({ entityId: entity.entityId, title: entity.title, description: entity.description,
        lifecycleStates: entity.lifecycleStates, useRules: entity.useRules }));
    const relationshipSummary = relationships.map(relationship => ({ relationshipId: relationship.relationshipId,
        fromEntity: relationship.fromEntity, toEntity: relationship.toEntity, type: relationship.type,
        required: relationship.required, description: relationship.description }));
    const candidateRuleIds = new Set([
        ...journeys.flatMap(journey => journey.useRules),
        ...entities.flatMap(entity => entity.useRules),
    ]);
    const relevantRules = bundle.rules.rules.filter(rule => candidateRuleIds.has(rule.id));
    const currentGate = current ? validateNs4UseCaseDraft(plan, current, bundle) : null;
    const humanPrompt = [
        `## Frozen use case plan\n${JSON.stringify(target)}`,
        `## Source journey steps and typed contexts\n${JSON.stringify(journeys)}`,
        `## Relevant E4 entity and relationship catalog\n${JSON.stringify({ entities, relationships: relationshipSummary })}`,
        `## Candidate E5 rules; select only behavior-owned rules\n${JSON.stringify(relevantRules)}`,
        current ? `## Current draft; preserve valid decisions\n${JSON.stringify(current)}` : '',
        currentGate && !currentGate.ok ? `## Deterministic repair required\n${formatGate(currentGate.issues)}` : '',
        `## Required identity\nmoduleName=${moduleName}; useCaseId=${useCaseId}; userLanguage=${plan.userLanguage}`,
    ].filter(Boolean).join('\n\n');
    return { type: 'prompt_ready', args: hookArgs, messageId: context.message.orderAt,
        threadId: context.message.threadId, taskId: context.task?.PK || '', hookSequential,
        parentStepId: parentStep.stepId, systemPrompt: prompt, humanPrompt,
        tools: [tool], toolChoice: { type: 'function', function: { name: tool.function.name } } };
}
async function finalizeE7(context, parentStep, step, hookSequential, args) {
    const [plan, bundle] = await Promise.all([readPlan(args.moduleName), loadBundle(args.moduleName)]);
    const valid = [];
    const invalid = [];
    const validationResults = [];
    for (const target of plan.useCases) {
        const draft = await readDraft(args.moduleName, target.useCaseId, plan);
        if (!draft) {
            invalid.push(target.useCaseId);
            validationResults.push({ useCaseId: target.useCaseId, status: 'missing', issues: [{
                        code: 'NS4_E7_DRAFT_MISSING', path: 'draft', message: 'Use case draft was not persisted.',
                    }] });
            continue;
        }
        const draftGate = validateNs4UseCaseDraft(plan, draft, bundle);
        validationResults.push({ useCaseId: target.useCaseId, status: draftGate.ok ? 'valid' : 'invalid', issues: draftGate.issues });
        if (!draftGate.ok)
            invalid.push(target.useCaseId);
        else
            valid.push(draft);
    }
    const repairRound = args.repairRound || 0;
    const reportStatus = invalid.length ? repairRound < MAX_REPAIR_ROUNDS ? 'repairing' : 'failed' : 'passed';
    const mutationParent = findMutableParent(context, parentStep);
    if (invalid.length && repairRound < MAX_REPAIR_ROUNDS) {
        await updateValidationReport(args.moduleName, repairRound, validationResults, reportStatus);
        const parallel = parallelUseCaseStep(context, step, 'agentNewSolution', plan, repairRound + 1, invalid);
        return [parallel,
            addStep(context, mutationParent, createFinalizeStep(args.moduleName, repairRound + 1, [String(parallel.step.planning?.planId || '')])),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `${invalid.length} invalid/missing use cases; targeted parallel repair started: ${invalid.join(', ')}.`, 'input_output')];
    }
    if (invalid.length) {
        await updateValidationReport(args.moduleName, repairRound, validationResults, reportStatus);
        throw new Error(`E7 use cases remain invalid after repair: ${invalid.join(', ')}.`);
    }
    const generatedAt = new Date().toISOString();
    const writeDecisions = ns4E7WriteIntentDecisions(valid, bundle, plan.presentation);
    const { artifacts: useCases, index: useCaseIndex } = await buildNs4UseCaseArtifacts(plan, valid, generatedAt, writeDecisions);
    const ontologyLifecycles = new Map(bundle.ontology.entities.map(entity => [entity.entityId, workflowLifecycleOf(entity)]));
    const { artifacts: workflows, index: workflowIndex } = await buildNs4WorkflowArtifacts(plan, valid, ontologyLifecycles, generatedAt);
    const workflowGate = validateNs4Workflows(workflows, bundle, useCases.map(useCase => useCase.useCaseId), workflowIndex.systemDecisions);
    if (!workflowGate.ok) {
        await updateValidationReport(args.moduleName, repairRound, validationResults, 'failed', workflowGate.issues);
        throw new Error(`E7 workflow structural gate failed: ${formatGate(workflowGate.issues)}.`);
    }
    await updateValidationReport(args.moduleName, repairRound, validationResults, 'passed');
    const artifactPaths = [];
    for (const useCase of useCases)
        artifactPaths.push(await writeNs4UseCase(args.moduleName, useCase.useCaseId, useCase));
    artifactPaths.push(await writeNs4UseCaseIndex(args.moduleName, useCaseIndex));
    for (const workflow of workflows)
        artifactPaths.push(await writeNs4Workflow(args.moduleName, workflow.workflowId, workflow));
    artifactPaths.push(await writeNs4WorkflowIndex(args.moduleName, workflowIndex));
    const derivedContexts = deriveNs4Contexts(bundle);
    const realizedJourneys = await Promise.all(bundle.journeyArtifacts.map(journey => buildNs4RealizedJourneyArtifact(journey, useCases, derivedContexts)));
    for (const journey of realizedJourneys)
        artifactPaths.push(await writeNs4Journey(args.moduleName, journey.journeyId, journey));
    artifactPaths.push(await writeNs4JourneyIndex(args.moduleName, await buildNs4RealizedJourneyIndex(bundle.journeyIndex, realizedJourneys)));
    artifactPaths.push(await writeNs4AccessMatrix(args.moduleName, await buildNs4RealizedAccessArtifact(bundle.accessArtifact, useCases)));
    await writeNs4Module(args.moduleName, markNs4ModuleE7Approved(bundle.module, generatedAt));
    await writeNs4Pipeline(markNs4E7Approved(await requirePipeline(args.moduleName), artifactPaths, generatedAt));
    return [
        resultStep(context, mutationParent, args.moduleName, useCases.length, workflows.length, artifactPaths),
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `E7 compiled ${useCases.length} use cases and ${workflows.length} workflows with ${workflowIndex.systemDecisions.length} system decision(s).`, 'input_output'),
    ];
}
async function loadBundle(moduleName) {
    const [module, pipeline, journeys, access, ontology, journeyIndex, accessArtifact, ontologyIndex, rules] = await Promise.all([
        readNs4Module(moduleName), requirePipeline(moduleName), readNs4ApprovedJourneys(moduleName),
        readNs4ApprovedAccess(moduleName), readNs4ApprovedOntology(moduleName),
        readNs4DefsJson(ns4JourneyIndexFile(moduleName), true),
        readNs4DefsJson(ns4AccessMatrixFile(moduleName), true),
        readNs4DefsJson(ns4OntologyIndexFile(moduleName), true),
        readNs4DefsJson(ns4RulesFile(moduleName), true),
    ]);
    if (!module || !journeyIndex || !accessArtifact || !ontologyIndex || !rules) {
        throw new Error(`E7 approved source artifacts are incomplete for ${moduleName}.`);
    }
    const journeyArtifacts = await Promise.all(journeyIndex.journeys.map(entry => readNs4DefsJson(ns4JourneyFile(moduleName, entry.journeyId), true)));
    if (journeyArtifacts.some(item => !item))
        throw new Error(`E7 cannot read every approved journey for ${moduleName}.`);
    const sourceHashes = {
        journeys: journeyIndex.journeys.map(entry => ({ journeyId: entry.journeyId, businessHash: entry.businessHash })),
        ontologyHash: ontologyIndex.ontologyHash, rulesHash: rules.rulesHash,
    };
    return { module, pipeline, journeys, access, ontology, journeyIndex,
        journeyArtifacts: journeyArtifacts, accessArtifact, ontologyIndex,
        rules, sourceHashes };
}
function parallelUseCaseStep(context, hostStep, agentName, plan, repairRound, useCaseIds = plan.useCases.map(item => item.useCaseId)) {
    if (!context.task || !useCaseIds.length)
        throw new Error('E7 use case fan-out cannot be empty.');
    const planId = `e7-realization-usecases-${repairRound}`;
    return { type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task.PK, parentStepId: hostStep.stepId,
        step: { type: 'agent', stepId: 0,
            interaction: { input: [{ type: 'system', content: '<!-- modelType: reasoning -->' }], cost: 0,
                trace: [`queued ${useCaseIds.length} E7 use cases with maxParallel=${NS4_E7_MAX_PARALLEL}`], payload: null },
            stepTitle: 'Realizing {{completed}}/{{total}} use cases, failed {{failed}}', status: 'in_progress',
            nextSteps: [], agentName, onFailure: 'wait_after_prompt', prompt: JSON.stringify({ planId: 'e7-realization' }), rags: [],
            planning: { planId, dependsOn: [], executionMode: 'parallel_dynamic', executionHost: 'client' },
        },
        executionMode: { type: 'parallel', args: useCaseIds.map(useCaseId => `usecase:${useCaseId}`), maxParallel: NS4_E7_MAX_PARALLEL } };
}
function createFinalizeStep(moduleName, repairRound, dependsOn) {
    return { type: 'agent', stepId: 0, interaction: null, stepTitle: `Finalize E7 realization${repairRound ? ` · R${repairRound}` : ''}`,
        status: 'waiting_dependency', nextSteps: [], agentName: 'agentNewSolution',
        prompt: JSON.stringify({ planId: 'e7-realization', moduleName, stage: 'finalize', repairRound }), rags: [],
        planning: { planId: `e7-realization-finalize-${repairRound}`, dependsOn, executionMode: 'sequential', executionHost: 'client' } };
}
export async function beforeNs4E7ClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    const review = parseLifecycleResolution(json);
    if (!review)
        throw new Error('Invalid E7 lifecycle resolution checkpoint.');
    await import('/_102035_/l2/agentNewSolution/widgets/widgetNs4LifecycleResolution.js');
    const element = document.createElement('widget-ns4-lifecycle-resolution-102035');
    element.value = review;
    element.addEventListener('ns4-lifecycle-resolution', (event) => {
        void applyLifecycleResolution(context, parentStep, step, hookSequential, event.detail)
            .catch(error => { showNs4ClarificationError(element, error); console.error(`[${agent.agentName}] ${errorMessage(error)}`); });
    });
    return element;
}
async function applyLifecycleResolution(context, parentStep, step, hookSequential, event) {
    if (!context.task)
        throw new Error('[agentNewSolution:e7] task invalid');
    const review = parseLifecycleResolution(step.json);
    if (!review || event.moduleName !== review.moduleName)
        throw new Error('Lifecycle resolution does not match its checkpoint.');
    const actions = new Map(event.selections.map(selection => [selection.findingId, selection.action]));
    if (actions.size !== review.findings.length || review.findings.some(finding => !actions.has(finding.findingId))) {
        throw new Error('Choose operateState or shrinkLifecycle for every lifecycle finding.');
    }
    if ([...actions.values()].some(action => action !== 'operateState' && action !== 'shrinkLifecycle')) {
        throw new Error('Each lifecycle resolution must be operateState or shrinkLifecycle.');
    }
    const selected = review.findings.map(finding => ({ finding, action: actions.get(finding.findingId) }));
    const operate = selected.filter(item => item.action === 'operateState');
    const shrink = selected.filter(item => item.action === 'shrinkLifecycle');
    const pipeline = await requirePipeline(review.moduleName);
    const parent = findMutableParent(context, parentStep);
    const intents = [];
    if (operate.length) {
        const feedback = lifecycleFeedback(operate, 'operateState');
        intents.push(addStep(context, parent, createNs4E2Step(review.moduleName, Math.max(1, (pipeline.steps.e2?.reviewRound || 1) + 1), feedback, [], pipeline.presentation.stepTitles['e2-journeys'])));
    }
    if (shrink.length) {
        const feedback = lifecycleFeedback(shrink, 'shrinkLifecycle');
        intents.push(addStep(context, parent, createNs4E4Step(review.moduleName, Math.max(1, (pipeline.steps.e4?.reviewRound || 1) + 1), feedback, operate.length ? ['e2-result'] : [], pipeline.presentation.stepTitles['e4-ontology'])));
    }
    intents.push(updateStatus(context, parent, step, hookSequential, 'completed', 'Lifecycle decisions recorded; the selected upstream round is ready without retrying E7.', 'input_output'));
    await applyIntents(context, intents);
    await continuePoolingTask(context);
}
function lifecycleResolutionStep(context, parent, moduleName, issues) {
    const review = createNs4E7LifecycleResolutionReview(moduleName, issues);
    return addStep(context, parent, {
        type: 'clarification', stepId: 0, interaction: null, status: 'pending', nextSteps: [],
        stepTitle: 'Resolve lifecycle findings',
        json: JSON.stringify(review),
        planning: { planId: 'e7-lifecycle-resolution', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    });
}
function parseLifecycleResolution(value) {
    const root = parse(value);
    if (!isRecord(root) || root.planId !== 'e7-lifecycle-resolution' || !text(root.moduleName) || !Array.isArray(root.findings))
        return null;
    const findings = root.findings.filter(isRecord).map(item => ({
        findingId: text(item.findingId), code: text(item.code), path: text(item.path), message: text(item.message),
        repairOptions: item.repairOptions,
    })).filter(item => item.findingId && item.code && item.path && item.message && Array.isArray(item.repairOptions));
    return findings.length === root.findings.length ? { planId: 'e7-lifecycle-resolution', moduleName: text(root.moduleName), findings } : null;
}
function lifecycleFeedback(selected, action) {
    return [
        'Human lifecycle resolution:',
        ...selected.map(({ finding }) => `- ${finding.code} ${finding.path}: ${finding.message}`),
        action === 'operateState'
            ? 'Add or amend explicit journey steps that operate these lifecycle states; preserve all unrelated approved contracts.'
            : 'Remove or redefine only these lifecycle states when they are not required business outcomes; preserve all unrelated approved contracts.',
    ].join('\n');
}
function resultStep(context, parentStep, moduleName, useCaseCount, workflowCount, artifactPaths) {
    return addStep(context, parentStep, { type: 'result', stepId: 0, interaction: null,
        stepTitle: 'E7 realization completed', status: 'completed', nextSteps: [],
        result: JSON.stringify({ moduleName, useCaseCount, workflowCount, artifactPaths,
            completedStep: 'e7-realization', nextStep: 'e8-workspaces' }, null, 2),
        planning: { planId: 'e7-result', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' } });
}
function addStep(context, parentStep, step) {
    return { type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', parentStepId: parentStep.stepId, step };
}
async function applyIntents(context, intents) {
    const response = await msgApplyIntents({ userId: context.message.senderId, intents });
    if (!response || response.statusCode !== 200)
        throw new Error(response?.msg || 'Error applying E7 lifecycle resolution intents.');
    const applied = response;
    context.task = applied.task;
    if (applied.message)
        context.message = applied.message;
}
function updateStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    return { type: 'update-status', hookSequential, messageId: context.message.orderAt,
        threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: parentStep.stepId,
        stepId: step.stepId, status, ...(traceMsg ? { traceMsg } : {}), ...(cleaner ? { cleaner } : {}) };
}
function findMutableParent(context, parentStep, phaseStep) {
    return resolveNs4MutableParent(getAllSteps(context.task?.iaCompressed?.nextSteps), parentStep, phaseStep);
}
async function readPlan(moduleName) {
    const parsed = parse(await readNs4Text(ns4E7PlanDraftFile(moduleName), true));
    if (!isRecord(parsed) || parsed.planId !== 'e7-realization-plan')
        throw new Error(`Invalid E7 plan for ${moduleName}.`);
    return parsed;
}
async function updateValidationReport(moduleName, round, results, finalStatus, lifecycleIssues = []) {
    const now = new Date().toISOString();
    const previous = round > 0 ? await readValidationReport(moduleName) : null;
    const attempt = { round, checkedAt: now, valid: results.filter(result => result.status === 'valid').length,
        invalid: results.filter(result => result.status !== 'valid').length, results, lifecycleIssues };
    const attempts = mergeNs4E7ValidationAttempts(previous?.attempts || [], attempt);
    await writeNs4E7ValidationReport(moduleName, {
        schemaVersion: NS4_E7_VALIDATION_REPORT_VERSION, moduleName, attempts, finalStatus, updatedAt: now,
    });
}
async function readValidationReport(moduleName) {
    const parsed = parse(await readNs4Text(ns4E7ValidationReportFile(moduleName), false));
    if (!isNs4E7ValidationReport(parsed, moduleName))
        return null;
    return parsed;
}
async function readDraft(moduleName, useCaseId, existingPlan) {
    const parsed = parse(await readNs4Text(ns4E7UseCaseDraftFile(moduleName, useCaseId), false));
    if (!isRecord(parsed) || parsed.draftVersion !== NS4_USE_CASE_DRAFT_VERSION)
        return null;
    const plan = existingPlan || await readPlan(moduleName);
    return normalizeNs4UseCaseDraft(parsed, plan, useCaseId);
}
async function requirePipeline(moduleName) {
    const pipeline = await readNs4Pipeline(moduleName);
    if (!isNs4Pipeline(pipeline))
        throw new Error(`agentNewSolution pipeline not found for ${moduleName}.`);
    return pipeline;
}
async function recordFailure(moduleName, failure) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readNs4Pipeline(moduleName);
        if (isNs4Pipeline(pipeline))
            await writeNs4Pipeline(markNs4E7Failed(pipeline, failure));
    }
    catch { /* task trace fallback */ }
}
function resolveArgs(context, value) {
    const root = parse(value);
    if (!isRecord(root) || root.planId !== 'e7-realization')
        throw new Error('Invalid E7 step arguments.');
    const moduleName = text(root.moduleName) || resolveModuleName(context);
    if (!moduleName)
        throw new Error('E6 module result not found for E7.');
    return { planId: 'e7-realization', moduleName,
        ...(root.stage === 'finalize' ? { stage: 'finalize' } : { stage: 'plan' }),
        ...(integer(root.repairRound) ? { repairRound: integer(root.repairRound) } : {}) };
}
function resolveModuleName(context) {
    const result = getAllSteps(context.task?.iaCompressed?.nextSteps).find(step => step.planning?.planId === 'e6-result');
    const parsed = result?.type === 'result' ? parse(result.result) : null;
    return isRecord(parsed) ? text(parsed.moduleName) : memoryString(context, 'resumeModule');
}
function parseUseCaseSelector(value) {
    if (typeof value !== 'string')
        return '';
    return /^usecase:([a-z][A-Za-z0-9]*)$/.exec(value.trim())?.[1] || '';
}
async function readNs4UseCaseWorkerTool() {
    const raw = await readNs4Text(ns4AgentFile('schemas', 'e7-usecase-worker.schema', '.json'), true);
    const schema = parse(raw);
    if (!isRecord(schema))
        throw new Error('Invalid E7 use case worker tool schema.');
    return createNs4FlexibleWorkerTool('submitNs4E7UseCase', 'Submit one E7 use case detail.', schema);
}
function unwrap(value) { return unwrapNs4FlexibleWorkerPayload(value); }
function parse(value) { if (typeof value !== 'string')
    return value; const clean = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''); try {
    return JSON.parse(clean);
}
catch {
    return value;
} }
function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function integer(value) { return typeof value === 'number' && Number.isInteger(value) && value >= 0 ? value : 0; }
function memoryString(context, key) { const value = context.task?.iaCompressed?.longMemory?.[key]; return typeof value === 'string' ? value.trim() : ''; }
function formatGate(issues) { return issues.map(issue => `${issue.code} ${issue.path}: ${issue.message}`).join('\n'); }
function errorMessage(error) { return error instanceof Error ? error.message : String(error); }
