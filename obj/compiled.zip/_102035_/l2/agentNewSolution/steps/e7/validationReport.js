export const NS4_E7_VALIDATION_REPORT_VERSION = '2026-08-12-ns4-e7-validation-report-v4';
export function isNs4E7ValidationReport(value, moduleName) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return false;
    const report = value;
    return report.schemaVersion === NS4_E7_VALIDATION_REPORT_VERSION
        && report.moduleName === moduleName
        && Array.isArray(report.attempts)
        && report.attempts.every(attempt => !!attempt && typeof attempt === 'object'
            && !Array.isArray(attempt) && Number.isInteger(attempt.round));
}
export function mergeNs4E7ValidationAttempts(previous, attempt) {
    return [...previous.filter(item => item.round !== attempt.round), attempt]
        .sort((left, right) => left.round - right.round);
}
