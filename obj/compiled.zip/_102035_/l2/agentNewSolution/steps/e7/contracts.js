/// <mls fileReference="_102035_/l2/agentNewSolution/steps/e7/contracts.ts" enhancement="_blank"/>
import { isNs4CurrentJourneyBusiness, sha256Ns4 } from '/_102035_/l2/agentNewSolution/steps/e2/contracts.js';
import { NS4_JOURNEY_INDEX_SCHEMA_VERSION, NS4_REALIZED_JOURNEY_SCHEMA_VERSION } from '/_102035_/l2/agentNewSolution/steps/e2/contracts.js';
import { NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION } from '/_102035_/l2/agentNewSolution/steps/e3/contracts.js';
export const NS4_USE_CASE_DRAFT_VERSION = '2026-09-09-ns4-usecase-draft-v4';
export const NS4_USE_CASE_SCHEMA_VERSION = '2026-09-09-ns4-usecase-v4';
export const NS4_USE_CASE_INDEX_SCHEMA_VERSION = '2026-09-09-ns4-usecase-index-v4';
export const NS4_WORKFLOW_SCHEMA_VERSION = '2026-08-11-ns4-workflow-v4';
export const NS4_WORKFLOW_INDEX_SCHEMA_VERSION = '2026-08-12-ns4-workflow-index-v5';
/** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
export const TEXT_PATHS_2026_09_09_ns4_usecase_v4 = [
    'title',
    'description',
    'inputs[].description',
    'outputs[].description',
    'errors[].description',
    'errors[].when',
];
export const TEXT_PATHS_2026_08_10_ns4_usecase_v3 = TEXT_PATHS_2026_09_09_ns4_usecase_v4;
export const TEXT_PATHS_2026_08_10_ns4_usecase_v2 = TEXT_PATHS_2026_09_09_ns4_usecase_v4;
export const TEXT_PATHS_2026_09_09_ns4_usecase_index_v4 = [
    'useCases[].title',
    'systemDecisions[].question',
    'systemDecisions[].chosen',
    'systemDecisions[].alternatives[]',
    'systemDecisions[].changeHint',
];
export const TEXT_PATHS_2026_08_10_ns4_usecase_index_v2 = TEXT_PATHS_2026_09_09_ns4_usecase_index_v4;
/** Workflow artifacts are ids and transitions; no human prose. */
export const TEXT_PATHS_2026_08_11_ns4_workflow_v4 = [];
export const TEXT_PATHS_2026_08_10_ns4_workflow_v1 = TEXT_PATHS_2026_08_11_ns4_workflow_v4;
export const TEXT_PATHS_2026_08_12_ns4_workflow_index_v5 = [
    'systemDecisions[].question',
    'systemDecisions[].chosen',
    'systemDecisions[].alternatives[]',
    'systemDecisions[].changeHint',
];
export const TEXT_PATHS_2026_08_11_ns4_workflow_index_v4 = TEXT_PATHS_2026_08_12_ns4_workflow_index_v5;
export const TEXT_PATHS_2026_08_10_ns4_workflow_index_v1 = TEXT_PATHS_2026_08_12_ns4_workflow_index_v5;
export function workflowLifecycleOf(entity) {
    const states = entity.lifecycleStates.map(entry => typeof entry === 'string' ? entry : entry.state);
    return {
        states,
        initialState: entity.initialState,
        terminalStates: entity.terminalStates,
        lifecyclePredicates: (entity.lifecyclePredicates || []).map(predicate => ({
            predicateId: predicate.predicateId, stateIds: predicate.stateIds,
        })),
        reachedBy: Object.fromEntries(entity.lifecycleStates.map(entry => (typeof entry === 'string' ? [entry, 'actor'] : [entry.state, entry.reachedBy]))),
    };
}
/** Contexts come from the derivation, never from the journey text: E7 copies no declared name. */
export function buildNs4E7Plan(moduleName, userLanguage, journeys, sourceHashes, contexts, presentation) {
    const grouped = new Map();
    for (const journey of journeys.journeys) {
        for (const step of journey.business.steps) {
            const current = grouped.get(step.stepId) || { kinds: new Set(), refs: [], titles: [],
                requires: new Set(), provides: new Set() };
            const stepRef = `${journey.journeyId}.${step.stepId}`;
            current.kinds.add(step.kind);
            current.refs.push(stepRef);
            current.titles.push(step.title);
            contexts.byStepRef.get(stepRef)?.requires.forEach(context => current.requires.add(context.contextId));
            contexts.byStepRef.get(stepRef)?.provides.forEach(context => current.provides.add(context.contextId));
            grouped.set(step.stepId, current);
        }
    }
    const useCases = [...grouped.entries()].sort(([left], [right]) => left.localeCompare(right)).map(([useCaseId, group]) => ({
        useCaseId,
        title: group.titles[0] || useCaseId,
        kind: [...group.kinds].every(kind => kind === 'locate' || kind === 'inspect') ? 'query' : 'command',
        compiledFrom: [...new Set(group.refs)].sort(),
        contexts: { requires: [...group.requires].sort(), provides: [...group.provides].sort() },
    }));
    return { planId: 'e7-realization-plan', moduleName, userLanguage, useCases, sourceHashes, ...(presentation ? { presentation } : {}) };
}
export function normalizeNs4UseCaseDraft(value, plan, useCaseId) {
    const root = record(value);
    const target = plan.useCases.find(item => item.useCaseId === useCaseId);
    if (!target)
        throw new Error(`Unknown E7 use case ${useCaseId}.`);
    return {
        draftVersion: NS4_USE_CASE_DRAFT_VERSION, planId: 'e7-usecase', moduleName: plan.moduleName, useCaseId,
        title: text(root.title) || target.title, kind: target.kind,
        compiledFrom: [...target.compiledFrom], description: text(root.description),
        contexts: { requires: [...target.contexts.requires], provides: [...target.contexts.provides] },
        entityRefs: uniqueStrings(root.entityRefs), writes: normalizeWrites(root.writes),
        useRules: uniqueStrings(root.useRules),
        transitions: array(root.transitions).map(normalizeTransition),
    };
}
export async function buildNs4UseCaseArtifacts(plan, drafts, generatedAt, systemDecisions = []) {
    const artifacts = await Promise.all(drafts.map(async (draft) => {
        const { planId: _planId, draftVersion: _draftVersion, transitions, ...contract } = draft;
        const transitionRefs = [...new Set(transitions.map(transition => transition.transitionId))].sort();
        const useCaseHash = await sha256Ns4({ ...contract, transitionRefs });
        return {
            schemaVersion: NS4_USE_CASE_SCHEMA_VERSION, ...contract, transitionRefs, useCaseHash,
        };
    }));
    const realizationHash = await sha256Ns4(artifacts.map(item => ({ useCaseId: item.useCaseId, useCaseHash: item.useCaseHash })));
    return {
        artifacts,
        index: {
            schemaVersion: NS4_USE_CASE_INDEX_SCHEMA_VERSION, moduleName: plan.moduleName,
            userLanguage: plan.userLanguage, sourceHashes: plan.sourceHashes,
            useCases: artifacts.map(item => ({ useCaseId: item.useCaseId, title: item.title, kind: item.kind,
                compiledFrom: item.compiledFrom, useCaseHash: item.useCaseHash,
                artifactPath: `l4/${plan.moduleName}/usecases/${item.useCaseId}.defs.ts` })),
            realizationHash, generatedAt, systemDecisions,
        },
    };
}
export async function buildNs4WorkflowArtifacts(plan, drafts, ontologyLifecycles, generatedAt) {
    const byEntity = new Map();
    for (const useCase of drafts) {
        for (const transition of useCase.transitions) {
            const values = byEntity.get(transition.entityRef) || [];
            values.push({ ...transition, useCaseId: useCase.useCaseId });
            byEntity.set(transition.entityRef, values);
        }
    }
    const relevantEntities = [...ontologyLifecycles.entries()].filter(([entityRef, lifecycle]) => {
        const terminal = new Set(lifecycle.terminalStates || []);
        const reachedBy = lifecycle.reachedBy || {};
        const operatedIntermediate = lifecycle.states.some(state => (reachedBy[state] || 'actor') !== 'time'
            && state !== lifecycle.initialState
            && !terminal.has(state));
        return byEntity.has(entityRef) || operatedIntermediate;
    }).sort(([left], [right]) => left.localeCompare(right));
    const decisions = [];
    const artifacts = (await Promise.all(relevantEntities.map(async ([entityRef, lifecycle]) => {
        const transitions = byEntity.get(entityRef) || [];
        const workflowId = `${entityRef.slice(0, 1).toLowerCase()}${entityRef.slice(1)}Lifecycle`;
        const initialState = lifecycle.initialState || '';
        const reachedBy = lifecycle.reachedBy || {};
        // Time states never enter the workflow and are never shrunk. Actor/command states stay so the
        // gate can fail NS4_E7_STATE_UNREACHABLE instead of a silent shrinkLifecycle.
        const states = lifecycle.states.filter(state => (reachedBy[state] || 'actor') !== 'time');
        const terminalStates = (lifecycle.terminalStates || []).filter(state => states.includes(state));
        if (!transitions.length)
            return null;
        const workflowHash = await sha256Ns4({ entityRef, initialState, terminalStates, states, transitions });
        return { schemaVersion: NS4_WORKFLOW_SCHEMA_VERSION, moduleName: plan.moduleName,
            workflowId, entityRef, initialState, terminalStates, states, transitions, workflowHash };
    }))).filter((artifact) => !!artifact);
    const realizationHash = await sha256Ns4(artifacts.map(item => ({ workflowId: item.workflowId, workflowHash: item.workflowHash })));
    return {
        artifacts,
        index: {
            schemaVersion: NS4_WORKFLOW_INDEX_SCHEMA_VERSION, moduleName: plan.moduleName,
            userLanguage: plan.userLanguage,
            workflows: artifacts.map(item => ({ workflowId: item.workflowId, entityRef: item.entityRef,
                workflowHash: item.workflowHash, artifactPath: `l4/${plan.moduleName}/workflows/${item.workflowId}.defs.ts` })),
            sourceHashes: plan.sourceHashes, realizationHash, generatedAt, systemDecisions: decisions,
        },
    };
}
export async function buildNs4RealizedJourneyArtifact(source, useCases, derived) {
    if (!isNs4CurrentJourneyBusiness(source.business))
        throw new Error(`E7 does not migrate legacy journey ${source.journeyId}.`);
    const business = source.business;
    const journeyUseCases = useCases.filter(useCase => useCase.compiledFrom.some(ref => ref.startsWith(`${source.journeyId}.`)));
    const contexts = new Map();
    const addContext = (context, sourceRef, consumers) => {
        const current = contexts.get(context.contextId) || { value: context, sources: new Set(), consumers: new Set() };
        current.sources.add(sourceRef);
        consumers.forEach(ref => current.consumers.add(ref));
        contexts.set(context.contextId, current);
    };
    const journeySteps = business.steps.map(step => derived.byStepRef.get(`${source.journeyId}.${step.stepId}`))
        .filter((step) => !!step);
    const consumersOf = (contextId) => journeySteps
        .filter(step => step.requires.some(context => context.contextId === contextId)).map(step => step.stepRef);
    for (const context of derived.entryByJourneyId.get(source.journeyId) || []) {
        addContext({ ...context, sourceRefs: [], consumerStepRefs: [] }, `${source.journeyId}.entry`, consumersOf(context.contextId));
    }
    for (const step of journeySteps)
        for (const context of step.provides) {
            addContext({ ...context, sourceRefs: [], consumerStepRefs: [] }, step.stepRef, consumersOf(context.contextId));
        }
    const resolvedContexts = Object.fromEntries([...contexts.entries()].map(([contextId, entry]) => [contextId, {
            ...entry.value, sourceRefs: [...entry.sources].sort(), consumerStepRefs: [...entry.consumers].sort(),
        }]));
    const steps = business.steps.map(step => ({ stepId: step.stepId,
        useCaseRefs: journeyUseCases.filter(useCase => useCase.compiledFrom.includes(`${source.journeyId}.${step.stepId}`))
            .map(useCase => useCase.useCaseId).sort() }));
    const transitionRefs = journeyUseCases.flatMap(useCase => useCase.transitionRefs);
    const realizationHash = await sha256Ns4({ contexts: resolvedContexts, steps, transitionRefs, businessHash: source.businessHash });
    return {
        schemaVersion: NS4_REALIZED_JOURNEY_SCHEMA_VERSION, journeyId: source.journeyId,
        revision: source.revision, business, businessHash: source.businessHash,
        resolution: { status: 'compiled', contexts: resolvedContexts },
        realization: { status: 'compiled', compiledFromBusinessHash: source.businessHash,
            steps, transitionRefs: [...new Set(transitionRefs)].sort(), realizationHash },
    };
}
export async function buildNs4RealizedJourneyIndex(source, journeys) {
    const byId = new Map(journeys.map(journey => [journey.journeyId, journey]));
    const entries = source.journeys.map(entry => ({ ...entry,
        useCaseRefs: [...new Set((byId.get(entry.journeyId)?.realization.steps || []).flatMap(step => step.useCaseRefs))].sort() }));
    const realizationHash = await sha256Ns4(journeys.map(journey => ({ journeyId: journey.journeyId,
        realizationHash: journey.realization.realizationHash })));
    return { ...source, schemaVersion: NS4_JOURNEY_INDEX_SCHEMA_VERSION, journeys: entries, realizationHash };
}
export async function buildNs4RealizedAccessArtifact(source, useCases) {
    if (source.grants.some(grant => !('useRules' in grant)))
        throw new Error('E7 does not migrate a legacy access matrix.');
    const grants = source.grants;
    const useCaseAuthorityRefs = useCases.flatMap(useCase => source.authorities.flatMap(authority => {
        const journeyStepRefs = useCase.compiledFrom.filter(ref => authority.journeyStepRefs.includes(ref));
        return journeyStepRefs.length ? [{ useCaseId: useCase.useCaseId,
                authorityRef: authority.authorityRef, journeyStepRefs }] : [];
    })).sort((left, right) => `${left.useCaseId}|${left.authorityRef}`.localeCompare(`${right.useCaseId}|${right.authorityRef}`));
    const realizationHash = await sha256Ns4({ accessHash: source.accessHash, useCaseAuthorityRefs });
    return {
        schemaVersion: NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION, moduleName: source.moduleName,
        userLanguage: source.userLanguage, title: source.title, profiles: source.profiles,
        authorities: source.authorities, grants, accessHash: source.accessHash,
        approvedBy: source.approvedBy, approvedAt: source.approvedAt,
        realization: { status: 'useCasesCompiled', compiledFromAccessHash: source.accessHash,
            useCaseAuthorityRefs, realizationHash },
    };
}
function normalizeTransition(value) {
    const transition = record(value);
    return {
        transitionId: text(transition.transitionId), entityRef: text(transition.entityRef),
        fromStates: strings(transition.fromStates), toState: text(transition.toState), useRules: strings(transition.useRules),
    };
}
function normalizeWrites(value) {
    const byId = new Map();
    for (const item of array(value)) {
        const row = record(item);
        const entityId = text(row.entityId);
        if (!entityId || byId.has(entityId))
            continue;
        const fieldRefs = uniqueStrings(row.fieldRefs);
        byId.set(entityId, fieldRefs.length ? { entityId, fieldRefs } : { entityId });
    }
    return [...byId.values()].sort((left, right) => left.entityId.localeCompare(right.entityId));
}
function record(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
function array(value) { return Array.isArray(value) ? value : []; }
function strings(value) { return array(value).map(text).filter(Boolean); }
function uniqueStrings(value) { return [...new Set(strings(value))].sort(); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
