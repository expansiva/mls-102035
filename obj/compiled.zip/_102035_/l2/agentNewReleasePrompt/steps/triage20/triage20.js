/// <mls fileReference="_102035_/l2/agentNewReleasePrompt/steps/triage20/triage20.ts" enhancement="_blank" />
import { NRP_AGENT_NAME, NRP_CANDIDATE_REL, parseNrpInvocation } from '/_102035_/l2/agentNewReleasePrompt/helpers/invocation.js';
import { loadNrpArtifacts } from '/_102035_/l2/agentNewReleasePrompt/helpers/artifacts.js';
import { buildNrpIndex } from '/_102035_/l2/agentNewReleasePrompt/helpers/compactIndex.js';
import { displayPath, pipelineJsonFileForProject, setModuleRoot, writeJson } from '/_102035_/l2/solution/fs.js';
import { createNs4FlexibleWorkerTool, unwrapNs4FlexibleWorkerPayload } from '/_102035_/l2/solution/helpers/ns4WorkerTools.js';
import { promptHoldSummary } from '/_102035_/l2/agentNewReleasePrompt/helpers/promptSummary.js';
import { createEdit30Step, planNrpEditOrders } from '/_102035_/l2/agentNewReleasePrompt/steps/edit30/edit30.js';
export const NRP_TRIAGE_TOOL = 'submitNrpTriage';
export const NRP_TRIAGE_CLARIFICATION_MAX = 1000;
const SECRET_KEY = /token|secret|password|authorization|api[-_]?key|credential/iu;
const triageNotes = new WeakMap();
export class NrpTriageRefusal extends Error {
    constructor(message, raw) {
        super(message);
        this.name = 'NrpTriageRefusal';
        this.raw = raw;
    }
}
export const NRP_ARTIFACT_KINDS = ['ontology', 'rules', 'journeys', 'access', 'workflows', 'integration'];
export const NRP_MECHANICAL_OPS = ['setOptional', 'setRequired', 'remove', 'setScalar'];
export const NRP_TRIAGE_SCHEMA = {
    $id: 'https://collab.codes/schemas/agentNewReleasePrompt/triage/2026-10-27-nrp-triage-v1',
    type: 'object',
    additionalProperties: false,
    required: ['valid', 'reason', 'clarification', 'artifacts', 'targets', 'intent', 'mechanical', 'mechanicalOnly', 'assumptions', 'l3Notice'],
    properties: {
        valid: { type: 'boolean' },
        reason: { anyOf: [{ type: 'string', minLength: 1 }, { type: 'null' }] },
        clarification: { anyOf: [{ type: 'string', minLength: 1 }, { type: 'null' }] },
        artifacts: { type: 'array', items: { type: 'string', enum: [...NRP_ARTIFACT_KINDS] } },
        targets: { type: 'array', items: { type: 'string', minLength: 1 } },
        intent: { anyOf: [{ type: 'string', minLength: 1 }, { type: 'null' }] },
        mechanical: {
            type: 'array',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['op', 'targetId', 'fieldId', 'value'],
                properties: {
                    op: { type: 'string', enum: [...NRP_MECHANICAL_OPS] },
                    targetId: { type: 'string', minLength: 1 },
                    fieldId: { type: 'string' },
                    value: { type: 'string' },
                },
            },
        },
        mechanicalOnly: { type: 'boolean' },
        assumptions: { type: 'array', items: { type: 'string', minLength: 1 } },
        l3Notice: { anyOf: [{ type: 'string', minLength: 1 }, { type: 'null' }] },
    },
};
export const NRP_TRIAGE_SYSTEM_PROMPT = `<!-- modelType: reasoning -->
Decide whether one free-text request can change the L4 specification that is being edited.
The index you receive lists only that specification: entities and their fields, rules, journeys, access grants, workflows, and integration events.
You do not edit anything. You only classify the request.

Call submitNrpTriage. Every property is required.
- valid is true only when the request asks for a concrete change inside that specification.
- valid is false only when the request has no path in the specification: it is empty, it is not about this module at all (general questions, jokes, infrastructure, deployment, distributing the app), or the specification already satisfies it. When it is already satisfied, reason names the item that satisfies it (field, rule, journey or grant id from the index) and nothing is changed.
- reason explains an invalid request. Use null when the request is valid, or when the whole request is interface work and l3Notice carries the answer.
- A request of a few words ("a field name", "a feature") names something to add: if the index already has it, say so in reason; if not, add it with the most probable default and record it in assumptions. Do not refuse it as vague.
- clarification is one question for the user, only when applying the request could break the module or its data (removing or renaming an entity or field that exists, changing the type of a field, taking access away from an actor that uses it) or when the request contradicts an indexed rule. State the effect in the question. Do not propose a default. Otherwise null. A clarification means valid is false, artifacts is [], targets is [], intent is null, mechanical is [] and assumptions is [].
- assumptions are short sentences, in the language of the request, one for each thing the request left open and you decided from the module specification: who performs a step (it may be an actor the index does not have yet), a default value, who sees a new field. Example: 'who marks the dish ready: the kitchen (new actor)'. The change is applied with these choices and the user reads them in the summary, so do not ask about them. Use [] when nothing was assumed or when valid is false.
- l3Notice is text for the user, in the language of the request, when part or all of the request is about how the interface looks or is drawn: colors, positions, sizes, order of columns, design system or theme, how a screen is rendered. Say that this part is not in the specification and that the user should check the point adjustments in l3. Null otherwise. When the whole request is interface work, valid is false, clarification is null and l3Notice carries the answer. When only part is, treat the rest as usual (apply it, or ask) and still fill l3Notice.
- artifacts lists the kinds the change would touch. Use [] when the request stops here. Kinds: ontology, rules, journeys, access, workflows, integration.
- targets lists ids copied from the index. Use [] when there is no id to name. A new id is allowed only when the request explicitly asks to add it.
- intent is one sentence of the change to apply. Use null when the request stops here.
- mechanical lists changes the code can apply without a model. A mark covers only making a field optional or required (setOptional, setRequired), removing an item (remove), or replacing one scalar (setScalar). Each mark has op, targetId, fieldId (empty string when the mark is not a field), and value (empty string when the op carries no new scalar). For remove, targetId is the owner of the item (the entity when the item is a field) and fieldId is that field. A field inside details uses a dotted path: details, then the field id. Removing a whole entity is not a mechanical mark.
  Any other part of the request goes to the model. A default value, a notice, a new rule, or new text is not a mechanical mark. Put that kind in artifacts and describe that part in intent. Use [] when the request stops here, or when every part needs the model and no mark applies.
- mechanicalOnly is true only when those marks, by themselves, fulfill the whole request. A default value, a notice, a new rule, or new text makes mechanicalOnly false, and the kind that records that part goes in artifacts and in intent.

How a request in the user's own words becomes a specification change:
- a screen, list, panel, report, or "see / follow" something is a journey that lets an actor find and inspect data, plus the access grant that lets that actor read it. It is a valid request, not interface work. If the request does not say which actor, choose the one the journeys and grants of the index make most probable (it may be an actor the index does not have yet) and record it in assumptions.
- a button, an action, "be able to do X" is a journey step that acts, plus the transition or effect on the entity.
- a field, a piece of information, "keep X" is an entity field, plus the access grant of whoever must see it: put access in artifacts and decide from the journeys which actors see the new field.
- "cannot", "always", "required" is a rule.
- a notice, a deadline, an approval, "after X happens Y" is a workflow.
- "another module", "when it arrives from" is an integration.
- Removing or renaming an entity or field, changing the type of a field, or taking access away from an actor that uses it can break data or users: ask once, explaining the effect, with no default filled in.
- When unsure which of these the user means, pick the most probable one, apply it and record the choice in assumptions. Ask only in the cases of the clarification line above.
- The index lists the journeys and grants that exist today per actor; use it so you do not duplicate a screen or grant.

Do not restate the index. Do not invent an example module.`;
export function buildNrpTriageHumanPrompt(request, index) {
    return `Request:\n${request}\n\nIndex:\n${JSON.stringify(index)}`;
}
export function buildNrpTriageTool() {
    return createNs4FlexibleWorkerTool(NRP_TRIAGE_TOOL, 'Classify one request against the L4 index. Do not edit artifacts.', NRP_TRIAGE_SCHEMA);
}
export function nrpTriageNotes(triage) {
    return triageNotes.get(triage) || [];
}
export function normalizeNrpTriage(value) {
    try {
        const root = record(value);
        const valid = root.valid;
        if (typeof valid !== 'boolean')
            throw new Error('Triage valid must be a boolean.');
        const reason = nullableText(root.reason, 'reason');
        const clarification = nullableText(root.clarification, 'clarification');
        const intent = nullableText(root.intent, 'intent');
        const artifacts = kinds(root.artifacts);
        const targets = texts(root.targets, 'targets');
        const mechanical = marks(root.mechanical);
        if (typeof root.mechanicalOnly !== 'boolean')
            throw new Error('Triage mechanicalOnly must be a boolean.');
        const assumptions = texts(root.assumptions, 'assumptions');
        const l3Notice = nullableText(root.l3Notice, 'l3Notice');
        const triage = {
            valid, reason, clarification, artifacts, targets, intent, mechanical, mechanicalOnly: root.mechanicalOnly, assumptions, l3Notice,
        };
        const notes = settleShape(triage);
        if (notes.length)
            triageNotes.set(triage, notes);
        return triage;
    }
    catch (error) {
        if (error instanceof NrpTriageRefusal)
            throw error;
        throw new NrpTriageRefusal(error instanceof Error ? error.message : String(error), value);
    }
}
/** Last whole sentence that fits, otherwise the last word, otherwise a hard cut. */
export function clipNrpClarification(text) {
    const trimmed = text.trim();
    if (trimmed.length <= NRP_TRIAGE_CLARIFICATION_MAX)
        return { text: trimmed, clipped: false };
    let end = -1;
    const limit = Math.min(trimmed.length, NRP_TRIAGE_CLARIFICATION_MAX);
    for (let index = 0; index < limit; index += 1) {
        const mark = trimmed[index];
        if ((mark === '.' || mark === '?' || mark === '!') && (index + 1 === trimmed.length || /\s/u.test(trimmed[index + 1]))) {
            end = index + 1;
        }
    }
    if (end > 0)
        return { text: trimmed.slice(0, end).trim(), clipped: true };
    const space = trimmed.lastIndexOf(' ', NRP_TRIAGE_CLARIFICATION_MAX);
    const cut = space > 0 ? space : NRP_TRIAGE_CLARIFICATION_MAX;
    return { text: trimmed.slice(0, cut).trim(), clipped: true };
}
export const NRP_REFUSAL_PROMPT_LIMIT = 6000;
export async function recordNrpTriageRefusal(info, reason, raw, writer = writeJson, prompt) {
    const citation = displayPath(info);
    const body = { reason, raw: redact(raw) };
    if (prompt !== undefined)
        body.prompt = prompt.slice(0, NRP_REFUSAL_PROMPT_LIMIT);
    await writer(info, body);
    return citation;
}
/**
 * The tool-call answer of the triage call. Without one, the model answered but no tool call reached the step:
 * the refusal says so and keeps the step trace (provider, tokens, cost), which is all the stored task keeps.
 */
export function nrpTriagePayload(step) {
    const first = step.interaction?.payload?.[0];
    if (first === undefined || first === null) {
        const trace = step.interaction?.trace ?? [];
        throw new NrpTriageRefusal('The model answered the triage without a tool call (no payload reached the step).', { payloadMissing: true, payloadLength: step.interaction?.payload?.length ?? null, cost: step.interaction?.cost ?? null, trace });
    }
    return unwrapNs4FlexibleWorkerPayload(first);
}
export function createTriage20Step(prompt) {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        nextSteps: [],
        status: 'waiting_human_input',
        agentName: NRP_AGENT_NAME,
        stepTitle: 'Triage the request',
        prompt,
        rags: [],
        planning: { planId: 'triage20', dependsOn: ['index10-done'], executionMode: 'sequential', executionHost: 'client' },
    };
}
export async function beforeNrpTriageStep(context, parentStep, step, hookSequential) {
    try {
        const project = mls.actualProject || 0;
        const invocation = parseNrpInvocation(String(step.prompt || ''), project);
        setModuleRoot(invocation.moduleName, `${invocation.moduleName}/${NRP_CANDIDATE_REL}`);
        const index = buildNrpIndex(await loadNrpArtifacts(invocation.moduleName));
        const tool = buildNrpTriageTool();
        return [{
                type: 'prompt_ready',
                args: String(step.prompt || ''),
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task?.PK || '',
                hookSequential,
                parentStepId: parentStep.stepId,
                systemPrompt: NRP_TRIAGE_SYSTEM_PROMPT,
                humanPrompt: buildNrpTriageHumanPrompt(invocation.request, index),
                tools: [tool],
                toolChoice: { type: 'function', function: { name: tool.function.name } },
            }];
    }
    catch (error) {
        console.error('[agentNewReleasePrompt] triage20 prompt failed', error);
        return [fail(context, parentStep, step, hookSequential, error)];
    }
}
export async function afterNrpTriageStep(context, parentStep, step, hookSequential) {
    const base = {
        messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', parentStepId: parentStep.stepId,
    };
    try {
        const triage = normalizeNrpTriage(nrpTriagePayload(step));
        const stopped = !triage.valid;
        const hold = stopped
            ? await holdSummary(step, [triage.clarification || triage.reason, triage.l3Notice].filter(Boolean).join('\n'))
            : null;
        const intents = [];
        intents.push({
            type: 'add-step', ...base, step: {
                type: 'result', stepId: 0, status: 'completed', interaction: null, nextSteps: [],
                stepTitle: stopped ? 'Triage stopped' : 'Triage accepted',
                result: JSON.stringify({
                    triage,
                    nextStep: stopped ? null : 'edit30',
                    notes: nrpTriageNotes(triage),
                    ...(hold ? { written: false, summary: hold } : {}),
                }),
                planning: { planId: 'triage20-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
            },
        });
        if (!stopped) {
            const project = mls.actualProject || 0;
            const invocation = parseNrpInvocation(String(step.prompt || ''), project);
            setModuleRoot(invocation.moduleName, `${invocation.moduleName}/${NRP_CANDIDATE_REL}`);
            const orders = planNrpEditOrders(await loadNrpArtifacts(invocation.moduleName), triage);
            const [first, ...rest] = orders;
            if (first) {
                intents.push({
                    type: 'add-step', ...base, step: createEdit30Step(invocation.moduleName, invocation.request, {
                        ...first,
                        rest: rest.map(order => ({ mode: order.mode, kind: order.kind })),
                        applied: [],
                    }),
                });
            }
        }
        intents.push({
            type: 'update-status', ...base, stepId: step.stepId, hookSequential, status: 'completed',
            cleaner: 'input_output',
            traceMsg: stopped
                ? `triage20 stopped: ${triage.clarification || triage.reason || 'invalid request'}.`
                : `triage20: ${triage.artifacts.join(', ') || 'no artifacts'}.`,
        });
        return intents;
    }
    catch (error) {
        console.error('[agentNewReleasePrompt] triage20 result rejected', error);
        const cited = await citeRefusal(step, error);
        return [fail(context, parentStep, step, hookSequential, cited)];
    }
}
async function holdSummary(step, text) {
    const project = mls.actualProject || 0;
    const invocation = parseNrpInvocation(String(step.prompt || ''), project);
    setModuleRoot(invocation.moduleName, `${invocation.moduleName}/${NRP_CANDIDATE_REL}`);
    const artifacts = await loadNrpArtifacts(invocation.moduleName);
    return promptHoldSummary(text, artifacts.module.userLanguage);
}
async function citeRefusal(step, error) {
    if (!(error instanceof NrpTriageRefusal))
        return error;
    try {
        const project = mls.actualProject || 0;
        const invocation = parseNrpInvocation(String(step.prompt || ''), project);
        const info = pipelineJsonFileForProject(project, invocation.moduleName, 'newReleasePrompt-refused');
        const citation = await recordNrpTriageRefusal(info, error.message, error.raw);
        return new NrpTriageRefusal(`${error.message} See ${citation}.`, error.raw);
    }
    catch (writeError) {
        console.error('[agentNewReleasePrompt] triage20 could not record the refused response', writeError);
        const writeMessage = writeError instanceof Error ? writeError.message : String(writeError);
        return new NrpTriageRefusal(`${error.message} The refused response was not recorded: ${writeMessage}.`, error.raw);
    }
}
function fail(context, parentStep, step, hookSequential, error) {
    return {
        type: 'update-status',
        messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', parentStepId: parentStep.stepId, stepId: step.stepId,
        hookSequential, status: 'failed', cleaner: 'input_output',
        traceMsg: error instanceof Error ? error.message : String(error),
    };
}
function settleShape(triage) {
    const notes = [];
    if (triage.clarification) {
        const clipped = clipNrpClarification(triage.clarification);
        triage.clarification = clipped.text;
        if (clipped.clipped)
            notes.push(`clarification exceeded ${NRP_TRIAGE_CLARIFICATION_MAX} characters and was cut to a whole sentence`);
        if (!triage.clarification)
            throw new Error('A clarification needs a question.');
        if (hasChangeFields(triage) || triage.valid || triage.reason)
            notes.push('Discarded fields.');
        triage.valid = false;
        triage.reason = null;
        clearChanges(triage);
        return notes;
    }
    if (!triage.valid) {
        if (!triage.reason && !triage.l3Notice)
            throw new Error('An invalid request needs a reason or an l3Notice.');
        if (hasChangeFields(triage))
            notes.push('Discarded fields.');
        clearChanges(triage);
        return notes;
    }
    if (triage.reason || !triage.intent || !triage.artifacts.length) {
        throw new Error('A valid request needs an intent, at least one artifact, and a null reason.');
    }
    if (triage.mechanicalOnly && !triage.mechanical.length) {
        throw new Error('mechanicalOnly needs at least one mechanical mark.');
    }
    return notes;
}
function hasChangeFields(triage) {
    return !!(triage.intent || triage.artifacts.length || triage.targets.length || triage.mechanical.length || triage.mechanicalOnly || triage.assumptions.length);
}
function clearChanges(triage) {
    triage.intent = null;
    triage.artifacts = [];
    triage.targets = [];
    triage.mechanical = [];
    triage.mechanicalOnly = false;
    triage.assumptions = [];
}
function redact(value, depth = 0) {
    if (depth > 8)
        return null;
    if (Array.isArray(value))
        return value.slice(0, 64).map(item => redact(item, depth + 1));
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const [key, item] of Object.entries(value)) {
            out[key] = SECRET_KEY.test(key) ? '[redacted]' : redact(item, depth + 1);
        }
        return out;
    }
    if (typeof value === 'string' && value.length > 20000)
        return `${value.slice(0, 20000)}…`;
    return value;
}
function kinds(value) {
    if (!Array.isArray(value))
        throw new Error('Triage artifacts must be an array.');
    return value.map(item => {
        if (typeof item !== 'string' || !NRP_ARTIFACT_KINDS.includes(item)) {
            throw new Error(`Unknown artifact kind: ${String(item)}.`);
        }
        return item;
    });
}
function texts(value, label) {
    if (!Array.isArray(value))
        throw new Error(`Triage ${label} must be an array.`);
    return value.map(item => {
        if (typeof item !== 'string' || !item.trim())
            throw new Error(`Triage ${label} entries must be non-empty text.`);
        return item;
    });
}
function marks(value) {
    if (!Array.isArray(value))
        throw new Error('Triage mechanical must be an array.');
    return value.map(item => {
        const row = record(item);
        const op = row.op;
        if (typeof op !== 'string' || !NRP_MECHANICAL_OPS.includes(op)) {
            throw new Error(`Unknown mechanical op: ${String(op)}.`);
        }
        const targetId = row.targetId;
        if (typeof targetId !== 'string' || !targetId.trim())
            throw new Error('A mechanical mark needs a targetId.');
        if (typeof row.fieldId !== 'string' || typeof row.value !== 'string') {
            throw new Error('A mechanical mark needs fieldId and value strings.');
        }
        return { op: op, targetId, fieldId: row.fieldId, value: row.value };
    });
}
function nullableText(value, label) {
    if (value === null)
        return null;
    if (typeof value !== 'string' || !value.trim())
        throw new Error(`Triage ${label} must be text or null.`);
    return value.trim();
}
function record(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('Triage payload must be an object.');
    return value;
}
