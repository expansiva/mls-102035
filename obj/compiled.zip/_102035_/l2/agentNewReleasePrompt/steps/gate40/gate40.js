/// <mls fileReference="_102035_/l2/agentNewReleasePrompt/steps/gate40/gate40.ts" enhancement="_blank" />
import { NRP_AGENT_NAME, NRP_CANDIDATE_REL, parseNrpInvocation } from '/_102035_/l2/agentNewReleasePrompt/helpers/invocation.js';
import { loadNrpArtifacts } from '/_102035_/l2/agentNewReleasePrompt/helpers/artifacts.js';
import { buildNrpRepairHumanPrompt, buildNrpRepairTool, checkNrpGates, classifyNrpGateIssues, nrpGateAction, NRP_REPAIR_SYSTEM_PROMPT, overlayNrpEdits, } from '/_102035_/l2/agentNewReleasePrompt/helpers/releaseGate.js';
import { setModuleRoot } from '/_102035_/l2/solution/fs.js';
import { unwrapNs4FlexibleWorkerPayload } from '/_102035_/l2/solution/helpers/ns4WorkerTools.js';
import { NRP_ARTIFACT_KINDS, normalizeNrpTriage, } from '/_102035_/l2/agentNewReleasePrompt/steps/triage20/triage20.js';
import { createWrite50Step } from '/_102035_/l2/agentNewReleasePrompt/steps/write50/write50.js';
export function createGate40Step(cursor) {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        nextSteps: [],
        status: 'waiting_human_input',
        agentName: NRP_AGENT_NAME,
        stepTitle: cursor.repaired.length ? `Repair ${cursor.repaired[cursor.repaired.length - 1]}` : 'Verify the edit',
        prompt: JSON.stringify({ moduleName: cursor.moduleName, request: cursor.request, nrpGate: cursor }),
        rags: [],
        planning: { planId: 'gate40', dependsOn: ['edit30-done'], executionMode: 'sequential', executionHost: 'client' },
    };
}
export async function beforeNrpGateStep(context, parentStep, step, hookSequential) {
    const base = {
        messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', parentStepId: parentStep.stepId,
    };
    try {
        const project = mls.actualProject || 0;
        const cursor = readCursor(String(step.prompt || ''), project);
        setModuleRoot(cursor.moduleName, `${cursor.moduleName}/${NRP_CANDIDATE_REL}`);
        const baseArtifacts = await loadNrpArtifacts(cursor.moduleName);
        const merged = overlayNrpEdits(baseArtifacts, cursor.applied);
        const issues = gateIssues(baseArtifacts, merged);
        const decision = nrpGateAction(issues, cursor.triage.artifacts, cursor.repaired);
        if (decision.action === 'write') {
            return [
                {
                    type: 'add-step', ...base, step: createWrite50Step({
                        moduleName: cursor.moduleName,
                        project,
                        request: cursor.request,
                        triage: cursor.triage,
                        artifacts: merged,
                        applied: cursor.applied,
                        issues,
                        allowWrite: true,
                        modelCalls: cursor.modelCalls,
                    }),
                },
                done(base, step, hookSequential, 'gate40 passed. write50 will record the version.'),
            ];
        }
        if (decision.action === 'stop' || !decision.kind) {
            return [
                {
                    type: 'add-step', ...base, step: {
                        type: 'result', stepId: 0, status: 'completed', interaction: null, nextSteps: [],
                        stepTitle: 'Verification failed',
                        result: JSON.stringify({ written: false, reason: 'Verification failed. Nothing was written.', issues }),
                        planning: { planId: 'gate40-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
                    },
                },
                done(base, step, hookSequential, 'gate40 failed again. Nothing was written.'),
            ];
        }
        const tool = buildNrpRepairTool();
        return [{
                type: 'prompt_ready',
                args: String(step.prompt || ''),
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task?.PK || '',
                hookSequential,
                parentStepId: parentStep.stepId,
                systemPrompt: NRP_REPAIR_SYSTEM_PROMPT,
                humanPrompt: buildNrpRepairHumanPrompt(cursor.request, decision.kind, issues, sliceOf(merged, decision.kind)),
                tools: [tool],
                toolChoice: { type: 'function', function: { name: tool.function.name } },
            }];
    }
    catch (error) {
        console.error('[agentNewReleasePrompt] gate40 failed', error);
        return [fail(context, parentStep, step, hookSequential, error)];
    }
}
export async function afterNrpGateStep(context, parentStep, step, hookSequential) {
    if (!step.interaction?.payload?.[0])
        return [];
    const base = {
        messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', parentStepId: parentStep.stepId,
    };
    try {
        const project = mls.actualProject || 0;
        const cursor = readCursor(String(step.prompt || ''), project);
        setModuleRoot(cursor.moduleName, `${cursor.moduleName}/${NRP_CANDIDATE_REL}`);
        const baseArtifacts = await loadNrpArtifacts(cursor.moduleName);
        const merged = overlayNrpEdits(baseArtifacts, cursor.applied);
        const issues = gateIssues(baseArtifacts, merged);
        const decision = nrpGateAction(issues, cursor.triage.artifacts, cursor.repaired);
        if (decision.action !== 'repair' || !decision.kind)
            return [];
        const artifact = readRepairArtifact(decision.kind, unwrapNs4FlexibleWorkerPayload(step.interaction.payload[0]));
        const next = {
            ...cursor,
            applied: [...cursor.applied, { mode: 'model', kind: decision.kind, artifact }],
            repaired: [...cursor.repaired, decision.kind],
            modelCalls: cursor.modelCalls + 1,
        };
        return [
            { type: 'add-step', ...base, step: createGate40Step(next) },
            done(base, step, hookSequential, `gate40 repair returned ${decision.kind}.`),
        ];
    }
    catch (error) {
        console.error('[agentNewReleasePrompt] gate40 repair rejected', error);
        return [fail(context, parentStep, step, hookSequential, error)];
    }
}
function gateIssues(base, merged) {
    const kinds = NRP_ARTIFACT_KINDS;
    return classifyNrpGateIssues(checkNrpGates(base, kinds), checkNrpGates(merged, kinds));
}
function sliceOf(artifacts, kind) {
    if (kind === 'ontology')
        return { ontologyIndex: artifacts.ontologyIndex, entities: artifacts.entities };
    if (kind === 'rules')
        return artifacts.rules;
    if (kind === 'journeys')
        return { journeyIndex: artifacts.journeyIndex, journeys: artifacts.journeys };
    if (kind === 'access')
        return artifacts.access;
    if (kind === 'workflows')
        return artifacts.workflows;
    return artifacts.integration;
}
function readRepairArtifact(kind, value) {
    const root = record(value, 'Repair payload');
    const raw = root.artifactJson;
    if (typeof raw !== 'string' || raw.trim().length < 2)
        throw new Error('Repair artifactJson must be JSON text.');
    let parsed;
    try {
        parsed = JSON.parse(raw);
    }
    catch (error) {
        console.error('[agentNewReleasePrompt] repair artifactJson is not JSON', error);
        throw new Error('Repair artifactJson must be JSON text.');
    }
    const artifact = record(parsed, 'Repaired artifact');
    const ok = kind === 'ontology'
        ? Array.isArray(artifact.entities)
        : kind === 'rules'
            ? 'rules' in artifact
            : kind === 'journeys'
                ? Array.isArray(artifact.journeys)
                : kind === 'access'
                    ? Array.isArray(artifact.grants)
                    : kind === 'workflows'
                        ? Array.isArray(artifact.processes)
                        : Array.isArray(artifact.inbound) && Array.isArray(artifact.outbound);
    if (!ok)
        throw new Error(`Repaired ${kind} artifact has the wrong shape.`);
    return parsed;
}
function readCursor(prompt, project) {
    const invocation = parseNrpInvocation(strip(prompt), project);
    let raw;
    try {
        raw = JSON.parse(prompt);
    }
    catch (error) {
        console.error('[agentNewReleasePrompt] gate prompt is not JSON', error);
        throw new Error('Gate step prompt must be JSON.');
    }
    const root = record(raw, 'Gate step prompt');
    const body = record(root.nrpGate, 'Gate cursor');
    const repaired = texts(body.repaired, 'repaired');
    const modelCalls = body.modelCalls;
    if (typeof modelCalls !== 'number' || modelCalls < 0)
        throw new Error('Gate modelCalls must be a number.');
    return {
        moduleName: invocation.moduleName,
        request: invocation.request,
        triage: normalizeNrpTriage(body.triage),
        applied: appliedOf(body.applied),
        repaired,
        modelCalls,
    };
}
function appliedOf(value) {
    if (!Array.isArray(value))
        throw new Error('Gate applied must be an array.');
    return value.map(item => {
        const root = record(item, 'Applied edit');
        const mode = root.mode;
        if (mode !== 'apply' && mode !== 'model')
            throw new Error('Applied edit mode must be apply or model.');
        const kind = root.kind;
        if (kind !== null && (typeof kind !== 'string' || !NRP_ARTIFACT_KINDS.includes(kind))) {
            throw new Error('Applied edit kind must be an artifact kind or null.');
        }
        return { mode, kind: kind, artifact: root.artifact };
    });
}
function texts(value, label) {
    if (!Array.isArray(value))
        throw new Error(`Gate ${label} must be an array.`);
    return value.map(item => {
        if (typeof item !== 'string' || !NRP_ARTIFACT_KINDS.includes(item)) {
            throw new Error(`Gate ${label} has an unknown kind.`);
        }
        return item;
    });
}
function strip(value) {
    let raw;
    try {
        raw = JSON.parse(value);
    }
    catch (error) {
        console.error('[agentNewReleasePrompt] gate prompt is not JSON', error);
        return value;
    }
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return value;
    const { nrpGate: _ignored, ...invocation } = raw;
    return JSON.stringify(invocation);
}
function done(base, step, hookSequential, traceMsg) {
    return {
        type: 'update-status', ...base, stepId: step.stepId, hookSequential,
        status: 'completed', cleaner: 'input_output', traceMsg,
    };
}
function fail(context, parentStep, step, hookSequential, error) {
    return {
        type: 'update-status',
        messageId: context.message.orderAt, threadId: context.message.threadId,
        taskId: context.task?.PK || '', parentStepId: parentStep.stepId, stepId: step.stepId,
        hookSequential, status: 'failed', cleaner: 'input_output',
        traceMsg: error instanceof Error ? error.message : String(error),
    };
}
function record(value, label) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error(`${label} must be an object.`);
    return value;
}
