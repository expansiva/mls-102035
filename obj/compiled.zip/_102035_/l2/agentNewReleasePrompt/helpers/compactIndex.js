/// <mls fileReference="_102035_/l2/agentNewReleasePrompt/helpers/compactIndex.ts" enhancement="_blank" />
import { ns5OntologyEntityIds } from '/_102035_/l2/solution/ontologyView.js';
import { ns5RuleEntries } from '/_102035_/l2/solution/rulesView.js';
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
const ENUM_VALUE_LIST_MAX = 12;
function enumValueIds(field) {
    if (field.type !== 'enum' || !Array.isArray(field.values))
        return null;
    const values = [];
    for (const item of field.values) {
        if (typeof item === 'string')
            values.push(item);
        else if (isRecord(item) && typeof item.value === 'string')
            values.push(item.value);
    }
    return values;
}
function fieldIndex(id, field) {
    const item = isRecord(field) ? field : {};
    const row = {
        id,
        type: typeof item.type === 'string' ? item.type : '',
        required: item.required === true,
    };
    const values = enumValueIds(item);
    if (!values)
        return row;
    if (values.length <= ENUM_VALUE_LIST_MAX)
        row.values = values;
    else
        row.valueCount = values.length;
    return row;
}
/** One level of `details.fields`, named `details.<id>`. The container itself stays out of the index. */
function detailFields(field) {
    if (!isRecord(field) || !isRecord(field.fields))
        return [];
    return Object.entries(field.fields).map(([id, child]) => fieldIndex(`details.${id}`, child));
}
function fieldsOf(entity) {
    const source = entity;
    const record = source.record;
    if (isRecord(record) && isRecord(record.fields)) {
        const fields = [];
        for (const [id, field] of Object.entries(record.fields)) {
            if (id === 'details')
                fields.push(...detailFields(field));
            else
                fields.push(fieldIndex(id, field));
        }
        return fields;
    }
    const fields = source.fields;
    if (!Array.isArray(fields))
        return [];
    const listed = [];
    for (const field of fields) {
        const item = isRecord(field) ? field : {};
        const id = typeof item.fieldId === 'string' ? item.fieldId : '';
        if (id === 'details')
            listed.push(...detailFields(item));
        else
            listed.push(fieldIndex(id, item));
    }
    return listed;
}
function stringList(value) {
    if (Array.isArray(value))
        return value.filter((item) => typeof item === 'string');
    if (typeof value === 'string' && value)
        return [value];
    return [];
}
function transitionsOf(entity) {
    const transitions = entity.transitions;
    if (!Array.isArray(transitions))
        return [];
    return transitions.map(item => {
        const row = isRecord(item) ? item : {};
        return {
            id: typeof row.transitionId === 'string' ? row.transitionId : '',
            from: stringList(row.from),
            to: typeof row.to === 'string' ? row.to : '',
            by: stringList(row.by),
        };
    });
}
function triggerOf(process) {
    const trigger = process.trigger;
    if (!trigger)
        return '';
    const parts = [trigger.kind, trigger.actorRef, trigger.event].filter(Boolean);
    return parts.join(':');
}
export function buildNrpIndex(artifacts) {
    const entityOrder = ns5OntologyEntityIds(artifacts.ontologyIndex);
    const byId = new Map(artifacts.entities.map(entity => [entity.entityId, entity]));
    const entities = entityOrder.map(entityId => {
        const entity = byId.get(entityId);
        if (!entity)
            return { entityId, kind: '', fields: [], transitions: [] };
        return {
            entityId,
            kind: String(entity.kind || ''),
            fields: fieldsOf(entity),
            transitions: transitionsOf(entity),
        };
    });
    const journeys = artifacts.journeys.map(journey => ({
        journeyId: journey.journeyId,
        title: journey.business.title,
        actorRef: journey.business.actorRef,
        stepIds: journey.business.steps.map(step => step.stepId),
    }));
    const grants = artifacts.access.grants.map(grant => ({
        grantId: grant.grantId,
        actorRef: grant.actorRef,
        entityRefs: [...grant.entityRefs],
        scope: grant.dataScope.mode,
    }));
    const processes = artifacts.workflows.processes.map(process => ({
        processId: process.processId,
        trigger: triggerOf(process),
        taskIds: process.tasks.map(task => task.taskId),
    }));
    const events = [
        ...artifacts.integration.inbound.map(item => ({
            id: item.id,
            direction: 'inbound',
            event: item.event || item.id,
        })),
        ...artifacts.integration.outbound.map(item => ({
            id: item.id,
            direction: 'outbound',
            event: item.event || item.id,
        })),
    ];
    return {
        moduleName: artifacts.module.moduleName,
        entities,
        rules: ns5RuleEntries(artifacts.rules).map(rule => ({
            ruleId: rule.ruleId,
            description: rule.description,
        })),
        journeys,
        grants,
        processes,
        events,
    };
}
