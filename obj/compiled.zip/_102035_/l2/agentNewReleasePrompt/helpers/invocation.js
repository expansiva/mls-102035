/// <mls fileReference="_102035_/l2/agentNewReleasePrompt/helpers/invocation.ts" enhancement="_blank" />
export const NRP_AGENT_NAME = 'agentNewReleasePrompt';
export const NRP_CANDIDATE_REL = 'tobe/plan';
const MODULE = /^[a-z][A-Za-z0-9]{0,59}$/u;
const PREFIX = /^@@agentNewReleasePrompt(?:\s+|$)/u;
function record(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
export function parseNrpInvocation(value, project) {
    if (!Number.isInteger(project) || project <= 0) {
        throw new Error('Select a valid project before editing a module.');
    }
    let raw = value;
    if (typeof value === 'string') {
        const body = value.trim().replace(PREFIX, '').trim();
        try {
            raw = JSON.parse(body);
        }
        catch (error) {
            console.error('[agentNewReleasePrompt] invocation is not JSON', error);
            throw new Error('Provide one valid JSON object after @@agentNewReleasePrompt.');
        }
    }
    if (!record(raw))
        throw new Error('Invocation must be one JSON object.');
    const allowed = new Set(['moduleName', 'request']);
    const unexpected = Object.keys(raw).find(key => !allowed.has(key));
    if (unexpected)
        throw new Error(`Unexpected field: ${unexpected}.`);
    const moduleName = raw.moduleName;
    if (typeof moduleName !== 'string' || !MODULE.test(moduleName))
        throw new Error('moduleName must be lowerCamel.');
    const request = raw.request;
    if (typeof request !== 'string' || !request.trim() || request.length > 10000) {
        throw new Error('request must be non-empty text of at most 10000 characters.');
    }
    return { project, moduleName, request: request.trim() };
}
export function serializeNrpInvocation(invocation) {
    return JSON.stringify({ moduleName: invocation.moduleName, request: invocation.request });
}
