/// <mls fileReference="_102047_/l4/mensalidadesAcademia/integration.defs.ts" enhancement="_blank"/>
export const mensalidadesAcademiaIntegration = {
    "schemaVersion": "2026-09-12-ns5-integration-v2",
    "moduleName": "mensalidadesAcademia",
    "inbound": [],
    "outbound": [
        {
            "id": "cancelarMatricula",
            "kind": "event",
            "to": "any",
            "event": "cancelarMatricula",
            "on": "Matricula.cancelarMatricula",
            "description": "Publica o cancelamento da matrícula para que outros módulos deixem de considerar o aluno ativo.",
            "entityRefs": [
                "Matricula"
            ]
        }
    ],
    "plugins": []
};
export default mensalidadesAcademiaIntegration;
