/// <mls fileReference="_102035_/l2/agentPlannerL4/steps/dispatch20/agentPlDispatch.ts" enhancement="_blank"/>
import { candidateRootOf, createRound1InvokeSteps, existingModuleName, loadPlRevision, runPlDispatch, } from '/_102035_/l2/agentPlannerL4/helpers/plCore.js';
import { l4diffFile } from '/_102035_/l2/agentPlannerL4/helpers/plDiff.js';
import { describeItemEffort, effortMasters, mergeEffort, writeChangeEffort, } from '/_102035_/l2/agentPlannerL4/helpers/plEffort.js';
import { addPlStep, PL_STEP_HOOKS, updateStatus, } from '/_102035_/l2/agentPlannerL4/helpers/plDispatch.js';
import { readChangeRequest } from '/_102035_/l2/solution/candidate/moduleRevision.js';
import { moduleFile, readJson } from '/_102035_/l2/solution/fs.js';
import { readL5Config } from '/_102035_/l2/solution/lib.js';
import { CHANGE_EFFORT_SCHEMA_VERSION, } from '/_102035_/l2/solution/poolPlan.js';
export async function beforePlDispatchPromptStep(_agent, context, parentStep, step, hookSequential) {
    const moduleName = existingModuleName(memoryString(context, 'moduleName') || moduleNameFromPrompt(step))
        || memoryString(context, 'moduleName')
        || moduleNameFromPrompt(step);
    if (candidateRootOf(moduleName)) {
        await recordMaintenanceEffort(moduleName);
        return [
            doneAnchor(context, parentStep, moduleName, '', 1, 'pool/l4/changeEffort.json written.', 0),
            updateStatus(context, parentStep, step, hookSequential, 'completed', 'dispatch20 wrote pool/l4/changeEffort.json.'),
        ];
    }
    const result = await runPlDispatch(moduleName, new Date());
    const invoke = createRound1InvokeSteps(moduleName, result);
    const missing = result.status;
    const status = missing
        || `pool/l2 pending for the planner (${result.artifacts.length} artifacts).`;
    return [
        ...invoke.map(child => addPlStep(context, parentStep, child)),
        doneAnchor(context, parentStep, moduleName, result.thread, result.artifacts.length, status, invoke.length),
        updateStatus(context, parentStep, step, hookSequential, 'completed', missing
            || `dispatch20 wrote pool/l2 and created ${invoke.length} planner step(s).`),
    ];
}
export async function afterPlDispatchPromptStep(_agent, context, parentStep, step, hookSequential) {
    const message = 'dispatch20 is deterministic and must never receive an LLM response.';
    return [updateStatus(context, parentStep, step, hookSequential, 'failed', message)];
}
function doneAnchor(context, parentStep, moduleName, thread, artifactCount, status, invokeCount) {
    return addPlStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Dispatch done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({
            moduleName, thread, artifactCount, status, invokeCount,
            completedStep: 'dispatch20', nextStep: 'loop30',
        }),
        planning: { planId: 'dispatch20-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
/** After `l4diff`, on `/candidate` only: ask each master, merge, and write `pool/l4/changeEffort.json`. */
async function recordMaintenanceEffort(moduleName) {
    const diff = await readJson(l4diffFile(moduleName, 'l2'));
    if (!diff)
        throw new Error(`l4diff missing for ${moduleName}`);
    const config = await readL5Config();
    const masters = effortMasters(config ?? {});
    const revision = await loadPlRevision(moduleName);
    const request = await readChangeRequest(moduleFile(moduleName).project, moduleName);
    const base = { baseId: revision?.baseId ?? '', revisionId: revision?.revisionId ?? '' };
    const perItem = [];
    for (const item of diff.items) {
        const answers = [];
        for (const master of masters) {
            answers.push(await describeItemEffort(master, { module: moduleName, base, item }));
        }
        perItem.push({ item, answers });
    }
    const merged = mergeEffort(perItem);
    const file = {
        schemaVersion: CHANGE_EFFORT_SCHEMA_VERSION,
        module: moduleName,
        base: { ...base, candidateRoot: candidateRootOf(moduleName) },
        request: { text: request?.text ?? '', items: diff.items },
        masters,
        perItem: merged.perItem,
        merged: merged.merged,
        untouched: { count: 0, sealHash: '' },
        status: merged.status,
    };
    await writeChangeEffort(moduleName, file);
    return file;
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function moduleNameFromPrompt(step) {
    try {
        const parsed = JSON.parse(String(step.prompt || '{}'));
        return typeof parsed.moduleName === 'string' ? parsed.moduleName : '';
    }
    catch {
        return '';
    }
}
PL_STEP_HOOKS.dispatch20 = {
    beforePromptStep: beforePlDispatchPromptStep,
    afterPromptStep: afterPlDispatchPromptStep,
};
