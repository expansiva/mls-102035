/// <mls fileReference="_102035_/l2/agentPlannerL4/steps/entry10/agentPlEntry.ts" enhancement="_blank"/>
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { setModuleRoot } from '/_102035_/l2/solution/fs.js';
import { applyL5PlannerDeps, existingModuleName, gatherPlEntryFacts, parsePlInvocation, plEntryRefusal, unknownPipelineFlowId, wipeModulePool, } from '/_102035_/l2/agentPlannerL4/helpers/plCore.js';
import { PL_STEP_HOOKS, addPlStep, drainWaitingSiblings, updateStatus, } from '/_102035_/l2/agentPlannerL4/helpers/plDispatch.js';
export async function beforePlEntryPromptStep(_agent, context, parentStep, step, hookSequential) {
    const invocation = parsePlInvocation(String(context.message?.content || ''));
    const moduleName = memoryString(context, 'moduleName') || invocation.module || moduleNameFromPrompt(step);
    invocation.fast = invocation.fast || memoryString(context, 'fastMode') === 'true';
    if (moduleName)
        invocation.module = moduleName;
    const candidate = invocation.candidate || memoryString(context, 'candidate');
    invocation.candidate = candidate;
    setModuleRoot(invocation.module, candidate || null);
    const facts = await gatherPlEntryFacts(invocation.module);
    const refusal = plEntryRefusal(invocation, facts);
    if (refusal) {
        return [
            addPlStep(context, parentStep, {
                type: 'result',
                stepId: 0,
                status: 'completed',
                interaction: null,
                nextSteps: [],
                stepTitle: 'Status',
                result: refusal,
                planning: { planId: 'status', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
            }),
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${refusal}`),
            updateStatus(context, parentStep, step, hookSequential, 'completed', refusal),
        ];
    }
    const existing = existingModuleName(invocation.module) || invocation.module;
    const wiped = await wipeModulePool(existing, new Date());
    const adjusted = await applyL5PlannerDeps(existing);
    const already = getAllSteps(context.task?.iaCompressed?.nextSteps).some(item => item.planning?.planId === 'entry10-done');
    const unknownFlowId = unknownPipelineFlowId(facts.pipelineFlowId);
    const extra = already ? [] : [doneAnchor(context, parentStep, existing, adjusted, wiped, candidate, unknownFlowId)];
    const parts = [
        wiped.length ? `wiped ${wiped.length} pool path(s)` : 'pool already empty',
        adjusted.length
            ? `adjusted l5/config.json (${adjusted.join(', ')})`
            : 'l5/config.json already lists the planner projects',
    ];
    if (candidate)
        parts.push(`candidate ${candidate}`);
    if (unknownFlowId)
        parts.push(`unknown pipeline flowId "${unknownFlowId}" recorded`);
    return [
        ...extra,
        updateStatus(context, parentStep, step, hookSequential, 'completed', `entry10: ${parts.join('; ')}.`),
    ];
}
export async function afterPlEntryPromptStep(_agent, context, parentStep, step, hookSequential) {
    const message = 'entry10 is deterministic and must never receive an LLM response.';
    return [updateStatus(context, parentStep, step, hookSequential, 'failed', message)];
}
function doneAnchor(context, parentStep, moduleName, l5Adjusted, poolWiped, candidate, unknownFlowId) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'result',
            stepId: 0,
            interaction: null,
            stepTitle: 'Entry done',
            status: 'completed',
            nextSteps: [],
            result: JSON.stringify({
                moduleName, l5Adjusted, poolWiped, candidate, unknownFlowId,
                completedStep: 'entry10', nextStep: 'diff20',
            }),
            planning: { planId: 'entry10-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
        },
    };
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function moduleNameFromPrompt(step) {
    try {
        const parsed = JSON.parse(String(step.prompt || '{}'));
        return typeof parsed.moduleName === 'string' ? parsed.moduleName : '';
    }
    catch {
        return '';
    }
}
PL_STEP_HOOKS.entry10 = {
    beforePromptStep: beforePlEntryPromptStep,
    afterPromptStep: afterPlEntryPromptStep,
};
