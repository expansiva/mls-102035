/// <mls fileReference="_102035_/l2/agentPlannerL4/agentPlannerL4.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { setModuleRoot } from '/_102035_/l2/solution/fs.js';
import { PL_AGENT_NAME, buildPlPlannedSteps, existingModuleName, gatherPlEntryFacts, isPlStepId, parsePlInvocation, plEntryRefusal, } from '/_102035_/l2/agentPlannerL4/helpers/plCore.js';
import { drainWaitingSiblings, hooksFor, planIdOf, updateStatus, } from '/_102035_/l2/agentPlannerL4/helpers/plDispatch.js';
import '/_102035_/l2/agentPlannerL4/steps/entry10/agentPlEntry.js';
import '/_102035_/l2/agentPlannerL4/steps/diff20/agentPlDiff.js';
import '/_102035_/l2/agentPlannerL4/steps/dispatch20/agentPlDispatch.js';
import '/_102035_/l2/agentPlannerL4/steps/loop30/agentPlLoop.js';
export function createAgent() {
    return {
        agentName: PL_AGENT_NAME,
        agentProject: 102035,
        agentFolder: 'agentPlannerL4',
        agentDescription: 'L4 planner — wipes the module pool, lists artifacts, writes pool/l1 and pool/l2, and orchestrates L2 → L1 → L2 by steps in the same task.',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const invocation = parsePlInvocation(userPrompt || '');
    setModuleRoot(invocation.module, invocation.candidate || null);
    const facts = await gatherPlEntryFacts(invocation.module);
    const refusal = plEntryRefusal(invocation, facts);
    if (refusal)
        return statusTask(agent, context, refusal);
    const moduleName = existingModuleName(invocation.module) || invocation.module;
    const addMessage = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: 'agentPlannerL4 deterministic bootstrap. The root LLM is skipped by AgentIntentAddMessageAI.skipRootLLM.' },
                { type: 'human', content: moduleName },
            ],
            taskTitle: `plan ${moduleName}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {
                taskName: 'plannerL4',
                flowName: PL_AGENT_NAME,
                moduleName,
                candidate: invocation.candidate,
                ...(invocation.fast ? { fastMode: 'true' } : {}),
            },
        },
    };
    const steps = buildPlPlannedSteps(moduleName).map(step => addStepIntent(context, step));
    return [addMessage, ...steps];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    const planId = planIdOf(step);
    const hooks = hooksFor(planId);
    if (hooks?.beforePromptStep)
        return hooks.beforePromptStep(agent, context, parentStep, step, hookSequential, args);
    if (isPlStepId(planId))
        return notImplemented(context, parentStep, step, hookSequential, planId);
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential, args) {
    const planId = planIdOf(step);
    const hooks = hooksFor(planId);
    if (hooks?.afterPromptStep)
        return hooks.afterPromptStep(agent, context, parentStep, step, hookSequential, args);
    if (isPlStepId(planId))
        return notImplemented(context, parentStep, step, hookSequential, planId);
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
async function notImplemented(context, parentStep, step, hookSequential, stepId) {
    const traceMsg = `step ${stepId} not implemented yet`;
    return [
        ...drainWaitingSiblings(context, step, hookSequential, `stopped: awaiting step ${stepId}`, { onlyUnimplemented: true }),
        updateStatus(context, parentStep, step, hookSequential, 'completed', traceMsg),
    ];
}
function addStepIntent(context, step) {
    return {
        type: 'add-step',
        messageId: '',
        threadId: context.message.threadId,
        taskId: '',
        parentStepId: 1,
        step,
    };
}
function plStatusMessage(agent, context, message) {
    return {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: `<!-- modelType: general -->\n${message}` },
                { type: 'human', content: message },
            ],
            taskTitle: 'planner L4',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'plannerL4', flowName: PL_AGENT_NAME, statusOnly: 'true' },
        },
    };
}
function statusTask(agent, context, message) {
    const addMessage = plStatusMessage(agent, context, message);
    const result = {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: 'Status',
        result: message,
        planning: { planId: 'status', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
    return [addMessage, addStepIntent(context, result)];
}
