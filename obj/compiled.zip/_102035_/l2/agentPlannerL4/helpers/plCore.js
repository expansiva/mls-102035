/// <mls fileReference="_102035_/l2/agentPlannerL4/helpers/plCore.ts" enhancement="_blank"/>
import { diskFileInfo, displayPath, hostListFolder, listModuleFolders, moduleFile, moduleFolder, normalizeModuleName, pipelineFile, readPipeline, writeJson, writePipeline, } from '/_102035_/l2/solution/fs.js';
import { readL5Config, writeL5Config } from '/_102035_/l2/solution/lib.js';
import { deletePoolMessage, listPoolBox, nextThread, POOL_BOXES, POOL_MAX_ROUND, readPoolMessage, readPoolTrace, tracePool, writePoolMessage, } from '/_102035_/l2/solution/pool.js';
export const PL_FLOW_ID = 'agentPlannerL4';
export const PL_FLOW_VERSION = '2026-09-21-pl-flow-v4';
export const PL_AGENT_NAME = 'agentPlannerL4';
export const PL_STEP_IDS = ['entry10', 'diff20', 'dispatch20', 'loop30'];
export const PL_KNOWN_FLOW_IDS = ['agentNewSolution5', 'agentReviewSolution', 'agentPlannerL4'];
export const PL_DEFAULT_CANDIDATE_REL = 'tobe/plan';
export const PL_L4DIFF_REL = ['pool/l1/web/l4diff.json', 'pool/l2/web/l4diff.json'];
export const PL_PLANNER_PROJECTS = ['102020', '102021'];
export const PL_L2_AGENT = 'agentPlannerL2';
export const PL_L1_AGENT = 'agentPlannerL1';
export const PL_EXCLUDED_TOP = ['pipeline', 'tobe', 'pool'];
export const PL_DISPATCH_BODY = 'Evaluate and dispatch. The recipient decides what to do with these artifacts.';
export const PL_STEP_TITLES = {
    entry10: 'Entry',
    diff20: 'Diff',
    dispatch20: 'Dispatch',
    loop30: 'Loop',
};
export const PL_STEP_DEPENDS_ON = {
    entry10: [],
    diff20: ['entry10-done'],
    dispatch20: ['diff20-done'],
    loop30: ['dispatch20-done'],
};
const FAST_RE = /(^|\s)\/fast(?=\s|$)/i;
const ESTIMATE_RE = /(^|\s)\/estimate(?=\s|$)/i;
const CANDIDATE_RE = /(^|\s)\/candidate(?:\s+(?!\/)(\S+))?(?=\s|$)/i;
export function isPlStepId(value) {
    return PL_STEP_IDS.includes(value);
}
export function ownerStepId(planId) {
    if (isPlStepId(planId))
        return planId;
    for (const id of PL_STEP_IDS) {
        if (planId === `${id}-done` || planId.startsWith(`${id}-clarification`))
            continue;
        if (planId.startsWith(`${id}-`))
            return id;
    }
    return '';
}
export function moduleTokenOk(moduleName) {
    return /^[a-z][A-Za-z0-9]*$/.test(moduleName);
}
export function resolveCandidateFolder(moduleName, relativePath = '') {
    const mod = normalizeModuleName(moduleName);
    const rel = String(relativePath || '').trim().replace(/^\/+|\/+$/g, '') || PL_DEFAULT_CANDIDATE_REL;
    if (rel.includes('..'))
        return '';
    if (rel === mod || rel.startsWith(`${mod}/`))
        return rel;
    return `${mod}/${rel}`;
}
export function candidateRootOf(moduleName) {
    const root = moduleFolder(moduleName);
    const canonical = normalizeModuleName(moduleName);
    return root === canonical ? '' : root;
}
export function unknownPipelineFlowId(flowId) {
    const id = String(flowId || '').trim();
    if (!id)
        return '';
    return PL_KNOWN_FLOW_IDS.includes(id) ? '' : id;
}
export function parsePlInvocation(value) {
    const raw = String(value || '').replace(/^@@agentPlannerL4\b/i, ' ').trim();
    const fast = FAST_RE.test(raw);
    const estimate = ESTIMATE_RE.test(raw);
    const candidateMatch = CANDIDATE_RE.exec(raw);
    const hasCandidate = !!candidateMatch;
    const candidateRel = candidateMatch?.[2] || '';
    const stripped = raw
        .replace(new RegExp(FAST_RE.source, 'gi'), ' ')
        .replace(new RegExp(ESTIMATE_RE.source, 'gi'), ' ')
        .replace(new RegExp(CANDIDATE_RE.source, 'gi'), ' ')
        .replace(/\s+/g, ' ')
        .trim();
    const token = stripped.split(' ')[0] || '';
    const module = moduleTokenOk(token) ? token : normalizeModuleName(token, '');
    const candidate = hasCandidate && module ? resolveCandidateFolder(module, candidateRel) : '';
    return { fast, estimate, module, candidate };
}
export function existingModuleName(moduleName) {
    const wanted = moduleName.toLowerCase();
    for (const name of listModuleFolders()) {
        if (name.toLowerCase() === wanted)
            return name;
    }
    return '';
}
/**
 * Every deterministic refusal of the invocation in one pure place. Empty string means
 * the run may continue. Texts are English (i18n default).
 */
export function plEntryRefusal(invocation, facts) {
    if (invocation.estimate)
        return 'not available yet';
    if (!invocation.module)
        return 'Provide the module name after @@agentPlannerL4 (lowerCamel).';
    if (!moduleTokenOk(invocation.module))
        return 'Module name must be lowerCamel (example: stockControl).';
    if (!facts.moduleExists)
        return `Module "${invocation.module}" does not exist in l4/.`;
    if (facts.pipelineStatus !== 'complete') {
        return `Module "${invocation.module}" pipeline is not complete.`;
    }
    if (!facts.l5ConfigExists)
        return 'l5/config.json is missing.';
    return '';
}
export async function gatherPlEntryFacts(moduleName) {
    const existing = moduleName ? existingModuleName(moduleName) : '';
    const pipeline = existing ? await readPipeline(existing) : null;
    const config = await readL5Config();
    return {
        moduleExists: !!existing,
        pipelineStatus: pipeline?.status || '',
        pipelineFlowId: pipeline?.flowId || '',
        l5ConfigExists: config !== null,
    };
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
/**
 * Append planner projects to workspaceDependencies (existing order kept) and fill
 * `projects[id] = { root: '../mls-<id>', type: 'lib' }` when missing. No-op when both
 * 102020 and 102021 are already declared — caller must not rewrite the file then.
 */
export function adjustL5PlannerDeps(config) {
    const deps = Array.isArray(config.workspaceDependencies) ? [...config.workspaceDependencies] : [];
    const projects = isRecord(config.projects) ? { ...config.projects } : {};
    const adjusted = [];
    for (const id of PL_PLANNER_PROJECTS) {
        if (!deps.some(entry => String(entry) === id)) {
            deps.push(id);
            adjusted.push(`workspaceDependencies:+${id}`);
        }
        if (!isRecord(projects[id])) {
            projects[id] = { root: `../mls-${id}`, type: 'lib' };
            adjusted.push(`projects:+${id}`);
        }
    }
    if (!adjusted.length)
        return { config, adjusted };
    return { config: { ...config, workspaceDependencies: deps, projects }, adjusted };
}
/** Writes only when something was missing. Records tokens on the module pipeline. */
export async function applyL5PlannerDeps(moduleName) {
    const config = await readL5Config();
    // entry10 already refuses when the file is missing; a silent no-op here would hide the day
    // another caller reaches this without that guard.
    if (!config)
        throw new Error('[agentPlannerL4] l5/config.json is missing — cannot adjust planner dependencies.');
    const { config: next, adjusted } = adjustL5PlannerDeps(config);
    if (!adjusted.length)
        return [];
    await writeL5Config(next);
    const pipeline = await readPipeline(moduleName);
    if (pipeline) {
        const nextPipeline = {
            ...pipeline,
            l5Adjusted: [...(pipeline.l5Adjusted || []), ...adjusted],
            updatedAt: new Date().toISOString(),
        };
        await writePipeline(nextPipeline);
    }
    return adjusted;
}
export function createPlAgentStep(stepId, moduleName) {
    const dependsOn = [...PL_STEP_DEPENDS_ON[stepId]];
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: PL_STEP_TITLES[stepId],
        status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName: PL_AGENT_NAME,
        prompt: JSON.stringify({ planId: stepId, moduleName }),
        rags: [],
        planning: {
            planId: stepId,
            dependsOn,
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
export function buildPlPlannedSteps(moduleName) {
    return PL_STEP_IDS.map(stepId => createPlAgentStep(stepId, moduleName));
}
export function plDispatchSubject(moduleName) {
    return `Changed artifacts of ${moduleName}`;
}
/**
 * Same lookup `getInstanceByName` uses (a `.ts` whose shortName is the agent), without
 * importing the module. Missing file ⇒ not available. File present ⇒ create the step;
 * a later host `Invalid agent` still surfaces if `createAgent` is absent.
 */
export function plannerAgentPresent(agentName) {
    if (!agentName.startsWith('agent'))
        return false;
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.status === 'deleted')
            continue;
        if (file.extension !== '.ts')
            continue;
        if (String(file.shortName || '') !== agentName)
            continue;
        return true;
    }
    return false;
}
function topSegmentAfterModule(folder, root) {
    const rest = folder === root
        ? ''
        : folder.startsWith(`${root}/`)
            ? folder.slice(root.length + 1)
            : folder;
    return rest.split('/').filter(Boolean)[0] || '';
}
function artifactRelPath(file, root) {
    const folder = String(file.folder || '');
    const rest = folder === root
        ? ''
        : folder.startsWith(`${root}/`)
            ? folder.slice(root.length + 1)
            : folder;
    const name = `${file.shortName || ''}${file.extension || ''}`;
    return rest ? `${rest}/${name}` : name;
}
/** Every file under the module root (canonical or `/candidate`) except `pipeline/`, `tobe/`, `pool/`. */
export function listPlArtifacts(moduleName) {
    const root = moduleFolder(moduleName);
    const project = moduleFile(moduleName).project;
    const files = mls.stor.files;
    const found = new Map();
    const consider = (file) => {
        if (file.status === 'deleted' || !file.shortName)
            return;
        const folder = String(file.folder || '');
        const top = topSegmentAfterModule(folder, root);
        if (PL_EXCLUDED_TOP.includes(top))
            return;
        const rel = artifactRelPath(file, root);
        if (rel)
            found.set(rel, true);
    };
    for (const file of Object.values(files)) {
        if (!file || file.project !== project || Number(file.level) !== 4)
            continue;
        const folder = String(file.folder || '');
        if (folder !== root && !folder.startsWith(`${root}/`))
            continue;
        consider(file);
    }
    const listFolder = hostListFolder();
    if (listFolder) {
        for (const info of listFolder(project, 4, root)) {
            const key = mls.stor.getKeyToFile(info);
            const indexed = files[key];
            if (indexed?.status === 'deleted')
                continue;
            if (!indexed)
                files[key] = diskFileInfo(info);
            consider(indexed || info);
        }
    }
    return [...found.keys()].sort();
}
export function buildPlPoolMessage(moduleName, to, thread, artifacts) {
    return {
        from: 'l4',
        to,
        thread,
        round: 1,
        mode: 'implement',
        subject: plDispatchSubject(moduleName),
        artifacts: [...artifacts],
        body: PL_DISPATCH_BODY,
    };
}
export function invokePlanId(box, thread, round) {
    return `pool-${box}-${thread}-${round}`;
}
export function plRoundPlanId(side, round) {
    return side === 'effort' ? `l2-effort-r${round}` : `${side}-r${round}`;
}
export function plRoundTitle(side, round) {
    if (side === 'effort')
        return `L2 effort r${round}`;
    if (side === 'l1')
        return `L1 r${round}`;
    return `L2 r${round}`;
}
export function plStepPrompt(moduleName, thread, file) {
    return JSON.stringify({ moduleName, thread, file, candidate: candidateRootOf(moduleName) });
}
export function createPlInvokeStep(args) {
    const dependsOn = [...(args.dependsOn || [])];
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: args.stepTitle
            || (args.agentName === PL_L1_AGENT ? 'Planner L1' : 'Planner L2'),
        status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName: args.agentName,
        prompt: plStepPrompt(args.moduleName, args.thread, args.file),
        rags: [],
        planning: {
            planId: args.planId,
            dependsOn,
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
export function createPlLoopWaitStep(moduleName, dependsOn, tick) {
    const planId = `loop30-wait-${tick}`;
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: PL_STEP_TITLES.loop30,
        status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName: PL_AGENT_NAME,
        prompt: JSON.stringify({ planId, moduleName }),
        rags: [],
        planning: {
            planId,
            dependsOn,
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
export function nextLoopWaitTick(planId) {
    const match = /^loop30-wait-(\d+)$/.exec(planId);
    return match ? Number(match[1]) + 1 : 1;
}
export async function runPlDispatch(moduleName, now) {
    const artifacts = [...listPlArtifacts(moduleName), ...PL_L4DIFF_REL];
    const thread = nextThread(moduleName, now);
    const at = now.toISOString();
    const l2File = await writePoolMessage(moduleName, buildPlPoolMessage(moduleName, 'l2', thread, artifacts), now);
    const l1File = await writePoolMessage(moduleName, buildPlPoolMessage(moduleName, 'l1', thread, artifacts), now);
    const l2Path = displayPath(l2File);
    const l1Path = displayPath(l1File);
    const base = { at, thread, round: 1, mode: 'implement', from: 'l4', outcome: 'delivered' };
    await tracePool(moduleName, { ...base, file: l2Path, to: 'l2' });
    await tracePool(moduleName, { ...base, file: l1Path, to: 'l1' });
    const invokeL2 = plannerAgentPresent(PL_L2_AGENT);
    const invokeL1 = plannerAgentPresent(PL_L1_AGENT);
    return { artifacts, thread, l2File, l1File, l2Path, l1Path, invokeL2, invokeL1, status: formatMissingPlannerStatus(1, invokeL2, invokeL1) };
}
export function createRound1InvokeSteps(moduleName, run) {
    if (!run.invokeL2)
        return [];
    return [createPlInvokeStep({
            agentName: PL_L2_AGENT,
            moduleName,
            thread: run.thread,
            file: run.l2Path,
            planId: plRoundPlanId('l2', 1),
            stepTitle: plRoundTitle('l2', 1),
        })];
}
function otherBox(box) {
    return box === 'l4' ? 'l2' : 'l4';
}
function listIndexedPoolFiles(moduleName, folder) {
    const project = moduleFile(moduleName).project;
    const files = mls.stor.files;
    const found = new Map();
    const consider = (file) => {
        if (file.status === 'deleted' || !file.shortName)
            return;
        if (String(file.folder || '') !== folder)
            return;
        const info = {
            project, level: 4, folder, shortName: String(file.shortName), extension: String(file.extension || ''),
        };
        found.set(`${info.shortName}${info.extension}`, info);
    };
    for (const file of Object.values(files)) {
        if (!file || file.project !== project || Number(file.level) !== 4)
            continue;
        consider(file);
    }
    const listFolder = hostListFolder();
    if (listFolder) {
        for (const info of listFolder(project, 4, folder)) {
            const key = mls.stor.getKeyToFile(info);
            const indexed = files[key];
            if (indexed?.status === 'deleted')
                continue;
            if (!indexed)
                files[key] = diskFileInfo(info);
            consider(indexed || info);
        }
    }
    return [...found.values()];
}
/** `l4/<mod>/pool/<box>/web/**.json` — not pool messages (menu/needs/backend/effort). */
export function listPoolWebFiles(moduleName, box) {
    const folder = `${moduleFolder(moduleName)}/pool/${box}/web`;
    return listIndexedPoolFiles(moduleName, folder).filter(file => file.extension === '.json');
}
/**
 * se os artefatos do l4 mudarem, todo o planejamento dos pools deve ser refeito
 *
 * Wipes every mailbox of the module: pool messages (trace `processed` then
 * `deletePoolMessage`) and `web/*.json`. Records `poolWiped` on the l4 pipeline.
 * Trace outcome stays `processed` (the pool enum does not grow); the reason is
 * `pool wiped: l4 changed`.
 */
export async function wipeModulePool(moduleName, now) {
    const wiped = [];
    const at = now.toISOString();
    const threadFallback = `${normalizeModuleName(moduleName)}-00000000000000`;
    for (const box of POOL_BOXES) {
        for (const file of listPoolBox(moduleName, box)) {
            const path = displayPath(file);
            let from = otherBox(box);
            let to = box;
            let thread = threadFallback;
            let round = 1;
            let mode = 'implement';
            try {
                const message = await readPoolMessage(file);
                from = message.from;
                to = message.to;
                thread = message.thread;
                round = message.round;
                mode = message.mode;
            }
            catch {
                // unreadable leftover: still wipe, with a synthetic trace so deletePoolMessage can run
            }
            await tracePool(moduleName, {
                at, file: path, from, to, thread, round, mode,
                outcome: 'processed',
            });
            await deletePoolMessage(moduleName, file, path);
            wiped.push(path);
        }
        for (const file of listPoolWebFiles(moduleName, box)) {
            const path = displayPath(file);
            const { deleteFile } = await import('/_102027_/l2/libStor.js');
            await deleteFile(diskFileInfo(file));
            wiped.push(path);
        }
    }
    const pipeline = await readPipeline(moduleName);
    if (pipeline) {
        await writeJson(pipelineFile(moduleName), { ...pipeline, poolWiped: wiped, updatedAt: at });
    }
    return wiped;
}
export async function findOldestBoxMessage(moduleName, box, from, thread) {
    const items = await loadPlBoxMessages(moduleName, box);
    const match = items.filter(item => item.message.thread === thread && item.message.from === from);
    return match[0] || null;
}
function hasPoolWebJson(moduleName, box, shortName) {
    return listPoolWebFiles(moduleName, box).some(file => file.shortName === shortName && file.extension === '.json');
}
/**
 * After an L2/L1 invoke, the table cell is `done` only when the planner produced.
 * L2: `pool/l2/web/menu.json` and a `l2→l1` message. L1: `l1→l2` message or `backend.json`.
 * No production → `no-output` (the loop fails the task with "<planId> ran without output").
 */
export async function plInvokeOutput(side, moduleName, thread) {
    if (side === 'l2') {
        const hasMenu = hasPoolWebJson(moduleName, 'l2', 'menu');
        const needs = await findOldestBoxMessage(moduleName, 'l1', 'l2', thread);
        return hasMenu && needs ? 'done' : 'no-output';
    }
    const reply = await findOldestBoxMessage(moduleName, 'l2', 'l1', thread);
    const hasBackend = hasPoolWebJson(moduleName, 'l2', 'backend');
    return reply || hasBackend ? 'done' : 'no-output';
}
export async function writePlOrchestration(moduleName, table) {
    const pipeline = await readPipeline(moduleName);
    if (!pipeline)
        return;
    await writeJson(pipelineFile(moduleName), {
        ...pipeline,
        plOrchestration: table,
        updatedAt: new Date().toISOString(),
    });
}
export function formatMissingPlannerStatus(round, l2Available, l1Available) {
    const missing = [];
    if (!l2Available)
        missing.push('l2 pending (agentPlannerL2 not available)');
    if (!l1Available)
        missing.push('l1 pending (agentPlannerL1 not available)');
    if (!missing.length)
        return '';
    return `round ${round}/${POOL_MAX_ROUND} · ${missing.join('; ')}. Requests stayed in the box.`;
}
export async function loadPlBoxMessages(moduleName, box) {
    const out = [];
    for (const file of listPoolBox(moduleName, box)) {
        out.push({ file, path: displayPath(file), message: await readPoolMessage(file) });
    }
    return out;
}
export function plDeliveredRounds(trace, thread, to) {
    return trace.filter(line => line.thread === thread && line.to === to && line.outcome === 'delivered').length;
}
export function decidePlLoop(input) {
    const invoke = [];
    const disputed = [];
    const pendingUnavailable = [];
    const traced = new Set(input.trace.map(line => line.file));
    const alreadyDisputed = new Set(input.trace.filter(line => line.outcome === 'disputed').map(line => line.file));
    const handle = (box, items, available, agentName) => {
        const rounds = plDeliveredRounds(input.trace, input.thread, box);
        if (items.length && rounds >= POOL_MAX_ROUND) {
            for (const item of items) {
                if (alreadyDisputed.has(item.path))
                    continue;
                disputed.push(toInvoke(box, agentName, item));
            }
            return;
        }
        const fresh = items.filter(item => !traced.has(item.path));
        if (fresh.length && rounds < POOL_MAX_ROUND) {
            if (!available) {
                pendingUnavailable.push(box);
                return;
            }
            invoke.push(toInvoke(box, agentName, fresh[0]));
            return;
        }
        if (items.length && !available)
            pendingUnavailable.push(box);
    };
    handle('l2', input.l2, input.l2Available, PL_L2_AGENT);
    handle('l1', input.l1, input.l1Available, PL_L1_AGENT);
    const maxRound = Math.max(1, plDeliveredRounds(input.trace, input.thread, 'l2'), plDeliveredRounds(input.trace, input.thread, 'l1'), ...input.l1.map(item => item.message.round), ...input.l2.map(item => item.message.round));
    const stop = invoke.length === 0;
    const status = stop
        ? formatLoopStopStatus(maxRound, disputed.length > 0, pendingUnavailable, input.l1.length + input.l2.length)
        : '';
    return { invoke, disputed, stop, status, maxRound };
}
function toInvoke(box, agentName, item) {
    return {
        box,
        agentName,
        file: item.file,
        path: item.path,
        thread: item.message.thread,
        round: item.message.round,
        from: item.message.from,
        to: item.message.to,
        mode: item.message.mode,
    };
}
function formatLoopStopStatus(maxRound, disputed, pendingUnavailable, pendingCount) {
    if (disputed) {
        return `round ${maxRound}/${POOL_MAX_ROUND} · disputed. Messages were not deleted.`;
    }
    const missing = [];
    if (pendingUnavailable.includes('l2'))
        missing.push('l2 pending (agentPlannerL2 not available)');
    if (pendingUnavailable.includes('l1'))
        missing.push('l1 pending (agentPlannerL1 not available)');
    if (missing.length) {
        return `round ${maxRound}/${POOL_MAX_ROUND} · ${missing.join('; ')}. Requests stayed in the box.`;
    }
    if (pendingCount === 0)
        return `round ${maxRound}/${POOL_MAX_ROUND} · pool empty.`;
    return `round ${maxRound}/${POOL_MAX_ROUND} · pending.`;
}
export async function applyPlLoopDecision(moduleName, decision, now) {
    const at = now.toISOString();
    for (const item of decision.disputed) {
        await tracePool(moduleName, {
            at, file: item.path, from: item.from, to: item.to,
            thread: item.thread, round: item.round, mode: item.mode, outcome: 'disputed',
        });
    }
    for (const item of decision.invoke) {
        await tracePool(moduleName, {
            at, file: item.path, from: item.from, to: item.to,
            thread: item.thread, round: item.round, mode: item.mode, outcome: 'delivered',
        });
    }
}
export function latestDeliveredThread(trace) {
    for (let i = trace.length - 1; i >= 0; i -= 1) {
        if (trace[i].outcome === 'delivered' && trace[i].from === 'l4')
            return trace[i].thread;
    }
    return trace[trace.length - 1]?.thread || '';
}
export async function gatherPlLoopDecision(moduleName, thread) {
    const trace = await readPoolTrace(moduleName);
    const current = thread || latestDeliveredThread(trace);
    const l1 = (await loadPlBoxMessages(moduleName, 'l1')).filter(item => !current || item.message.thread === current);
    const l2 = (await loadPlBoxMessages(moduleName, 'l2')).filter(item => !current || item.message.thread === current);
    return decidePlLoop({
        thread: current,
        trace,
        l1,
        l2,
        l1Available: plannerAgentPresent(PL_L1_AGENT),
        l2Available: plannerAgentPresent(PL_L2_AGENT),
    });
}
export function invokeSideOf(item) {
    if (item.box === 'l1')
        return 'l1';
    if (item.from === 'l1')
        return 'effort';
    return 'l2';
}
export function createLoopInvokeStep(moduleName, item, dependsOn = []) {
    const side = invokeSideOf(item);
    return createPlInvokeStep({
        agentName: item.agentName,
        moduleName,
        thread: item.thread,
        file: item.path,
        planId: plRoundPlanId(side, item.round),
        stepTitle: plRoundTitle(side, item.round),
        dependsOn,
    });
}
