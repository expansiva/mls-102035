/// <mls fileReference="_102035_/l2/agentPlannerL4/helpers/plDispatch.ts" enhancement="_blank"/>
import { ownerStepId } from '/_102035_/l2/agentPlannerL4/helpers/plCore.js';
/** Filled by step modules. A missing entry means the step is not implemented yet. */
export const PL_STEP_HOOKS = {};
export function planIdOf(step) {
    return step.planning?.planId || '';
}
export function hooksFor(planId) {
    const stepId = ownerStepId(planId);
    return stepId ? PL_STEP_HOOKS[stepId] : undefined;
}
export function addPlStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
export function updateStatus(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        cleaner: 'input_output',
        traceMsg,
    };
}
export function drainWaitingSiblings(context, current, hookSequential, traceMsg, opts) {
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    if (!root)
        return [];
    const intents = [];
    for (const sibling of walk(root.nextSteps || [])) {
        if (sibling.stepId === current.stepId)
            continue;
        if (sibling.status === 'completed' || sibling.status === 'failed')
            continue;
        if (opts?.onlyUnimplemented && hooksFor(planIdOf(sibling)))
            continue;
        intents.push(updateStatus(context, root, sibling, hookSequential, 'completed', traceMsg));
    }
    return intents;
}
function walk(steps) {
    const out = [];
    for (const step of steps) {
        out.push(step);
        if (step.nextSteps?.length)
            out.push(...walk(step.nextSteps));
    }
    return out;
}
