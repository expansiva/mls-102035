/// <mls fileReference="_102035_/l2/agentPlannerL4/helpers/plDiff.ts" enhancement="_blank"/>
import { readL4Revision } from '/_102035_/l2/solution/candidate/moduleRevision.js';
import { parseNs4ClassicDefsSource as parseDefsSource } from '/_102035_/l2/solution/helpers/ns4ClassicDefs.js';
import { declaredRevisionBaseId, loadPlRevision, parseRevisionRoot, releaseL4Present, releaseL4Root, releaseMissingRefusal, revisionMissingRefusal, } from '/_102035_/l2/agentPlannerL4/helpers/plCore.js';
import { fileExists, moduleFile, moduleFolder, normalizeModuleName, readDefsJson, readJson, writeJson, } from '/_102035_/l2/solution/fs.js';
import { isNs5OntologyEntityV3, } from '/_102035_/l2/solution/types.js';
import { ns5OntologyEntityIds } from '/_102035_/l2/solution/ontologyView.js';
import { ns5RuleEntries } from '/_102035_/l2/solution/rulesView.js';
import { L4_DIFF_SCHEMA, L4_DIFF_OPS, L4_DIFF_KINDS, L4_TEXT_ATTRIBUTES, } from '/_102035_/l2/solution/poolPlan.js';
// 2026-10-08: reexport until consumers import from poolPlan. Remove this block when they migrate.
export { L4_DIFF_SCHEMA, L4_DIFF_OPS, L4_DIFF_KINDS, };
function emptySnapshot() {
    return {
        entities: {}, rules: {}, grants: {}, processes: {}, inbound: {}, outbound: {},
        journeys: {}, steps: {},
    };
}
function asString(value) {
    return typeof value === 'string' ? value : '';
}
function asStringArray(value) {
    return Array.isArray(value) ? value.map(item => String(item)) : [];
}
function sameJson(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
}
/** Copies every own attribute. `skip` is only the children that already have their own diff item. */
function assignOwn(target, source, skip) {
    for (const [key, value] of Object.entries(source)) {
        if (skip.has(key))
            continue;
        target[key] = value;
    }
}
function fileAt(project, root, rel) {
    const last = rel.lastIndexOf('/');
    const folder = last < 0 ? root : `${root}/${rel.slice(0, last)}`;
    const name = last < 0 ? rel : rel.slice(last + 1);
    const dot = name.indexOf('.');
    return {
        project,
        level: 4,
        folder,
        shortName: dot < 0 ? name : name.slice(0, dot),
        extension: dot < 0 ? '' : name.slice(dot),
    };
}
function textAttrs(source) {
    const record = source;
    const out = { title: '', description: '' };
    for (const key of L4_TEXT_ATTRIBUTES) {
        if (key !== 'title' && key !== 'description')
            continue;
        const value = record[key];
        if (typeof value === 'string')
            out[key] = value;
    }
    return out;
}
/** Codes plus `L4_TEXT_ATTRIBUTES` only, so a label edit is visible and an added code is not text. */
function enumLabels(field) {
    const raw = field.values ?? field.enum;
    if (!Array.isArray(raw))
        return undefined;
    return raw.map(item => {
        if (typeof item === 'string')
            return item;
        if (!item || typeof item !== 'object' || Array.isArray(item))
            return item;
        const row = item;
        const out = {};
        if (typeof row.value === 'string')
            out.value = row.value;
        for (const key of L4_TEXT_ATTRIBUTES) {
            if (typeof row[key] === 'string')
                out[key] = row[key];
        }
        return out;
    });
}
function fieldSlice(fieldId, field, derived) {
    const record = field;
    const slice = {
        fieldId,
        type: '',
        derived,
        title: '',
        description: '',
    };
    for (const [key, value] of Object.entries(record)) {
        if (key === 'fields' || key === 'enum')
            continue;
        slice[key] = value;
    }
    slice.fieldId = fieldId;
    slice.type = String(record.type || '');
    slice.derived = derived;
    const text = textAttrs(field);
    slice.title = text.title;
    slice.description = text.description;
    const values = enumLabels(field);
    if (values)
        slice.values = values;
    else
        delete slice.values;
    return slice;
}
function walkV3Fields(fields, parent, out) {
    for (const [id, field] of Object.entries(fields || {})) {
        const fieldId = parent ? `${parent}.${id}` : id;
        out[fieldId] = fieldSlice(fieldId, field, field.derived === true);
        if (field.fields)
            walkV3Fields(field.fields, fieldId, out);
    }
}
function transitionSlice(row, cloneBy) {
    const record = row;
    const slice = {
        transitionId: record.transitionId,
        from: [...record.from],
        to: record.to,
        by: cloneBy || Array.isArray(record.by) ? [...record.by] : record.by,
        description: record.description,
        ruleRefs: [...(record.ruleRefs || [])],
    };
    assignOwn(slice, record, new Set(['from', 'by', 'ruleRefs']));
    slice.transitionId = record.transitionId;
    slice.from = [...record.from];
    slice.to = record.to;
    slice.by = cloneBy || Array.isArray(record.by) ? [...record.by] : record.by;
    slice.description = record.description;
    slice.ruleRefs = [...(record.ruleRefs || [])];
    return slice;
}
function entitySlice(entity, source) {
    const fields = {};
    const transitions = {};
    if (isNs5OntologyEntityV3(entity)) {
        walkV3Fields(entity.record?.fields, '', fields);
        for (const row of entity.transitions || [])
            transitions[row.transitionId] = transitionSlice(row, true);
    }
    else {
        for (const field of entity.fields || []) {
            fields[field.fieldId] = fieldSlice(field.fieldId, field, false);
        }
        for (const [fieldId, detail] of Object.entries(entity.details || {})) {
            fields[fieldId] = fieldSlice(fieldId, detail, true);
        }
        for (const row of entity.transitions || [])
            transitions[row.transitionId] = transitionSlice(row, false);
    }
    const slice = {
        entityId: entity.entityId,
        source,
        fields,
        transitions,
        initialData: '',
    };
    assignOwn(slice, entity, new Set(['fields', 'transitions', 'details']));
    const record = slice.record;
    if (record && typeof record === 'object' && !Array.isArray(record)) {
        const copy = { ...record };
        delete copy.fields;
        slice.record = copy;
    }
    slice.entityId = entity.entityId;
    slice.source = source;
    slice.fields = fields;
    slice.transitions = transitions;
    // Absent initialData on a recorded table reads as ''. A role never carries it.
    slice.initialData = isNs5OntologyEntityV3(entity) && entity.kind === 'entity' ? (entity.initialData || '') : '';
    return slice;
}
function grantSlice(grant) {
    const slice = {
        grantId: grant.grantId,
        entityRefs: [...grant.entityRefs],
        dataScope: grant.dataScope,
        disclosure: grant.disclosure,
    };
    assignOwn(slice, grant, new Set(['entityRefs']));
    slice.grantId = grant.grantId;
    slice.entityRefs = [...grant.entityRefs];
    return slice;
}
function taskSlice(task) {
    const slice = {
        taskId: task.taskId,
        kind: task.kind,
        actorRef: asString(task.actorRef),
        journeyRef: asString(task.journeyRef),
        entityRef: asString(task.entityRef),
        effect: asString(task.effect),
        transitionRef: asString(task.transitionRef),
        next: [...(task.next || [])],
        description: task.description,
    };
    assignOwn(slice, task, new Set(['next']));
    slice.taskId = task.taskId;
    slice.kind = task.kind;
    slice.actorRef = asString(task.actorRef);
    slice.journeyRef = asString(task.journeyRef);
    slice.entityRef = asString(task.entityRef);
    slice.effect = asString(task.effect);
    slice.transitionRef = asString(task.transitionRef);
    slice.next = [...(task.next || [])];
    slice.description = task.description;
    // A recorded wait without wake reads as 'none', so adding the neutral value is not a change.
    if (task.kind === 'wait') {
        slice.wake = task.wake?.mode === 'periodic'
            ? { mode: 'periodic', ...(task.wake.every ? { every: task.wake.every } : {}) }
            : { mode: 'none' };
    }
    else {
        delete slice.wake;
    }
    return slice;
}
function processSlice(process) {
    const functions = {};
    for (const fn of process.functions || [])
        functions[fn.functionId] = fn.description;
    const tasks = {};
    for (const task of process.tasks || [])
        tasks[task.taskId] = taskSlice(task);
    const slice = {
        processId: process.processId,
        title: process.title,
        description: process.description,
        trigger: process.trigger,
        functions,
        // A recorded process without room reads as 'exclusive'.
        room: process.room || 'exclusive',
        tasks,
    };
    assignOwn(slice, process, new Set(['tasks', 'functions']));
    slice.processId = process.processId;
    slice.title = process.title;
    slice.description = process.description;
    slice.trigger = process.trigger;
    slice.functions = functions;
    slice.room = process.room || 'exclusive';
    slice.tasks = tasks;
    return slice;
}
/** Process-level view. `wake` is stored on each task and compared here, same as `functions`. */
function processCompare(row) {
    const wake = {};
    for (const task of Object.values(row.tasks)) {
        if (task.wake)
            wake[task.taskId] = task.wake;
    }
    const { tasks, ...rest } = row;
    return { ...rest, wake };
}
function taskForDiff(task, processId) {
    const rest = { ...task };
    delete rest.wake;
    return { ...rest, processId };
}
function integrationSlice(item) {
    const slice = {
        id: item.id,
        kind: item.kind,
        from: asString(item.from),
        to: asString(item.to),
        event: asString(item.event),
        writes: asStringArray(item.writes),
        effect: asString(item.effect),
        transitionRef: asString(item.transitionRef),
        on: asString(item.on),
        description: item.description,
        entityRefs: [...(item.entityRefs || [])],
    };
    assignOwn(slice, item, new Set(['writes', 'entityRefs']));
    slice.id = item.id;
    slice.kind = item.kind;
    slice.from = asString(item.from);
    slice.to = asString(item.to);
    slice.event = asString(item.event);
    slice.writes = asStringArray(item.writes);
    slice.effect = asString(item.effect);
    slice.transitionRef = asString(item.transitionRef);
    slice.on = asString(item.on);
    slice.description = item.description;
    slice.entityRefs = [...(item.entityRefs || [])];
    return slice;
}
/** Entity attributes compared as one item. Fields and transitions already have their own items. */
function entityBody(row) {
    const { fields, transitions, source, ...rest } = row;
    return rest;
}
/** Journey body compared as one item. Steps already have their own items. Derived hashes stay out. */
function journeySlice(journey, indexEntry) {
    const slice = {
        journeyId: journey.journeyId,
        index: { ...indexEntry },
    };
    assignOwn(slice, journey.business, new Set(['steps']));
    slice.journeyId = journey.journeyId;
    slice.index = { ...indexEntry };
    return slice;
}
function stepSlice(journeyId, step) {
    const slice = { journeyId, stepId: step.stepId };
    assignOwn(slice, step, new Set());
    slice.journeyId = journeyId;
    slice.stepId = step.stepId;
    return slice;
}
export function snapshotFromParsed(input) {
    const snap = emptySnapshot();
    for (const row of input.entities)
        snap.entities[row.entity.entityId] = entitySlice(row.entity, row.source);
    if (input.rules) {
        for (const rule of ns5RuleEntries(input.rules))
            snap.rules[rule.ruleId] = rule;
    }
    if (input.access) {
        for (const grant of input.access.grants || [])
            snap.grants[grant.grantId] = grantSlice(grant);
    }
    if (input.workflows) {
        for (const process of input.workflows.processes || [])
            snap.processes[process.processId] = processSlice(process);
    }
    if (input.integration) {
        for (const item of input.integration.inbound || [])
            snap.inbound[item.id] = integrationSlice(item);
        for (const item of input.integration.outbound || [])
            snap.outbound[item.id] = integrationSlice(item);
    }
    for (const row of input.journeys || []) {
        const journeyId = row.index.journeyId || row.journey.journeyId;
        snap.journeys[journeyId] = journeySlice(row.journey, row.index);
        for (const step of row.journey.business?.steps || []) {
            if (!step.stepId)
                continue;
            snap.steps[`${journeyId}/${step.stepId}`] = stepSlice(journeyId, step);
        }
    }
    return snap;
}
function pushMapDiff(items, kind, beforeMap, afterMap, sourceOf, entityOf) {
    const ids = new Set([...Object.keys(beforeMap), ...Object.keys(afterMap)]);
    for (const id of [...ids].sort()) {
        const before = beforeMap[id];
        const after = afterMap[id];
        if (!before && after) {
            items.push({
                changeId: `${kind}:${id}`, kind, op: 'added', entity: entityOf(id, after),
                source: sourceOf(id, after, 'after'), after,
            });
            continue;
        }
        if (before && !after) {
            items.push({
                changeId: `${kind}:${id}`, kind, op: 'removed', entity: entityOf(id, before),
                source: sourceOf(id, before, 'before'), before,
            });
            continue;
        }
        if (before && after && !sameJson(before, after)) {
            items.push({
                changeId: `${kind}:${id}`, kind, op: 'changed', entity: entityOf(id, after),
                source: sourceOf(id, after, 'after'), before, after,
            });
        }
    }
}
export function diffL4Snapshots(base, candidate) {
    const items = [];
    const entityIds = new Set([...Object.keys(base.entities), ...Object.keys(candidate.entities)]);
    for (const entityId of [...entityIds].sort()) {
        const before = base.entities[entityId];
        const after = candidate.entities[entityId];
        if (!before && after) {
            items.push({
                changeId: `entity:${entityId}`, kind: 'entity', op: 'added', entity: entityId,
                source: after.source, after: { entityId },
            });
        }
        else if (before && !after) {
            items.push({
                changeId: `entity:${entityId}`, kind: 'entity', op: 'removed', entity: entityId,
                source: before.source, before: { entityId },
            });
        }
        else if (before && after && !sameJson(entityBody(before), entityBody(after))) {
            items.push({
                changeId: `entity:${entityId}`, kind: 'entity', op: 'changed', entity: entityId,
                source: after.source,
                before: entityBody(before),
                after: entityBody(after),
            });
        }
        pushMapDiff(items, 'field', before?.fields || {}, after?.fields || {}, () => (after || before)?.source || `ontology/${entityId}.defs.ts`, () => entityId);
        pushMapDiff(items, 'transition', before?.transitions || {}, after?.transitions || {}, () => (after || before)?.source || `ontology/${entityId}.defs.ts`, () => entityId);
    }
    pushMapDiff(items, 'rule', base.rules, candidate.rules, () => 'rules.defs.ts', () => '');
    pushMapDiff(items, 'grant', base.grants, candidate.grants, () => 'access.defs.ts', () => '');
    pushMapDiff(items, 'process', Object.fromEntries(Object.entries(base.processes).map(([id, row]) => [id, processCompare(row)])), Object.fromEntries(Object.entries(candidate.processes).map(([id, row]) => [id, processCompare(row)])), () => 'workflows.defs.ts', () => '');
    const beforeTasks = {};
    const afterTasks = {};
    for (const process of Object.values(base.processes)) {
        for (const task of Object.values(process.tasks))
            beforeTasks[`${process.processId}.${task.taskId}`] = taskForDiff(task, process.processId);
    }
    for (const process of Object.values(candidate.processes)) {
        for (const task of Object.values(process.tasks))
            afterTasks[`${process.processId}.${task.taskId}`] = taskForDiff(task, process.processId);
    }
    pushMapDiff(items, 'task', beforeTasks, afterTasks, () => 'workflows.defs.ts', () => '');
    pushMapDiff(items, 'inbound', base.inbound, candidate.inbound, () => 'integration.defs.ts', () => '');
    pushMapDiff(items, 'outbound', base.outbound, candidate.outbound, () => 'integration.defs.ts', () => '');
    pushMapDiff(items, 'journey', base.journeys, candidate.journeys, (id) => `journeys/${id}.defs.ts`, () => '');
    pushMapDiff(items, 'step', base.steps, candidate.steps, (id) => `journeys/${id.slice(0, id.indexOf('/'))}.defs.ts`, (_id, value) => asString(value.entity));
    return items.sort((a, b) => a.changeId.localeCompare(b.changeId) || a.op.localeCompare(b.op));
}
async function readDefsAt(info) {
    const parsed = await readDefsJson(info);
    if (parsed)
        return parsed;
    return null;
}
export { parseDefsSource };
async function loadSnapshot(project, root) {
    if (!root)
        return emptySnapshot();
    const index = await readDefsAt(fileAt(project, root, 'ontology/index.defs.ts'));
    const entities = [];
    if (index) {
        for (const entityId of ns5OntologyEntityIds(index)) {
            const source = `ontology/${entityId}.defs.ts`;
            const entity = await readDefsAt(fileAt(project, root, source));
            if (entity)
                entities.push({ entity, source });
        }
    }
    const journeyIndex = await readDefsAt(fileAt(project, root, 'journeys/index.defs.ts'));
    const journeys = [];
    if (journeyIndex) {
        for (const entry of journeyIndex.journeys || []) {
            const journey = await readDefsAt(fileAt(project, root, `journeys/${entry.journeyId}.defs.ts`));
            if (journey)
                journeys.push({ journey, index: entry });
        }
    }
    return snapshotFromParsed({
        entities,
        rules: await readDefsAt(fileAt(project, root, 'rules.defs.ts')),
        access: await readDefsAt(fileAt(project, root, 'access.defs.ts')),
        workflows: await readDefsAt(fileAt(project, root, 'workflows.defs.ts')),
        integration: await readDefsAt(fileAt(project, root, 'integration.defs.ts')),
        journeys,
    });
}
async function findSealedBaseRoot(moduleName) {
    const canonical = normalizeModuleName(moduleName);
    const project = moduleFile(moduleName).project;
    const active = await readJson({ project, level: 4, folder: `${canonical}/pipeline/changes`, shortName: 'active', extension: '.json' });
    const fromActive = typeof active?.baseId === 'string' ? active.baseId.trim() : '';
    if (fromActive)
        return `${canonical}/pipeline/releases/${fromActive}/l4`;
    const catalog = await readJson({ project, level: 4, folder: `${canonical}/pipeline/releases`, shortName: 'index', extension: '.json' });
    const releases = Array.isArray(catalog?.releases) ? catalog.releases : [];
    const ranked = releases
        .map(row => ({ baseId: typeof row.baseId === 'string' ? row.baseId.trim() : '', createdAt: typeof row.createdAt === 'string' ? row.createdAt : '' }))
        .filter(row => row.baseId)
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    const baseId = ranked[ranked.length - 1]?.baseId || '';
    return baseId ? `${canonical}/pipeline/releases/${baseId}/l4` : '';
}
/**
 * Label written to `l4diff.json.base` plus the literal folder `loadSnapshot` reads.
 * A sealed revision uses `manifest.baseId` and never falls through to canonical.
 */
export async function resolveBase(moduleName) {
    const canonical = normalizeModuleName(moduleName);
    const rev = parseRevisionRoot(moduleFolder(canonical));
    if (rev) {
        const baseId = await declaredRevisionBaseId(canonical);
        const releaseRoot = releaseL4Root(canonical, baseId);
        if (!baseId || !releaseRoot || !releaseL4Present(canonical, baseId)) {
            const refusal = baseId
                ? releaseMissingRefusal(canonical, baseId)
                : revisionMissingRefusal(canonical, rev.changeId, rev.revisionId);
            return { base: '', root: '', refusal };
        }
        return { base: releaseRoot, root: releaseRoot, refusal: '' };
    }
    const sealed = await findSealedBaseRoot(moduleName);
    if (sealed)
        return { base: sealed, root: sealed, refusal: '' };
    const project = moduleFile(moduleName).project;
    if (!fileExists(fileAt(project, canonical, 'module.defs.ts')))
        return { base: '', root: '', refusal: '' };
    return { base: 'canonical', root: canonical, refusal: '' };
}
export function emptyL4Diff(moduleName, base = '', candidate = '') {
    return {
        schemaVersion: L4_DIFF_SCHEMA,
        moduleName: normalizeModuleName(moduleName),
        base,
        candidate,
        revision: null,
        items: [],
    };
}
export function l4diffFile(moduleName, box) {
    const base = moduleFile(moduleName);
    return { project: base.project, level: 4, folder: `${base.folder}/pool/${box}/web`, shortName: 'l4diff', extension: '.json' };
}
export async function runPlDiff(moduleName) {
    const existing = normalizeModuleName(moduleName);
    const candidate = moduleFolder(existing);
    const canonical = existing;
    const hasCandidate = candidate !== canonical;
    if (!hasCandidate) {
        const empty = emptyL4Diff(existing);
        await writeJson(l4diffFile(existing, 'l1'), empty);
        await writeJson(l4diffFile(existing, 'l2'), empty);
        return empty;
    }
    const project = moduleFile(existing).project;
    const resolved = await resolveBase(existing);
    if (resolved.refusal)
        throw new Error(resolved.refusal);
    const revision = await loadPlRevision(existing);
    const rev = parseRevisionRoot(candidate);
    if (rev && !revision)
        throw new Error(revisionMissingRefusal(existing, rev.changeId, rev.revisionId));
    const items = diffL4Snapshots(await loadSnapshot(project, resolved.root), await loadSnapshot(project, candidate));
    if (rev) {
        const manifest = await readL4Revision(project, existing, rev.changeId, rev.revisionId);
        if (!manifest || !Array.isArray(manifest.changedPaths)) {
            throw new Error('L4 revision manifest is missing changedPaths.');
        }
        // changedPaths and item.source are both paths relative to the module L4 root (e.g. rules.defs.ts).
        const covered = new Set(items.map(item => item.source));
        for (const path of manifest.changedPaths) {
            if (covered.has(path))
                continue;
            covered.add(path);
            items.push({
                changeId: `artifact:${path}`,
                kind: 'artifact',
                op: 'changed',
                entity: '',
                source: path,
            });
        }
        items.sort((a, b) => a.changeId.localeCompare(b.changeId) || a.op.localeCompare(b.op));
    }
    const diff = {
        schemaVersion: L4_DIFF_SCHEMA,
        moduleName: existing,
        base: resolved.base,
        candidate,
        revision,
        items,
    };
    await writeJson(l4diffFile(existing, 'l1'), diff);
    await writeJson(l4diffFile(existing, 'l2'), diff);
    return diff;
}
