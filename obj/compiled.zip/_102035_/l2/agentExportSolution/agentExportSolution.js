/// <mls fileReference="_102035_/l2/agentExportSolution/agentExportSolution.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readAgentProvenance } from '/_102035_/l2/agentNewSolution/helpers/ns4BuildStamp.js';
import { ns4RegistryRoleSubtype, ns4RegistryRoleTag, NS4_LEVEL1_SCHEMA_VERSION } from '/_102035_/l2/agentNewSolution/helpers/organizationTypes.js';
import { listNs4ModuleFolders, ns4FileExists, ns4ModuleFile, readNs4Pipeline, readNs4SolutionRegistry, readNs4Text, } from '/_102035_/l2/agentNewSolution/helpers/ns4Fs.js';
import { packSolution, packSolutionZip, parseArtifact, parseExportInvocation, } from '/_102035_/l2/agentExportSolution/helpers/packSolution.js';
import { zipBytesToBinaryString } from '/_102035_/l2/agentExportSolution/helpers/storedZip.js';
export function createAgent() {
    return {
        agentName: 'agentExportSolution',
        agentProject: 102035,
        agentFolder: 'agentExportSolution',
        agentDescription: 'Pack l4 modules into a portable solution.zip for the catalog',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const modules = parseExportInvocation(userPrompt || '');
    if (!modules.length) {
        return [statusTask(agent, context, 'Provide one or more module names after @@exportSolution.', true)];
    }
    const existing = listNs4ModuleFolders();
    const missing = modules.filter(name => !existing.has(name) || !ns4FileExists(ns4ModuleFile(name)));
    if (missing.length) {
        return [statusTask(agent, context, `Module not found: ${missing.join(', ')}.`, true)];
    }
    const catalogPrompt = await readExportPrompt();
    return [{
            type: 'add-message-ai',
            request: {
                action: 'addMessageAI',
                agentName: agent.agentName,
                inputAI: [{ type: 'system', content: catalogPrompt }],
                taskTitle: `export ${modules.join(' ')}`,
                threadId: context.message.threadId,
                userMessage: context.message.content,
                longTermMemory: {
                    taskName: 'exportSolution',
                    modules: modules.join(','),
                },
            },
        }];
}
async function beforePromptStep(_agent, context, parentStep, _step, hookSequential) {
    const modules = memoryModules(context);
    const summaries = await Promise.all(modules.map(summarizeModule));
    return [{
            type: 'prompt_ready',
            args: '',
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            hookSequential,
            parentStepId: parentStep.stepId,
            humanPrompt: summaries.join('\n\n'),
        }];
}
async function afterPromptStep(_agent, context, parentStep, step, hookSequential) {
    const modules = memoryModules(context);
    const description = catalogDescriptionOf(step) || modules.join(', ');
    const packed = await buildPackedSolution(modules, description);
    const zip = packSolutionZip(packed);
    await writeExportText({ project: mls.actualProject || 0, level: 4, folder: 'organization', shortName: 'solution', extension: '.json' }, `${JSON.stringify(packed.manifest, null, 2)}\n`);
    await writeExportText({ project: mls.actualProject || 0, level: 4, folder: 'organization', shortName: 'solution', extension: '.zip' }, zipBytesToBinaryString(zip));
    return [{
            type: 'update-status',
            hookSequential,
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: parentStep.stepId,
            stepId: step.stepId,
            status: 'completed',
            cleaner: 'input_output',
            traceMsg: `Exported ${modules.join(', ')} to l4/organization/solution.zip`,
        }];
}
export { parseExportInvocation };
async function buildPackedSolution(modules, catalogDescription) {
    const registry = await readNs4SolutionRegistry();
    const inputs = [];
    const actors = [];
    const roles = [];
    for (const moduleName of modules) {
        const files = await readModuleL4Files(moduleName);
        const pipeline = await readNs4Pipeline(moduleName);
        const moduleArtifact = parseArtifact(files.find(file => file.relativePath === 'module.defs.ts')?.content || '');
        const sourceLanguage = languageOf(moduleArtifact) || pipeline?.presentation.userLanguage || 'en';
        inputs.push({
            moduleName,
            sourceLanguage,
            sourcePrompt: pipeline?.sourcePrompt || '',
            files,
        });
        const block = registry?.modules.find(item => item.moduleName === moduleName);
        if (block) {
            actors.push(...block.actors.map(actor => ({ moduleName, actorId: actor.actorId, kind: actor.kind })));
            // ns5_43 T4 renamed the registry keys; the export bundle keeps its own contract.
            roles.push(...block.roles.map(role => ({
                mdmSubtype: ns4RegistryRoleSubtype(role),
                role: ns4RegistryRoleTag(role),
                namespace: role.namespace,
            })));
        }
    }
    const provenance = await readAgentProvenance().catch(() => ({ buildRef: '' }));
    return packSolution({
        modules: inputs,
        sourceProjectId: mls.actualProject || 0,
        level1SchemaVersion: registry?.level1SchemaVersion || NS4_LEVEL1_SCHEMA_VERSION,
        level1Roles: uniqueRoles(roles),
        actors,
        platformCommit: provenance.buildRef || '',
        catalogDescription,
    });
}
async function readModuleL4Files(moduleName) {
    const project = mls.actualProject || 0;
    const prefix = `${moduleName}/`;
    const files = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted')
            continue;
        const folder = String(file.folder || '');
        if (folder !== moduleName && !folder.startsWith(prefix))
            continue;
        const relative = folder === moduleName
            ? `${file.shortName}${file.extension}`
            : `${folder.slice(prefix.length)}/${file.shortName}${file.extension}`;
        const content = await readNs4Text({
            project, level: 4, folder, shortName: String(file.shortName), extension: String(file.extension),
        }, false);
        if (content)
            files.push({ relativePath: relative, content });
    }
    return files.sort((left, right) => left.relativePath.localeCompare(right.relativePath));
}
async function summarizeModule(moduleName) {
    const raw = await readNs4Text(ns4ModuleFile(moduleName), false);
    const artifact = parseArtifact(raw);
    const title = stringAt(artifact, ['module', 'title']) || moduleName;
    const purpose = stringAt(artifact, ['module', 'purpose']);
    const actors = Array.isArray(artifact?.businessScope?.actors)
        ? (artifact.businessScope.actors)
            .map(actor => `${actor.title || actor.actorId} (${actor.kind || ''})`).join(', ')
        : '';
    return [`Module: ${moduleName}`, `Title: ${title}`, purpose ? `Purpose: ${purpose}` : '', actors ? `Actors: ${actors}` : '']
        .filter(Boolean).join('\n');
}
function catalogDescriptionOf(step) {
    const payload = step.interaction?.payload?.[0];
    const fromFlexible = payload?.result && typeof payload.result.description === 'string' ? payload.result.description.trim() : '';
    if (fromFlexible)
        return fromFlexible;
    const raw = typeof payload === 'object' && payload && 'description' in payload
        ? String(payload.description || '').trim()
        : '';
    return raw;
}
function languageOf(artifact) {
    if (!artifact)
        return '';
    const presentation = artifact.presentation;
    if (typeof presentation?.userLanguage === 'string' && presentation.userLanguage)
        return presentation.userLanguage;
    if (typeof artifact.userLanguage === 'string')
        return artifact.userLanguage;
    return '';
}
function stringAt(value, path) {
    let cursor = value;
    for (const key of path) {
        if (!cursor || typeof cursor !== 'object')
            return '';
        cursor = cursor[key];
    }
    return typeof cursor === 'string' ? cursor : '';
}
function uniqueRoles(roles) {
    const seen = new Set();
    return roles.filter(role => {
        const key = `${role.namespace}|${role.role}|${role.mdmSubtype}`;
        if (seen.has(key))
            return false;
        seen.add(key);
        return true;
    });
}
function memoryModules(context) {
    const raw = context.task?.iaCompressed?.longMemory?.modules;
    const text = typeof raw === 'string' ? raw : '';
    return text.split(',').map(item => item.trim()).filter(Boolean);
}
async function readExportPrompt() {
    return readNs4Text({ project: 102035, level: 2, folder: 'agentExportSolution', shortName: 'promptCatalog', extension: '.md' }, true);
}
async function writeExportText(fileInfo, content) {
    const { createStorFile } = await import('/_102027_/l2/libStor.js');
    const key = mls.stor.getKeyToFile(fileInfo);
    let file = mls.stor.files[key];
    if (!file)
        file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
    else if (file.status === 'deleted') {
        file.status = 'changed';
        file.updatedAt = new Date().toISOString();
    }
    await mls.stor.localStor.setContent(file, { contentType: 'string', content });
}
function statusTask(agent, context, message, isError) {
    return {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: `<!-- modelType: general -->\n${message}` },
                { type: 'human', content: message },
            ],
            taskTitle: 'export Solution',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {
                taskName: 'exportSolution',
                statusOnly: 'true',
                statusOutcome: isError ? 'error' : 'info',
            },
        },
    };
}
