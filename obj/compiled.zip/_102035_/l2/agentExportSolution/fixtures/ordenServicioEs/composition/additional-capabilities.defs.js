/// <mls fileReference="_102035_/l4/ordenServicioEs/composition/additional-capabilities.defs.ts" enhancement="_blank"/>
export const ordenServicioEsAdditionalCapabilities = {
    "schemaVersion": "2026-08-09-ns4-composition-v1",
    "moduleName": "ordenServicioEs",
    "userLanguage": "es",
    "analysisSummary": "No hace falta un módulo hermano: el taller opera solo la orden de servicio.",
    "recommendations": [],
    "compositionHash": "sha256:00",
    "approvedBy": "auto",
    "approvedAt": "2026-09-09T00:00:00.000Z",
    "realization": { "status": "pending", "compiledFromCompositionHash": "sha256:00" }
};
export default ordenServicioEsAdditionalCapabilities;
