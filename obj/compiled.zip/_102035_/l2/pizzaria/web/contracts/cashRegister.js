/// <mls fileReference="_102035_/l2/pizzaria/web/contracts/cashRegister.ts" enhancement="_blank" />
export {};
