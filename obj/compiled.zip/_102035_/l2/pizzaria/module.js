export const moduleGenome = {
    'web/desktop/page11': {
        designSystem: 'default',
        device: 'desktop',
        layout: 'standard',
    }
};
export const skills = {
    web: {
        sharedPath: '/_102035_/l2/pizzaria/web/shared',
        sharedSkill: '/_102020_/l2/agents/newModule/skills/genPageShared.ts'
    }
};
export const moduleStates = {};
export const moduleShellPreferences = {
    layout: {
        asideMode: {
            desktop: 'inline',
            mobile: 'fullscreen',
        },
    },
};
export const moduleFrontendDefinition = {
    pageTitle: 'pizzaria',
    device: 'desktop',
    navigation: [
        {
            id: 'cashRegister',
            label: 'cashRegister',
            href: '/pizzaria/cashRegister',
            description: 'cashRegister',
        },
    ],
    routes: [
        {
            path: '/pizzaria/cashRegister',
            aliases: [],
            entrypoint: '/_102035_/l2/pizzaria/web/desktop/page11/cashRegister.js',
            tag: 'pizzaria--web--desktop--page11--cash-register-102035',
            title: 'cashRegister',
        },
    ],
};
