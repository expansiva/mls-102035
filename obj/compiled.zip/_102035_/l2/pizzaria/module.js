export const moduleGenome = {
    page11: {
        device: 'desktop',
        layout: 'standard',
    },
    page21: {
        device: 'mobile',
        layout: 'standard',
    },
};
export const moduleStates = {};
export const moduleShellPreferences = {
    layout: {
        asideMode: {
            desktop: 'inline',
            mobile: 'fullscreen',
        },
    },
};
export const moduleFrontendDefinition = {
    pageTitle: 'pizzaria',
    device: 'desktop',
    navigation: [
        {
            id: 'displayCozinha',
            label: 'displayCozinha',
            href: '/pizzaria/displayCozinha',
            description: 'displayCozinha',
        },
        {
            id: 'confirmacaoImpressaoComanda',
            label: 'confirmacaoImpressaoComanda',
            href: '/pizzaria/confirmacaoImpressaoComanda',
            description: 'confirmacaoImpressaoComanda',
        },
        {
            id: 'metasTempoConfiguracao',
            label: 'metasTempoConfiguracao',
            href: '/pizzaria/metasTempoConfiguracao',
            description: 'metasTempoConfiguracao',
        },
    ],
    routes: [
        {
            path: '/pizzaria/displayCozinha',
            aliases: [],
            entrypoint: '/_102035_/l2/pizzaria/web/desktop/page11/displayCozinha.js',
            tag: 'pizzaria--web--desktop--page11--display-cozinha-102035',
            title: 'displayCozinha',
        },
        {
            path: '/pizzaria/confirmacaoImpressaoComanda',
            aliases: [],
            entrypoint: '/_102035_/l2/pizzaria/web/desktop/page11/confirmacaoImpressaoComanda.js',
            tag: 'pizzaria--web--desktop--page11--confirmacao-impressao-comanda-102035',
            title: 'confirmacaoImpressaoComanda',
        },
        {
            path: '/pizzaria/metasTempoConfiguracao',
            aliases: [],
            entrypoint: '/_102035_/l2/pizzaria/web/desktop/page11/metasTempoConfiguracao.js',
            tag: 'pizzaria--web--desktop--page11--metas-tempo-configuracao-102035',
            title: 'metasTempoConfiguracao',
        },
    ],
};
