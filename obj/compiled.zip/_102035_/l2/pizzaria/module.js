export const moduleGenome = {
    'web/desktop/page11': {
        designSystem: 'default',
        designSystemSkill: '_102020_/l2/agents/newModule/skills/defaultDs.js',
        device: 'desktop',
        layout: 'standart',
        layoutSkill: '_102020_/l2/agents/newModule/skills/genPageRender.ts',
    }
};
export const skills = {
    web: {
        sharedPath: 'web/shared',
        sharedSkill: '/_102020_/l2/agents/newModule/skills/genPageShared.ts'
    }
};
export const moduleShellPreferences = {
    layout: {
        asideMode: {
            desktop: 'inline',
            mobile: 'fullscreen',
        },
    },
};
export const moduleFrontendDefinition = {
    pageTitle: 'pizzaria',
    device: 'desktop',
    navigation: [
        {
            id: 'areaPublicaAcompanhamento',
            label: 'areaPublicaAcompanhamento',
            href: '/pizzaria/areaPublicaAcompanhamento',
            description: 'areaPublicaAcompanhamento',
        },
        {
            id: 'areaPublicaCardapio',
            label: 'areaPublicaCardapio',
            href: '/pizzaria/areaPublicaCardapio',
            description: 'areaPublicaCardapio',
        },
        {
            id: 'areaPublicaCheckout',
            label: 'areaPublicaCheckout',
            href: '/pizzaria/areaPublicaCheckout',
            description: 'areaPublicaCheckout',
        },
    ],
    routes: [
        {
            path: '/pizzaria/areaPublicaAcompanhamento',
            aliases: [],
            entrypoint: '/_102035_/l2/pizzaria/web/desktop/page11/areaPublicaAcompanhamento.js',
            tag: 'pizzaria--web--desktop--page11--area-publica-acompanhamento-102035',
            title: 'areaPublicaAcompanhamento',
        },
        {
            path: '/pizzaria/areaPublicaCardapio',
            aliases: [],
            entrypoint: '/_102035_/l2/pizzaria/web/desktop/page11/areaPublicaCardapio.js',
            tag: 'pizzaria--web--desktop--page11--area-publica-cardapio-102035',
            title: 'areaPublicaCardapio',
        },
        {
            path: '/pizzaria/areaPublicaCheckout',
            aliases: [],
            entrypoint: '/_102035_/l2/pizzaria/web/desktop/page11/areaPublicaCheckout.js',
            tag: 'pizzaria--web--desktop--page11--area-publica-checkout-102035',
            title: 'areaPublicaCheckout',
        },
    ],
};
