export const moduleGenome = {
    page11: {
        device: 'desktop',
        layout: 'standard',
    },
    page21: {
        device: 'mobile',
        layout: 'standard',
    },
};
export const moduleStates = {};
export const moduleShellPreferences = {
    layout: {
        asideMode: {
            desktop: 'inline',
            mobile: 'fullscreen',
        },
    },
};
export const moduleFrontendDefinition = {
    pageTitle: 'pizzaria',
    device: 'desktop',
    navigation: [
        {
            id: 'displayCozinha',
            label: 'displayCozinha',
            href: '/pizzaria/displayCozinha',
            description: 'displayCozinha',
        },
    ],
    routes: [
        {
            path: '/pizzaria/displayCozinha',
            aliases: [],
            entrypoint: '_102035_/l2/pizzaria/web/desktop/page11/displayCozinha.js',
            tag: 'pizzaria--web--desktop--page11--display-cozinha-102035',
            title: 'displayCozinha',
        },
    ],
};
